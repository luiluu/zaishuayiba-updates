// 大厅漩涡过场（重制铺垫）。
// 1. 记录哪些过场已经播过：记在 config（不跟存档走），换存档、新开档都不会再播。
//    地图事件用 CodexWhisper.seen('键') 判断，用 CodexWhisper.mark('键') 记下并立即写盘。
// 2. CodexWhisper.lie(事件ID, true/false)：把该事件的行走图横放成「趴着」，或扶正。只在过场里用。
window.CodexRuntime.register('installRemakeWhisperRuntime',function(){
 'use strict';
 var seen=Object.create(null);
 function sprite(eventId){
  var scene=SceneManager._scene,set=scene&&scene._spriteset,ev=$gameMap.event(eventId);
  if(!set||!set._characterSprites||!ev)return null;
  for(var i=0;i<set._characterSprites.length;i++)if(set._characterSprites[i]._character===ev)return set._characterSprites[i];
  return null;
 }
 var W=window.CodexWhisper={
  seen:function(key){return !!seen[String(key)];},
  mark:function(key){seen[String(key)]=true;ConfigManager.save();},
  lie:function(eventId,on){var s=sprite(eventId);if(s)s.rotation=on?Math.PI/2:0;}
 };
 var make=ConfigManager.makeData;
 ConfigManager.makeData=function(){var data=make.apply(this,arguments);data.codexWhisperSeen=Object.keys(seen);return data;};
 var apply=ConfigManager.applyData;
 ConfigManager.applyData=function(data){
  apply.apply(this,arguments);
  var list=data&&Array.isArray(data.codexWhisperSeen)?data.codexWhisperSeen:[];
  list.forEach(function(key){seen[String(key)]=true;});
 };
 return W;
});
