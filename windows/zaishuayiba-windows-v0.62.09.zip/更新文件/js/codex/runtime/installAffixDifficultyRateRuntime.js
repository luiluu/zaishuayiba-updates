// 【Claude·未经Codex检验】v0.62 高阶词条概率随难度浮动（方案 design/drops/混沌神话词条概率随难度_方案_v0.3.md，用户 2026-10-31 确认）。
// - 只管「整行都是神话／混沌神话词条」的那一行（行内记录全部带 <quality:14> 或 <quality:15>），按标签识别，不写死编号。
// - 实际概率 ＝ min（底材配置概率 × 倍率 M，50%）；天灾 M＝1 时直接走原函数，与旧版逐值一致。
// - 难度按路线开关判断（与修行页、难度继承模块同一套开关），不读 $gameSystem 难度 ID：副本地图会把难度 ID 临时设成 1。
// - 洪荒 M ＝ 2 ＋ 3 ×（诅咒倍率 − 1）÷（6.075 − 1），范围 2～5，越靠后的重诅咒加得越多；宝宝 M＝25（洪荒最高的 5 倍）。
// - 掷骰仍用 Star_RomGetItems 预生成的随机表（读档不能重掷），每行消耗一个随机数，与原函数相同。
window.CodexRuntime.register('installAffixDifficultyRateRuntime',function(){
 'use strict';
 var C=window.CodexAffixRate={version:1,CAP:50,HH_MAX:6.075,
  // 路线开关 → 倍率；按顺序取第一个开着的（高难度在前，补强开关与本体同档）
  ROUTES:[{key:'primordial',name:'洪荒',sw:[2483,2463]},{key:'doom',name:'灭世',sw:[2487,2462],m:1.5},
   {key:'calamity',name:'天灾',sw:[2489,2461],m:1},{key:'hell',name:'地狱',sw:[2494],m:0.75},
   {key:'hard',name:'困难',sw:[2500],m:0.55},{key:'normal',name:'普通',sw:[2491],m:0.4},
   {key:'easy',name:'简单',sw:[2492],m:0.3},{key:'baby',name:'宝宝',sw:[2496],m:25}]};
 function num(v){v=Number(v);return isFinite(v)?v:0;}
 C.route=function(){
  if(!window.$gameSwitches)return null;
  for(var i=0;i<C.ROUTES.length;i++){var r=C.ROUTES[i];
   if(r.sw.some(function(id){return $gameSwitches.value(id);}))return r;}
  return null;};
 C.curse=function(){var H=window.CodexHonghuang;return H&&H.curseBonus?Math.max(1,num(H.curseBonus())||1):1;};
 C.factor=function(){
  var r=C.route();if(!r)return 1;
  if(r.key==='primordial'){var h=Math.min(C.HH_MAX,C.curse());return 2+3*(h-1)/(C.HH_MAX-1);}
  return r.m;};
 C.rate=function(base){return Math.min(C.CAP,num(base)*C.factor());};
 C.label=function(){var r=C.route();return (r?r.name:'未选路线')+' ×'+(Math.round(C.factor()*100)/100);};
 // 这一行的档位：全部有效记录都是 14／15 品质才算高阶行；返回最高档，否则 0
 function quality(item){var m=item&&/<quality:\s*(\d+)>/i.exec(item.note||'');return m?Number(m[1]):0;}
 C.lineTier=function(choiceObj,dataType){
  var lines=choiceObj&&choiceObj.lineChoices;if(!lines||!lines.length)return 0;
  var top=0,ok=true,any=false;
  lines.forEach(function(lc){DreamX.parseNumberRanges(lc.line).forEach(function(id){
   var it=dataType[id];if(!DreamX.RandomPrefixSuffix.isValidItem(it))return;
   any=true;var q=quality(it);if(q<14)ok=false;else top=Math.max(top,q);});});
  return ok&&any?top:0;};
 // 与 Star_RomGetItems 版 choose 开头完全相同的随机表检查
 function ensureTables(){
  var P=$gameParty,L=Star.RomGetItems.RomLength,R=Star.RomGetItems.RomLengthRef,i;
  P.RomDreamX=P.RomDreamX||[];P.RomDreamXNum=P.RomDreamXNum||0;
  if(P.RomDreamX.length!=L||P.RomDreamXNum>R){P.RomDreamX=[];for(i=0;i<L;i++)P.RomDreamX[i]=Math.random();P.RomDreamXNum=0;}
  P.RomDreamXs=P.RomDreamXs||[];P.RomDreamXsNum=P.RomDreamXsNum||0;
  if(P.RomDreamXs.length!=L||P.RomDreamXsNum>R){P.RomDreamXs=[];for(i=0;i<L;i++)P.RomDreamXs[i]=Math.randomInt(2);}}
 C.stats={rolls:0,hits:0};
 if(window.DreamX&&DreamX.RandomPrefixSuffix&&window.Star&&Star.RomGetItems){
  var original=DreamX.RandomPrefixSuffix.choose;
  C.originalChoose=original;
  DreamX.RandomPrefixSuffix.choose=function(choiceObj,dataType){
   var M=C.factor();
   if(M===1||!C.lineTier(choiceObj,dataType))return original.apply(this,arguments);
   ensureTables();
   var P=$gameParty,r=P.RomDreamX[P.RomDreamXNum];P.RomDreamXNum++;
   var roll=num(r)*100,choices=[];
   choiceObj.lineChoices.forEach(function(lc){
    var ids=DreamX.parseNumberRanges(lc.line).filter(function(id){return DreamX.RandomPrefixSuffix.isValidItem(dataType[id]);});
    if(ids.length)choices.push({chance:Math.min(C.CAP,num(lc.chance)*M),base:num(lc.chance),ids:ids});});
   choices.sort(function(a,b){return a.base-b.base;});
   C.stats.rolls++;
   for(var i=0;i<choices.length;i++){
    if(roll<choices[i].chance){C.stats.hits++;return DreamX.randomArrayElement(choices[i].ids);}
    roll-=choices[i].chance;}
   return undefined;};
 }
 // 显示：修行页末尾加一段
 var G=window.CodexGuide;
 if(G&&G.detailRows){var rows=G.detailRows;G.detailRows=function(){
  var out=rows.apply(this,arguments);if(!out||!out.push)return out;
  var M=C.factor(),r=C.route();
  out.push({type:'blank'});
  out.push({type:'head',text:'高阶词条概率　'+(r?r.name:'未选路线')});
  out.push({type:'text',text:'神话、混沌神话词条概率：天灾的 ×'+(Math.round(M*100)/100)+'（单行最高 '+C.CAP+'%）'});
  if(r&&r.key==='primordial')out.push({type:'text',text:'\\C[8]洪荒按诅咒倍率 ×'+C.curse().toFixed(2)+' 取值：全轻 ×2，四重一中 ×5\\C[0]'});
  out.push({type:'text',text:'\\C[8]例：星辰耀光的混沌行 '+C.rate(1).toFixed(2).replace(/\.?0+$/,'')+'%\\C[0]'});
  return out;};}
 return C;
});
