// 【Codex·未经Claude检验】v0.03 战力显示与估算开关；未经claude检验。
/* Combat power v2. Derived views only: no database IDs or persistent score fields. */
window.CodexRuntime.register('installCombatPowerRuntime', function () {
    'use strict';
    var root = window, gearCache = new WeakMap(), actorCache = new WeakMap();
    function enabled(){return ConfigManager.codexPowerEnabled!==false;}
    ConfigManager.codexPowerEnabled=true;
    function clearPowerCache(){gearCache=new WeakMap();actorCache=new WeakMap();enemyCache=new WeakMap();if(toast)toast.style.display='none';}
    function setEnabled(value){var before=enabled();ConfigManager.codexPowerEnabled=!!value;if(before!==enabled()){clearPowerCache();window.dispatchEvent(new CustomEvent('codex-power-setting'));}}
    var makeConfig=ConfigManager.makeData,applyConfig=ConfigManager.applyData;
    ConfigManager.makeData=function(){var data=makeConfig.apply(this,arguments);data.codexPowerEnabled=enabled();return data;};
    ConfigManager.applyData=function(data){applyConfig.apply(this,arguments);setEnabled(!data||data.codexPowerEnabled!==false);};
    var makeOptions=Window_Options.prototype.makeCommandList,changeOption=Window_Options.prototype.changeValue;
    Window_Options.prototype.makeCommandList=function(){makeOptions.apply(this,arguments);this.addCommand('战力显示与估算','codexPowerEnabled');};
    Window_Options.prototype.changeValue=function(symbol,value){var before=enabled(),result=changeOption.apply(this,arguments);if(symbol==='codexPowerEnabled'&&before!==enabled()){clearPowerCache();window.dispatchEvent(new CustomEvent('codex-power-setting'));}return result;};
    var names = ['生命','魔法','物攻','物防','魔攻','魔防','敏捷','幸运'];
    // Common reference attributes make the score of an item independent of its wearer.
    var reference = [1000,300,100,100,100,100,100,100];
    var weights = [[0,0.08,0],[0,0,0.06],[3,0,0],[0,2,0],[3,0,0],[0,2,0],[0.8,0.2,0.5],[0.2,0,0.2]];
    var xWeights = [[1000,0,0],[0,1200,0],[1500,0,0],[0,800,0],[0,1000,0],[0,1200,0],[1200,0,0],[0,2000,0],[0,0,600],[0,0,400]];
    var labels = ['输出','生存','辅助'];
    function num(v) { v=Number(v); return isFinite(v)?v:0; }
    function clamp(v,min,max) { return Math.max(min,Math.min(max,num(v))); }
    function isGear(i) { return !!i && (DataManager.isWeapon(i)||DataManager.isArmor(i)); }
    function format(v) { v=Math.round(num(v)); var a=Math.abs(v); return a>=1e12?(v/1e12).toFixed(2)+'万亿':a>=1e8?(v/1e8).toFixed(2)+'亿':a>=1e4?(v/1e4).toFixed(2)+'万':String(v); }
    function delta(v) { return (v>0?'+':'')+format(v); }
    function empty() { return {parts:[0,0,0],rows:[]}; }
    function add(s,label,values) { values=values.map(num); if(!values.some(function(v){return v!==0;}))return; values.forEach(function(v,i){s.parts[i]+=v;}); s.rows.push({label:label,parts:values,value:values.reduce(function(a,b){return a+b;},0)}); }
    function attribute(s,id,value,label) {if((id===3||id===5)&&root.CodexDamage){var d=reference[id],before=CodexDamage.defenseRate(100,d),after=CodexDamage.defenseRate(100,Math.max(0,d+value));value=(before/after-1)*200;}add(s,label||names[id],weights[id].map(function(w){return value*w;})); }
    function finish(s) { var total=Math.max(0,Math.round(s.parts.reduce(function(a,b){return a+num(b);},0))),positive=s.parts.reduce(function(a,b){return a+Math.max(0,num(b));},0),ratio=positive?total/positive:0;s.parts=s.parts.map(function(v){return Math.max(0,num(v))*ratio;});s.parts[0]=Math.min(total,Math.round(s.parts[0]));s.parts[1]=Math.min(total-s.parts[0],Math.round(s.parts[1]));s.parts[2]=total-s.parts[0]-s.parts[1];s.total=total;return s; }
    // Common early/middle/late references value capped probabilities and separate damage pools.
    var gearReferences=[{weight:0.1,hit:0.95,crit:0.25,critical:1.5,final:1},{weight:0.2,hit:1,crit:0.75,critical:3,final:3},{weight:0.7,hit:1,crit:1,critical:5,final:8}];
    function effectPools(s){return s.effects||(s.effects={x:[0,0,0,0,0,0,0,0,0,0],critical:0,final:0,elements:{},magnify:{},penetrate:{fixed:{},percent:{}},weapons:{},physical:1,magical:1});}
    function traits(s,obj,attributesIncluded) {
        (obj.traits||[]).forEach(function(t){var id=num(t.dataId),v=num(t.value),a=[0,0,0],label='';
            if(t.code===21&&!attributesIncluded&&weights[id]){attribute(s,id,reference[id]*(v-1),names[id]+'倍率');return;}
            if(t.code===22&&xWeights[id]){effectPools(s).x[id]+=v;return;}
            if(t.code===23){
                if(id===1){a[1]=(v-1)*400;label='防御效果';}
                if(id===2){a[2]=(v-1)*800;label='治疗效果';}
                if(id===3){a[2]=(v-1)*150;label='药品效果';}
                if(id===4){a[2]=(1-v)*600;label='魔法减耗';}
                if(id===5){a[2]=(v-1)*400;label='怒气获得';}
                if(id===6||id===7){a[1]=(1-v)*1200;label=id===6?'物理减伤':'魔法减伤';}
            }
            if(t.code===11){a[1]=(1-v)*120;label='元素抗性';}
            if(t.code===13){a[1]=(1-v)*60;label='状态抵抗';}
            if(t.code===14){var state=$dataStates[id];if(state&&(state.restriction>0||/毒|诅咒|灼伤|流血|封印|沉默|眩晕|麻痹|虚弱/.test(state.name))){a[1]=80;label='异常免疫';}}
            if(t.code===32){a[2]=clamp(v,0,1)*100;label='攻击附加状态';}
            if(t.code===33){a[0]=v*2;label='攻击速度';}
            if(t.code===34){a[0]=v*600;label='额外攻击次数';}
            if(t.code===61){a[0]=clamp(v,0,1)*600;a[2]=clamp(v,0,1)*200;label='额外行动';}
            if(t.code===62&&id===2){a[1]=150;a[2]=150;label='保护队友';}
            if(t.code===64&&(id===2||id===3)){a[2]=80;label=id===3?'先制':'防偷袭';}
            if(label)add(s,label,a);
        });
    }
    function notes(s,obj,visited) {
        var note=obj.note||'',m,p=effectPools(s),re=/<(passiveHarmRi|passiveCrHarmRi|passiveELUP\d+|passiveHEUP|passiveAPLUS|passiveHarmRe\d+|SkillCriPush(?:All|Mf|Zj)|SkETypeHarmRi\d+|DBHPLSteal)\s*:\s*([+-]?\d+(?:\.\d+)?)\s*%?\s*>/gi;
        while((m=re.exec(note))){var key=m[1].toLowerCase(),v=num(m[2]);
            if(key==='passiveharmri')p.final+=v/100;
            else if(key==='passivecrharmri')p.critical+=v/100;
            else if(/^passiveelup/.test(key)){var element=num(key.replace('passiveelup',''));p.elements[element]=(p.elements[element]||0)+v/100;}
            else if(/^sketypeharmri/.test(key)){var weapon=num(key.replace('sketypeharmri',''));p.weapons[weapon]=(p.weapons[weapon]||0)+v/100;}
            else if(key==='passiveheup')add(s,'治疗增幅',[0,0,v*8]);
            else if(key==='passiveaplus')add(s,'再行动',[clamp(v,0,100)*6,0,clamp(v,0,100)*2]);
            else if(/^passiveharmre/.test(key))add(s,'固定减伤',[0,v*0.1,0]);
            else if(/^skillcripush/.test(key))p.x[2]+=v/100;
            else if(key==='dbhplsteal')add(s,'生命吸取',[0,v*6,0]);
        }
        var er=/<Element Amplify (\d+):\s*([+-]?[\d.]+)%\s*>/gi;while((m=er.exec(note))){var ei=num(m[1]);p.elements[ei]=(p.elements[ei]||0)+num(m[2])/100;}
        var mr=/<Element Magnify (\d+):\s*([+-]?[\d.]+)%\s*>/gi;while((m=mr.exec(note))){var ei=num(m[1]);p.magnify[ei]=(p.magnify[ei]||0)+num(m[2])/100;}
        //【DeepSeek·未经Codex/Claude检验】v0.51：与被动缓存同口径：无元素ID=全部元素、同对象重复标签只计一次。
        var _depSeen={},pr=/<DepassiveHarmRe(\d+):\s*([+-]?[\d.]+)(%?)\s*>/gi;
        while((m=pr.exec(note))){
            var _key=(m[1]===''?'ALL':String(num(m[1])))+'|'+m[2]+m[3];if(_depSeen[_key])continue;_depSeen[_key]=1;
            var pool=m[3]?'percent':'fixed',_dv=num(m[2]),_dels=m[1]===''?(function(){var out=[],n=($dataSystem&&$dataSystem.elements)?$dataSystem.elements.length:16;for(var i=1;i<n;i++){if(i===10||!$dataSystem.elements[i])continue;out.push(i);}return out.length?out:[1,2,3,4,5,6,7,8,9,11,12,13,14,15];})():[num(m[1])];
            _dels.forEach(function(ei){p.penetrate[pool][ei]=(p.penetrate[pool][ei]||0)+_dv;});
        }
        var attr=/<passivePBST([0-7]):\s*([+-]?\d+(?:\.\d+)?)(%?)\s*>/gi;
        while((m=attr.exec(note)))attribute(s,num(m[1]),num(m[2])*(m[3]?reference[num(m[1])]/100:1),'被动属性 · '+names[num(m[1])]);
        var xr=/<passiveXPBST([0-9]):\s*([+-]?\d+(?:\.\d+)?)%?\s*>/gi;
        while((m=xr.exec(note)))p.x[num(m[1])]+=num(m[2])/100;
        var sr=/<passiveSPBST([0-9]):\s*([+-]?\d+(?:\.\d+)?)%?\s*>/gi;
        while((m=sr.exec(note)))traits(s,{traits:[{code:23,dataId:num(m[1]),value:1+num(m[2])/100}]},true);
        var rr=/<AgainUse(?:All|Mf|Zj|\d+):\s*([+-]?\d+(?:\.\d+)?)%?\s*>/gi;
        while((m=rr.exec(note)))add(s,'额外释放',[clamp(m[1],0,100)*6,0,0]);
        m=/<SelfPhysRate:([\d.]+)>/i.exec(note);if(m)p.physical*=num(m[1]);
        m=/<SelfElemRate:([\d.]+)>/i.exec(note);if(m)p.magical*=num(m[1]);
        visited=visited||{};(obj.passiveStates||[]).forEach(function(id){if(visited[id])return;visited[id]=true;var state=$dataStates[id];if(!state)return;traits(s,state,false);(state.G_ShuXing||[]).forEach(function(v,i){attribute(s,i,num(v),'装备被动 · '+names[i]);});notes(s,state,visited);});
    }
    var referenceDamageCache=new Map(),gearGainCache=new Map();
    function gearEffects(s,item) {
        var p=effectPools(s),element=Object.keys(p.elements).reduce(function(v,k){return v+p.elements[k]/(root.CodexElements?CodexElements.activeIds.length:13);},0),weapon=DataManager.isWeapon(item)?num(p.weapons[item.wtypeId]):Object.keys(p.weapons).reduce(function(v,k){return Math.max(v,p.weapons[k]);},0)*0.5;
        var gainKey=JSON.stringify([root.CodexDamage&&CodexDamage.version,p.x[0],p.x[2],p.critical,p.final,p.elements,p.magnify,p.penetrate,weapon,p.physical,p.magical]);
        var gain=gearGainCache.get(gainKey);
        if(gain===undefined){gain=gearReferences.reduce(function(total,r){
            function average(withGear){
                var c={globalHarmRi:r.final-1+(withGear?p.final:0),critHarmRi:r.critical-1.5+(withGear?p.critical:0),skillPass:{},SkETypeHarmRi:{},skillTypeDvup:{QA:withGear?weapon:0},penetrateHarmRe:withGear?p.penetrate:{fixed:{},percent:{}}};
                var a=Object.create(Game_Actor.prototype);a._passiveCache=c;a.isActor=function(){return true;};a.actorId=function(){return 0;};a.skills=function(){return [];};a.equips=function(){return [];};a.traitObjects=function(){return [{note:'<SelfPhysRate:'+(withGear?p.physical:1)+'>\n<SelfElemRate:'+(withGear?p.magical:1)+'>'}];};a.param=function(){return 100;};a.criticalMultiplierBonus=function(){return 0;};a.elementAmplifyRate=function(e){return withGear?num(p.elements[e]):0;};a.elementAmplifyNRate=function(){return 0;};a.elementMagnifyRate=function(e){return 1+(withGear?num(p.magnify[e]):0);};a.isNullElement=function(){return false;};a.isWtypeEquipped=function(){return false;};
                var t=Object.create(Game_Enemy.prototype);t._passiveCache={harmRe:{}};[1].concat(CodexElements.activeIds).forEach(function(e){t._passiveCache.harmRe[e]=25000*r.final;});t._codexNeutralAffinity=true;t.enemy=function(){return {note:''};};t.enemyId=function(){return 0;};t.param=function(){return 100;};t.elementRate=function(){return 1;};t.sparam=function(){return 1;};t.traitObjects=function(){return [];};t.isGuard=function(){return false;};t.isActor=function(){return false;};t.isStateAffected=function(){return false;};
                var x=new Game_Action(a);x.subject=function(){return a;};var item={id:900000,meta:{SkillTypes:'["QA"]'},note:'',hitType:1,critMult:Yanfly.Param.critMult,damage:{type:1,formula:'1000000',critical:true,variance:0,elementId:1}};x.item=function(){return item;};x.evalDamageFormula=function(){return 1000000;};
                var hit=clamp(r.hit+(withGear?p.x[0]:0),0,1),cri=clamp(r.crit+(withGear?p.x[2]:0),0,1);
                var elements=[1].concat(CodexElements.activeIds),sum=0;
                elements.forEach(function(e){item.damage.elementId=e;item.hitType=e===1?1:2;var opts={preview:true,isolated:true,reference:true,commit:false,critical:false,mode:e===1?'physical':'magical'},normal=CodexDamage.calculate(x,t,opts).value;opts.critical=true;var crit=CodexDamage.calculate(x,t,opts).value;sum+=(normal*(1-cri)+crit*cri)*(e===1?.5:.5/CodexElements.activeIds.length);});return sum*hit;
            }
            var referenceKey=JSON.stringify([root.CodexDamage&&CodexDamage.version,r]);
            var before=referenceDamageCache.get(referenceKey);if(before===undefined){before=average(false);referenceDamageCache.set(referenceKey,before);}
            var after=average(true);return total+r.weight*(before?after/before-1:0);
        },0);gearGainCache.set(gainKey,gain);}

        add(s,'命中 / 暴击与伤害乘区',[(2000+Math.max(0,s.parts[0]))*gain,0,0]);
        for(var i=1;i<10;i++){if(i===2)continue;var effective=clamp(0.05+p.x[i],0,1)-0.05;add(s,['命中','闪避','暴击','暴击闪避','魔法闪避','魔法反射','反击','生命再生','魔法再生','怒气再生'][i],xWeights[i].map(function(w){return effective*w;}));}
    }
    function equipment(item) {
        if(!enabled())return finish(empty());
        if(!isGear(item))return finish(empty());
        var sig=JSON.stringify([root.CodexDamage&&CodexDamage.version,item.params,item.traits,item.note,item.level,item.paramPlusPerLevel,item.passiveStates]),cached=gearCache.get(item);if(cached&&cached.signature===sig)return cached.value;
        var s=empty(),magic=/<Magic Weapon>/i.test(item.note||''),level=magic?Math.max(0,num(item.level)||num(item.initLevel)||1):0;
        (item.params||[]).forEach(function(v,i){if(weights[i])attribute(s,i,num(v),'基础属性 · '+names[i]);});
        if(magic)(item.paramPlusPerLevel||[]).forEach(function(v,i){if(weights[i])attribute(s,i,num(v)*level,'法宝成长 · '+names[i]);});
        traits(s,item,false);notes(s,item);
        var id=num(item.baseItemId||item.id);
        if(DataManager.isArmor(item)&&root.CodexRaven&&id===CodexRaven.ARTIFACT_ID)(CodexRaven.ARTIFACT_BASE_BONUS||[]).forEach(function(v,i){attribute(s,i,num(v),'专属固定 · '+names[i]);});
        if(DataManager.isArmor(item)&&root.CodexMira&&id===CodexMira.armor){effectPools(s).elements[2]=(effectPools(s).elements[2]||0)+0.2;}
        if(DataManager.isArmor(item)&&root.CodexToji&&id===CodexToji.armor){effectPools(s).physical*=1.11;}
        // 2026-10-08: growth gear counts its current stage (心之钢层数／狂妄盛名).
        if(DataManager.isArmor(item)&&root.CodexHubris&&CodexHubris.isGear&&CodexHubris.isGear(item)&&CodexHubris.rateFor){var fame=CodexHubris.growth(item),hubrisRate=CodexHubris.rateFor(item,fame);effectPools(s).physical*=1+(hubrisRate-1)*0.6;}
        if(DataManager.isArmor(item)&&root.CodexHeartsteel&&CodexHeartsteel.isGear(item)&&CodexHeartsteel.hpRate){var steelRate=CodexHeartsteel.hpRate(item);if(steelRate!==1)attribute(s,0,reference[0]*(steelRate-1),'心钢 · 生命×'+steelRate.toFixed(1)+'（层数'+CodexHeartsteel.stacks(item)+'，第'+CodexHeartsteel.stage(item)+'阶）');effectPools(s).x[7]+=CodexHeartsteel.isLeviathan(item)?0.05:0.03;}
        gearEffects(s,item);s.level=level;s=finish(s);gearCache.set(item,{signature:sig,value:s});return s;
    }
    // V2 evaluates readonly loadouts. No action is applied and no real battle is started.
    var formulaCache = new Map(), profiles = [{def:100,weight:0.3},{def:10000,weight:0.4},{def:1000000,weight:0.3}];
    var nanoStates = [1522,1708,1709,1763,1765,1768,1769,1770,1771,1772,1773,1774,1775,1776,1777,1778,1780,1781,1782,1783,1784,1785,1786,1789,1792,1793,1794,1795,1796,1797,1798,1799,1800,1801,1802,1803,1804,1805,1806,1807];
    var cannonPower = {5703:0.3,5704:0.6,5705:0.9,5706:0.3,5708:0.6,5709:0.9};
    function environment(obj) { return !!obj && /^(?:轮回模式|灭世挑战|天灾难度|强者增强.*洪荒|天道诅咒|强者压制)/.test(obj.name||''); }
    function clearDerived(a) {

        a._statescache2=undefined;a._basestatecache=undefined;a.need_refresh_states=true;a.need_refresh_basestates=true;a.need_refresh_passiveStates=true;
        a._cacheBaseParam={};a._baseParamCache=[];a._cacheParamBuffRate={};a._ParamCache2=[];a._xparamCache2=[];a._sparamCache2=[];
        a.need_refresh_param=[1,1,1,1,1,1,1,1];a.need_refresh_xparam=[1,1,1,1,1,1,1,1,1,1];a.need_refresh_sparam=[1,1,1,1,1,1,1,1,1,1];
        a._passiveStatesRaw=undefined;a._passiveSkillCache=undefined;a._skillsCache=undefined;a._statelist=undefined;
    }
    function isolatedActor(actor,naked) {
        var a=JsonEx.makeDeepCopy(actor);
        a._skills=(a._skills||[]).filter(function(id){return !environment($dataSkills[id]);});
        a._states=(a._states||[]).filter(function(id){var s=$dataStates[id];return s&&id!==1&&!environment(s)&&!s.removeAtBattleEnd&&!s.autoRemovalTiming&&nanoStates.indexOf(id)<0;});
        a._actions=[];a._buffs=[0,0,0,0,0,0,0,0];a._buffTurns=[0,0,0,0,0,0,0,0];var counters=a._stateCounter||{};a._stateCounter={};a._states.forEach(function(id){if(counters[id]!==undefined)a._stateCounter[id]=counters[id];});a._cooldownTurns={};a._warmupTurns={};
        a._garouEvolution=0;a._garouSaitama=false;a._codexRavenMythTurns=0;delete a._codexBlackFlashTemp;a._codexSukuna={adapt:0,prep:0};
        if(naked){a._equips=[];['_equipSuits','_equipSuitsTotal','_equipSuitsStateIDs','_equipSuitsStateResistIDs','_equipSuitsSkillIDs'].forEach(function(k){a[k]=[];});}
        clearDerived(a);a._hp=Number.MAX_SAFE_INTEGER;a._mp=Number.MAX_SAFE_INTEGER;a._tp=0;
        a.addState=function(id){if(this._powerEvaluatingHit||!$dataStates[id]||id===1||environment($dataStates[id])||this.isStateResist(id))return;if(this._states.indexOf(id)>=0)return;this._states.push(id);clearDerived(this);if(this.actorId()===108&&nanoStates.indexOf(id)>=0&&$dataStates[id].customEffectEval)this.customEffectEval(id,'addState');};
        a.removeState=function(id){this._states=this._states.filter(function(n){return n!==id;});clearDerived(this);};
        a.friendsUnit=function(){return $gameParty;};a.opponentsUnit=function(){return $gameTroop;};
        return a;
    }
    function neutralEnemy(defense) {
        var e=new Game_Enemy(1,0,0),data=Object.assign({},e.enemy(),{note:'',meta:{},traits:[],params:[1000000,10000,10000,defense,10000,defense,100,100]});
        e.enemy=function(){return data;};e.notetags=function(){return [];};e._states=[];e._stateCounter={};
        e._hp=data.params[0];e._mp=data.params[1];e.paramBase=function(id){return data.params[id];};e.param=function(id){return data.params[id]||0;};e.xparam=function(id){return id===0?1:0;};e.sparam=function(){return 1;};e._ParamCache2=[];
        e._codexNeutralAffinity=true;e.elementRate=function(){return 1;};e.addState=function(){};e._passiveCache={harmRe:{},penetrateHarmRe:{fixed:{},percent:{}},globalHarmRi:0,critHarmRi:0,states:{DBHPLSteal:1}};
        return e;
    }
    function context(a,target,fn) {
        var saved={},keys=['$gameActors','$gameParty','$gameTroop','$gameVariables','$gameSwitches','$gameTemp'],action=BattleManager._action,subject=BattleManager._subject;
        keys.forEach(function(k){saved[k]=root[k];});
        var dm=DataManager.isSkill,ds=Star.dsPassiveSkill.GetAction,race=Star.EnemyRace.GetAction,random=Math.random,clones={},sukunaRound=root.CodexSukuna&&CodexSukuna.round;clones[a.actorId()]=a;
        try {
            Math.random=function(){return 0.5;};
            root.$gameActors=Object.create(saved.$gameActors);$gameActors.actor=function(id){return clones[id]||(clones[id]=saved.$gameActors._data[id]?JsonEx.makeDeepCopy(saved.$gameActors._data[id]):null);};$gameActors._data=[];$gameActors._data[a.actorId()]=a;
            root.$gameParty=JsonEx.makeDeepCopy(saved.$gameParty);['members','allMembers','battleMembers','aliveMembers'].forEach(function(k){$gameParty[k]=function(){return [a];};});$gameParty.inBattle=function(){return true;};
            root.$gameTroop=JsonEx.makeDeepCopy(saved.$gameTroop);$gameTroop._enemies=[target];$gameTroop.members=function(){return [target];};$gameTroop._turnCount=0;
            root.$gameVariables=JsonEx.makeDeepCopy(saved.$gameVariables);$gameVariables._data[20]=0;
            root.$gameSwitches=JsonEx.makeDeepCopy(saved.$gameSwitches);root.$gameTemp=Object.create(saved.$gameTemp);$gameTemp._powerEvents=[];$gameTemp.reserveCommonEvent=function(id){this._powerEvents.push(id);};
            DataManager.isSkill=function(item){return !!(item&&item._codexPowerSkill)||dm.call(this,item);};
            return fn();
        } finally {keys.forEach(function(k){root[k]=saved[k];});if(root.CodexSukuna)CodexSukuna.round=sukunaRound;Math.random=random;DataManager.isSkill=dm;BattleManager._action=action;BattleManager._subject=subject;Star.dsPassiveSkill.GetAction=ds;Star.EnemyRace.GetAction=race;}
    }
    function drainNanoEvents() {
        var loops=0;
        while($gameTemp._powerEvents.length&&loops++<50){var id=$gameTemp._powerEvents.shift();if([2478,2479,2480,2481,2482].indexOf(id)<0)continue;var event=$dataCommonEvents[id];
            if(!event.list.every(function(c){return [0,111,411,412,117,122,333].indexOf(c.code)>=0;}))continue;
            var interpreter=new Game_Interpreter();interpreter.setup(event.list,0);var steps=0;while(interpreter.isRunning()&&steps++<500)interpreter.executeCommand();
        }
    }
    function refreshPassives(a) {clearDerived(a);a.initPassiveCache();a.refreshPassiveCache();}
    function freezeStats(a) {
        var methods=a._powerNativeMethods||{param:a.param,xparam:a.xparam,sparam:a.sparam};a._powerNativeMethods=methods;
        a.param=methods.param;a.xparam=methods.xparam;a.sparam=methods.sparam;
        var p=[],x=[],s=[];for(var i=0;i<8;i++)p[i]=num(a.param(i));for(i=0;i<10;i++){x[i]=num(a.xparam(i));s[i]=num(a.sparam(i));}
        a.param=function(i){return p[i]||0;};a.xparam=function(i){return i===2?num(methods.xparam.call(this,i)):x[i]||0;};a.sparam=function(i){return s[i]===undefined?1:s[i];};a._powerStatKey=JSON.stringify([p,x,s]);
    }
    function nativeStats(a,fn) {var m=a._powerNativeMethods;if(m){a.param=m.param;a.xparam=m.xparam;a.sparam=m.sparam;}fn();freezeStats(a);}
    function prepare(a) {
        var objects=a.equips().concat(a.skills()).filter(Boolean);
        if(a.actorId()===108)$gameVariables._data[1136]=a.isLearnedSkill(5702)?2:1;
        objects.forEach(function(obj){var re=/<StartPushState(\d+)\s*:\s*([\d.]+)%?\s*>/gi,m;while((m=re.exec(obj.note||'')))if(num(m[2])>=100)a.addState(num(m[1]));});
        if(a.actorId()===108){a.states().slice().forEach(function(s){if(nanoStates.indexOf(s.id)>=0&&s.customEffectEval)a.customEffectEval(s.id,'battle');});drainNanoEvents();}
        refreshPassives(a);a._hp=a.mhp;a._mp=a.mmp;a._tp=a.actorId()===172?Math.min(60,a.maxTp()):0;freezeStats(a);
    }
    function compileFormula(item) {
        var source=String(item.damage&&item.damage.formula||'0'),key=source+'|'+!!(item.damage&&item.damage.custom);
        if(formulaCache.has(key))return formulaCache.get(key);
        if(item.damage&&item.damage.custom){formulaCache.set(key,null);return null;}
        source=source.replace(/Math\.(floor|ceil)\(Math\.random\(\)\s*\*\s*(\d+)\)/g,function(_,kind,n){return '('+(num(n)+(kind==='floor'?-1:1))+'/2)';}).replace(/Math\.random\(\)/g,'0.5');
        var stripped=source.replace(/Codex(?:Raven\.(?:legionStrikeRate|skillCoefficient|defenseFactor|defenseDeduction)|Mira\.damage|Yomi\.damage|Jingliu\.damage|Toji\.damage|Sukuna\.damage|Garou\.base)\b/g,'1')
            .replace(/CodexYunshang\.formula\b/g,'1').replace(/CodexLiuying\.damage\(a,\s*b,\s*\d+\)/g,'1').replace(/Codex(?:Tusu|Xuan)\.(?:damage|heal)\(a,\s*b(?:,\s*'\w+')?\)/g,'1')
            .replace(/(?:a|b|user|target|subject)\.(?:skillMasteryLevel|isStateAffected|hpRate|mpRate|tpRate|param|xparam|sparam)\b/g,'1')
            .replace(/(?:a|b|user|target|subject)\.(?:mhp|mmp|hp|mp|tp|atk|def|mat|mdf|agi|luk|level|hit|cri|pdr|mdr|rec)\b/g,'1')
            .replace(/Math\.(?:floor|ceil|round|max|min|abs|pow|sqrt|log)\b/g,'1').replace(/item\.id/g,'1').replace(/v\[\d+\]/g,'1').replace(/\b(?:a|b|user|target|subject|this|true|false)\b/g,'1');
        var fn=null;if(/^[\d\s.eE+*/()%\-,?:<>=!&|]+$/.test(stripped)&&!/[;{}\[\]'"`]/.test(stripped)&&!/(?<![<>=!])=(?!=)/.test(stripped)){
            try{fn=Function('a','b','user','target','subject','item','v','return ('+source+');');}catch(e){}
        }
        formulaCache.set(key,fn);return fn;
    }
    function proxySkill(skill) {var item=Object.assign({},skill);item.damage=Object.assign({},skill.damage);item.meta=Object.assign({},skill.meta);item._codexPowerSkill=true;return item;}
    function actionFor(a,skill) {
        var item=proxySkill(skill),action=new Game_Action(a);action._codexPowerPreview=true;action.setSkill(skill.id);action.subject=function(){return a;};action.item=function(){return item;};
        action.evalDamageFormula=function(b){var fn=compileFormula(item);if(!fn)return 0;var value=num(fn.call(action,a,b,a,b,a,item,$gameVariables._data));return Math.max(0,value)*([3,4].indexOf(item.damage.type)>=0?-1:1);};
        action.applyVariance=function(value){return value;};action.applyDamageRate=function(value){return value;};
        return action;
    }
    function confirm(action,target,value) {
        if(root.CodexDamage&&CodexDamage.version>=3)return value;
        var a=action.subject();a.states().forEach(function(s){var code=s.customEffectEval&&s.customEffectEval.confirmState;
            if(!code)return;
            if([1522,1708,1770].indexOf(s.id)>=0)value=action.customEffectEval(target,s.id,'confirmState',a,value);
        });return value;
    }
    function repeatCount(a,item) {
        var cache=a._passiveCache||{},again=cache.againUse||{},by=again.byType||{},base=num(item.repeats)||1;
        // v0.57：李逍遥专武普攻形态的万剑归宗9926照原生规则吃攻击次数（与战斗一致）。
        if(item.id===a.attackSkillId())base+=num(a.attackTimesAdd());base+=num(cache.atkk);
        var chance=num(again.all)+num((again.bySkill||{})[item.id])+num(by[item.stypeId===1?'Zj':item.stypeId===2?'Mf':'']);
        var commands=(item.wholeActions||[]).concat(item.targetActions||[]),hits=commands.filter(function(s){return s[0]==='ACTION EFFECT';}).length;
        // Nanoha's six ACTION EFFECTs are gated by an actually learned passive.
        if(a.actorId()===108&&item.id===5710)hits=a.isLearnedSkill(5702)?6:1;
        // dsPassiveSkill 的再次使用为 numRepeats+1，YEP 动作序列会把每段 ACTION EFFECT 再结算一遍。
        var count=(Math.max(1,base)+clamp(chance/100,0,1))*Math.max(1,hits);
        if(a.actorId()===174&&a.level>=30&&a.isLearnedSkill(10277))count*=2;
        return count;
    }
    function skillCost(a,item) {
        var cost={mp:0,tp:0,hp:0};['mp','tp','hp'].forEach(function(k){var method='skill'+k.charAt(0).toUpperCase()+k.slice(1)+'Cost';try{cost[k]=Math.max(0,num(a[method]?a[method](item):item[k+'Cost']));}catch(e){cost[k]=Math.max(0,num(item[k+'Cost']));}});return cost;
    }
    function expected(a,target,skill,cost) {
        var action=actionFor(a,skill),item=action.item();action._codexRacePowerBlood=!!(cost&&cost.raceBlood);if(a.actorId()===174){action._yunPrimary=target;if(item.id===10274&&root.CodexYunshang){var wake=CodexYunshang.data(a);action._yunWakeTarget=a.actorId();action._yunGatherRounds=wake&&CodexYunshang.awake(a)?Math.max(1,wake.wakeUntil-CodexYunshang.round()+1):0;}}BattleManager._action=action;BattleManager._subject=a;
        var beforeMp=a._mp,beforeHp=a._hp,beforeTp=a._tp,paid=cost&&cost.mp||0,power=cannonPower[item.id];
        a._mp=Math.max(0,beforeMp-paid);a._hp=Math.max(1,beforeHp-(cost&&cost.hp||0));a._tp=Math.max(0,beforeTp-(cost&&cost.tp||0));
        var normal,critical,p,hit;
        a._powerEvaluatingHit=true;
        try {normal=confirm(action,target,num(action.makeDamageValue(target,false)));critical=item.damage.critical?confirm(action,target,num(action.makeDamageValue(target,true))):normal;p=clamp(action.itemCri(target),0,1);hit=clamp(action.itemHit(target),0,1)*(1-clamp(action.itemEva(target),0,1));}
        finally {a._mp=beforeMp;a._hp=beforeHp;a._tp=beforeTp;a._powerEvaluatingHit=false;}
        var value=Math.max(0,normal*(1-p)+critical*p)*hit*repeatCount(a,item);
        if(item.scope===2)value*=1.8; // 60% single-target / 40% three-target benchmark.
        else if(item.scope>=3&&item.scope<=6)value*=item.scope-2;
        if(power)value*=Math.max(1,Math.floor(beforeMp*power/2000));
        if(root.CodexImportedBalance&&[1,2,5,6].indexOf(item.damage.type)>=0)value*=CodexImportedBalance.outgoingRate(a);
        // Authored post-action echoes are separate from each hit's native damage pools.
        if(a.actorId()===167&&item.meta.CodexRavenDamage){if(a._codexRavenMythTurns>0&&a.isLearnedSkill(10136))value*=1.85;if(a.level>=35&&a._codexRavenStage>=3&&a.isLearnedSkill(10133)&&a._powerRound>=3)value*=2;}
        if(root.CodexRaces)value=CodexRaces.powerAdjust(action,target,value);
        return Math.max(0,num(value));
    }
    function skillsFor(a,coverage) {
        var list=a.skills().filter(function(s){return s&&s.occasion<2&&s.damage&&[1,2,5,6].indexOf(s.damage.type)>=0;}),attack=$dataSkills[a.attackSkillId()];
        if(attack&&list.indexOf(attack)<0)list.push(attack);
        if(a.actorId()===108&&a.isLearnedSkill(5692))Object.keys(cannonPower).forEach(function(id){list.push($dataSkills[num(id)]);});
        // 模型不施放强化/变身/切换类技能；装备、形态或状态条件当前不满足的伤害技能也不会出手。逐项披露。
        if(coverage.unmodeled)a.skills().forEach(function(s){if(!s||s.occasion>=2||s.stypeId===4||!s.damage)return;
            if(s.damage.type===0&&s.id!==a.guardSkillId())coverage.unmodeled.push({id:s.id,name:s.name,reason:s.scope>=7&&s.scope<=10?'队友辅助':'强化/变身/切换'});
            else if([1,2,5,6].indexOf(s.damage.type)>=0&&compileFormula(s)&&!meetsIgnoringCost(a,s))coverage.unmodeled.push({id:s.id,name:s.name,reason:'当前条件不可用'});});
        return list.filter(function(s,i,all){if(all.findIndex(function(x){return x&&x.id===s.id;})!==i)return false;if(!compileFormula(s)){coverage.unknown.push({id:s.id,name:s.name});return false;}coverage.known++;return true;});
    }
    // 原生使用条件含「付得起费用」；判断角色/形态条件时暂时补满资源，判断后恢复。
    function meetsIgnoringCost(a,s){var mp=a._mp,tp=a._tp;a._mp=a.mmp;a._tp=a.maxTp();try{return a.meetsSkillConditions(s);}finally{a._mp=mp;a._tp=tp;}}
    // 依赖变身、强化或切换的角色：每个钩子与该角色运行模块的实际触发一致（施放后写入同一状态或字段）。
    function formHooks(a) {
        var id=a.actorId(),list=[];
        if(id===167&&root.CodexRaven)list.push({skill:CodexRaven.SKILL.MYTH,active:function(x){return x._codexRavenMythTurns>0;},apply:function(x){x._codexRavenMythTurns=3;}});
        if(id===168&&root.CodexMira)list.push({skill:CodexMira.skills.liberate,active:function(x){return x.isStateAffected(CodexMira.dragon);},apply:function(x){x.addState(CodexMira.dragon);}});
        if(id===171){var shapes=[2630,2631,2632,2633];[10212,10213,10214,10215].forEach(function(skill,i){list.push({skill:skill,active:function(x){return x.isStateAffected(shapes[i]);},apply:function(x){shapes.forEach(function(s){x.removeState(s);});x.addState(shapes[i]);}});});}
        if(id===172)list.push({skill:10231,active:function(x){return x.isStateAffected(2636);},apply:function(x){var d=x._codexSukuna||(x._codexSukuna={});d.domain=4;d.prep=0;x.addState(2636);}});
        if(id===173)list.push({skill:10262,active:function(x){return !!x._garouSaitama;},apply:function(x){x._garouSaitama=true;}});
        return list.filter(function(h){return $dataSkills[h.skill]&&a.isLearnedSkill(h.skill);});
    }
    function cycle(a,target,skills,plan) {
        if(root.CodexRaces)CodexRaces.resetPowerCycle(a);
        var damage=0,first=0,schedule=[],cooldowns={},warmups={},candidates=skills,damageCache=new Map(),costCache=new Map(),hooks=formHooks(a),used={};
        function formKey(){return [(a._states||[]).join('.'),a._codexRavenMythTurns>0,!!a._garouSaitama,!!(a._codexSukuna&&a._codexSukuna.domain>0)].join(',');}
        function costFor(s){var key=[s.id,a.mp,a.hp,a.tp,a._powerStatKey].join('|');if(root.CodexRaces)key+='|'+JSON.stringify(a._codexRacePower);if(!costCache.has(key)){var cost=skillCost(a,s);if(root.CodexRaces)cost=CodexRaces.powerCost(a,s,cost);costCache.set(key,cost);}return costCache.get(key);}
        function damageFor(s,c){var f=s.damage.formula,key=[s.id,a._powerStatKey,formKey(),/\.(?:mp|mpRate)/.test(f)||cannonPower[s.id]?a.mp:0,/\.(?:hp|hpRate)/.test(f)?a.hp:0,/\.(?:tp|tpRate)/.test(f)?a.tp:0,a.actorId()===167&&a._powerRound>=3,a._garouEvolution||0,JSON.stringify(a._codexRacePower)].join('|');if(!damageCache.has(key))damageCache.set(key,expected(a,target,s,c));return damageCache.get(key);}
        function ready(s,cost){return !(cooldowns[s.id]>0||warmups[s.id]>0)&&cost.mp<=a.mp&&cost.tp<=a.tp&&cost.hp<a.hp&&a.canUse(s);}
        // Screen every available formula once, then retain eight useful attacks per profile; rescreen after a form change.
        function screen(){
            skills.forEach(function(s){if(warmups[s.id]===undefined)warmups[s.id]=Math.max(0,num(s.warmup));});
            candidates=skills.map(function(s){var c=costFor(s),v=damageFor(s,c);return {s:s,value:v};}).sort(function(x,y){return y.value-x.value;}).slice(0,8).map(function(r){return r.s;});
            var fallback=skills.find(function(s){return s.id===a.attackSkillId();});if(fallback&&candidates.indexOf(fallback)<0)candidates.push(fallback);
        }
        function changeForm(fn){nativeStats(a,function(){fn();clearDerived(a);});skills=skillsFor(a,{known:0,unknown:[]});screen();}
        screen();
        for(var turn=1;turn<=10;turn++) {
            a._powerRound=turn;$gameTroop._turnCount=turn;if(root.CodexRaces)CodexRaces.startPowerTurn(a,turn);if(root.CodexSukuna)CodexSukuna.round=turn;
            var actions=1;if(root.CodexRaces&&CodexRaces.data(a)&&CodexRaces.data(a).race===2)actions+=CodexRaces.rate(a)/2;(a.actionPlusSet?a.actionPlusSet():[]).forEach(function(v){actions+=clamp(v,0,1);});
            for(var actionIndex=0;actionIndex<Math.ceil(actions);actionIndex++){
                var weight=Math.min(1,actions-actionIndex);
                if(a.actorId()===108&&a.isLearnedSkill(5685))nativeStats(a,function(){a.customEffectEval(1780,'actionStartState');drainNanoEvents();clearDerived(a);});
                var best=null;
                // 本路线的变身/强化/切换在可用且未生效时优先施放（占用该次行动）。
                if(plan&&!plan.active(a)){var fs=$dataSkills[plan.skill],fc=costFor(fs);if(ready(fs,fc))best={skill:fs,cost:fc,value:[1,2,5,6].indexOf(fs.damage.type)>=0?damageFor(fs,fc):0};}
                if(!best)candidates.forEach(function(s){var cost=costFor(s);if(!ready(s,cost))return;used[s.id]=true;
                    var value=damageFor(s,cost);if(!best||value>best.value)best={skill:s,cost:cost,value:value};});
                if(best){
                    used[best.skill.id]=true;if(root.CodexRaces)CodexRaces.commitPowerRoot(a,best.skill,best.value);
                    damage+=best.value*weight;a._mp=Math.max(0,a.mp-best.cost.mp*weight);a._tp=Math.max(0,a.tp-best.cost.tp*weight);a._hp=Math.max(1,a.hp-best.cost.hp*weight);
                    var cd=best.skill.cooldown&&best.skill.cooldown[best.skill.id];cooldowns[best.skill.id]=Math.max(0,num(cd));schedule.push({turn:turn,id:best.skill.id,name:best.skill.name,damage:best.value*weight,action:actionIndex+1,weight:weight});
                    if(a.actorId()===167&&best.skill.id===10122)a._mp=Math.min(a.mmp,a.mp+Math.max(1,Math.floor(a.mmp*0.02))*weight);
                    if(a.actorId()===172&&best.skill.id===10238)a._tp=Math.min(a.maxTp(),a.tp+20*weight);if(a.actorId()===173&&best.skill.id===10250)a._tp=Math.min(a.maxTp(),a.tp+20*weight);
                    if(a.actorId()===173&&best.skill.id===10263)a._garouSaitama=false;if(a.actorId()===174&&best.skill.id===10274&&root.CodexYunshang){var wd=CodexYunshang.data(a);if(wd)wd.wakeUntil=0;}
                    var hook=hooks.find(function(h){return h.skill===best.skill.id;});if(hook&&!hook.active(a))changeForm(function(){hook.apply(a);});
                }
                if(a.actorId()===108&&a.isLearnedSkill(5685))nativeStats(a,function(){a.customEffectEval(1780,'actionEndState');drainNanoEvents();clearDerived(a);});
            }
            if(a.actorId()===167&&a._codexRavenMythTurns>0)a._codexRavenMythTurns--;
            if(a.actorId()===173)a._garouSaitama=false;
            // 宿傩领域：回合末对各敌人追加御厨子·斩击，持续 4 回合，结束后 3 回合内不能再展开。
            if(a.actorId()===172&&a._codexSukuna&&a._codexSukuna.domain>0&&a.isStateAffected(2636)){var slash=$dataSkills[10237];
                if(slash){var sv=damageFor(slash,{mp:0,tp:0,hp:0});damage+=sv;schedule.push({turn:turn,id:10237,name:slash.name,damage:sv,action:'回合末',weight:1});}
                if(--a._codexSukuna.domain<=0){a._codexSukuna.domain=0;a._codexSukuna.available=turn+3;changeForm(function(){a.removeState(2636);});}}
            a._mp=Math.min(a.mmp,a.mp+Math.max(0,a.mmp*num(a.mrg)));a._hp=Math.min(a.mhp,a.hp+Math.max(0,a.mhp*num(a.hrg)));a._tp=Math.min(a.maxTp(),a.tp+Math.max(0,a.maxTp()*num(a.trg))+5);
            Object.keys(cooldowns).forEach(function(k){cooldowns[k]=Math.max(0,cooldowns[k]-1);});Object.keys(warmups).forEach(function(k){warmups[k]=Math.max(0,warmups[k]-1);});
            if(turn===3)first=damage/3;
        }
        return {burst:first,sustained:damage/10,schedule:schedule,used:used,opening:plan?$dataSkills[plan.skill].name:''};
    }
    // 谷雨：技能公式均为0，治疗、绽放与一念花开都在其模块里按“生命储备”结算。这里按模块配置与其自动战斗策略复演10回合：
    // 泽苍生给全队按各自生命上限加储备（花期外再加生未央）；花期内谷雨与3名队友（以谷雨基础生命作参照）每次行动绽放25%储备；
    // 一念花开把储备×系数打向全体；春之阶（5阶）绽放与花开不消耗储备。伤害按实际伤害管线结算一次后缓存。
    function guyuSkill(k){var found=0;($dataSkills||[]).forEach(function(s){if(!found&&s&&s.meta&&s.meta.GuyuSkill===k)found=s.id;});return found;}
    function isGuyu(a){return !!(root.Guyu&&Guyu.isGuyu&&Guyu.isGuyu(a));}
    function guyuHeal(a){return Math.max(0,num(Guyu.baseMhp(a))*num(Guyu.healRatio(a)));}
    function guyuCycle(a,target){
        var C=Guyu.config,st=Guyu.stageOf(a),pick=function(list){return list[Math.max(0,Math.min(list.length-1,st))];},can=function(k){return Guyu.unlocked(a,k);};
        var ids={heal:guyuSkill('heal'),open:guyuSkill('open'),finish:guyuSkill('finish'),bloom:guyuSkill('bloom')},cap=Math.floor((CodexBinding.curve(a,[1,1.25,1.5,1.75],[1,20,40,60])+.15*st)*Math.max(1,num(Guyu.baseMhp(a)))),gain=guyuHeal(a);
        var free=Guyu.unlocked(a,'spring'),reserve=[0,0,0,0],flowerUntil=-1,openAt=0,damage=0,first=0,schedule=[],used={},cache={};
        function hit(id,power,scale){power=Math.floor(power);if(!id||power<1)return 0;var key=id+':'+power;
            if(cache[key]===undefined){var action=actionFor(a,$dataSkills[id]);action.evalDamageFormula=function(){return power;};BattleManager._action=action;BattleManager._subject=a;
                var v=num(action.makeDamageValue(target,false));if(root.CodexImportedBalance)v*=CodexImportedBalance.outgoingRate(a);cache[key]=Math.max(0,v);}
            return cache[key]*scale;}
        function bloom(i){var q=Math.floor(reserve[i]*C.bloom.ratio);if(q<1)return 0;if(!free)reserve[i]-=q;used[ids.bloom]=true;return hit(ids.bloom,q*CodexBinding.curve(a,[5,6,7,8],[1,20,40,60]),1);}
        for(var turn=1;turn<=10;turn++){
            var blooming=flowerUntil>=turn,act='heal',value=0;
            if(blooming&&can('finish')&&ids.finish&&reserve[0]>=1&&(reserve[0]>=cap*C.ai.finishAtReserve||flowerUntil===turn)){
                act='finish';value=hit(ids.finish,Guyu.finishPower(a,reserve[0]),1.8);if(!free)reserve[0]=0;flowerUntil=-1;openAt=turn+2;blooming=false;
            } else if(!blooming&&can('open')&&ids.open&&turn>=openAt&&reserve.some(function(e){return e>=cap*C.ai.openAtReserve;})){
                act='open';flowerUntil=turn+1;blooming=true;
            } else {
                var g=Math.floor(gain*(1+(!blooming&&can('growth')?C.growth.ratio:0)));reserve=reserve.map(function(e){return Math.min(cap,e+g);});if(blooming)value+=bloom(0);
            }
            if(blooming)for(var i=1;i<reserve.length;i++)value+=bloom(i);
            if(ids[act])used[ids[act]]=true;damage+=value;
            schedule.push({turn:turn,id:ids[act],name:ids[act]?$dataSkills[ids[act]].name:act,damage:value,action:1,weight:1});
            if(flowerUntil>=0&&flowerUntil<=turn){flowerUntil=-1;openAt=turn+2;}
            if(turn===3)first=damage/3;
        }
        return {burst:first,sustained:damage/10,schedule:schedule,used:used,opening:''};
    }
    function curve(value,reference,weight,exponent){return Math.round(weight*Math.pow(Math.max(0,num(value))/reference,exponent));}
    function* evaluationSteps(actor,naked) {
        var coverage={known:0,unknown:[],unmodeled:[]},results=[],ehp=0,aux=0,params=[],seen={},hookIds=[],routes=[],planIndex=0;
        function score(r){return r.burst*0.4+r.sustained*0.6;}
        function run(profile,index,p,first){var a=isolatedActor(actor,naked),target=neutralEnemy(profile.def),out=null;
            context(a,target,function(){prepare(a);if(a.actorId()===174&&root.CodexYunshang&&a.isLearnedSkill(10281)&&CodexYunshang.robe(a))try{CodexYunshang.wake(a);}catch(e){}var hooks=formHooks(a).filter(function(h){return !h.active(a)&&meetsIgnoringCost(a,$dataSkills[h.skill]);});
                if(first&&index===1)hookIds=hooks.map(function(h){return h.skill;});
                var skills=skillsFor(a,first&&index===0?coverage:{known:0,unknown:[]});out=cycle(a,target,skills,p?hooks[p-1]||null:null);if(isGuyu(a)){var gc=guyuCycle(a,target),merged=Object.assign({},out.used,gc.used);if(score(gc)>score(out))out=gc;out.used=merged;}out.weight=profile.weight;out.plans=1+hooks.length;
                if(index===1)Object.keys(out.used).forEach(function(id){seen[id]=true;});
                if(!first)return;if(index===0)for(var j=0;j<8;j++)params[j]=num(a.param(j));
                var avoidance=(clamp(a.eva,0,0.8)+clamp(a.mev,0,0.8))/2,rate=Math.max(0.02,(Math.max(0,num(a.pdr))+Math.max(0,num(a.mdr)))/2)*(1-avoidance);
                var defense=1/((CodexDamage.defenseRate(10000,a.def)+CodexDamage.defenseRate(10000,a.mdf))/2);
                ehp+=profile.weight*Math.max(0,a.mhp)*(1+Math.min(1,Math.max(0,num(a.hrg))*3))*defense/rate;
                if(index===0){var heal=0;a.skills().forEach(function(s){if(!s||!s.damage||[3,4].indexOf(s.damage.type)<0||!compileFormula(s))return;var c=skillCost(a,s);if(c.mp>a.mmp)return;try{var fn=compileFormula(s),amount=Math.max(0,num(fn.call(null,a,a,a,a,a,s,$gameVariables._data)));heal=Math.max(heal,amount*(s.scope===8?3:1)*Math.max(0,num(a.rec)));}catch(e){}});
                    if(root.CodexRaces&&CodexRaces.data(a)&&CodexRaces.data(a).race===0)heal*=1+CodexRaces.rate(a);aux=heal;if(isGuyu(a))aux=Math.max(aux,guyuHeal(a)*3);if(a.actorId()===108&&a.isLearnedSkill(5682))aux+=1000*a.level/100*(a.isLearnedSkill(5701)?2:1)*3;
                }
            });
            return out;}
        var best=run(profiles[1],1,0,true);yield;routes.push({opening:'',burst:best.burst,sustained:best.sustained,schedule:best.schedule.slice(0,12)});
        for(var p=1;p<best.plans;p++){var r=run(profiles[1],1,p,false);yield;routes.push({opening:r.opening,burst:r.burst,sustained:r.sustained,schedule:r.schedule.slice(0,12)});if(score(r)>score(best)){best=r;planIndex=p;}}
        best.weight=profiles[1].weight;
        results[1]=best;
        for(var index of [0,2]){var first=run(profiles[index],index,0,true);yield;results[index]=planIndex?run(profiles[index],index,planIndex,false):first;if(planIndex)yield;}
        // 已在某条路线中实际可用或施放过的技能不再列为未计入；登记了路线却始终攒不够资源的，单独说明。
        coverage.unmodeled=coverage.unmodeled.filter(function(r){return !seen[r.id];});
        hookIds.forEach(function(id){if(!seen[id]&&!coverage.unmodeled.some(function(r){return r.id===id;}))coverage.unmodeled.push({id:id,name:$dataSkills[id].name,reason:'10回合内资源不足'});});
        if(root.CodexRaces&&CodexRaces.data(actor)&&CodexRaces.data(actor).race===6)coverage.unmodeled.push({id:0,name:'蛮骨与反攻',reason:'需敌方实际攻击，固定参照场景未计入'});
        if(root.CodexCat && CodexCat.is(actor))coverage.unmodeled.push({id:CodexCat.ids.skill.heart,name:"至圣喵心与连携",reason:"剑心、追击、巨龙试炼不计入战力参考"});
        var burst=results.reduce(function(v,r){return v+r.burst*r.weight;},0),sustained=results.reduce(function(v,r){return v+r.sustained*r.weight;},0);
        var parts=[curve(burst*0.4+sustained*0.6,1000,600,0.35),curve(ehp,1000,300,0.5),curve(aux,1000,100,0.5)];
        return {total:parts.reduce(function(x,y){return x+y;},0),parts:parts,burst:burst,sustained:sustained,effectiveHp:ehp,auxiliary:aux,params:params,coverage:coverage,schedule:results[1].schedule,opening:results[1].opening,routes:routes};
    }
    function evaluationStep(iterator) {var random=Math.random;Math.random=function(){return 0.5;};try{return iterator.next();}finally{Math.random=random;}}
    function evaluate(actor,naked) {if(!enabled())return null;var iterator=evaluationSteps(actor,naked),step;do{step=evaluationStep(iterator);}while(!step.done);return step.value;}
    function ownSignature(a) {return JSON.stringify([root.CodexDamage&&CodexDamage.version,a._actorId,a._classId,a._level,a._AdvancedNum,a._paramPlus,a._skills,a._codexRace,a._skillMasteryLevels,a._codexRavenSoul,a._codexRavenStage,a._garouForm,(a._states||[]).filter(function(id){var s=$dataStates[id];return s&&!s.removeAtBattleEnd&&!s.autoRemovalTiming&&nanoStates.indexOf(id)<0;}).map(function(id){return [id,(a._stateCounter||{})[id]];}),root.$gameVariables&&$gameVariables.value(8)]);}
    function signature(a) {return JSON.stringify([ownSignature(a),a._equips.map(function(e){var i=e.object();return i?[i.id,i.params,i.traits,i.note,i.level]:null;}),a._equipSuitsStateIDs]);}
    function actorPower(actor,force) {
        if(!enabled()||!actor)return {self:0,gear:0,total:0,parts:[0,0,0],selfParts:[0,0,0],gearParts:[0,0,0],equipment:[],rows:[]};
        var prior=actorCache.get(actor);if(!force&&prior&&Date.now()-prior.checked<250)return prior.value;
        var sig=signature(actor);if(!force&&prior&&sig===prior.signature){prior.checked=Date.now();return prior.value;}
        var start=Date.now(),ownKey=ownSignature(actor),own=prior&&prior.ownKey===ownKey?prior.value.ownEvaluation:evaluate(actor,true),full=evaluate(actor,false);
        return cacheActorPower(actor,sig,ownKey,own,full,start);
    }
    function cacheActorPower(actor,sig,ownKey,own,full,start) {
        var worn=actor.equips().map(function(item,slot){return {item:item,slot:slot,score:equipment(item)};}).filter(function(r){return isGear(r.item);});
        var result={self:own.total,gear:full.total-own.total,gearScore:actor.equips().reduce(function(s,e){return s+(isGear(e)?num(equipment(e).total):0);},0),total:full.total,parts:full.parts,selfParts:own.parts,gearParts:full.parts.map(function(v,i){return v-own.parts[i];}),equipment:worn,rows:[],params:full.params,model:'v3.2-race-cycle',evaluation:full,ownEvaluation:own,elapsedMs:Date.now()-start};
        actorCache.set(actor,{signature:sig,ownKey:ownKey,checked:Date.now(),value:result});return result;
    }
    function preview(actor,slot,item) {if(!enabled()||!actor||slot<0)return null;var before=actorPower(actor),copy=JsonEx.makeDeepCopy(actor);if(!copy._equips[slot])return null;copy._equips[slot].setObject(item);clearDerived(copy);var after=actorPower(copy,true);return {before:before.total,after:after.total,delta:after.total-before.total};}
    // 怪物战力（HOLD-003）：与角色同一刻度，可直接比较。行动表按原生规则取评分不低于最高分−2的行动并按评分加权；
    // 每回合行动数计入额外行动概率；不改变敌人、不施加状态、不消耗随机数。
    var enemyCache=new WeakMap();
    // 【Codex·未经Claude检验】 自动绘制只读敌人战力缓存，详情展开才运行伤害预演。
    function enemySignature(enemy) {
        if(!enemy||!enemy.enemy||!enemy.enemy()||!enemy.isEnemy||!enemy.isEnemy())return null;
        return JSON.stringify([enemy.enemyId(),[0,1,2,3,4,5,6,7].map(function(i){return Math.round(num(enemy.param(i)));}),(enemy._states||[]).slice().sort()]);
    }
    function cachedEnemyPower(enemy) {
        if(!enabled())return null;
        var cached=enemy&&enemyCache.get(enemy);
        return cached&&cached.key===enemySignature(enemy)?cached.value:null;
    }
    function enemyPower(enemy) {
        if(!enabled())return null;
        var key=enemySignature(enemy);if(key===null)return null;
        var cached=enemyCache.get(enemy);if(cached&&cached.key===key)return cached.value;
        var random=Math.random;Math.random=function(){return 0.5;};
        try {
            var acts=(enemy.enemy().actions||[]).filter(function(a){var s=$dataSkills[a.skillId];return s&&s.damage&&[1,2,5,6].indexOf(s.damage.type)>=0;});
            var top=acts.reduce(function(m,a){return Math.max(m,num(a.rating));},0),pool=acts.filter(function(a){return num(a.rating)>=top-2;});
            var weights=pool.map(function(a){return num(a.rating)-(top-3);}),actions=1;
            (enemy.actionPlusSet?enemy.actionPlusSet():[]).forEach(function(v){actions+=clamp(v,0,1);});
            var seed=new Game_Action(enemy);seed.setSkill(pool.length?pool[0].skillId:1);
            var output=CodexDamage.previewBatch(seed,neutralEnemy(100),function(seedAction,seedTarget,source){
                source._powerNativeMethods={param:source.param};
                var output=0;
                profiles.forEach(function(profile){var target=neutralEnemy(profile.def),sum=0,wsum=0;
                    pool.forEach(function(a,i){var s=$dataSkills[a.skillId],x=new Game_Action(source),v=0;x.subject=function(){return source;};x.setSkill(s.id);x._codexPowerPreview=true;
                        try{var n=num(x.makeDamageValue(target,false)),c=s.damage.critical?num(x.makeDamageValue(target,true)):n,p=clamp(x.itemCri(target),0,1),h=clamp(x.itemHit(target),0,1);
                            v=Math.max(0,n*(1-p)+c*p)*h*Math.max(1,num(s.repeats)||1);if(s.scope===2)v*=1.8;else if(s.scope>=3&&s.scope<=6)v*=s.scope-2;}catch(e){v=0;}
                        sum+=v*weights[i];wsum+=weights[i];});
                    output+=profile.weight*(wsum?sum/wsum:0)*actions;});
                return output;
            });
            var avoidance=(clamp(enemy.eva,0,0.8)+clamp(enemy.mev,0,0.8))/2,rate=Math.max(0.02,(Math.max(0,num(enemy.pdr))+Math.max(0,num(enemy.mdr)))/2)*(1-avoidance);
            var defense=1/((CodexDamage.defenseRate(10000,enemy.def)+CodexDamage.defenseRate(10000,enemy.mdf))/2),ehp=Math.max(0,num(enemy.mhp))*defense/rate;
            var parts=[curve(output,1000,600,0.35),curve(ehp,1000,300,0.5),0],value={total:parts[0]+parts[1],parts:parts,output:output,effectiveHp:ehp};
            enemyCache.set(enemy,{key:key,value:value});return value;
        } catch(e) { return null; } finally { Math.random=random; }
    }
    root.CodexCombatPower={version:2,enabled:enabled,setEnabled:setEnabled,clearCache:clearPowerCache,enemy:enemyPower,cachedEnemy:cachedEnemyPower,equipment:equipment,actor:actorPower,preview:preview,format:format,delta:delta,labels:labels,reference:reference,weights:weights,formula:compileFormula,evaluate:evaluate,description:'固定装备评分；角色按整套配置评估3回合爆发、10回合持续、生存与辅助。成长按当前实际数值计入；渡鸦、米拉、甚尔、宿傩、饿狼的变身/强化/切换按开场路线比较后计入，谷雨的生命储备（泽苍生、绽放、一念花开）按其模块规则复演计入；云裳学会天衣无缝时按开场唤醒计入收针；其余强化与队友辅助不计入。'};
    var refresh=Game_Actor.prototype.refresh;
    Game_Actor.prototype.refresh=function(){var out=refresh.apply(this,arguments);var cached=actorCache.get(this);if(cached)cached.checked=0;return out;};
    // 【Codex·未经Claude检验】 主菜单只读有效缓存；完整评估由状态、技能、装备界面按需触发。
    function cachedActorPower(actor) {
        if(!enabled())return null;
        var prior=actor&&actorCache.get(actor);
        return prior&&signature(actor)===prior.signature?prior.value:null;
    }
    function menuPower(window,actor) { return cachedActorPower(actor); }
    root.CodexCombatPower.cachedActor=cachedActorPower;
    // Menu rows and compact skill/equipment headers share the same derived score.
    var identityOverrides={
        30:['李栖梧','西凉女帝'],104:['傲笑红尘','天虎令'],
        122:['南宫恨','狂刀'],123:['南宫恨','武道'],
        143:['小樱','初代萌王'],144:['艾斯特','赛维里昂圣剑'],
        145:['夜夜','人形自动人偶'],155:['栗子','病娇']
    };
    function characterIdentity(actor){
        var data=actor.actor()||{},name=String(actor.name()||data.name||'').trim(),code=String(actor.nickname()||'').trim(),pair=identityOverrides[actor.actorId()];
        if(pair){if(name===String(data.name||'').trim()||name===pair[0])name=pair[0];if(!code||code===String(data.nickname||'').trim())code=pair[1];}
        if(!code||code===name){var className=String(actor.currentClass().name||'').trim();code=className&&className!==name&&className!==String(data.name||'').trim()?className:'';}
        if(code===name)code='';
        return {name:name,code:code};
    }
    root.CodexCombatPower.identity=characterIdentity;
    var compactStatus=Window_Base.prototype.drawActorSimpleStatus;
    Window_Base.prototype.drawActorSimpleStatus=function(actor,x,y,width){
        var menuRow=this instanceof Window_MenuStatus&&!(this instanceof Window_MenuActor);
        if(!actor||(!menuRow&&!(this instanceof Window_SkillStatus))||(!menuRow&&width<360))return compactStatus.apply(this,arguments);
        if(menuRow){
            var index=$gameParty.members().indexOf(actor),rect=this.itemRect(index);
            y=Math.min(y,rect.y+Math.max(0,Math.floor((rect.height-this.lineHeight()*4)/2)));
        }
        var line=this.lineHeight(),gap=Window_Base._faceWidth+2*Yanfly.Param.TextPadding,x2=x+gap;
        var leftWidth=gap-12,rightWidth=Math.max(0,Math.min(width-gap-this.textPadding(),this.contentsWidth()-x2));
        var identity=characterIdentity(actor),font=this.contents.fontSize,power=enabled()?(menuRow?menuPower(this,actor):actorPower(actor)):null;
        this.changeTextColor(this.hpColor(actor));this.drawText(identity.name,x,y,leftWidth);
        this.resetTextColor();this.drawText(identity.code,x2,y,rightWidth);
        this.drawActorLevel(actor,x,y+line);
        this.drawActorIcons(actor,x,y+line*2,leftWidth);
        this.contents.fontSize=Math.min(font,21);this.changeTextColor('rgb(255,211,115)');
        if(enabled())this.drawText(menuRow&&!power?'战力见状态':(menuRow?'战斗力 ':'战力 ')+(power?format(power.total):'…'),x,y+line*3,leftWidth);
        this.contents.fontSize=font;this.resetTextColor();
        this.drawActorHp(actor,x2,y+line,rightWidth);this.drawActorMp(actor,x2,y+line*2,rightWidth);
        if(Yanfly.Param.MenuTpGauge)this.drawActorTp(actor,x2,y+line*3,rightWidth);
        this._codexCompactIdentity={actorId:actor.actorId(),name:identity.name,code:identity.code,total:power?power.total:null,
            nameRect:{x:x,y:y,width:leftWidth},codeRect:{x:x2,y:y,width:rightWidth},powerRect:{x:x,y:y+line*3,width:leftWidth}};
        if(menuRow){
            this._codexMenuPowerRows=this._codexMenuPowerRows||{};
            this._codexMenuPowerRows[actor.actorId()]=this._codexCompactIdentity;
        }
    };

    // Keep the score in its own native strip, outside the scrolling status contents.
    if(typeof JAH_Window_Status_Base!=='undefined') {
        var createStatus=Scene_Status.prototype.create,updateStatus=Scene_Status.prototype.update;
        Scene_Status.prototype.create=function(){
            createStatus.apply(this,arguments);
            if(!enabled())return;
            var pageY=this._pageWindows[0].y,bitmap=new Bitmap(Graphics.boxWidth-48,36);
            this._pageWindows.forEach(function(page){page.move(page.x,page.y+36,page.width,page.height-36);page.createContents();page.refresh();});
            this._codexPowerSprite=new Sprite(bitmap);this._codexPowerSprite.x=24;this._codexPowerSprite.y=pageY;this.addChild(this._codexPowerSprite);this.refreshCombatPowerSummary();
        };
        Scene_Status.prototype.refreshCombatPowerSummary=function(){
            if(!this._codexPowerSprite||!this.actor())return;
            this._codexPowerSprite.visible=enabled();if(!enabled()){this._codexPowerSignature=null;return;}
            var actor=this.actor(),p=actorPower(actor),signature=[actor.actorId(),p.total,p.self,p.gear].join('|');
            if(this._codexPowerSignature===signature)return;this._codexPowerSignature=signature;
            var bitmap=this._codexPowerSprite.bitmap;bitmap.clear();bitmap.fillRect(0,0,bitmap.width,36,'rgba(12,25,35,0.45)');
            bitmap.fontSize=23;bitmap.textColor='rgb(255,211,115)';bitmap.drawText('战力：'+format(p.total),12,0,300,36,'left');
            bitmap.fontSize=18;bitmap.textColor='rgb(180,201,220)';CodexElements.drawAttributes(bitmap,actor,325,0,220,36,'人物属性');bitmap.drawText('自身 '+format(p.self)+'  ·  装备战力 '+format(p.gearScore||0),550,0,bitmap.width-565,36,'left');
            this._codexPowerNativeInfo={actorId:actor.actorId(),total:p.total,self:p.self,gear:p.gear};
        };
        Scene_Status.prototype.update=function(){updateStatus.apply(this,arguments);this.refreshCombatPowerSummary();};
    }
    // A tooltip has exactly one item score, independent of the selected actor.
    if(typeof Sprite_ItemHelp!=='undefined') {
        var setItem=Sprite_ItemHelp.prototype.setItem;
        Sprite_ItemHelp.prototype.setItem=function(item) {
            if(enabled()&&isGear(item)) {
                var proxy=Object.assign({},item),type=DataManager.isWeapon(item)?1:2;
                if(!proxy.descParams&&root.RJO&&RJO.HE)RJO.HE.getDescParams(proxy,type);
                proxy.descParams=(proxy.descParams||[]).slice();
                proxy.descParams.splice(1,0,['装备战力：'+format(equipment(item).total),18,'rgba(255,211,115,1)',false,0]);
                return setItem.call(this,proxy);
            }
            return setItem.apply(this,arguments);
        };
    }
    var toast,timer;
    function notify(actor,before,after) {
        if(!enabled())return;
        var change=after-before;root.CodexCombatPower.lastChange={actorId:actor.actorId(),before:before,after:after,delta:change};
        if(!toast){toast=document.createElement('div');toast.id='codex-power-notice';toast.style.cssText='position:fixed;right:24px;bottom:36px;z-index:2147483000;background:rgba(15,29,43,.97);border:1px solid #c5a463;border-radius:10px;padding:14px 22px;color:#f5d992;font:20px sans-serif;pointer-events:none;box-shadow:0 4px 24px #0008;white-space:pre-line';document.body.appendChild(toast);}
        toast.textContent=actor.name()+' · '+(change>0?'战力提升 ':change<0?'战力下降 ':'战力变化 ')+delta(change)+'\n当前总战力：'+format(after);toast.style.display='block';clearTimeout(timer);timer=setTimeout(function(){toast.style.display='none';},3500);
    }
    function wornKey(a){return JSON.stringify(a._equips.map(function(e){return [e._dataClass,e._itemId];}));}
    ['onItemOk','commandOptimize','commandClear'].forEach(function(name){var original=Scene_Equip.prototype[name];if(!original)return;Scene_Equip.prototype[name]=function(){if(!enabled())return original.apply(this,arguments);var a=this.actor(),key=wornKey(a),before=actorPower(a).total,out=original.apply(this,arguments);if(key!==wornKey(a))notify(a,before,actorPower(a,true).total);return out;};});
    return {version:2};
});
