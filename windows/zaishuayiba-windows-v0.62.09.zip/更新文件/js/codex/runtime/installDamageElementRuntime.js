// 2026-10-11 只在装备效果文字中统一旧元素别名。
/* v3: attacker settlement effects precede per-hit flat mitigation.
   Native Confirm scripts execute once at their original pre-damage entry; previews use isolated copies.
   Damage/element v1: one settlement pipeline, native mechanics contribute to named pools.
   v2（2026-10-10，用户确认元素审查）：暴击在扣固定减伤之前（恢复原作者顺序）；真气、天道补偿、五乘区修正经 growthMultiplier 在扣减伤前乘；
   吸收部分不吃暴击、独立结算、成长倍率，也不被结算状态放大；多属性取最有利的一个；虚空～风的增伤不低于火～暗中最低的一项。 */
window.CodexDamageHooks=window.CodexDamageHooks||[];
window.CodexRuntime.register('installDamageElementRuntime',function(){
 'use strict';
 var root=window,previewDepth=0,stack=[],functions=new Map(),version=3,active=[2,3,4,5,6,7,8,9,11,12,13,14,15];
 root.$dataCodexDamage=null;
 DataManager._databaseFiles.push({name:'$dataCodexDamage',src:'CodexDamageElements.json'});
 function number(v,otherwise){v=Number(v);return Number.isFinite(v)?v:(otherwise||0);}
 function clamp(v,lo,hi){return Math.max(lo,Math.min(hi,number(v)));}
 function actor(b){return !!(b&&b.isActor&&b.isActor());}
 function unique(a){return Array.from(new Set(a.filter(Boolean)));}
 function objects(b){return unique((b.traitObjects?b.traitObjects():[]).concat(b.skills&&(actor(b)||b.enemy&&Array.isArray(b.enemy().actions))?b.skills():[]));}
 function data(){return root.$dataCodexDamage||{names:[],affinities:{actors:{},enemies:{}},edges:[],skills:{}};}
 function name(id){return data().names[id]||'无属性';}
 var colors=['#c1c9d5','#d5dce6','#ff846b','#9be4ff','#d8ac74','#f7db62','#83d784','#a99bff','#fff0b0','#bd8bc9','#6fe4c0','#b59cf0','#f497c8','#7eb8ff','#65ccef','#bce986'];
 function color(id){return colors[id]||colors[0];}
 function richText(ids){return ids.length?ids.map(function(e){return '\\C['+(2000+e)+']'+name(e)+'\\C[0]';}).join('／'):'无属性';}
 function colorText(text){
  if(root.CodexDisplay&&CodexDisplay.text)text=CodexDisplay.text(text);
  if(typeof text!=='string'||/\\c\[20\d\d\]/i.test(text))return text;
  var ids=[1].concat(active),labels=ids.map(name).sort(function(a,b){return b.length-a.length;}),lookup={};ids.forEach(function(e){lookup[name(e)]=e;});lookup['雷']=5;
  function tint(s){return s.replace(new RegExp(labels.concat(['雷']).join('|'),'g'),function(n){return richText([lookup[n]]);});}
  return text.replace(/((?:伤害属性|触发攻击属性|攻击属性|人物属性|敌人属性|元素)[：:]\s*)([\u4e00-\u9fff／/、·]+)/g,function(_,label,values){return label+tint(values);}).replace(new RegExp('('+labels.concat(['雷']).join('|')+')(?=(?:增伤|伤害|抗性|穿透|承伤))','g'),function(n){return tint(n);});
 }
 function drawAttributes(bitmap,b,x,y,width,height,label){
  var priorColor=bitmap.textColor,priorSize=bitmap.fontSize,ids=affinity(b),parts=[{text:(label||'人物属性')+'：',color:priorColor}];
  if(!ids.length)parts.push({text:'无属性',color:color(0)});
  ids.forEach(function(e,i){if(i)parts.push({text:'／',color:priorColor});parts.push({text:name(e),color:color(e)});});
  try{var total=parts.reduce(function(sum,p){return sum+bitmap.measureTextWidth(p.text);},0);if(total>width)bitmap.fontSize=priorSize*width/total;
   parts.forEach(function(p){var w=bitmap.measureTextWidth(p.text);bitmap.textColor=p.color;bitmap.drawText(p.text,x,y,w+1,height,'left');x+=w;});
  }finally{bitmap.textColor=priorColor;bitmap.fontSize=priorSize;}
 }
 function createAttributes(b,label){var line=document.createElement('div');line.className='cq-note';line.appendChild(document.createTextNode((label||'人物属性')+'：'));var ids=affinity(b);if(!ids.length)line.appendChild(document.createTextNode('无属性'));ids.forEach(function(e,i){if(i)line.appendChild(document.createTextNode('／'));var s=document.createElement('span');s.textContent=name(e);s.style.color=color(e);line.appendChild(s);});return line;}
 function createResistance(b){var line=document.createElement('div');line.className='cq-note';line.style.display='flex';line.style.flexWrap='wrap';line.style.gap='6px 12px';active.forEach(function(e){var s=document.createElement('span');s.textContent=name(e)+'承伤 '+Math.round(b.elementRate(e)*100)+'%';s.style.color=color(e);line.appendChild(s);});return line;}
 // Both native window text and the game's item-help renderer share this palette.
 var nativeTextColor=Window_Base.prototype.textColor;Window_Base.prototype.textColor=function(id){return id>=2000&&id<=2015?color(id-2000):nativeTextColor.call(this,id);};
 if(root.RJO&&RJO.SW){var helpTextColor=RJO.SW.textColor;RJO.SW.textColor=function(id){return id>=2000&&id<=2015?color(id-2000):helpTextColor.call(this,id);};var drawHelpText=RJO.SW.drawContentText;RJO.SW.drawContentText=function(text){var args=Array.from(arguments);args[0]=colorText(text);return drawHelpText.apply(this,args);};}
 function affinity(b){
  if(!b||b._codexNeutralAffinity)return [];
  var ids=actor(b)?data().affinities.actors[b.actorId()]:data().affinities.enemies[b.enemyId&&b.enemyId()];
  return unique(b._codexBodyElements||ids||[]).filter(function(e){return active.includes(e);}).slice(0,2);
 }
 function matchup(element,body){
  if(!active.includes(element)||!body||!body.length)return 1;
  var edges=data().edges,product=1;
  body.forEach(function(e){var forward=edges.some(function(pair){return pair[0]===element&&pair[1]===e;}),backward=edges.some(function(pair){return pair[0]===e&&pair[1]===element;});product*=forward?1.5:backward?0.75:1;});
  return Math.pow(product,1/body.length);
 }
 function actionElements(action){
  var item=action.item(),a=action.subject(),cache=a._passiveCache||{},terminal=action._sukunaCast&&action._sukunaCast.terminal;
  if(actor(a)&&a.actorId()===172&&(terminal||[10234,10235].includes(item.id)))return [13];
  if(root.$gameTemp&&$gameTemp._forcedElements!==undefined)return unique($gameTemp._forcedElements).filter(function(e){return e>=1&&e<=15;});
  if(a.isNullElement&&a.isNullElement())return [];
  var id=number(cache.damageElement)||item.damage.elementId,es=id<0?(a.attackElements?a.attackElements():[1]):id>0?[id]:[];
  es=es.concat(item.multipleElements||[],$gameTemp._addedElements||[]);return unique(es).filter(function(e){return e>=1&&e<=15;});
 }
 // 属性转换只改目标承伤；攻击方增伤、固定附加与自乘仍按技能原属性。
 function conversionId(action){
  var item=action.item(),a=action.subject(),cache=a._passiveCache||{},terminal=action._sukunaCast&&action._sukunaCast.terminal;
  if(actor(a)&&a.actorId()===172&&(terminal||[10234,10235].includes(item.id)))return 0;
  if(root.$gameTemp&&$gameTemp._forcedElements!==undefined)return 0;
  if(a.isNullElement&&a.isNullElement())return 0;
  var id=number(cache.damageElement);return id>=1&&id<=15?id:0;
 }
 // 原属性取技能自身的 damage.elementId；-1 取普攻属性；附加属性仍参与。
 function originalElements(action){
  var item=action.item(),a=action.subject(),terminal=action._sukunaCast&&action._sukunaCast.terminal;
  if(actor(a)&&a.actorId()===172&&(terminal||[10234,10235].includes(item.id)))return [13];
  if(root.$gameTemp&&$gameTemp._forcedElements!==undefined)return unique($gameTemp._forcedElements).filter(function(e){return e>=1&&e<=15;});
  if(a.isNullElement&&a.isNullElement())return [];
  var id=item.damage.elementId,es=id<0?(a.attackElements?a.attackElements():[1]):id>0?[id]:[];
  es=es.concat(item.multipleElements||[],$gameTemp._addedElements||[]);return unique(es).filter(function(e){return e>=1&&e<=15;});
 }
 // Ordinary resistance/incoming reductions share an additive pool. Native
 // forced rates, absorption, and explicit character corrections remain intact.
 function additiveRate(b,code,id,current,passive){
  // 2026-10-09 修正：敌人身上多项减抗相加会掉到 0 以下变成免疫（例：守层者 ×0.05 再叠神魔战纹 ×0.85 → 0；原生加算也会先截成 0）。
  // 敌人：只有数据里明确写 0 才算免疫，否则不低于 min(0.01, 各项相乘)；我方不变。
  var isEnemy=b.isEnemy&&b.isEnemy();if(current===0&&!isEnemy)return 0;
  var values=(b.traitsWithId?b.traitsWithId(code,id):[]).map(function(t){return number(t.value,1);}),ordinary=b.traitsPi?number(b.traitsPi(code,id),1):values.reduce(function(s,v){return s*v;},1),passiveProduct=1;
  if(passive&&actor(b)&&b.iteratePassiveSkill)b.iteratePassiveSkill('passiveELEM'+('00'+id).slice(-2),function(v){var p=number(parseFloat(v))/100;values.push(p);passiveProduct*=p;});
  if(!values.length)return current;
  if(values.some(function(v){return v===0;}))return 0;
  if(current===0){var pure=values.reduce(function(s,v){return s*v;},1),r0=values.reduce(function(s,v){return s+v-1;},1);return Math.max(Math.min(0.01,pure),r0);}
  var product=ordinary*passiveProduct,sum=values.reduce(function(s,v){return s+v-1;},1);
  if(current<0){if(b.isAbsorbElement&&b.isAbsorbElement(id)&&product>0)return Math.min(sum-2+(current-(product-2)),-.01);return current;}
  var r=sum+current-product;if(isEnemy){var low=Math.min(0.01,product);if(r<low)return low;}
  return Math.max(0,r);
 }
 [Game_Actor,Game_Enemy].forEach(function(Type){
  var oldElement=Type.prototype.elementRate,oldIncoming=Type.prototype.sparam;
  Type.prototype.elementRate=function(e){var forced=this.forcedElementRate?this.forcedElementRate(e):undefined,current=oldElement.call(this,e);if(forced!==undefined)return current;return additiveRate(this,11,e,current,true);};
  Type.prototype.sparam=function(i){var value=oldIncoming.call(this,i);return i===6||i===7?additiveRate(this,23,i,value,false):value;};
 });
 root.CodexElements={version:version,activeIds:active.slice(),name:name,color:color,richText:richText,colorText:colorText,drawAttributes:drawAttributes,createAttributes:createAttributes,createResistance:createResistance,affinity:affinity,matchup:matchup,actionElements:actionElements,resistance:function(b,e){return number(b.elementRate(e),1);},describe:function(b){var es=affinity(b);return es.length?es.map(name).join('／'):'无属性';}};
 function formula(item){var source=item.damage.formula||'0',key=source+'|'+!!item.damage.custom;if(functions.has(key))return functions.get(key);
  var fn,args=['a','b','user','target','subject','item','v','s'];try{fn=Function.apply(null,args.concat(item.damage.custom?'var value=0;'+source+';return value;':'return ('+source+');'));}catch(e){try{fn=Function.apply(null,args.concat('return eval('+JSON.stringify(source)+');'));}catch(other){throw new Error('技能 '+item.id+' 公式无法编译: '+other.message);}}functions.set(key,fn);return fn;
 }
 function defaultFrame(action,target,options){var a=action.subject(),item=action.item(),spec=data().skills[item.id]||{},cache=a._passiveCache||{},pass=cache.skillPass&&cache.skillPass[item.id]||{},normal=0;
  var finalAdd=number(cache.globalHarmRi),criticalAdd=number(cache.critHarmRi);
  if(!actor(a))objects(a).forEach(function(o){var re=/<(passiveHarmRi|passiveCrHarmRi)\s*:\s*([+-]?[\d.]+)%?\s*>/gi,m;while((m=re.exec(o.note||'')))if(m[1].toLowerCase()==='passiveharmri')finalAdd+=number(m[2])/100;else criticalAdd+=number(m[2])/100;});
  Object.keys(cache.SkETypeHarmRi||{}).forEach(function(id){if(a.isWtypeEquipped&&a.isWtypeEquipped(Number(id)))normal+=number(cache.SkETypeHarmRi[id]);});
  if(item.meta&&item.meta.SkillTypes){try{JSON.parse(item.meta.SkillTypes).forEach(function(t){normal+=number((cache.skillTypeDvup||{})[t]);});}catch(e){throw new Error('技能 '+item.id+' 的技能分类无效');}}
  return {action:action,target:target,subject:a,item:item,options:options,mode:spec.mode|| (action.isMagical()?'magical':'physical'),kind:options.kind||spec.kind||'normal',
   skillMultiplier:Math.max(0,1+number(pass.rate)),flatSkill:number(pass.flat),normalAdd:normal,criticalAdd:criticalAdd,elementAdd:{},elementMultiplier:{},finalAdd:finalAdd,finalMultiplier:1,growthMultiplier:1,settlementMultiplier:1,
   physicalDefenseRate:1,magicalDefenseRate:1,physicalDamageMultiplier:1,magicalDamageMultiplier:1,flatMitigationRate:1,healingMultiplier:1,physicalIncomingPierce:0,magicalIncomingPierce:0,resistancePierce:0,incomingMultiplier:1,resistancePierceByElement:(function(){var m={},pp=cache.penetrateHarmRe&&cache.penetrateHarmRe.percent||{};Object.keys(pp).forEach(function(k){var v=number(pp[k]);if(v>0)m[Number(k)]=clamp(v,0,100);});return m;})(),after:[],origins:[],cleanup:[]};
 }
 function defenseRate(attack,defense){var a=Math.max(0,number(attack)),d=Math.max(0,number(defense));return a+d===0?1:Math.max(0.05,a/(a+d));}
 function rawMixedWeights(f){
  if(f.mode!=='mixed')return f.mode==='magical'?[0,1]:[1,0];
  var a=f.subject,b=f.target,fn=formula(f.item),saved=Math.random,values=[];
  try{var draws=f.randomValues||[],cursor=0;Math.random=function(){return cursor<draws.length?draws[cursor++]:.5;};var baseline=number(fn.call(f.action,a,b,a,b,a,f.item,$gameVariables._data,$gameSwitches._data));
   [2,4].forEach(function(id){cursor=0;var copy=Object.create(a),native=a.param;copy.param=function(p){return native.call(a,p)*(p===id?1.001:1);};var v=number(fn.call(f.action,copy,b,copy,b,copy,f.item,$gameVariables._data,$gameSwitches._data));values.push(Math.max(0,v-baseline));});
  }finally{Math.random=saved;}
  var sum=values[0]+values[1];return sum>0?[values[0]/sum,values[1]/sum]:[.5,.5];
 }
 function flatMitigation(f,e){var target=f.target._passiveCache||{},source=f.subject._passiveCache||{},pierce=source.penetrateHarmRe||{},value=number((target.harmRe||{})[e]);value=Math.max(0,value-number((pierce.fixed||{})[e]));return value*(1-clamp((pierce.percent||{})[e],0,100)/100)*Math.max(0,number(f.flatMitigationRate,1));}
 // 通用穿透作用于目标元素抗性（elementRate）；固定减伤穿透仍留在 flatMitigation。
 function applyResistancePierce(resistance,f,e){
  if(!(number(resistance)>0)){
   if(number(resistance)!==0)return resistance; // absorb(<0) 保持原样
   var pImmune=clamp(number((f.resistancePierceByElement||{})[e]),0,100);
   return pImmune>=100?1:0; // 完全免疫：仅 100% 及以上穿透可打破
  }
  if(number(resistance)<1){
   var py=clamp(f.resistancePierce,0,1),pg=clamp(number((f.resistancePierceByElement||{})[e]),0,100)/100;
   return 1-(1-number(resistance))*(1-py)*(1-pg); // 黄泉/镜流与装备穿透乘算，互不覆盖
  }
  return resistance;
 }
 function raceFactors(f){var a=f.subject,b=f.target,boost=0,flat=0;
  var targetNote=b.enemy?b.enemy().note:'',sourceNote=a.enemy?a.enemy().note:'';
  var targetIds=Array.from(targetNote.matchAll(/<EnemyRace\s*:\s*(\d+)\s*>/gi)).map(function(m){return Number(m[1]);}),sourceIds=Array.from(sourceNote.matchAll(/<EnemyRace\s*:\s*(\d+)\s*>/gi)).map(function(m){return Number(m[1]);});
  objects(a).forEach(function(o){var re=/<EnemyRaceBo(\d+)\s*:\s*([+-]?[\d.]+)%?\s*>/gi,m;while((m=re.exec(o.note||'')))if(targetIds.includes(Number(m[1])))boost+=number(m[2])/100;});
  objects(b).forEach(function(o){var re=/<EnemyRaceRe(\d+)\s*:\s*([+-]?[\d.]+)\s*>/gi,m;while((m=re.exec(o.note||'')))if(sourceIds.includes(Number(m[1])))flat+=number(m[2]);});
  return {multiplier:Math.max(0,1+boost),flat:Math.max(0,flat)};
 }
 function independent(f,e){var rate=f.settlementMultiplier,a=f.subject,physical=(f.noElement?f.mode==='physical':e===1)||(actor(a)&&a.actorId()===169&&f.item.id>=10171&&f.item.id<=10174);
  var pr=1,er=1;objects(a).forEach(function(o){var phys=/<SelfPhysRate:\s*([\d.]+)>/i.exec(o.note||''),elem=/<SelfElemRate:\s*([\d.]+)>/i.exec(o.note||'');if(phys)pr*=number(phys[1],1);if(elem)er*=number(elem[1],1);});
  rate*=f.categoryMax&&!f.noElement?Math.max(pr,er):(physical?pr:1)*(active.includes(e)?er:1);return Math.max(0,rate);
 }
 function equipmentElementBonus(a,e){var total=0,list=[];try{if(a&&typeof a.equips==='function')list=a.equips()||[];else if(a){if(typeof a.weapons==='function')list=list.concat(a.weapons()||[]);if(typeof a.armors==='function')list=list.concat(a.armors()||[]);}}catch(_e){}list.forEach(function(item){if(!item)return;var note=String(item.note||''),re=/<passiveELUP(\d+)\s*:\s*([+-]?[\d.]+)%?\s*>/gi,m;while((m=re.exec(note)))if(Number(m[1])===e)total+=number(m[2])/100;});return total;}
 function ownBonus(a,e){var value=number(a.elementAmplifyRate?a.elementAmplifyRate(e):0),tag='passiveELUP'+('00'+e).slice(-2);
  if(a.iteratePassiveSkill)a.iteratePassiveSkill(tag,function(v){value+=number(parseFloat(v))/100;});
  else objects(a).forEach(function(o){var re=/<passiveELUP(\d+)\s*:\s*([+-]?[\d.]+)%?\s*>/gi,m;while((m=re.exec(o.note||'')))if(Number(m[1])===e)value+=number(m[2])/100;});
  return value+equipmentElementBonus(a,e)+number(a.elementMagnifyRate?a.elementMagnifyRate(e):1,1)-1;
 }
 // 虚空、混沌、空间、水、风：「全伤」类来源多半只写到 1～9，取 max(自身, 火～暗中最低的一项)
 function elementBonus(a,e){var own=ownBonus(a,e);if(e>=11&&e<=15){var common=Math.min.apply(null,[2,3,4,5,6,7,8,9].map(function(c){return ownBonus(a,c);}));return Math.max(own,common);}return own;}
 CodexElements.bonus=elementBonus;
 function elementalBonus(f,e){return Math.max(0,1+elementBonus(f.subject,e)+number(f.elementAdd[e]))*number(f.elementMultiplier[e],1);}
 if(typeof JAH_Window_Status_Resistances!=='undefined'){
  JAH_Window_Status_Resistances.prototype.calcPassiveValue=function(e){return Math.round(elementBonus(this._actor,e)*10000)/100+'%';};
  var resistanceDraw=JAH_Window_Status_Resistances.prototype.drawText;JAH_Window_Status_Resistances.prototype.drawText=function(text){var e=data().names.indexOf(text),prior=this.contents.textColor;if(e>0)this.changeTextColor(color(e));try{return resistanceDraw.apply(this,arguments);}finally{this.contents.textColor=prior;}};
 }
 function healing(action,target,options,f){
  // 治疗沿用旧插件口径：只转换 HP 伤害，治疗不看转换后的属性增伤。
  var base=number(action.evalDamageFormula(target)),es=originalElements(action),mult=es.length?es.reduce(function(s,e){return s+elementalBonus(f,e);},0)/es.length:1;
  var value=base*mult*Math.max(0,number(f.healingMultiplier,1))*number($gameSystem.healRate(),1)*Math.max(0,number(target.rec,1));
  if(action.applyPassiveHealRate)value=action.applyPassiveHealRate(value);if(actor(target))value*=number((target._passiveCache||{}).states&&target._passiveCache.states.DBHPLSteal,1);
  if(!options.preview)value=action.applyVariance(value,f.item.damage.variance);
  return {value:Math.round(Math.min(0,value)),kind:'healing',breakdown:{base:base,elementMultiplier:mult}};
 }
 function compute(action,target,options){
  var f=defaultFrame(action,target,options),prior=action._codexDamageFrame,raw,critical,rows=[];stack.push(f);action._codexDamageFrame=f;
  try{
   (root.CodexDamageHooks||[]).forEach(function(h){if(h.enter){var close=h.enter(action,target,f);if(close)f.cleanup.push(close);}if(h.build)h.build(action,target,f);});
   if(options.mode)f.mode=options.mode;
   if([3,4].includes(f.item.damage.type))return healing(action,target,options,f);
   if(f.mode==='mixed'&&options.raw===undefined){var nativeRandom=Math.random;f.randomValues=[];try{Math.random=function(){var value=nativeRandom();f.randomValues.push(value);return value;};raw=Math.max(0,number(action.evalDamageFormula(target)));}finally{Math.random=nativeRandom;}}
   else raw=Math.max(0,number(options.raw===undefined?action.evalDamageFormula(target):options.raw));
   if(f.kind==='settled')return {value:Math.round(raw),kind:'settled',breakdown:{base:raw,origins:f.origins}};
   var initial=raw+f.flatSkill,mastered=initial;if(action.isSkill()&&f.item.masteryDamage)mastered=number(f.item.masteryDamage.call(action,initial,action.subject().skillMasteryLevel(f.item),f.item),initial);
   var masteryRate=initial?mastered/initial:1,basis=Math.max(0,mastered*f.skillMultiplier),weights=rawMixedWeights(f),defense=f.kind==='true'||f.kind==='fixed'||f.kind==='percent'?1:
    weights[0]*defenseRate(f.subject.atk,number(target.def)*Math.max(0,f.physicalDefenseRate))+weights[1]*defenseRate(f.subject.mat,number(target.mdf)*Math.max(0,f.magicalDefenseRate));
   var raceTyped=weights[0]*number(f.physicalDamageMultiplier,1)+weights[1]*number(f.magicalDamageMultiplier,1);
   if(f.mode==='mixed'&&['normal'].includes(f.kind)){defense=weights[0]*defenseRate(f.subject.atk,number(target.def)*Math.max(0,f.physicalDefenseRate))*number(f.physicalDamageMultiplier,1)+weights[1]*defenseRate(f.subject.mat,number(target.mdf)*Math.max(0,f.magicalDefenseRate))*number(f.magicalDamageMultiplier,1);}
   else defense*=raceTyped;
   critical=options.reference?!!options.critical:action.modifyCritical(!!options.critical,raw,target);
   var damageResult=target.result&&target.result();if(damageResult)damageResult.critical=critical;
   // Evaluate the skill's authored critical base once, then add all bonus sources.
   // The old applyCritical/applyCriticalRate chain multiplies those sources twice.
   var criticalBase=f.item.critMult&&f.item.critMult!==Yanfly.Param.critMult&&action.applyItemCriticalMult?number(action.applyItemCriticalMult(1,raw,target),1.5):1.5+number(f.subject.criticalMultiplierBonus?f.subject.criticalMultiplierBonus():0);
   var black=action._codexBlackFlashHit;if(black&&black.target===target&&black.boost)f.criticalAdd+=number(black.increment);
   var criticalMultiplier=critical?Math.max(1,(criticalBase+f.criticalAdd)*(options.reference?1:number($gameSystem.criticalMultiplier?$gameSystem.criticalMultiplier():1,1))):1;
   var finalMultiplier=Math.max(0,1+f.finalAdd)*Math.max(0,f.finalMultiplier),normalMultiplier=Math.max(0,1+f.normalAdd),race=raceFactors(f),explicit=options.elements||f.elements,es=explicit||actionElements(action);if(f.noElement)es=[0];if(!es.length)es=[0];
   // 转换时攻击方逐项按原属性结算，目标侧仍按转换后属性；多原属性取最终伤害最高的一项。
   var conversion=explicit||f.noElement?0:conversionId(action);
   var physical=options.mode?options.mode==='physical':action.isPhysical(),magical=options.mode?options.mode==='magical':action.isMagical();
   var incoming=f.kind==='true'?1:physical?Math.max(0,number(target.pdr,1)):magical?Math.max(0,number(target.mdr,1)):1;
   var pierce=physical?f.physicalIncomingPierce:f.magicalIncomingPierce;if(incoming>0&&incoming<1)incoming=1-(1-incoming)*(1-clamp(pierce,0,1));incoming*=Math.max(0,f.incomingMultiplier);
   var guard=f.kind==='true'?1:number(action.applyGuard(1,target),1),beforeCritical=0,settled=0,growth=Math.max(0,number(f.growthMultiplier,1)),cands=[];
   if(conversion){
    var original=originalElements(action);if(!original.length)original=[0];
    es.forEach(function(e){
     var resistance=f.kind==='true'||e===0?1:number(target.elementRate(e),1),absorb=resistance<0,match=f.kind==='true'?1:matchup(e,affinity(target));
     resistance=applyResistancePierce(resistance,f,e);
     var flat=f.kind==='true'?0:(flatMitigation(f,e)+race.flat),plus=options.reference?0:number($gameSystem.flatDamage());
     original.forEach(function(oe){
      var bonus=f.noElement||oe<=0?1:elementalBonus(f,oe),flatElement=f.noElement||oe<=0?0:number(f.subject.elementAmplifyNRate?f.subject.elementAmplifyNRate(oe):0),system=options.reference?1:Math.max(0,number($gameSystem.damageRate(),1));
      var multiplied=(basis+flatElement*masteryRate*f.skillMultiplier)*normalMultiplier*bonus*race.multiplier*finalMultiplier*system*(absorb?1:growth);
      var crit=absorb?1:criticalMultiplier,beforeFixed=multiplied*defense*match*Math.abs(resistance)*incoming*crit;
      var independentRate=absorb?1:independent(f,oe),gross=resistance===0?0:Math.max(0,beforeFixed+plus)*independentRate*guard;
      var afterFixed=resistance===0?0:Math.max(0,gross-flat),value=absorb?Math.max(0,beforeFixed+plus-flat)*guard:gross;
      if(absorb)value=-value;
      cands.push({value:value,pre:(absorb?-1:1)*(resistance===0?0:Math.max(0,beforeFixed/crit+plus-flat)),row:{element:e,name:name(e),sourceElement:oe,share:1,bonus:bonus,defense:defense,matchup:match,resistance:resistance,incoming:incoming,terminal:finalMultiplier,growth:absorb?1:growth,beforeFixed:gross,fixedMitigation:flat,afterFixed:afterFixed,critical:crit,independent:independentRate,guard:guard,value:value}});
     });
    });
   }else{
    es.forEach(function(e){
     var resistance=f.kind==='true'||e===0?1:number(target.elementRate(e),1),absorb=resistance<0,match=f.kind==='true'?1:matchup(e,affinity(target));
     resistance=applyResistancePierce(resistance,f,e);
     var bonus=f.noElement?1:elementalBonus(f,e),flatElement=f.noElement?0:number(f.subject.elementAmplifyNRate?f.subject.elementAmplifyNRate(e):0),system=options.reference?1:Math.max(0,number($gameSystem.damageRate(),1));
     var multiplied=(basis+flatElement*masteryRate*f.skillMultiplier)*normalMultiplier*bonus*race.multiplier*finalMultiplier*system*(absorb?1:growth);
     var crit=absorb?1:criticalMultiplier,beforeFixed=multiplied*defense*match*Math.abs(resistance)*incoming*crit;
     var flat=f.kind==='true'?0:(flatMitigation(f,e)+race.flat),plus=options.reference?0:number($gameSystem.flatDamage());
     var independentRate=absorb?1:independent(f,e),gross=resistance===0?0:Math.max(0,beforeFixed+plus)*independentRate*guard;
     var afterFixed=resistance===0?0:Math.max(0,gross-flat),value=absorb?Math.max(0,beforeFixed+plus-flat)*guard:gross;
     if(absorb)value=-value;
     cands.push({value:value,pre:(absorb?-1:1)*(resistance===0?0:Math.max(0,beforeFixed/crit+plus-flat)),row:{element:e,name:name(e),share:1,bonus:bonus,defense:defense,matchup:match,resistance:resistance,incoming:incoming,terminal:finalMultiplier,growth:absorb?1:growth,beforeFixed:gross,fixedMitigation:flat,afterFixed:afterFixed,critical:crit,independent:independentRate,guard:guard,value:value}});
    });
   }
   // 多属性：取对攻击方最有利的一个属性（原生 MV 取最有利的承伤）
   var pick=cands.reduce(function(b,c){return !b||c.value>b.value?c:b;},null);settled=pick.value;beforeCritical=pick.pre;rows.push(pick.row);
   if(!options.preview)settled=action.applyVariance(settled,f.item.damage.variance);
   var value=Math.round(settled);if(settled>0&&value===0)value=1;if(!Number.isFinite(value))throw new Error('技能 '+f.item.id+' 伤害非有限值');
   var result={value:value,_candidates:cands,_candidateGross:pick.value,kind:f.kind,critical:critical,breakdown:{version:version,base:raw,mastered:mastered,basis:basis,weights:weights,normal:normalMultiplier,terminal:finalMultiplier,beforeCritical:beforeCritical,critical:criticalMultiplier,criticalBase:criticalBase,criticalBonus:f.criticalAdd,defenses:{physicalAttack:f.subject.atk,magicalAttack:f.subject.mat,physicalDefense:target.def,magicalDefense:target.mdf,physicalRate:f.physicalDefenseRate,magicalRate:f.magicalDefenseRate},rows:rows,origins:f.origins}};
   if(options.commit)result._after=f.after.slice();return result;
  }finally{f.cleanup.reverse().forEach(function(fn){fn();});if(prior===undefined)delete action._codexDamageFrame;else action._codexDamageFrame=prior;stack.pop();}
 }
 function preview(action,target,options){
  var a,t,x,saved={},keys=['$gameActors','$gameParty','$gameTroop','$gameVariables','$gameSwitches','$gameTemp','$gameSystem','$gameMap','$gameScreen','$gameSelfSwitches'],bmAction=BattleManager._action,bmSubject=BattleManager._subject,random=Math.random,blackRandom=root.CodexBlackFlash&&CodexBlackFlash.random;
  keys.forEach(function(k){saved[k]=root[k];});
  try{
   Math.random=function(){return .5;};if(root.CodexBlackFlash)CodexBlackFlash.random=Math.random;
   var graph=JsonEx.makeDeepCopy({subject:action.subject(),target:target,action:action});a=graph.subject;t=graph.target;x=graph.action;
   // One graph preserves native action -> target references (cloud primary,
   // Garou snapshots, Sukuna casts). Separate clones would change those mechanics.
   function statMethods(original,copy){['param','paramBase','xparam','sparam','elementRate','traitObjects','skills','equips','criticalMultiplierBonus','skillMasteryLevel','iteratePassiveSkill'].forEach(function(k){if(Object.prototype.hasOwnProperty.call(original,k)&&typeof original[k]==='function')copy[k]=original[k];});}
   statMethods(action.subject(),a);statMethods(target,t);if(Object.prototype.hasOwnProperty.call(action,'item'))x.item=action.item;
   x.subject=function(){return a;};x._codexBlackFlashHit=null;
   root.$gameActors=Object.create(saved.$gameActors);$gameActors._data=[];var cloned={};if(actor(a))cloned[a.actorId()]=a;if(actor(t))cloned[t.actorId()]=t;
   saved.$gameActors._data.forEach(function(v,id){if(v){cloned[id]=cloned[id]||JsonEx.makeDeepCopy(v);$gameActors._data[id]=cloned[id];}});
   $gameActors.actor=function(id){var value=cloned[id]||(cloned[id]=saved.$gameActors._data[id]?JsonEx.makeDeepCopy(saved.$gameActors._data[id]):$dataActors[id]?new Game_Actor(id):null);$gameActors._data[id]=value;return value;};
   root.$gameParty=JsonEx.makeDeepCopy(saved.$gameParty);
   root.$gameTroop=JsonEx.makeDeepCopy(saved.$gameTroop);var ti=saved.$gameTroop.members().indexOf(target);if(ti>=0)$gameTroop._enemies[ti]=t;root.$gameVariables=JsonEx.makeDeepCopy(saved.$gameVariables);root.$gameSwitches=JsonEx.makeDeepCopy(saved.$gameSwitches);root.$gameTemp=JsonEx.makeDeepCopy(saved.$gameTemp);$gameTemp.reserveCommonEvent=function(){};
   ['$gameSystem','$gameMap','$gameScreen','$gameSelfSwitches'].forEach(function(k){root[k]=JsonEx.makeDeepCopy(saved[k]);});
   BattleManager._action=x;BattleManager._subject=a;
   // A derived panel can evaluate several attacks in this one isolated graph.
   // Never expose or reuse the graph beyond this synchronous callback.
   if(options.batch)return options.batch(x,t,a);
   return calculate(x,t,Object.assign({},options,{preview:true,isolated:true,commit:false}));
  }finally{keys.forEach(function(k){root[k]=saved[k];});BattleManager._action=bmAction;BattleManager._subject=bmSubject;Math.random=random;if(root.CodexBlackFlash)CodexBlackFlash.random=blackRandom;}
 }
 function dispatch(action,target,options){
  if(!options.segment){var split;
   (root.CodexDamageHooks||[]).some(function(h){if(h.split)split=h.split(action,target,options);return !!split;});
   if(split){var parts=split.map(function(p){return compute(action,p.target||target,Object.assign({},options,p.options,{segment:true}));});
    return {value:Math.round(parts.reduce(function(s,r){return s+r.value;},0)),_parts:parts,kind:parts[0].kind,critical:parts.some(function(p){return p.critical;}),breakdown:{version:version,segments:parts.map(function(p){return p.breakdown;}),rows:[].concat.apply([],parts.map(function(p){return p.breakdown.rows||[];}))}};
   }
  }return compute(action,target,options);
 }
 // Subtract each segment's flat amount after the attacker's native Confirm effects.
 // Target reaction effects, shields, drains and HP submission retain their native order.
 function finishSettlement(result,confirmed){
  var gross=result.value,ratio=gross>0?Math.max(0,number(confirmed))/gross:1;
  function part(r,amount){
   var rows=r.breakdown.rows||[],row=rows[0];
   if(row&&r.value>=0){
    if(r._candidates){var entered=Math.max(0,number(amount)),scale=r._candidateGross>0?entered/r._candidateGross:1,pick=null,best=-Infinity;
     r._candidates.forEach(function(c){if(c.value<0)return;var gross=r._candidateGross>0?c.value*scale:entered,final=c.row.resistance===0?0:Math.max(0,gross-c.row.fixedMitigation);if(final>best){best=final;pick=c;}});
     if(pick){row=pick.row;amount=best;r.breakdown.rows=[row];r.breakdown.beforeCritical=pick.pre;row.beforeFixed=row.resistance===0?0:r._candidateGross>0?pick.value*scale:entered;}
    }else amount=row.resistance===0?0:Math.max(0,number(amount)-row.fixedMitigation);
    row.afterFixed=amount;row.value=amount;
   }
   delete r._candidates;delete r._candidateGross;
   r.value=Math.round(number(amount));
   (r._after||[]).forEach(function(fn){fn(r);});delete r._after;
   return r.value;
  }
  if(result._parts){result.value=Math.round(result._parts.reduce(function(sum,r){return sum+part(r,r.value>=0?r.value*ratio:r.value);},0));result.breakdown.rows=[].concat.apply([],result._parts.map(function(r){return r.breakdown.rows||[];}));delete result._parts;}
  else part(result,confirmed);
  // 拆段（云裳）时整体的命中挂状态在这里执行；不拆段时 part() 已执行并删除 _after。
  if(result._after){var whole=result._after;delete result._after;whole.forEach(function(fn){fn(result);});}
  result.breakdown.settlementApplied=true;
  return result;
 }
 var nativePreState=Game_Action.prototype.onPreDamageStateEffects;
 if(nativePreState)Game_Action.prototype.onPreDamageStateEffects=function(target,value){
  var pending=this._codexFlatPending;delete this._codexFlatPending;
  var it=this.item(),absorbed=value<0&&it&&it.damage&&[1,5].indexOf(it.damage.type)>=0;
  var confirmed=absorbed?value:nativePreState.call(this,target,value);
  if(pending&&pending.target===target){var r=finishSettlement(pending.result,confirmed);this._codexDamageBreakdown=r.breakdown;this._resist=resistanceTag(r);return r.value;}
  return confirmed;
 };
 function resistanceTag(r){return r.breakdown.rows?r.breakdown.rows.every(function(v){return v.resistance===0;})?'immune':r.value<0?'absorb':r.breakdown.rows.some(function(v){return v.matchup>1;})?'weak':r.breakdown.rows.some(function(v){return v.resistance<1||v.matchup<1;})?'resist':'':'';}
 function calculateInternal(action,target,options){
  options=options||{};
  if(options.preview&&!options.isolated)return preview(action,target,options);
  var result=dispatch(action,target,options);
  if(options.preview){
   var confirmed=result.value,a=action.subject();
   // Reference-only synthetic battlers do not own native state machinery.
   if(!options.reference&&nativePreState&&a._states&&a.need_refreshstatelist&&!(confirmed<0&&[1,5].includes(action.item().damage.type)))confirmed=nativePreState.call(action,target,confirmed);
   return finishSettlement(result,confirmed);
  }
  action._codexFlatPending={target:target,result:result};
  return result;
 }
 function calculate(action,target,options){if(!(options&&options.preview))return calculateInternal(action,target,options);previewDepth++;try{return calculateInternal(action,target,options);}finally{previewDepth--;}}
 ['startDamagePopup','customPopup','startAnimation'].forEach(function(k){var original=Game_Battler.prototype[k];if(original)Game_Battler.prototype[k]=function(){if(previewDepth)return;return original.apply(this,arguments);};});
 root.CodexDamage={version:version,isPreviewing:function(){return previewDepth>0;},isCalculating:function(){return stack.length>0;},frame:function(){return stack[stack.length-1];},defenseRate:defenseRate,calculate:calculate,
  previewBatch:function(action,target,fn){previewDepth++;try{return preview(action,target,{batch:fn});}finally{previewDepth--;}}};
 var previous=Game_Action.prototype.makeDamageValue;
 CodexDamage.previousPipeline=previous;
 // 【Claude·未经Codex检验】v0.62.02：「治疗时加状态」（RecPushState）只给攻击者的友方。原来按结算值为负就挂，
 // 打到吸收属性（回血）的敌人时，治疗增益会挂到敌人身上（玩家反馈：蔷薇领域追加的DEBUFF之斩打免疫回血的敌人）。
 Game_Action.prototype.makeDamageValue=function(target,critical){var result=CodexDamage.calculate(this,target,{critical:critical,preview:!!this._codexPowerPreview,isolated:!!this._codexPowerPreview&&!!this.subject()._powerNativeMethods,commit:!this._codexPowerPreview});this._codexDamageBreakdown=result.breakdown;this._resist=result.breakdown.rows?result.breakdown.rows.every(function(r){return r.resistance===0;})?'immune':result.value<0?'absorb':result.breakdown.rows.some(function(r){return r.matchup>1;})?'weak':result.breakdown.rows.some(function(r){return r.resistance<1||r.matchup<1;})?'resist':'':'';
  if(!this._codexPowerPreview){var x=this,sign=result.value;result._after=result._after||[];result._after.push(function(r){if(actor(x.subject())&&!(root.CodexAlienation&&CodexAlienation.has(x.subject(),'void')&&CodexAlienation.isAttackDamage(this))){var cache=x.subject()._passiveCache||{},list=sign<0?(target.isActor&&target.isActor()===x.subject().isActor()?cache.recPushStates:[]):sign>0?cache.pushStates:[];(list||[]).forEach(function(row){if(Math.random()*100<row.probability&&!target.isStateAffected(row.stateId))target.addState(row.stateId);});if(sign>0)(cache.pushSelfStates||[]).forEach(function(row){if(Math.random()*100<row.probability&&!x.subject().isStateAffected(row.stateId))x.subject().addState(row.stateId);},x);}});}
  return result.value;};
 Game_Action.prototype.getItemElements=function(){return actionElements(this);};
 var oldHit=Game_Action.prototype.itemHit,oldEva=Game_Action.prototype.itemEva,oldCri=Game_Action.prototype.itemCri;
 Game_Action.prototype.itemHit=function(t){return clamp(oldHit.call(this,t),0,1);};Game_Action.prototype.itemEva=function(t){return clamp(oldEva.call(this,t),0,1);};Game_Action.prototype.itemCri=function(t){return clamp(oldCri.call(this,t),0,1);};
 function expandAll(note){if(!/所有(?:属性|元素)|全(?:属性|元素)|全部元素/.test(note))return note;
  ['Element Amplify ','Element Magnify ','passiveELUP','passiveELEM','passiveHarmRe','DepassiveHarmRe'].forEach(function(family){var entries={},re=new RegExp('<'+family+'(\\d+)\\s*:\\s*([^>]+)>','gi'),m;while((m=re.exec(note)))entries[Number(m[1])]=m[2].trim();var old=[2,3,4,5,6,7,8,9];if(old.every(function(i){return entries[i]!==undefined&&entries[i]===entries[2];}))active.forEach(function(i){if(entries[i]===undefined)note+='\n<'+family+i+': '+entries[2]+'>';});});return note;
 }
 // Keep proper names such as 太极阴阳/阴阳二气瓶/阴阳五行 intact.
 // Lists can put the statistic only after the final element (阴阳 混沌伤害+15%).
 function gearText(text){
  if(typeof text!=='string')return text;
  var aliases={'阴阳':'虚空','奥数':'奥术','暗黑':'黑暗'};
  var tail=/^(?:\s|[、，,／/·（(]|物理|火焰|寒冰|冰|火|大地|雷电|雷|自然|奥术|奥数|神圣|黑暗|暗黑|阴阳|虚空|混沌|空间|水|风)*(?:伤害|伤|增伤|抗性|穿透|承伤|属性)/;
  return text.replace(/阴阳|奥数|暗黑/g,function(label,at,whole){
   var after=whole.slice(at+label.length),before=whole.slice(0,at);
   var direct=/^(?:伤害|伤|增伤|抗性|穿透|承伤|属性)/.test(after);
   var list=(!at||/[\s、，,／/·（(：:]$/.test(before))&&tail.test(after);
   var attribute=/(?:伤害属性|攻击属性|元素)\s*[:：][^:：\n]*$/.test(before)&&/^(?:$|[\s、，,／/·）)])/.test(after);
   return direct||list||attribute?aliases[label]:label;
  });
 }
 CodexElements.normalizeEquipmentText=gearText;
 CodexElements.normalizeGear=function(item){if(!item)return false;var original=item.note||'',note=expandAll(gearText(original)),description=gearText(item.description||'');
  var all=/所有(?:属性|元素)|全(?:属性|元素)|全部元素/.test(note+' '+description),rates=(item.traits||[]).filter(function(t){return t.code===11;}),base=rates.find(function(t){return t.dataId===2;}),allTraits=all&&base&&[2,3,4,5,6,7,8,9].every(function(e){return rates.some(function(t){return t.dataId===e&&t.value===base.value;});}),missingTraits=allTraits&&active.some(function(e){return !rates.some(function(t){return t.dataId===e;});}),missingParsed=all&&['elementAmplify','elementAmplifyN','elementMagnify','elementReflect','elementForcedRate'].some(function(k){var old=item[k]||{};return [2,3,4,5,6,7,8,9].every(function(e){return old[e]!==undefined&&old[e]===old[2];})&&active.some(function(e){return old[e]===undefined;});});
  if(note===original&&description===(item.description||'')&&!missingTraits&&!missingParsed)return false;
  var prior={},meta=item.meta||{};['elementAmplify','elementAmplifyN','elementMagnify','elementReflect','elementForcedRate'].forEach(function(k){prior[k]=Object.assign({},item[k]||{});});var absorb=(item.elementAbsorb||[]).slice();
  item.note=note;if(item.description!==undefined)item.description=description;DataManager.extractMetadata(item);item.meta=Object.assign({},meta,item.meta);
  if(allTraits){item.traits=item.traits||[];active.forEach(function(e){if(!rates.some(function(t){return t.dataId===e;}))item.traits.push({code:11,dataId:e,value:base.value});});}
  // Rebuild only the element fields; preserve all native random affixes and growth.
  if(DataManager.processElementNotetags2)DataManager.processElementNotetags2([null,item]);
  // Upgrade-slot enchantments can exist only in parsed fields, outside the note.
  Object.keys(prior).forEach(function(k){var old=prior[k],equal=[2,3,4,5,6,7,8,9].every(function(e){return old[e]!==undefined&&old[e]===old[2];});if(equal&&all)active.forEach(function(e){if(old[e]===undefined){item[k]=item[k]||{};item[k][e]=old[2];}});item[k]=Object.assign(item[k]||{},old);});
  item.elementAbsorb=unique((item.elementAbsorb||[]).concat(absorb));
  item._codexElementSchema=1;return true;};
 var extract=DataManager.extractSaveContents;
 DataManager.extractSaveContents=function(contents){var out=extract.apply(this,arguments);[$dataWeapons,$dataArmors].forEach(function(rows){rows.forEach(function(i){if(i&&(i.baseItemId||i.originalBaseItemId))CodexElements.normalizeGear(i);});});return out;};
 CodexElements.normalizeNote=expandAll;
 var register=DataManager.registerNewItem;
 if(register)DataManager.registerNewItem=function(item){CodexElements.normalizeGear(item);return register.apply(this,arguments);};
 if(typeof Sprite_ItemHelp!=='undefined'){
  var help=Sprite_ItemHelp.prototype.setItem;
  Sprite_ItemHelp.prototype.setItem=function(item){
   if(!item)return help.apply(this,arguments);var proxy=Object.assign({},item),type=DataManager.isWeapon(item)?1:DataManager.isArmor(item)?2:DataManager.isSkill(item)?3:0;
   if(!proxy.descParams&&root.RJO&&RJO.HE)RJO.HE.getDescParams(proxy,type);
   if(type===1||type===2){proxy.note=gearText(proxy.note||'');proxy.description=gearText(proxy.description||'');proxy.descParams=(proxy.descParams||[]).map(function(row){var copy=row.slice();copy[0]=root.CodexDisplay&&CodexDisplay.text?CodexDisplay.text(gearText(copy[0])):gearText(copy[0]);return copy;});}
   proxy.descParams=(proxy.descParams||[]).filter(function(row){return !/^(?:\\c\[\d+\])?伤害属性\s*[:：]/i.test(row[0]||'');});var lines=[];
   if(DataManager.isSkill(item)&&item.damage&&[1,2,5,6].includes(item.damage.type)){
    var es=[item.damage.elementId].concat(item.multipleElements||[]).filter(function(e){return e>0;});
    lines.push('伤害属性：'+(es.length?richText(unique(es)):item.damage.elementId<0?'随武器属性':'无属性')+(es.length>1?'（均分伤害）':''));
   }
   if(item.meta&&item.meta.CodexTriggeredElement)lines.push('触发攻击属性：'+richText([Number(item.meta.CodexTriggeredElement)])+'（真实伤害）');
   if(type===1||type===2){
    function group(values,label,format,neutral){var es=active.filter(function(e){return values[e]!==undefined&&values[e]!==neutral;});if(es.length===active.length&&es.every(function(e){return values[e]===values[es[0]];})){lines.push('全部元素'+label+' '+format(values[es[0]]));return;}for(var i=0;i<es.length;i+=3)lines.push(es.slice(i,i+3).map(function(e){return richText([e])+label+' '+format(values[e]);}).join(' · '));}
    function percent(v){return Math.round(v*10000)/100+'%';}
    group(item.elementAmplify||{},'增伤',percent,0);group(item.elementMagnify||{},'增伤',percent,0);group(item.elementAmplifyN||{},'追加',String,0);
    var resist={},pierces={};(item.traits||[]).filter(function(t){return t.code===11&&active.includes(t.dataId);}).forEach(function(t){if(resist[t.dataId]===0)return;resist[t.dataId]=t.value===0?0:(resist[t.dataId]===undefined?1:resist[t.dataId])+t.value-1;});group(resist,'承伤',percent,1);
    // v0.51：穿透显示与缓存口径一致（无元素ID=全部元素、同对象完全相同标签只计一次、支持负值）。
    (function(){
     var all=[],n=($dataSystem&&$dataSystem.elements)?$dataSystem.elements.length:16;for(var i=1;i<n;i++){if(i===10||!$dataSystem.elements[i])continue;all.push(i);}if(!all.length)all=[1,2,3,4,5,6,7,8,9,11,12,13,14,15];
     var pctMap={},fixedMap={},seen={},re=/<DepassiveHarmRe(\d+)\s*:\s*([+-]?[\d.]+%?)>/gi,m;
     while((m=re.exec(item.note||''))){
      var key=(m[1]===''?'ALL':String(parseInt(m[1],10)))+'|'+m[2];if(seen[key])continue;seen[key]=1;
      var num=parseFloat(m[2]);if(!isFinite(num))continue;
      var els=m[1]===''?all:[parseInt(m[1],10)],isPct=m[2].indexOf('%')>=0;
      els.forEach(function(e){if(!isFinite(e))return;if(isPct)pctMap[e]=(pctMap[e]||0)+num;else fixedMap[e]=(fixedMap[e]||0)+num;});
     }
     function fmtPct(v){return Math.round(v*100)/100+'%';}
     function fmtFlat(v){return String(Math.round(v*100)/100);}
     function emit(map,label,isPercent){
      var ids=all.filter(function(e){return map[e]!==undefined;});if(!ids.length)return;
      var fmt=isPercent?fmtPct:fmtFlat;
      var allSame=ids.length===all.length&&ids.every(function(e){return map[e]===map[ids[0]];});
      if(allSame){lines.push('全部'+label+' '+fmt(map[ids[0]]));return;}
      for(var i=0;i<ids.length;i+=3)lines.push(ids.slice(i,i+3).map(function(e){return richText([e])+label+' '+fmt(map[e]);}).join(' · '));
     }
     emit(pctMap,'穿透',true);emit(fixedMap,'固定减伤穿透',false);
     // v0.57：提示破免疫门槛。
     if(Object.keys(pctMap).length)lines.push('穿透合计≥100%才能击破完全免疫');
    })();
    var attackElements=unique((item.traits||[]).filter(function(t){return t.code===31;}).map(function(t){return t.dataId;}));if(attackElements.length)lines.push('攻击属性：'+richText(attackElements));
   }
   lines.reverse().forEach(function(line){proxy.descParams.splice(1,0,[line,14,'rgba(170,215,245,1)',false,0]);});return help.call(this,proxy);
  };
 }
 // v0.57：旧档独立装备沿用旧备注，把无编号穿透标签换成数据库里的新写法（与 data 同表）。
 var PIERCE_FIX={weapon:{1360:['<DepassiveHarmRe: 15%>',''],1416:['<DepassiveHarmRe: 40%>','2']},armor:{1763:['<DepassiveHarmRe: 30%>',''],2583:['<DepassiveHarmRe: 10%>','0.5']}};
 function migratePierceNotes(){var n=0;[['weapon',window.$dataWeapons],['armor',window.$dataArmors]].forEach(function(pair){var table=PIERCE_FIX[pair[0]];(pair[1]||[]).forEach(function(i){if(!i||typeof i.note!=='string')return;var base=Number(i.originalBaseItemId||i.baseItemId||i.id),fix=table[base];if(!fix||i.note.indexOf(fix[0])<0)return;
  var rep='';if(fix[1]){for(var e=1;e<=9;e++)rep+=(e>1?'\n':'')+'<DepassiveHarmRe'+(e<10?'0':'')+e+': '+fix[1]+'%>';}
  i.note=rep?i.note.split(fix[0]).join(rep):i.note.split('\n'+fix[0]).join('').split(fix[0]).join('');if(DataManager.extractMetadata)DataManager.extractMetadata(i);delete i.descParams;n++;});});
  if(n&&window.$gameActors)($gameActors._data||[]).forEach(function(a){if(a&&a.refreshPassiveCache){a.initPassiveCache();a.refreshPassiveCache();}});return n;}
 root.CodexPierceNoteMigration=migratePierceNotes;
 var _codexPierceLoad=DataManager.extractSaveContents;
 DataManager.extractSaveContents=function(){var r=_codexPierceLoad.apply(this,arguments);try{migratePierceNotes();}catch(e){console.error('穿透备注迁移失败',e);}return r;};
 // v0.52：护盾/治疗类技能（恢复值=0 或正数）不触发 custom React Effect。
 // 背景：护盾技能公式为“...addShield(...); 0”，damage.type=3 仍走 executeDamage(0)；
 //       友方身上的 <Custom React Effect> 反伤（如状态381 反伤属性，条件 value>=0）会以施法者为 user 反伤，把施法者反死。
 //       真实伤害（value>0）不受影响，仍正常触发反伤。
 var _codexOnReactStateEffects=Game_Action.prototype.onReactStateEffects;
 if(_codexOnReactStateEffects)Game_Action.prototype.onReactStateEffects=function(target,value){
  if(this.isRecover&&this.isRecover()&&value>=0)return value;
  return _codexOnReactStateEffects.apply(this,arguments);
 };
 // 目标列表不启动战力预演，保持进入战斗与选敌流畅。
 if(typeof Window_BattleEnemy!=='undefined'){
  var drawEnemy=Window_BattleEnemy.prototype.drawItem;
  Window_BattleEnemy.prototype.drawItem=function(index){var b=this._enemies[index];if(!b)return drawEnemy.apply(this,arguments);var rect=this.itemRectForText(index),width=Math.min(230,rect.width*.55),power=root.CodexCombatPower&&CodexCombatPower.cachedEnemy?CodexCombatPower.cachedEnemy(b):null,pw=power?120:0,own=Object.getOwnPropertyDescriptor(this,'drawText'),native=this.drawText,size=this.contents.fontSize;this.drawText=function(text,x,y,w,align){return native.call(this,text,x,y,text===b.name()?Math.max(1,w-width-pw-8):w,align);};try{drawEnemy.apply(this,arguments);this.contents.fontSize=18;if(power){var pc=this.contents.textColor;this.contents.textColor='rgb(255,211,115)';this.contents.drawText('战力 '+CodexCombatPower.format(power.total),rect.x+rect.width-width-pw-4,rect.y,pw,this.lineHeight(),'right');this.contents.textColor=pc;}CodexElements.drawAttributes(this.contents,b,rect.x+rect.width-width,rect.y,width,this.lineHeight(),'敌人属性');}finally{if(own)Object.defineProperty(this,'drawText',own);else delete this.drawText;this.contents.fontSize=size;}};
 }
 return root.CodexDamage;
});
