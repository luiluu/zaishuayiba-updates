// Extracted from the verified native runtime; installer order is maintained by main.js.
window.CodexRuntime.register("installNanohaSharedKillRuntime", function() {
  function installNanohaSharedKillRuntime() {
    var skillId=10168, actorId=108;
    // v0.62.03（Kyo 2026-10-31）：适应成长软上限。累计前 2000 次每次 +10 生命、+30 魔法；之后每次乘 2000/累计次数。
    // 队友击杀（并肩适应）只给一半。旧存档按已得魔法加值÷30 估算累计次数，已得的不收回。
    window.CodexNanohaAdapt=function(a,share) {
      if (!a || !a.addParam) return;
      share=Number(share)||1;
      if (a._codexNanohaAdapt==null) a._codexNanohaAdapt=Math.max(0,Math.floor((Number(a._paramPlus&&a._paramPlus[1])||0)/30));
      var n=Math.max(0,Number(a._codexNanohaAdapt)||0), f=(n<2000?1:2000/n)*share;
      a.addParam(0,10*f); a.addParam(1,30*f);
      a._codexNanohaAdapt=n+share;
    };
    function ensureLearned() {
      var nanoha=$gameActors && $gameActors._data && $gameActors._data[actorId];
      if (nanoha && nanoha.level>=1 && !nanoha.isLearnedSkill(skillId)) {
        nanoha.learnSkill(skillId);
        if (nanoha.refreshPassiveSkillCache) nanoha.refreshPassiveSkillCache();
        if (nanoha.initPassiveCache && nanoha.refreshPassiveCache) {
          nanoha.initPassiveCache(); nanoha.refreshPassiveCache();
        }
      }
    }
    function eligibleNanoha(subject) {
      if (!subject || !subject.isActor || !subject.isActor() ||
          !subject.actorId || subject.actorId()===actorId ||
          !$gameParty || !$gameParty.inBattle || !$gameParty.inBattle()) return null;
      var nanoha=$gameActors && $gameActors._data && $gameActors._data[actorId];
      if (!nanoha || !nanoha.isLearnedSkill(skillId) ||
          !nanoha.isLearnedSkill(5683) || !nanoha.isAlive()) return null;
      var members=$gameParty.battleMembers();
      return members.indexOf(nanoha)>=0 && members.indexOf(subject)>=0 ? nanoha : null;
    }
    var oldExtract=DataManager.extractSaveContents;
    DataManager.extractSaveContents=function(contents) {
      oldExtract.call(this,contents);
      ensureLearned();
    };
    var oldApply=Game_Action.prototype.apply;
    Game_Action.prototype.apply=function(target) {
      var subject=this.subject();
      var liveEnemy=target && target.isEnemy && target.isEnemy() &&
        target.isAlive && target.isAlive();
      oldApply.call(this,target);
      if (!liveEnemy || !eligibleNanoha(subject) || !target.result ||
          !target.result().isHit()) return;
      this._codexNanohaTargets=this._codexNanohaTargets || [];
      if (this._codexNanohaTargets.indexOf(target)<0)
        this._codexNanohaTargets.push(target);
    };
    var oldEndAction=BattleManager.endAction;
    BattleManager.endAction=function() {
      var action=this._action;
      var targets=action && action._codexNanohaTargets;
      var nanoha=targets && eligibleNanoha(this._subject);
      oldEndAction.call(this);
      if (!nanoha) return;
      for (var i=0;i<targets.length;i++) {
        var enemy=targets[i];
        if (!enemy || !enemy.isDead || !enemy.isDead()) continue;
        window.CodexNanohaAdapt(nanoha,0.5);
      }
    };
  }

  // 原生职业从 1 级习得；旧存档需在读档后补学新数据库技能。

return installNanohaSharedKillRuntime.apply(this, arguments);
});
