// v0.62.12 暴击率为 0 及以下时，自然暴击概率记 0（修「负负得正」）。
// 原来的公式是「攻击方暴击率 ×（1－目标暴击回避）」：攻击方暴击率为负、目标暴击回避超过 100% 时，
// 两个负数相乘得正，暴击率为负的人反而能暴击。
// 攻击方暴击率＝面板暴击率（cri）＋被动「暴击率增加」（dsPassiveSkill 的 critPush：指定技能、战技/魔法、全局）。
// 这个值 ≤0 时，本次计算按「攻击方暴击率恰好为 0」走原有整条链，所以：
//   - 自然暴击概率为 0；
//   - 必爆（状态、动作序列 force critical）、黑闪、猫猫「心」必暴、云裳法宝等额外加成照旧生效（Kyo 2026-11-01：必暴可以暴）。
// 须在所有改暴击的模块之后安装。
window.CodexRuntime.register('installCritFloorRuntime',function(){
 'use strict';
 function num(v){v=Number(v);return isFinite(v)?v:0;}
 function push(a,item){
  var c=a&&a.isActor&&a.isActor()&&a._passiveCache&&a._passiveCache.critPush;if(!c||!item)return 0;
  var n=0,t=c.byType||{};
  if(c.bySkill&&c.bySkill[item.id])n+=num(c.bySkill[item.id])/100;
  if(item.stypeId===1)n+=num(t.Zj)/100;else if(item.stypeId===2)n+=num(t.Mf)/100;
  return n+num(c.all)/100;
 }
 function rate(action){
  var a=action.subject(),item=action.item();
  if(!a||!item)return 0;
  return num(a.cri)+push(a,item);
 }
 var oldCri=Game_Action.prototype.itemCri;
 Game_Action.prototype.itemCri=function(target){
  var a=this.subject(),item=this.item();
  if(!a||!item||!item.damage||!item.damage.critical||rate(this)>0)return oldCri.apply(this,arguments);
  // 攻击方暴击率 ≤0：临时把面板暴击率读成「－被动加成」，让原公式里的攻击方暴击率恰好为 0。
  var own=Object.prototype.hasOwnProperty.call(a,'cri'),prior=own&&Object.getOwnPropertyDescriptor(a,'cri'),zero=-push(a,item);
  Object.defineProperty(a,'cri',{get:function(){return zero;},configurable:true});
  try{return oldCri.apply(this,arguments);}
  finally{if(own)Object.defineProperty(a,'cri',prior);else delete a.cri;}
 };
 return {rate:rate};
});
