// 【Codex·未经Claude检验】v0.39 一二星强者；蕾姆保持强者。
// 【Claude·未经Codex检验】v0.14：超强者／强者名单说明补充路线压制（仅文字）。
/* 【Codex·未经Claude检验】超强者出战门槛；核查状态：未经claude检验。
 * Boss difficulty: +20% to eight parameters per deployed super-strong actor;
 * hyper armor on rounds 2, 4, 6... and another +20% outgoing damage per actor.
 * Roster follows the lobby projection plus user-confirmed imports and new actors.
 */
// 【Claude·未经Codex检验】v0.44 强弱分类统一读角色备注 <KyoTier>（CodexTier），本文件不再写编号名单。
// 两份数组由 installClaudeTierV044Runtime 在数据库读完后按标签填入。
window.CodexRuntime.register('installBossDifficultyRuntime', function() {
    'use strict';
    if (window.CodexBossDifficulty) return window.CodexBossDifficulty;
    var D = window.CodexBossDifficulty = {version: 1, armorStateId: 2651,
        superStrongIds: [], strongIds: [], perActor: 0.20};
    var setupCount = null;
    var contexts = [], settled = [], direct = [], updatingArmor = false;
    D.superStrongActorIds = function() { return D.superStrongIds.slice(); };
    D.showRoster = function(kind) {
        var ids = kind === 'super' ? D.superStrongIds : D.strongIds;
        var title = kind === 'super' ? '超强者名单' : '强者名单';
        $gameMessage.setFaceImage('SF_People2', 5);
        $gameMessage.setBackground(0); $gameMessage.setPositionType(2);
        $gameMessage.add('\\n<破阵·投影>' + title + '（' + ids.length + '人）');
        var line = '';
        ids.forEach(function(id) {
            var name = $dataActors[id].name;
            if (window.CodexImportedBalance && CodexImportedBalance.isDisabledActor(id)) name += '（停用）';
            if (line && line.length + name.length + 1 > 24) { $gameMessage.add(line); line = ''; }
            line += (line ? '、' : '') + name;
        });
        if (line) $gameMessage.add(line);
        if (kind === 'super') {
            $gameMessage.add('超强者仅限地狱及以上难度出战。');
            $gameMessage.add('每名出战超强者：Boss八项属性+20%。');
            $gameMessage.add('第2、4、6…回合霸体，持续一整回合。');
            $gameMessage.add('霸体回合每名超强者再令Boss输出+20%。');
            $gameMessage.add('洪荒以下路线压制：灭世微幅、天灾小幅、地狱大幅。');
            $gameMessage.add('天灾、地狱：受到伤害×1.2、×1.5，');
            $gameMessage.add('给队友的治疗、护盾、增益×0.8、×0.5。');
        } else { $gameMessage.add('镜流属于强者，不计入超强者难度加成。'); $gameMessage.add('强者在普通、困难、地狱路线有小幅压制。'); }
    };
    D.isSuperStrong = function(actor) {
        return !!(actor && actor.isActor && actor.isActor() &&
            D.superStrongActorIds().indexOf(actor.actorId()) >= 0);
    };
    // Use persistent challenge switches, not the enemy difficulty temporarily
    // selected by dungeon events. Chaos (native ID 9) is also above Hell.
    D.superStrongEnabled = function() {
        return !!($gameSwitches && [2494,2489,2487,2483,2461,2462,2463].some(function(id) {
            return $gameSwitches.value(id);
        })) || !!($gameSystem && $gameSystem.difficultyId() === 9);
    };
    D.canDeploy = function(actor) { return !D.isSuperStrong(actor) || D.superStrongEnabled(); };
    D.canAcquireId = function(id) {
        return D.superStrongActorIds().indexOf(Number(id)) < 0 || D.superStrongEnabled();
    };
    // Existing native horns use command129. The new native integrations expose
    // recruit() APIs; register their actual actor/horn pairs, independent of quality.
    D.recruitments = [
        [167,2902,'CodexRaven'],[168,2904,'CodexMira'],[169,2931,'CodexYomi'],
        [170,2932,'CodexJingliu'],[171,2936,'CodexToji'],[172,2938,'CodexSukuna'],
        [173,2940,'CodexGarou'],[174,2941,'CodexYunshang'],[175,2943,'Guyu'],
        [176,2945,'CodexTusu'],[177,2946,'CodexXuan'],[179,3063,'CodexLiuying']
    ];
    D.recruitActorId=function(item) {
        if (!item || !DataManager.isItem(item)) return 0;
        var id=item.baseItemId||item.id, spec=D.recruitments.filter(function(r){return r[1]===id;})[0];
        if(spec)return spec[0];
        var tag=/<CodexRecruitActor:\s*(\d+)>/i.exec(item.note||'');
        if(tag)return Number(tag[1]);
        var found=[];
        (item.effects||[]).forEach(function(effect){
            var ce=effect.code===44&&$dataCommonEvents[effect.dataId];
            if(ce)ce.list.forEach(function(c){
                if(c.code===129&&c.parameters[1]===0&&found.indexOf(c.parameters[0])<0)found.push(c.parameters[0]);
            });
        });
        return found.length===1?found[0]:0;
    };
    D.canAcquireItem=function(item) {return D.canAcquireId(D.recruitActorId(item));};
    function acquisitionNotice(){
        var text='超强者仅限地狱及以上难度获取。';
        if(window.$&&$.toaster)$.toaster({message:text});else $gameMessage.add(text);
    }
    var recruitWrapped=false, databaseLoaded=DataManager.isDatabaseLoaded;
    DataManager.isDatabaseLoaded=function(){
        if(!databaseLoaded.apply(this,arguments))return false;
        if(!recruitWrapped){
            D.recruitments.forEach(function(r){
                var api=window[r[2]],old=api&&api.recruit;
                if(typeof old!=='function')throw Error('超强者招募入口缺失：'+r[2]);
                api.recruit=function(){
                    if(!D.canAcquireId(r[0])){acquisitionNotice();return false;}
                    return old.apply(this,arguments);
                };
            });
            recruitWrapped=true;
        }
        return true;
    };
    var addActor=Game_Party.prototype.addActor;
    Game_Party.prototype.addActor=function(id){
        if((this._actors||[]).indexOf(Number(id))<0&&!D.canAcquireId(id)){
            acquisitionNotice();return false;
        }
        return addActor.apply(this,arguments);
    };
    var gainItem=Game_Party.prototype.gainItem;
    Game_Party.prototype.gainItem=function(item,amount){
        if(amount>0&&!D.canAcquireItem(item))return;
        return gainItem.apply(this,arguments);
    };
    var itemConditions=Game_BattlerBase.prototype.meetsItemConditions;
    Game_BattlerBase.prototype.meetsItemConditions=function(item){
        return D.canAcquireItem(item)&&itemConditions.apply(this,arguments);
    };
    var shopEnabled=Window_ShopBuy.prototype.isEnabled;
    Window_ShopBuy.prototype.isEnabled=function(item){
        return D.canAcquireItem(item)&&shopEnabled.apply(this,arguments);
    };
    var doBuy=Scene_Shop.prototype.doBuy;
    Scene_Shop.prototype.doBuy=function(){
        if(!D.canAcquireItem(this._item)){SoundManager.playBuzzer();acquisitionNotice();return;}
        return doBuy.apply(this,arguments);
    };
    [Window_ItemList,Window_ShopBuy].forEach(function(win){
        var help=win.prototype.updateHelp;
        win.prototype.updateHelp=function(){
            var out=help.apply(this,arguments),item=this.item();
            if(item&&!D.canAcquireItem(item)&&this._helpWindow)
                this._helpWindow.setText(item.name+'\n\\C[2]仅限地狱及以上难度获取与招募。\\C[0]');
            return out;
        };
    });
    var enforcing = new WeakSet(), deploymentNotice = null;
    D.enforceParty = function(party) {
        if (!party || enforcing.has(party) || !$gameActors ||
            !Array.isArray(party._battleMembers) || D.superStrongEnabled()) return false;
        enforcing.add(party);
        try {
            var ids = D.superStrongActorIds(), removed = [], vacancies = [], slots = party._battleMembers;
            slots.forEach(function(id,i) {
                if (ids.indexOf(id) < 0) return;
                removed.push(id); vacancies.push(i); slots[i] = 0;
            });
            if (!removed.length) return false;
            // Fill only the slots vacated by this rule. Existing deliberately
            // empty slots stay empty, and all owned characters remain owned.
            var reserves = (party._actors || []).filter(function(id) {
                var a;
                return ids.indexOf(id) < 0 && slots.indexOf(id) < 0 &&
                    (a=$gameActors.actor(id)) && a.isAppeared();
            });
            vacancies.forEach(function(i) { slots[i]=reserves.length?reserves.shift():0; });
            // No migration marker or roster history is persisted in the save.
            deploymentNotice = {party:party, ids:removed};
            return true;
        } finally { enforcing.delete(party); }
    };
    var battleMembers = Game_Party.prototype.battleMembers;
    Game_Party.prototype.battleMembers = function() {
        D.enforceParty(this);
        var members = battleMembers.apply(this,arguments);
        if (D.enforceParty(this)) members = battleMembers.apply(this,arguments);
        return members.filter(D.canDeploy);
    };
    ['initializeBattleMembers','addActor','swapOrderBattleMembers','rearrangeActors','changeBattleMax'].forEach(function(name) {
        var old = Game_Party.prototype[name];
        if (typeof old !== 'function') return;
        Game_Party.prototype[name] = function() {
            D.enforceParty(this);
            var result = old.apply(this,arguments);
            D.enforceParty(this);
            return result;
        };
    });
    D.flushDeploymentNotice = function() {
        if (!deploymentNotice || deploymentNotice.party !== $gameParty) return;
        var text='超强者仅限地狱及以上难度出战，已移至替补。';
        deploymentNotice=null;
        if (window.$ && $.toaster) $.toaster({message:text});
        else $gameMessage.add(text);
    };
    [Scene_Map,Scene_Party].forEach(function(scene) {
        var start=scene.prototype.start;
        scene.prototype.start=function() {
            D.enforceParty($gameParty);
            var out=start.apply(this,arguments);
            D.flushDeploymentNotice();
            return out;
        };
    });
    var actorEnabled=Window_PartyList.prototype.actorIsEnabled;
    Window_PartyList.prototype.actorIsEnabled=function(actor) {
        return D.canDeploy(actor) && actorEnabled.apply(this,arguments);
    };
    var itemEnabled=Window_PartyList.prototype.isCurrentItemEnabled;
    Window_PartyList.prototype.isCurrentItemEnabled=function() {
        return D.canDeploy(this.curActor()) && itemEnabled.apply(this,arguments);
    };
    var setHelp=Window_PartyList.prototype.setHelpWindowItem;
    Window_PartyList.prototype.setHelpWindowItem=function(actor) {
        if (actor && !D.canDeploy(actor) && this._helpWindow) {
            this._helpWindow.setText('\\C[2]'+actor.name()+'仅限地狱及以上难度出战。\\C[0]\n当前难度无法编入出战队伍；角色仍保留在替补。');
            return;
        }
        return setHelp.apply(this,arguments);
    };
    var switchActors=Scene_Party.prototype.switchActors;
    Scene_Party.prototype.switchActors=function() {
        if (!D.canDeploy($gameActors.actor(this._listWindow.item()))) {
            SoundManager.playBuzzer(); return;
        }
        return switchActors.apply(this,arguments);
    };
    D.countDeployed = function() {
        return $gameParty && $gameParty.battleMembers ?
            $gameParty.battleMembers().filter(D.isSuperStrong).length : 0;
    };
    function bossId(id) {
        var enemy = $dataEnemies && $dataEnemies[id];
        if (!enemy) return false;
        if (typeof Moghunter !== 'undefined' && Moghunter.boss_list) {
            for (var i = 1; i <= Moghunter.boss_list_length; i++) {
                if (Number(Moghunter.boss_list[i]) === Number(id)) return true;
            }
        }
        return /<boss(?:\s*:[^>]*)?\s*>|BOSS级怪物/i.test(enemy.note || '');
    }
    D.isBoss = function(enemy) {
        return !!(enemy && enemy.isEnemy && enemy.isEnemy() && enemy._codexBossDifficultyBoss);
    };
    D.attributeRate = function(enemy) {
        return D.isBoss(enemy) ? 1 + D.perActor * (enemy._codexBossStrongCount || 0) : 1;
    };
    D.hasHyperArmor = function(enemy) { return D.isBoss(enemy) && !!enemy._codexBossHyperArmor; };
    D.outputRate = function(enemy) { return D.hasHyperArmor(enemy) ? D.attributeRate(enemy) : 1; };
    D.isControlState = function(id) {
        var state = $dataStates && $dataStates[id];
        if (!state || id === 1 || id === D.armorStateId) return false;
        return Number(state.restriction) > 0 ||
            /<BuffType:\s*(?:沉默|封印|眩晕|睡眠|麻痹|混乱|魅惑|恐惧|冰冻)\s*>/i.test(state.note || '') ||
            (state.traits || []).some(function(t) { return t.code === 42 || t.code === 44; });
    };
    function dropState(enemy, id) {
        if (!enemy.isStateAffected(id)) return;
        if (enemy.removeStateCompletely) enemy.removeStateCompletely(id);
        else enemy.removeState(id);
        if (enemy.isStateAffected(id)) enemy.eraseState(id);
    }
    D.syncArmor = function(enemy, active) {
        enemy._codexBossHyperArmor = D.isBoss(enemy) && !!active;
        updatingArmor = true;
        try {
            if (enemy._codexBossHyperArmor) {
                enemy._states.slice().forEach(function(id) {
                    if (D.isControlState(id)) dropState(enemy, id);
                });
                if (!enemy.isDead() && !enemy.isStateAffected(D.armorStateId)) enemy.addState(D.armorStateId);
                if (enemy.isStateAffected(D.armorStateId)) enemy._stateTurns[D.armorStateId] = 1;
            } else dropState(enemy, D.armorStateId);
        } finally { updatingArmor = false; }
    };
    var troopSetup = Game_Troop.prototype.setup;
    Game_Troop.prototype.setup = function() {
        var previous = setupCount;
        this._codexBossStrongCount = D.countDeployed();
        setupCount = this._codexBossStrongCount;
        try { return troopSetup.apply(this, arguments); }
        finally { setupCount = previous; }
    };
    var enemySetup = Game_Enemy.prototype.setup;
    Game_Enemy.prototype.setup = function(id) {
        // Set the factor before native setup fills HP/MP. Parameter caches keep
        // the unscaled native values; our final wrapper never compounds them.
        this._codexBossStrongCount = setupCount === null ? D.countDeployed() : setupCount;
        this._codexBossDifficultyBoss = bossId(id);
        this._codexBossHyperArmor = false;
        return enemySetup.apply(this, arguments);
    };
    var param = Game_Enemy.prototype.param;
    Game_Enemy.prototype.param = function(id) {
        var value = param.apply(this, arguments);
        return id >= 0 && id < 8 ? Math.round(value * D.attributeRate(this)) : value;
    };
    var transform = Game_Enemy.prototype.transform;
    Game_Enemy.prototype.transform = function(id) {
        this._codexBossDifficultyBoss = bossId(id);
        var out = transform.apply(this, arguments);
        D.syncArmor(this, $gameTroop.turnCount() > 0 && $gameTroop.turnCount() % 2 === 0);
        return out;
    };
    var increaseTurn = Game_Troop.prototype.increaseTurn;
    Game_Troop.prototype.increaseTurn = function() {
        var out = increaseTurn.apply(this, arguments), active = this.turnCount() % 2 === 0;
        this.members().forEach(function(enemy) { D.syncArmor(enemy, active); });
        return out;
    };
    var endBattle = BattleManager.endBattle;
    BattleManager.endBattle = function() {
        $gameTroop.members().forEach(function(enemy) { D.syncArmor(enemy, false); });
        return endBattle.apply(this, arguments);
    };
    var addable = Game_Enemy.prototype.isStateAddable;
    Game_Enemy.prototype.isStateAddable = function(id) {
        if (D.hasHyperArmor(this) && D.isControlState(id)) return false;
        return addable.apply(this, arguments);
    };
    // Direct addNewState scripts must respect armor too. Death and ordinary
    // damage/debuffs remain valid; hyper armor grants no damage immunity.
    var addNewState = Game_Enemy.prototype.addNewState;
    Game_Enemy.prototype.addNewState = function(id) {
        if (D.hasHyperArmor(this) && D.isControlState(id)) return;
        return addNewState.apply(this, arguments);
    };
    ['removeState','eraseState','removeStateCompletely'].forEach(function(name) {
        var old = Game_Enemy.prototype[name];
        if (typeof old !== 'function') return;
        Game_Enemy.prototype[name] = function(id) {
            if (id === D.armorStateId && D.hasHyperArmor(this) && !updatingArmor && !this.isDead()) return;
            return old.apply(this, arguments);
        };
    });
    var recoverAll = Game_Enemy.prototype.recoverAll;
    Game_Enemy.prototype.recoverAll = function() {
        var out = recoverAll.apply(this, arguments);
        if (D.hasHyperArmor(this) && !updatingArmor) D.syncArmor(this, true);
        return out;
    };
    function subject(action) { return action && action.subject ? action.subject() : null; }
    function context(action, target, targets, fn, self, args, source) {
        contexts.push({source: source || subject(action), target: target, targets: targets});
        try { return fn.apply(self, args); }
        finally { contexts.pop(); }
    }
    function eligible(ctx, target) {
        return ctx && target && target !== ctx.source && D.outputRate(ctx.source) > 1 &&
            (ctx.target ? ctx.target === target : ctx.targets && ctx.targets.indexOf(target) >= 0);
    }
    function marked(list, target, kind) {
        return list.some(function(x) { return x.target === target && x.kind === kind; });
    }
    function scaled(value, source) { return Math.floor(Number(value) * D.outputRate(source)); }
    ['apply','executeDamage','applyPostDamageEval'].forEach(function(name) {
        var old = Game_Action.prototype[name];
        if (typeof old !== 'function') return;
        Game_Action.prototype[name] = function(target) {
            return context(this, target, null, old, this, arguments);
        };
    });
    ['Hp','Mp'].forEach(function(kind) {
        var name = 'execute' + kind + 'Damage', old = Game_Action.prototype[name];
        Game_Action.prototype[name] = function(target, value) {
            var args = Array.prototype.slice.call(arguments), source = subject(this);
            if (value > 0 && target !== source && !marked(settled, target, kind)) args[1] = scaled(value, source);
            settled.push({target: target, kind: kind});
            try { return old.apply(this, args); }
            finally { settled.pop(); }
        };
        function wrapGain(type) {
            var name = 'gain' + kind, old = type.prototype[name];
            type.prototype[name] = function(value) {
                var ctx = contexts[contexts.length - 1], args = Array.prototype.slice.call(arguments);
                if (value < 0 && eligible(ctx, this) && !marked(settled, this, kind) && !marked(direct, this, kind))
                    args[0] = -scaled(-value, ctx.source);
                direct.push({target: this, kind: kind});
                try { return old.apply(this, args); }
                finally { direct.pop(); }
            };
        }
        wrapGain(Game_Battler);
        if (Object.prototype.hasOwnProperty.call(Game_Actor.prototype, 'gain' + kind)) wrapGain(Game_Actor);
        var setName = 'set' + kind, oldSet = Game_BattlerBase.prototype[setName];
        Game_BattlerBase.prototype[setName] = function(value) {
            var ctx = contexts[contexts.length - 1], before = this[kind.toLowerCase()];
            var args = Array.prototype.slice.call(arguments);
            if (value < before && eligible(ctx, this) && !marked(settled, this, kind) && !marked(direct, this, kind))
                args[0] = before - scaled(before - value, ctx.source);
            direct.push({target: this, kind: kind});
            try { return oldSet.apply(this, args); }
            finally { direct.pop(); }
        };
    });
    ['processActionSequence','actionHpModify','actionMpModify'].forEach(function(name) {
        var old = BattleManager[name];
        if (typeof old !== 'function') return;
        BattleManager[name] = function() {
            var targets = this._targets || [];
            if (name !== 'processActionSequence' && this.makeActionTargets && arguments[1])
                targets = this.makeActionTargets(arguments[1][0]);
            return context(this._action, null, targets, old, this, arguments);
        };
    });
    // State damage is attributed to its applying battler rather than a stale
    // BattleManager subject. Self-costs and healing do not receive a bonus.
    var stateEval = Game_Battler.prototype.customEffectEval;
    if (typeof stateEval === 'function') Game_Battler.prototype.customEffectEval = function(id, type) {
        var origin = this.stateOrigin && this.stateOrigin(id);
        return context(null, this, null, stateEval, this, arguments, origin);
    };
    var actionStateEval = Game_Action.prototype.customEffectEval;
    if (typeof actionStateEval === 'function') Game_Action.prototype.customEffectEval = function(target, id, type, side) {
        if (type !== 'reactState' || (id !== 1341 && id !== 2550))
            return actionStateEval.apply(this, arguments);
        var origin = id === 1341 && side && side.stateOrigin ? side.stateOrigin(id) : side;
        var victim = id === 2550 ? subject(this) : target;
        return context(this, victim, null, actionStateEval, this, arguments, origin);
    };
    return D;
});
