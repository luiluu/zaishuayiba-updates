// 【Claude·未经Codex检验】v0.62 宝宝路线开放全部角色（用户 2026-10-31 确认：隐藏角色不可用，超强者可用；方式选「号角商店全部免费」）。
// - 宝宝路线（开关 2496）下，任何卖伙伴号角的商店都改为列出全部可用角色的号角，价格全部为 0（金币和魂灯等货币都不扣）。
// - 每名角色只能免费领一次：领过的记在存档（$gameParty._codexBabyHornActors），之后不再列出，防止领了卖掉（号角可卖 5000 金币＋1 魂灯）再领；
//   已经拥有（队伍、角色仓库、背包里已有这支号角，或招募事件的已招募变量≥1）的角色也不列出。每次最多买 1 支。
// - 排除：停用角色（CodexImportedBalance.disabledActorIds，含未完成角色）与隐藏角色（CodexV029.hiddenActors）。
// - 超强者：宝宝路线下视同已开放（CodexBossDifficulty.superStrongEnabled），可获取、可出战。
// - 招募仍走号角的原生使用流程，招募赠送照常发；本模块不直接加角色。
window.CodexRuntime.register('installBabyAllActorsRuntime',function(){
 'use strict';
 var W=window,B=W.CodexBabyAllActors={version:1,SWITCH:2496};
 var PRICE_KEYS=[['variableBuyPrice',{}],['variableBuyPrices',[]],['itemBuyPrice',{}],['itemBuyPrices',[]],
  ['weaponBuyPrice',{}],['weaponBuyPrices',[]],['armorBuyPrice',{}],['armorBuyPrices',[]]];
 B.active=function(){return !!(W.$gameSwitches&&$gameSwitches.value(B.SWITCH));};
 function isHorn(item){return !!(item&&W.DataManager&&DataManager.isItem(item)&&/^伙伴号角/.test(item.name||''));}
 function hornEvents(item){return (item.effects||[]).filter(function(e){return e.code===44;}).map(function(e){return e.dataId;});}
 // 号角 → 角色：先用超强者模块的识别（新角色接口登记表、<CodexRecruitActor>、招募事件里唯一的「加入队伍」），再取招募事件里第一个「加入队伍」
 B.hornActor=function(item){
  if(!isHorn(item))return 0;
  var D=W.CodexBossDifficulty,id=D&&D.recruitActorId?Number(D.recruitActorId(item))||0:0;if(id)return id;
  var ces=hornEvents(item);
  for(var i=0;i<ces.length;i++){var ce=$dataCommonEvents[ces[i]];if(!ce)continue;
   for(var k=0;k<ce.list.length;k++){var c=ce.list[k];if(c.code===129&&c.parameters[1]===0)return Number(c.parameters[0]);}}
  return 0;};
 B.excluded=function(id){
  id=Number(id);
  if(W.CodexImportedBalance&&CodexImportedBalance.isDisabledActor&&CodexImportedBalance.isDisabledActor(id))return true;
  if(W.CodexV029&&CodexV029.hiddenActors&&CodexV029.hiddenActors.indexOf(id)>=0)return true;
  var a=$dataActors[id];return !(a&&a.name);};
 // 招募事件开头「变量≥1 → 已有该队友」的那个变量
 function recruitedVar(item){
  var ces=hornEvents(item);
  for(var i=0;i<ces.length;i++){var ce=$dataCommonEvents[ces[i]],c=ce&&ce.list[0],p=c&&c.parameters;
   if(c&&c.code===111&&p[0]===1&&p[2]===0&&p[3]===1&&p[4]===0&&$gameVariables.value(p[1])>=1)return true;}
  return false;}
 B.taken=function(){var P=$gameParty;return P._codexBabyHornActors=P._codexBabyHornActors||[];};
 B.owned=function(id,item){
  var P=$gameParty;id=Number(id);
  return B.taken().indexOf(id)>=0||(P._actors||[]).indexOf(id)>=0||(P._saveactors||[]).indexOf(id)>=0||(item?recruitedVar(item)||P.hasItem(item):false);};
 // 每名角色取一支号角：优先商店里本来就卖的那支，其次编号最小的
 B.catalog=function(preferred){
  var byActor={};preferred=preferred||[];
  ($dataItems||[]).forEach(function(item){
   if(!isHorn(item))return;var id=B.hornActor(item);if(!id||B.excluded(id))return;
   var cur=byActor[id];
   if(!cur||(preferred.indexOf(item.id)>=0&&preferred.indexOf(cur.id)<0))byActor[id]=item;});
  return Object.keys(byActor).map(Number).sort(function(a,b){return a-b;}).map(function(id){return {actor:id,item:byActor[id]};});};
 // 超强者：宝宝路线视同已开放
 var D=W.CodexBossDifficulty;
 if(D&&D.superStrongEnabled){var enabled=D.superStrongEnabled;D.superStrongEnabled=function(){return B.active()||enabled.apply(this,arguments);};}
 // 商店
 var prepare=Scene_Shop.prototype.prepare;
 Scene_Shop.prototype.prepare=function(goods,purchaseOnly){
  this._codexBabyFree=false;
  var list=goods||[];
  if(B.active()&&list.some(function(g){return g&&g[0]===0&&isHorn($dataItems[g[1]]);})){
   var sold=list.filter(function(g){return g&&g[0]===0;}).map(function(g){return g[1];});
   var others=list.filter(function(g){return !(g&&g[0]===0&&isHorn($dataItems[g[1]]));});
   var horns=B.catalog(sold).filter(function(r){return !B.owned(r.actor,r.item);}).map(function(r){return [0,r.item.id,1,0];});
   goods=others.concat(horns);this._codexBabyFree=true;B.makeFree(true);}
  return prepare.call(this,goods,purchaseOnly);};
 // 免费期间清空号角的额外货币价格（场景结束时还原）
 var saved=null;
 B.makeFree=function(on){
  if(on){if(saved)return;saved={};
   ($dataItems||[]).forEach(function(item){if(!isHorn(item))return;var s=saved[item.id]={};
    PRICE_KEYS.forEach(function(k){s[k[0]]=item[k[0]];item[k[0]]=JSON.parse(JSON.stringify(k[1]));});});}
  else if(saved){Object.keys(saved).forEach(function(id){var item=$dataItems[id],s=saved[id];
    PRICE_KEYS.forEach(function(k){item[k[0]]=s[k[0]];});});saved=null;}};
 var terminate=Scene_Shop.prototype.terminate;
 Scene_Shop.prototype.terminate=function(){try{return terminate.apply(this,arguments);}finally{B.makeFree(false);}};
 var maxBuy=Scene_Shop.prototype.maxBuy;
 Scene_Shop.prototype.maxBuy=function(){var n=maxBuy.apply(this,arguments);
  return this._codexBabyFree&&isHorn(this._item)?Math.min(n,1):n;};
 // 买过之后从列表里拿掉（未使用的号角仍在背包里，也算「已拿」）
 var doBuy=Scene_Shop.prototype.doBuy;
 Scene_Shop.prototype.doBuy=function(number){var item=this._item,out=doBuy.apply(this,arguments);
  if(this._codexBabyFree&&isHorn(item)&&this._goods){
   var aid=B.hornActor(item);if(aid&&B.taken().indexOf(aid)<0)B.taken().push(aid);
   this._goods=this._goods.filter(function(g){return !(g[0]===0&&g[1]===item.id);});
   if(this._buyWindow){this._buyWindow._shopGoods=this._goods;this._buyWindow.refresh();}}
  return out;};
 return B;
});
