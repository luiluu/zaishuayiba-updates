// 【Codex·未经Claude检验】v0.35：技能详情沿用人物图鉴当前选中实例。
/*:
 * @plugindesc 人物图鉴全解锁，并可进入查看主动技能、被动与其他技能的完整说明
 * @author Codex
 *
 * @help
 * 人物图鉴中选择人物并确认，进入技能详情列表；取消返回人物列表。
 */

(function() {
    'use strict';

    if (typeof Scene_ActorBook === 'undefined' ||
        typeof Window_ActorBookIndex === 'undefined') {
        return;
    }

    function actorBookAllIds() {
        var result = [];
        for (var i = 1; i < $dataActors.length; i++) {
            if ($dataActors[i] && $dataActors[i].name) result.push(i);
        }
        return result;
    }

    var systemSkillSource, systemBookSkills;
    function externalBookSkill(skill) {
        if(systemSkillSource!==$dataSkills){
            systemSkillSource=$dataSkills;systemBookSkills={};
            [5968,5969,5970,5971,5972,5973,5980,6216,6235].forEach(function(id){systemBookSkills[id]=true;});
            var event=$dataCommonEvents&&$dataCommonEvents[1442];
            if(event)event.list.forEach(function(command){if(command.code!==355&&command.code!==655)return;var re=/\.learnSkill\((\d+)\)/g,m;while((m=re.exec(command.parameters[0]||'')))systemBookSkills[Number(m[1])]=true;});
        }
        return !!systemBookSkills[skill.id] || !!(skill.meta&&skill.meta.CodexRetired) || /^(?:轮回模式(?:·|$)|灭世挑战|(?:宝宝|简单|普通|困难|地狱|天灾)难度$|难度适应$|天道诅咒$)/.test(skill.name||'');
    }

    function actorBookSkills(actor, baseOnly) {
        var active = [];
        var passive = [];
        var other = [];
        var seen = {};
        var actorData = $dataActors[actor.actorId()];
        var classData = $dataClasses[actor._classId];
        var isRaven = typeof CodexRaven !== 'undefined' &&
            actor.actorId() === CodexRaven.ACTOR_ID;
        // 黑龙是米拉在战斗中的形态，不是另一名图鉴角色。
        var isMira = actor.actorId() === 168 && actorData && actorData.name;

        function addSkill(skillId) {
            var skill = $dataSkills[skillId];
            if (!skill || !skill.name || seen[skillId] || skill.stypeId === 3 || externalBookSkill(skill)) return;
            seen[skillId] = true;
            if (skill.stypeId >= 1 && skill.stypeId <= 3) {
                active.push(skill);
            } else if (skill.stypeId === 4) {
                passive.push(skill);
            } else if (skill.stypeId === 5) {
                other.push(skill);
            }
        }

        function addTraitSkills(data) {
            if (!data || !data.traits) return;
            for (var i = 0; i < data.traits.length; i++) {
                if (data.traits[i].code === 43) addSkill(data.traits[i].dataId);
            }
        }

        addTraitSkills(actorData);
        // 特殊角色的全部进阶技能在原生进阶表中，而非职业学习表中。
        // 其他角色仍沿用原图鉴的职业枚举。
        if (!isRaven || baseOnly) {
            addTraitSkills(classData);
            if (classData && classData.learnings) {
                for (var i = 0; i < classData.learnings.length; i++) {
                    addSkill(classData.learnings[i].skillId);
                }
            }
        }
        // Runtime-added characters (including 渡鸦) learn their skills after
        // the static database is loaded, so they may not have class learnings
        // or trait entries to enumerate.  Include the actor's real learned
        // list as the final source of truth.
        if (!baseOnly && isRaven) {
            var ravenSkills = [10122, 10123, 10124, 10125, 10126, 10127,
                10129, 10130, 10131, 10132, 10133, 10134,
                10136, 10137, 10138, 10139, 10170];
            for (var r = 0; r < ravenSkills.length; r++) addSkill(ravenSkills[r]);
        } else if (!baseOnly && isMira) {
            // 10140-10167 是米拉同一 Actor 的人形、解放、黑龙战技和被动。
            // 图鉴预览全部条目；实际学会与生效仍由职业、进阶和状态判定。
            for (var m = 10140; m <= 10167; m++) {
                // 10147 是解放动作内部调用的群伤，不是玩家可选技能。
                if (m !== 10147 && m !== 10153) addSkill(m);
            }
        } else if (!baseOnly && (actor.actorId() === 169 || actor.actorId() === 170)) {
            var first = actor.actorId() === 169 ? 10171 : 10187;
            var last = actor.actorId() === 169 ? 10186 : 10202;
            for (var n = first; n <= last; n++) addSkill(n);
        } else if (!baseOnly && actor.actorId() === 172) {
            for (var su=10229;su<=10249;su++) if ([10236,10237,10238].indexOf(su)<0) addSkill(su);
            addSkill(10225);
        } else if (!baseOnly && actor.actorId() === 173) {
            for (var gr=10250;gr<=10269;gr++) if (gr!==10258 && gr!==10264) addSkill(gr);
        } else if (!baseOnly && actor.actorId() === 171) {
            [10203,10205,10206,10207,10208,10209,10210,10211,10212,10213,10214,10215,10216,10217,10218,10219,10225,10226].forEach(addSkill);
        }
        if (!baseOnly && actor.actorId() === 179) {
            // 流萤：10622 天火轰击、10623 完全燃烧、10624-10632 被动。
            for (var ly = 10622; ly <= 10632; ly++) addSkill(ly);
            for (var lz = 1; lz < $dataSkills.length; lz++) if ($dataSkills[lz] && /<CodexLiuyingPassive:/.test($dataSkills[lz].note || '')) addSkill(lz);
        }
        if (!baseOnly && actor.actorId() === 174) {
            for (var yu=10270;yu<=10281;yu++) addSkill(yu);
            addSkill(10287);
        }
        return active.concat(passive, other);
    }

    window.CodexActorBookSkills=actorBookSkills;

    function skillTypeName(skill) {
        if (/<CodexAura>/.test(skill.note || '')) return '光环';
        if (skill.stypeId === 4) return '被动';
        return $dataSystem.skillTypes[skill.stypeId] || '其他';
    }

    // Opening the book permanently registers every real, named actor in the
    // current save while keeping empty database slots hidden.
    var _Scene_ActorBook_initialize = Scene_ActorBook.prototype.initialize;
    Scene_ActorBook.prototype.initialize = function() {
        _Scene_ActorBook_initialize.call(this);
        var ids = actorBookAllIds();
        for (var i = 0; i < ids.length; i++) {
            if ($gameParty.ActorBookLite.indexOf(ids[i]) < 0) {
                $gameParty.ActorBookLite.push(ids[i]);
            }
        }
    };

    function Window_ActorBookSkillHeader() {
        this.initialize.apply(this, arguments);
    }
    Window_ActorBookSkillHeader.prototype = Object.create(Window_Base.prototype);
    Window_ActorBookSkillHeader.prototype.constructor = Window_ActorBookSkillHeader;
    Window_ActorBookSkillHeader.prototype.initialize = function(x, y, width, height) {
        Window_Base.prototype.initialize.call(this, x, y, width, height);
        this._actor = null;
    };
    Window_ActorBookSkillHeader.prototype.setActor = function(actor) {
        if (this._actor !== actor) {
            this._actor = actor;
            this.refresh();
        }
    };
    Window_ActorBookSkillHeader.prototype.refresh = function() {
        this.contents.clear();
        if (!this._actor) return;
        this.changeTextColor(this.systemColor());
        this.drawText(this._actor.name() + ' · 技能详情', 0, 0, this.contentsWidth(), 'center');
        this.resetTextColor();
        this.contents.fontSize = 18;
        this.drawText('上下选择技能，取消返回人物图鉴', 0, this.lineHeight(), this.contentsWidth(), 'center');
        this.resetFontSettings();
    };

    function Window_ActorBookSkillList() {
        this.initialize.apply(this, arguments);
    }
    Window_ActorBookSkillList.prototype = Object.create(Window_Selectable.prototype);
    Window_ActorBookSkillList.prototype.constructor = Window_ActorBookSkillList;
    Window_ActorBookSkillList.prototype.initialize = function(x, y, width, height) {
        Window_Selectable.prototype.initialize.call(this, x, y, width, height);
        this._actor = null;
        this._data = [];
        this._detailSprite = null;
        this.hide();
        this.deactivate();
    };
    Window_ActorBookSkillList.prototype.maxItems = function() {
        return this._data ? this._data.length : 0;
    };
    Window_ActorBookSkillList.prototype.item = function() {
        return this.index() >= 0 ? this._data[this.index()] : null;
    };
    Window_ActorBookSkillList.prototype.setDetailSprite = function(sprite) {
        this._detailSprite = sprite;
        // Register the details panel as the selectable window's help target.
        // This makes every cursor move invoke updateHelp immediately.
        this._helpWindow = sprite;
    };
    Window_ActorBookSkillList.prototype.setActor = function(actor) {
        this._actor = actor;
        this._data = actorBookSkills(actor);
        this.refresh();
        this.select(this._data.length > 0 ? 0 : -1);
        this.updateHelp();
    };
    Window_ActorBookSkillList.prototype.drawItem = function(index) {
        var skill = this._data[index];
        if (!skill) return;
        var rect = this.itemRectForText(index);
        var isMira = this._actor && this._actor.actorId() === 168;
        var dragonOnly = isMira &&
            (skill.id >= 10148 && skill.id <= 10154 ||
             skill.id >= 10161 && skill.id <= 10164 || skill.id === 10167);
        var label = '【' + (dragonOnly ? '黑龙·' : '') + skillTypeName(skill) + '】';
        if (skill.stypeId === 4) this.changeTextColor(this.textColor(14));
        else if (skill.stypeId >= 1 && skill.stypeId <= 3) this.changeTextColor(this.textColor(3));
        else this.changeTextColor(this.textColor(6));
        this.drawText(label, rect.x, rect.y, this.textWidth(label) + 8);
        this.resetTextColor();
        var preview = this._actor && (this._actor.actorId() === 167 || isMira ||
             this._actor.actorId() === 169 || this._actor.actorId() === 170 || this._actor.actorId() === 172 || this._actor.actorId() === 173 || this._actor.actorId() === 174 || this._actor.actorId() === 179) &&
            this._actor.skills && !this._actor.skills().some(function(known) {
                return known.id === skill.id;
            });
        var prefixWidth = this.textWidth(label) + 4;
        var previewWidth = preview ? this.textWidth('未解锁') + 8 : 0;
        this.drawItemName(skill, rect.x + prefixWidth, rect.y,
            rect.width - prefixWidth - previewWidth);
        if (preview) {
            this.changeTextColor(this.textColor(7));
            this.drawText('未解锁', rect.x + rect.width - previewWidth, rect.y, previewWidth);
            this.resetTextColor();
        }
    };
    Window_ActorBookSkillList.prototype.updateHelp = function() {
        if (!this._detailSprite) return;
        var skill = this.item();
        if (!skill) {
            this._detailSprite.visible = false;
            return;
        }
        if (!skill.descParams && typeof RJO !== 'undefined' && RJO.HE) {
            RJO.HE.getDescParams(skill, 3);
        }
        var displaySkill = {};
        for (var key in skill) displaySkill[key] = skill[key];
        displaySkill.note = String(skill.note || '').replace(/<HelpWidth:\s*\d+>/ig, '');
        this._detailSprite.setItem(displaySkill);
        this._detailSprite.x = Math.floor(Graphics.boxWidth * 0.42) + 8;
        this._detailSprite.y = 8;
        this._detailSprite.visible = true;
    };

    var _Scene_ActorBook_create = Scene_ActorBook.prototype.create;
    Scene_ActorBook.prototype.create = function() {
        _Scene_ActorBook_create.call(this);
        var leftWidth = Math.floor(Graphics.boxWidth * 0.42);
        var headerHeight = this._indexWindow.lineHeight() * 2 +
            this._indexWindow.standardPadding() * 2;

        this._actorSkillHeader = new Window_ActorBookSkillHeader(
            0, 0, leftWidth, headerHeight
        );
        this._actorSkillList = new Window_ActorBookSkillList(
            0, headerHeight, leftWidth, Graphics.boxHeight - headerHeight
        );
        this._actorSkillHelp = new Sprite_ItemHelp(Graphics.boxWidth - leftWidth - 16);
        this._actorSkillHelp._isExtra = true;
        this._actorSkillHelp.x = leftWidth + 8;
        this._actorSkillHelp.y = 8;
        this._actorSkillHelp.visible = false;

        this._actorSkillHeader.hide();
        this._actorSkillList.setDetailSprite(this._actorSkillHelp);
        this._actorSkillList.setHandler('cancel', this.closeActorSkillDetails.bind(this));
        this._indexWindow.setHandler('ok', this.openActorSkillDetails.bind(this));

        this.addWindow(this._actorSkillHeader);
        this.addWindow(this._actorSkillList);
        this.addChild(this._actorSkillHelp);
    };

    Scene_ActorBook.prototype.openActorSkillDetails = function() {
        var actor = this._indexWindow.actor();
        if (!actor) {
            SoundManager.playBuzzer();
            this._indexWindow.activate();
            return;
        }
        this._indexWindow.hide();
        this._statusWindow.hide();
        this._indexWindow.deactivate();
        this._actorSkillHeader.setActor(actor);
        this._actorSkillList.setActor(actor);
        this._actorSkillHeader.show();
        this._actorSkillList.show();
        this._actorSkillList.activate();
    };

    var _CodexActorBook_update = Scene_ActorBook.prototype.update;
    Scene_ActorBook.prototype.update = function() {
        _CodexActorBook_update.apply(this, arguments);
        if (this._actorSkillList && this._actorSkillList.visible) {
            this._indexWindow.hide();
            this._statusWindow.hide();
        }
    };

    Scene_ActorBook.prototype.closeActorSkillDetails = function() {
        this._actorSkillList.deactivate();
        this._actorSkillList.hide();
        this._actorSkillHeader.hide();
        this._actorSkillHelp.visible = false;
        this._indexWindow.show();
        this._statusWindow.show();
        this._indexWindow.activate();
    };

})();
