/* 游戏内更新模块（Windows 解压版）。
 *
 * 由 js/windows-preload.js 在页面中载入。启动后在标题界面静默检查更新通道，
 * 玩家确认后下载内容更新包、校验 SHA-256 与 RSA 签名，退出游戏，
 * 由独立 PowerShell 进程等待游戏退出后运行包内安装器并重新启动游戏。
 *
 * 只使用静态 HTTPS 文件：channel.json / channel.sig / 内容更新包 ZIP。
 * 任何检查失败都不打断游戏；安装失败保留原有游戏内容，并写入 update.log。
 * 玩家可见文本不包含内部工具信息。
 */
(function (global) {
    'use strict';

    var FORMAT = 'kyo-update-channel-v1';

    // NW.js 页面上下文通常有 Buffer；没有时从 Node 模块取，避免依赖全局实现。
    var NodeBuffer = (typeof Buffer !== 'undefined') ? Buffer :
        ((typeof require === 'function') ? require('buffer').Buffer : null);

    // 更新通道公钥（与 channel.sig 的签名证书对应）。
    var PUBLIC_KEY_PEM = [
        '-----BEGIN PUBLIC KEY-----',
        'MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAtginv+/y+tmm5WIFmC9l',
        'q5Ko45fLL44Sjop5HFBC/IUaD1tr34n+DTye1i8T21sahFCb8vSm8sm/5E4rIou/',
        'OaB4huCiAl43FNih4ld8EAITqYajZqApmthcvXuHQ34DSAi+kkE8Jjg5COu8OYiE',
        'zf1bk/JL0S2t4OhA09STlyL+C8NaMhbZfq1a5P6Rcw5y61LnsRB0occ/eRtBZ2Va',
        'c8N3s6z6HolIpubTGeSOE+Pl4R2JRhvxcQJNvTrY0cCXs9VG9MLBlRdqW6rxywB/',
        'Sj566tdmk6VNkSM2eZjtIifefxZQ6RD6LCfJXzJEZZOudzFUrDHK9ZK86bdMiwyH',
        'O9k1JMk0h3z3LE/ut49z8xVxWePYs0p9xTe6sBDTXvuV+EGBb2+swSnsSlRdaUiE',
        'P/AXYr+SCsmnAeSMlVVrexCwvTbWdwKQ8lL2qiBGObOxLV7+y6FkyU2qQRH4Ex6n',
        'LQ3k9f708xOrOJ2BRAHi2T61ZYgYcjKXZLYtniEfKGtVMiUp6XVL7Tvo26ORAipu',
        'bIsOWJbN7+RF/mUV+Tc77zcCvecfxPnSv2/eLp+11PbDR9pRJ8XgB94GZvM2wE7/',
        '+5ipCcM4PYWTjWDdw1uV94+r6D5FOTeKsRviRR4PSRPNpitRGUNLVUTCPaLtU61N',
        'VXrgQMu5qvy1QzHIc7HB6AkCAwEAAQ==',
        '-----END PUBLIC KEY-----'
    ].join('\n') + '\n';

    // 发布前由打包脚本写入更新通道地址；留空表示当前构建未配置通道，只在手动检查时提示。
    var CHANNEL_URL = 'https://raw.githack.com/luiluu/zaishuayiba-updates/main/windows/channel.json';
    // 备用通道：CDN 对 main 分支有小时级缓存，主地址失效或过旧时依次尝试，取签名有效且版本最高的一个。
    // jsDelivr 对 main 分支缓存最久（约 12 小时），放在最后。
    var CHANNEL_FALLBACKS = [
        'https://raw.githubusercontent.com/luiluu/zaishuayiba-updates/main/windows/channel.json',
        'https://cdn.jsdelivr.net/gh/luiluu/zaishuayiba-updates@main/windows/channel.json'
    ];

    var DEFAULT_CONFIG = {
        channelUrl: CHANNEL_URL,
        channelUrls: CHANNEL_URL ? [CHANNEL_URL].concat(CHANNEL_FALLBACKS) : [],
        autoCheckDelayMs: 1500,
        timeoutMs: 20000,
        redirectLimit: 5,
        channelMaxBytes: 64 * 1024,
        downloadMaxBytes: 512 * 1024 * 1024,
        allowHttp: false,
        disableAuto: false,
        quitDelayMs: 900,
        waitTimeoutSeconds: 1800
    };

    var RUNNER_SCRIPT = [
        'param(',
        ' [Parameter(Mandatory=$true)][string]$PackageDir,',
        ' [Parameter(Mandatory=$true)][string]$GameDir,',
        ' [string]$GameExe = "",',
        ' [int]$GamePid = 0,',
        ' [Parameter(Mandatory=$true)][string]$LogPath,',
        ' [string]$InstallerCmd = "",',
        ' [string]$GameProcessName = "Game",',
        ' [int]$WaitTimeoutSeconds = 1800,',
        ' [bool]$RestartOnFailure = $true,',
        ' [switch]$SkipLaunch',
        ')',
        '$ErrorActionPreference = "Stop"',
        'Write-Host "正在等待游戏退出，然后安装更新。请保留此窗口直到游戏重新启动。"',
        'function Write-UpdateLog([string]$Kind, $Value) {',
        ' try {',
        '  $record = [ordered]@{ time = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ"); kind = $Kind; value = $Value }',
        '  $json = $record | ConvertTo-Json -Compress -Depth 6',
        '  [IO.File]::AppendAllText($LogPath, $json + "`r`n", (New-Object Text.UTF8Encoding($false)))',
        ' } catch {}',
        '}',
        'function Get-PowerShellPath() {',
        ' if ($PSHOME) {',
        '  $candidates = @((Join-Path $PSHOME "powershell.exe"), (Join-Path $PSHOME "pwsh.exe"), (Join-Path $PSHOME "pwsh"))',
        '  foreach ($item in $candidates) { if ($item -and (Test-Path -LiteralPath $item -PathType Leaf)) { return $item } }',
        ' }',
        ' if ($env:SystemRoot) {',
        '  $windowsPowerShell = Join-Path $env:SystemRoot "System32\\WindowsPowerShell\\v1.0\\powershell.exe"',
        '  if (Test-Path -LiteralPath $windowsPowerShell -PathType Leaf) { return $windowsPowerShell }',
        ' }',
        ' $command = Get-Command powershell.exe -ErrorAction SilentlyContinue',
        ' if ($command) { return $command.Source }',
        ' return "powershell.exe"',
        '}',
        'try {',
        ' Write-UpdateLog "runner-start" ("package=" + $PackageDir + "; game=" + $GameDir + "; pid=" + $GamePid)',
        ' if ($GamePid -gt 0) {',
        '  $deadline = (Get-Date).AddSeconds($WaitTimeoutSeconds)',
        '  while ($true) {',
        '   $process = Get-Process -Id $GamePid -ErrorAction SilentlyContinue',
        '   if (-not $process) { Write-UpdateLog "game-exited" ("pid=" + $GamePid + " 已退出"); break }',
        '   if ($process.ProcessName -ne $GameProcessName -and $process.ProcessName -ne ($GameProcessName + ".exe")) { Write-UpdateLog "game-exited" ("pid=" + $GamePid + " 已被其他进程使用: " + $process.ProcessName); break }',
        '   if ((Get-Date) -gt $deadline) { Write-UpdateLog "runner-error" ("game-still-running: 等待超时 pid=" + $GamePid); exit 3 }',
        '   Start-Sleep -Seconds 1',
        '  }',
        '  Start-Sleep -Milliseconds 800',
        ' }',
        ' $installer = $InstallerCmd',
        ' if (-not $installer) { $installer = Join-Path $PackageDir "InstallUpdate.ps1" }',
        ' if (-not (Test-Path -LiteralPath $installer -PathType Leaf)) { Write-UpdateLog "runner-error" ("installer-missing: " + $installer); exit 2 }',
        ' $logDirectory = [IO.Path]::GetDirectoryName($LogPath)',
        ' if (-not (Test-Path -LiteralPath $logDirectory)) { New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null }',
        ' $installerLog = Join-Path $logDirectory ("installer-" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".log")',
        ' $ps = Get-PowerShellPath',
        ' Write-UpdateLog "installer-start" ("powershell=" + $ps + "; script=" + $installer + "; log=" + $installerLog)',
        ' $arguments = @("-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $installer, "-GameDir", $GameDir)',
        ' & $ps @arguments *> $installerLog',
        ' $code = $LASTEXITCODE',
        ' if ($code -ne 0) {',
        '  Write-UpdateLog "installer-failed" ("exit=" + $code + "; log=" + $installerLog)',
        '  if ($RestartOnFailure -and -not $SkipLaunch -and $GameExe -and (Test-Path -LiteralPath $GameExe -PathType Leaf)) {',
        '   try { Start-Process -FilePath $GameExe -WorkingDirectory $GameDir | Out-Null; Write-UpdateLog "game-restarted" "安装失败，已按原版本重新启动游戏" } catch { Write-UpdateLog "restart-failed" $_.Exception.Message }',
        '  }',
        '  exit 4',
        ' }',
        ' Write-UpdateLog "installer-ok" ("exit=0; log=" + $installerLog)',
        ' if ($SkipLaunch) { Write-UpdateLog "skip-launch" "测试模式，不重新启动游戏"; exit 0 }',
        ' if (-not $GameExe -or -not (Test-Path -LiteralPath $GameExe -PathType Leaf)) { Write-UpdateLog "runner-error" ("game-exe-missing: " + $GameExe); exit 5 }',
        ' Start-Process -FilePath $GameExe -WorkingDirectory $GameDir | Out-Null',
        ' Write-UpdateLog "game-restarted" $GameExe',
        ' exit 0',
        '} catch {',
        ' Write-UpdateLog "runner-error" $_.Exception.Message',
        ' exit 1',
        '}'
    ].join('\n');

    var EXTRACT_SCRIPT = [
        'param(',
        ' [Parameter(Mandatory=$true)][string]$ZipPath,',
        ' [Parameter(Mandatory=$true)][string]$DestDir',
        ')',
        '$ErrorActionPreference = "Stop"',
        '$ProgressPreference = "SilentlyContinue"',
        'if (-not (Test-Path -LiteralPath $ZipPath -PathType Leaf)) { throw "zip-missing" }',
        '$destFull = [IO.Path]::GetFullPath($DestDir)',
        '$probe = $destFull.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar',
        'Add-Type -AssemblyName System.IO.Compression.FileSystem',
        '$zip = [IO.Compression.ZipFile]::OpenRead($ZipPath)',
        '$count = 0',
        '$total = 0',
        'try {',
        ' foreach ($entry in $zip.Entries) {',
        '  $count++',
        '  if ($count -gt 5000) { throw "too-many-entries" }',
        '  $total += $entry.Length',
        '  if ($total -gt 2147483648) { throw "too-large" }',
        '  $full = [IO.Path]::GetFullPath([IO.Path]::Combine($destFull, $entry.FullName))',
        '  if (-not $full.StartsWith($probe, [StringComparison]::OrdinalIgnoreCase)) { throw ("unsafe-entry: " + $entry.FullName) }',
        ' }',
        '} finally { $zip.Dispose() }',
        'if (Test-Path -LiteralPath $destFull) { Remove-Item -LiteralPath $destFull -Recurse -Force }',
        'New-Item -ItemType Directory -Path $destFull -Force | Out-Null',
        'Expand-Archive -LiteralPath $ZipPath -DestinationPath $destFull -Force',
        'Write-Output ("extracted:" + $count)'
    ].join('\n');

    // ------------------------------------------------------------------
    // 基础工具
    // ------------------------------------------------------------------

    function makeError(code, detail) {
        var error = new Error(code + (detail === undefined ? '' : (': ' + detail)));
        error.code = code;
        if (detail !== undefined) error.detail = detail;
        return error;
    }

    function stripBom(text) {
        return String(text || '').replace(/^\uFEFF/, '');
    }

    function parseVersion(text) {
        var value = String(text === undefined || text === null ? '' : text).trim();
        var match = /^v?(\d+)\.(\d+)(?:\.(\d+))?(?:\.(\d+))?$/i.exec(value);
        if (!match) return null;
        var parts = [Number(match[1]), Number(match[2]), Number(match[3] || 0), Number(match[4] || 0)];
        return { text: value, parts: parts };
    }

    function compareVersions(left, right) {
        var a = typeof left === 'string' ? parseVersion(left) : left;
        var b = typeof right === 'string' ? parseVersion(right) : right;
        if (!a && !b) return 0;
        if (!a) return -1;
        if (!b) return 1;
        for (var i = 0; i < Math.max(a.parts.length, b.parts.length); i++) {
            var x = a.parts[i] || 0;
            var y = b.parts[i] || 0;
            if (x > y) return 1;
            if (x < y) return -1;
        }
        return 0;
    }

    function isSafeRelativePath(relative) {
        if (typeof relative !== 'string' || !relative) return false;
        var value = relative.replace(/\\/g, '/');
        if (value.charAt(0) === '/') return false;
        if (/^[A-Za-z]:/.test(value)) return false;
        if (/(^|\/)\.\.?(\/|$)/.test(value)) return false;
        if (/(^|\/)save(\/|$)/i.test(value)) return false;
        if (/\.rpgsave$/i.test(value)) return false;
        return true;
    }

    function signatureUrlFor(channelUrl) {
        var value = String(channelUrl || '');
        if (/\.json(\?.*)?$/i.test(value)) return value.replace(/\.json(\?.*)?$/i, '.sig$1');
        return value + '.sig';
    }

    function normalizeVersionText(text) {
        var parsed = parseVersion(text);
        return parsed ? parsed.text : '';
    }

    function ensureDirectory(fs, path, directory) {
        if (fs.existsSync(directory)) return;
        ensureDirectory(fs, path, path.dirname(directory));
        try { fs.mkdirSync(directory); } catch (error) {
            if (!fs.existsSync(directory)) throw error;
        }
    }

    function removeDirectory(fs, path, target) {
        if (!fs.existsSync(target)) return;
        var stat;
        try { stat = fs.lstatSync(target); } catch (error) { return; }
        if (!stat.isDirectory()) { try { fs.unlinkSync(target); } catch (error) {} return; }
        var names = [];
        try { names = fs.readdirSync(target); } catch (error) { names = []; }
        for (var i = 0; i < names.length; i++) removeDirectory(fs, path, path.join(target, names[i]));
        try { fs.rmdirSync(target); } catch (error) {}
    }

    function readJsonFile(fs, file) {
        try {
            return JSON.parse(stripBom(fs.readFileSync(file, 'utf8')));
        } catch (error) {
            return null;
        }
    }

    function sha256File(fs, crypto, file) {
        var hash = crypto.createHash('sha256');
        var data = fs.readFileSync(file);
        hash.update(data);
        return hash.digest('hex');
    }

    // ------------------------------------------------------------------
    // 网络：HTTPS、重定向、超时、大小上限
    // ------------------------------------------------------------------

    function requestBuffer(urlText, options) {
        return new Promise(function (resolve, reject) {
            var parsed;
            try { parsed = new URL(urlText); } catch (error) { reject(makeError('bad-url', urlText)); return; }
            var transport = null;
            if (parsed.protocol === 'https:') transport = options.libs.https;
            else if (parsed.protocol === 'http:' && options.allowHttp) transport = options.libs.http;
            if (!transport) { reject(makeError('protocol-not-allowed', parsed.protocol)); return; }
            var settled = false;
            function fail(error) {
                if (settled) return;
                settled = true;
                reject(error);
            }
            var request = transport.get(parsed, {
                headers: {
                    'User-Agent': 'KyoContentUpdate/1',
                    'Cache-Control': 'no-cache',
                    'Accept': '*/*'
                }
            }, function (response) {
                var status = response.statusCode || 0;
                if (status >= 300 && status < 400) {
                    response.resume();
                    if (!response.headers.location) { fail(makeError('redirect-without-location', urlText)); return; }
                    if (!(options.redirectsLeft > 0)) { fail(makeError('too-many-redirects', urlText)); return; }
                    var next;
                    try { next = new URL(response.headers.location, parsed).toString(); } catch (error) { fail(makeError('bad-redirect', urlText)); return; }
                    var nextOptions = {};
                    for (var key in options) if (Object.prototype.hasOwnProperty.call(options, key)) nextOptions[key] = options[key];
                    nextOptions.redirectsLeft = options.redirectsLeft - 1;
                    requestBuffer(next, nextOptions).then(resolve, reject);
                    return;
                }
                if (status !== 200) { response.resume(); fail(makeError('http-status', status)); return; }
                var chunks = [];
                var size = 0;
                response.on('data', function (chunk) {
                    size += chunk.length;
                    if (size > options.maxBytes) { fail(makeError('response-too-large', size)); try { request.destroy(); } catch (error) {} return; }
                    chunks.push(chunk);
                });
                response.on('end', function () {
                    if (settled) return;
                    settled = true;
                    resolve(NodeBuffer.concat(chunks));
                });
                response.on('error', function (error) { fail(makeError('response-error', error.message)); });
            });
            request.on('error', function (error) { fail(makeError('request-error', error.message)); });
            request.setTimeout(options.timeoutMs, function () { fail(makeError('timeout', urlText)); try { request.destroy(); } catch (error) {} });
        });
    }

    function downloadFile(deps, urlText, targetPath) {
        return new Promise(function (resolve, reject) {
            var fs = deps.fs;
            var crypto = deps.crypto;
            var parsed;
            try { parsed = new URL(urlText); } catch (error) { reject(makeError('bad-url', urlText)); return; }
            var transport = null;
            if (parsed.protocol === 'https:') transport = deps.libs.https;
            else if (parsed.protocol === 'http:' && deps.config.allowHttp) transport = deps.libs.http;
            if (!transport) { reject(makeError('protocol-not-allowed', parsed.protocol)); return; }
            var settled = false;
            var hash = crypto.createHash('sha256');
            var received = 0;
            var stream = null;
            function cleanup() {
                try { if (stream) stream.destroy(); } catch (error) {}
                try { if (fs.existsSync(targetPath)) fs.unlinkSync(targetPath); } catch (error) {}
            }
            function fail(error) {
                if (settled) return;
                settled = true;
                cleanup();
                reject(error);
            }
            function start(currentUrl, redirectsLeft) {
                var current;
                try { current = new URL(currentUrl); } catch (error) { fail(makeError('bad-url', currentUrl)); return; }
                var lib = null;
                if (current.protocol === 'https:') lib = deps.libs.https;
                else if (current.protocol === 'http:' && deps.config.allowHttp) lib = deps.libs.http;
                if (!lib) { fail(makeError('protocol-not-allowed', current.protocol)); return; }
                var request = lib.get(current, {
                    headers: {
                        'User-Agent': 'KyoContentUpdate/1',
                        'Cache-Control': 'no-cache',
                        'Accept': '*/*'
                    }
                }, function (response) {
                    var status = response.statusCode || 0;
                    if (status >= 300 && status < 400) {
                        response.resume();
                        if (!response.headers.location) { fail(makeError('redirect-without-location', currentUrl)); return; }
                        if (!(redirectsLeft > 0)) { fail(makeError('too-many-redirects', currentUrl)); return; }
                        var next;
                        try { next = new URL(response.headers.location, current).toString(); } catch (error) { fail(makeError('bad-redirect', currentUrl)); return; }
                        start(next, redirectsLeft - 1);
                        return;
                    }
                    if (status !== 200) { response.resume(); fail(makeError('http-status', status)); return; }
                    stream = fs.createWriteStream(targetPath);
                    stream.on('error', function (error) { fail(makeError('write-error', error.message)); });
                    response.on('data', function (chunk) {
                        received += chunk.length;
                        if (received > deps.config.downloadMaxBytes) { fail(makeError('download-too-large', received)); return; }
                        hash.update(chunk);
                        try {
                            if (!stream.write(chunk)) response.pause();
                        } catch (error) { fail(makeError('write-error', error.message)); return; }
                        if (deps.onProgress) { try { deps.onProgress(received, deps.expectedBytes || 0); } catch (error) {} }
                    });
                    stream.on('drain', function () { try { response.resume(); } catch (error) {} });
                    response.on('end', function () {
                        if (settled) return;
                        try {
                            stream.end(function () {
                                if (settled) return;
                                var digest = hash.digest('hex');
                                if (deps.expectedBytes && received !== deps.expectedBytes) { fail(makeError('bytes-mismatch', received + ' != ' + deps.expectedBytes)); return; }
                                if (deps.expectedSHA256 && digest.toLowerCase() !== String(deps.expectedSHA256).toLowerCase()) { fail(makeError('sha256-mismatch', digest)); return; }
                                settled = true;
                                resolve({ bytes: received, sha256: digest });
                            });
                        } catch (error) { fail(makeError('write-error', error.message)); }
                    });
                    response.on('error', function (error) { fail(makeError('response-error', error.message)); });
                });
                request.on('error', function (error) { fail(makeError('request-error', error.message)); });
                request.setTimeout(deps.config.timeoutMs, function () { fail(makeError('timeout', currentUrl)); try { request.destroy(); } catch (error) {} });
            }
            start(urlText, deps.config.redirectLimit);
        });
    }

    // ------------------------------------------------------------------
    // 更新通道校验
    // ------------------------------------------------------------------

    function verifyChannelBytes(crypto, channelBytes, signatureBytes) {
        if (!channelBytes || !channelBytes.length) throw makeError('channel-empty');
        if (!signatureBytes || !signatureBytes.length) throw makeError('signature-empty');
        var verifier = crypto.createVerify('RSA-SHA256');
        verifier.update(channelBytes);
        verifier.end();
        var ok = false;
        try {
            ok = verifier.verify(PUBLIC_KEY_PEM, signatureBytes);
        } catch (error) {
            throw makeError('signature-invalid', error.message);
        }
        if (!ok) throw makeError('signature-invalid');
    }

    function validateChannel(channel) {
        if (!channel || typeof channel !== 'object') throw makeError('channel-not-object');
        if (channel.format !== FORMAT) throw makeError('channel-format', channel.format);
        if (channel.platform !== 'windows') throw makeError('channel-platform', channel.platform);
        if (!parseVersion(channel.releaseVersion)) throw makeError('channel-version', channel.releaseVersion);
        if (!(typeof channel.releaseNumber === 'number' && isFinite(channel.releaseNumber) && channel.releaseNumber >= 0)) throw makeError('channel-release-number', channel.releaseNumber);
        if (typeof channel.url !== 'string' || !/^https:\/\//i.test(channel.url)) throw makeError('channel-url-not-https', channel.url);
        if (typeof channel.sha256 !== 'string' || !/^[0-9a-f]{64}$/i.test(channel.sha256)) throw makeError('channel-sha256', channel.sha256);
        if (!(typeof channel.bytes === 'number' && isFinite(channel.bytes) && channel.bytes > 0)) throw makeError('channel-bytes', channel.bytes);
        if (channel.notes !== undefined && typeof channel.notes !== 'string') throw makeError('channel-notes');
        if (channel.mirrors !== undefined) {
            if (!Array.isArray(channel.mirrors)) throw makeError('channel-mirrors');
            for (var m = 0; m < channel.mirrors.length; m++) {
                if (typeof channel.mirrors[m] !== 'string' || !/^https:\/\//i.test(channel.mirrors[m])) throw makeError('channel-mirror-not-https', channel.mirrors[m]);
            }
        }
        if (channel.packageType !== undefined && ['cumulative', 'single'].indexOf(channel.packageType) < 0) throw makeError('channel-package-type', channel.packageType);
        if (channel.minHostVersion !== undefined && !parseVersion(channel.minHostVersion)) throw makeError('channel-min-host-version', channel.minHostVersion);
        return channel;
    }

    // ------------------------------------------------------------------
    // 更新器主体
    // ------------------------------------------------------------------

    function create(overrides) {
        overrides = overrides || {};
        var nodeRequire = overrides.require || require;
        var fs = overrides.fs || nodeRequire('fs');
        var path = overrides.path || nodeRequire('path');
        var os = overrides.os || nodeRequire('os');
        var crypto = overrides.crypto || nodeRequire('crypto');
        var childProcess = overrides.childProcess || nodeRequire('child_process');
        var libs = {
            https: overrides.https || nodeRequire('https'),
            http: overrides.http || nodeRequire('http')
        };
        var environment = overrides.env || (typeof process !== 'undefined' && process.env ? process.env : {});
        var platform = overrides.platform || (typeof process !== 'undefined' ? process.platform : 'win32');

        var config = {};
        for (var key in DEFAULT_CONFIG) if (Object.prototype.hasOwnProperty.call(DEFAULT_CONFIG, key)) config[key] = DEFAULT_CONFIG[key];
        if (overrides.config) for (var overridden in overrides.config) if (Object.prototype.hasOwnProperty.call(overrides.config, overridden)) config[overridden] = overrides.config[overridden];
        if (environment.KYO_UPDATE_CHANNEL_URL) {
            config.channelUrl = environment.KYO_UPDATE_CHANNEL_URL;
            config.channelUrls = [environment.KYO_UPDATE_CHANNEL_URL];
        }
        if (environment.KYO_DISABLE_AUTO_UPDATE === '1') config.disableAuto = true;
        if (environment.KYO_UPDATE_ALLOW_HTTP === '1') config.allowHttp = true;

        var root = overrides.root || (global.WindowsPort && global.WindowsPort.root) || path.join(environment.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'), '再刷一把 1.57');
        var bundle = overrides.bundle || (global.WindowsPort && global.WindowsPort.bundle) || '';
        var execPath = overrides.execPath || (typeof process !== 'undefined' ? process.execPath : '');
        var gameDir = overrides.gameDir || '';
        if (!gameDir && bundle) gameDir = detectGameDir(fs, path, bundle);
        if (!gameDir && execPath) gameDir = path.dirname(execPath);
        var gameExe = overrides.gameExe || '';
        if (!gameExe && execPath && /game\.exe$/i.test(execPath)) gameExe = execPath;
        if (!gameExe && gameDir) gameExe = path.join(gameDir, 'Game.exe');
        var pid = overrides.pid !== undefined ? overrides.pid : (typeof process !== 'undefined' ? process.pid : 0);

        function log(kind, value) {
            try {
                var logs = path.join(root, 'logs');
                ensureDirectory(fs, path, logs);
                fs.appendFileSync(path.join(logs, 'update.log'), JSON.stringify({ time: new Date().toISOString(), kind: kind, value: value }) + '\n');
            } catch (error) {}
        }

        function readPrefs() {
            return readJsonFile(fs, path.join(root, 'update-preferences.json')) || {};
        }

        function writePrefs(prefs) {
            try {
                ensureDirectory(fs, path, root);
                fs.writeFileSync(path.join(root, 'update-preferences.json'), JSON.stringify(prefs, null, 2));
            } catch (error) {}
        }

        function readCurrentVersion() {
            var contentVersion = bundle ? readJsonFile(fs, path.join(bundle, 'data', 'ContentVersion.json')) : null;
            if (contentVersion && contentVersion.releaseVersion) {
                return { releaseVersion: normalizeVersionText(contentVersion.releaseVersion), releaseNumber: contentVersion.releaseNumber };
            }
            var launcherFiles = [gameDir ? path.join(gameDir, 'package.json') : '', bundle ? path.join(bundle, 'package.json') : ''];
            for (var i = 0; i < launcherFiles.length; i++) {
                if (!launcherFiles[i]) continue;
                var launcher = readJsonFile(fs, launcherFiles[i]);
                if (launcher && launcher.releaseVersion) {
                    return { releaseVersion: normalizeVersionText(launcher.releaseVersion), releaseNumber: launcher.releaseNumber };
                }
            }
            return { releaseVersion: 'v0.0', releaseNumber: 0 };
        }

        function channelTransportOptions() {
            return { allowHttp: config.allowHttp, timeoutMs: config.timeoutMs, maxBytes: config.channelMaxBytes, redirectsLeft: config.redirectLimit, libs: libs };
        }

        function channelCandidates() {
            var values = [];
            if (Array.isArray(config.channelUrls)) values = config.channelUrls.slice();
            if (config.channelUrl && values.indexOf(config.channelUrl) < 0) values.push(config.channelUrl);
            return values.filter(function (value) {
                return typeof value === 'string' && /^https?:\/\//i.test(value);
            });
        }

        function fetchChannel() {
            var candidates = channelCandidates();
            if (!candidates.length) return Promise.reject(makeError('channel-not-configured'));
            function attempt(index, best, lastError) {
                if (index >= candidates.length) {
                    if (!best) return Promise.reject(lastError || makeError('channel-unavailable'));
                    log('update-channel-source', best.url);
                    return Promise.resolve(best.channel);
                }
                var url = candidates[index];
                return requestBuffer(url, channelTransportOptions()).then(function (channelBytes) {
                    return requestBuffer(signatureUrlFor(url), channelTransportOptions()).then(function (signatureBytes) {
                        verifyChannelBytes(crypto, channelBytes, signatureBytes);
                        var channel;
                        try { channel = JSON.parse(stripBom(channelBytes.toString('utf8'))); } catch (error) { throw makeError('channel-json-invalid'); }
                        channel = validateChannel(channel);
                        if (!best || compareVersions(best.channel.releaseVersion, channel.releaseVersion) < 0) {
                            best = { channel: channel, url: url };
                        }
                    });
                }).catch(function (error) {
                    lastError = error;
                    log('update-channel-source-error', { url: url, error: String(error && (error.code ? error.code + ': ' : '') + (error.message || error)) });
                }).then(function () { return attempt(index + 1, best, lastError); });
            }
            return attempt(0, null, null);
        }

        function check(force) {
            force = !!force;
            if (!force && config.disableAuto) {
                log('update-check-disabled', 'auto');
                return Promise.resolve({ status: 'disabled' });
            }
            var candidates = channelCandidates();
            if (!candidates.length) {
                log('update-check-skip', 'channel-not-configured');
                return Promise.resolve({ status: 'not-configured' });
            }
            log('update-check-start', candidates.join(' '));
            return fetchChannel().then(function (channel) {
                var current = readCurrentVersion();
                log('update-channel-ok', { current: current.releaseVersion, latest: channel.releaseVersion });
                if (channel.minHostVersion && compareVersions(current.releaseVersion, channel.minHostVersion) < 0) {
                    log('update-unsupported', { current: current.releaseVersion, minHostVersion: channel.minHostVersion });
                    return { status: 'unsupported', channel: channel, current: current };
                }
                if (compareVersions(channel.releaseVersion, current.releaseVersion) <= 0) {
                    return { status: 'latest', channel: channel, current: current };
                }
                if (!force) {
                    var prefs = readPrefs();
                    if (prefs.skippedVersion && compareVersions(prefs.skippedVersion, channel.releaseVersion) === 0) {
                        log('update-prompt-skipped', channel.releaseVersion);
                        return { status: 'skipped', channel: channel, current: current };
                    }
                }
                return { status: 'new', channel: channel, current: current };
            }).catch(function (error) {
                log('update-check-error', String(error && (error.code ? error.code + ': ' : '') + (error.message || error)));
                return { status: 'error', error: error };
            });
        }

        function skipVersion(version) {
            var prefs = readPrefs();
            prefs.skippedVersion = version;
            prefs.skippedAt = new Date().toISOString();
            writePrefs(prefs);
        }

        function resolvePowerShell() {
            if (overrides.psPath) return overrides.psPath;
            if (environment.KYO_UPDATE_PWSH) return environment.KYO_UPDATE_PWSH;
            if (platform === 'win32') {
                var systemRoot = environment.SystemRoot || environment.windir || 'C:\\Windows';
                return path.join(systemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
            }
            return 'pwsh';
        }

        function writePowerShellScript(file, script) {
            ensureDirectory(fs, path, path.dirname(file));
            fs.writeFileSync(file, '\uFEFF' + script, 'utf8');
        }

        function runPowerShell(scriptPath, args, timeoutMs) {
            return new Promise(function (resolve, reject) {
                var command = resolvePowerShell();
                var baseArgs = ['-NoLogo', '-NoProfile', '-ExecutionPolicy', 'Bypass'];
                baseArgs = baseArgs.concat(['-File', scriptPath], args);
                childProcess.execFile(command, baseArgs, { windowsHide: true, timeout: timeoutMs || (5 * 60 * 1000), maxBuffer: 8 * 1024 * 1024 }, function (error, stdout, stderr) {
                    if (error) {
                        var wrapped = makeError('powershell-failed', (error.message || '') + ' ' + String(stderr || '').slice(-500));
                        wrapped.stdout = String(stdout || '');
                        wrapped.stderr = String(stderr || '');
                        reject(wrapped);
                        return;
                    }
                    resolve({ stdout: String(stdout || ''), stderr: String(stderr || '') });
                });
            });
        }

        function extractPackage(zipPath, stagingDir) {
            var scriptPath = path.join(root, 'updates', 'extract-zip.ps1');
            writePowerShellScript(scriptPath, EXTRACT_SCRIPT);
            return runPowerShell(scriptPath, ['-ZipPath', zipPath, '-DestDir', stagingDir], 10 * 60 * 1000).then(function (result) {
                var match = /extracted:(\d+)/.exec(result.stdout || '');
                if (!match) throw makeError('extract-output', String(result.stdout || '').slice(-300));
                return { entries: Number(match[1]), stagingDir: stagingDir };
            });
        }

        function verifyPackage(stagingDir, channel) {
            var manifestPath = path.join(stagingDir, '更新清单.json');
            if (!fs.existsSync(manifestPath)) throw makeError('manifest-missing');
            var manifest = readJsonFile(fs, manifestPath);
            if (!manifest || !Array.isArray(manifest.files) || manifest.files.length === 0) throw makeError('manifest-empty');
            if (manifest.platform && String(manifest.platform).toLowerCase() !== 'windows') throw makeError('manifest-platform', manifest.platform);
            var manifestVersion = manifest.releaseVersion || manifest.version;
            if (compareVersions(manifestVersion, channel.releaseVersion) !== 0) throw makeError('manifest-version-mismatch', manifestVersion + ' != ' + channel.releaseVersion);
            var payloadRoot = path.join(stagingDir, '更新文件');
            var fileCount = 0;
            for (var i = 0; i < manifest.files.length; i++) {
                var entry = manifest.files[i] || {};
                if (!isSafeRelativePath(entry.path)) throw makeError('manifest-unsafe-path', entry.path);
                if (typeof entry.after !== 'string' || !/^[0-9a-f]{64}$/i.test(entry.after)) throw makeError('manifest-after-invalid', entry.path);
                var source = path.join(payloadRoot, entry.path);
                if (!fs.existsSync(source) || !fs.statSync(source).isFile()) throw makeError('payload-missing', entry.path);
                var actual = sha256File(fs, crypto, source);
                if (actual.toLowerCase() !== entry.after.toLowerCase()) throw makeError('payload-sha256-mismatch', entry.path);
                fileCount++;
            }
            if (!fs.existsSync(path.join(stagingDir, 'InstallUpdate.ps1'))) throw makeError('installer-missing');
            return { files: fileCount, manifest: manifest };
        }

        function spawnRunner(stagingDir, channel) {
            var updatesDir = path.join(root, 'updates');
            ensureDirectory(fs, path, updatesDir);
            ensureDirectory(fs, path, path.join(root, 'logs'));
            var runnerPath = path.join(updatesDir, 'runner.ps1');
            writePowerShellScript(runnerPath, RUNNER_SCRIPT);
            var logPath = path.join(root, 'logs', 'update.log');
            var command = resolvePowerShell();
            var args = ['-NoLogo', '-NoProfile', '-ExecutionPolicy', 'Bypass'];
            args = args.concat([
                '-File', runnerPath,
                '-PackageDir', stagingDir,
                '-GameDir', gameDir,
                '-GameExe', gameExe,
                '-GamePid', String(pid),
                '-LogPath', logPath
            ]);
            if (overrides.installerCmd) args = args.concat(['-InstallerCmd', overrides.installerCmd]);
            if (overrides.gameProcessName) args = args.concat(['-GameProcessName', overrides.gameProcessName]);
            if (overrides.waitTimeoutSeconds) args = args.concat(['-WaitTimeoutSeconds', String(overrides.waitTimeoutSeconds)]);
            if (overrides.skipLaunch) args.push('-SkipLaunch');
            var spawn = overrides.spawn || childProcess.spawn;
            var child = spawn(command, args, { detached: true, stdio: 'ignore', windowsHide: false, cwd: updatesDir });
            if (child && typeof child.unref === 'function') child.unref();
            return { runnerPath: runnerPath, logPath: logPath, powershell: command, childPid: child && child.pid };
        }

        function quit() {
            if (overrides.quit) { overrides.quit(); return; }
            try {
                if (global.nw && global.nw.App && typeof global.nw.App.quit === 'function') { global.nw.App.quit(); return; }
            } catch (error) {}
            try { global.close(); } catch (error) {}
        }

        function install(channel, hooks) {
            hooks = hooks || {};
            var onStatus = hooks.onStatus || function () {};
            var updatesDir = path.join(root, 'updates');
            var safeVersion = String(channel.releaseVersion || 'update').replace(/[^0-9A-Za-z._-]/g, '_');
            var zipPath = path.join(updatesDir, safeVersion + '.zip');
            var partPath = zipPath + '.part';
            var stagingDir = path.join(updatesDir, 'staging-' + safeVersion);
            ensureDirectory(fs, path, updatesDir);
            removeDirectory(fs, path, stagingDir);
            try { if (fs.existsSync(partPath)) fs.unlinkSync(partPath); } catch (error) {}
            log('update-install-start', { version: channel.releaseVersion, url: channel.url, bytes: channel.bytes });
            var downloadOptions = {
                config: config,
                libs: libs,
                fs: fs,
                crypto: crypto,
                expectedBytes: channel.bytes,
                expectedSHA256: channel.sha256,
                onProgress: function (received, total) {
                    if (hooks.onProgress) { try { hooks.onProgress(received, total); } catch (error) {} }
                }
            };
            onStatus('正在下载更新…');
            // 主地址下载失败时依次换备用地址；每个地址都按通道里的 SHA256 和字节数校验。
            var downloadUrls = [channel.url].concat((channel.mirrors || []).filter(function (value) { return value !== channel.url; }));
            function downloadFrom(index, lastError) {
                if (index >= downloadUrls.length) return Promise.reject(lastError || makeError('download-failed'));
                try { if (fs.existsSync(partPath)) fs.unlinkSync(partPath); } catch (error) {}
                return downloadFile(downloadOptions, downloadUrls[index], partPath).catch(function (error) {
                    log('update-download-source-failed', { url: downloadUrls[index], error: String(error && (error.code || error.message) || error) });
                    return downloadFrom(index + 1, error);
                });
            }
            return downloadFrom(0, null).then(function (info) {
                try {
                    if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);
                    fs.renameSync(partPath, zipPath);
                } catch (error) {
                    throw makeError('rename-failed', error.message);
                }
                log('update-download-ok', info);
                onStatus('正在解压更新包…');
                return extractPackage(zipPath, stagingDir);
            }).then(function (extractInfo) {
                log('update-extract-ok', extractInfo);
                onStatus('正在校验更新包…');
                var verified = verifyPackage(stagingDir, channel);
                log('update-verify-ok', { files: verified.files });
                onStatus('正在准备安装…');
                var runner = spawnRunner(stagingDir, channel);
                log('update-runner-spawned', { runner: runner.runnerPath, pid: runner.childPid });
                try { if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath); } catch (error) {}
                return { ok: true, channel: channel, stagingDir: stagingDir, runner: runner, verified: verified };
            }).catch(function (error) {
                log('update-install-error', String(error && (error.code ? error.code + ': ' : '') + (error.message || error)));
                try { if (fs.existsSync(partPath)) fs.unlinkSync(partPath); } catch (inner) {}
                removeDirectory(fs, path, stagingDir);
                throw error;
            });
        }

        return {
            config: config,
            root: root,
            bundle: bundle,
            gameDir: gameDir,
            gameExe: gameExe,
            pid: pid,
            log: log,
            readCurrentVersion: readCurrentVersion,
            check: check,
            install: install,
            skipVersion: skipVersion,
            readPrefs: readPrefs,
            quit: quit,
            verifyPackage: verifyPackage,
            resolvePowerShell: resolvePowerShell
        };
    }

    function detectGameDir(fs, path, bundle) {
        var directory = bundle;
        for (var i = 0; i < 5; i++) {
            if (fs.existsSync(path.join(directory, 'Game.exe'))) return directory;
            var parent = path.dirname(directory);
            if (!parent || parent === directory) break;
            directory = parent;
        }
        return '';
    }

    // ------------------------------------------------------------------
    // 游戏内界面：标题界面入口 + 更新提示 + 进度提示
    // ------------------------------------------------------------------

    function createUI(updater, gui) {
        gui = gui || {};
        var state = { promptOpen: false, busy: false, autoScheduled: false, installed: false };
        var SceneManager = gui.SceneManager;
        var Graphics = gui.Graphics;
        var Window_Base = gui.Window_Base;
        var Window_Command = gui.Window_Command;
        var Window_TitleCommand = gui.Window_TitleCommand;
        var Scene_Title = gui.Scene_Title;
        var setTimeoutFn = gui.setTimeout || setTimeout;

        function boxWidth() { return Graphics.boxWidth || 1280; }
        function boxHeight() { return Graphics.boxHeight || 720; }

        function fontBitmap() { return null; }

        function wrapText(bitmap, text, maxWidth) {
            var source = String(text || '').replace(/\r\n?/g, '\n');
            var paragraphs = source.split('\n');
            var lines = [];
            for (var p = 0; p < paragraphs.length; p++) {
                var paragraph = paragraphs[p];
                if (paragraph === '') { lines.push(''); continue; }
                var current = '';
                for (var i = 0; i < paragraph.length; i++) {
                    var next = current + paragraph.charAt(i);
                    if (bitmap && current && bitmap.measureTextWidth(next) > maxWidth) {
                        lines.push(current);
                        current = paragraph.charAt(i);
                    } else {
                        current = next;
                    }
                }
                if (current) lines.push(current);
            }
            return lines;
        }

        function titleCommandWindow(scene) {
            return scene && scene._commandWindow ? scene._commandWindow : null;
        }

        function closeWindow(scene, win) {
            if (!win) return;
            try { win.close(); } catch (error) {}
            try { win.deactivate(); } catch (error) {}
        }

        function reopenTitleCommand(scene) {
            var win = titleCommandWindow(scene);
            if (!win) return;
            try { win.open(); win.activate(); win.select(0); } catch (error) {}
        }

        function makeWindowClass(basePrototype) {
            function Window() { this.initialize.apply(this, arguments); }
            Window.prototype = Object.create(basePrototype);
            Window.prototype.constructor = Window;
            return Window;
        }

        var UpdateInfoWindow = makeWindowClass(Window_Base.prototype);
        UpdateInfoWindow.prototype.initialize = function (heading, subtitle, notes) {
            var width = Math.min(800, boxWidth() - 80);
            var x = (boxWidth() - width) / 2;
            var y = Math.max(40, (boxHeight() - 300) / 2 - 80);
            Window_Base.prototype.initialize.call(this, x, y, width, 300);
            this._heading = heading;
            this._subtitle = subtitle || '';
            this._notes = notes || '';
            this.refresh();
        };
        UpdateInfoWindow.prototype.refresh = function () {
            this.contents.clear();
            var left = 0;
            var width = this.contentsWidth();
            this.contents.fontSize = 26;
            this.changeTextColor(this.textColor(6));
            this.drawText(this._heading, left, 4, width, 36, 'left');
            this.contents.fontSize = 20;
            this.changeTextColor(this.normalColor());
            if (this._subtitle) this.drawText(this._subtitle, left, 44, width, 28, 'left');
            var lines = wrapText(this.contents, this._notes, width);
            var maxLines = 6;
            if (lines.length > maxLines) { lines = lines.slice(0, maxLines); lines[maxLines - 1] = lines[maxLines - 1] + '……'; }
            this.contents.fontSize = 22;
            for (var i = 0; i < lines.length; i++) {
                this.drawText(lines[i], left, 82 + i * 30, width, 28, 'left');
            }
            this.resetTextColor();
        };

        var UpdateChoiceWindow = makeWindowClass(Window_Command.prototype);
        UpdateChoiceWindow.prototype.initialize = function (y) {
            this._kyoNames = ['立即更新', '以后再说'];
            this._kyoSymbols = ['updateNow', 'later'];
            Window_Command.prototype.initialize.call(this, (boxWidth() - this.windowWidth()) / 2, y);
            this.select(1);
        };
        UpdateChoiceWindow.prototype.windowWidth = function () { return 320; };
        UpdateChoiceWindow.prototype.makeCommandList = function () {
            for (var i = 0; i < this._kyoNames.length; i++) this.addCommand(this._kyoNames[i], this._kyoSymbols[i], true);
        };

        var UpdateStatusWindow = makeWindowClass(Window_Base.prototype);
        UpdateStatusWindow.prototype.initialize = function () {
            var width = Math.min(660, boxWidth() - 80);
            var height = 150;
            Window_Base.prototype.initialize.call(this, (boxWidth() - width) / 2, (boxHeight() - height) / 2, width, height);
            this._lines = [];
            this.refresh();
        };
        UpdateStatusWindow.prototype.setText = function (lines) {
            this._lines = lines || [];
            this.refresh();
        };
        UpdateStatusWindow.prototype.refresh = function () {
            if (!this.contents) return;
            this.contents.clear();
            this.contents.fontSize = 22;
            for (var i = 0; i < this._lines.length; i++) {
                this.drawText(this._lines[i], 0, 18 + i * 36, this.contentsWidth(), 32, 'center');
            }
        };

        function addWindow(scene, win) {
            scene.addWindow(win);
            win.open();
            return win;
        }

        function showMessage(scene, lines, after) {
            if (!scene || !Window_Base) return;
            var message = new UpdateInfoWindow(lines[0] || '', '', lines.slice(1).join('\n'));
            addWindow(scene, message);
            setTimeoutFn(function () {
                closeWindow(scene, message);
                if (after) after();
            }, 2600);
        }

        function showPrompt(scene, result) {
            if (!scene || state.promptOpen || state.busy) return;
            state.promptOpen = true;
            closeWindow(scene, titleCommandWindow(scene));
            var heading = result.channel.releaseVersion + ' 更新说明';
            var subtitle = '当前版本 ' + result.current.releaseVersion + '　→　新版本 ' + result.channel.releaseVersion;
            var info = addWindow(scene, new UpdateInfoWindow(heading, subtitle, result.channel.notes || ''));
            var choice = addWindow(scene, new UpdateChoiceWindow(info.y + info.height + 12));
            choice.setHandler('updateNow', function () {
                state.promptOpen = false;
                closeWindow(scene, info);
                closeWindow(scene, choice);
                runInstall(scene, result);
            });
            choice.setHandler('later', function () {
                state.promptOpen = false;
                updater.skipVersion(result.channel.releaseVersion);
                closeWindow(scene, info);
                closeWindow(scene, choice);
                reopenTitleCommand(scene);
            });
            choice.activate();
        }

        function runInstall(scene, result) {
            if (state.busy) return;
            state.busy = true;
            var status = addWindow(scene, new UpdateStatusWindow());
            status.setText(['正在下载更新…']);
            function setStatus(lines) { try { status.setText(lines); } catch (error) {} }
            updater.install(result.channel, {
                onStatus: function (text) { setStatus([text]); }
            }).then(function () {
                setStatus(['更新包已准备完成。', '游戏将退出并自动安装，完成后会重新启动。']);
                setTimeoutFn(function () { updater.quit(); }, updater.config.quitDelayMs);
            }).catch(function (error) {
                state.busy = false;
                closeWindow(scene, status);
                showMessage(SceneManager._scene || scene, ['更新未完成，游戏内容没有变化。', '请检查网络后重试；详细信息见 logs/update.log。'], function () {
                    reopenTitleCommand(SceneManager._scene || scene);
                });
            });
        }

        function manualCheck(scene) {
            if (state.busy) return;
            state.busy = true;
            closeWindow(scene, titleCommandWindow(scene));
            var status = addWindow(scene, new UpdateStatusWindow());
            status.setText(['正在检查更新…']);
            updater.check(true).then(function (result) {
                state.busy = false;
                closeWindow(scene, status);
                if (result.status === 'new') {
                    showPrompt(SceneManager._scene || scene, result);
                    return;
                }
                var lines;
                if (result.status === 'latest') lines = ['当前已是最新版本（' + result.current.releaseVersion + '）。'];
                else if (result.status === 'unsupported') lines = ['当前版本过低，请按更新说明手动升级到 ' + result.channel.minHostVersion + ' 或更新版本。'];
                else if (result.status === 'not-configured' || result.status === 'disabled') lines = ['当前版本未配置更新通道。'];
                else lines = ['暂时无法检查更新，请稍后重试。'];
                showMessage(SceneManager._scene || scene, lines, function () { reopenTitleCommand(SceneManager._scene || scene); });
            }).catch(function () {
                state.busy = false;
                closeWindow(scene, status);
                showMessage(SceneManager._scene || scene, ['暂时无法检查更新，请稍后重试。'], function () { reopenTitleCommand(SceneManager._scene || scene); });
            });
        }

        function scheduleAutoCheck(scene) {
            if (state.autoScheduled) return;
            state.autoScheduled = true;
            setTimeoutFn(function () {
                if (state.busy || state.promptOpen || state.installed) return;
                updater.check(false).then(function (result) {
                    if (result.status !== 'new') return;
                    if (!SceneManager._scene || !(SceneManager._scene instanceof Scene_Title)) return;
                    showPrompt(SceneManager._scene, result);
                }).catch(function () {});
            }, updater.config.autoCheckDelayMs);
        }

        function patchTitleCommand() {
            if (!Window_TitleCommand || Window_TitleCommand._kyoUpdateEntry) return;
            var original = Window_TitleCommand.prototype.makeCommandList;
            Window_TitleCommand.prototype.makeCommandList = function () {
                original.apply(this, arguments);
                try {
                    this.addCommand('检查更新', 'kyoCheckUpdate', true);
                } catch (error) {}
            };
            Window_TitleCommand._kyoUpdateEntry = true;
        }

        function patchSceneTitle() {
            if (!Scene_Title || Scene_Title._kyoUpdatePatched) return;
            var originalCreate = Scene_Title.prototype.createCommandWindow;
            Scene_Title.prototype.createCommandWindow = function () {
                originalCreate.apply(this, arguments);
                if (this._commandWindow) this._commandWindow.setHandler('kyoCheckUpdate', this.commandKyoCheckUpdate.bind(this));
            };
            Scene_Title.prototype.commandKyoCheckUpdate = function () { manualCheck(this); };
            var originalStart = Scene_Title.prototype.start;
            Scene_Title.prototype.start = function () {
                originalStart.apply(this, arguments);
                scheduleAutoCheck(this);
            };
            Scene_Title._kyoUpdatePatched = true;
        }

        function installPatches() {
            var attempts = 0;
            function attempt() {
                attempts++;
                if (Window_TitleCommand && Scene_Title) {
                    patchTitleCommand();
                    patchSceneTitle();
                    return;
                }
                if (attempts < 200) setTimeoutFn(attempt, 100);
            }
            attempt();
        }

        return {
            install: installPatches,
            showPrompt: showPrompt,
            manualCheck: manualCheck,
            scheduleAutoCheck: scheduleAutoCheck,
            state: state
        };
    }

    // ------------------------------------------------------------------
    // 导出与自动启动
    // ------------------------------------------------------------------

    var exported = {
        create: create,
        createUI: createUI,
        parseVersion: parseVersion,
        compareVersions: compareVersions,
        validateChannel: validateChannel,
        verifyChannelBytes: verifyChannelBytes,
        signatureUrlFor: signatureUrlFor,
        isSafeRelativePath: isSafeRelativePath,
        detectGameDir: detectGameDir,
        PUBLIC_KEY_PEM: PUBLIC_KEY_PEM,
        CHANNEL_FORMAT: FORMAT,
        DEFAULT_CONFIG: DEFAULT_CONFIG,
        RUNNER_SCRIPT: RUNNER_SCRIPT,
        EXTRACT_SCRIPT: EXTRACT_SCRIPT
    };
    if (typeof module !== 'undefined' && module.exports) module.exports = exported;

    function boot() {
        try {
            if (!global.Scene_Title || !global.Window_TitleCommand || !global.SceneManager) return false;
            var updater = create();
            var ui = createUI(updater, global);
            updater.ui = ui;
            global.KyoContentUpdate = {
                check: function (force) { return updater.check(force); },
                currentVersion: updater.readCurrentVersion,
                config: updater.config
            };
            ui.install();
            return true;
        } catch (error) {
            try { if (global.WindowsPort && global.WindowsPort.log) global.WindowsPort.log('update-boot-error', String(error && error.stack || error)); } catch (inner) {}
            return false;
        }
    }

    var isGameContext = typeof window !== 'undefined' && typeof document !== 'undefined' &&
        typeof require === 'function' && typeof process !== 'undefined' && process.versions && process.versions.nw;
    if (isGameContext) {
        if (typeof process.env.KYO_UPDATE_NO_BOOT !== 'undefined' && process.env.KYO_UPDATE_NO_BOOT === '1') {
            // 仅供隔离测试：不自动安装界面钩子。
        } else if (document.readyState === 'complete') {
            boot();
        } else {
            window.addEventListener('load', function () { boot(); });
        }
    }
})(typeof window !== 'undefined' ? window : (typeof global !== 'undefined' ? global : this));
