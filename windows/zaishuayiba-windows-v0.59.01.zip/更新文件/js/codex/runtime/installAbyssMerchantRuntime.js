// 【Codex·未经Claude检验】v0.36：1／35／60级吸取槽位、定槽替换与旧档兼容。
// 【Codex·未经Claude检验】v0.35：吸取替换归一到真实独立实例，兼容全角特效标签。
// 【Codex·未经Claude检验】v0.30 深渊／不朽商人及单条特效吸取；未经claude检验。
window.CodexRuntime.register('installAbyssMerchantRuntime',function(){
 'use strict';
 var W=window,M=W.CodexAbyssMerchant={version:30,categories:['mod','mythic','chaos'],labels:['Mod特效','神话特效','混沌神话特效']},battle=null;
 DataManager._databaseFiles.push({name:'$dataCodexMerchants',src:'CodexMerchants.json'});
 function alias(o,k,fn){var old=o[k];if(typeof old==='function')o[k]=function(){return fn.call(this,old,arguments);};}
 function C(){return W.$dataCodexMerchants;}
 function clone(x){return JSON.parse(JSON.stringify(x));}
 function item(d){return d&&W['$data'+d.db]&&W['$data'+d.db][d.id];}
 function base(i){return Number(i&&(i.originalBaseItemId||i.baseItemId||i.id));}
 function msg(t){if(W.$&&$.toaster)$.toaster({message:t});}
 function ledger(){return $gameSystem._codexMerchants29||($gameSystem._codexMerchants29={sequence:0,balances:{},misses:{}});}
 function route(){return C()&&C().routes[String($gameMap.mapId())];}
 function isUnknown(){return !!(W.CodexYunshang&&CodexYunshang.config.unknownBattles[$gameMap.mapId()]);}
 function identity(){
  var id=$gameMap.mapId(),origin=$gameMap._yunUnknownOrigin;if(origin==null)origin=$gameMap._codexLeviathanUnknownOrigin;
  var unknown=isUnknown(),immortal=unknown&&W.CodexYunshang&&CodexYunshang.isImmortalClear();
  // Unknown maps shared by different source dungeons must retain their actual origin.
  return {key:(immortal?'immortal:':'abyss:')+id+(unknown?':from:'+String(origin==null?'legacy-'+$gameVariables.value(107):origin):''),kind:immortal?'不朽商人':'深渊商人',map:id};
 }
 alias(Game_Map.prototype,'setup',function(old,args){var out=old.apply(this,args);if(C()&&C().routes[String(args[0])]){var l=ledger();this._merchantRun29={sequence:++l.sequence,claimed:false,appeared:false,used:0,seed:Math.floor(Math.random()*0x7fffffff)};}else this._merchantRun29=null;return out;});
 alias(BattleManager,'startBattle',function(old,args){var out=old.apply(this,args),r=route();battle=r?{map:$gameMap.mapId(),troop:$gameTroop._troopId,eligible:r.troops.indexOf($gameTroop._troopId)>=0,identity:identity(),won:false,run:$gameMap._merchantRun29&&$gameMap._merchantRun29.sequence}:null;return out;});
 alias(BattleManager,'endBattle',function(old,args){if(battle)battle.won=args[0]===0;return old.apply(this,args);});
 M.complete=function(interpreter){
  var run=$gameMap._merchantRun29,r=route();if(!run||!r||run.claimed||!battle||!battle.won||!battle.eligible||battle.map!==$gameMap.mapId()||battle.run!==run.sequence)return false;
  var l=ledger(),who=battle.identity;run.claimed=true;run.identity=who;run.pool=clone(r.pool);l.balances[who.key]=(l.balances[who.key]||0)+C().reward;
  var misses=l.misses[who.key]||0;run.appeared=misses>=C().pity-1||Math.random()<C().encounterRate;l.misses[who.key]=run.appeared?0:misses+1;
  $gameMap.requestRefresh();msg('获得本副本战利品点＋'+C().reward+'。'+(run.appeared?who.kind+'出现了。':''));
  if(run.appeared)M.openCurrent(interpreter);return true;
 };
 M.hasMerchant=function(){var r=$gameMap&&$gameMap._merchantRun29;return !!(r&&r.claimed&&r.appeared);};
 alias(Game_Event.prototype,'meetsConditions',function(old,args){var e=this.event();if(e&&/<CodexMerchant29>/.test(e.note||'')&&e.pages.indexOf(args[0])===1)return M.hasMerchant();return old.apply(this,args);});
 alias(Scene_Map.prototype,'onMapLoaded',function(old,args){
  if(W.$dataMap&&$dataMap.events)$dataMap.events.forEach(function(e){if(e&&/<CodexMerchant29>/.test(e.note||'')&&!$gameMap._events[e.id])$gameMap._events[e.id]=new Game_Event($gameMap.mapId(),e.id);});
  return old.apply(this,args);
 });
 M.balance=function(key){return ledger().balances[key]||0;};
 M.openCurrent=function(interpreter){if(!M.hasMerchant()||M.active)return false;M.active=true;M.mode='merchant';M.interpreter=interpreter||null;if(interpreter)interpreter.setWaitMode('merchant29');SceneManager.push(Scene_Merchant29);return true;};
 M.openPreview=function(map){if(M.active||!C().routes[String(map)])return false;M.active=true;M.mode='preview';M.previewMap=Number(map);SceneManager.push(Scene_Merchant29);return true;};
 M.openAbsorb=function(){if(M.active)return false;M.active=true;M.mode='absorb';SceneManager.push(Scene_Merchant29);return true;};
 alias(Game_Interpreter.prototype,'updateWaitMode',function(old,args){if(this._waitMode==='merchant29'){if(M.active)return true;this._waitMode='';return false;}return old.apply(this,args);});
 function seedRandom(seed){var s=seed>>>0;return function(){s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296;};}
 function group(d){var i=item(d);return d.db==='Weapons'?'武器':[9,10,11,12].indexOf(i.etypeId)>=0?'饰品':'防具';}
 M.pool=function(g){var r=$gameMap._merchantRun29;return (r&&r.pool||route()&&route().pool||[]).filter(function(d){return !g||group(d)===g;});};
 function choose(list,random){return list[Math.floor(random()*list.length)];}
 function candidates(cat,typ){var pool=C().affixes[cat]||[],native=pool.filter(function(d){return d.db===typ;});return native.length?native:pool;}
 M.generate=function(d,affix,random){
  var original=item(d),blue=clone(original),D=DreamX.RandomPrefixSuffix;
  // Native DreamX treats armor type 0 as a consumable. Use an armor sentinel only during synthesis.
  var armorType=blue.atypeId;if(armorType===0)blue.atypeId=1;
  blue.note=blue.note.replace(/<(Prefixes|Suffixes)>[\s\S]*?<\/(?:Prefixes|Suffixes)>/gi,'').replace(/<(?:prefix|suffix):[^>]*>/gi,'');
  blue.meta=clone(blue.meta||{});delete blue.meta.prefix;delete blue.meta.suffix;delete blue.meta.prefixSuffixUseWeaponDatabase;delete blue.meta.prefixSuffixUseArmorDatabase;
  blue.meta[affix.db==='Armors'?'prefixSuffixUseArmorDatabase':'prefixSuffixUseWeaponDatabase']=true;
  blue.note+='\n<Prefixes>\n'+affix.id+' 100%\n</Prefixes>';
  DataManager.processDXRPSNotetagsChoices(blue);blue.nonIndependent=false;
  var oldMath=Math.random,stock=$gameTemp.varianceStock(),randFields=['RomDreamX','RomDreamXNum','RomDreamXs','RomDreamXsNum'],saved={};
  randFields.forEach(function(k){saved[k]=$gameParty[k];});
  var before={weapons:DataManager._independentWeapons.slice(),armors:DataManager._independentArmors.slice(),w:clone($gameParty._weapons),a:clone($gameParty._armors),wl:$dataWeapons.length,al:$dataArmors.length,overlay:($gameSystem.overlayIcons||[]).length,last:$gameTemp.lastDXRPSItemCreated};
  try{
   Math.random=random;$gameTemp.disableVarianceStock();randFields.forEach(function(k){$gameParty[k]=k.indexOf('Num')>=0?0:[];});
   D.makeItem(blue);
   var created=$gameTemp.lastDXRPSItemCreated;
   if(!created)throw Error('装备生成失败，未扣除点数。');
   $gameParty.registerNewItem(created,created);
   var list=d.db==='Weapons'?DataManager._independentWeapons:DataManager._independentArmors,old=d.db==='Weapons'?before.weapons:before.armors;
   var made=list.filter(function(x){return x&&old.indexOf(x)<0&&base(x)===d.id;});
   if(made.length!==1||!$gameParty.hasItem(made[0],false)){M.lastGenerationFailure={descriptor:d,affix:affix,newRows:list.filter(function(x){return x&&old.indexOf(x)<0;}).map(function(x){return {id:x.id,baseItemId:x.baseItemId,originalBaseItemId:x.originalBaseItemId,name:x.name};}),made:made.length,last:$gameTemp.lastDXRPSItemCreated&&$gameTemp.lastDXRPSItemCreated.id};throw Error('装备生成结果不完整，未扣除点数。');}
   var result=made[0];if(armorType===0)result.atypeId=0;result._codexExtraAffix29=clone(affix);result._codexMerchant29=true;
   return result;
  }catch(e){
   DataManager._independentWeapons=before.weapons;DataManager._independentArmors=before.armors;$gameParty._weapons=before.w;$gameParty._armors=before.a;$dataWeapons.length=before.wl;$dataArmors.length=before.al;
   if($gameSystem.overlayIcons)$gameSystem.overlayIcons.length=before.overlay;$gameTemp.lastDXRPSItemCreated=before.last;throw e;
  }finally{Math.random=oldMath;if(stock)$gameTemp.enableVarianceStock();else $gameTemp.disableVarianceStock();randFields.forEach(function(k){if(saved[k]===undefined)delete $gameParty[k];else $gameParty[k]=saved[k];});}
 };
 M.draw=function(tier,g){
  var run=$gameMap._merchantRun29;if(!M.hasMerchant()||!run.identity)throw Error('当前没有可交易的商人。');
  if(!Number.isInteger(tier)||tier<0||tier>2)throw Error('抽奖档位无效。');var key=run.identity.key,cost=C().costs[tier];
  if(run.used>=C().visitLimit)throw Error('本次商人的抽取次数已用完。');if(M.balance(key)<cost)throw Error('本副本战利品点不足。');
  var pool=M.pool(g);if(!pool.length)throw Error('本分组暂无装备。');
  var random=seedRandom(run.seed+run.used*104729),d=choose(pool,random),affix=choose(candidates(M.categories[tier],d.db),random);
  if(!affix)throw Error('对应类别没有可用特效。');
  var result=M.generate(d,affix,random);ledger().balances[key]-=cost;run.used++;return result;
 };

 // Absorption stores one descriptor on the real weapon. Its effect view is rebuilt from the current instance,
 // preserving later upgrades, socketing, independent identity and previous ownership.
 // 【Claude·未经Codex检验】v0.32：缓存改用廉价比对（引用、短字段、版本号），不再每次JSON序列化；
 // equips() 仍给出效果视图供各插件读取特效，但数组按原对象识别，交易与持有判断也换回原对象。
 var views=new WeakMap(),revision=0;
 M.touch=function(){revision++;};
 M.real=function(i){return i&&i._codexAbsorbSource29||i;};
 // Field reads on these large instances are hash lookups, so only the fields that can change the effect are compared;
 // socketing and item-name rebuilds also bump the revision through their ItemManager entry points.
 function fresh(c,i,d,capacity){
  var p=i.params,cp=c.params;
  if(c.capacity!==capacity||c.revision!==revision||c.descriptor!==d||c.note!==i.note||c.name!==i.name||c.traits!==i.traits||c.traitCount!==c.traits.length||c.paramsRef!==p||cp.length!==p.length)return false;
  for(var k=0;k<p.length;k++)if(cp[k]!==p[k])return false;return true;
 }
 // 【Codex·未经Claude检验】v0.36：旧单条描述原位兼容；目前开放专武的槽位随所属角色等级开放。
 var ownerCache36=new WeakMap();
 M.absorbOwners=function(i){
  i=M.real(i);var template=i&&$dataWeapons[base(i)];
  if(!template||i.wtypeId===undefined||!template.name||/<CodexHiddenEquipment>/i.test(template.note||'')||(W.CodexV029&&CodexV029.hiddenGear(template)))return [];
  var cached=ownerCache36.get(template);if(cached&&cached.note===template.note)return cached.ids;
  var match=/<req_actors\s*:\s*([^>]+)>/i.exec(template.note||'');
  var ids=match?(match[1].match(/\d+/g)||[]).map(Number).filter(function(id){return $dataActors[id]&&$dataActors[id].name&&!(W.CodexV029&&CodexV029.hiddenActor(id))&&!(W.CodexImportedBalance&&CodexImportedBalance.isDisabledActor(id));}):[];
  ownerCache36.set(template,{note:template.note,ids:ids});return ids;
 };
 M.canAbsorb=function(i){return M.absorbOwners(i).length>0;};
 M.isAbsorbActor=function(id){return $dataWeapons.some(function(i){return i&&M.absorbOwners(i).indexOf(Number(id))>=0;});};
 M.absorbCapacity=function(target){var ids=M.absorbOwners(target||$dataWeapons[90]),lv=1;ids.forEach(function(id){var a=W.$gameActors&&$gameActors._data[id];if(a)lv=Math.max(lv,Number(a.level)||1);});return lv>=60?3:lv>=35?2:1;};
 M.absorptions=function(i){i=M.real(i);var d=i&&i._codexAbsorbed29;return d?(Array.isArray(d)?d:[d]):[];};
 M.absorbView=function(i){
  i=M.real(i);
  if(!i||!i._codexAbsorbed29)return i;
  var d=i._codexAbsorbed29,capacity=M.absorbCapacity(i),cached=views.get(i);if(cached&&fresh(cached,i,d,capacity))return cached.view;
  var active=M.absorptions(i).slice(0,capacity).filter(Boolean);if(!active.length||active.some(function(d){return !item(d);}))return i;
  var view;
  try{
   view=clone(i);delete view._codexAbsorbed29;
   active.forEach(function(d){DreamX.RandomPrefixSuffix.combineWithBaseItem(item(d),view,'prefix');});
   DataManager.processYanflyTags(view);view.id=i.id;view.baseItemId=i.baseItemId;view.originalBaseItemId=i.originalBaseItemId;view._codexAbsorbView29=true;
   Object.defineProperty(view,'_codexAbsorbSource29',{value:i});
   if(i.traits&&i.params)views.set(i,{view:view,capacity:capacity,revision:revision,descriptor:d,note:i.note,name:i.name,traits:i.traits,traitCount:i.traits.length,paramsRef:i.params,params:i.params.slice()});return view;
  }catch(e){
   // v0.59.01：一件装备的吸取显示副本失败不能卡住整个读档；本帧按原装备显示。
   console.error('[专武吸取] 装备 '+(i&&i.id)+' 的吸取显示副本创建失败，本次按原装备显示：'+(e&&e.message?e.message:e));
   return i;
  }
 };
 // Real arrays whose search methods also match the original weapon; filter/map/concat still return plain arrays.
 function EquipList(){}
 function indexOf(x,from){x=M.real(x);for(var k=Math.max(0,from|0);k<this.length;k++){var e=this[k];if(e===x||(e&&e._codexAbsorbSource29===x))return k;}return -1;}
 function contains(x){return indexOf.call(this,x)>=0;}
 EquipList.prototype=Object.create(Array.prototype,{constructor:{value:Array},indexOf:{value:indexOf},contains:{value:contains},includes:{value:contains}});
 alias(Game_Actor.prototype,'equips',function(old,args){
  var list=old.apply(this,args),out=null;
  for(var k=0;k<list.length;k++){var e=list[k];if(e&&e._codexAbsorbed29){var v=M.absorbView(e);if(v!==e){if(!out){out=Reflect.construct(Array,[],EquipList);for(var j=0;j<list.length;j++)out[j]=list[j];}out[k]=v;}}}
  return out||list;
 });
 alias(Game_Actor.prototype,'tradeItemWithParty',function(old,args){args[0]=M.real(args[0]);args[1]=M.real(args[1]);return old.apply(this,args);});
 ['gainItem','loseItem'].forEach(function(k){alias(Game_Party.prototype,k,function(old,args){args[0]=M.real(args[0]);return old.apply(this,args);});});
 if(W.ItemManager)['augmentRefreshParty','updateItemName'].forEach(function(k){alias(ItemManager,k,function(old,args){M.touch();return old.apply(this,args);});});
 if(W.Sprite_ItemHelp)alias(Sprite_ItemHelp.prototype,'setItem',function(old,args){args[0]=M.absorbView(args[0]);return old.apply(this,args);});
 M.extraAffixes=function(i){
  i=M.real(i);if(!i)return [];if(i._codexExtraAffix29)return [clone(i._codexExtraAffix29)];
  var result=[],seen={};Object.keys(C().affixes).forEach(function(cat){C().affixes[cat].forEach(function(d){var t=item(d),lines=String(t.note||'').split(/\r?\n/).filter(function(line){return /(?:mod|神话)特效\s*[:：]/i.test(line);});if(!lines.length||!lines.every(function(line){return String(i.note||'').indexOf(line)>=0;}))return;var signature=JSON.stringify([t.params,t.traits,t.note]);if(!seen[signature]){seen[signature]=true;result.push(clone(d));}});});return result;
 };
 M.absorb=function(target,material,descriptor,slot){
  target=M.real(target);material=M.real(material);
  if(!target||!DataManager.isWeapon(target)||!M.canAbsorb(target)||!$gameParty.hasItem(target,true))throw Error('请先持有当前开放的专武。');
  if(!material||material===target||!$gameParty.hasItem(material,false)||/\[锁定\]/.test(material.name||''))throw Error('请选择背包中未锁定、未装备的材料。');
  if($gameParty.members().some(function(a){return (a._equips||[]).some(function(r){return r.object()===material;});}))throw Error('材料正在装备中，请先卸下。');
  if(!M.extraAffixes(material).some(function(d){return d.db===descriptor.db&&d.id===descriptor.id;}))throw Error('材料不包含所选额外特效。');
  var stored=M.absorptions(target),capacity=M.absorbCapacity(target);slot=slot===undefined?0:Number(slot);
  if(!Number.isInteger(slot)||slot<0||slot>=capacity)throw Error('所选吸取槽位尚未开放。');
  var old=target._codexAbsorbed29,next=stored.slice();while(next.length<slot)next.push(null);next[slot]=clone(descriptor);target._codexAbsorbed29=next;views.delete(target);
  try{var view=M.absorbView(target);if(view===target)throw Error('特效解析失败。');$gameParty.loseItem(material,1,false);if($gameParty.hasItem(material,false))throw Error('材料消耗失败。');}
  catch(e){if(old)target._codexAbsorbed29=old;else delete target._codexAbsorbed29;views.delete(target);throw e;}
  $gameParty.members().forEach(function(a){CodexV029.refresh(a);});return true;
 };

 function Window_Merchant29(){this.initialize.apply(this,arguments);}
 Window_Merchant29.prototype=Object.create(Window_Command.prototype);Window_Merchant29.prototype.constructor=Window_Merchant29;
 Window_Merchant29.prototype.initialize=function(x,y,w,h){this._rows29=[];this._width29=w;this._height29=h;Window_Command.prototype.initialize.call(this,x,y);};
 Window_Merchant29.prototype.windowWidth=function(){return this._width29;};Window_Merchant29.prototype.windowHeight=function(){return this._height29;};
 Window_Merchant29.prototype.makeCommandList=function(){this._rows29.forEach(function(r,i){this.addCommand(r.label,'choose',r.enabled!==false,i);},this);};
 Window_Merchant29.prototype.updateHelp=function(){if(this._helpWindow){var row=this._rows29[this.index()];if(row){if(row.item29)this._helpWindow.setEquipment29(row.item29);else this._helpWindow.setText(row.help||'确认选择；取消返回上一级。');}}};
 function Window_MerchantDetail29(){this.initialize.apply(this,arguments);}
 Window_MerchantDetail29.prototype=Object.create(Window_Base.prototype);Window_MerchantDetail29.prototype.constructor=Window_MerchantDetail29;
 Window_MerchantDetail29.prototype.initialize=function(x,y,w,h){Window_Base.prototype.initialize.call(this,x,y,w,h);this._key29=null;this._rows29=[];this._page29=0;this._pages29=1;};
 Window_MerchantDetail29.prototype.setText=function(text){if(this._key29==='text:'+text)return;this._key29='text:'+text;this._rows29=[[text,22,'#ffffff',false,0]];this.render29();};
 Window_MerchantDetail29.prototype.setEquipment29=function(e){var key='item:'+e.id+':'+e.note+':'+JSON.stringify(e.params)+':'+JSON.stringify(M.absorptions(e))+':'+M.absorbCapacity(e);if(this._key29===key)return;this._key29=key;var view=clone(M.absorbView(e));RJO.HE.getDescParams(view,DataManager.isWeapon(e)?1:2);this._rows29=view.descParams;this._equipment29=e;this.render29();};
 Window_MerchantDetail29.prototype.render29=function(){
  var width=this.contentsWidth(),height=0;RJO.SW.setContent(this.contents,0);
  this._rows29.forEach(function(r){RJO.SW.changeTextSize(Number(r[1])||20);RJO.SW.setupTextState(String(r[0]||''),0,height,width,r[4]);height+=RJO.SW.textHeight+8;});
  this._fullHeight29=Math.max(1,height);this.contents=new Bitmap(width,Math.max(this.contentsHeight(),height));RJO.SW.setContent(this.contents,0);height=0;
  this._rows29.forEach(function(r){RJO.SW.changeTextSize(Number(r[1])||20);RJO.SW.changeTextColor(r[2]||'#ffffff');RJO.SW.drawContentText(String(r[0]||''),0,height,width,r[4]);height+=RJO.SW.textHeight+8;});
  this._page29=0;this._pages29=Math.max(1,1+Math.ceil(Math.max(0,this._fullHeight29-this.contentsHeight())/Math.max(1,this.contentsHeight()-40)));this.origin.y=0;this.updateNav29();
 };
 Window_MerchantDetail29.prototype.turn29=function(delta){this._page29=Math.max(0,Math.min(this._pages29-1,this._page29+delta));this.origin.y=Math.min(Math.max(0,this._fullHeight29-this.contentsHeight()),this._page29*Math.max(1,this.contentsHeight()-40));this.updateNav29();};
 Window_MerchantDetail29.prototype.updateNav29=function(){if(this._nav29)this._nav29.setText('◀ 上一页     '+(this._page29+1)+'／'+this._pages29+'     下一页 ▶');};
 Window_MerchantDetail29.prototype.update=function(){Window_Base.prototype.update.call(this);if(TouchInput.x>=this.x&&TouchInput.x<this.x+this.width&&TouchInput.y>=this.y&&TouchInput.y<this.y+this.height){if(TouchInput.wheelY>=20)this.turn29(1);if(TouchInput.wheelY<=-20)this.turn29(-1);}var n=this._nav29;if(n&&TouchInput.isTriggered()&&TouchInput.x>=n.x&&TouchInput.x<n.x+n.width&&TouchInput.y>=n.y&&TouchInput.y<n.y+n.height)this.turn29(TouchInput.x<n.x+n.width/2?-1:1);};
 function Scene_Merchant29(){this.initialize.apply(this,arguments);}
 Scene_Merchant29.prototype=Object.create(Scene_MenuBase.prototype);Scene_Merchant29.prototype.constructor=Scene_Merchant29;
 Scene_Merchant29.prototype.create=function(){
  Scene_MenuBase.prototype.create.call(this);this._header29=new Window_Help(2);this.addWindow(this._header29);
  var y=this._header29.height,left=Math.floor(Graphics.boxWidth*.43),height=Graphics.boxHeight-y,navHeight=this._header29.fittingHeight(1);
  this._details29=new Window_MerchantDetail29(left,y,Graphics.boxWidth-left,height-navHeight);this.addWindow(this._details29);
  this._detailNav29=new Window_Help(1);this._detailNav29.move(left,Graphics.boxHeight-navHeight,Graphics.boxWidth-left,navHeight);this._detailNav29.createContents();this._detailNav29.contents.fontSize=20;this.addWindow(this._detailNav29);this._details29._nav29=this._detailNav29;
  this._choices29=new Window_Merchant29(0,y,left,height);this._choices29.setHelpWindow(this._details29);
  this._choices29.setHandler('choose',this.choose29.bind(this));this._choices29.setHandler('cancel',this.back29.bind(this));
  this._choices29.setHandler('pageup',function(){this._details29.turn29(-1);this._choices29.activate();}.bind(this));
  this._choices29.setHandler('pagedown',function(){this._details29.turn29(1);this._choices29.activate();}.bind(this));this.addWindow(this._choices29);
  if(M.mode==='absorb')this.absorbHome29();else if(M.mode==='preview')this.preview29(M.previewMap);else this.home29();
 };
 Scene_Merchant29.prototype.list29=function(title,rows,back){this._back29=back||this.popScene.bind(this);this._header29.setText(title);this._choices29._rows29=rows;this._choices29.refresh();this._choices29.select(rows.length?0:-1);this._choices29.activate();this._choices29.updateHelp();};
 Scene_Merchant29.prototype.choose29=function(){var row=this._choices29._rows29[this._choices29.currentExt()];try{if(row&&row.run)row.run();}catch(e){msg(e.message);this._details29.setText(e.message);this._choices29.activate();}};
 Scene_Merchant29.prototype.back29=function(){this._back29();};
 Scene_Merchant29.prototype.home29=function(){var self=this,run=$gameMap._merchantRun29,who=run.identity;this.list29(who.kind+'　'+route().name+'\n战利品点 '+M.balance(who.key)+'　剩余抽取 '+(C().visitLimit-run.used)+' 次',[
  {label:'查看本副本完整装备池',run:function(){self.preview29(who.map);}},
  {label:'抽取武器',enabled:M.pool('武器').length>0,run:function(){self.tiers29('武器');}},
  {label:'抽取防具',enabled:M.pool('防具').length>0,run:function(){self.tiers29('防具');}},
  {label:'抽取饰品',enabled:M.pool('饰品').length>0,run:function(){self.tiers29('饰品');}},
  {label:'离开',run:function(){self.popScene();}}]);};
 function detail(d){var i=item(d);return i.name+'　'+group(d)+'\n基础属性：'+i.params.join('／')+'\n'+String(i.description||'')+'\n数值按装备原有范围随机；三档分别必出Mod／神话／混沌神话特效。';}
 Scene_Merchant29.prototype.preview29=function(map){var self=this,r=C().routes[String(map)],pool=r.pool;this.list29(r.name+'　完整装备池（'+pool.length+'件）\n先选分组时，该分组内每件基础装备等概率。',pool.map(function(d){return {label:item(d).name+'　'+group(d),item29:item(d),help:detail(d),run:function(){self.equipmentDetail29(d,map);}};}),M.mode==='preview'?this.popScene.bind(this):this.home29.bind(this));};
 Scene_Merchant29.prototype.equipmentDetail29=function(d,map){this._details29.setEquipment29(item(d));this._details29.turn29(1);this._choices29.activate();};
 Scene_Merchant29.prototype.tiers29=function(g){var self=this,run=$gameMap._merchantRun29;this.list29(g+'抽奖　'+route().name+'\n同一分组内基础装备等概率，必出本档指定类别1条。',M.labels.map(function(label,tier){var cost=C().costs[tier];return {label:cost+'点　必出1条'+label,help:'消耗本路线战利品点'+cost+'；装备本体和具体特效随机。',enabled:M.balance(run.identity.key)>=cost&&run.used<C().visitLimit,run:function(){var i=M.draw(tier,g);msg('获得 '+i.name+'（'+label+'）');self.tiers29(g);}};}),this.home29.bind(this));};
 Scene_Merchant29.prototype.absorbHome29=function(){var self=this,targets=$gameParty.weapons().concat($gameParty.members().reduce(function(out,a){return out.concat((a._equips||[]).map(function(r){return r.object();}).filter(Boolean));},[])).filter(function(i,n,a){return M.canAbsorb(i)&&a.indexOf(i)===n;});this.list29('专武·特效吸取\n按所属角色等级开放：1级一条，35级两条，60级三条。',targets.map(function(t){return {label:t.name+'（'+M.absorptions(t).filter(Boolean).length+'／'+M.absorbCapacity(t)+'条）',item29:t,run:function(){self.slots29(t);}};}));};
 Scene_Merchant29.prototype.slots29=function(target){var self=this,stored=M.absorptions(target),capacity=M.absorbCapacity(target),rows=[];
  for(var slot=0;slot<3;slot++)(function(n){var d=stored[n],open=n<capacity;rows.push({label:'槽位'+(n+1)+'：'+(open?(d?affixLabel(d):'空槽'):(n===1?'所属角色35级开放':'所属角色60级开放')),help:d?affixLabel(d):'选择空槽吸取，或替换指定槽位的特效。',enabled:open,run:function(){self.materials29(target,n);}});})(slot);
  this.list29('选择吸取槽位\n替换只影响所选槽位。',rows,this.absorbHome29.bind(this));
 };
 Scene_Merchant29.prototype.materials29=function(target,slot){var self=this,list=$gameParty.weapons().concat($gameParty.armors()).filter(function(i){return i!==target&&!/\[锁定\]/.test(i.name||'')&&M.extraAffixes(i).length>0;});this.list29('选择要消耗的材料装备\n已装备、锁定装备不会消耗。',list.map(function(i){return {label:i.name,item29:i,run:function(){self.affixes29(target,i,slot);}};}),function(){self.slots29(target);});};
 function affixLabel(d){var t=item(d),m=/text=(.*?) size=/.exec(t.note);return m?m[1].replace(/\\c\[\d+\]/g,''):'额外特效';}
 Scene_Merchant29.prototype.affixes29=function(target,material,slot){var self=this;this.list29('选择一条额外特效',M.extraAffixes(material).map(function(d){return {label:affixLabel(d),help:affixLabel(d),run:function(){self.list29('确认消耗 '+material.name+'\n'+(M.absorptions(target)[slot]?'原槽位特效会被替换。':'吸取至空槽位。')+'当前最多保留'+M.absorbCapacity(target)+'条。',[{label:'确认消耗并吸取',help:affixLabel(d),run:function(){M.absorb(target,material,d,slot);msg('特效吸取完成。');self.slots29(target);}},{label:'取消',run:function(){self.affixes29(target,material,slot);}}],function(){self.affixes29(target,material,slot);});}};}),function(){self.materials29(target,slot);});};
 Scene_Merchant29.prototype.terminate=function(){Scene_MenuBase.prototype.terminate.call(this);M.active=false;if(M.interpreter){M.interpreter.setWaitMode('');M.interpreter=null;}Input.clear();TouchInput.clear();};
 W.Scene_Merchant29=Scene_Merchant29;
 return M;
});
