// 【Codex·未经Claude检验】v0.45：十二类本命兵试炼、完成记录兼容、指定奖励与分页，幻境不重复产出奖励。
// 【Codex·未经Claude检验】v0.23 玩家反馈与平衡修复；未经claude检验。
// 【Codex·未经Claude检验】v0.05 天道使者旧档校正；未经claude检验。
// 【Codex·未经Claude检验】核查状态：未经claude检验。幻境试炼隔离战利品，只有主动进入神兵试炼才解锁本命兵。
// 真气成长线（设计稿 v0.3，2026-10-09；v1.1 大圆满只在到瓶颈时显示；v1.2 神兵试炼；v1.3 守层者只能打一次，可反复的 Boss 胜利改为 3×）：把超额行动伤害改为可见、可突破的角色成长。
// 真气＝溢出再动＋守层者首通／胜利＋Boss胜利；加成√(1＋真气÷10)；凡人修仙传境界；大境界需在方桌大厅闭关打瓶颈之战。
window.CodexRuntime.register('installNativeZhenqiRuntime',function(){
 'use strict';
 var Z=window.CodexZhenqi={version:45,DIV:10,OVERFLOW_UNIT:0.2,OVERFLOW_CAP:10,COEF:{first:10,guardian:3,boss:3}};
 Z.ROUTES=[{key:'normal',name:'普通',coef:1},{key:'hard',name:'困难',coef:2},{key:'hell',name:'地狱',coef:3},{key:'calamity',name:'天灾',coef:5},{key:'doom',name:'灭世',coef:8},{key:'primordial',name:'洪荒',coef:13}];
 // 守层者敌群 → 楼层（由各层地图的战斗处理统计）
 Z.GUARDIANS={4:1,5:2,8:3,22:4,28:5,245:5,39:6,52:7,53:8,67:9,69:10,109:11,110:12,111:13,118:14,138:15,172:16,173:17,174:18,333:19,456:20,457:21,458:22,459:23,460:24,461:25,462:26,463:27,464:28,465:29,466:30,467:31,468:32,469:33};
 Z.REALMS=[
  {name:'炼气',need:0,world:'人界'},
  {name:'筑基',need:600,world:'人界',trial:'心魔',scale:1,choice:{split:30}},
  {name:'结丹',need:2500,world:'人界',trial:'心魔',scale:1,fixed:'jindan',choice:{split:50}},
  {name:'元婴',need:6000,world:'人界',trial:'心魔',scale:1,fixed:'yuanying',choice:{split:70}},
  {name:'化神',need:18000,world:'人界',trial:'心魔',scale:1,choice:{split:99}},
  {name:'炼虚',need:36000,world:'灵界',trial:'心魔',scale:2,fixed:'lianxu',choice:{all:333}},
  {name:'合体',need:66000,world:'灵界',trial:'心魔',scale:2,choice:{all:333}},
  {name:'大乘',need:88000,world:'灵界',trial:'心魔',scale:2,fixed:'dacheng',choice:{all:500}},
  {name:'渡劫',need:111000,world:'灵界',trial:'天劫',scale:3,fixed:'dujie',choice:{all:666}},
  {name:'真仙',need:150000,world:'仙界',trial:'天劫',scale:5,fixed:'xianyuan',choice:{all:1000}},
  {name:'金仙',need:222000,world:'仙界',trial:'天劫',scale:8,fixed:'xianyuan',choice:{all:1000}},
  {name:'太乙',need:300000,world:'仙界',trial:'天劫',scale:13,fixed:'xianyuan',choice:{all:1000}},
  {name:'大罗',need:388000,world:'仙界',trial:'天劫',scale:21,fixed:'xianyuan',choice:{all:1000}},
  {name:'道祖',need:500000,world:'仙界',trial:'天劫',scale:34,fixed:'xianyuan',choice:{all:1000}}];
 Z.TRIAL_TROOP={'心魔':901,'天劫':823};Z.HEART_TROOP={1:770};
 Z.DAOFA=['lianji','fenshen','lingtai','benming','linggen','huichun','jinshen','pojia','hufa'];
 Z.DAOFA_NAME={lianji:'连击',fenshen:'分神',lingtai:'灵台',benming:'本命兵',linggen:'灵根',huichun:'回春',jinshen:'金身',pojia:'破甲',hufa:'护法'};
 Z.WEAPON_BOSS={20:11,40:2,51:5,52:2,419:2,420:2,421:2,655:4,664:9,667:4};
 Z.LINGGEN_ELEMENTS=[1,2,3,4,5,6,7,8,9];
 // 天道补偿：真气加成低于旧超额行动伤害，按路线与楼层给敌人受到我方伤害的倍率（对数插值，标定值）
 // 洪荒标定（2026-10-09，无画面引擎三种子几何平均）：存档1 第21层 ×15、毕业档 第33层 ×500；12层及以下 ×1。
 // 其他路线没有参照存档，按难度系数取指数：洪荒值^(系数÷13)。
 Z.COMP_ANCHORS=[[12,1],[21,15],[33,111]];
 Z.COMP={};
 Z.ROUTES.forEach(function(r){var e=r.coef/13;Z.COMP[r.key]=Z.COMP_ANCHORS.map(function(p){return [p[0],Math.pow(p[1],e)];});});
 var SUB3=['初期','中期','后期'],CN='零一二三四五六七八九十';
 function num(v){v=Number(v);return isFinite(v)?v:0;}
 function toast(msg){try{if(window.$&&$.toaster)$.toaster({message:msg});}catch(e){}}
 function cnNum(n){if(n<=10)return n===10?'十':CN[n];if(n<20)return '十'+CN[n-10];return CN[Math.floor(n/10)]+'十'+(n%10?CN[n%10]:'');}
 function parseFloor(text){
  var m=/(\d+)\s*层/.exec(text||'');if(m)return num(m[1]);
  m=/([一二三四五六七八九十]+)层/.exec(text||'');if(!m)return 0;
  var s=m[1],v=0;if(s.indexOf('十')<0)return CN.indexOf(s);
  var p=s.split('十');v=(p[0]?CN.indexOf(p[0]):1)*10+(p[1]?CN.indexOf(p[1]):0);return v;}
 Z.route=function(){var s=function(id){return $gameSwitches&&$gameSwitches.value(id);};
  if(s(2483)||s(2463))return Z.ROUTES[5];if(s(2487)||s(2462))return Z.ROUTES[4];if(s(2489)||s(2461))return Z.ROUTES[3];
  if(s(2494))return Z.ROUTES[2];if(s(2500))return Z.ROUTES[1];return Z.ROUTES[0];};
 Z.progressFloor=function(){return Math.max(0,Math.min(33,num($gameVariables.value(20))-1));};
 Z.mapFloor=function(){var info=$dataMapInfos&&$dataMapInfos[$gameMap.mapId()];return parseFloor(info&&info.name)||parseFloor($gameMap.displayName&&$gameMap.displayName());};
 // ---- 境界 ----
 Z.majorByQi=function(qi){for(var i=Z.REALMS.length-1;i>0;i--)if(qi>=Z.REALMS[i].need)return i;return 0;};
 Z.data=function(actor){
  if(!actor||!actor.isActor||!actor.isActor())return null;
  var d=actor._codexZhenqi;
  if(!d){d=actor._codexZhenqi={qi:0,firsts:{},realm:0,pending:[],daofa:{},spec:{}};migrate(actor,d);}
  return d;};
 function migrate(actor,d){
  var adm=num(actor._actionDMG);
  if(adm>0){d.qi+=Math.round(adm/Z.OVERFLOW_UNIT);d.legacy=adm;}
  actor._actionDMG=0;
  var retro=$gameSystem&&$gameSystem._codexZhenqiRetro;
  if(retro&&retro.floors>0){var r=Z.ROUTES.filter(function(x){return x.key===retro.route;})[0]||Z.ROUTES[0];
   for(var f=1;f<=retro.floors;f++){var key=r.key+':'+f;if(!d.firsts[key]){d.firsts[key]=1;d.qi+=Z.COEF.first*f*r.coef;}}}
  var m=Math.min(Z.majorByQi(d.qi),Z.allowedRealm());
  for(var i=1;i<=m;i++){d.realm=i;grantFixed(actor,i);d.pending.push(i);}
 }
 Z.rate=function(actor){var d=Z.data(actor);if(!d)return 1;var x=Math.sqrt(1+d.qi/Z.DIV);
  for(var i=9;i<=d.realm&&i<Z.REALMS.length;i++)x*=1.1;return x;};
 Z.state=function(actor){
  var d=Z.data(actor),i=d.realm,R=Z.REALMS,byQi=Z.majorByQi(d.qi),capped=byQi>i,name,sub;
  if(i===R.length-1){sub=Math.floor((d.qi-R[i].need)/100000)+1;name='道祖'+cnNum(Math.min(sub,99))+'重';}
  else if(capped)name=R[i].name+'大圆满';
  else{var lo=R[i].need,hi=R[i+1].need,n=i===0?13:3,k=Math.min(n-1,Math.floor((d.qi-lo)/(hi-lo)*n));
   name=R[i].name+(i===0?cnNum(k+1)+'层':SUB3[k]);}
  var next=i<R.length-1?R[i+1]:null;
  return {name:name,realm:i,world:R[i].world,qi:d.qi,rate:Z.rate(actor),capped:capped,next:next,need:next?Math.max(0,next.need-d.qi):0,pending:d.pending.length,gate:Z.gate(actor),canBreak:capped&&Z.gate(actor).unlocked};};
 function skillKey(key){if(!Z._skills){Z._skills={};$dataSkills.forEach(function(s){var m=s&&/<CodexZhenqi:\s*([^>]+)>/.exec(s.note||'');if(m)Z._skills[m[1].trim()]=s.id;});}return Z._skills[key];}
 Z.skillKey=skillKey;
 function learnKey(actor,key){var id=skillKey(key);if(id&&!actor.isLearnedSkill(id))actor.learnSkill(id);return id;}
 function grantFixed(actor,i){var f=Z.REALMS[i].fixed;if(!f)return;learnKey(actor,f==='xianyuan'?'fixed:xianyuan:'+i:'fixed:'+f);}
 Z.gain=function(actor,amount,why){
  var d=Z.data(actor);if(!d||!(amount>0))return;
  var before=Z.state(actor).name,wasCapped=Z.majorByQi(d.qi)>d.realm;d.qi+=Math.round(amount);
  var s=Z.state(actor);
  if(s.capped&&!wasCapped)toast(actor.name()+' 已至'+Z.REALMS[d.realm].name+'大圆满，'+(s.canBreak?'打开菜单「真气」闭关突破'+s.next.name:'通关第'+s.gate.required+'层后可突破'));
  else if(s.name!==before)toast(actor.name()+' 真气精进：'+s.name);};
 Z.breakthrough=function(actor){var d=Z.data(actor),i=d.realm+1;if(i>=Z.REALMS.length||d.qi<Z.REALMS[i].need||!Z.gate(actor).unlocked)return false;
  d.realm=i;grantFixed(actor,i);d.pending.push(i);toast(actor.name()+' 突破至'+Z.REALMS[i].name+'！');return true;};
 // ---- 道法 ----
 Z.has=function(actor,key){var d=actor&&actor.isActor&&actor.isActor()?actor._codexZhenqi:null;return !!(d&&d.daofa[key]);};
 var _atkTimes=Game_Actor.prototype.attackTimesAdd;
 Game_Actor.prototype.attackTimesAdd=function(){return _atkTimes.call(this)+(Z.has(this,'lianji')?1:0);};
 var _aps=Game_Actor.prototype.actionPlusSet;
 Game_Actor.prototype.actionPlusSet=function(){var s=_aps.call(this);if(Z.has(this,'fenshen'))s=s.concat([1]);return s;};
 var _seb=Game_Battler.prototype.shieldEffectBonus;
 Game_Battler.prototype.shieldEffectBonus=function(){return (_seb?num(_seb.call(this)):0)+(Z.has(this,'jinshen')?Z.daofaScale(this):0);};
 // ---- 伤害：真气加成与天道补偿 ----
 Z.compFor=function(routeKey,floor){var pts=Z.COMP[routeKey];if(!pts||!pts.length)return 1;
  if(floor<=pts[0][0])return pts[0][1];
  for(var i=1;i<pts.length;i++)if(floor<=pts[i][0]){var a=pts[i-1],b=pts[i],t=(floor-a[0])/(b[0]-a[0]);return Math.exp(Math.log(a[1])+(Math.log(b[1])-Math.log(a[1]))*t);}
  return pts[pts.length-1][1];};
 Z.comp=function(){var b=Z._battle;return b?b.comp:1;};
 var _amd=Game_Action.prototype.applyMinimumDamage;
 Game_Action.prototype.applyMinimumDamage=function(value,baseDamage,target){
  return _amd.apply(this,arguments);};
 // 2026-10-10：真气×天道补偿改在伤害结算里、扣固定减伤之前乘（growthMultiplier），能帮助打穿固定减伤；参考预览不计
 (window.CodexDamageHooks=window.CodexDamageHooks||[]).push({name:'zhenqi-growth',build:function(action,target,f){
  if(f.options&&f.options.reference)return;var a=f.subject;if(!a||!a.isActor||!a.isActor()||!target||!target.isEnemy||!target.isEnemy())return;
  var r=Z.rate(a)*Z.comp();if(r>0&&r!==1){f.growthMultiplier*=r;f.origins.push('真气×天道补偿 ×'+r.toFixed(1));}}});
 var _ehd=Game_Action.prototype.executeHpDamage;
 Game_Action.prototype.executeHpDamage=function(target,value){
  if(target&&target.isActor&&target.isActor()&&value>0&&$gameParty.inBattle()){
   if(Z.has(target,'hufa'))value=Math.round(value*(1-.3*Z.daofaScale(target)));
   var yid=skillKey('fixed:yuanying');
   if(yid&&target.isLearnedSkill(yid)&&!target._codexZqGuard&&target.hp>1&&value>=target.hp){value=target.hp-1;target._codexZqGuard=true;}
  }
  return _ehd.call(this,target,value);};
 // ---- 溢出再动转真气：OTB 第 1 回合的超额次数记进本场，不再累计 _actionDMG ----
 var _otb=BattleManager.otbActionTimesModification;
 if(_otb)BattleManager.otbActionTimesModification=function(array){
  var before=$gameParty.members().map(function(a){Z.data(a);return [a,num(a._actionDMG)];});
  var r=_otb.apply(this,arguments),ovf=Z._ovf||(Z._ovf={});
  before.forEach(function(p){var a=p[0],delta=num(a._actionDMG)-p[1];if(delta>0)ovf[a.actorId()]=(ovf[a.actorId()]||0)+Math.round(delta/Z.OVERFLOW_UNIT);a._actionDMG=p[1];});
  return r;};
 // ---- 战斗：开始、瓶颈之战敌人、胜利结算 ----
 function guardianTroopOfFloor(f){var best=0;Object.keys(Z.GUARDIANS).forEach(function(t){if(Z.GUARDIANS[t]===f&&(!best||Number(t)!==245))best=Number(t);});return best;}
 Z.trialRef=function(i){var f=Math.max(1,Z.progressFloor()),t=guardianTroopOfFloor(f),tr=$dataTroops[t];
  return {floor:f,troopId:t,enemyId:tr&&tr.members[0]?tr.members[0].enemyId:0,scale:Z.REALMS[i].scale};};
 var _bmSetup=BattleManager.setup;
 BattleManager.setup=function(troopId,canEscape,canLose){
  var trial=Z._pendingTrial||null,scaled=Z._pendingScale||null;Z._pendingTrial=null;Z._pendingScale=null;Z._ovf={};
  if(trial&&trial.troopId!==troopId)trial=null;if(scaled&&scaled.troopId!==troopId)scaled=null;
  var route=Z.route(),gf=Z.GUARDIANS[troopId]||0,floor=gf||(trial&&trial.ref.floor)||Z.mapFloor()||Z.progressFloor();
  if(scaled)floor=scaled.ref.floor;
  Z._battle={troopId:troopId,trial:trial,scaled:scaled,route:route,guardianFloor:trial?0:gf,floor:floor,comp:Z.compFor(route.key,floor)};
  $gameParty.members().forEach(function(a){Z.data(a);a._codexZqGuard=false;});
  return _bmSetup.apply(this,arguments);};
 var _troopSetup=Game_Troop.prototype.setup;
 Game_Troop.prototype.setup=function(troopId){
  _troopSetup.apply(this,arguments);
  var b=Z._battle,t=b&&(b.trial||b.scaled);if(!t||!t.ref.enemyId)return;
  var ref=new Game_Enemy(t.ref.enemyId,0,0),p=[0,1,2,3,4,5,6,7].map(function(i){return num(ref.paramBase(i));});
  this.members().forEach(function(e){e._codexZqRef={p:p,k:t.ref.scale};e._codexZqTrialLoot=true;if(b.scaled)e._codexZqWeaponTrial=true;e.recoverAll();});};
 // The source enemy is reused for an illusion. Block loot before MOG caches
 // a death popup, and after reward plugins append map-specific extras.
 var _zqDrops=Game_Enemy.prototype.makeDropItems;
 Game_Enemy.prototype.makeDropItems=function(){
  if(this._codexZqTrialLoot){if(this._treasure){this._treasure.checked=true;this._treasure.item=[];this._treasure.needPopup=false;}return [];}
  return _zqDrops.apply(this,arguments);};
 var _zqRewards=BattleManager.makeRewards;
 BattleManager.makeRewards=function(){var out=_zqRewards.apply(this,arguments);
  if($gameTroop.members().some(function(e){return e._codexZqTrialLoot;})&&this._rewards)this._rewards.items=[];if($gameTroop.members().some(function(e){return e._codexZqWeaponTrial;})&&this._rewards){this._rewards.exp=0;this._rewards.gold=0;}return out;};
 ['exp','gold'].forEach(function(k){var old=Game_Enemy.prototype[k];Game_Enemy.prototype[k]=function(){return this._codexZqWeaponTrial?0:old.apply(this,arguments);};});
 var _pb=Game_Enemy.prototype.paramBase;
 Game_Enemy.prototype.paramBase=function(id){var r=this._codexZqRef;if(r)return r.p[id]*((id===0||id===2||id===4)?r.k:1);return _pb.call(this,id);};
 function isBossEnemy(e){
  if(window.CodexBossDifficulty&&CodexBossDifficulty.isBoss&&CodexBossDifficulty.isBoss(e))return true;
  return /【(首领|守层者|守护者|被封印者|未知存在|超级Boos|前所未见|终焉恐惧|神兵)】/.test(e.originalName?e.originalName():(e.enemy().name||''));}
 function learned45(v){return v===true||num(v)>0;}
 Z.specState=function(){
  var sp=$gameSystem._codexZhenqiSpec;if(!sp||typeof sp!=='object'||Array.isArray(sp))sp=$gameSystem._codexZhenqiSpec={};
  ['w','e','weaponTrials'].forEach(function(k){if(!sp[k]||typeof sp[k]!=='object'||Array.isArray(sp[k]))sp[k]={};});
  Object.keys(sp.weaponTrials).forEach(function(k){if(learned45(sp.weaponTrials[k])&&!learned45(sp.w[k]))sp.w[k]=1;});return sp;
 };
 Z.weaponTypes=function(){return ($dataSystem.weaponTypes||[]).map(function(name,id){return name&&id>0&&skillKey('daofa:benming:'+id)&&$dataWeapons.some(function(w){return w&&w.name&&w.wtypeId===id&&!(window.CodexV029&&CodexV029.hiddenGear&&CodexV029.hiddenGear(w));})?id:0;}).filter(Boolean);};
 Z.knownSpecs=function(key){var sp=Z.specState(),pool=key==='benming'?Z.weaponTypes():Z.LINGGEN_ELEMENTS,map=key==='benming'?sp.w:sp.e;return pool.filter(function(id){return learned45(map[id]);});};
 function unlockSpecs(b){
  var sp=Z.specState();
  $gameTroop.members().forEach(function(e){var id=e.enemyId(),tag=/<CodexZhenqi:\s*weapon\s+(\d+)>/.exec(e.enemy().note||''),w=tag?num(tag[1]):Z.WEAPON_BOSS[id];
   if(b&&b.scaled){
    if(id===b.scaled.master&&w===b.scaled.wtype&&e.isDead()&&!e.isHidden()&&Z.weaponTypes().indexOf(w)>=0){var first=!learned45(sp.weaponTrials[w]);sp.w[w]=1;sp.weaponTrials[w]=1;if(first)toast('神兵试炼完成：本命兵可指定「'+$dataSystem.weaponTypes[w]+'」');}return;
   }
   if(!isBossEnemy(e))return;
   // 旧 <Element Absorb> 继续认（其余首领的来源不变）；第六段补的 14 个改用只给灵根的
   // <CodexZhenqiLinggen>，两处来源合并后同一元素只解锁一次、只提示一次。
   var note=e.enemy().note||'',els=[];
   function addLinggen(x){x=num(x);if(Z.LINGGEN_ELEMENTS.indexOf(x)>=0&&els.indexOf(x)<0)els.push(x);}
   [/<Element Absorb:\s*([\d,\s]+)>/gi,/<CodexZhenqiLinggen:\s*([\d,\s]+)>/gi].forEach(function(re){var m;while((m=re.exec(note)))m[1].split(',').forEach(addLinggen);});
   els.forEach(function(x){if(!sp.e[x]){sp.e[x]=1;toast('降服 '+e.originalName()+'：灵根可指定「'+$dataSystem.elements[x]+'」');}});
  });
 }
 Z.isBossEnemy=isBossEnemy;
 Z.onVictory=function(){
  var b=Z._battle;Z._battle=null;if(!b)return;
  var alive=$gameParty.battleMembers().filter(function(a){return a.isAlive();});
  if(b.scaled){if(alive.length)unlockSpecs(b);return;}
  if(b.trial){b.trial.won=alive.some(function(a){return a.actorId()===b.trial.actorId;});Z._trialDone=b.trial;return;}
  unlockSpecs(b);
  var boss=!b.guardianFloor&&$gameTroop.members().some(isBossEnemy),c=b.route.coef,f=b.guardianFloor||b.floor,lines=[];
  alive.forEach(function(a){
   var d=Z.data(a),g=Math.min(Z.OVERFLOW_CAP,num(Z._ovf&&Z._ovf[a.actorId()])),first=false;
   if(b.guardianFloor){var key=b.route.key+':'+f;if(!d.firsts[key]){d.firsts[key]=1;first=true;g+=Z.COEF.first*f*c;}g+=Z.COEF.guardian*f*c;}
   else if(boss&&f>0)g+=Z.bossReward(f,c);
   if(g>0){Z.gain(a,g);lines.push(a.name()+' +'+g+(first?'（首通）':''));}});
  if(lines.length)toast('真气 '+lines.join('，'));};
 var _endBattle=BattleManager.endBattle;
 BattleManager.endBattle=function(result){
  if(result===0){try{Z.onVictory();}catch(e){console.error('[Zhenqi]',e);}}
  else{var b=Z._battle;if(b&&b.trial){b.trial.won=false;Z._trialDone=b.trial;}Z._battle=null;}
  return _endBattle.apply(this,arguments);};
 // ---- 存档：迁移记录 ----
 var _extract=DataManager.extractSaveContents;
 DataManager.extractSaveContents=function(contents){
  _extract.apply(this,arguments);
  if(!$gameSystem._codexZhenqiRetro)$gameSystem._codexZhenqiRetro={route:Z.route().key,floors:Z.progressFloor(),at:Date.now()};
  $gameActors._data.forEach(function(a){if(a)Z.data(a);});};
 var _newGame=DataManager.setupNewGame;
 DataManager.setupNewGame=function(){_newGame.apply(this,arguments);$gameSystem._codexZhenqiRetro={route:'normal',floors:0,at:Date.now()};};
 // 旧档读入时地图事件来自存档，补上新增的闭关 NPC
 var _oml=Scene_Map.prototype.onMapLoaded;
 Scene_Map.prototype.onMapLoaded=function(){
  if($dataMap&&$dataMap.events)$dataMap.events.forEach(function(ev){if(ev&&ev.note==='<CodexZhenqi: retreat>'&&!$gameMap._events[ev.id])$gameMap._events[ev.id]=new Game_Event($gameMap.mapId(),ev.id);});
  return _oml.apply(this,arguments);};
 // ---- 闭关：原生选项与战斗处理 ----
 function say(lines){var out=[{code:101,indent:0,parameters:['',0,0,2]}];lines.slice(0,4).forEach(function(l){out.push({code:401,indent:0,parameters:[l]});});return out;}
 Z._cbs=null;
 Z._cb=function(k,interp){var f=Z._cbs&&Z._cbs[k];Z._cbs=null;if(f)f(interp);};
 function ask(interp,lines,options){
  Z._cbs=options.map(function(o){return o.fn;});
  var list=say(lines),labels=options.map(function(o){return o.label;});
  list.push({code:102,indent:0,parameters:[labels,labels.length-1,0,2,0]});
  options.forEach(function(o,k){list.push({code:402,indent:0,parameters:[k,o.label]},{code:355,indent:1,parameters:['CodexZhenqi._cb('+k+',this)']},{code:0,indent:1,parameters:[]});});
  list.push({code:404,indent:0,parameters:[]},{code:0,indent:0,parameters:[]});
  interp.setupChild(list,interp._eventId);}
 function tell(interp,lines,then){var list=say(lines);if(then){Z._cbs=[then];list.push({code:355,indent:0,parameters:['CodexZhenqi._cb(0,this)']});}list.push({code:0,indent:0,parameters:[]});interp.setupChild(list,interp._eventId);}
 Z.retreat=function(interp,page){
  var members=$gameParty.members(),size=4,pages=Math.max(1,Math.ceil(members.length/size));
  page=Math.max(0,Math.min(pages-1,Math.floor(num(page))));
  var opts=members.slice(page*size,(page+1)*size).map(function(a){var s=Z.state(a),tag=s.pending?'［待选奖励］':(s.canBreak?'［可突破］':s.capped?'［通关'+s.gate.required+'层后突破］':'');
   return {label:a.name()+' '+s.name+' ×'+s.rate.toFixed(1)+tag,fn:function(it){Z.actorPage(it,a);}};});
  if(page>0)opts.push({label:'上一页（'+page+'/'+pages+'）',fn:function(it){Z.retreat(it,page-1);}});
  if(page+1<pages)opts.push({label:'下一页（'+(page+2)+'/'+pages+'）',fn:function(it){Z.retreat(it,page+1);}});
  opts.push({label:'神兵试炼（指定本命兵武器）',fn:function(it){Z.weaponMenu(it);}},{label:'离开',fn:null});
  ask(interp,['\\C[6]闭关之所\\C[0]','真气达到大圆满、通关对应楼层后，打赢瓶颈之战突破。','突破后获得境界奖励。'],opts);};
 Z.actorPage=function(interp,a){
  var s=Z.state(a),lines=['\\C[6]'+a.name()+'\\C[0]：'+s.world+' '+s.name,'真气 '+s.qi+'　加成 ×'+s.rate.toFixed(1)];
  lines.push(s.next?(s.capped?(s.canBreak?'已到瓶颈，可挑战「'+Z.REALMS[s.realm+1].trial+'」突破'+s.next.name:'需先通关第'+s.gate.required+'层，当前已通关'+s.gate.passed+'层'):'距'+s.next.name+'还差 '+s.need+' 真气'):'已至最高境界');
  var opts=[];
  if(s.pending)opts.push({label:'选择突破奖励（'+s.pending+'）',fn:function(it){Z.pickFlow(it,a);}});
  if(s.canBreak)opts.push({label:'挑战瓶颈之战',fn:function(it){Z.startTrial(it,a);}});
  opts.push({label:'返回',fn:function(it){Z.retreat(it);}},{label:'离开',fn:null});
  ask(interp,lines,opts);};
 Z.startTrial=function(interp,a){
  var d=Z.data(a),i=d.realm+1,g=Z.gate(a);
  if(!g.ready||!g.unlocked){tell(interp,[g.ready?'需先通关第'+g.required+'层，当前已通关'+g.passed+'层。':'真气尚未达到下一境界。']);return;}
  if($gameParty.battleMembers().indexOf(a)<0){tell(interp,[a.name()+' 不在出战队伍中。','请先把'+a.name()+'编入出战队伍再闭关。']);return;}
  var ref=Z.trialRef(i),kind=Z.REALMS[i].trial,troop=kind==='心魔'&&Z.HEART_TROOP[a.actorId()]||Z.TRIAL_TROOP[kind];
  Z._pendingTrial={actorId:a.actorId(),target:i,ref:ref,kind:kind,troopId:troop};
  var list=say(['\\C[6]'+kind+'\\C[0]幻化为第'+ref.floor+'层守层者之力（×'+ref.scale+'）。',a.name()+'必须坚持到战斗结束，才能突破'+Z.REALMS[i].name+'。']);
  list.push({code:301,indent:0,parameters:[0,troop,false,true]},
   {code:601,indent:0,parameters:[]},{code:355,indent:1,parameters:['CodexZhenqi._trialEnd(this)']},{code:0,indent:1,parameters:[]},
   {code:603,indent:0,parameters:[]},{code:355,indent:1,parameters:['CodexZhenqi._trialEnd(this)']},{code:0,indent:1,parameters:[]},
   {code:604,indent:0,parameters:[]},{code:0,indent:0,parameters:[]});
  interp.setupChild(list,interp._eventId);};
 Z._trialEnd=function(interp){
  var t=Z._trialDone;Z._trialDone=null;Z._pendingTrial=null;if(!t)return;
  var a=$gameActors.actor(t.actorId);
  if(t.won&&Z.breakthrough(a)){tell(interp,['\\C[6]'+a.name()+' 突破至'+Z.REALMS[t.target].name+'！\\C[0]'],function(it){Z.pickFlow(it,a);});}
  else tell(interp,[a.name()+' 未能突破。','（突破的角色需活到战斗结束）'],function(it){Z.actorPage(it,a);});};
 Z.pickFlow=function(interp,a){
  var d=Z.data(a);if(!d.pending.length){Z.actorPage(interp,a);return;}
  var i=d.pending[0],R=Z.REALMS[i],ch=R.choice,opts=[];
  function done(key){return function(it){if(d.pending[0]!==i||!skillKey(key))return;learnKey(a,key);d.pending.shift();delete d.pendingDaofaRoll;Z.pickFlow(it,a);};}
  if(ch.split){opts.push({label:'攻击属性 +'+ch.split+'%（物攻、魔攻）',fn:done('attr:atk:'+i)},{label:'防御属性 +'+ch.split+'%（生命、物防、魔防）',fn:done('attr:def:'+i)},{label:'辅助属性 +'+ch.split+'%（敏捷、幸运、魔法上限）',fn:done('attr:sup:'+i)});}
  else opts.push({label:'全属性 +'+ch.all+'%',fn:done('attr:all:'+i)});
  var left=Z.DAOFA.filter(function(k){return !d.daofa[k];});
  if(left.length)opts.push({label:'道法（随机一项，剩 '+left.length+' 种）',fn:function(it){Z.rollDaofa(it,a,i);}});
  opts.push({label:'稍后再选',fn:null});
  ask(interp,['\\C[6]'+a.name()+'\\C[0] '+R.name+'突破奖励：自选一项','属性：稳定提升；道法：对特定打法大幅加成。'],opts);};
 // Persist the rolled school until this realm's reward is resolved; Back never rerolls or spends it.
 Z.finishDaofa=function(interp,a,i,k,value,mode){
  var d=Z.data(a),roll=d.pendingDaofaRoll;if(!roll||roll.realm!==i||roll.key!==k||d.pending[0]!==i||d.daofa[k])return false;
  var special=k==='benming'||k==='linggen',pool=k==='benming'?Z.weaponTypes():Z.LINGGEN_ELEMENTS;
  if(special&&(pool.indexOf(value)<0||mode==='choose'&&Z.knownSpecs(k).indexOf(value)<0))return false;
  var key='daofa:'+k+(special?':'+value:''),id=skillKey(key);if(!id)return false;
  learnKey(a,key);if(!a.isLearnedSkill(id))return false;
  d.daofa[k]=1;d.daofaStages=d.daofaStages||{};d.daofaStages[k]=i;d.spec=d.spec||{};if(special)d.spec[k]=value;d.pending.shift();delete d.pendingDaofaRoll;Z.refreshRewards(a);
  var names=k==='benming'?$dataSystem.weaponTypes:$dataSystem.elements,label=Z.DAOFA_NAME[k]+(special?'·'+names[value]:'');tell(interp,[a.name()+' 领悟道法「'+label+'」！'],function(it){Z.pickFlow(it,a);});return true;
 };
 Z.pickSpecialization=function(interp,a,i,k,page){
  var d=Z.data(a),roll=d.pendingDaofaRoll;if(!roll||roll.realm!==i||roll.key!==k||d.pending[0]!==i||d.daofa[k])return;
  var isW=k==='benming',pool=isW?Z.weaponTypes():Z.LINGGEN_ELEMENTS,names=isW?$dataSystem.weaponTypes:$dataSystem.elements,known=Z.knownSpecs(k),size=4,pages=Math.max(1,Math.ceil(known.length/size));
  if(pool.indexOf(roll.random)<0)roll.random=pool[Math.randomInt(pool.length)];
  if(!known.length){Z.finishDaofa(interp,a,i,k,roll.random,'random');return;}
  page=Math.max(0,Math.min(pages-1,Math.floor(num(page))));
  var opts=known.slice(page*size,(page+1)*size).map(function(x){return {label:'指定「'+names[x]+'」',fn:function(it){Z.finishDaofa(it,a,i,k,x,'choose');}};});
  if(page>0)opts.push({label:'上一页',fn:function(it){Z.pickSpecialization(it,a,i,k,page-1);}});
  if(page+1<pages)opts.push({label:'下一页',fn:function(it){Z.pickSpecialization(it,a,i,k,page+1);}});
  opts.push({label:'随机（'+names[roll.random]+'）',fn:function(it){Z.finishDaofa(it,a,i,k,roll.random,'random');}},{label:'稍后再选',fn:null});
  ask(interp,['领悟道法「'+Z.DAOFA_NAME[k]+'」：',isW?'已完成试炼的武器可直接指定。':'已领悟的元素可直接指定。','第'+(page+1)+'／'+pages+'页；稍后再选会保留本次结果。'],opts);
 };
 Z.rollDaofa=function(interp,a,i){
  var d=Z.data(a);if(!d||!Array.isArray(d.pending)||d.pending[0]!==i||!Z.REALMS[i]||i>d.realm)return false;d.daofa=d.daofa||{};
  var left=Z.DAOFA.filter(function(k){return !d.daofa[k];});if(!left.length)return false;
  var roll=d.pendingDaofaRoll;if(!roll||roll.realm!==i||left.indexOf(roll.key)<0){roll=d.pendingDaofaRoll={realm:i,key:left[Math.randomInt(left.length)]};}
  var k=roll.key;if(k==='benming'||k==='linggen'){Z.pickSpecialization(interp,a,i,k,0);return true;}return Z.finishDaofa(interp,a,i,k);
 };
 // Each real weapon family has exactly one dedicated illusion; no wild-boss completion is inferred.
 Z.weaponMasters=function(){var out=[],seen={},pool=Z.weaponTypes();$dataEnemies.forEach(function(e){var m=e&&/<CodexZhenqi:\s*weapon\s+(\d+)>/.exec(e.note||'');if(!m)return;var w=num(m[1]);if(pool.indexOf(w)<0||seen[w])return;
  var troop=$dataTroops.find(function(t){return t&&t.members.length===1&&t.members[0].enemyId===e.id&&!t.members[0].hidden;});if(troop){seen[w]=true;out.push({enemyId:e.id,name:e.name,wtype:w,troopId:troop.id});}});return out.sort(function(a,b){return a.wtype-b.wtype;});};
 Z.WEAPON_TRIAL_SCALE=2;
 Z.weaponMenu=function(interp,page){
  var sp=Z.specState(),ms=Z.weaponMasters(),f=Math.max(1,Z.progressFloor()),size=4,pages=Math.max(1,Math.ceil(ms.length/size));page=Math.max(0,Math.min(pages-1,Math.floor(num(page))));
  var opts=ms.slice(page*size,(page+1)*size).map(function(m){return {label:m.name+'（'+$dataSystem.weaponTypes[m.wtype]+'）'+(learned45(sp.weaponTrials[m.wtype])?'［试炼完成］':learned45(sp.w[m.wtype])?'［已领悟］':''),fn:function(it){Z.startWeaponTrial(it,m);}};});
  if(page>0)opts.push({label:'上一页',fn:function(it){Z.weaponMenu(it,page-1);}});if(page+1<pages)opts.push({label:'下一页',fn:function(it){Z.weaponMenu(it,page+1);}});
  opts.push({label:'返回',fn:function(it){Z.retreat(it);}},{label:'离开',fn:null});
  ask(interp,['\\C[6]神兵试炼\\C[0]：第'+(page+1)+'／'+pages+'页；领悟本命兵时可指定已完成的武器。','对手采用第'+f+'层守层者之力 ×'+Z.WEAPON_TRIAL_SCALE+'。','此处主动挑战获胜才算完成；试炼不结算常规战利品。'],opts);
 };
 Z.startWeaponTrial=function(interp,m){
  if(!m||$gameParty.inBattle()||Z._pendingScale||Z._pendingTrial)return false;
  var valid=Z.weaponMasters().find(function(x){return x.enemyId===m.enemyId&&x.wtype===m.wtype&&x.troopId===m.troopId;});if(!valid)return false;
  var ref=Z.trialRef(1);if(!ref.enemyId)return false;ref.scale=Z.WEAPON_TRIAL_SCALE;Z._pendingScale={ref:ref,master:m.enemyId,wtype:m.wtype,troopId:m.troopId};
  var list=say(['\\C[6]'+m.name+'\\C[0]：「来，让我看看你配不配用'+$dataSystem.weaponTypes[m.wtype]+'。」']);
  list.push({code:301,indent:0,parameters:[0,m.troopId,false,true]},{code:601,indent:0,parameters:[]},{code:0,indent:1,parameters:[]},{code:603,indent:0,parameters:[]},{code:0,indent:1,parameters:[]},{code:604,indent:0,parameters:[]},{code:0,indent:0,parameters:[]});interp.setupChild(list,interp._eventId);return true;
 };
 Z.describe=function(actor){var s=Z.state(actor);return s.world+' '+s.name+' ×'+s.rate.toFixed(1);};
 // 2026-10-10：主菜单「真气」＝随身闭关（境界、突破奖励、瓶颈之战、神兵试炼）。回到地图后由地图解释器执行，战斗与选项沿用闭关流程。
 Z.openFromMenu=function(){$gameTemp._codexZhenqiMenu=true;SceneManager.pop();};
 var _zqMenuCmds=Window_MenuCommand.prototype.addOriginalCommands;
 Window_MenuCommand.prototype.addOriginalCommands=function(){_zqMenuCmds.apply(this,arguments);this.addCommand('真气','codexZhenqi',$gameParty.size()>0);};
 var _zqMenuWin=Scene_Menu.prototype.createCommandWindow;
 Scene_Menu.prototype.createCommandWindow=function(){_zqMenuWin.apply(this,arguments);this._commandWindow.setHandler('codexZhenqi',Z.openFromMenu);};
 var _zqStart=Game_Map.prototype.setupStartingEvent;
 Game_Map.prototype.setupStartingEvent=function(){
  if($gameTemp._codexZhenqiMenu){$gameTemp._codexZhenqiMenu=false;this._interpreter.setup([{code:355,indent:0,parameters:['CodexZhenqi.retreat(this)']},{code:0,indent:0,parameters:[]}],0);return true;}
  return _zqStart.apply(this,arguments);};
// 【Codex·未经Claude检验】既有楼层／奖励／命中规则；未经claude检验。
 Z.requiredFloor=function(realm){return realm<=0?0:realm<=6?realm*5:33;};
 Z.allowedRealm=function(){var f=Z.progressFloor();return f>=33?Z.REALMS.length-1:Math.min(6,Math.floor(f/5));};
 Z.gate=function(actor){var d=Z.data(actor),i=d.realm+1,required=Z.requiredFloor(i);return {required:required,passed:Z.progressFloor(),unlocked:i<Z.REALMS.length&&Z.progressFloor()>=required,ready:i<Z.REALMS.length&&d.qi>=Z.REALMS[i].need};};
 Z.bossReward=function(f,c){var rate=f<=15?1/3:f<=25?1/2:2/3;return Math.round(Z.COEF.boss*f*c*rate);};
 Z.daofaScale=function(actor){var d=actor&&actor._codexZhenqi,i=d&&d.realm||0;return i>=5?1:i>=4?2/3:i===3?1/2:i===2?1/3:1/4;};
 function pct(v){return String(Math.round(v*100)/100);}
 Z.patchRewards=function(){if(!$dataSkills||Z._rewardDatabase===$dataSkills)return;Z._rewardDatabase=$dataSkills;var values=[30,50,70,99];
  $dataSkills.forEach(function(s){if(!s)return;var tag=(/<CodexZhenqi:\s*([^>]+)>/.exec(s.note||'')||[])[1],value;
   if(tag==='fixed:jindan')value=20;else if(tag==='fixed:yuanying')value=50;else if(/^attr:(atk|def|sup):[1-4]$/.test(tag||''))value=values[Number(tag.slice(-1))-1];else return;
   var note=s.note.replace(/(<passive(?:PBST\d|XPBST\d|CrHarmRi):\s*)[\d.]+(%?>)/gi,function(_,a,b){return a+value+b;}).replace(/\+\d+(?:\.\d+)?%/g,'+'+value+'%');
   if(note!==s.note){s.note=note;DataManager.extractMetadata(s);delete s.descParams;}
  });
 };
 var loaded=DataManager.isDatabaseLoaded;DataManager.isDatabaseLoaded=function(){var ready=loaded.apply(this,arguments);if(ready)Z.patchRewards();return ready;};Z.patchRewards();
 var viewCache=new WeakMap(),skillViews=new WeakSet();
 var nativeIsSkill=DataManager.isSkill;DataManager.isSkill=function(item){return item&&skillViews.has(item)?nativeIsSkill.call(this,$dataSkills[item.id]):nativeIsSkill.apply(this,arguments);};
 Z.skillView=function(s,actor){if(s&&skillViews.has(s))s=$dataSkills[s.id];var tag=s&&(/<CodexZhenqi:\s*(daofa:[^>]+)>/.exec(s.note||'')||[])[1];if(!tag)return s;
  var factor=Z.daofaScale(actor),cached=viewCache.get(s);if(!cached){cached={};viewCache.set(s,cached);}if(cached[factor])return cached[factor];
  var v=Object.assign({},s);skillViews.add(v);v.meta=Object.assign({},s.meta);delete v.descParams;
  v.note=(s.note||'').replace(/(<passive(?:WPNM\d+|ELUP\d+|HEUP|EXTTP):\s*)([\d.]+)(%?>)/gi,function(_,prefix,n,end){return prefix+Math.round(Number(n)*factor)+end;});
  if(tag.indexOf('daofa:benming:')===0)v.note=v.note.replace(/物攻、魔攻\+333%/,'物攻、魔攻+'+Math.round(333*factor)+'%');
  else if(tag.indexOf('daofa:linggen:')===0)v.note=v.note.replace(/伤害\+500%/,'伤害+'+Math.round(500*factor)+'%');
  else if(tag==='daofa:huichun')v.note=v.note.replace(/治疗量\+100%/,'治疗量+'+Math.round(100*factor)+'%');
  else if(tag==='daofa:jinshen')v.note=v.note.replace(/护盾\+100%/,'护盾+'+pct(100*factor)+'%');
  else if(tag==='daofa:lingtai')v.note=v.note.replace(/TP上限\+100/,'TP上限+'+Math.round(100*factor));
  else if(tag==='daofa:hufa')v.note=v.note.replace(/伤害-30%/,'伤害-'+pct(30*factor)+'%');
  else if(tag==='daofa:pojia')v.note=v.note.replace(/双防×0\.5/,'双防×'+pct(1-.5*factor));
  DataManager.extractMetadata(v);cached[factor]=v;return v;
 };
 var nativeSkills=Game_Actor.prototype.skills;Game_Actor.prototype.skills=function(){return nativeSkills.apply(this,arguments).map(function(s){return Z.skillView(s,this);},this);};
 var passiveStamps=new WeakMap(),rebuilding=new WeakSet();
 function ensurePassive(a){if(rebuilding.has(a))return;var key=[Z.daofaScale(a),(a._skills||[]).join(',')].join('|');if(passiveStamps.get(a)===key)return;passiveStamps.set(a,key);rebuilding.add(a);try{a.refreshPassiveSkillCache();}finally{rebuilding.delete(a);}}
 var iterate=Game_Actor.prototype.iteratePassiveSkill;Game_Actor.prototype.iteratePassiveSkill=function(){ensurePassive(this);return iterate.apply(this,arguments);};
 var passive=Game_Actor.prototype.refreshPassiveCache;Game_Actor.prototype.refreshPassiveCache=function(){ensurePassive(this);return passive.apply(this,arguments);};
 Z.refreshRewards=function(a){passiveStamps.delete(a);a._passiveSkillCache=null;if(a.initPassiveCache)a.initPassiveCache();if(a.refreshPassiveCache)a.refreshPassiveCache();a.refresh();};
 var breakOld=Z.breakthrough;Z.breakthrough=function(a){var result=breakOld.apply(this,arguments);if(result)Z.refreshRewards(a);return result;};
 var extractRewards=DataManager.extractSaveContents;DataManager.extractSaveContents=function(){var result=extractRewards.apply(this,arguments);$gameActors._data.forEach(function(a){if(a)Z.refreshRewards(a);});return result;};
 var xparam=Game_Actor.prototype.xparam;Game_Actor.prototype.xparam=function(id){var v=xparam.apply(this,arguments);return id===0?Math.max(.9,v):v;};
 var applyAction=Game_Action.prototype.apply,pojiaActor=null;
 Game_Action.prototype.apply=function(target){var before=pojiaActor,a=this.subject();pojiaActor=a&&a.isActor&&a.isActor()&&Z.has(a,'pojia')?a:null;try{return applyAction.apply(this,arguments);}finally{pojiaActor=before;}};
 [Game_Battler,Game_Enemy,Game_Actor].forEach(function(Type){var addState=Type.prototype.addState;Type.prototype.addState=function(id){if(id===2705&&this.isStateAddable(id))this._codexZqPojiaRate=pojiaActor?1-.5*Z.daofaScale(pojiaActor):.5;return addState.apply(this,arguments);};});
 [Game_Actor,Game_Enemy].forEach(function(Type){var states=Type.prototype.states;Type.prototype.states=function(){var list=states.apply(this,arguments),rate=this._codexZqPojiaRate;if(rate===undefined||rate===.5)return list;return list.map(function(s){if(s.id!==2705)return s;var v=Object.assign({},s);v.traits=s.traits.map(function(t){return t.code===21&&(t.dataId===3||t.dataId===5)?Object.assign({},t,{value:rate}):t;});v.note=s.note.replace('双防×0.5','双防×'+pct(rate));return v;});};});
 var clearStates=Game_BattlerBase.prototype.clearStates;Game_BattlerBase.prototype.clearStates=function(){delete this._codexZqPojiaRate;return clearStates.apply(this,arguments);};
 [Game_BattlerBase,Game_Enemy,Game_Actor].forEach(function(Type){var erase=Type.prototype.eraseState;Type.prototype.eraseState=function(id){var result=erase.apply(this,arguments);if(id===2705)delete this._codexZqPojiaRate;return result;};});

 // 【Codex·未经Claude检验】v0.05 旧档天道使者与永久超限回退；未经claude检验。
 Z.ENVOY_VERSION=1;Z.ENVOY_TICKET=1639;Z.ENVOY_COMPENSATION=100;
 function rewardTag(id){var s=$dataSkills[id];return s&&(/<CodexZhenqi:\s*([^>]+)>/.exec(s.note||'')||[])[1]||'';}
 function fixedRealm(tag){var names={jindan:2,yuanying:3,lianxu:5,dacheng:7,dujie:8};var x=/^fixed:xianyuan:(\d+)$/.exec(tag);return x?Number(x[1]):names[tag.slice(6)]||0;}
 Z.qiCeiling=function(realm){return realm>=Z.REALMS.length-1?Infinity:Z.REALMS[realm+1].need;};
 // Old saves retain daofa acquisition order in the object's key order. New
 // rewards also record the exact source realm; no new random choice is made.
 Z.daofaRewardStages=function(a){var d=Z.data(a),out={},slots=[],assigned={};
  for(var i=1;i<=d.realm;i++){
   var chosen=(a._skills||[]).some(function(id){var m=/^attr:(?:atk|def|sup|all):(\d+)$/.exec(rewardTag(id));return m&&Number(m[1])===i;});
   if(!chosen&&(d.pending||[]).indexOf(i)<0)slots.push(i);
  }
  Object.keys(d.daofa||{}).forEach(function(k){if(!d.daofa[k])return;var exact=Number(d.daofaStages&&d.daofaStages[k]);if(exact>0&&exact<=d.realm){out[k]=exact;assigned[exact]=true;}});
  Object.keys(d.daofa||{}).forEach(function(k){if(!d.daofa[k]||out[k])return;var n=slots.find(function(i){return !assigned[i];});out[k]=n||d.realm+1;assigned[out[k]]=true;});
  return out;
 };
 Z.legacyLimitPlan=function(a){var d=Z.data(a),allowed=Z.allowedRealm(),realm=Math.min(d.realm,allowed),qi=Math.min(d.qi,Z.qiCeiling(allowed)),stages=Z.daofaRewardStages(a),remove=[],removeDaofa=[];
  (a._skills||[]).forEach(function(id){var tag=rewardTag(id),m=/^attr:(?:atk|def|sup|all):(\d+)$/.exec(tag),da=/^daofa:([^:]+)/.exec(tag);
   if(m&&Number(m[1])>realm||/^fixed:/.test(tag)&&fixedRealm(tag)>realm||da&&(!d.daofa[da[1]]||stages[da[1]]>realm))remove.push(id);
  });
  Object.keys(d.daofa||{}).forEach(function(k){if(d.daofa[k]&&stages[k]>realm)removeDaofa.push(k);});
  var pending=(d.pending||[]).filter(function(i){return i<=realm;});
  return {actorId:a.actorId(),oldRealm:d.realm,realm:realm,oldQi:d.qi,qi:qi,remove:remove,removeDaofa:removeDaofa,stages:stages,pending:pending,affected:d.realm>allowed||d.qi>qi||remove.length>0||removeDaofa.length>0||pending.length!==(d.pending||[]).length};
 };
 // Scoped compensation capacity: exactly100 even at the native item limit.
 // Already awarded overflow can be spent normally, without truncation.
 var ticketCapacity=Game_Party.prototype.maxItems,grantTicketLimit=0;
 Game_Party.prototype.maxItems=function(item){var n=ticketCapacity.apply(this,arguments);if(item&&item.id===Z.ENVOY_TICKET&&(grantTicketLimit||this._codexEnvoyTicketOverflow))return Math.max(n,this.numItems(item),grantTicketLimit);return n;};
 Z.applyLegacyLimits=function(){var migration=$gameSystem._codexZhenqiEnvoy;if(!migration||migration.done)return migration||null;
  var plans=($gameActors._data||[]).filter(Boolean).map(Z.legacyLimitPlan).filter(function(p){return p.affected;}),backups=[],ticket=$dataItems[Z.ENVOY_TICKET],ticketBefore=$gameParty.numItems(ticket),overflowBefore=$gameParty._codexEnvoyTicketOverflow;
  try{
   plans.forEach(function(p){var a=$gameActors._data[p.actorId],d=Z.data(a);backups.push({actor:a,data:JSON.parse(JSON.stringify(d)),skills:a._skills.slice()});d.realm=p.realm;d.qi=p.qi;d.pending=p.pending.slice();d.daofaStages=d.daofaStages||{};
    Object.keys(p.stages).forEach(function(k){d.daofaStages[k]=p.stages[k];});p.removeDaofa.forEach(function(k){delete d.daofa[k];delete d.daofaStages[k];});p.remove.forEach(function(id){a.forgetSkill(id);});Z.refreshRewards(a);
   });
   if(plans.length){grantTicketLimit=ticketBefore+Z.ENVOY_COMPENSATION;
    // Compare the unwrapped native cap; grantTicketLimit itself is scoped.
    if(grantTicketLimit>ticketCapacity.call($gameParty,ticket))$gameParty._codexEnvoyTicketOverflow=true;
    $gameParty.gainItem(ticket,Z.ENVOY_COMPENSATION);if($gameParty.numItems(ticket)!==ticketBefore+Z.ENVOY_COMPENSATION)throw new Error('天道补偿未完整发放');
   }
   if(window.CodexCombatPower&&CodexCombatPower.clearCache)CodexCombatPower.clearCache();
   migration.done=true;migration.at=Date.now();migration.floor=Z.progressFloor();migration.allowed=Z.allowedRealm();migration.affected=plans.map(function(p){return p.actorId;});migration.compensation=plans.length?Z.ENVOY_COMPENSATION:0;
   return migration;
  }catch(e){backups.forEach(function(p){p.actor._codexZhenqi=p.data;p.actor._skills=p.skills;Z.refreshRewards(p.actor);});var box=$gameParty.itemContainer(ticket);if(box){if(ticketBefore)box[ticket.id]=ticketBefore;else delete box[ticket.id];}$gameParty._codexEnvoyTicketOverflow=overflowBefore;throw e;}
  finally{grantTicketLimit=0;}
 };
 var envoyExtract=DataManager.extractSaveContents;
 DataManager.extractSaveContents=function(){var out=envoyExtract.apply(this,arguments);if(!$gameSystem._codexZhenqiEnvoy)$gameSystem._codexZhenqiEnvoy={version:Z.ENVOY_VERSION,done:false};return out;};
 var envoyNewGame=DataManager.setupNewGame;
 DataManager.setupNewGame=function(){var out=envoyNewGame.apply(this,arguments);$gameSystem._codexZhenqiEnvoy={version:Z.ENVOY_VERSION,done:true,source:'newGame',compensation:0};return out;};
 var envoyBusy=false,envoyHangupBattle=null;
 var envoyHangup=Game_Party.prototype.isHangUp;Game_Party.prototype.isHangUp=function(){return !envoyBusy&&envoyHangup.apply(this,arguments);};
 Z.clearEnvoy=function(scene){var visual=scene&&scene._codexEnvoyVisual;if(!visual)return;if(visual.sprite.parent)visual.sprite.parent.removeChild(visual.sprite);if(visual.label.bitmap){var lb=visual.label.bitmap;if(lb.destroy)lb.destroy();else if(lb._baseTexture)lb._baseTexture.destroy();}visual.sprite.destroy({children:true,texture:false,baseTexture:false});scene._codexEnvoyVisual=null;envoyBusy=false;if(envoyHangupBattle!==null&&window.XdRsData&&XdRsData.hangUp){XdRsData.hangUp.GuaJiStartBettleOk=envoyHangupBattle;envoyHangupBattle=null;}};
 Z.finishEnvoy=function(){var s=SceneManager._scene;if(s instanceof Scene_Map)Z.clearEnvoy(s);};
 Z.startEnvoy=function(scene){var state=$gameSystem._codexZhenqiEnvoy;if(!state||state.done)return false;
  if(!scene.isActive()||SceneManager.isSceneChanging()||$gamePlayer.isTransferring()||$gameParty.inBattle()||$gameMap.isEventRunning()||$gameMessage.isBusy()||$gameTemp.isCommonEventReserved())return false;
  var atlas=ImageManager.loadCharacter('People3');if(!atlas.isReady())return false;
  var result=Z.applyLegacyLimits(),character=new Game_Character(),directions=[4,6,8,2],direction=directions.find(function(d){return $gamePlayer.canPass($gamePlayer.x,$gamePlayer.y,d);})||4;
  var x=$gameMap.roundXWithDirection($gamePlayer.x,direction),y=$gameMap.roundYWithDirection($gamePlayer.y,direction);if(!$gameMap.isValid(x,y)){x=$gamePlayer.x;y=$gamePlayer.y;}
  character.setImage('People3',0);character.setThrough(true);character.setPriorityType(1);character.locate(x,y);character.setDirection(10-direction);character.setStepAnime(true);
  var sprite=new Sprite_Character(character),label=new Sprite(new Bitmap(180,28));label.anchor.set(.5,1);label.y=-48;label.bitmap.fontSize=20;label.bitmap.textColor='#ffe5a3';label.bitmap.outlineWidth=4;label.bitmap.drawText('天道使者',0,0,180,28,'center');sprite.addChild(label);scene._spriteset._tilemap.addChild(sprite);scene._codexEnvoyVisual={character:character,sprite:sprite,label:label};
  envoyBusy=true;if(window.XdRsData&&XdRsData.hangUp){envoyHangupBattle=XdRsData.hangUp.GuaJiStartBettleOk;XdRsData.hangUp.GuaJiStartBettleOk=false;}
  $gameTemp.clearDestination();Input.clear();TouchInput.clear();if(window.AndroidPort&&AndroidPort.releaseTouchKeys)AndroidPort.releaseTouchKeys();
  var lines=result.affected.length?['\\C[6]天道使者\\C[0]','你竟然没被规则发现吗？','越界的修为已压回此层界限。','之后须循序修行，重新突破。']:['\\C[6]天道使者\\C[0]','你竟然没被规则发现吗？','你的修行尚在此界规则之内。'];
  var list=say(lines);list[0].parameters=['People3',0,0,2];if(result.compensation)list=list.concat(say(['获得 肝帝积分抽奖券 ×100','这是天道留给你的补偿。']));list.push({code:355,indent:0,parameters:['CodexZhenqi.finishEnvoy()']},{code:0,indent:0,parameters:[]});$gameMap._interpreter.setup(list,0);return true;
 };
 var envoyMapUpdate=Scene_Map.prototype.update;
 Scene_Map.prototype.update=function(){Z.startEnvoy(this);return envoyMapUpdate.apply(this,arguments);};
 var envoyTerminate=Scene_Map.prototype.terminate;
 Scene_Map.prototype.terminate=function(){Z.clearEnvoy(this);return envoyTerminate.apply(this,arguments);};

 // 【Claude·未经Codex检验】v0.37：心魔／天劫瓶颈之战、神兵试炼及可指定本命兵武器的Boss显示MOG首领血条。
 // 只走显示层：不改Moghunter.boss_list与_bosshp_meter，难度、AI、饿狼首领战计数等规则不变。
 Z.bossHpEnemy=function(enemyId){var e=$dataEnemies&&$dataEnemies[enemyId];if(!e)return false;
  if(Z.WEAPON_BOSS[enemyId]||/<CodexZhenqi:\s*weapon\s+\d+>/.test(e.note||''))return true;
  return [Z.TRIAL_TROOP,Z.HEART_TROOP].some(function(map){return Object.keys(map).some(function(k){var t=$dataTroops&&$dataTroops[map[k]];return !!(t&&t.members.some(function(m){return m.enemyId===enemyId;}));});});};
 var _zqEnemySetup=Game_Enemy.prototype.setup;
 Game_Enemy.prototype.setup=function(enemyId){var out=_zqEnemySetup.apply(this,arguments);this._codexZqBossHp=!this._bosshp_meter&&Z.bossHpEnemy(enemyId);return out;};
 if(Game_System.prototype.checkBossHpEnemies){
  var _zqBossHud=Game_System.prototype.checkBossHpEnemies;
  Game_System.prototype.checkBossHpEnemies=function(){var boss=_zqBossHud.apply(this,arguments);if(boss)return boss;
   $gameTroop.members().forEach(function(e){if(e._codexZqBossHp&&!e.isHidden())boss=e;});return boss;};
  var _zqBossApply=Game_Action.prototype.apply;
  Game_Action.prototype.apply=function(target){var mark=!!(target&&target.isEnemy&&target.isEnemy()&&target._codexZqBossHp&&!target._bosshp_meter),old=mark?target.hp:0;
   if(mark){$gameTemp._battler_bhp_temp[1]=target.hp;$gameTemp._battler_bhp_temp[3]=0;}
   var out=_zqBossApply.apply(this,arguments);
   if(mark){$gameTemp._battler_bhp_temp[0]=target;if(old>target.hp)$gameTemp._battler_bhp_temp[3]=80;}return out;};
  var _zqSmallGauge=Game_Enemy.prototype.hpGaugeVisible;
  if(_zqSmallGauge)Game_Enemy.prototype.hpGaugeVisible=function(){if(this._codexZqBossHp)return false;return _zqSmallGauge.apply(this,arguments);};
 }

 return Z;
});
