/* v0.58：深渊异化全部隐藏。
 *
 * 加载顺序必须在 installAlienationRuntime / Affixes / Advanced / Workshop 之后。
 * 本文件只做四件事：
 *   1. 关掉异化遭遇与异化奖励（A.setupEncounter / A.grant）；
 *   2. 主菜单去掉「异化工坊」；
 *   3. 六件相关物品不可获得、不可见、不可装备；
 *   4. 读档时把已有 _alien 实例恢复为普通装备，并把相关物品原位归档。
 *
 * 旧档迁移只跑一次，标记写在 $gameSystem._alienHiddenV058 上。
 * 不删除独立装备对象；残响装备保留在队伍容器里并标记 _codexAlienHiddenV058。
 */
function installAlienationHide(A, W) {
  'use strict';
  W = W || window;
  var DM = W.DataManager;
  var GP = W.Game_Party;
  var GA = W.Game_Actor;
  var H = W.CodexAlienationHide = W.CodexAlienationHide || {};

  H.version = '1.0.0';
  H.itemIds = [2872, 2873];
  H.weaponBaseIds = [3980, 3981];
  H.armorBaseIds = [7980, 7981];
  H.gearBaseIds = H.weaponBaseIds.concat(H.armorBaseIds);
  H.marker = '_alienHiddenV058';
  H.hiddenFlag = '_codexAlienHiddenV058';
  H.restoredFlag = '_codexAlienRestoredV058';

  function alias(obj, key, fn) {
    if (!obj || typeof obj[key] !== 'function') return false;
    var old = obj[key];
    obj[key] = function () {
      return fn.call(this, old, Array.prototype.slice.call(arguments));
    };
    return true;
  }
  function db(kind) {
    return W[kind === 'weapon' ? '$dataWeapons' : '$dataArmors'] || [];
  }
  function baseId(item) {
    return Number(item && (item.originalBaseItemId || item.baseItemId || item.id));
  }
  function isItem(item) {
    return !!(item && DM && DM.isItem && DM.isItem(item));
  }
  function isGear(item) {
    return !!(item && DM && ((DM.isWeapon && DM.isWeapon(item)) || (DM.isArmor && DM.isArmor(item))));
  }
  function kindOf(item) {
    return item && item.wtypeId !== undefined ? 'weapon' : 'armor';
  }
  function markHidden(item) {
    try { item[H.hiddenFlag] = true; } catch (e) { /* Ignore frozen objects. */ }
  }
  // 归档数量/记录真正写进 $gameParty，多次迁移只累加、不覆盖。
  function stash(party, key, value) {
    if (value === undefined || value === null) return;
    if (Array.isArray(value)) {
      party[key] = (party[key] || []).concat(value);
    } else {
      party[key] = party[key] || {};
      Object.keys(value).forEach(function (id) {
        party[key][id] = (Number(party[key][id]) || 0) + Number(value[id] || 0);
      });
    }
  }

  H.baseId = baseId;
  H.isHiddenItem = function (item) {
    return isItem(item) && H.itemIds.indexOf(Number(item.id)) >= 0;
  };
  H.isHiddenGear = function (item) {
    return isGear(item) && H.gearBaseIds.indexOf(baseId(item)) >= 0;
  };
  H.isHidden = function (item) {
    return H.isHiddenItem(item) || H.isHiddenGear(item);
  };

  // 异化装备可能带的运行时字段；读档时一次性清掉，避免战斗钩子残留。
  var ACTOR_RUNTIME = [
    '_alienBattle', '_alienReceivedEffects', '_alienLife', '_alienProtector',
    '_alienPossessedBy', '_alienJail', '_alienJailBuff', '_alienWish',
    '_alienWishBuff', '_alienSeals', '_alienReleaseSeals', '_alienSealCheck',
    '_alienSilenceSkill', '_alienLastSkill', '_alienStateRevision',
    '_alienDeathSync', '_alienCorrosionUntil', '_alienCorrosionTick',
    '_codexAlienSupplies'
  ];

  function alienStateIds() {
    var out = [2652];
    var t = A && A.config && A.config.templates && A.config.templates.statePairs;
    if (t) Object.keys(t).forEach(function (k) { out.push(Number(t[k])); });
    return out;
  }

  function refreshActor(a) {
    try {
      if (A && typeof A.refreshGear === 'function') A.refreshGear(a);
      if (a && typeof a.refresh === 'function') a.refresh();
      if (a && typeof a.initPassiveCache === 'function') a.initPassiveCache();
      if (a && typeof a.refreshPassiveCache === 'function') a.refreshPassiveCache();
    } catch (e) { /* A refresh hook must not abort the migration. */ }
  }

  function clearActor(a, report) {
    if (!a) return false;
    var changed = false;
    ACTOR_RUNTIME.forEach(function (k) {
      if (a[k] !== undefined && a[k] !== null) { a[k] = null; changed = true; }
    });
    Object.keys(a).forEach(function (k) {
      if (k.indexOf('_alien') === 0 && k !== '_alienLedger') {
        try { delete a[k]; changed = true; } catch (e) { a[k] = null; changed = true; }
      }
    });
    try {
      if (a.isStateAffected) {
        alienStateIds().forEach(function (id) {
          if (a.isStateAffected(id)) {
            try { a.removeState(id); changed = true; } catch (e) { /* Battle-only state. */ }
          }
        });
      }
    } catch (e) { /* Ignore state cleanup failures. */ }
    if (changed) {
      report.actors++;
      refreshActor(a);
    }
    return changed;
  }

  function restoreAlien(item, report) {
    if (!item || !item._alien) return false;
    var m = item._alien || {};
    var name = String(item.name || '');
    var plain = m.plainName;
    if (!plain) {
      plain = name.replace(/^(逆骨|祸祝|百相|逆祷|疫囊|无面|空壳|连命|吞器|夺舍|绝缘|舍身|嫁祸|缄默|恶愿|献器|囚厄|饕餮|蚀术|归墟)·/, '');
    }
    item.name = String(plain || name);
    item.note = String(item.note || '')
      .replace(/\n?<AlienationDescription>[\s\S]*?<\/AlienationDescription>/g, '')
      .replace(/\n?<AlienationDescription>[\s\S]*$/, '');
    try { delete item._alien; } catch (e) { item._alien = null; }
    try { delete item._alienBound; } catch (e) { item._alienBound = null; }
    item[H.restoredFlag] = 1;
    report.restored.push({ id: item.id, baseId: baseId(item), name: item.name });
    return true;
  }

  function ensurePartyItem(party, kind, item) {
    var key = kind === 'weapon' ? '_weapons' : '_armors';
    party[key] = party[key] || {};
    if (!party[key][item.id]) party[key][item.id] = 1;
    markHidden(item);
    return party[key][item.id];
  }

  function archiveItemStacks(party, report) {
    var items = party._items = party._items || {};
    H.itemIds.forEach(function (id) {
      var n = Number(items[id]) || 0;
      if (n <= 0) return;
      report.items[id] = (report.items[id] || 0) + n;
      delete items[id];
    });
  }

  function scanGearContainer(party, report) {
    ['weapon', 'armor'].forEach(function (kind) {
      var key = kind === 'weapon' ? '_weapons' : '_armors';
      var source = party[key] || {};
      Object.keys(source).forEach(function (id) {
        var item = db(kind)[id];
        if (!item) return;
        if (item._alien) restoreAlien(item, report);
        if (!H.isHiddenGear(item)) return;
        markHidden(item);
        var b = baseId(item);
        report.gear[kind][b] = (report.gear[kind][b] || 0) + 1;
      });
    });
  }

  function scanActors(party, report) {
    var actors = (W.$gameActors && W.$gameActors._data) || [];
    actors.forEach(function (a) {
      if (!a || !a._equips) return;
      var unequipped = false;
      a._equips.forEach(function (ref, slot) {
        var item = null;
        try { item = ref && ref.object ? ref.object() : null; } catch (e) { item = null; }
        if (!item) return;
        if (item._alien) restoreAlien(item, report);
        if (!H.isHiddenGear(item)) return;
        var kind = kindOf(item);
        report.equips.push({
          actorId: a.actorId ? a.actorId() : null, slot: slot,
          itemId: item.id, baseId: baseId(item), name: item.name
        });
        ensurePartyItem(party, kind, item);
        if (ref && ref.setObject) ref.setObject(null);
        unequipped = true;
      });
      var changed = clearActor(a, report);
      // 只穿残响、身上没有异化字段时 clearActor 不会算 changed；卸下也必须刷新被动缓存。
      if (unequipped && !changed) {
        report.actors++;
        refreshActor(a);
      }
    });
  }

  function scanWarehouse(party, report) {
    var ph = W.PHPlugins && W.PHPlugins.PHWarehouse;
    var all = ph && ph._warehouses || {};
    Object.keys(all).forEach(function (title) {
      var wh = all[title];
      if (!wh || !wh.items) return;
      ['item', 'weapon', 'armor'].forEach(function (cat) {
        var ids = wh.items[cat] || [];
        var qtty = (wh.qtty && wh.qtty[cat]) || {};
        var bases = (wh.base && wh.base[cat]) || {};
        for (var i = ids.length - 1; i >= 0; i--) {
          var id = Number(ids[i]);
          var item = cat === 'item'
            ? (W.$dataItems && W.$dataItems[id])
            : db(cat)[id];
          var b = item ? baseId(item) : Number(bases[id]);
          var hidden = cat === 'item' ? H.itemIds.indexOf(id) >= 0 : H.gearBaseIds.indexOf(b) >= 0;
          if (!hidden) continue;
          var n = Math.max(1, Number(qtty[id]) || 1);
          report.warehouse.push({ title: title, category: cat, itemId: id, baseId: b, count: n });
          if (cat === 'item') {
            report.items[id] = (report.items[id] || 0) + n;
          } else if (item) {
            ensurePartyItem(party, cat, item);
          }
          ids.splice(i, 1);
          delete qtty[id];
          delete bases[id];
          if (wh.currentCapacity) wh.currentCapacity = Math.max(0, Number(wh.currentCapacity) - n);
        }
      });
    });
  }

  H.migrate = function () {
    var sys = W.$gameSystem;
    var party = W.$gameParty;
    if (!sys || !party) return null;
    if (sys[H.marker]) return null;
    var report = {
      items: {}, gear: { weapon: {}, armor: {} }, equips: [], warehouse: [],
      restored: [], actors: 0, pending: false
    };
    // 1. 先把全库独立实例里的 _alien 恢复成普通装备。
    [(DM && DM._independentWeapons) || [], (DM && DM._independentArmors) || []].forEach(function (list) {
      list.forEach(function (item) { if (item) restoreAlien(item, report); });
    });
    // 2. 背包里的普通物品、残响装备。
    archiveItemStacks(party, report);
    // 3. 角色身上：恢复后卸下残响，放回队伍容器归档。
    scanActors(party, report);
    // 4. 仓库：残响移入队伍容器归档；能量/石头记数量后移出。
    scanWarehouse(party, report);
    // 5. 队伍容器里的残响全部标记隐藏并计数。
    scanGearContainer(party, report);
    // 6. 待选重抽结果清掉；最近掉落记录保留。
    if (sys._alienLedger && sys._alienLedger.pending) {
      sys._alienLedger.pending = null;
      report.pending = true;
    }
    // 7. 归档结果写进 $gameParty；累加，不覆盖。
    stash(party, '_codexAlienHiddenItems', report.items);
    stash(party, '_codexAlienHiddenEquip', report.equips);
    stash(party, '_codexAlienHiddenWarehouse', report.warehouse);
    sys[H.marker] = 1;
    return report;
  };

  // ---- 1. 不再产生异化遭遇 / 奖励 ----
  A.setupEncounter = function () { return null; };
  A.grant = function () { return false; };
  A.encounter = function () { return null; };
  A.openWorkshop = function () { return false; };
  A.closeWorkshop = function () {};

  // ---- 2. 主菜单不再出现「异化工坊」 ----
  if (W.Window_MenuCommand && W.Window_MenuCommand.prototype) {
    alias(W.Window_MenuCommand.prototype, 'makeCommandList', function (old, args) {
      var out = old.apply(this, args);
      this._list = (this._list || []).filter(function (c) {
        return !(c && (c.symbol === 'alienation' || c.name === '异化工坊'));
      });
      return out;
    });
  }

  // ---- 3. 六件物品不可获得 / 不可见 / 不可装备 ----
  if (GP && GP.prototype) {
    alias(GP.prototype, 'gainItem', function (old, args) {
      if (Number(args[1]) > 0 && H.isHidden(args[0])) return;
      return old.apply(this, args);
    });
    alias(GP.prototype, 'items', function (old, args) {
      return old.apply(this, args).filter(function (item) { return !H.isHidden(item); });
    });
    alias(GP.prototype, 'weapons', function (old, args) {
      return old.apply(this, args).filter(function (item) { return !H.isHidden(item); });
    });
    alias(GP.prototype, 'armors', function (old, args) {
      return old.apply(this, args).filter(function (item) { return !H.isHidden(item); });
    });
    alias(GP.prototype, 'hasItem', function (old, args) {
      if (H.isHidden(args[0])) return false;
      return old.apply(this, args);
    });
  }
  if (GA && GA.prototype) {
    alias(GA.prototype, 'canEquip', function (old, args) {
      return !H.isHiddenGear(args[0]) && old.apply(this, args);
    });
    ['changeEquip', 'forceChangeEquip'].forEach(function (key) {
      alias(GA.prototype, key, function (old, args) {
        if (H.isHiddenGear(args[1])) return false;
        return old.apply(this, args);
      });
    });
  }
  if (W.Window_ShopBuy && W.Window_ShopBuy.prototype) {
    alias(W.Window_ShopBuy.prototype, 'isEnabled', function (old, args) {
      return !H.isHidden(args[0]) && old.apply(this, args);
    });
    alias(W.Window_ShopBuy.prototype, 'makeItemList', function (old, args) {
      var out = old.apply(this, args);
      var data = [], prices = [];
      (this._data || []).forEach(function (item, i) {
        if (!H.isHidden(item)) { data.push(item); prices.push(this._price[i]); }
      }, this);
      this._data = data;
      this._price = prices;
      return out;
    });
  }
  if (W.Window_ShopSell && W.Window_ShopSell.prototype) {
    alias(W.Window_ShopSell.prototype, 'isEnabled', function (old, args) {
      return !H.isHidden(args[0]) && old.apply(this, args);
    });
  }
  if (W.DreamX && W.DreamX.RandomPrefixSuffix) {
    alias(W.DreamX.RandomPrefixSuffix, 'isValidItem', function (old, args) {
      return !H.isHidden(args[0]) && old.apply(this, args);
    });
  }

  // ---- 4. 读档迁移：只在 DataManager.extractSaveContents 之后跑一次 ----
  if (DM && typeof DM.extractSaveContents === 'function') {
    alias(DM, 'extractSaveContents', function (old, args) {
      var out = old.apply(this, args);
      try { H.migrate(); } catch (e) {
        if (W.console && W.console.error) W.console.error('[alien-hide] migration failed', e);
      }
      return out;
    });
  }

  A.hideInstalled = true;
  return H;
}

window.CodexRuntime.register('installAlienationHide', function () {
  'use strict';
  if (!window.CodexAlienation) return null;
  if (window.CodexAlienation.hideInstalled) return window.CodexAlienation;
  return installAlienationHide(window.CodexAlienation, window);
});
