// 【Codex·未经Claude检验】核查状态：未经claude检验。2026-10-11 主动支援与持武指令去重，以当前正式Mac版维护。
// 本轮维护源：tusu-active-support-20261011-025323/game；禁止用旧安装器覆盖。
// 历史来源为 install_xuan_tusu.py；后续以最新正式版为基准按本轮清单增量合并。
window.CodexRuntime.register("installNativeTusuRuntime", function() {
var CFG = {"ai":{"hurt":0.4,"shieldBelow":0.5},"armActions":2,"armWeapon":{"chiling":"book","dianshe":"bow","guanri":"bow","hengsao":"sword","zhanfeng":"sword","zhenji":"hammer"},"bodyGuard":{"rate":0.5,"turns":2},"book":{"mpRate":0.7},"coef":{"hemingRate":1.5,"huzhenRate":0.7,"lockRate":1.5},"cuoshi":{"hyperRate":0.7,"rate":0.8},"devour":{"rate":3},"dmg":{"body_mag":18,"body_phys":30,"chiling":50,"dianshe":36,"guanri":108,"hengsao":30,"jianqi":33,"zhanfeng":36,"zhenhun":36,"zhenji":25},"floor":{"shield":1.0},"growth":{"damage":{"body_mag":[1800.0,3600.0,6300.0,9000.0,11700.0,15000.0,18000],"body_phys":[3000.0,6000.0,10500.0,15000.0,19500.0,23500.0,30000],"chiling":[5000.0,10000.0,17500.0,25000.0,32500.0,39500.0,50000],"dianshe":[3600.0,7200.0,12600.0,18000.0,23500.0,28800.0,36000],"guanri":[10800.0,21600.0,37800.0,53500.0,70200.0,86500.0,108000],"hengsao":[3000.0,6000.0,10500.0,15000.0,19500.0,23500.0,30000],"jianqi":[3300.0,6600.0,11550.0,16500.0,21500.0,26500.0,33000],"zhanfeng":[3600.0,7200.0,12600.0,18000.0,23500.0,28800.0,36000],"zhenhun":[3600.0,7200.0,12600.0,18000.0,23500.0,28800.0,36000],"zhenji":[2500.0,5000.0,8750.0,12500.0,16250.0,20000.0,25000]},"identity":[1,3,6,11],"levels":[1,10,20,30,40,50,60],"names":["余火淬锋","五相铭文","神兵成器"],"passives":["growth.35","growth.50","growth.70"],"unlock":{"arm.hengsao":10,"arm.guanri":20,"support.jianqi":5,"support.suoding":15,"support.jintang":25,"support.heming":30,"support.zhenhun":35,"growth.35":1,"growth.50":20,"growth.70":40}},"jintang":{"def":30,"hp":5,"targetRate":0.3,"turns":2},"kairen":{"swordDebuffTurns":2},"lines":{"devour":"屠苏：「魔力不够了——借你的。」","devourFail":"屠苏：「你也撑不住了……先放开我。」","fallen":"屠苏：「……起来。我还没认可你呢。」","huawu":"屠苏：「握稳。我不喜欢掉在地上。」","reserve":"下回合形态：%s","ret":"屠苏：「换个人。别误会，不是你不好。」","support":"屠苏：「这一下，我自己来。」","yiwu_book":"屠苏：「书。字念对，别念错。」","yiwu_bow":"屠苏：「弓。看准了再松手。」","yiwu_hammer":"屠苏：「锤。砸它的势，不必砸它的命。」","yiwu_shield":"屠苏：「盾。站到我后面。」","yiwu_sword":"屠苏：「剑。放开了砍。」"},"magicKeys":["body_mag"],"mpRate":{"arm.chiling":0.06,"arm.dianshe":0.05,"arm.guanri":0.1,"arm.hengsao":0.1,"arm.huzhen":0.1,"arm.zhanfeng":0.05,"arm.zhenji":0.1,"body.guard":0.1,"body.mag":0.06,"body.phys":0.05,"support.heming":0.06,"support.jianqi":0.06,"support.jintang":0.12,"support.suoding":0.06,"support.zhenhun":0.1},"names":{"book":"书","bow":"弓","forgeInfo":"每次进阶可为一种形态开刃，最多三种；重新开刃消耗人道意志碎片×10","forgePick":"第%d种形态：选择开刃的形态","forgeTitle":"器谱　开刃 %d/3","hammer":"锤","kairenDesc_book":"和鸣增幅一次治疗或护盾法术；仍支付支援费用","kairenDesc_bow":"贯日击杀目标时返还锁定","kairenDesc_hammer":"伤害降低可叠到2层","kairenDesc_shield":"霸体回合主动施放金汤时，护盾量额外提高20%","kairenDesc_sword":"剑气纵横附带群体破防","kairen_book":"开刃·书","kairen_bow":"开刃·弓","kairen_hammer":"开刃·锤","kairen_shield":"开刃·盾","kairen_sword":"开刃·剑","shield":"盾","sword":"剑"},"reforge":[2530,10],"relicBonus":{"firstCharge":0,"support":1},"stunState":29,"supportRate":{"m":2.7,"r":0.5},"version":"0.4.0"};
/* 【最终兵器】屠苏：五相武具、主动支援、噬主、开刃与器谱、专属法宝止戈环。
 * 依赖：installNativeBindingChargeRuntime（形态绑定与行动充能）、installSourceShieldLedgerRuntime（来源护盾账本）。
 * 所有记录按备注标签 <CodexTusu: 键> 查找；CFG 由安装器从 tusu_design.json 写入。
 */
(function(W, CFG) {
'use strict';
CFG.version = '0.4.1-active-support';
if (W.CodexTusu) return;
var T = W.CodexTusu = {version: CFG.version, config: CFG};
var WEAPONS = ['sword', 'bow', 'shield', 'book', 'hammer'];
T.WEAPONS = WEAPONS;
function num(v) { v = Number(v); return isFinite(v) ? v : 0; }
function alias(o, k, f) { var prev = o[k]; o[k] = function() { return f.call(this, prev, arguments); }; }
function tagOf(r) { var m = r && (r.note || '').match(/<CodexTusu:\s*([^>]+)>/); return m ? m[1].trim() : ''; }
function sharedTag(r) { var m = r && (r.note || '').match(/<CodexBind:\s*([^>]+)>/); return m ? m[1].trim() : ''; }
var cache = null;
function ids() {
  if (cache && cache.db === W.$dataSkills) return cache;
  var out = {db: W.$dataSkills, skill: {}, state: {}, key: {}, actor: 0, cls: 0, relic: 0, horn: 0, ce: {}};
  (W.$dataSkills || []).forEach(function(s) { var k = tagOf(s); if (k) { out.skill[k] = s.id; out.key[s.id] = k; } });
  (W.$dataStates || []).forEach(function(s) { var k = tagOf(s); if (k) out.state[k] = s.id; var b = sharedTag(s); if (b === 'empty') out.state.empty = s.id; });
  (W.$dataActors || []).forEach(function(a) { if (tagOf(a) === 'actor') out.actor = a.id; });
  (W.$dataArmors || []).forEach(function(a) { if (!out.relic && tagOf(a) === 'relic') out.relic = a.id; });
  (W.$dataItems || []).forEach(function(i) { if (tagOf(i) === 'horn') out.horn = i.id; });
  (W.$dataCommonEvents || []).forEach(function(e) { if (!e) return; (e.list || []).forEach(function(c) { if (c.code === 108 && /<CodexTusu:\s*ce\.(\w+)>/.test(c.parameters[0] || '')) out.ce[RegExp.$1] = e.id; }); });
  cache = out;
  return out;
}
T.ids = ids;
T.status = function() {
  var i = ids(), need = ['actor'], miss = [];
  if (!i.actor) miss.push('actor');
  ['return', 'menu.forge'].concat(WEAPONS.map(function(w) { return 'yiwu.' + w; }), WEAPONS.map(function(w) { return 'huawu.' + w; }),
    ['arm.zhanfeng', 'arm.hengsao', 'arm.dianshe', 'arm.guanri', 'arm.huzhen', 'arm.chiling', 'arm.zhenji',
     'support.jianqi', 'support.suoding', 'support.jintang', 'support.heming', 'support.zhenhun']).forEach(function(k) { if (!i.skill[k]) miss.push('skill.' + k); });
  ['armed', 'empty', 'lock', 'heming', 'huzhen', 'cuoshi', 'cuoshi2'].concat(WEAPONS.map(function(w) { return 'hold.' + w; }), WEAPONS.map(function(w) { return 'reserve.' + w; }))
    .forEach(function(k) { if (!i.state[k]) miss.push('state.' + k); });
  return {ok: !miss.length, missing: miss};
};
function isTusu(a) { return !!(a && a.isActor && a.isActor() && a.actorId() === ids().actor); }
T.isTusu = isTusu;
function tusu() { return $gameParty.battleMembers().filter(isTusu)[0] || null; }
function B() { return W.CodexBinding; }
function stage(a) { return Math.max(0, Math.min(3, Math.floor(num(a && a._AdvancedNum)))); }
function kairen(a) { return (a && a._codexTusuKairen) || []; }
T.kairen = kairen;
function hasKairen(w) { var t = tusu(); return !!(t && kairen(t).indexOf(w) >= 0 && kairen(t).indexOf(w) < stage(t)); }
// ---- 本场武具数据 ----
function data(a) { return a && a._codexTusu; }
function weapon(a) { var d = data(a); return d && d.weapon; }
T.weapon = weapon;
function holder(a) { return B() && B().host(a); }
T.holder = holder;
function weaponOfHost(host) { var t = tusu(); return t && holder(t) === host ? weapon(t) : null; }
T.weaponOfHost = weaponOfHost;
function holdState(w) { return ids().state['hold.' + w]; }
function setHold(host, w) {
  WEAPONS.forEach(function(x) { var id = holdState(x); if (id && host.isStateAffected(id) && x !== w) host.removeState(id); });
  if (w) { var id = holdState(w); if (id && !host.isStateAffected(id)) host.addState(id); }
  host.refresh();
}
function setReserve(a, w) {
  var d = data(a); if (!d) return;
  d.reserve = w;
  WEAPONS.forEach(function(x) { var id = ids().state['reserve.' + x]; if (!id) return; if (x === w && w !== d.weapon) { if (!a.isStateAffected(id)) a.addState(id); } else if (a.isStateAffected(id)) a.removeState(id); });
}
function clearHostStates(host) {
  if (!host) return;
  WEAPONS.forEach(function(x) { var id = holdState(x); if (id && host.isStateAffected(id)) host.removeState(id); });
  ['lock', 'heming'].forEach(function(k) { var id = ids().state[k]; if (id && host.isStateAffected(id)) host.removeState(id); });
  delete host._codexTusuLock;
  host.refresh();
}
// ---- 属性基准：只由屠苏提供（只补底、不叠加） ----
// 本作角色物攻跨度极大（70级约 200～50 万），按 max(持武者, k×屠苏) 取值时几乎都取到持武者，超强者持武会爆炸。
// 所以武装基准只读屠苏：弱者被抬到屠苏的水平，超强者自身技能更强、不获属性收益（方案 1.1 的本意）。
T.base = function(host, w) {
  var t = tusu();
  if (!t) return 0;
  return w === 'book' ? num(t.mat) : num(t.atk);
};
// 面板公式：伤害＝屠苏物攻（或魔攻）×当前等级系数。成长被动进入原生增伤乘区。之后交给统一伤害（防御比例、暴击、加成）。
T.coefficient = function(key) { return Math.round(B().curve(tusu(), CFG.growth.damage[key] || [0,0,0,0])); };
T.damage = function(a, b, key) {
  var w = CFG.armWeapon[key];
  if (w) return T.base(a, w) * T.coefficient(key);
  var t = isTusu(a) ? a : tusu(); if (!t) return 0;
  var magic = CFG.magicKeys.indexOf(key) >= 0;
  return (magic ? num(t.mat) : num(t.atk)) * T.coefficient(key);
};
// ---- 专属法宝止戈环：装备时支援伤害、金汤护盾×CFG.relicBonus.support；第一回合兵势＋1 ----
function baseId(item) { return item ? Number(item.originalBaseItemId || item.baseItemId || item.id) : 0; }
function relicOn(t) { var id = ids().relic; return !!(t && id && t.equips().some(function(e) { return e && baseId(e) === id; })); }
T.relicOn = relicOn;
// ---- 噬主：屠苏的技能先用屠苏自己的魔法；不足时改由持武者支付（比例×噬主倍率，按持武者最大魔法）；仍不足时屠苏回归人形 ----
function costRate(key) { return num(CFG.mpRate[key]); }
function ownCost(t, key) { return B().percentMpCost(t, $dataSkills[ids().skill[key]], costRate(key)); }
function devourCost(h, key) { return B().percentMpCost(h, $dataSkills[ids().skill[key]], costRate(key) * CFG.devour.rate); }
T.ownCost = ownCost; T.devourCost = devourCost;
// 返回本次由谁付：'tusu'（屠苏自付）、'host'（噬主，持武者付）、null（都付不起）。
T.payer = function(key) {
  var t = tusu(); if (!t) return null;
  if (num(t.mp) >= ownCost(t, key)) return 'tusu';
  var h = B() && B().isBound(t) ? holder(t) : null;
  if (h && h.isAlive() && num(h.mp) >= devourCost(h, key)) return 'host';
  return null;
};
// 维持：当前武相的技能（武装技能与支援）屠苏和持武者都付不起时，无法维持武具态。host 省略时取当前持武者。
var ARM_OF = {sword: ['arm.zhanfeng', 'arm.hengsao'], bow: ['arm.dianshe', 'arm.guanri'], shield: ['arm.huzhen'], book: ['arm.chiling'], hammer: ['arm.zhenji']};
T.canMaintain = function(w, host) {
  var t = tusu(); if (!t || !w) return false;
  var h = host || holder(t), keys = ARM_OF[w].concat(['support.' + SUPPORT_OF[w]]);
  return keys.some(function(k) { return num(t.mp) >= ownCost(t, k) || (h && h.isAlive() && num(h.mp) >= devourCost(h, k)); });
};
function devourFail(t) {
  if (!t || !B() || !B().isBound(t)) return false;
  log(CFG.lines.devourFail);
  return B().unbind(t, 'devour');
}
T.devourFail = devourFail;
// ---- 绑定登记 ----
function registerBinding() {
  if (!B() || B().kinds.tusu) return;
  B().register('tusu', {
    isOwner: isTusu,
    // Tusu keeps her own paid action slots for support/change/return.
    // No simultaneous conversion into automatic support charges.
    manual: function() { return true; },
    get formState() { return ids().state.armed; },
    get emptyState() { return ids().state.empty; },
    onBind: function(owner, host, reason) {
      var d = owner._codexTusu = owner._codexTusu || {};
      var w = d.pendingWeapon || d.weapon || owner._codexTusuLast || 'sword';
      delete d.pendingWeapon;
      d.weapon = w; owner._codexTusuLast = w; setReserve(owner, null);
      setHold(host, w);
      if (reason !== 'opening') log(CFG.lines.huawu);
    },
    onUnbind: function(owner, host, reason) {
      clearHostStates(host);
      var d = data(owner); if (d) { setReserve(owner, null); }
      if (reason === 'death-host') log(CFG.lines.fallen);
      else if (reason === 'return') log(CFG.lines.ret);
      if (W.CodexTusuDevour) W.CodexTusuDevour.unbind = (W.CodexTusuDevour.unbind || 0) + (reason === 'devour' ? 1 : 0);
    },
    onRoundStart: function(owner) {
      var d = data(owner); if (!d) return;
      if (d.reserve && d.reserve !== d.weapon) { d.weapon = d.reserve; owner._codexTusuLast = d.weapon; setHold(holder(owner), d.weapon); log(CFG.lines['yiwu_' + d.weapon]); }
      setReserve(owner, null);
      d.supported = {};
      var h = holder(owner); d.hostActions = h && h._actions ? Math.max(1, h._actions.length) : 1;
      if (B().round() === 1 && relicOn(owner) && owner.canMove()) B().gain(owner, CFG.relicBonus.firstCharge);
      // 维持：屠苏付不起当前武相的支援、持武者也付不起噬主费用时，无法维持武具态。
      if (!T.canMaintain(d.weapon)) { devourFail(owner); return; }
    },
    onRoundEnd: function(owner) { roundEndRelease(owner); },
    chargeCounter: function(owner, n) { owner._codexTusuCharges = n; },
    onClear: function(a) { delete a._codexTusu; delete a._codexTusuCharges; }
  });
}
function log(text) { var w = BattleManager._logWindow; if (text && w && w.push) w.push('addText', text); }
function bossHyperRound() {
  var D = W.CodexBossDifficulty;
  return !!(D && $gameTroop.aliveMembers().some(function(e) { return D.isBoss(e) && D.hasHyperArmor(e); }));
}
// ---- 武相主动支援；保留内部支援接口供其他结算引用 ----
var SUPPORT_OF = {sword: 'jianqi', bow: 'suoding', shield: 'jintang', book: 'heming', hammer: 'zhenhun'};
T.supportSkill = function(a) {
  return isTusu(a) && B() && B().isBound(a) ? $dataSkills[ids().skill['support.' + SUPPORT_OF[weapon(a)]]] : null;
};
T.shieldSupportRate = function(a) { return isTusu(a) && hasKairen('shield') && bossHyperRound() ? 1.2 : 1; };
function manualSupport(action) {
  if (!action) return null;
  var a = action && action.subject(), item = action && action.item(), key = item && ids().key[item.id];
  return !action._codexInternal && isTusu(a) && key && key.indexOf('support.') === 0 ? key.slice(8) : null;
}
// Lock targets an enemy in the selection UI, but applies the existing lock
// effect to the wielder. Heming always supports the actual wielder.
alias(Game_Action.prototype, 'isForOpponent', function(old, args) {
  return manualSupport(this) === 'suoding' || old.apply(this, args);
});
alias(Game_Action.prototype, 'isForFriend', function(old, args) {
  return manualSupport(this) === 'suoding' ? false : old.apply(this, args);
});
alias(Game_Action.prototype, 'needsSelection', function(old, args) {
  var key = manualSupport(this);
  if (key === 'heming') return false;
  return key === 'suoding' || old.apply(this, args);
});
alias(Game_Action.prototype, 'makeTargets', function(old, args) {
  var key = manualSupport(this), a = this.subject();
  if (!key) return old.apply(this, args);
  var skill = T.supportSkill(a), h = holder(a);
  if (!skill || skill.id !== this.item().id || !h || !h.isAlive()) return [];
  if (key === 'heming') return this.repeatTargets([h]);
  if (key === 'suoding') {
    var enemy = $gameTroop.smoothTarget(this._targetIndex);
    if (!enemy || !enemy.isAlive()) return [];
    this._codexTusuLockTarget = enemy;
    return this.repeatTargets([h]);
  }
  var targets = old.apply(this, args);
  return key === 'jintang' ? targets.filter(function(t) { return !B().untargetable(t); }) : targets;
});
alias(BattleManager, 'startAction', function(old, args) {
  var a = this._subject, action = a && a.currentAction(), key = manualSupport(action), d = data(a);
  if (key && d) {
    d.trigger = 0; // Active support uses its own base, with no stale host hit.
    action._codexTusuSupportBonus = T.supportBonus(a, key);
  }
  return old.apply(this, args);
});
alias(BattleManager, 'endAction', function(old, args) {
  var action = this._action, a = this._subject, key = manualSupport(action), d = data(a);
  if (key && d && action._codexTusuResultSuccessful) d.growthSupportRound = B().round();
  return old.apply(this, args);
});
// Keep the native categories and handlers, deduplicating only the wielder's
// repeated category IDs. Do not merge unrelated commands by displayed name.
// Native attack replacement can cache 0 while form states are being rebuilt.
// A bound Tusu always uses Return in this slot, including after wielder actions.
alias(Game_Actor.prototype, 'attackSkillId', function(old, args) {
  return isTusu(this) && W.$gameParty && $gameParty.inBattle() && B().isBound(this) ? ids().skill['return'] : old.apply(this, args);
});
alias(Game_Actor.prototype, 'addedSkillTypes', function(old, args) {
  var rows = old.apply(this, args);
  return W.$gameParty && $gameParty.inBattle() && weaponOfHost(this) ? rows.filter(function(id, at) { return rows.indexOf(id) === at; }) : rows;
});
alias(Window_ActorCommand.prototype, 'addSkillCommands', function(old, args) {
  if (isTusu(this._actor) && B().isBound(this._actor)) {
    this._skillTypes = [1];
    this.addCommand('易武', 'skill', true, 1); return;
  }
  return old.apply(this, args);
});
alias(Window_ActorCommand.prototype, 'makeCommandList', function(old, args) {
  var out = old.apply(this, args), a = this._actor;
  if (a && weaponOfHost(a)) {
    var seen = {};
    this._list = this._list.filter(function(row) {
      if (row.symbol !== 'skill') return true;
      var key = String(row.ext); if (seen[key]) return false; seen[key] = true; return true;
    });
  }
  if (isTusu(a) && B().isBound(a)) {
    var skill = T.supportSkill(a), row = {name: skill ? skill.name : '屠苏的支援', symbol: 'codexTusuSupport',
      enabled: !!(skill && a.canUse(skill)), ext: skill && skill.id};
    this._list.splice(1, 0, row);
    this._list.forEach(function(c) { if (c.symbol === 'guard') c.name = '待命'; });
  }
  return out;
});
alias(Window_BattleSkill.prototype, 'includes', function(old, args) {
  var s = args[0], key = s && ids().key[s.id];
  if (isTusu(this._actor) && B().isBound(this._actor)) return !!(key && key.indexOf('yiwu.') === 0 && T.unlocked(this._actor, key));
  return old.apply(this, args);
});
alias(Scene_Battle.prototype, 'createActorCommandWindow', function(old, args) {
  var out = old.apply(this, args), scene = this;
  this._actorCommandWindow.setHandler('codexTusuSupport', function() {
    var a = BattleManager.actor(), skill = T.supportSkill(a), action = BattleManager.inputtingAction();
    if (!action || !skill || !a.canUse(skill)) { scene._actorCommandWindow.setup(a); return; }
    action.setSkill(skill.id); a.setLastBattleSkill(skill); scene.onSelectAction();
  });
  return out;
});
alias(Scene_Battle.prototype, 'onEnemyCancel', function(old, args) {
  var supportCommand = this._actorCommandWindow.currentSymbol() === 'codexTusuSupport';
  var out = old.apply(this, args);
  if (supportCommand) this._actorCommandWindow.activate();
  return out;
});
// Team support uses the native actor selector when selection help is enabled.
// Cancel returns to the same custom support command, as enemy cancel does.
alias(Scene_Battle.prototype, 'onActorCancel', function(old, args) {
  var supportCommand = this._actorCommandWindow.currentSymbol() === 'codexTusuSupport';
  var out = old.apply(this, args);
  if (supportCommand) this._actorCommandWindow.activate();
  return out;
});
function ready(owner, key) {
  var id = ids().skill['support.' + key], s = $dataSkills[id];
  if (!s || !T.unlocked(owner,'support.'+key) || (owner.cooldown && owner.cooldown(id) > 0)) return false;
  if (owner.canPaySkillCost(s)) return true;
  devourFail(owner); // 冷却已好但屠苏与持武者都付不起：噬主失败，回归人形
  return false;
}
function dangerEnemy() {
  var D = W.CodexBossDifficulty, foes = $gameTroop.aliveMembers();
  if (!foes.length) return null;
  return foes.slice().sort(function(x, y) {
    var bx = D && D.isBoss(x) ? 1 : 0, by = D && D.isBoss(y) ? 1 : 0;
    return by - bx || (y.atk + y.mat) - (x.atk + x.mat);
  })[0];
}
function support(owner, key, targets, setup, free) {
  var b = B(); if (!b || !targets || !targets.length || !T.unlocked(owner, 'support.'+key)) return false;
  if (!free && b.charges(owner) < 1) return false;
  if (!free && !ready(owner, key)) return false;
  var d = data(owner); if (!d) return false;
  var castAction=null,growthBonus=T.supportBonus(owner,key); var originalSetup=setup; setup=function(action){castAction=action;action._codexTusuSupportBonus=growthBonus;if(originalSetup)originalSetup(action);};
  var done = b.cast(owner, ids().skill['support.' + key], targets, {free: !!free, tag: 'tusu-support', setup: setup, text: CFG.lines.support});
  if (!done) return false;
  if (!free) b.spend(owner, 1);
  if(castAction&&castAction._codexTusuResultSuccessful&&data(owner))data(owner).growthSupportRound=B().round();
  return true;
}
function roundSupport(owner, key, free) {
  var host = holder(owner), foes = $gameTroop.aliveMembers();
  if (!host) return false;
  if (key === 'jianqi') return support(owner, 'jianqi', foes, null, free);
  if (key === 'zhenhun') { var e = dangerEnemy(); return !!e && support(owner, 'zhenhun', [e], null, free); }
  if (key === 'jintang') return support(owner, 'jintang', $gameParty.battleMembers().filter(function(x) { return x.isAlive() && !(B() && B().untargetable(x) && x !== host); }), null, free);
  if (key === 'heming') return !host.isStateAffected(ids().state.heming) && support(owner, 'heming', [host], null, free);
  if (key === 'suoding') { var t = dangerEnemy(); return !!t && !host._codexTusuLock && support(owner, 'suoding', [host], function(a) { a._codexTusuLockTarget = t; }, free); }
  return false;
}
T.roundSupport = roundSupport;
function roundEndRelease(owner) {
  var w = weapon(owner), b = B();
  if (!w || !b || b.charges(owner) < 1 || !b.isBound(owner)) return;
  var key = SUPPORT_OF[w];
  if (data(owner)) data(owner).trigger = 0; // 回合末释放没有触发行动，支援按自身基式
  roundSupport(owner, key, false);
}
// 剑：持武者完成一次主动物理伤害行动后；锤：持武者主动行动后；弓：贯日启动前；书：敕令启动前；盾：敌方确定的伤害行动开始前。
alias(BattleManager, 'startAction', function(old, args) {
  var subject = this._subject, action = subject && subject.currentAction(), t = tusu(), b = B();
  try {
    if (t && b && b.isBound(t) && action && action.item()) {
      var host = holder(t), w = weapon(t), key = ids().key[action.item().id];
      if (subject === host && w === 'bow' && key === 'arm.guanri' && !host._codexTusuLock) {
        var target = $gameTroop.members()[action._targetIndex];
        if (target && target.isAlive()) support(t, 'suoding', [host], function(a) { a._codexTusuLockTarget = target; });
      }
      if (subject === host && w === 'book' && key === 'arm.chiling' && !host.isStateAffected(ids().state.heming)) support(t, 'heming', [host]);
      if (subject.isEnemy() && w === 'shield' && action.isForOpponent() && [1, 5].indexOf(action.item().damage.type) >= 0) {
        var allies = $gameParty.battleMembers().filter(function(x) { return x.isAlive(); });
        var risky = action.isForAll() || allies.some(function(x) { return x.hp / Math.max(1, x.mhp) <= CFG.ai.shieldBelow; });
        if (risky) roundSupport(t, 'jintang', false);
      }
    }
  } catch (e) { console.error('屠苏支援失败', e); }
  return old.apply(this, args);
});
alias(BattleManager, 'endAction', function(old, args) {
  var subject = this._subject, action = this._action, t = tusu(), b = B();
  try {
    if (t && b && b.isBound(t) && action && !action._codexInternal && subject === holder(t) && subject.isAlive()) {
      var w = weapon(t), d = data(t), item = action.item();
      d.supported = d.supported || {};
      d.trigger = num(action._codexTusuDealt);
      if (w === 'sword' && action.isPhysical() && action.isDamage() && action.isForOpponent()) roundSupport(t, 'jianqi', false);
      if (w === 'hammer' && item && action.isForOpponent()) roundSupport(t, 'zhenhun', false);
    }
  } catch (e) { console.error('屠苏支援失败', e); }
  return old.apply(this, args);
});
// 持武者主动行动的直接伤害（异界制约结算后），作为支援随主成长的读数。
alias(Game_Action.prototype, 'executeHpDamage', function(old, args) {
  var out = old.apply(this, args);
  if (!this._codexInternal && num(args[1]) > 0 && args[0] && args[0].isEnemy && args[0].isEnemy()) this._codexTusuDealt = num(this._codexTusuDealt) + num(args[1]);
  return out;
});
// ---- 技能使用条件 ----
alias(Game_Actor.prototype, 'meetsSkillConditions', function(old, args) {
  var s = args[0], key = s && ids().key[s.id];
  if (isTusu(this) && $gameParty.inBattle() && B()) {
    var bound = B().isBound(this);
    if (key === 'return') return bound && B().charges(this) >= 1 && old.apply(this, args);
    if (key && key.indexOf('yiwu.') === 0) { var w = key.slice(5), d = data(this); return bound && w !== (d && (d.reserve || d.weapon)) && old.apply(this, args); }
    if (key && key.indexOf('huawu.') === 0) return !bound && old.apply(this, args);
    if (key && key.indexOf('support.') === 0) {
      var active = T.supportSkill(this), h = holder(this);
      return bound && active && active.id === s.id && h && h.isAlive() &&
        (key !== 'support.heming' || !h.isStateAffected(ids().state.heming)) && old.apply(this, args);
    }
    if (bound && s.id !== this.guardSkillId()) return false; // 武具态只有易武可用
  }
  if (key && key.indexOf('arm.') === 0 && $gameParty.inBattle()) {
    var requiredWeapon = CFG.armWeapon[key.slice(4)] || (key === 'arm.huzhen' ? 'shield' : null);
    if (!requiredWeapon || weaponOfHost(this) !== requiredWeapon) return false;
  }
  if (key === 'menu.forge') return !$gameParty.inBattle() && old.apply(this, args);
  return old.apply(this, args);
});
// 易武不耗兵势与 MP：预约下一个自然回合的武相；化武：选择持武者并绑定；归形：不消耗兵势回到人形。
alias(Game_Action.prototype, 'apply', function(old, args) {
  var a = this.subject(), target = args[0], key = this.item() && ids().key[this.item().id];
  if (isTusu(a) && key && (key === 'return' || key.indexOf('yiwu.') === 0 || key.indexOf('huawu.') === 0)) {
    this.makeSuccess(target);
    if (key === 'return') B().unbind(a, 'return');
    else if (key.indexOf('yiwu.') === 0) { setReserve(a, key.slice(5)); log(CFG.lines.reserve.replace('%s', CFG.names[key.slice(5)])); }
    else if (B().canHost(a, target)) { a._codexTusu = a._codexTusu || {}; a._codexTusu.pendingWeapon = key.slice(6); B().bind(a, target, 'huawu'); }
    return;
  }
  // 屠苏来源（本人技能、武装技能）豁免异界制约；持武者原技能不豁免。
  var exempt = isTusu(a) || (key && key.indexOf('arm.') === 0);
  // 武装技能按屠苏的属性与加成结算（先例：谷雨绽放以谷雨为攻击者），持武者的加成不叠加。
  var arm = key && key.indexOf('arm.') === 0 && !isTusu(a) && tusu();
  if (exempt) exemptDepth++;
  if (arm) { this._codexTusuOwner = arm; }
  try { return old.apply(this, args); } finally { if (exempt) exemptDepth--; if (arm) delete this._codexTusuOwner; }
});
alias(Game_Action.prototype, 'subject', function(old, args) { return this._codexTusuOwner || old.apply(this, args); });
var exemptDepth = 0;
if (W.CodexImportedBalance && CodexImportedBalance.outgoingRate) {
  var oldRate = CodexImportedBalance.outgoingRate;
  CodexImportedBalance.outgoingRate = function(actor) { return exemptDepth > 0 ? 1 : oldRate.apply(this, arguments); };
}
// 「攻击」位置（武具态为归形）不按伤害技能估算；易武在 AI 里只按规则选。
// ---- 书相：持武者登记的法系技能省蓝 ----
var devourPaying = false;
function devourKey(a, key) {
  if (!key || CFG.mpRate[key] === undefined || !$gameParty.inBattle() || !B()) return false;
  if (key.indexOf('arm.') === 0) return !isTusu(a);
  return key.indexOf('support.') === 0 && isTusu(a) && B().isBound(a);
}
alias(Game_Actor.prototype, 'skillMpCost', function(old, args) {
  var s = args[0], v = old.apply(this, args), key = s && ids().key[s.id];
  // 武装技能：屠苏付得起时持武者不花魔法（面板显示 0），否则显示噬主费用。支援由屠苏施放，噬主时屠苏这边不扣。
  if (devourKey(this, key)) {
    if (key.indexOf('arm.') === 0) return T.payer(key) === 'tusu' ? 0 : devourCost(this, key);
    if (devourPaying) return 0;
  }
  if (key && CFG.mpRate[key] !== undefined && (isTusu(this))) return ownCost(this, key);
  if ($gameParty.inBattle() && weaponOfHost(this) === 'book' && s && s.hitType === 2 && !(key && key.indexOf('arm.') === 0)) return Math.floor(v * CFG.book.mpRate);
  return v;
});
alias(Game_BattlerBase.prototype, 'canPaySkillCost', function(old, args) {
  var s = args[0], key = s && ids().key[s.id];
  if (this.isActor && this.isActor() && devourKey(this, key)) return !!T.payer(key) && this._tp >= this.skillTpCost(s);
  return old.apply(this, args);
});
alias(Game_BattlerBase.prototype, 'paySkillCost', function(old, args) {
  var s = args[0], key = s && ids().key[s.id];
  if (!(this.isActor && this.isActor() && devourKey(this, key))) return old.apply(this, args);
  var who = T.payer(key), t = tusu(), h = t && holder(t);
  if (!who) return; // 由调用方在支付前检查；这里不扣到负数
  devourPaying = who === 'host' && isTusu(this);
  try { old.apply(this, args); } finally { devourPaying = false; } // 武装技能：持武者这边按 skillMpCost（0 或噬主费用）；TP 照常
  if (who === 'tusu' && !isTusu(this)) t.setMp(t.mp - ownCost(t, key));
  if (who === 'host' && isTusu(this) && h) h.setMp(h.mp - devourCost(h, key));
  if (who === 'host') { log(CFG.lines.devour); if (W.CodexTusuDevour) W.CodexTusuDevour.paid = (W.CodexTusuDevour.paid || 0) + 1; }
});
// ---- 盾相：双防补底写入面板（唯一写入面板的项） ----
alias(Game_Actor.prototype, 'param', function(old, args) {
  var v = old.apply(this, args), id = args[0];
  if ((id === 3 || id === 5) && $gameParty.inBattle() && !this._codexTusuParam && weaponOfHost(this) === 'shield') {
    var t = tusu(); if (t && t !== this) { this._codexTusuParam = true; try { v = Math.max(v, Math.floor(CFG.floor.shield * (id === 3 ? t.def : t.mdf))); } finally { this._codexTusuParam = false; } }
  }
  return v;
});
// ---- 统一伤害：武装基准同时用于基式与防御比例；挫势、护阵、锁定、和鸣、支援上下限 ----
if (W.CodexDamageHooks) W.CodexDamageHooks.push({name: 'tusu', build: function(action, target, f) {
  var key = ids().key[action.item().id], subject = action.subject();
  if (key && key.indexOf('arm.') === 0 && CFG.armWeapon[key.slice(4)]) {
    var w = CFG.armWeapon[key.slice(4)], base = T.base(subject, w), proxy = Object.create(subject);
    Object.defineProperty(proxy, w === 'book' ? 'mat' : 'atk', {value: base});
    f.subject = proxy;
    f.mode = w === 'book' ? 'magical' : 'physical';
    // 武装技能威力按持武者本回合行动次数分摊（以 CFG.armActions 次为基准），多行动持武者不成倍放大。
    var td = data(tusu()); if (td && td.hostActions) f.finalMultiplier *= CFG.armActions / Math.max(1, td.hostActions);
    var wielder = action._codexTusuOwner ? holder(action._codexTusuOwner) || subject : subject;
    if (key === 'arm.guanri' && wielder._codexTusuLock && wielder._codexTusuLock.target === target) f.finalMultiplier *= T.lockRate(tusu());
    if (key === 'arm.chiling' && wielder.isStateAffected(ids().state.heming)) f.finalMultiplier *= T.hemingRate(tusu());
  }
  if (key && key.indexOf('support.') === 0) {
    var t = isTusu(subject) ? subject : tusu(), d = data(t), r = CFG.supportRate.r, m = CFG.supportRate.m, trig = d ? num(d.trigger) : 0;
    if (['support.jianqi', 'support.zhenhun'].indexOf(key) >= 0 && relicOn(t)) f.finalMultiplier *= CFG.relicBonus.support;
    if (['support.jianqi', 'support.zhenhun'].indexOf(key) >= 0) f.after.push(function(res) { var self = num(res.value); res.value = Math.floor(Math.min(Math.max(self, trig * r), self * m) * (action._codexTusuSupportBonus||1)); });
  }
  if (subject && subject.isEnemy && subject.isEnemy() && subject._codexTusuCuoshi) f.finalMultiplier *= subject._codexTusuCuoshi.rate;
  if (target && target.isActor && target.isActor() && target.isStateAffected(ids().state.huzhen)) f.incomingMultiplier *= T.huzhenRate(tusu());
}});
// 锁定、和鸣：启动即消费（未命中或被免疫也不退回）。
alias(BattleManager, 'endAction', function(old, args) {
  var action = this._action, subject = this._subject, key = action && action.item() && ids().key[action.item().id];
  try {
    if (key === 'arm.guanri' && subject && subject._codexTusuLock) {
      var target = subject._codexTusuLock.target, killed = target && target.isDead();
      delete subject._codexTusuLock; if (subject.isStateAffected(ids().state.lock)) subject.removeState(ids().state.lock);
      if (killed && hasKairen('bow')) { var next = dangerEnemy(); if (next) { subject._codexTusuLock = {target: next}; subject.addState(ids().state.lock); } }
    }
    if (key === 'arm.chiling' && subject && subject.isStateAffected(ids().state.heming)) subject.removeState(ids().state.heming);
  } catch (e) { console.error(e); }
  return old.apply(this, args);
});
// 支援技能的附加效果（原生主动行动与内部结算共用）。
alias(Game_Action.prototype, 'applyItemUserEffect', function(old, args) {
  var out = old.apply(this, args), key = ids().key[this.item().id], target = args[0], a = this.subject();
  try {
    if (key === 'support.suoding' && this._codexTusuLockTarget) { target._codexTusuLock = {target: this._codexTusuLockTarget}; target.addState(ids().state.lock); }
    if (key === 'support.heming') target.addState(ids().state.heming);
    if (key === 'support.jintang' && W.CodexShieldLedger) {
      var t = isTusu(a) ? a : tusu();
      var amount = T.shieldAmount(t,target);
      amount *= T.relicMultiplier(t,'support.jintang')*(this._codexTusuSupportBonus||1)*T.shieldSupportRate(t);
      var beforeShield=CodexShieldLedger.amount(target,'tusu.jintang');
      CodexShieldLedger.grant(target,'tusu.jintang',amount,CFG.jintang.turns,t.actorId());
      if(CodexShieldLedger.amount(target,'tusu.jintang')>beforeShield)this._codexTusuResultSuccessful=true;
    }
    if (key === 'body.guard' && W.CodexShieldLedger && isTusu(a)) {
      var base = T.shieldAmount(a,target);
      CodexShieldLedger.grant(target, 'tusu.body', base * CFG.bodyGuard.rate, CFG.bodyGuard.turns, a.actorId());
    }
    if (key === 'arm.huzhen') target.addState(ids().state.huzhen);
    if ((key === 'arm.zhenji' || key === 'support.zhenhun') && target.isEnemy() && target.isAlive()) applyCuoshi(target);
    if (key === 'support.jianqi' && hasKairen('sword') && target.isEnemy() && target.isAlive()) target.addDebuff(3, CFG.kairen.swordDebuffTurns);
  } catch (e) { console.error('屠苏效果失败', e); }
  return out;
});
function applyCuoshi(e) {
  var D = W.CodexBossDifficulty, hyper = !!(D && D.hasHyperArmor(e)), r = B() ? B().round() : 1;
  var rate = hyper ? B().curve(tusu(),[.85,.70],[20,60]) : B().curve(tusu(),[.90,.80],[20,60]), until = r + (hyper ? 2 : 1);
  var stateId = ids().state[hyper ? 'cuoshi2' : 'cuoshi'];
  if (!stateId || e.isStateResist(stateId)) return false;
  // 同源不叠加：刷新取较低倍率（更强）与较晚到期；开刃·锤后最多 2 层，倍率按层数连乘。
  var c = e._codexTusuCuoshi, maxStack = hasKairen('hammer') ? 2 : 1;
  if (c && c.until >= r) { c.base = Math.min(c.base, rate); c.stack = Math.min(maxStack, c.stack + 1); c.until = Math.max(c.until, until); }
  else c = e._codexTusuCuoshi = {base: rate, stack: 1, until: until};
  c.rate = Math.pow(c.base, c.stack);
  ['cuoshi', 'cuoshi2'].forEach(function(k) { var id = ids().state[k]; if (id && e.isStateAffected(id)) e.removeState(id); });
  e.addState(stateId);
  // 眩晕只在目标非霸体时尝试，仍经过状态接受率与免疫。
  if (!hyper && Math.random() < e.stateRate(CFG.stunState) && !e.isStateResist(CFG.stunState)) e.addState(CFG.stunState);
  return true;
}
T.applyCuoshi = applyCuoshi;
// 挫势按自然回合到期。
alias(BattleManager, 'endTurn', function(old, args) {
  var out = old.apply(this, args), r = B() ? B().round() : 1;
  if (this._enteredEndPhase) $gameTroop.members().forEach(function(e) {
    var c = e._codexTusuCuoshi; if (c && c.until <= r) { delete e._codexTusuCuoshi; ['cuoshi', 'cuoshi2'].forEach(function(k) { var id = ids().state[k]; if (id && e.isStateAffected(id)) e.removeState(id); }); }
  });
  return out;
});
// ---- 自动战斗：武具态使用自己的支援行动，按规则易武；人形时化武 ----
T.autoAction = function(a) {
  if (!isTusu(a) || !$gameParty.inBattle() || !B()) return null;
  var act = new Game_Action(a), b = B(), allies = $gameParty.battleMembers().filter(function(x) { return x.isAlive(); }), foes = $gameTroop.aliveMembers();
  if (b.isBound(a)) {
    var d = data(a), cur = d.reserve || d.weapon, D = W.CodexBossDifficulty, next = $gameTroop.turnCount() + 1;
    var want = null;
    var hurt = allies.filter(function(x) { return x.hp / Math.max(1, x.mhp) < CFG.ai.hurt; }).length;
    var bossNextHyper = D && foes.some(function(e) { return D.isBoss(e); }) && next % 2 === 0;
    if ((hurt >= 2 || bossNextHyper) && cur !== 'shield') want = 'shield';
    else if (foes.length >= 3 && cur !== 'sword') want = 'sword';
    else if (foes.length === 1 && D && D.isBoss(foes[0]) && cur === 'sword') want = 'hammer';
    if (want) { act.setSkill(ids().skill['yiwu.' + want]); return act; }
    var s = T.supportSkill(a), key = s && ids().key[s.id], h = holder(a), target = dangerEnemy(), useful = !!s;
    if (key === 'support.suoding') useful = target && (!h._codexTusuLock || h._codexTusuLock.target !== target);
    if (key === 'support.jintang') useful = allies.some(function(x) { return !B().untargetable(x) && W.CodexShieldLedger && CodexShieldLedger.amount(x, 'tusu.jintang') < T.shieldAmount(a, x) * T.relicMultiplier(a, key) * T.shieldSupportRate(a) * T.supportBonus(a, 'jintang'); });
    if (s && useful && a.canUse(s)) { act.setSkill(s.id); if (target && (key === 'support.suoding' || key === 'support.zhenhun')) act.setTarget(target.index()); return act; }
    act.setGuard(); return act;
  }
  var host = b.defaultHost(a), w0 = a._codexTusuLast || 'sword';
  if (host && T.canMaintain(w0, host)) { act.setSkill(ids().skill['huawu.' + (a._codexTusuLast || 'sword')]); act.setTarget(host.index()); return act; }
  return null;
};
// 持武者自动战斗：用统一伤害预览比较武装技能与 AI 选中的原技能，武装技能实际伤害更高时改用（只作用于持武者）。
function previewDamage(action, target) {
  if (!W.CodexDamage || !target) return 0;
  var key = ids().key[action.item().id], t = tusu();
  try {
    if (key && key.indexOf('arm.') === 0 && t) action._codexTusuOwner = t;
    var v = num(CodexDamage.calculate(action, target, {preview: true, critical: false}).value);
    var hits = action.isForAll() ? $gameTroop.aliveMembers().length : 1;
    return v * hits * Math.max(1, action.numRepeats());
  } catch (e) { return 0; } finally { delete action._codexTusuOwner; }
}
function superStrong(a) { var D = W.CodexBossDifficulty, id = a && a.actorId && a.actorId(); return !!(D && D.superStrongIds && D.superStrongIds.indexOf(id) >= 0); }
T.superStrong = superStrong;
T.hostAuto = function(host) {
  var t = tusu(); if (!t || holder(t) !== host || !host._actions || superStrong(host)) return;
  var foes = $gameTroop.aliveMembers(); if (!foes.length) return;
  var D = W.CodexBossDifficulty, focus = foes.slice().sort(function(x, y) { return (D && D.isBoss(y) ? 1 : 0) - (D && D.isBoss(x) ? 1 : 0) || y.hp - x.hp; })[0];
  host._actions.forEach(function(act, i) {
    var item = act && act.item(); if (!item || ids().key[item.id]) return;
    if (!act.isForOpponent() || !act.isDamage()) return;
    var own = previewDamage(act, focus), best = null, bestValue = own * 1.1;
    host.skills().forEach(function(s) {
      var k = ids().key[s.id]; if (!k || k.indexOf('arm.') !== 0 || !host.canUse(s) || !s.damage || s.damage.type !== 1) return;
      var x = new Game_Action(host); x.setSkill(s.id); x.setTarget(focus.index());
      var v = previewDamage(x, focus); if (v > bestValue) { best = x; bestValue = v; }
    });
    if (best) host._actions[i] = best;
  });
};
alias(Game_Actor.prototype, 'makeAutoBattleActions', function(old, args) {
  var out = old.apply(this, args);
  if (isTusu(this) && $gameParty.inBattle() && this.numActions() > 0) { var act = T.autoAction(this); if (act) this._actions[0] = act; }
  else if ($gameParty.inBattle()) { try { T.hostAuto(this); } catch (e) { console.error(e); } }
  return out;
});
// ---- 智能战斗AI：武装、支援、本体技能的伤害估算（原始公式值，与其他角色同一口径） ----
(W.CodexAIEstimators = W.CodexAIEstimators || []).push(function(a, b, item) {
  var key = ids().key[item.id]; if (!key) return undefined;
  if (key.indexOf('arm.') === 0 && superStrong(a)) return 0; // 超强者持武只获武相功能，自动战斗保留原技能
  if (key.indexOf('arm.') === 0 || key.indexOf('support.') === 0 || key.indexOf('body.') === 0) {
    var k = key.split('.')[1], v = T.damage(a, b, key.indexOf('body.') === 0 ? 'body_' + k : k);
    if (key === 'arm.guanri' && a._codexTusuLock && a._codexTusuLock.target === b) v *= T.lockRate(tusu());
    if (key === 'arm.chiling' && a.isStateAffected && a.isStateAffected(ids().state.heming)) v *= T.hemingRate(tusu());
    return v;
  }
  return 0;
});
// ---- 招募：首次赠送并装备法宝 ----
T.recruit = function() {
  var i = ids(), a = $gameActors.actor(i.actor); if (!a) return false;
  if ($gameParty._actors.indexOf(i.actor) >= 0) return false;
  $gameParty.addActor(i.actor);
  if (!a._codexTusuRelicGiven && i.relic) {
    a._codexTusuRelicGiven = true;
    var relic = $dataArmors[i.relic];
    $gameParty.gainItem(relic, 1);
    var slot = a.equipSlots().indexOf(relic.etypeId);
    if (slot >= 0) { var owned = $gameParty.armors().filter(function(x) { return x && (x.baseItemId || x.id) === i.relic; }).slice(-1)[0] || relic; a.changeEquip(slot, owned); }
  }
  return true;
};
// ---- 器谱：开刃选择（每阶一相，最多三相；重新开刃消耗材料） ----
T.forgeRows = function(a) {
  var k = kairen(a), n = stage(a), rows = [];
  rows.push({label: CFG.names.forgeTitle.replace('%d', n), enabled: false});
  for (var i = 0; i < 3; i++) rows.push({slot: i, label: (i < n ? '' : '（未开放）') + '第' + (i + 1) + '道铭文：' + (k[i] ? CFG.names['kairen_' + k[i]] : '未开刃'), enabled: i < n});
  return rows;
};
T.setKairen = function(a, slot, w) {
  var k = kairen(a).slice(), n = stage(a);
  if (slot >= n || WEAPONS.indexOf(w) < 0) return false;
  if (k.indexOf(w) >= 0 && k.indexOf(w) !== slot) return false;
  var cost = k[slot] && k[slot] !== w ? CFG.reforge : null;
  if (cost) { var item = $dataItems[cost[0]]; if ($gameParty.numItems(item) < cost[1]) throw Error('重新开刃需要' + item.name + '×' + cost[1]); $gameParty.loseItem(item, cost[1]); }
  k[slot] = w; a._codexTusuKairen = k;
  syncKairenSkills(a);
  return true;
};
function syncKairenSkills(a) {
  var k = kairen(a).slice(0, stage(a));
  WEAPONS.forEach(function(w) { var id = ids().skill['kairen.' + w]; if (!id) return; if (k.indexOf(w) >= 0) a.learnSkill(id); else a.forgetSkill(id); });
}
T.syncKairenSkills = syncKairenSkills;
T.openForge = function() {
  var a = $gameActors.actor(ids().actor);
  if (!a || $gameParty._actors.indexOf(a.actorId()) < 0) return;
  B().openMenu(function(scene) { forgeMenu(scene, a); });
};
function forgeMenu(scene, a) {
  var Y = W.CodexYunshang;
  Y.choose(scene, T.forgeRows(a).filter(function(r) { return r.enabled !== false || r.slot !== undefined; }), function(r) {
    if (r.slot === undefined) return;
    Y.choose(scene, WEAPONS.map(function(w) { return {label: CFG.names['kairen_' + w] + '　' + CFG.names['kairenDesc_' + w], w: w, enabled: kairen(a).indexOf(w) < 0 || kairen(a).indexOf(w) === r.slot}; }), function(x) {
      try { T.setKairen(a, r.slot, x.w); } catch (e) { if (W.$ && $.toaster) $.toaster({message: e.message}); }
      forgeMenu(scene, a);
    }, function() { forgeMenu(scene, a); }, [CFG.names.forgePick.replace('%d', r.slot + 1)]);
  }, function() { scene.popScene(); }, [CFG.names.forgeInfo]);
}
// ---- 读档、进阶后同步开刃被动；战斗外清理 ----
// 读档：补学职业表里新增的 1 级技能（v0.7 新增被动）；已有的法宝实例按底本同步名称与说明。
function syncNative(a) {
  var c = a.currentClass && a.currentClass();
  if (c) c.learnings.forEach(function(l) { if (l.level <= a.level && $dataSkills[l.skillId] && !a.isLearnedSkill(l.skillId)) a.learnSkill(l.skillId); });

}
T.syncNative = syncNative;
alias(DataManager, 'extractSaveContents', function(old, args) {
  var out = old.apply(this, args), a = $gameActors && $gameActors._data[ids().actor];
  if (a) { syncNative(a); syncKairenSkills(a); delete a._codexTusu; }
  $gameParty.allMembers().forEach(function(x) { clearHostStates(x); });
  return out;
});
alias(BattleManager, 'endBattle', function(old, args) {
  try { return old.apply(this, args); } finally {
    $gameParty.allMembers().forEach(function(x) { clearHostStates(x); delete x._codexTusuLock; delete x._codexTusu; });
    $gameTroop.members().forEach(function(e) { delete e._codexTusuCuoshi; });
  }
});

T.weight=function(a){return B().curve(a,[.1,.2,.35,.5,.65,.8,1],[1,10,20,30,40,50,60]);};
T.lockRate=function(a){return B().curve(a,[1.3,1.5],[20,60]);};
T.hemingRate=function(a){return B().curve(a,[1.2,1.5],[20,60]);};
T.huzhenRate=function(a){return B().curve(a,[.85,.70],[20,60]);};
T.shieldAmount=function(a,target){return Math.max((CFG.jintang.hp*num(a.mhp)+CFG.jintang.def*(num(a.def)+num(a.mdf)))*T.weight(a), B().curve(a,[.1,.3],[1,60])*num(target.mhp));};
T.supportBonus=function(a,k){var d=data(a);return ['jianqi','zhenhun','jintang'].indexOf(k)>=0&&a.level>=40&&(!d||d.growthSupportRound!==B().round())?B().curve(a,[1,1.2],[40,60]):1;};
// 五兵淬纹（屠苏成长被动，2026-10-10 由法宝词条改为被动，不需要装备法宝）：按屠苏等级，10/20/30/40级起对应技能×1.1，60级×1.2；剑气纵横保持×1.1。
T.TEMPER={'support.jianqi':10,'arm.hengsao':20,'arm.dianshe':20,'arm.guanri':20,'support.jintang':30,'arm.chiling':30,'arm.zhenji':40,'support.zhenhun':40};
T.temperRate=function(a,k){
 var lv=Number(a&&a.level)||1,at=T.TEMPER[k];
 if(!at||lv<at)return 1;
 if(lv<60||k==='support.jianqi')return 1.1;
 return 1.2;
};
T.relicMultiplier=T.temperRate; // 旧名保留给法宝模块与金汤调用

registerBinding();
B().bindGrowth(T, CFG, ids, isTusu, tusu);
})(window, CFG);

});
