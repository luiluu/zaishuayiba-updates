// 本轮维护源：three-growth-install-20261009-114400；禁止用旧安装器覆盖。
// 由 install_xuan_tusu.py 生成；请改 design/*.json 或 runtime/*.js 后重新安装。
window.CodexRuntime.register("installNativeXuanRuntime", function() {
var CFG = {"ai":{"heal":0.3},"chart":{"bossSand":12,"cost":[10,15,25],"initial":["yuhui","tongdiao","yiguang"],"sand":3,"unlockLevels":[10,20,30]},"coef":{},"dmg":{"lengguang":30},"gongsu":{"rate":0.3},"growth":{"damage":{"lengguang":[2000.0,3500.0,7000.0,10000.0,13000.0,16000.0,20000]},"identity":[1,3,6,11],"levels":[1,10,20,30,40,50,60],"names":["星辉凝聚","命轨共鸣","群星归宿"],"passives":["growth.35","growth.50","growth.70"],"unlock":{"lengguang":5,"gongsu":10,"liexing":30,"growth.35":1,"growth.50":20,"growth.70":30,"mark.yuhui":10,"mark.dingxing":10,"mark.xianzhao":10,"mark.tongdiao":20,"mark.fenguang":20,"mark.shihui":20,"mark.yiguang":30,"mark.binggui":30,"mark.liuhui":30}},"huiguang":{"below":0.6,"mat":20,"targetRate":0.35},"keepLastCharge":true,"lengguang":{"debuffTurns":2},"libi":{"hp":2,"mat":300,"targetRate":0.35,"turns":2},"liexing":{"auto":true,"turns":2},"lines":{"dingxing":"免控挡住了控制。","huiguang":"璇：「别撑了，先缓一口气。」","lengguang":"璇：「往左。现在出手。」","libi":"璇：「低头。这一下我来。」","liexing":"璇：「都在。接上。」","transfer":"璇：「我去另一边，有事叫我。」"},"marks":{"xianzhao":{"every":3},"yuhui":{"rate":[0.2,0.35,0.5]}},"mpRate":{"huiguang":0.06,"lengguang":0.05,"libi":0.08,"liexing":0.15},"names":{"markDesc_binggui":"指定副宿主；默认目标安全时也支援副宿主","markDesc_dingxing":"净化控制后，下一回合内阻止一次可净化的硬控制","markDesc_fenguang":"被附身的队友群攻时，棱光分配给最多2/3/4名敌人","markDesc_liuhui":"换队友附身后，原队友保留共宿增益1/2/3回合","markDesc_shihui":"棱光命中时驱散一项增益（每3/2/1回合一次）","markDesc_tongdiao":"棱光跟随被附身的队友攻击的元素","markDesc_xianzhao":"手动时璃壁先制；自动时可预支下回合1次自动出手（每3回合一次）","markDesc_yiguang":"换队友附身时迁移50%/75%/100%璇护盾","markDesc_yuhui":"回光的溢出治疗按20%/35%/50%转为护盾","mark_binggui":"并轨","mark_dingxing":"免控","mark_fenguang":"分光","mark_liuhui":"留辉","mark_shihui":"蚀辉","mark_tongdiao":"同调","mark_xianzhao":"先照","mark_yiguang":"移光","mark_yuhui":"余辉"},"relicBonus":{"firstCharge":0,"heal":1},"tacit":{"assist":5,"keep":0.5,"perRound":20,"protect":5,"rosterKeep":0.75,"rosterStart":20,"stay":10},"version":"0.4.0"};
/* 璇：寄命星灵。附身、星契调度、回光／璃壁／棱光／列星、共宿、星谱（星纹、星砂）、默契与同轨、命主名册。
 * 依赖：installNativeBindingChargeRuntime、installSourceShieldLedgerRuntime。
 * 所有记录按备注标签 <CodexXuan: 键> 查找；CFG 由安装器从 xuan_design.json 写入。
 */
(function(W, CFG) {
'use strict';
if (W.CodexXuan) return;
var X = W.CodexXuan = {version: CFG.version, config: CFG};
var MARKS = ['yuhui', 'dingxing', 'xianzhao', 'tongdiao', 'fenguang', 'shihui', 'yiguang', 'binggui', 'liuhui'];
var SLOT_OF = {yuhui: 0, dingxing: 0, xianzhao: 0, tongdiao: 1, fenguang: 1, shihui: 1, yiguang: 2, binggui: 2, liuhui: 2};
X.MARKS = MARKS;
function num(v) { v = Number(v); return isFinite(v) ? v : 0; }
function alias(o, k, f) { var prev = o[k]; o[k] = function() { return f.call(this, prev, arguments); }; }
function tagOf(r) { var m = r && (r.note || '').match(/<CodexXuan:\s*([^>]+)>/); return m ? m[1].trim() : ''; }
function sharedTag(r) { var m = r && (r.note || '').match(/<CodexBind:\s*([^>]+)>/); return m ? m[1].trim() : ''; }
var cache = null;
function ids() {
  if (cache && cache.db === W.$dataSkills) return cache;
  var out = {db: W.$dataSkills, skill: {}, state: {}, key: {}, actor: 0, relic: 0, horn: 0};
  (W.$dataSkills || []).forEach(function(s) { var k = tagOf(s); if (k) { out.skill[k] = s.id; out.key[s.id] = k; } });
  (W.$dataStates || []).forEach(function(s) { var k = tagOf(s); if (k) out.state[k] = s.id; if (sharedTag(s) === 'empty') out.state.empty = s.id; });
  (W.$dataActors || []).forEach(function(a) { if (tagOf(a) === 'actor') out.actor = a.id; });
  (W.$dataArmors || []).forEach(function(a) { if (!out.relic && tagOf(a) === 'relic') out.relic = a.id; });
  (W.$dataItems || []).forEach(function(i) { if (tagOf(i) === 'horn') out.horn = i.id; });
  cache = out;
  return out;
}
X.ids = ids;
X.status = function() {
  var i = ids(), miss = [];
  if (!i.actor) miss.push('actor');
  ['jixing.possess', 'jixing', 'huiguang', 'libi', 'lengguang', 'liexing', 'gongsu', 'menu.starchart'].concat(MARKS.map(function(m) { return 'mark.' + m; }))
    .forEach(function(k) { if (!i.skill[k]) miss.push('skill.' + k); });
  ['possess', 'hostmark', 'liexing', 'shadow', 'tacit', 'tonggui', 'debt', 'dingxing', 'empty'].forEach(function(k) { if (!i.state[k]) miss.push('state.' + k); });
  return {ok: !miss.length, missing: miss};
};
function isXuan(a) { return !!(a && a.isActor && a.isActor() && a.actorId() === ids().actor); }
X.isXuan = isXuan;
function B() { return W.CodexBinding; }
function members() { return $gameParty.battleMembers(); }
function live(b) { return !!b && b.isAlive(); /* 【Codex·未经Claude检验】v0.48：零血未死亡仍为存活。 */ }
function xuan() { return members().filter(isXuan)[0] || null; }
function round() { return B() ? B().round() : 1; }
function data(a) { return a && a._codexXuan; }
function host(a) { return B() && B().host(a); }
X.host = host;
function log(text) { var w = BattleManager._logWindow; if (text && w && w.push) w.push('addText', text); }
// ---- 永久成长：星谱、星砂、星纹、命主名册 ----
function chart(a) {
  var c = a._codexXuanChart;
  if (!c) c = a._codexXuanChart = {sand: 0, level: {}, slots: [CFG.chart.initial[0], CFG.chart.initial[1], CFG.chart.initial[2]], partner: 0, roster: [], spent: {}};
  CFG.chart.initial.forEach(function(m) { if (!c.level[m]) c.level[m] = 1; });
  return c;
}
X.chart = chart;
function markLevel(a, m) { if(!a||a.level<CFG.chart.unlockLevels[SLOT_OF[m]])return 0; var c = a && chart(a); return c && c.slots[SLOT_OF[m]] === m ? num(c.level[m]) : 0; }
X.markLevel = markLevel;
function stage(a) { return Math.max(0, Math.min(3, Math.floor(num(a && a._AdvancedNum)))); }
function isRoster(a, target) { var c = chart(a); return !!target && c.roster.slice(0, stage(a)).indexOf(target.actorId()) >= 0; }
X.isRoster = isRoster;
function syncMarkSkills(a) {
  var c = chart(a);
  MARKS.forEach(function(m) { var id = ids().skill['mark.' + m]; if (!id) return; if (c.slots[SLOT_OF[m]] === m && c.level[m]) a.learnSkill(id); else a.forgetSkill(id); });
}
X.syncMarkSkills = syncMarkSkills;
// ---- 本场数据 ----
function fresh(a) {
  var d = a._codexXuan = {tacit: 0, tonggui: false, debt: 0, xianzhaoRound: -99, liexingUntil: -1, shadows: [], record: {}, dingxing: {}, shihuiRound: -99, used: {}};
  return d;
}
function tacitStart(a, target) { return isRoster(a, target) ? CFG.tacit.rosterStart : 0; }
// ---- 绑定登记 ----
function registerBinding() {
  if (!B() || B().kinds.xuan) return;
  B().register('xuan', {
    isOwner: isXuan,
    manual: function(a){return !X.autoEnabled(a);},
    get formState() { return ids().state.possess; },
    get emptyState() { return ids().state.empty; },
    onBind: function(owner, target, reason, previous) {
      var d = data(owner) || fresh(owner);
      markHost(target, true);
      if (reason === 'opening') { d.tacit = tacitStart(owner, target); }
      else {
        var keep = isRoster(owner, target) || (previous && isRoster(owner, previous)) ? CFG.tacit.rosterKeep : CFG.tacit.keep;
        d.tacit = Math.floor(d.tacit * keep);
        d.record.transferRound = round();
        if (previous) transferEffects(owner, previous, target);
        log(CFG.lines.transfer);
      }
      d.tonggui = d.tacit >= 100; syncCounters(owner);
      owner.refresh(); target.refresh();
    },
    onUnbind: function(owner, target, reason) {
      if (target) { markHost(target, false); target.refresh(); }
      var d = data(owner);
      if (reason !== 'transfer' && d) { d.tonggui = false; syncCounters(owner); }
    },
    onRoundStart: function(owner, n) {
      var d = data(owner) || fresh(owner);
      if (round() === 1 && relicOn(owner) && owner.canMove()) B().gain(owner, CFG.relicBonus.firstCharge); // 璇玑星盘：第一回合星契＋1
      if (d.debt > 0 && n > 0) { var pay = Math.min(d.debt, B().charges(owner)); d.debt -= pay; B().spend(owner, pay); }
      d.used = {}; d.record = {round: round(), stayed: B().host(owner) ? B().host(owner).actorId() : 0};
      syncCounters(owner);
    },
    onRoundEnd: function(owner) { roundEndRelease(owner); },
    onRoundClose: function(owner) { settleTacit(owner); },
    chargeCounter: function(owner, n) { owner._codexXuanCharges = n; },
    onClear: function(a) { delete a._codexXuan; delete a._codexXuanCharges; }
  });
}
function markHost(target, on) {
  var id = ids().state.hostmark; if (!id || !target) return;
  if (on && !target.isStateAffected(id)) target.addState(id);
  if (!on && target.isStateAffected(id)) target.removeState(id);
}
// 星纹标记只作显示：被驱散或移除时由模块补回。
alias(Game_Battler.prototype, 'removeState', function(old, args) {
  var out = old.apply(this, args), x = $gameParty.inBattle() && xuan();
  if (x && args[0] === ids().state.hostmark && host(x) === this && !this._codexXuanUnmark) this.addState(args[0]);
  if (x && args[0] === ids().state.shadow && data(x) && data(x).shadows.indexOf(this.actorId && this.actorId()) >= 0 && round() <= data(x).liexingUntil) this.addState(args[0]);
  return out;
});
function syncCounters(a) {
  var d = data(a); if (!d) return;
  a._codexXuanTacit = d.tacit;
  [['tonggui', d.tonggui], ['debt', d.debt > 0]].forEach(function(p) {
    var id = ids().state[p[0]]; if (!id) return;
    if (p[1] && !a.isStateAffected(id)) a.addState(id);
    if (!p[1] && a.isStateAffected(id)) a.removeState(id);
  });
}
// ---- 受益者：主宿主＋列星期间的星影 ----
function beneficiaries(a) {
  var h = host(a), list = h && live(h) ? [h] : [], d = data(a);
  if (d && round() <= d.liexingUntil) d.shadows.forEach(function(id) { var t = $gameActors.actor(id); if (live(t) && !B().untargetable(t) && members().indexOf(t) >= 0 && list.indexOf(t) < 0) list.push(t); });
  if (!h && d && round() <= d.liexingUntil) {} // 回归本体后已有星影按剩余期限继续
  var partner = $gameActors.actor(chart(a).partner);
  return {list: list, partner: partner && partner !== h && live(partner) && members().indexOf(partner) >= 0 ? partner : null};
}
X.beneficiaries = beneficiaries;
function inCover(a, t) { return beneficiaries(a).list.indexOf(t) >= 0; }
// ---- 技能就绪与内部施放 ----
function ready(a, key) {
  var id = ids().skill[key], s = $dataSkills[id];
  return !!(s && X.unlocked(a,key) && a.isLearnedSkill(id) && (!a.cooldown || a.cooldown(id) <= 0) && a.canPaySkillCost(s));
}
function canSpend(a, protect) {
  var b = B(), d = data(a), n = b.charges(a);
  if (n >= 2 || (n >= 1 && protect)) return true;
  if (n >= 1 && !protect) return !CFG.keepLastCharge; // 默认保留最后 1 点星契护主
  return false;
}
function borrow(a, key) {
  // 先照：没有星契时预支下一回合 1 点（每 3 回合一次、只允许一笔债）。
  var d = data(a), lv = markLevel(a, 'xianzhao');
  if (!lv || d.debt > 0 || round() - d.xianzhaoRound < CFG.marks.xianzhao.every) return false;
  var allowed = ['huiguang'].concat(lv >= 2 ? ['libi'] : [], lv >= 3 ? ['liexing'] : []);
  if (allowed.indexOf(key) < 0) return false;
  d.debt = 1; d.xianzhaoRound = round(); B().gain(a, 1); syncCounters(a);
  return true;
}
function cast(a, key, targets, setup, protect) {
  var b = B(); if (!b || !targets || !targets.length || !live(a)) return false;
  if (!X.autoEnabled(a) || !ready(a, key)) return false;
  if (!canSpend(a, protect) && !(b.charges(a) < 1 && protect && borrow(a, key))) return false;
  if (b.charges(a) < 1) return false;
  var done = b.cast(a, ids().skill[key], targets, {tag: 'xuan', setup: setup, text: CFG.lines[key]});
  if (!done) return false;
  b.spend(a, 1);
  var d = data(a); d.used[key] = true;
  return true;
}
X.cast = cast;
// ---- 反应：璃壁（伤害入口前）、回光（低血或被控）、棱光（宿主主动攻击后）、列星 ----
function lowHp(t) { return t.hp / Math.max(1, t.mhp) <= CFG.huiguang.below; }
X.isCleanseState=function(s,hard){return !!s&&s.id!==1&&!/无法解除|不可驱散|不能解除|Cannot Remove/i.test(s.note||'')&&(hard?s.restriction>0:(s.restriction>0||/<BuffType:\s*(?:减益|控制|诅咒|中毒|毒|麻痹|眩晕|混乱|睡眠|魅惑|愤怒|封印|减速|流血)/.test(s.note||'')));};
function cleansable(t){return t.states().filter(function(s){return X.isCleanseState(s,true);});}

function needRescue(t) { return live(t) && (lowHp(t) || cleansable(t).length > 0); }
function tryRescue(a, protect) {
  var cover = beneficiaries(a), list = cover.list.filter(needRescue);
  var partner = cover.partner && markLevel(a, 'binggui') >= 1 && needRescue(cover.partner) && !list.length ? [cover.partner] : [];
  var targets = list.length ? list : partner;
  if (!targets.length) return false;
  return cast(a, 'huiguang', targets, null, true);
}
function tryLiexing(a) {
  var d = data(a), h = host(a);
  if (!h || round() <= d.liexingUntil) return false;
  var others = members().filter(function(t) { return t !== h && t !== a && live(t) && !(W.CodexTusu && W.CodexTusu.isTusu(t) && B().isBound(t)); });
  if (!others.length || !ready(a, 'liexing')) return false;
  var ok = cast(a, 'liexing', [a], function(action) { action._codexXuanShadows = X.shadowCandidates(a).map(function(t) { return t.actorId(); }); }, true);
  return ok;
}
function onEnemyAction(action) {
  var a = xuan(); if (!a || !X.autoEnabled(a) || !B().isBound(a) || !action || !action.isForOpponent()) return;
  if ([1, 5].indexOf(action.item().damage.type) < 0) return;
  var cover = beneficiaries(a).list, targets;
  try { targets = action.makeTargets(); } catch (e) { targets = []; }
  var hit = cover.filter(function(t) { return targets.indexOf(t) >= 0 && live(t); });
  var partner = beneficiaries(a).partner;
  if (!hit.length && partner && markLevel(a, 'binggui') >= 2 && targets.indexOf(partner) >= 0) hit = [partner];
  if (!hit.length || data(a).used.libi) return;
  cast(a, 'libi', hit, null, true);
}
X.onEnemyAction = onEnemyAction;
alias(BattleManager, 'startAction', function(old, args) {
  try {
    var s = this._subject, act = s && s.currentAction();
    if (s && s.isEnemy() && act) onEnemyAction(act);
  } catch (e) { console.error('璇反应失败', e); }
  return old.apply(this, args);
});
alias(BattleManager, 'endAction', function(old, args) {
  var s = this._subject, act = this._action, a = xuan();
  try {
    if (a && X.autoEnabled(a) && B().isBound(a) && live(a)) {
      // 回光：救援优先
      tryRescue(a, true);
      // 列星：就绪且有其他有效队友时展开
      if (CFG.liexing.auto) tryLiexing(a);
      // 棱光：宿主（列星期间含星影所附队友）完成一次主动攻击后
      if (s && s.isActor && s.isActor() && act && !act._codexInternal && act.isForOpponent() && act.isDamage() && inCover(a, s)) {
        var target = act._codexXuanLastTarget || $gameTroop.aliveMembers()[0];
        followUp(a, s, act, target);
      }
    }
  } catch (e) { console.error('璇反应失败', e); }
  return old.apply(this, args);
});
alias(Game_Action.prototype, 'apply', function(old, args) {
  var t = args[0];
  if (t && t.isEnemy && t.isEnemy()) this._codexXuanLastTarget = t;
  return old.apply(this, args);
});
function followUp(a, origin, act, target) {
  if (!target || !target.isAlive()) target = $gameTroop.aliveMembers()[0];
  if (!target) return false;
  var targets = [target], lv = markLevel(a, 'fenguang');
  if (lv && act.isForAll()) targets = $gameTroop.aliveMembers().slice(0, [0, 2, 3, 4][lv]);
  var physical = act.isPhysical();
  return cast(a, 'lengguang', targets, function(action) {
    action._codexXuanSplit = targets.length;
    action._codexXuanDebuff = physical ? 3 : 5;
    var elements = act.item().damage.elementId > 0 ? [act.item().damage.elementId] : [];
    if (markLevel(a, 'tongdiao') >= 2 && elements.length) action._codexXuanElement = elements[0];
    else if (markLevel(a, 'tongdiao') >= 1 && chart(a).element) action._codexXuanElement = chart(a).element;
  }, false);
}
// ---- 技能效果 ----
alias(Game_Action.prototype, 'applyItemUserEffect', function(old, args) {
  var out = old.apply(this, args), key = ids().key[this.item().id], t = args[0], a = this.subject();
  try {
    if (!isXuan(a)) return out;
    if (key === 'huiguang') {
      var bad = cleansable(t)[0]; if (bad) { t.removeState(bad.id); if (markLevel(a, 'dingxing') >= 1) grantDingxing(a, t, bad.id); }
      if (data(a)) data(a).record.protect = true;
      // 同轨：回光内置一次棱光式协同
      tongguiStrike(a, this);
    }
    if (key === 'libi' && W.CodexShieldLedger) {
      CodexShieldLedger.grant(t, 'xuan.libi', X.shieldAmount(a, t), CFG.libi.turns, a.actorId());
      tongguiStrike(a, this);
    }
    if (key === 'lengguang' && t.isEnemy() && t.isAlive()) {
      t.addDebuff(3, CFG.lengguang.debuffTurns);
      t.addDebuff(5, CFG.lengguang.debuffTurns);
      if (markLevel(a, 'shihui') && round() - data(a).shihuiRound >= [0, 3, 2, 1][markLevel(a, 'shihui')]) {
        var buffs = [3, 5, 2, 4, 6, 7].filter(function(i) { return t._buffs[i] > 0; });
        if (buffs.length) { t.removeBuff(buffs[0]); data(a).shihuiRound = round(); }
      }
      if (data(a)) data(a).record.assist = true;
    }
    if (key === 'liexing') {
      var d = data(a); d.liexingUntil = round() + CFG.liexing.turns - 1;
      d.shadows = this._codexXuanShadows || X.shadowCandidates(a).map(function(t){return t.actorId();}); d.homeUsed=false;d.relicHealUsed=false;d.relicWallUsed=false;
      d.shadows.forEach(function(id) { var x = $gameActors.actor(id); if (x) x.addState(ids().state.shadow); });
      a.addState(ids().state.liexing);
      tongguiStrike(a, this);
      if (isRoster(a, host(a))) { var h = host(a), bad2 = h && cleansable(h)[0]; if (bad2) h.removeState(bad2.id); }
    }
  } catch (e) { console.error('璇效果失败', e); }
  return out;
});
// 专属法宝璇玑星盘：装备时回光治疗量、璃壁护盾量×CFG.relicBonus.heal。
function baseId(item) { return item ? Number(item.originalBaseItemId || item.baseItemId || item.id) : 0; }
function relicOn(a) { var id = ids().relic; return !!(a && id && a.equips && a.equips().some(function(e) { return e && baseId(e) === id; })); }
X.relicOn = relicOn;
function relicRate(a) { return relicOn(a) ? CFG.relicBonus.heal : 1; }
X.weight=function(a){return B().curve(a,[.1,.2,.35,.5,.65,.8,1],[1,10,20,30,40,50,60]);};
X.shieldAmount=function(a,t){return Math.max((CFG.libi.mat*num(a.mat)+CFG.libi.hp*num(a.mhp))*X.weight(a),B().curve(a,[.15,.35],[1,60])*num(t.mhp));};
X.healAmount=function(a,t){return Math.max(B().curve(a,[10,20],[1,60])*num(a.mat),B().curve(a,[.20,.35],[1,60])*num(t.mhp));};
// 面板公式：伤害＝璇魔攻×当前等级系数；已学成长被动进入原生增伤乘区，之后交给统一伤害。
X.damage = function(a, b, key) { return num(a.mat) * X.coefficient(key, a); };
X.heal = function(a, b) { return X.healAmount(a, b); };
// 统一伤害：分光按目标数分摊、同调指定元素。
if (W.CodexDamageHooks) W.CodexDamageHooks.push({name: 'xuan', build: function(action, target, f) {
  if (!isXuan(action.subject()) || ids().key[action.item().id] !== 'lengguang') return;
  if (action._codexXuanSplit > 1) f.finalMultiplier /= action._codexXuanSplit;
  if (action._codexXuanElement) f.elements = [action._codexXuanElement];
}});
// 余辉：回光的溢出转为璇同源护盾（溢出只用一次，余下的才进入谷雨储备）。
alias(Game_Battler.prototype, 'gainHp', function(old, args) {
  var value = num(args[0]), before = this.hp, act = BattleManager._action, a = act && act.subject && act.subject();
  var out = old.apply(this, args);
  if (value > 0 && a && isXuan(a) && act && ids().key[act.item().id] === 'huiguang' && W.CodexShieldLedger) {
    var over = Math.max(0, value - (this.hp - before)), lv = markLevel(a, 'yuhui');
    if (lv && over > 0) CodexShieldLedger.grant(this, 'xuan.yuhui', over * CFG.marks.yuhui.rate[lv - 1], CFG.libi.turns, a.actorId());
  }
  return out;
});
function tongguiStrike(a, action) {
  var d = data(a); if (!X.autoEnabled(a) || !d || !d.tonggui || action._codexXuanTonggui) return;
  var target = $gameTroop.aliveMembers()[0]; if (!target) return;
  action._codexXuanTonggui=true;
  var strike = new Game_Action(a); strike.setSkill(ids().skill.lengguang); strike._codexInternal = 'xuan-tonggui'; strike._codexXuanTonggui = true;
  strike._codexXuanDebuff = 5;
  strike.apply(target); if (target.startDamagePopup) target.startDamagePopup();
}
// 定星：成功净化控制后，下一个完整自然回合内阻止一次普通、可净化的硬控制。
function grantDingxing(a, t, cleansed) {
  var lv = markLevel(a, 'dingxing'), d = data(a);
  if (lv < 2 && !(round() <= d.liexingUntil)) return;
  d.dingxing[t.actorId()] = {until: round() + 1, numeric: lv >= 3};
  t.addState(ids().state.dingxing);
}
alias(Game_Battler.prototype, 'addState', function(old, args) {
  var a = $gameParty.inBattle() && xuan(), id = args[0], s = $dataStates[id];
  if (a && this.isActor && this.isActor() && data(a) && data(a).dingxing[this.actorId()] && X.isCleanseState(s,true) && !this.isStateAffected(id)) {
    var g = data(a).dingxing[this.actorId()];
    if (g.until >= round()) { delete data(a).dingxing[this.actorId()]; if (this.isStateAffected(ids().state.dingxing)) this.removeState(ids().state.dingxing); log(CFG.lines.dingxing); return; }
  }
  return old.apply(this, args);
});
// 移光：换宿主时迁移旧宿主身上的璇护盾；留辉：旧宿主保留一份共宿增益。
function transferEffects(a, previous, target) {
  var L = W.CodexShieldLedger, lv = markLevel(a, 'yiguang');
  if (L && lv && previous) {
    var rate = [0, 0.5, 0.75, 1][lv], moved = 0;
    ['xuan.libi', 'xuan.yuhui'].forEach(function(src) { var v = L.amount(previous, src); if (v > 0) { var m = Math.floor(v * rate); L.revoke(previous, src); if (v - m > 0) L.grant(previous, src, v - m, 1, a.actorId()); moved += m; } });
    if (moved > 0) L.grant(target, 'xuan.libi', moved, 1, a.actorId());
  }
  var keep = markLevel(a, 'liuhui');
  $gameParty.allMembers().forEach(function(x) { delete x._codexXuanAfterglow; });
  if (keep && previous && live(previous)) previous._codexXuanAfterglow = {until: round() + keep - 1, def: gongsuValue(a, 3), mdf: gongsuValue(a, 5)};
}
// 共宿面板与战斗共用当前成长值；未学会或未解锁时为0。
X.gongsuDamageRate = function(a) {
  return a && a.isLearnedSkill && a.isLearnedSkill(ids().skill.gongsu) && X.unlocked(a, 'gongsu') ? B().curve(a, [.10, .30], [10, 60]) : 0;
};
X.gongsuDefenseRate = function(a) {
  return a && a.isLearnedSkill && a.isLearnedSkill(ids().skill.gongsu) && X.unlocked(a, 'gongsu') ? B().curve(a, [.15, .30], [20, 60]) : 0;
};
// 共宿：主宿主与有效星影的直接伤害增益；不复制璇输出、不放大百分比/固定/已结算伤害。
X.hostDamageRate = function(t) {
  if (!$gameParty.inBattle() || !t || !t.isActor || !t.isActor() || isXuan(t)) return 0;
  var a = xuan();
  if (!a || !live(a) || !a.isLearnedSkill(ids().skill.gongsu) || !X.unlocked(a, 'gongsu') || !inCover(a, t)) return 0;
  return X.gongsuDamageRate(a);
};
if (W.CodexDamageHooks) W.CodexDamageHooks.push({name: 'xuan-host-offense', build: function(action, target, f) {
  if (['normal', 'true'].indexOf(f.kind) < 0 || !action.item() || !action.item().damage || [1, 5].indexOf(action.item().damage.type) < 0) return;
  var rate = X.hostDamageRate(action.subject());
  if (rate > 0) f.finalMultiplier *= 1 + rate;
}});
// ---- 共宿：附身时宿主获得璇双防的一部分（同源取较高值，不相加） ----
function gongsuValue(a, id) { return Math.floor(X.gongsuDefenseRate(a) * num(id === 3 ? a.def : a.mdf)); }
alias(Game_Actor.prototype, 'param', function(old, args) {
  var v = old.apply(this, args), id = args[0];
  if ((id === 3 || id === 5) && $gameParty.inBattle() && !this._codexXuanParam && !isXuan(this)) {
    var a = xuan();
    if (a && a.isLearnedSkill(ids().skill.gongsu)) {
      this._codexXuanParam = true;
      try {
        var bonus = 0, d = data(a);
        if (B().isBound(a) && inCover(a, this)) bonus = gongsuValue(a, id);
        var part = d && chart(a).partner === this.actorId() && markLevel(a, 'binggui') >= 3 ? gongsuValue(a, id) : 0;
        var glow = this._codexXuanAfterglow && this._codexXuanAfterglow.until >= round() ? this._codexXuanAfterglow[id === 3 ? 'def' : 'mdf'] : 0;
        v += Math.max(bonus, part, glow);
      } finally { this._codexXuanParam = false; }
    }
  }
  return v;
});
// ---- 回合末释放（6.2 顺序）、默契结算 ----
function roundEndRelease(a) {
  var b = B();
  if(!X.autoEnabled(a))return;
  while (b.charges(a) > 0) {
    var cover = beneficiaries(a).list, done = false;
    if (cover.some(function(t) { return t.hp < t.mhp || cleansable(t).length; })) done = cast(a, 'huiguang', cover.filter(function(t) { return t.hp < t.mhp || cleansable(t).length; }), null, true);
    if (!done && (a.hp < a.mhp * 0.5 || cleansable(a).length)) done = cast(a, 'huiguang', [a], null, true);
    if (!done && $gameTroop.aliveMembers().length) { var e = $gameTroop.aliveMembers()[0]; done = cast(a, 'lengguang', [e], function(x) { x._codexXuanDebuff = 5; }, true); }
    if (!done && host(a)) done = cast(a, 'libi', [host(a)], null, true);
    if (!done) break;
  }
}
function settleTacit(a) {
  var d = data(a); if (!d) return;
  var r = d.record || {}, gain = 0;
  if (host(a) && r.stayed === host(a).actorId() && r.transferRound !== round()) gain += CFG.tacit.stay;
  if (r.protect) gain += CFG.tacit.protect;
  if (r.assist) gain += CFG.tacit.assist;
  var extra=(r.protect||r.assist)&&a.level>=20?Math.floor(B().curve(a,[1,3],[20,60])):0;
  d.tacit = Math.min(100, d.tacit + Math.min(CFG.tacit.perRound, gain)+extra);
  d.tonggui = d.tacit >= 100 && B().isBound(a);
  syncCounters(a);
  // 列星到期
  if (d.liexingUntil >= 0 && round() >= d.liexingUntil) {
    d.shadows.forEach(function(id) { var x = $gameActors.actor(id); if (x && x.isStateAffected(ids().state.shadow)) { x._codexXuanUnmark = true; x.removeState(ids().state.shadow); delete x._codexXuanUnmark; } });
    d.shadows = []; d.liexingUntil = -1;
    if (a.isStateAffected(ids().state.liexing)) a.removeState(ids().state.liexing);
  }
}
// 护盾真实吸收外部伤害计护主一次。
if (W.CodexShieldLedger) {
  var oldAbsorb = CodexShieldLedger.onAbsorb;
  CodexShieldLedger.onAbsorb = function(b, amount, rows) {
    if (oldAbsorb) oldAbsorb.apply(this, arguments);
    var a = xuan(); if (a && data(a) && rows.some(function(r) { return /^xuan\./.test(r.source); })) data(a).record.protect = true;
  };
}
// ---- 开战：默契起始、星砂奖励（胜利结算一次） ----
alias(BattleManager, 'startBattle', function(old, args) {
  var out = old.apply(this, args), a = xuan();
  if (a) { var d = data(a) || fresh(a); if (!host(a)) d.tacit = 0; syncCounters(a); }
  return out;
});
alias(BattleManager, 'endBattle', function(old, args) {
  var a = xuan(), win = args[0] === 0;
  try {
    if (a && win) {
      var D = W.CodexBossDifficulty, boss = !!(D && $gameTroop.members().some(function(e) { return D.isBoss(e); }));
      chart(a).sand += boss ? CFG.chart.bossSand : CFG.chart.sand;
    }
  } catch (e) { console.error(e); }
  try { return old.apply(this, args); } finally {
    $gameParty.allMembers().forEach(function(x) { delete x._codexXuanAfterglow; ['hostmark', 'shadow', 'dingxing'].forEach(function(k) { var id = ids().state[k]; if (id && x._states && x._states.indexOf(id) >= 0) x.eraseState(id); }); });
  }
});
// ---- MP 费用：按璇的 MP 上限百分比 ----
alias(Game_Actor.prototype, 'skillMpCost', function(old, args) {
  var s = args[0], key = s && ids().key[s.id];
  if (key && isXuan(this) && CFG.mpRate[key] !== undefined) return B().percentMpCost(this, s, CFG.mpRate[key]);
  return old.apply(this, args);
});
// ---- 技能使用条件 ----
alias(Game_Actor.prototype, 'meetsSkillConditions', function(old, args) {
  var s = args[0], key = s && ids().key[s.id];
  if (isXuan(this) && $gameParty.inBattle() && B()) {
    var bound = B().isBound(this), d = data(this);
    if(bound&&X.autoEnabled(this)&&s.id!==this.guardSkillId()&&['jixing.possess','return'].indexOf(key)<0)return false;
    if (key === 'jixing.possess') return bound && (!X.autoEnabled(this)||B().charges(this)>=1) && !(d && d.used.jixing) && old.apply(this,args);
    if (key === 'jixing') return !bound && old.apply(this, args);
    if (key === 'liexing') return bound && !X.autoEnabled(this) && old.apply(this,args);
    if(bound && X.autoEnabled(this) && ['huiguang','libi','lengguang'].indexOf(key)>=0)return false;
  }
  if (key === 'menu.starchart') return !$gameParty.inBattle() && old.apply(this, args);
  return old.apply(this, args);
});
alias(Game_Action.prototype, 'apply', function(old, args) {
  var a = this.subject(), target = args[0], key = this.item() && ids().key[this.item().id];
  if (isXuan(a) && (key === 'jixing.possess' || key === 'jixing') && B()) {
    this.makeSuccess(target);
    if (B().canHost(a, target) && target !== host(a)) {
      if (key === 'jixing.possess') { if (!X.autoEnabled(a)||B().spend(a, 1)) { data(a).used.jixing = true; B().bind(a, target, 'transfer'); } }
      else B().bind(a, target, 'jixing');
    }
    return;
  }
  return old.apply(this, args);
});
// ---- 自动战斗：附身时防御；本体时先救、再寄星（命主优先）、再普通作战 ----
X.autoAction = function(a) {
  if (!isXuan(a) || !$gameParty.inBattle() || !B()) return null;
  var act = new Game_Action(a);
  if (B().isBound(a)) { if(X.autoEnabled(a)){act.setGuard();return act;} return null; }
  var hurt = members().filter(function(t) { return live(t) && t.hp / t.mhp < CFG.ai.heal; })[0];
  if (hurt && a.canUse($dataSkills[ids().skill.huiguang])) { act.setSkill(ids().skill.huiguang); act.setTarget(hurt.index()); return act; }
  var c = chart(a), pick = c.roster.slice(0, stage(a)).map(function(id) { return $gameActors.actor(id); }).filter(function(t) { return B().canHost(a, t); })[0] || B().defaultHost(a);
  if (pick && a.canUse($dataSkills[ids().skill.jixing])) { act.setSkill(ids().skill.jixing); act.setTarget(pick.index()); return act; }
  return null;
};
alias(Game_Actor.prototype, 'makeAutoBattleActions', function(old, args) {
  var out = old.apply(this, args);
  if (isXuan(this) && $gameParty.inBattle() && this.numActions() > 0) { var act = X.autoAction(this); if (act) this._actions[0] = act; }
  return out;
});
(W.CodexAIEstimators = W.CodexAIEstimators || []).push(function(a, b, item) {
  var key = ids().key[item.id]; if (!key) return undefined;
  if (key === 'lengguang') return X.damage(a, b, 'lengguang');
  return 0;
});
// ---- 招募 ----
X.recruit = function() {
  var i = ids(), a = $gameActors.actor(i.actor); if (!a) return false;
  if ($gameParty._actors.indexOf(i.actor) >= 0) return false;
  $gameParty.addActor(i.actor);
  chart(a); syncMarkSkills(a);
  if (!a._codexXuanRelicGiven && i.relic) {
    a._codexXuanRelicGiven = true;
    var relic = $dataArmors[i.relic]; $gameParty.gainItem(relic, 1);
    var slot = a.equipSlots().indexOf(relic.etypeId);
    if (slot >= 0) { var owned = $gameParty.armors().filter(function(x) { return x && (x.baseItemId || x.id) === i.relic; }).slice(-1)[0] || relic; a.changeEquip(slot, owned); }
  }
  return true;
};
// ---- 星谱（菜单）：三槽配纹、学习与强化、回收、并轨副宿主、命主名册、同调元素 ----
X.learn = function(a, m) {
  var c = chart(a), lv = num(c.level[m]); if (a.level<CFG.chart.unlockLevels[SLOT_OF[m]]||lv >= 3) return false;
  var cost = CFG.chart.cost[lv]; if (c.sand < cost) throw Error('星砂不足（需要' + cost + '）');
  c.sand -= cost; c.level[m] = lv + 1; if (lv > 0) c.spent[m] = num(c.spent[m]) + cost;
  syncMarkSkills(a); return true;
};
X.refund = function(a, m) { var c = chart(a); if (num(c.level[m]) <= 1) return false; c.sand += num(c.spent[m]); c.spent[m] = 0; c.level[m] = 1; syncMarkSkills(a); return true; };
X.equip = function(a, m) { var c = chart(a); if (a.level<CFG.chart.unlockLevels[SLOT_OF[m]]||!c.level[m]) return false; c.slots[SLOT_OF[m]] = m; syncMarkSkills(a); return true; };
X.openStarchart = function() {
  var a = $gameActors.actor(ids().actor);
  if (!a || $gameParty._actors.indexOf(a.actorId()) < 0) return;
  B().openMenu(function(scene) { starMenu(scene, a); });
};
function markLabel(a, m) { var c = chart(a), lv = num(c.level[m]); return CFG.names['mark_' + m] + (lv ? '　熟练' + lv : '　未学') + (c.slots[SLOT_OF[m]] === m ? '　[已配]' : ''); }
function starMenu(scene, a) {
  var Y = W.CodexYunshang, c = chart(a);
  var info = ['星谱　星砂 ' + c.sand, '护主：' + CFG.names['mark_' + c.slots[0]] + '　协同：' + CFG.names['mark_' + c.slots[1]] + '　结缘：' + CFG.names['mark_' + c.slots[2]]];
  var rows = [0,1,2].map(function(s){return {label:['护主','协同','结缘'][s]+'槽：选择星纹',slot:s,enabled:a.level>=CFG.chart.unlockLevels[s]};});
  rows.unshift({label:'自动支援：'+(a._codexXuanControl==='auto'?'自动':'手动')+(X.autoQualified(a)?'':'（50级第三阶解锁）'),control:true,enabled:X.autoQualified(a)});
  rows.push({label: '并轨副宿主：' + (c.partner ? $gameActors.actor(c.partner).name() : '未指定'), partner: true});
  rows.push({label: '命主名册（' + stage(a) + '席）', roster: true, enabled: stage(a) > 0});
  rows.push({label: '同调指定元素：' + (c.element ? $dataSystem.elements[c.element] : '未指定'), element: true});
  Y.choose(scene, rows, function(r) {
    try {
      if(r.control){X.setControl(a,a._codexXuanControl==='auto'?'manual':'auto');return starMenu(scene,a);}
      if (r.slot !== undefined) return slotMenu(scene, a, r.slot);
      if (r.partner) return pickActor(scene, a, '并轨副宿主', function(id) { c.partner = id; });
      if (r.roster) return pickActor(scene, a, '命主名册（最多' + stage(a) + '人）', function(id) { var i = c.roster.indexOf(id); if (i >= 0) c.roster.splice(i, 1); else { c.roster.push(id); c.roster = c.roster.slice(-stage(a)); } });
      if (r.element) return Y.choose(scene, $dataSystem.elements.map(function(n, i) { return {label: n || '无', id: i}; }).filter(function(x) { return x.id >= 2 && x.label; }), function(x) { c.element = x.id; starMenu(scene, a); }, function() { starMenu(scene, a); }, ['同调熟练1：本场棱光使用指定元素']);
    } catch (e) { if (W.$ && $.toaster) $.toaster({message: e.message}); starMenu(scene, a); }
  }, function() { scene.popScene(); }, info);
}
function slotMenu(scene, a, slot) {
  var Y = W.CodexYunshang, c = chart(a), list = MARKS.filter(function(m) { return SLOT_OF[m] === slot; });
  Y.choose(scene, list.map(function(m) { return {label: markLabel(a, m), m: m}; }), function(r) {
    Y.choose(scene, [{label: '配入此槽', act: 'equip', enabled: !!c.level[r.m]},
                     {label: (c.level[r.m] ? '强化（星砂' + CFG.chart.cost[c.level[r.m]] + '）' : '学习（星砂' + CFG.chart.cost[0] + '）'), act: 'learn', enabled: num(c.level[r.m]) < 3},
                     {label: '回收强化星砂', act: 'refund', enabled: num(c.level[r.m]) > 1}], function(x) {
      try { X[x.act](a, r.m); } catch (e) { if (W.$ && $.toaster) $.toaster({message: e.message}); }
      slotMenu(scene, a, slot);
    }, function() { slotMenu(scene, a, slot); }, [CFG.names['mark_' + r.m], CFG.names['markDesc_' + r.m]]);
  }, function() { starMenu(scene, a); }, ['星砂 ' + c.sand]);
}
function pickActor(scene, a, title, fn) {
  var Y = W.CodexYunshang;
  Y.choose(scene, $gameParty.allMembers().filter(function(t) { return t !== a && !(W.CodexTusu && W.CodexTusu.isTusu(t)); }).map(function(t) { return {label: t.name(), id: t.actorId()}; }),
    function(r) { fn(r.id); starMenu(scene, a); }, function() { starMenu(scene, a); }, [title]);
}
// ---- 读档同步、战斗外清理 ----
// 读档：补学职业表里新增的 1 级技能（v0.6 新增被动）；已有的法宝实例按底本同步名称与说明。
function syncNative(a) {
  var c = a.currentClass && a.currentClass();
  if (c) c.learnings.forEach(function(l) { if (l.level <= a.level && $dataSkills[l.skillId] && !a.isLearnedSkill(l.skillId)) a.learnSkill(l.skillId); });

}
X.syncNative = syncNative;
alias(DataManager, 'extractSaveContents', function(old, args) {
  var out = old.apply(this, args), a = $gameActors && $gameActors._data[ids().actor];
  if (a) { syncNative(a); chart(a); syncMarkSkills(a); delete a._codexXuan; }
  return out;
});

X.autoQualified=function(a){return !!a&&a.level>=50&&stage(a)>=3;};
X.autoEnabled=function(a){return X.autoQualified(a)&&($gameParty.inBattle()?a._codexXuanBattleControl==='auto':a._codexXuanControl==='auto');};
X.setControl=function(a,mode){if($gameParty.inBattle()||!X.autoQualified(a)||['manual','auto'].indexOf(mode)<0)return false;a._codexXuanControl=mode;return true;};
X.shadowLimit=function(a){return !a||!X.unlocked(a,'liexing')?0:a.level>=60?99:a.level>=50?3:a.level>=40?2:1;};
X.shadowCandidates=function(a){var h=host(a),c=chart(a),limit=X.shadowLimit(a);
 return members().filter(function(t){return t!==a&&t!==h&&live(t)&&!B().untargetable(t);}).sort(function(x,y){return (y.actorId()===c.partner?1:0)-(x.actorId()===c.partner?1:0)||x.hp/x.mhp-y.hp/y.mhp||x.index()-y.index();}).slice(0,limit);};
alias(BattleManager,'startBattle',function(old,args){var a=xuan();if(a)a._codexXuanBattleControl=X.autoQualified(a)&&a._codexXuanControl==='auto'?'auto':'manual';return old.apply(this,args);});
alias(BattleManager,'endBattle',function(old,args){try{return old.apply(this,args);}finally{var a=$gameActors._data[ids().actor];if(a)delete a._codexXuanBattleControl;}});
alias(Game_Action.prototype,'makeTargets',function(old,args){
 var targets=old.apply(this,args),a=this.subject(),k=this.item()&&ids().key[this.item().id];
 if(isXuan(a)&&!this._codexInternal&&['huiguang','libi'].indexOf(k)>=0&&data(a)&&round()<=data(a).liexingUntil){
  X.beneficiaries(a).list.forEach(function(t){if(targets.indexOf(t)<0)targets.push(t);});
 }
 if(isXuan(a)&&!this._codexInternal&&k==='lengguang'&&data(a)&&round()<=data(a).liexingUntil){var original=targets.slice();X.beneficiaries(a).list.filter(function(t){return t!==host(a);}).forEach(function(){targets=targets.concat(original);});}
 return targets;
});
alias(Game_Action.prototype,'speed',function(old,args){var v=old.apply(this,args),a=this.subject(),k=this.item()&&ids().key[this.item().id];return isXuan(a)&&!X.autoEnabled(a)&&k==='libi'&&markLevel(a,'xianzhao')?v+100000:v;});

registerBinding();
B().bindGrowth(X, CFG, ids, isXuan, xuan);
alias(Game_Action.prototype,'apply',function(old,args){
  var a=this.subject(),k=this.item()&&ids().key[this.item().id];
  if(isXuan(a)&&k==='return'){this.makeSuccess(args[0]);B().unbind(a,'return');return;}
  return old.apply(this,args);
});
alias(Window_ActorCommand.prototype,'makeCommandList',function(old,args){
  var out=old.apply(this,args),a=this._actor;
  if(isXuan(a)&&B().isBound(a))this.addCommand('回身','codexXuanReturn',a.canUse($dataSkills[ids().skill.return]));
  return out;
});
alias(Scene_Battle.prototype,'createActorCommandWindow',function(old,args){
  var out=old.apply(this,args),scene=this;
  this._actorCommandWindow.setHandler('codexXuanReturn',function(){var a=BattleManager.inputtingAction();if(a){a.setSkill(ids().skill.return);scene.selectNextCommand();}});return out;
});
alias(Window_BattleActor.prototype,'isCurrentItemEnabled',function(old,args){
  var action=BattleManager.inputtingAction(),a=action&&action.subject(),key=action&&action.item()&&ids().key[action.item().id];
  if(isXuan(a)&&(key==='jixing'||key==='jixing.possess'))return B().canHost(a,this.actor())&&this.actor()!==host(a);
  return old.apply(this,args);
});
})(window, CFG);

});
