// 【Codex·未经Claude检验】v0.28 赠春／还春窗口参与战斗输入互斥；未经claude检验。
// 【Codex·未经Claude检验】v0.23 玩家反馈与平衡修复；未经claude检验。
// 【Codex·未经Claude检验】核查状态：未经claude检验。2026-10-11 谷雨原素材待机稳定修复。
// 本轮维护源：three-growth-install-20261009-114400；禁止用旧安装器覆盖。
// 谷雨 v0.3.1；唯一维护源：design/guyu/v0.3.1。旧安装器不得覆盖当前正式版。
window.CodexRuntime.register("installNativeGuyuRuntime", function() {
var CFG = {"ai":{"healBelow":0.35,"shieldBelow":0.7,"shieldWhenHurt":2,"openAtReserve":0.5,"finishAtReserve":0.8,"shieldPressure":0.2},"anim":{"heal":48,"open":589,"transfer":33,"shield":478,"finish":178,"bloom":33,"root":0,"regenerate":50},"bloom":{"ratio":0.25,"budRatio":0.35,"k":[5,5.5,6,6.5,7,7.5]},"finish":{"k":[0,0,0,40,44,48],"masteryPerLevel":0.15},"growth":{"ratio":0.2},"heal":{"base":0.3,"perStage":0.04,"levelGrowthAt99":0.3},"icons":{"atlas":"Guyu_Icons","atlasStart":220000,"relicSlot":0,"skillGlyph":{"heal":791,"open":812,"transfer":795,"shield":793,"finish":804,"echo":803,"substitute":807,"root":813,"growth":801,"spring":810,"relic":1209,"bloom":812},"skillQuality":{"heal":9,"open":9,"transfer":9,"shield":10,"finish":12,"echo":10,"substitute":12,"root":10,"growth":10,"spring":12,"relic":10,"bloom":9}},"mp":{"heal":0.06,"open":0.05,"transfer":0.02,"shield":0.03,"finish":0.08},"reserve":{"capRatio":[1.0,1.25,1.5,1.75,2.0,2.5]},"root":{"ratio":0.5},"shield":{"ratio":0.3,"targetCapRatio":1.0},"shop":{"mapId":132},"stone":{"name":"谷种金缮石","iconIndex":228,"quality":6,"dropOneIn":50},"transfer":{"ratio":0.5,"relicRatios":[0.25,0.5,0.75]},"unlock":{"heal":0,"open":0,"echo":0,"substitute":0,"root":0,"transfer":0,"relic":0,"shield":0,"finish":0,"growth":0,"spring":5},"skillLevels":{"heal":1,"echo":1,"transfer":5,"open":10,"shield":15,"substitute":25,"root":25,"finish":35,"growth":45,"spring":60,"relic":10}};
/* 谷雨·生命花期 v0.3.1
 * 由 compile_runtime.py 编译；CFG 来自本目录 guyu_design.json。旧整包安装器禁止覆盖当前正式版。
 * 角色、技能、法宝、号角、进阶石均按备注标签动态查找，不写死数据库 ID。
 */
(function(W, CFG) {
'use strict';
if (W.Guyu) return;
var G = W.Guyu = {version: '0.3.1', config: CFG, activeBattle: false, round: 0, flowerUntil: -1, flowerSerial: 0, openAt: 0, seed: null,
  events: [], serial: 0, rows: new WeakMap(), tracked: new Set(), internal: 0, unprotected: 0, calcOwner: null, healing: null,
  totals: null};
function freshTotals() { return {generated: 0, wasted: 0, spent: 0, transferred: 0, blooms: 0, damage: 0, deaths: 0, regenerations: 0, healed: 0, shielded: 0, bloomDamage: 0, finishDamage: 0}; }
G.totals = freshTotals();

// ---------- 查找 ----------
function tag(obj, name) { return !!(obj && ((obj.meta && obj.meta[name] !== undefined) || new RegExp('<' + name + '(?:[:>])', 'i').test(obj.note || ''))); }
function key(item) { if (!item) return ''; return item.meta && item.meta.GuyuSkill || ((item.note || '').match(/<GuyuSkill:([^>]+)>/) || [])[1] || ''; }
var idCache = null;
function ids() {
  if (idCache && idCache.db === W.$dataSkills) return idCache;
  var out = {db: W.$dataSkills, skill: {}, skillKey: {}, actor: 0, relic: 0, horn: 0, stone: 0};
  (W.$dataSkills || []).forEach(function(s) { var k = key(s); if (k) { out.skill[k] = s.id; out.skillKey[s.id] = k; } });
  (W.$dataActors || []).forEach(function(a) { if (!out.actor && tag(a, 'GuyuActor')) out.actor = a.id; });
  (W.$dataArmors || []).forEach(function(a) { if (!out.relic && tag(a, 'GuyuRelic')) out.relic = a.id; });
  (W.$dataItems || []).forEach(function(i) { if (!out.horn && tag(i, 'GuyuHorn')) out.horn = i.id; if (!out.stone && tag(i, 'GuyuStone')) out.stone = i.id; });
  return idCache = out;
}
G.ids = ids;
function members() { return W.$gameParty && $gameParty.battleMembers ? $gameParty.battleMembers() : []; }
function isGuyu(b) { return !!(b && b.isActor && b.isActor() && tag(b.actor(), 'GuyuActor')); }
function stage(b) { return Math.max(0, Math.min(5, Math.floor(Number(b && b._AdvancedNum) || 0))); }
function at(list, n) { return list[Math.max(0, Math.min(list.length - 1, n))]; }
function row(b) { if (G.activeBattle) G.tracked.add(b); var r = G.rows.get(b); if (!r) { r = {e: 0, shield: 0, shieldUntil: -1, rootUntil: -1, bud: false, budFlower: 0}; G.rows.set(b, r); } return r; }
function current() { return G.events[G.events.length - 1] || null; }
function guyu() { return members().filter(isGuyu)[0] || null; }
function active() { var g = guyu(); return G.activeBattle && g && g.hp > 0 && g.isAlive() && row(g).rootUntil < 0 && !G.events.some(function(e) { return e.guyu === g && e.pendingDeath; }) ? g : null; }
function finite(v) { v = Number(v); if (!isFinite(v) || v < 0) throw new Error('谷雨生命资源出现无效数值'); return Math.floor(v); }
function rawRefresh(b) { G.internal++; try { b.refresh(); } finally { G.internal--; } }
var paramCalls = new WeakMap();
// 不含储备的生命上限：让本模块的 param 包装暂时不加 E。
function baseMhp(b) { var d = paramCalls.get(b) || 0; paramCalls.set(b, d + 1); try { return b.param(0); } finally { paramCalls.set(b, d); } }
G.baseMhp = baseMhp;
function providerStage() { var g = guyu(); return g ? stage(g) : 0; }
function referenceCap(b){return Math.floor((W.CodexBinding.curve(guyu(),[1,1.25,1.5,1.75],[1,20,40,60])+.15*providerStage())*baseMhp(b));}
function cap(b){return isGuyu(b)?Infinity:referenceCap(b);}
G.cap = function(b) { return G.activeBattle ? cap(b) : 0; };
function addE(b, v) {
  var n = finite(v); if (!n) return 0;
  var r = row(b), room = Math.max(0, cap(b) - r.e), add = Math.min(n, room);
  G.totals.wasted += n - add; if (!add) return 0;
  r.e += add; b._hp = Math.min(b._hp, b.mhp); rawRefresh(b); G.totals.generated += add; return add;
}
function pay(b, q) { q = finite(q); var g = active(), s = g && G.unlocked(g,'spring') ? 0 : q; if (s) { var r = row(b); r.e = Math.max(0, r.e - s); b._hp = Math.min(b._hp, b.mhp); rawRefresh(b); G.totals.spent += s; } return s; }
function clearBud(r) { r.bud = false; r.budFlower = 0; }
function closeFlower() { G.flowerUntil = -1; G.seed = null; G.openAt = G.round + 2; G.tracked.forEach(function(b) { clearBud(row(b)); }); }
function blooming() { return G.flowerUntil >= G.round && !!active(); }
function log(text) { var win = W.BattleManager && BattleManager._logWindow; if (win && win.push) win.push('addText', text); }
function anim(target, id) { if (id && target && target.startAnimation) target.startAnimation(id, false, 0); }

G.skillLevel=function(k){return CFG.skillLevels[k]||1;};
G.unlocked=function(a,k){return !!a&&a.level>=G.skillLevel(k)&&(k!=='spring'||stage(a)>=5);};
G.isGuyu = isGuyu; G.stageOf = stage; G.reserve = function(b) { return G.activeBattle ? row(b).e : 0; };
G.isRooted = function(b) { return G.activeBattle && row(b).rootUntil >= 0; };
G.hasBud = function(b) { var r = row(b); return G.activeBattle && !!r.bud && r.budFlower >= G.flowerSerial; };
G.shield = function(b) { if (!G.activeBattle) return 0; var L = W.CodexShieldLedger; return L ? L.amount(b, 'guyu.shield') : row(b).shield; };
G.totalShield = function(b) { return (Number(b && b.shield) || 0) + (W.CodexShieldLedger ? 0 : G.shield(b)); }; // 账本护盾已计入 shield 合计
G.reset = function() { G.springReturnDone=false; G.roundTaken = 0; G.lastRoundPressure = 0; G.activeBattle = false; G.round = 0; G.flowerUntil = -1; G.flowerSerial = 0; G.openAt = 0; G.seed = null; G.events = []; G.rows = new WeakMap(); G.tracked = new Set(); G.healing = null; G.internal = 0; G.unprotected = 0; G.calcOwner = null; G.testRelicActor = null; };
G.withUnprotected = function(fn) { G.unprotected++; try { return fn(); } finally { G.unprotected--; } };

// ---------- 行动事件：代命以“同一来源行动”为单位 ----------
G.begin = function(action, eligible) {
  var g = active(), e = {id: ++G.serial, action: action, guyu: g, protected: new Set(), pendingDeath: false, eligible: !!eligible, executed: false, heights: new Map()};
  if (g && G.unlocked(g,'substitute')) members().forEach(function(b) { if (b !== g && b.hp > 0 && b.isAlive()) e.protected.add(b); e.heights.set(b, b.mhp); });
  G.events.push(e); return e;
};
function root(g, forced) {
  var r = row(g); if (!G.unlocked(g,'root') || r.rootUntil >= 0) return;
  var q = Math.floor(r.e * CFG.root.ratio), s = G.unlocked(g,'spring') ? 0 : q; if (s) { r.e -= s; G.totals.spent += s; }
  G.totals.deaths++; closeFlower();
  if (forced) {
    G.internal++; try {
      g._hp = 0; g._immortalState = false; g.addState(g.deathStateId());
      // 代命责任一旦成立，同源回复或外部即时复活不能取消归根。
      g._hp = 0;
      if (!g.isStateAffected(g.deathStateId())) {
        // 死亡免疫不能取消已经成立的代命，但必须完整执行死亡清理与排序。
        g.addNewState(g.deathStateId());
        g.resetStateCounts(g.deathStateId());
        g.result().pushAddedState(g.deathStateId());
      }
      r.rootUntil = G.round + 1;
      g.clearActions(); rawRefresh(g);
    } finally { G.internal--; }
  }
  r.rootUntil = G.round + 1;
  if (!forced) { g.need_refresh = true; rawRefresh(g); }
  if (g.requestMotion) g.requestMotion('dead');
  if (g.requestMotionRefresh) g.requestMotionRefresh();
  queueVisual(g, 'root');
  anim(g, CFG.anim.root);
  log('众生之劫，归于我身：谷雨代替倒下。');
}
function protect(b) {
  var e = current(); if (!e || !e.guyu || !e.protected.has(b) || G.internal || G.unprotected) return false;
  // 原有死亡免疫与 YEP 动作不死保护优先。
  if (b.isStateResist(b.deathStateId()) || (b.isImmortal && b.isImmortal())) return false;
  e.pendingDeath = true; b._hp = 1; return true;
}
function validSeed() { var alive = W.$gameTroop && $gameTroop.aliveMembers ? $gameTroop.aliveMembers() : []; if (G.seed && G.seed.isAlive()) return G.seed; G.seed = alive[0] || null; return G.seed; }
G.bloom = function(b) {
  var g = active(), target = validSeed(); if (!g || !target || !b || members().indexOf(b) < 0 || !b.isAlive() || !blooming()) return;
  var r = row(b), bud = G.hasBud(b) && r.budFlower === G.flowerSerial, q = Math.floor(r.e * (bud ? (hasSpring(g)&&g.level>=60?.5:CFG.bloom.budRatio) : CFG.bloom.ratio)); if (q < 1) return;
  pay(b, q); clearBud(r); G.totals.blooms++;
  var action = new Game_Action(b); action.setSkill(ids().skill.bloom);
  action._guyuPower = q * W.CodexBinding.curve(g,[5,6,7,8],[1,20,40,60]) * (hasSpring(g)&&g.level>=20&&r.springBoost?(g.level>=60?1.2:1.1):1); action._guyuOwner = g; action._guyuInternal = true; r.springBoost=false;
  anim(target, CFG.anim.bloom);
  action.apply(target); // YEP_BattleEngineCore在apply中提交一次弹字。
  var win = BattleManager._logWindow;
  if (win && win.displayActionResults) {
    // Slow battle logs otherwise enqueue a second popupDamage after YEP's apply popup.
    var push = win.push, ownPush = Object.prototype.hasOwnProperty.call(win, 'push');
    if (push) win.push = function(method) { if (method === 'popupDamage') return; return push.apply(this, arguments); };
    try { win.displayActionResults(b, target); }
    finally { if (push) { if (ownPush) win.push = push; else delete win.push; } }
  } else if (target.isDead() && target.performCollapse) target.performCollapse();
};
G.afterAction = function(e) {
  var a = e && e.action, item = a && a.item(), k = key(item), b = a && a.subject();
  if (e && e.eligible && e.executed && b && b.isAlive() && a.isSkill() && !a.isGuard() && !a._guyuInternal && ['open', 'shield', 'finish'].indexOf(k) < 0) G.bloom(b);
};
G.end = function(e, deferBloom) {
  if (!e) return; var i = G.events.lastIndexOf(e); if (i < 0) return;
  G.events.splice(i, 1);
  if (e.pendingDeath && e.guyu) root(e.guyu, true);
  if (!deferBloom) G.afterAction(e);
};
function isolated(action, fn) { var e = G.begin(action, false); try { return fn(); } finally { G.end(e); } }
function regenerate(g) {
  var r = row(g); G.internal++; G.regenerating = g;
  try {
    r.rootUntil = -1; g.removeState(g.deathStateId()); g._hp = g.mhp; rawRefresh(g);
    if (!G.ending && BattleManager.isOTB && BattleManager.isOTB() && BattleManager.otbInsertRevivalActionOrders) BattleManager.otbInsertRevivalActionOrders(g);
    if (g.requestMotionRefresh) g.requestMotionRefresh();
  } finally { G.internal--; G.regenerating = null; }
  G.totals.regenerations++;
  if(hasRelic(g)&&g.level>=60&&!G.springReturnDone){G.springReturnDone=true;var q=Math.floor(baseMhp(g)*.18);addE(g,q);var t=members().filter(function(b){return b!==g&&b.isAlive()&&!G.isRooted(b);}).sort(function(a,b){return row(a).e/Math.max(1,cap(a))-row(b).e/Math.max(1,cap(b));})[0];if(t)addE(t,q);} if (!G.ending) queueVisual(g, 'regenerate'); anim(g, CFG.anim.regenerate); log('骨生花：谷雨再生。');
}
G.endRound = function() {
  if (!G.activeBattle) return;
  var pool = members().reduce(function(s, b) { return s + Math.max(1, b.mhp); }, 0);
  G.lastRoundPressure = (G.roundTaken || 0) / Math.max(1, pool); G.roundTaken = 0;
  var othersAlive = members().some(function(b) { return !isGuyu(b) && b.isAlive() && b.hp > 0; });
  G.tracked.forEach(function(b) { var r = row(b); if (r.shieldUntil <= G.round) { r.shield = 0; r.shieldUntil = -1; } });
  if (G.flowerUntil >= 0 && G.flowerUntil <= G.round) closeFlower();
  var g = guyu(); if (g && row(g).rootUntil >= 0 && row(g).rootUntil <= G.round && othersAlive) regenerate(g);
};
G.finishBattle = function(result) {
  var all = W.$gameParty && $gameParty.allMembers ? $gameParty.allMembers() : members(), g = guyu();
  var survivor = members().some(function(b) { return b !== g && b.isAlive() && b.hp > 0; });
  G.ending = true; try { if (result !== 2 && g && row(g).rootUntil >= 0 && survivor) regenerate(g); } finally { G.ending = false; }
  all = Array.from(new Set(all.concat(Array.from(G.tracked).filter(function(b) { return b.isActor && b.isActor(); }))));
  G.lastTotals = G.totals;
  G.reset(); all.forEach(function(b) { b._hp = Math.min(b._hp, b.mhp); rawRefresh(b); });
};

// ---------- 数值 ----------
function relicHealingStrength(b) {
  var bonus = 0; if (!isGuyu(b)) return bonus;
  (b._equips || []).forEach(function(item) {
    var obj = item && item.object && item.object(); if (!tag(obj, 'GuyuRelic')) return;
    var m = obj.meta || {}, level = obj.level !== undefined ? Number(obj.level) : (item.level ? item.level() : 1);
    bonus += (Number(m.GuyuHealStrength) || 0) + (Number(m.GuyuHealStrengthPerLevel) || 0) * Math.max(0, (Number(level) || 1) - 1);
  });
  return bonus;
}
G.relicHealingStrength = relicHealingStrength;
G.healRatio = function(a) {
  var p=W.CodexBinding.curve(a,[.25,.30,.35,.40],[1,20,40,60]),strength=1;
  if(a.iteratePassiveSkill)a.iteratePassiveSkill('passiveHEUP',function(v){strength*=1+Number(v)*.01;});
  return p*strength;
};
G.healFormula = function(a, b) {
  var e = current(), h = e && e.heights.has(b) ? e.heights.get(b) : b.mhp;
  // 强度在引擎取整前计入一次；治疗元素与受治疗修正仍走原流程。
  return h * G.healRatio(a);
};
G.finishPower = function(g, e) { return e * W.CodexBinding.curve(g,[33,50],[40,60]); };
G.shieldValue = function(g) { return Math.floor(row(g).e * CFG.shield.ratio); };
G.mpRate = function(k) { return CFG.mp[k]; };

function doSpecial(action, target) {
  var k = key(action.item()), b = action.subject(), e = current(); if (!isGuyu(b) || !e || !active()) return;
  var required = CFG.unlock[k]; if (required !== undefined && !G.unlocked(b,k)) return;
  if (k === 'open' && !action._guyuSpecialDone) {
    if (!target.isAlive() || G.flowerUntil >= G.round || G.round < G.openAt) return;
    action._guyuSpecialDone = true; G.flowerSerial++; G.flowerUntil = G.round + 1; G.seed = target; log('请与我共赴花期。');
  } else if (k === 'transfer' && !action._guyuSpecialDone) {
    var p = G.transferPreview(b, target, action._guyuTransferMode, action._guyuRatio); if (!p.valid) return;
    action._guyuSpecialDone = true;
    row(p.from).e -= p.amount; row(p.to).e += p.amount; [p.from, p.to].forEach(function(x) { x._hp = Math.min(x._hp, x.mhp); rawRefresh(x); });
    G.totals.transferred += p.amount;
    if (hasSpring(b) && p.from === b) { var bud = row(p.to); bud.bud = true; bud.budFlower = G.flowerSerial + (blooming() ? 0 : 1); }
  } else if (k === 'shield') {
    if (members().indexOf(target) < 0 || !target.isAlive() || G.isRooted(target)) return;
    if (!action._guyuSpecialDone) { action._guyuShieldValue = G.shieldValue(b); if (action._guyuShieldValue < 1) return; action._guyuSpecialDone = true; pay(b, action._guyuShieldValue); }
    var r = row(target), v = Math.min(action._guyuShieldValue, Math.floor(CFG.shield.targetCapRatio * baseMhp(target)));
    if (W.CodexShieldLedger) CodexShieldLedger.grant(target, 'guyu.shield', v, 2, b.actorId(), {noDecay: true, noHalve: true, noBonus: true, skip: function() { return G.unprotected > 0; }});
    else { r.shield = Math.max(r.shield, v); r.shieldUntil = G.round + 1; }
    if(!r.springShieldAction||r.springShieldAction!==action){r.springShieldAction=action;r.springBoost=false;r.springHitUsed=false;}
    G.totals.shielded += v;
  } else if (k === 'finish' && !action._guyuSpecialDone) {
    if (!blooming() || row(b).e < 1) return;
    action._guyuSpecialDone = true; var q = row(b).e; action._guyuPower = G.finishPower(b, q);
    pay(b, q); closeFlower();
  }
}
// 装备与进阶都满足才开放百谷生；测试开关不进入正式装备判断。
function hasRelic(b) { return !!(isGuyu(b) && b.level>=10 && (G.testRelicActor === b || (b.equips && b.equips().some(function(x) { return tag(x, 'GuyuRelic'); })))); }
G.hasRelic = hasRelic;
// 先许一枝开（谷雨成长被动，2026-10-10 由法宝词条改为被动，不需要装备法宝）：10级起赠春可选比例并让受赠者待绽，20级起花荫强化，60级提高。
function hasSpring(b) { return !!(isGuyu(b) && b.level >= 10); }
G.hasSpring = hasSpring;
G.setTestRelic = function(b, enabled) { G.testRelicActor = enabled ? b : null; };
G.transferRatios = function(b) { return hasSpring(b) ? CFG.transfer.relicRatios : [CFG.transfer.ratio]; };
G.transferPreview = function(b, target, mode, ratio) {
  var result = {valid: false, amount: 0, reason: '请选择存活的出战队友'};
  if (!G.activeBattle || b !== active() || !G.unlocked(b,'transfer') || !target || target === b || members().indexOf(target) < 0 || !target.isActor() || !target.isAlive() || G.isRooted(target)) return result;
  mode = mode === undefined ? 'give' : mode; ratio = ratio === undefined ? CFG.transfer.ratio : Number(ratio);
  if (['give', 'back'].indexOf(mode) < 0 || !isFinite(ratio) || G.transferRatios(b).indexOf(ratio) < 0) { result.reason = '当前装备不支持此转移方式'; return result; }
  result.from = mode === 'back' ? target : b; result.to = result.from === b ? target : b;
  var want = Math.floor(row(result.from).e * ratio), room = Math.max(0, cap(result.to) - row(result.to).e);
  result.amount = Math.min(want, room); result.capped = want > room;
  result.valid = result.amount >= 1; result.ratio = ratio; result.mode = mode;
  result.reason = result.valid ? '' : (want < 1 ? '供给者生命储备不足' : '接收者储备已满');
  return result;
};
G.canTransfer = function(b, mode, ratio) { return members().some(function(t) { return G.transferPreview(b, t, mode, ratio).valid; }); };

G.springShieldHit=function(b){var g=active(),r=row(b);if(g&&hasSpring(g)&&g.level>=20&&!r.springHitUsed){r.springHitUsed=true;r.springBoost=true;}};
// ---------- 引擎接入 ----------
function alias(obj, name, wrap) { var old = obj[name]; if (typeof old === 'function') obj[name] = wrap(old); }
// 各角色模块在 Game_Actor 上直接重写 param、gainHp 等；同时封装实际入口，避免绕过基类。
function entrances(base, name, wrap) { [Game_Actor.prototype, Game_Enemy.prototype, Game_Battler.prototype].forEach(function(p) { if (p !== base && Object.prototype.hasOwnProperty.call(p, name)) alias(p, name, wrap); }); alias(base, name, wrap); }
var hpCalls = new WeakMap(), damageCalls = new WeakMap();
function absorbShield(b, value) { if (W.CodexShieldLedger) return value; // 账本在最外层吸收
  if (value > 0 && G.activeBattle && !G.unprotected && row(b).shield > 0) { var used = Math.min(row(b).shield, value); row(b).shield -= used; return value - used; } return value; }
// 先改写传给原生结算的伤害，吸血、受伤回调与弹字才能读取实际穿透量。
alias(Game_Action.prototype, 'executeHpDamage', function(old) { return function(target, value) {
  value = absorbShield(target, value); var depth = damageCalls.get(target) || 0; damageCalls.set(target, depth + 1);
  if (G.activeBattle && value > 0 && target.isActor && target.isActor()) G.roundTaken = (G.roundTaken || 0) + value;
  try { return old.call(this, target, value); } finally { if (depth) damageCalls.set(target, depth); else damageCalls.delete(target); }
}; });
entrances(Game_BattlerBase.prototype, 'param', function(old) { return function(n) {
  if (n !== 0) return old.apply(this, arguments); var depth = paramCalls.get(this) || 0; paramCalls.set(this, depth + 1); var v;
  try { v = old.apply(this, arguments); } finally { paramCalls.set(this, depth); }
  return !depth && G.activeBattle && this.isActor && this.isActor() ? v + row(this).e : v;
}; });
entrances(Game_Battler.prototype, 'gainHp', function(old) { return function(value) {
  if (hpCalls.get(this)) return old.apply(this, arguments);
  var b = this; function run() {
    if (G.isRooted(b) && value > 0 && !G.internal) return;
    if (value > 0 && G.healing && isGuyu(G.healing.subject) && G.healing.direct) value = Math.floor(value);
    if (value < 0 && !damageCalls.get(b)) value = -absorbShield(b, -value);
    var wasAlive = b.isAlive() && b.hp > 0, source = G.healing;
    hpCalls.set(b, true); try { old.call(b, value); } finally { hpCalls.delete(b); }
    var g = active();
    if (G.activeBattle && value > 0 && wasAlive && b.isActor() && members().indexOf(b) >= 0 && g && !G.internal) {
      var amount = Math.floor(value); addE(b, amount);
      if (source && source.subject === g && source.direct) G.totals.healed += amount;
      if (source && source.subject === g && source.direct && G.unlocked(g,'growth') && !blooming()) addE(b, Math.floor(amount * CFG.growth.ratio));
    }
  }
  if (G.activeBattle && value < 0 && !current() && !G.internal && !G.unprotected) return isolated(null, run);
  return run();
}; });
alias(Game_BattlerBase.prototype, 'setHp', function(old) { return function(hp) { if (G.isRooted(this) && hp > 0 && !G.internal) return; if (hp < this._hp && !damageCalls.get(this) && !hpCalls.get(this) && !G.internal) hp = this._hp - absorbShield(this, this._hp - hp); return old.call(this, hp); }; });
alias(Game_Action.prototype, 'isValid', function(old) { return function() { if (key(this.item()) === 'transfer' && isGuyu(this.subject()) && !G.transferPreview(this.subject(), members()[this._targetIndex], this._guyuTransferMode, this._guyuRatio).valid) return false; return old.apply(this, arguments); }; });
entrances(Game_Battler.prototype, 'addState', function(old) { return function(n) {
  if (G.activeBattle && n === this.deathStateId() && protect(this)) return;
  var out = old.apply(this, arguments);
  if (G.activeBattle && isGuyu(this) && n === this.deathStateId() && this.isDead() && !G.internal) root(this, false);
  return out;
}; });
entrances(Game_Battler.prototype, 'removeState', function(old) { return function(n) { if (G.isRooted(this) && n === this.deathStateId() && !G.internal) return; return old.apply(this, arguments); }; });
entrances(Game_BattlerBase.prototype, 'revive', function(old) { return function() { if (G.isRooted(this) && !G.internal) return; return old.apply(this, arguments); }; });
alias(Game_BattlerBase.prototype, 'recoverAll', function(old) { return function() { if (G.isRooted(this) && !G.internal) return; return old.apply(this, arguments); }; });
alias(Game_BattlerBase.prototype, 'isAlive', function(old) { return function() { return G.isRooted(this) ? false : old.apply(this, arguments); }; });
alias(Game_BattlerBase.prototype, 'isDead', function(old) { return function() { return G.isRooted(this) ? true : old.apply(this, arguments); }; });
alias(Game_BattlerBase.prototype, 'canMove', function(old) { return function() { return G.isRooted(this) ? false : old.apply(this, arguments); }; });
alias(Game_BattlerBase.prototype, 'paySkillCost', function(old) { return function() { var b = this, args = arguments; return G.withUnprotected(function() { return old.apply(b, args); }); }; });
alias(Game_Interpreter.prototype, 'command311', function(old) { return function() { var b = this, args = arguments; return G.withUnprotected(function() { return old.apply(b, args); }); }; });
// 绽放由队友触发，但属于谷雨的伤害：结算期间以谷雨为攻击者（加成、倍率、移植平衡均按谷雨计算）。
alias(Game_Action.prototype, 'subject', function(old) { return function() { return G.calcOwner || old.apply(this, arguments); }; });
alias(Game_Action.prototype, 'applyPassiveHealRate', function(old) { return function(value) { if (key(this.item()) === 'heal' && isGuyu(this.subject())) return value; return old.apply(this, arguments); }; });
alias(Game_Action.prototype, 'makeDamageValue', function(old) { return function(target, critical) {
  var prev = G.calcOwner; if (this._guyuOwner) G.calcOwner = this._guyuOwner;
  try { return old.call(this, target, key(this.item()) === 'bloom' ? false : critical); } finally { G.calcOwner = prev; }
}; });
alias(Game_Action.prototype, 'evalDamageFormula', function(old) { return function(target) {
  var k = key(this.item());
  if (k === 'heal' && isGuyu(this.subject())) return -G.healFormula(this.subject(), target);
  if (k === 'bloom' || (k === 'finish' && isGuyu(this.subject()))) {
    // 统一伤害在结算中按攻防比例处理防御；只有绕过统一伤害时才在这里扣防。
    var defense = W.CodexDamage && CodexDamage.isCalculating && CodexDamage.isCalculating() ? 0 : target.mdf * .5;
    return Math.max(0, (this._guyuPower || 0) - defense);
  }
  return old.apply(this, arguments);
}; });
['itemHit', 'itemEva', 'itemCri'].forEach(function(name) { alias(Game_Action.prototype, name, function(old) { return function() { if (['bloom', 'finish', 'heal'].indexOf(key(this.item())) >= 0) return name === 'itemHit' ? 1 : 0; return old.apply(this, arguments); }; }); });
alias(Game_Action.prototype, 'apply', function(old) { return function(target) {
  var a = this; function run() {
    var prev = G.healing, e = current(), k = key(a.item());
    G.healing = {subject: a.subject(), direct: a.isHpRecover() || a.item().effects.some(function(x) { return x.code === 11; })};
    try {
      doSpecial(a, target);
      if (isGuyu(a.subject()) && ['open', 'transfer', 'shield', 'finish'].indexOf(k) >= 0 && !a._guyuSpecialDone) { target.clearResult(); return; }
      if (e) e.executed = true;
      var out = old.call(a, target);
      if (['open', 'transfer', 'shield'].indexOf(k) >= 0 && a._guyuSpecialDone) a.makeSuccess(target);
      if (a._guyuInternal || (k === 'finish' && isGuyu(a.subject()))) { var dealt = Math.max(0, target.result().hpDamage || 0); G.totals.damage += dealt; G.totals[a._guyuInternal ? 'bloomDamage' : 'finishDamage'] += dealt; }
      return out;
    } finally { G.healing = prev; }
  }
  var e = current(); if (G.activeBattle && (!e || e.action !== a)) return isolated(a, run);
  return run();
}; });
entrances(Game_BattlerBase.prototype, 'skillMpCost', function(old) { return function(s) {
  var k = key(s), rate = CFG.mp[k];
  // 【Claude·未经Codex检验】v0.15 按最大MP比例收费后也吃装备、被动的通用技能减耗（原来直接返回，减耗词条对谷雨无效）。
  if (isGuyu(this) && rate !== undefined) { var g = Math.ceil(this.mmp * rate * this.mcr); return window.CodexSkillCost ? CodexSkillCost.applyConsumeReduce(this, s, g) : g; }
  return old.apply(this, arguments);
}; });
entrances(Game_BattlerBase.prototype, 'meetsSkillConditions', function(old) { return function(s) {
  var k = key(s), required = CFG.unlock[k], active5 = ['heal', 'open', 'transfer', 'shield', 'finish'].indexOf(k) >= 0;
  if (active5 && !isGuyu(this)) return false;
  if (isGuyu(this) && active5) {
    if (!G.unlocked(this,k) || G.isRooted(this)) return false;
    if (k === 'open' && (G.flowerUntil >= G.round || G.round < G.openAt)) return false;
    if (k === 'finish' && (!blooming() || row(this).e < 1)) return false;
    if (k === 'shield' && G.shieldValue(this) < 1) return false;
    if (k === 'transfer' && !G.transferRatios(this).some(function(r) { return G.canTransfer(this, 'give', r) || G.canTransfer(this, 'back', r); }, this)) return false;
  }
  return old.apply(this, arguments);
}; });
alias(Game_Actor.prototype, 'skills', function(old) { return function() {
  var list = old.apply(this, arguments); if (!isGuyu(this)) return list;
  var a = this; return list.filter(function(s) { var k = key(s); if (k === 'relic') return hasSpring(a); if (k === 'bloom') return false; var r = CFG.unlock[k]; return r === undefined || G.unlocked(a,k); });
}; });
alias(BattleManager, 'setup', function(old) { return function() { G.reset(); G.activeBattle = true; G.totals = freshTotals(); return old.apply(this, arguments); }; });
alias(BattleManager, 'startTurn', function(old) { return function() { G.round = $gameTroop.turnCount() + 1; var out = old.apply(this, arguments); G.round = $gameTroop.turnCount(); return out; }; });
alias(BattleManager, 'startAction', function(old) { return function() {
  var a = this._subject && this._subject.currentAction(); if (a) { delete a._guyuSpecialDone; delete a._guyuShieldValue; if (!a._guyuInternal) delete a._guyuPower; }
  var e = a ? G.begin(a, true) : null;
  try { return old.apply(this, arguments); } catch (err) { if (e) G.end(e); throw err; }
}; });
alias(BattleManager, 'endAction', function(old) { return function() { var e = current(); if (e) G.end(e, true); var out = old.apply(this, arguments); if (e) G.afterAction(e); return out; }; });
alias(BattleManager, 'endTurn', function(old) { return function() {
  var waiting = this.isTurnBased && this.isTurnBased() && this._spriteset && this._spriteset.isPopupPlaying && this._spriteset.isPopupPlaying();
  var out = old.apply(this, arguments); if (!waiting) G.endRound(); return out;
}; });
alias(BattleManager, 'endBattle', function(old) { return function(result) { G.finishBattle(result); if (result === 0) G.rollStone(); return old.apply(this, arguments); }; });
alias(BattleManager, 'otbInsertRevivalActionOrders', function(old) { return function(b) {
  if (G.regenerating === b) { if (!G.ending && W.Olivia && Olivia.OctoBattle.OTB.RemoveRestrictNext) this.otbInsertActionOrders(b, this._nextTurnActionBattlers); return; }
  return old.apply(this, arguments);
}; });

// ---------- 阶位与技能 ----------
G.actorId = function() { return ids().actor; };
G.syncSkills = function(a) {
  if (!isGuyu(a) || a._guyuSyncing) return; a._guyuSyncing = true;
  try {
    var map = ids().skill, before = JSON.stringify(a._skills || []);
    Object.keys(CFG.unlock).forEach(function(k) { var id = map[k]; if (!id || k === 'bloom') return; var need = CFG.unlock[k];
      if (G.unlocked(a,k)) { if ((a._skills || []).indexOf(id) < 0) a.learnSkill(id); } else if ((a._skills || []).indexOf(id) >= 0) a.forgetSkill(id); });
    if (before !== JSON.stringify(a._skills || [])) { a.need_refresh = true; if (a.refreshPassiveSkillCache) a.refreshPassiveSkillCache(); if (a.initPassiveCache && a.refreshPassiveCache) { a.initPassiveCache(); a.refreshPassiveCache(); } }
  } finally { delete a._guyuSyncing; }
};
function syncAll() { var id = ids().actor, a = id && $gameActors && $gameActors._data[id]; if (a) G.syncSkills(a); }
alias(DataManager, 'extractSaveContents', function(old) { return function() {
  var out = old.apply(this, arguments); G.reset(); idCache = null; syncAll();
  if (W.$gameParty && $gameParty.allMembers) $gameParty.allMembers().forEach(function(b) { b._hp = Math.min(b._hp, b.mhp); rawRefresh(b); });
  return out;
}; });
['setup', 'levelUp', 'changeLevel'].forEach(function(n) { alias(Game_Actor.prototype, n, function(old) { return function() { var r = old.apply(this, arguments); if (isGuyu(this)) G.syncSkills(this); return r; }; }); });
if (typeof Scene_ActorAdvanced !== 'undefined') alias(Scene_ActorAdvanced.prototype, 'onConfirmOk', function(old) { return function() { var r = old.apply(this, arguments); syncAll(); return r; }; });
alias(BattleManager, 'startBattle', function(old) { return function() { syncAll(); return old.apply(this, arguments); }; });
G.setStage = function(n) { if (G.activeBattle) throw new Error('阶位测试只可在战斗外切换'); var a = $gameActors.actor(G.actorId()); a._AdvancedNum = Math.max(0, Math.min(5, Math.floor(Number(n) || 0))); G.syncSkills(a); a.refresh(); return a; };
G.grant = function(n, level) { var id = G.actorId(); if (!id) throw new Error('尚未安装谷雨数据库记录'); var a = G.setStage(n); if (level) a.changeLevel(Number(level), false); if ($gameParty._actors.indexOf(id) < 0) $gameParty.addActor(id); return a; };

// ---------- 获取：伙伴号角、专属法宝、进阶石 ----------
function notify(text) { try { if (W.$ && $.toaster) $.toaster({message: text}); } catch (e) {} }
G.recruit = function() {
  var I = ids(), id = I.actor; if (!id) throw new Error('尚未安装谷雨数据库记录');
  if ($gameParty._actors.indexOf(id) >= 0) return false;
  var a = $gameActors.actor(id), base = I.relic && $dataArmors[I.relic];
  if (!$gameSystem._guyuRelicGranted && base) {
    var slot = a.equipSlots().indexOf(13); if (slot < 0 || !a.canEquip(base)) throw new Error('百谷生装备槽不可用');
    var worn = a.equips()[slot], created = null;
    try {
      var item = $gameParty.getMatchingBaseItem ? $gameParty.getMatchingBaseItem(base, false) : null;
      if (!item) created = item = $gameParty.gainIndependentItem ? $gameParty.gainIndependentItem(base, 1)[0] : ($gameParty.gainItem(base, 1), base);
      if (!item) throw new Error('百谷生生成失败');
      a.changeEquip(slot, item); if (a.equips()[slot] !== item) throw new Error('百谷生装备失败');
      $gameSystem._guyuRelicGranted = true;
    } catch (e) { if (a.equips()[slot] !== worn) a.changeEquip(slot, worn); if (created && created !== base) $gameParty.loseItem(created, 1, false); throw e; }
  }
  $gameParty.addActor(id); G.syncSkills(a);
  notify($gameSystem._guyuRelicGranted && !G._notifiedRelic ? '谷雨加入队伍，已装备百谷生。' : '谷雨加入队伍。'); G._notifiedRelic = true;
  return true;
};
G.rollStone = function() {
  var I = ids(), a = I.actor && $gameActors._data[I.actor]; if (!a || !I.stone || $gameParty._actors.indexOf(I.actor) < 0) return false;
  var need = 5 - stage(a); if (need <= 0 || $gameParty.numItems($dataItems[I.stone]) >= need || Math.randomInt(CFG.stone.dropOneIn) !== 0) return false;
  $gameParty.gainItem($dataItems[I.stone], 1); notify('获得了 ' + $dataItems[I.stone].name + '！'); return true;
};
if (typeof Scene_Shop !== 'undefined') alias(Scene_Shop.prototype, 'prepare', function(old) { return function(goods, purchaseOnly) {
  goods = goods || []; var I = ids();
  // 与云裳相同：在出售伙伴号角的商店追加谷雨号角。
  if (I.horn && $gameMap && $gameMap.mapId() === CFG.shop.mapId && goods.some(function(g) { return g[0] === 0 && $dataItems[g[1]] && /^伙伴号角：/.test($dataItems[g[1]].name); })) {
    if (!goods.some(function(g) { return g[0] === 0 && g[1] === I.horn; })) goods.push([0, I.horn, 0, 0]);
  }
  return old.call(this, goods, purchaseOnly);
}; });

// ---------- 图标：技能沿用品质图标框架，法宝使用独立图集 ----------
if (W.CodexQualityIcons && CodexQualityIcons.lookup) {
  var lookup = CodexQualityIcons.lookup;
  CodexQualityIcons.lookup = function(index, w) {
    var s = index - 120000, item = W.$dataSkills && $dataSkills[s];
    if (item && ids().skillKey[s] && item.meta.CodexQualityIcon) return {item: item, source: Number(item.meta.CodexQualityIcon), skill: true};
    return lookup.apply(this, arguments);
  };
}
function ownIcon(index) { return index >= CFG.icons.atlasStart && index < CFG.icons.atlasStart + 16; }
function drawOwn(w, index, x, y, size) { var bitmap = ImageManager.loadSystem(CFG.icons.atlas), contents = w.contents; function draw() { if (w.contents === contents) contents.blt(bitmap, (index - CFG.icons.atlasStart) * 32, 0, 32, 32, x, y, size, size); } if (bitmap.isReady && !bitmap.isReady()) { bitmap.addLoadListener(draw); return; } draw(); }
alias(Window_Base.prototype, 'drawIcon', function(old) { return function(index, x, y) { if (!ownIcon(index)) return old.apply(this, arguments); drawOwn(this, index, x, y, 32); }; });
if (Window_Base.prototype.DXDrawLargeIcon) alias(Window_Base.prototype, 'DXDrawLargeIcon', function(old) { return function() { var i = this._item || arguments[0]; if (i && ownIcon(i.iconIndex)) { var s = Number(W.Yanfly && Yanfly.Param.ItemIconSize) || 64; drawOwn(this, i.iconIndex, (144 - s) / 2, (144 - s) / 2, s); return; } return old.apply(this, arguments); }; });
if (typeof Window_ItemStatus !== 'undefined') alias(Window_ItemStatus.prototype, 'drawLargeIcon', function(old) { return function() { if (this._item && ownIcon(this._item.iconIndex)) { this.contents.blt(ImageManager.loadSystem(CFG.icons.atlas), (this._item.iconIndex - CFG.icons.atlasStart) * 32, 0, 32, 32, 0, 0, 128, 128); return; } return old.apply(this, arguments); }; });

// ---------- 自动战斗：谷雨的固定判断，避免通用 AI 看不懂储备与花期 ----------
G.autoAction = function(a) {
  if (!isGuyu(a) || !G.activeBattle || !a.canMove()) return null;
  var map = ids().skill, team = members().filter(function(b) { return b.isAlive(); }), foes = $gameTroop.aliveMembers();
  if (!foes.length) return null;
  function can(k) { var s = $dataSkills[map[k]]; return s && a.canUse(s); }
  function make(k, target) { var act = new Game_Action(a); act.setSkill(map[k]); if (target !== undefined) act.setTarget(target); return act; }
  var lowest = team.reduce(function(m, b) { return !m || b.hp / b.mhp < m.hp / m.mhp ? b : m; }, null);
  var hurt = team.filter(function(b) { return b.hp / b.mhp < CFG.ai.shieldBelow && G.shield(b) <= 0; }).length;
  var reserveRatio = row(a).e / Math.max(1, referenceCap(a));
  if (lowest && lowest.hp / lowest.mhp < CFG.ai.healBelow && can('heal')) return make('heal');
  if ((hurt >= CFG.ai.shieldWhenHurt || (G.lastRoundPressure || 0) >= CFG.ai.shieldPressure) && can('shield') && !team.some(function(b) { return G.shield(b) > 0; })) return make('shield');
  if (blooming() && can('finish') && (reserveRatio >= CFG.ai.finishAtReserve || G.flowerUntil === G.round)) return make('finish');
  if (!blooming() && can('open') && team.some(function(b) { return row(b).e >= referenceCap(b) * CFG.ai.openAtReserve; })) {
    var boss = foes.reduce(function(m, b) { return !m || b.hp > m.hp ? b : m; }, null); return make('open', boss.index());
  }
  if (can('heal')) return make('heal');
  return null;
};
alias(Game_Actor.prototype, 'makeAutoBattleActions', function(old) { return function() {
  var out = old.apply(this, arguments);
  if (isGuyu(this) && G.activeBattle && this.numActions() > 0) {
    var act = G.autoAction(this); if (act) { this._actions = this._actions.length ? this._actions : [act]; this._actions[0] = act; }
  }
  return out;
}; });

// ---------- 状态显示 ----------
G.inspect = function() { return {round: G.round, flowerUntil: G.flowerUntil, openAt: G.openAt, totals: G.totals, party: members().map(function(b) { var r = row(b); return {name: b.name(), stage: isGuyu(b) ? stage(b) : undefined, hp: b.hp, maxHp: b.mhp, baseMaxHp: baseMhp(b), reserve: r.e, cap: isGuyu(b)?null:cap(b), unlimitedReserve:isGuyu(b), shield: r.shield, totalShield: G.totalShield(b), bud: G.hasBud(b), rootUntil: r.rootUntil}; })}; };
function shortNumber(n) { return n >= 100000000 ? (n / 100000000).toFixed(1) + '亿' : n >= 10000 ? (n / 10000).toFixed(1) + '万' : String(Math.floor(n)); }
G.shortNumber = shortNumber;
G.statusText = function(b) {
  if (!G.activeBattle || !guyu() || !b) return '';
  var r = row(b), text = '储' + shortNumber(r.e);
  if (G.isRooted(b)) text += ' 替倒' + Math.max(0, r.rootUntil - G.round);
  else if (G.hasBud(b)) text += ' 待发';
  else if (isGuyu(b)) text += blooming() ? ' 花期' + (G.flowerUntil - G.round + 1) : ' 平时';
  return text;
};
G.transferText = function(b, target, mode, ratio) {
  var p = G.transferPreview(b, target, mode, ratio); if (!p.valid) return p.reason;
  return (p.mode === 'back' ? '收回储备' : '交出储备') + ' ' + Math.round(p.ratio * 100) + '%：' + p.from.name() + ' → ' + p.to.name() + '，储备 ' + shortNumber(p.amount) + (p.capped ? '（受接收上限限制）' : '') + '。\n转移不回复HP' + (hasSpring(b) && p.mode === 'give' ? '；目标下次追加伤害消耗' + (b.level >= 60 ? '50%' : '35%') + '储备。' : '。');
};
if (W.Window_BattleSideHP && W.Window_BattleSideBase) {
  alias(Window_BattleSideHP.prototype, 'refresh', function(old) { return function() {
    var out = old.apply(this, arguments); if (!this._actor || G.shield(this._actor) <= 0) return out;
    Window_BattleSideBase.prototype.refresh.call(this); var b = this._actor, total = G.totalShield(b), gw = Olivia.OctoBattle.SideBattleUI.GaugeWidth || 160;
    this.drawActorHp(b, this.textPadding(), 0, gw); this._hp = b.hp; this._mhp = b.mhp; this._shield = total;
    var max = Math.max(b.mhp, b.hp + total, 1), x = this.textPadding(), start = Math.floor(x + gw * b.hp / max), end = Math.floor(x + gw * Math.min((b.hp + total) / max, 1)), gh = this.gaugeHeight();
    if (end > start) this.contents.fillRect(start, this.lineHeight() - gh, end - start, gh, 'rgba(0, 136, 255, 0.7)');
    var font = this.contents.fontSize, text = '盾' + shortNumber(total), label = x + this.textWidth('HP') + 6;
    this.contents.fontSize = 12; this.changeTextColor('#88ccff'); this.drawText(text, label, 0, Math.max(0, this.contentsWidth() - label), 'left'); this.contents.fontSize = font; this.resetTextColor(); return out;
  }; });
  alias(Window_BattleSideHP.prototype, 'checkRefreshConditions', function(old) { return function() { if (this._actor && this._shield !== G.totalShield(this._actor)) return true; return this._actor ? this._hp !== this._actor.hp || this._mhp !== this._actor.mhp : old.apply(this, arguments); }; });
}
if (W.Window_BattleSideName) {
  alias(Window_BattleSideName.prototype, 'refresh', function(old) { return function() {
    var out = old.apply(this, arguments), text = G.statusText(this._actor); this._guyuInfo = text;
    if (text) { var font = this.contents.fontSize, width = this.contentsWidth(), split = Math.floor(width * .38); this.contents.clear(); this.drawActorName(this._actor, this.textPadding(), 0, split);
      this.contents.fontSize = Math.max(10, Math.floor(font * .68)); this.changeTextColor('#b7ead0'); this.drawText(text, split, 0, width - split, 'right'); this.contents.fontSize = font; this.resetTextColor(); }
    return out;
  }; });
  alias(Window_BattleSideName.prototype, 'checkRefreshConditions', function(old) { return function() { return this._guyuInfo !== G.statusText(this._actor) || old.apply(this, arguments); }; });
}
alias(Game_Actor.prototype, 'canEquip', function(old) { return function(item) { if (tag(item, 'GuyuRelic') && !isGuyu(this)) return false; return old.apply(this, arguments); }; });
alias(Game_Interpreter.prototype, 'pluginCommand', function(old) { return function(command, args) { old.apply(this, arguments); if (String(command).toLowerCase() !== 'guyu') return; if (args[0] === 'grant') G.grant(args[1], args[2]); if (args[0] === 'stage') G.setStage(args[1]); if (args[0] === 'recruit') G.recruit(); }; });

// ---------- 赠春／还春选择窗：同一技能入口、一次行动 ----------
if (W.Scene_Battle && W.Window_Command) {
  var Window_GuyuTransfer = function() { this.initialize.apply(this, arguments); };
  Window_GuyuTransfer.prototype = Object.create(Window_Command.prototype); Window_GuyuTransfer.prototype.constructor = Window_GuyuTransfer;
  Window_GuyuTransfer.prototype.windowWidth = function() { return 320; };
  Window_GuyuTransfer.prototype.makeCommandList = function() { var actor = BattleManager.actor(), ratios = G.transferRatios(actor); for (var i = 0; i < ratios.length; i++) { var pct = Math.round(ratios[i] * 100); this.addCommand('交出储备（' + pct + '%）', 'choose', G.canTransfer(actor, 'give', ratios[i]), {mode: 'give', ratio: ratios[i]}); this.addCommand('收回储备（' + pct + '%）', 'choose', G.canTransfer(actor, 'back', ratios[i]), {mode: 'back', ratio: ratios[i]}); } };
  W.Window_GuyuTransfer = Window_GuyuTransfer;
  function closeTransfer(scene) {
    var win=scene._guyuTransferWindow;
    if(win){win.hide();win.deactivate();}
    scene._guyuTransferConfirmed=false;scene._guyuTransferContext=null;
  }
  function returnToSkills(scene) {
    closeTransfer(scene);scene._actorCommandWindow.deactivate();
    scene._skillWindow.show();scene._skillWindow.activate();scene._skillWindow.updateHelp();
  }
  // The native scene must pause battle input while the ratio chooser owns it.
  alias(Scene_Battle.prototype, 'isAnyInputWindowActive', function(old) { return function() {
    var win=this._guyuTransferWindow;
    return !!(win&&win.visible&&win.active)||old.apply(this,arguments);
  }; });
  alias(Scene_Battle.prototype, 'endCommandSelection', function(old) { return function() {
    closeTransfer(this);return old.apply(this,arguments);
  }; });
  alias(Scene_Battle.prototype, 'stop', function(old) { return function() {
    closeTransfer(this);return old.apply(this,arguments);
  }; });

  alias(Scene_Battle.prototype, 'createAllWindows', function(old) { return function() {
    old.apply(this, arguments); var win = this._guyuTransferWindow = new Window_GuyuTransfer(0, 0); win.x = (Graphics.boxWidth - win.width) / 2; win.y = (Graphics.boxHeight - win.height) / 2; this.addWindow(win); win.hide(); win.deactivate();
    var scene = this; win.setHandler('cancel', function() { returnToSkills(scene); });
    win.setHandler('choose', function() {
      var ext=win.currentExt(),action=BattleManager.inputtingAction(),context=scene._guyuTransferContext;
      if(!context||!action||context.action!==action||context.actor!==BattleManager.actor()){
        closeTransfer(scene);scene.changeInputWindow();return;
      }
      if(!ext||!G.canTransfer(context.actor,ext.mode,ext.ratio)){win.refresh();win.activate();return;}
      action._guyuTransferMode=ext.mode;action._guyuRatio=ext.ratio;
      closeTransfer(scene);scene._guyuTransferConfirmed=true;scene.onSkillOk();
    });
  }; });
  alias(Scene_Battle.prototype, 'onSkillOk', function(old) { return function() {
    if (key(this._skillWindow.item()) === 'transfer' && !this._guyuTransferConfirmed) { this._skillWindow.deactivate(); this._actorCommandWindow.deactivate(); this._helpWindow.hide(); this._guyuTransferContext={actor:BattleManager.actor(),action:BattleManager.inputtingAction()}; var win = this._guyuTransferWindow; win.refresh(); win.show(); win.activate(); var index = G.transferRatios(BattleManager.actor()).indexOf(CFG.transfer.ratio) * 2; if (index < 0 || !win.isCommandEnabled(index)) index = win._list.findIndex(function(x) { return x.enabled; }); win.select(Math.max(0, index)); return; }
    this._guyuTransferConfirmed = false; var out = old.apply(this, arguments); if (key(this._skillWindow.item()) === 'transfer') this.guyuUpdateTransferHelp(); return out;
  }; });
  Scene_Battle.prototype.guyuUpdateTransferHelp = function() { var a = BattleManager.inputtingAction(); if (a && key(a.item()) === 'transfer' && this._actorWindow && this._actorWindow.active) { var target = members()[this._actorWindow.index()]; this._helpWindow.setText(G.transferText(a.subject(), target, a._guyuTransferMode, a._guyuRatio)); this._helpWindow.show(); } };
  alias(Scene_Battle.prototype, 'onActorOk', function(old) { return function() { var a = BattleManager.inputtingAction(); if (a && key(a.item()) === 'transfer' && !G.transferPreview(a.subject(), members()[this._actorWindow.index()], a._guyuTransferMode, a._guyuRatio).valid) { SoundManager.playBuzzer(); this._actorWindow.activate(); this.guyuUpdateTransferHelp(); return; } return old.apply(this, arguments); }; });
  alias(Scene_Battle.prototype, 'onActorCancel', function(old) { return function() { var action=BattleManager.inputtingAction(),transfer=action&&key(action.item())==='transfer'; var out = old.apply(this, arguments); this._guyuTransferConfirmed = false; if(transfer)returnToSkills(this); return out; }; });
  if (W.Window_BattleActor) alias(Window_BattleActor.prototype, 'select', function(old) { return function() { var out = old.apply(this, arguments), scene = SceneManager._scene; if (scene && scene.guyuUpdateTransferHelp) scene.guyuUpdateTransferHelp(); return out; }; });
}
// 谷雨独立动作与归根/再生反馈。特效只属于精灵，不写入角色或存档，不消耗战斗随机数。
var visualQueue = new WeakMap();
function queueVisual(b, kind) {
  if (!G.activeBattle || !b) return;
  var list = visualQueue.get(b) || []; list.push(kind);
  visualQueue.set(b, list.slice(-2));
}
G.visuals = {asset: 'Codex_Guyu', motions: {heal: 'spell', open: 'chant', transfer: 'item', shield: 'guard', finish: 'skill'}};
alias(Game_Actor.prototype, 'performAction', function(old) { return function(action) {
  var out = old.apply(this, arguments), name = isGuyu(this) && action && G.visuals.motions[key(action.item())];
  if (name && !action._guyuInternal && !G.isRooted(this)) this.requestMotion(name);
  return out;
}; });
alias(Game_Actor.prototype, 'performActionEnd', function(old) { return function() {
  var out = old.apply(this, arguments);
  if (isGuyu(this)) {
    // Guard/chant are looped MV motions. Explicitly leave the casting pose before refreshing states.
    this.requestMotionRefresh();
    this.requestMotion(this.isDead() ? 'dead' : this.stateMotionIndex() === 2 ? 'sleep' : this.stateMotionIndex() === 1 ? 'abnormal' : this.isDying() ? 'dying' : 'wait');
  }
  return out;
}; });
var resetVisuals = G.reset;
G.reset = function() { G.springReturnDone=false; visualQueue = new WeakMap(); return resetVisuals.apply(this, arguments); };

function drawPetal(g, x, y, radius, color, alpha) {
  g.beginFill(color, alpha);
  g.drawEllipse(x, y, radius * 1.6, radius * .65); g.endFill();
}
function drawFlower(g, x, y, size, alpha) {
  for (var i = 0; i < 5; i++) {
    var angle = i * Math.PI * 2 / 5;
    g.beginFill(0xf9f2cf, alpha); g.drawCircle(x + Math.cos(angle) * size, y + Math.sin(angle) * size, size * .7); g.endFill();
  }
  g.beginFill(0xf1c862, alpha); g.drawCircle(x, y, size * .58); g.endFill();
}
function clearVisual(sprite) {
  if (sprite._guyuFX) { sprite._guyuFX.clear(); sprite._guyuFX.visible = false; }
  sprite._guyuFXKind = ''; sprite._guyuFXTime = 0;
}
function updateVisual(sprite) {
  var b = sprite._actor, body = sprite._mainSprite;
  if (!b || !isGuyu(b) || !G.activeBattle || !$gameParty.inBattle() || !body || !body.bitmap || !body.bitmap.isReady()) { clearVisual(sprite); return; }
  var queued = visualQueue.get(b);
  if (queued && queued.length) {
    sprite._guyuFXKind = queued.shift(); sprite._guyuFXTime = 0;
  }
  var kind = sprite._guyuFXKind;
  if (!kind) return;
  if (!sprite._guyuFX) { sprite._guyuFX = new PIXI.Graphics(); sprite.addChild(sprite._guyuFX); }
  var g = sprite._guyuFX, t = ++sprite._guyuFXTime, duration = kind === 'root' ? 48 : 64;
  g.clear(); g.visible = true;
  if (t > duration) { clearVisual(sprite); return; }
  var p = sprite._codexSVProfile, frame = body._frame;
  var feet = body.y + ((p ? p.bounds[3] : frame.height) - frame.height * body.anchor.y) * body.scale.y;
  var center = body.x + ((p ? (p.bounds[0] + p.bounds[2]) / 2 : frame.width / 2) - frame.width * body.anchor.x) * body.scale.x;
  g.position.set(center, feet);
  var life = t / duration, alpha = Math.sin(Math.PI * life);
  if (kind === 'root') {
    // Small gold-edged porcelain chips fall at the visible feet; withering leaves fade with them.
    g.lineStyle(1, 0xe1b858, alpha * .8);
    for (var i = 0; i < 8; i++) {
      var sign = i % 2 ? 1 : -1, x = sign * (7 + i * 2.4 + life * 13), y = -22 + life * 26 + Math.sin(i * 2.1) * 7;
      g.beginFill(0xe7dcc1, alpha * .85); g.drawPolygon([x-2,y-2,x+3,y-1,x+1,y+3,x-3,y+1]); g.endFill();
    }
    g.lineStyle(0);
    for (var j = 0; j < 5; j++) drawPetal(g, Math.cos(j * 2.1) * (8 + life * 20), -34 + life * 36 + j * 3, 2.4, 0x899a56, alpha * .7);
  } else {
    // A green stem rises from the grounded sprite, then opens into five small flowers.
    g.lineStyle(2, 0x83b975, alpha * .8); g.moveTo(0, 0); g.lineTo(0, -8 - Math.min(1, life * 2) * 22);
    g.lineStyle(1, 0xe6c973, alpha * .75); g.drawEllipse(0, -1, 12 + life * 18, 4 + life * 3);
    g.lineStyle(0);
    for (var k = 0; k < 5; k++) {
      var phase = k * Math.PI * 2 / 5 + life * .5;
      var x = Math.cos(phase) * (10 + life * 12), y = -18 - life * 23 + Math.sin(phase) * 8;
      drawPetal(g, x * .8, y + 8, 2.2, 0x9acb7e, alpha * .8);
      if (life > .22) drawFlower(g, x, y, 1.7 + Math.min(.8, life), alpha * .95);
    }
  }
}
var visualInstalled = false;
function installVisualHooks() {
  if (visualInstalled) return; visualInstalled = true;
  function ownVisual(sprite) {
    var actor = sprite._actor;
    return isGuyu(actor) && actor.battlerName() === 'Guyu' &&
      !(W.CodexCostumes && CodexCostumes.active(actor));
  }
  // OTB uses walk while awaiting input. These frames contain actual steps;
  // settle only when movement is over and hold the planted waiting frame.
  function planted(sprite) {
    if (!ownVisual(sprite) || sprite.isMoving()) return false;
    if (sprite._motion === Sprite_Actor.MOTIONS.walk) sprite.startMotion('wait');
    if (sprite._motion !== Sprite_Actor.MOTIONS.wait) return false;
    sprite._pattern = 0; sprite._motionCount = 0; return true;
  }
  alias(Sprite_Actor.prototype, 'startMotion', function(old) { return function(type) {
    if (ownVisual(this) && type === 'walk' && !this.isMoving()) type = 'wait';
    return old.call(this, type);
  }; });
  alias(Sprite_Actor.prototype, 'updateFrame', function(old) { return function() {
    planted(this); return old.apply(this, arguments);
  }; });
  alias(Sprite_Actor.prototype, 'updateMotionCount', function(old) { return function() {
    if (planted(this)) return;
    return old.apply(this, arguments);
  }; });
  if (W.CodexSV && CodexSV.profiles) CodexSV.profiles.Codex_Guyu = {"kind":"multi","width":160,"height":160,"bounds":[23,45,137,145],"targetHeight":72,"maxWidth":129};
  alias(Sprite_Actor.prototype, 'update', function(old) { return function() { var out = old.apply(this, arguments); updateVisual(this); return out; }; });
  alias(Sprite_Actor.prototype, 'setBattler', function(old) { return function(actor) { if (actor !== this._actor) clearVisual(this); return old.apply(this, arguments); }; });
}
// The shared normalization and state-indicator hooks finish installation at Scene_Boot.start.
alias(SceneManager, 'run', function(old) { return function() {
  alias(Scene_Boot.prototype, 'start', function(start) { return function() { var out = start.apply(this, arguments); installVisualHooks(); return out; }; });
  return old.apply(this, arguments);
}; });

})(window, CFG);

});
