// 【Claude·未经Codex检验】v0.15 传家宝改为品质后的标签：品质：不朽（传家宝）。
// 三角色60级法宝进化；基于当前生产增量维护。
window.CodexRuntime.register("installThreeGrowthRelicRuntime",function(){
'use strict';
var W=window,B=W.CodexBinding,T=W.CodexTusu,X=W.CodexXuan,G=W.Guyu,L=W.CodexShieldLedger;
var R=W.CodexThreeGrowth={version:'0.4.0'};
function alias(o,k,f){var old=o[k];o[k]=function(){return f.call(this,old,Array.prototype.slice.call(arguments));};}
function bid(x){return Number(x&&(x.originalBaseItemId||x.baseItemId||x.id));}

// 【Codex·未经Claude检验】新角色专属法宝固定为传家宝；名称与帮助使用同一品质调色表。
// Only presentation metadata changes: levels, traits, growth, sockets and ownership remain intact.
var RQ=W.CodexRelicQuality={version:'1.0.0',quality:9,ids:[4001,4047,4048,4577,4578,4579,4580,4581,7904,7905,7906,7908,7909,7910,7911,7912,7935,7999]},relicIds={};
RQ.ids.forEach(function(id){relicIds[id]=true;});
RQ.isRelic=function(item){return !!(item&&item.etypeId===13&&item.atypeId!==undefined&&relicIds[bid(item)]);};
RQ.normalize=function(item){
 if(!RQ.isRelic(item))return false;
 var note=String(item.note||''),qt=note.match(/<quality:\s*\d+>/gi)||[],ct=note.match(/<ici:\s*\d+>/gi)||[];
 var meta=item.meta||(item.meta={}),changed=qt.length!==1||ct.length!==1||!/^<quality:\s*9>$/i.test(qt[0]||'')||!/^<ici:\s*9>$/i.test(ct[0]||'')||Number(meta.quality)!==9||Number(meta.ici)!==9||item.quality!==9||item.ici!==9;
 if(!changed)return false;
 if(qt.length!==1||ct.length!==1||!/^<quality:\s*9>$/i.test(qt[0]||'')||!/^<ici:\s*9>$/i.test(ct[0]||''))item.note=note.replace(/<(?:quality|ici):\s*\d+>/gi,'').replace(/\n{3,}/g,'\n\n').replace(/\s+$/,'')+'\n<quality:9>\n<ici:9>\n';
 meta.quality=9;meta.ici=9;item.quality=9;item.ici=9;
 if(Array.isArray(item.descParams))item.descParams.forEach(function(row){if(/^品质[：:]/.test(String(row[0]||''))){row[0]='品质：'+(W.CodexQuality?W.CodexQuality.label(item):'传家宝');row[2]=RJO.IQ.QualitiesColor[9];}});
 return true;
};
RQ.sync=function(){
 var seen=new Set();
 function visit(item){if(!item||seen.has(item))return;seen.add(item);RQ.normalize(item);}
 (W.$dataArmors||[]).forEach(visit);(DataManager._independentArmors||[]).forEach(visit);
 if(W.$gameActors)($gameActors._data||[]).forEach(function(a){if(a&&a.equips)a.equips().forEach(visit);});
};
if(W.RJO&&RJO.HE&&RJO.HE.getDescParams){
 var qualityHelp=RJO.HE.getDescParams;
 RJO.HE.getDescParams=function(item){RQ.normalize(item);var out=qualityHelp.apply(this,arguments);RQ.normalize(item);return out;};
}
[Window_Base,Window_ItemList,Window_BattleSkill].forEach(function(Type){
 var drawName=Type.prototype.drawItemName;
 Type.prototype.drawItemName=function(item){
  if(!RQ.isRelic(item))return drawName.apply(this,arguments);
  RQ.normalize(item);
  var old=this.itemColor,own=Object.prototype.hasOwnProperty.call(this,'itemColor'),color=RJO.IQ.QualitiesColor[RQ.quality];
  this.itemColor=function(){return color;};
  try{return drawName.apply(this,arguments);}finally{if(own)this.itemColor=old;else delete this.itemColor;}
 };
});

function owner(id){return W.$gameActors&&$gameActors._data[id];}
function lvl(a){return Math.min(60,Number(a&&a.level)||1);}
function round(){return B.round();}
function tkey(action){return action&&action.item()&&T.ids().key[action.item().id];}
function xkey(action){return action&&action.item()&&X.ids().key[action.item().id];}
function all(){return ($gameParty?$gameParty.allMembers():[]).concat($gameTroop?$gameTroop.members():[]);}
function direct(action){var s=action&&action.subject(),item=action&&action.item();return !!(s&&s.isEnemy&&s.isEnemy()&&item&&[1,5].indexOf(item.damage.type)>=0&&action.isForOpponent());}
var specs={
 4047:{actor:176,base:'止戈环',name:'太初五兵环',extra:[2,3,4,5],rates:[[2,1.2],[4,1.2],[3,1.2],[5,1.2]],old:[[0,1.2],[2,1.2],[3,1.2],[5,1.2]],lines:["10级·剑纹：剑气纵横伤害＋10%", "20级·弓纹：横扫、点射、贯日伤害＋10%", "30级·盾书纹：金汤护盾、敕令伤害＋10%", "40级·锤纹：震击、镇魂重击伤害＋10%", "60级·剑：横扫×1.2；剑气留一次剑击增伤10%", "60级·弓／书：点射2段、贯日3段、敕令2段", "多段总伤害×1.2；同次施法只支付一次费用", "60级·盾：金汤×1.2；护阵首次敌方伤害补双防×18", "60级·锤：锤击×1.2；伤害降低的目标下次直接伤害－10%"]},
 4048:{actor:177,base:'璇玑星盘',name:'周天命星仪',extra:[0,3,4,5],rates:[[4,1.2],[3,1.3],[5,1.3]],old:[[0,1.2],[4,1.2],[3,1.2],[5,1.2]],lines:["10级·免控：璃壁被敌方击破，留一次硬控制免疫", "免控每回合一次，至下回合结束失效", "20级·护盾转移：换队友附身后转移20%剩余璇盾至第三名队友", "护盾转移不新增护盾；60级转移比例提高至30%", "60级·列星：首次回光额外净化一个可净化负面状态", "首次璃壁赋星幕：下一次敌方直接伤害－10%", "自动支援仍须50级第三阶，并在星谱选择自动"]},
 7912:{actor:175,base:'百谷生',name:'万象长春盏',extra:[0,3,5,6],rates:[[0,1.3],[3,1.2],[5,1.2]],old:[[0,1.35],[1,1.1],[4,1.2],[5,1.2]],lines:["10级·交出储备：可选25%／50%／75%，目标下次追加伤害消耗35%储备", "20级·护盾转化：吸收敌方伤害后，下次追加伤害×1.1", "60级·受赠消耗提高至50%，护盾转化提高至×1.2", "60级·本场首次再生：为谷雨及一名队友储春", "春归储备：谷雨基础生命×18%，各自不超过上限"]}
};
R.specs=specs;
// 屠苏、璇的法宝说明：对齐原生专属法宝（专属／等级需求／特效／法宝每级），按所属人物当前等级显示已解锁效果与当前数值。
var PN=['生命','魔法','物攻','物防','魔攻','魔防','速度','幸运'];
function pairs(list,fmt){var out=[];for(var i=0;i<list.length;i+=2)out.push(list.slice(i,i+2).map(fmt).join('　'));return out;}
var PAIRS=[[0,1],[2,4],[3,5],[6,7]]; // 生命／魔法、物攻／魔攻、物防／魔防、速度／幸运（同原生专属法宝）
var texts={
 4047:{who:'屠苏',evo:'太初五兵环',desc:['缺口的青铜铸环。老君炼她，本意是止息兵祸。','铸环合拢，五兵归一。'],
  evolved:['剑气纵横命中的敌人，本回合下一次受到斩锋或横扫时伤害×1.1',
   '点射分2段、贯日分3段、敕令分2段，只支付一次消耗',
   '护阵期间，敌方第一次伤害行动命中的队友各获得护盾：屠苏物防与魔防之和×18，持续1回合',
   '震击、镇魂重击命中已降低伤害的敌人时，该敌人下一次直接伤害×0.9，持续到下回合结束'],
  hint:'获得五种形态的专属特效'},
 4048:{who:'璇',evo:'周天命星仪',desc:['观星的星盘。星谱就刻在盘面上。','周天星宿都在仪上运转。'],
  evolved:['列星期间的第一次回光，额外净化一个可净化的负面状态','列星期间的第一次璃壁附带星幕：受益者本回合下一次受到的敌方直接伤害×0.9'],
  hint:'获得列星专属特效'},
 7912:{who:'谷雨',evo:'万象长春盏',desc:['一盏盛着百谷新芽的瓷盏。','盏中万象长春，生生不息。'],
  evolved:['本场谷雨第一次以骨生花复活时，谷雨与储备比例最低的一名队友各获得谷雨基础最大生命18%的生命储备'],
  hint:'获得复活专属特效'}
};
R.texts=texts;
function relicLines(spec,text,a,evolved,unit){
 // 同颜色放在一起：专属（红）、白色说明、蓝色特效与法宝每级。
 var per=spec.extra.map(Number),rows=['\\c[2]专属：'+text.who,'等级需求：1'];
 if(!evolved)rows.push('进化：'+text.who+'60级时进化为'+text.evo+'，'+text.hint);
 var values=[];spec.rates.forEach(function(r){if(values.indexOf(r[1])<0)values.push(r[1]);});
 values.forEach(function(v){rows=rows.concat(pairs(spec.rates.filter(function(r){return r[1]===v;}),function(r){return PN[r[0]]+'×'+Math.round(r[1]*100)+'%';}).map(function(t){return '\\c[1]特效：'+t;}));});
 if(evolved)text.evolved.forEach(function(t){rows.push('\\c[1]特效：'+t);});
 return rows.concat(PAIRS.map(function(pr){return '\\c[1]法宝每级：'+pr.map(function(i){return PN[i]+'＋'+unit*(per.indexOf(i)>=0?2:1);}).join('　');}));
}
var legacyProfiles={"175": "以生命为种，替众生承劫。\n储备满溢时开启花期，令全队行动化作追加伤害。", "176": "太上老君八卦炉里最后一件、还没铸完的神兵。\n能化为剑、弓、盾、书、锤，交给同伴使用。", "177": "住进同伴心魂里的琉璃星灵。\n会主动报出自己的名字，选择愿意同行的人。"};
alias(Game_Actor.prototype,'profile',function(old,args){var text=old.apply(this,args),id=this.actorId();return legacyProfiles[id]===text&&$dataActors[id]?$dataActors[id].profile:text;});
// Independent params/augment traits/experience are preserved. Only matching baseline rates are removed once.
function removeRates(rows,rates){var out=rows.slice();rates.forEach(function(p){var i=out.findIndex(function(t){return t.code===21&&t.dataId===p[0]&&Math.abs(t.value-p[1])<1e-9;});if(i>=0)out.splice(i,1);});return out;}
R.syncItem=function(item){
 RQ.normalize(item);var spec=specs[bid(item)];if(!spec)return false;
 var a=owner(spec.actor),evolved=!!item._codex60Evolved||!!a&&a.level>=60;
 var text=texts[bid(item)];
 var signature=text?'v05text6-'+(evolved?'evolved':'base'):'v04text1-'+(evolved?'evolved':'base');
 if(item._codex60Signature===signature)return false;
 var original=item.baseItemName||item.name;
 var prior=item._codex60Signature?spec.rates:((item===W.$dataArmors[bid(item)]||/法宝每级基础|额外四项/.test(item.note||''))?spec.rates:spec.old);
 item.traits=removeRates(item.traits||[],prior).concat(spec.rates.map(function(p){return {code:21,dataId:p[0],value:p[1]};}));
 var newName=evolved?spec.name:spec.base;
 item.name=String(item.name||spec.base).replace(original,newName);
 if(item.name===original||[spec.base,spec.name].indexOf(item.name)>=0)item.name=newName;
 item.baseItemName=newName;item.itemGaugeText=newName;
 var per=spec.extra.map(Number),unit=evolved?36:18;
 item.paramPlusPerLevel=Array.from({length:8},function(_,i){return unit*(per.indexOf(i)>=0?2:1);});
 var note=String(item.note||'').replace(/\n?<pos=APs [^>]*>/g,'').replace(/\n?<(?:\w+ Param \+\d+ per Level|GuyuHealStrength[^>]*|quality:\d+|ici:\d+)>/g,'');
 note+='\n<quality:9>\n<ici:9>\n';
 ['mhp','mmp','atk','def','mat','mdf','agi','luk'].forEach(function(p,i){note+='<'+p+' Param +'+item.paramPlusPerLevel[i]+' per Level>\n';});
 var lines=text?relicLines(spec,text,a,evolved,unit):['人物60级：'+spec.base+' → '+spec.name,'每级全属性＋'+unit+'；以下四项额外各＋'+unit,'定位属性：'+per.map(function(i){return ['生命','魔法','物攻','物防','魔攻','魔防','速度','幸运'][i];}).join('／'),'词条按所属人物等级解锁；法宝等级上限888'].concat(spec.lines);
 // HelpExtend 同一 APs 位置逆序显示：屠苏、璇的说明按显示顺序给出，这里倒序写入。
 (text?lines.slice().reverse():lines).forEach(function(s){note+='<pos=APs text='+s+' size=18 color=rgba(255,255,255,1) line=false align=0>\n';});
 item.note=note;item.description=text?'法宝\n'+text.desc[evolved?1:0]:'';
 item.meta=item.meta||{};item.meta.quality=9;item.meta.ici=9;
 item.quality=9;item.ici=9;
 if(W.RJO&&RJO.HE&&RJO.HE.getDescParams)RJO.HE.getDescParams(item,2);
 item._codex60Signature=signature;if(evolved)item._codex60Evolved=true;
 return true;
};
R.sync=function(){
 if(!W.$dataArmors||!W.$gameActors)return;
 RQ.sync();
 $dataArmors.forEach(function(x){if(x)R.syncItem(x);});
 [175,176,177].forEach(function(id){var a=owner(id);if(!a)return;
  a.equips().forEach(function(x){if(x)R.syncItem(x);});
 });
};
alias(DataManager,'extractSaveContents',function(old,args){var out=old.apply(this,args);R.sync();return out;});
alias(DataManager,'registerNewItem',function(old,args){var out=old.apply(this,args);if(out)R.syncItem(out);return out;});
alias(Game_Actor.prototype,'changeLevel',function(old,args){var out=old.apply(this,args);if([175,176,177].indexOf(this.actorId())>=0)R.sync();return out;});
alias(Game_Actor.prototype,'levelUp',function(old,args){var out=old.apply(this,args);if([175,176,177].indexOf(this.actorId())>=0)R.sync();return out;});
alias(Game_Actor.prototype,'changeEquip',function(old,args){if(args[1])R.syncItem(args[1]);return old.apply(this,args);});
alias(BattleManager,'startBattle',function(old,args){R.sync();return old.apply(this,args);});
// Newly gained unequipped relics evolve without needing a battle or equip operation.
alias(Game_Party.prototype,'gainItem',function(old,args){var out=old.apply(this,args);if(args[0]&&specs[bid(args[0])])R.sync();return out;});
// Random-prefix generation may finish after registerNewItem; normalize the final awarded instances.
alias(Game_Party.prototype,'gainIndependentItem',function(old,args){var out=old.apply(this,args);(out||[]).forEach(RQ.normalize);return out;});
alias(Game_Actor.prototype,'magicWeaponCustomParam',function(old,args){var x=args[0]&&args[0].object();if(x)R.syncItem(x);return old.apply(this,args);});
// Relic and five-form growth result multipliers (all read Tusu's level).
(W.CodexDamageHooks||[]).push({name:'three60-effects',build:function(action,target,f){
 var t=owner(176),k=tkey(action),x=owner(177);
 if(k&&t){
  var rate=T.relicMultiplier(t,k);
  if(['arm.dianshe','arm.guanri','arm.chiling'].indexOf(k)>=0&&t.level>=60&&T.relicOn(t)&&action._codex60Segment)rate=1;
  f.finalMultiplier*=rate;
  if(k==='arm.hengsao'){
   var list=action._codex60SwordTargets=action._codex60SwordTargets||[];
   if(list.indexOf(target)<0)list.push(target);
   if(list.indexOf(target)>0)f.finalMultiplier*=B.curve(t,[1,1.2],[20,60]);
  }
  if((k==='arm.zhanfeng'||k==='arm.hengsao')&&target._codex60Forged&&target._codex60Forged.until>=round())f.finalMultiplier*=1.1;
 }
 if(direct(action)){
  if(target._codex60Home&&target._codex60Home.until>=round())f.incomingMultiplier*=.9;
  if(target._codex60StarMist&&target._codex60StarMist.until>=round())f.incomingMultiplier*=.9;
  var s=action.subject();if(s._codex60Crushed&&s._codex60Crushed.until>=round())f.finalMultiplier*=.9;
 }
}});
// Evolved bow/book are segments of one action. Flat additions and final hooks are scaled together.
R.segments=function(action){var t=owner(176),k=tkey(action);return t&&t.level>=60&&T.relicOn(t)?({'arm.dianshe':2,'arm.guanri':3,'arm.chiling':2}[k]||1):1;};
alias(Game_Action.prototype,'apply',function(old,args){
 var n=R.segments(this),target=args[0];
 if(n===1||this._codex60Segment)return old.apply(this,args);
 this._codex60Segment={count:n,index:0,remainder:0};
 try{
  for(var i=0;i<n;i++){
   if(!target.isAlive())break;
   this._codex60Segment.index=i;
   old.apply(this,args);
  }
 }finally{delete this._codex60Segment;}
});
alias(Game_Action.prototype,'makeDamageValue',function(old,args){
 var value=old.apply(this,args),s=this._codex60Segment;
 if(!s)return value;
 var exact=value*1.2/s.count,part=Math.floor(exact);s.remainder+=exact-part;
 if(s.index===s.count-1)part+=Math.floor(s.remainder+1e-8);
 return part;
});
// Marks are consumed after actual damage, never by previews.
alias(Game_Action.prototype,'executeHpDamage',function(old,args){
 var target=args[0],value=Number(args[1])||0,s=this.subject(),k=tkey(this),t=owner(176);
 // Five-weapon shield: first damaging action, all actually hit guarded allies, no free skill/cost change.
 if(value>0&&direct(this)&&t&&t.level>=60&&T.relicOn(t)&&target.isActor()&&target.isStateAffected(T.ids().state.huzhen)&&t._codex60Guard){
  var guard=t._codex60Guard;
  if(!guard.action)guard.action=this;
  if(guard.action===this&&guard.targets.indexOf(target)<0){guard.targets.push(target);L.grant(target,'tusu.fiveguard',(t.def+t.mdf)*18,1,t.actorId(),{noBonus:true,noDecay:true});}
 }
 var wasCuoshi=target._codexTusuCuoshi&&target._codexTusuCuoshi.until>=round(),out=old.apply(this,args);
 if(value>0){
  if(['support.jianqi','support.zhenhun'].indexOf(k)>=0)this._codexTusuResultSuccessful=true;
  if(k==='arm.zhanfeng'||k==='arm.hengsao')delete target._codex60Forged;
  if(direct(this)){delete target._codex60Home;delete target._codex60StarMist;delete s._codex60Crushed;}
  if(t&&t.level>=60&&T.relicOn(t)&&k==='support.jianqi')target._codex60Forged={until:round()};
  if(t&&t.level>=60&&T.relicOn(t)&&wasCuoshi&&['arm.zhenji','support.zhenhun'].indexOf(k)>=0)target._codex60Crushed={until:round()+1};
 }
 return out;
});
alias(Game_Action.prototype,'applyItemUserEffect',function(old,args){
 var out=old.apply(this,args),a=this.subject(),target=args[0],k=tkey(this),xk=xkey(this),d=a&&a._codexXuan;
 if(k==='arm.huzhen'&&owner(176)){
  if(!this._codex60Guard){this._codex60Guard={targets:[],action:null};owner(176)._codex60Guard=this._codex60Guard;}
 }
 if(X.isXuan(a)&&d&&round()<=d.liexingUntil){
  // Per-cast qualifications shared across all shadow recipients.
  if(this._codex60HomeGrant===undefined)this._codex60HomeGrant=a.level>=60&&!d.homeUsed&&['huiguang','libi'].indexOf(xk)>=0;
  if(this._codex60HomeGrant){d.homeUsed=true;target._codex60Home={until:round()};}
  if(X.relicOn(a)&&a.level>=60){
   if(xk==='huiguang'){
    if(this._codex60ExtraCleanse===undefined)this._codex60ExtraCleanse=!d.relicHealUsed;
    if(this._codex60ExtraCleanse){d.relicHealUsed=true;var bad=target.states().find(function(s){return X.isCleanseState(s,false);});if(bad)target.removeState(bad.id);}
   }
   if(xk==='libi'){
    if(this._codex60MistGrant===undefined)this._codex60MistGrant=!d.relicWallUsed;
    if(this._codex60MistGrant){d.relicWallUsed=true;target._codex60StarMist={until:round()};}
   }
  }
 }
 return out;
});
// Ledger callbacks require a real enemy damage action; event deductions/resources never grant relic marks.
var beforeAbsorb=L.onAbsorb;
L.onAbsorb=function(target,amount,rows){
 if(beforeAbsorb)beforeAbsorb.apply(this,arguments);
 var action=BattleManager._action;if(!direct(action))return;
 var x=owner(177),d=x&&x._codexXuan;
 var libi=rows.find(function(r){return r.source==='xuan.libi'&&r.lastAbsorbed>0;});
 if(x&&d&&x.level>=10&&libi&&libi.amount<=0){ // 星盾流转·定轨（璇成长被动，不需要装备法宝）
  d.relicBreakRound=d.relicBreakRound||{};
  if(d.relicBreakRound[target.actorId()]!==round()){
   d.relicBreakRound[target.actorId()]=round();
   // Share the existing one-use dingxing slot, do not create a second immunity.
   d.dingxing[target.actorId()]={until:round()+1,numeric:false};
   target.addState(X.ids().state.dingxing);
  }
 }
 if(rows.some(function(r){return r.source==='guyu.shield'&&r.lastAbsorbed>0;}))G.springShieldHit(target);
};
// Some native actors override addState; protect the actual actor entry as well as the base class.
alias(Game_Actor.prototype,'addState',function(old,args){
 var a=owner(177),d=a&&a._codexXuan,id=args[0],grant=d&&d.dingxing[this.actorId()];
 // 先看定轨保护再取出战成员：角色构造中途取出战成员会再次构造同一角色（饿狼战斗中首次创建时无限递归）
 if(grant&&grant.until>=round()&&$gameParty.inBattle()&&$gameParty.battleMembers().indexOf(a)>=0&&X.isCleanseState($dataStates[id],true)&&!this.isStateAffected(id)){
  delete d.dingxing[this.actorId()];if(this.isStateAffected(X.ids().state.dingxing))this.removeState(X.ids().state.dingxing);return;
 }
 return old.apply(this,args);
});
// Transfer extra relay AFTER native yiguang, conserve source amounts and expiry.
var bound=X&&B.kinds.xuan,priorBind=bound&&bound.onBind;
if(bound)bound.onBind=function(a,target,reason,previous){
 if(priorBind)priorBind.apply(this,arguments);
 if(!previous||a.level<20||reason==='opening')return; // 星盾流转·接力（璇成长被动，不需要装备法宝）
 var recipient=$gameParty.battleMembers().filter(function(t){return t!==previous&&t!==target&&t!==a&&t.isAlive()&&!B.untargetable(t);}).sort(function(x,y){return x.hp/x.mhp-y.hp/y.mhp||x.index()-y.index();})[0];
 if(!recipient)return;
 L.rows(previous).filter(function(r){return /^xuan\./.test(r.source);}).forEach(function(r){
  var move=Math.floor(r.amount*(a.level>=60?.3:.2));if(!move)return;
  var turns=Math.max(1,r.until-round()+1),remainder=r.amount-move;
  L.revoke(previous,r.source);if(remainder)L.grant(previous,r.source,remainder,turns,a.actorId(),{noBonus:true,noDecay:r.noDecay});
  // Merge only portions with the same origin and expiry; later relays cannot refresh older portions.
  var src='xuan.relay.'+r.source+'.until-'+r.until,existing=L.amount(recipient,src);
  L.revoke(recipient,src);L.grant(recipient,src,existing+move,turns,a.actorId(),{noBonus:true,noDecay:r.noDecay});
 });
};
// Reset transient weapon marks and future-damage marks without touching saves or equipment.
function clear(){all().forEach(function(a){['_codex60Forged','_codex60Home','_codex60StarMist','_codex60Crushed','_codex60Guard'].forEach(function(k){delete a[k];});});}
alias(BattleManager,'startBattle',function(old,args){clear();return old.apply(this,args);});
alias(BattleManager,'endBattle',function(old,args){try{return old.apply(this,args);}finally{clear();}});
alias(DataManager,'extractSaveContents',function(old,args){var out=old.apply(this,args);clear();return out;});

// Existing open-blade book protection spells share Heming once for the whole paid action.
function bookProtection(action){
 var t=owner(176),a=action&&action.subject(),item=action&&action.item();
 return !!(t&&B.isBound(t)&&T.holder(t)===a&&T.weapon(t)==='book'&&T.kairen(t).slice(0,Math.min(3,Number(t._AdvancedNum)||0)).indexOf('book')>=0&&item&&item.hitType===2&&!action._codexInternal&&action.isForFriend()&&
  (action.isHpRecover()||item.effects.some(function(e){return e.code===11;})||/(?:addShield|gainShield|ShieldLedger\.grant)/.test(item.damage.formula||'')||xkey(action)==='libi'));
}
alias(BattleManager,'startAction',function(old,args){
 var a=this._subject,action=a&&a.currentAction(),t=owner(176);
 if(bookProtection(action)){
  if(!a.isStateAffected(T.ids().state.heming))T.roundSupport(t,'heming',false);
  if(a.isStateAffected(T.ids().state.heming))action._codex60BookHemingRate=T.hemingRate(t);
 }
 return old.apply(this,args);
});
alias(BattleManager,'endAction',function(old,args){
 var action=this._action,a=this._subject;
 if(action&&action._codex60BookHemingRate&&a&&a.isStateAffected(T.ids().state.heming))a.removeState(T.ids().state.heming);
 return old.apply(this,args);
});
alias(Game_Action.prototype,'executeHpDamage',function(old,args){
 if(args[1]<0&&this._codex60BookHemingRate)args[1]=Math.floor(args[1]*this._codex60BookHemingRate);
 return old.apply(this,args);
});
alias(Game_Battler.prototype,'addShield',function(old,args){
 var action=BattleManager._action;
 if(action&&action._codex60BookHemingRate)args[0]*=action._codex60BookHemingRate;
 return old.apply(this,args);
});
alias(L,'grant',function(old,args){
 var action=BattleManager._action;
 if(action&&action._codex60BookHemingRate)args[2]*=action._codex60BookHemingRate;
 return old.apply(this,args);
});

return R;
});
