// 【Codex·未经Claude检验】小数百分比解析；ID、次数与概率字段保持。
//==============================================================================
// dsPassiveSkill.js
// Copyright (c) 2015 - 2017 Douraku
// Released under the MIT License.
// http://opensource.org/licenses/mit-license.php
//==============================================================================

/*:
* @plugindesc 被动技能实现 ver1.7.0（优化版）
* @author 道楽(汉化:多卡多卡)
*
* @param 被动技能的技能类型A
* @type number
* @desc 被动技能技能类型的编号，可以在战斗中隐藏此类技能
* @default 0
*
* @param 被动技能的技能类型B
* @type number
* @desc 被动技能技能类型的编号，可以在战斗中隐藏此类技能
* @default 0
*
* @help
*
* 优化了处理流程，战斗时性能提高
*
* RPGMaker MV 默认只有主动技能，而没有那种学习了就能生效的被动技能，
* 此插件可以设定被动技能，并且能够在战斗中将此类技能隐藏。
*
* 在汉化的过程中还添加了部分原插件没有的功能，
* 插件版权归原作者所有，插件的使用和二次修改遵守MIT协议。
* 可以将此插件用于商业和非商业用途游戏中，
* 但如果进行了修改或再次发布，需要保留原作者的版权声明。
* -----------------------------------------------------------------------------
* 使用此插件时需要建立一个被动技能类型，并将所有被动技能范围设置为无，
* 并将场合设置为不可使用
* (此操作不是必需的，但这样能让被动技能看起来更加和谐)
* 
* 注意:由于敌人没有学会技能这一概念，因此请不要尝试在敌人的行动模式中
* 添加被动技能!!!
*
* 在技能的注释栏添加以下内容可以实现被动效果:
* (当数字位数不足时以0补齐，如0002，特殊说明除外)
* 输入编号时不需要添加[],直接输入数值即可
* --------
* ・增加装备武器的种类(Equip Weapon)
* <passiveEWPN[武器类型]>
*  [武器类型] - 武器类型的编号(2位数字)
*
* --------
* ・增加装备防具的种类(Equip Weapon)
* <passiveEARM[防具类型]>
*  [防具类型] - 防具类型的编号(2位数字)
*
* --------
* ・增加通常能力值(Parameter Boost)
* <passivePBST[能力值编号]:[上升量(%)]>
*  [能力值编号] - 需要增加的通常能力值的编号(数字)
*                 0 - HP
*                 1 - HP
*                 2 - 攻击力
*                 3 - 防御力
*                 4 - 魔法攻击
*                 5 - 魔法防御
*                 6 - 敏捷
*                 7 - 幸运
*  [上升量(%)]  - 能力值的上升量(数字)
*                 如果没有%则代表数值上升，有%代表百分比上升，
*                 百分比上升时基准为没有装备时的数值。
*
* 无法在同一技能中同时增加数值和百分比，否则将由最后一条决定最终效果
* 例)<passivePBST0:10%>
*    <passivePBST0:100>
*    结果为增加100HP，而没有增加10%
*
* --------
* ・一定条件下增加通常能力值(Parameter Boost Ex)
* <passivePBSTEX[能力值编号]:[上升量(%)],[判定条件],[判定值]>
*  [能力值编号]   - 参考passivePBST
*  [上升量(%)]    - 参考passivePBST
*  [判定条件]     - 增强特定能力值的条件(文字)
*                   HPUP - HP在特定值以上发挥效果
*                   HPLW - HP在特定值以下发挥效果
*                   MPUP - MP在特定值以上发挥效果
*                   MPLW - MP在特定值以下发挥效果
*                   TPUP - TP在特定值以上发挥效果
*                   TPLW - TP在特定值以下发挥效果
*  [判定值]       - 判定条件对应的数值(数字)
*
* 例) HP50%以下时增加50%的攻击力:
* <passivePBSTEX2:50%,HPUP,50>
* 可以实现背水，浑身等技能特定条件下发挥的效果
*
* --------
* ・增加追加能力值(XParameter Boost)
* <passiveXPBST[能力值编号]:[上升量]>
*  [能力值编号] - 需要增加的追加能力值的编号(数字)
*                 0 - 命中率
*                 1 - 回避率
*                 2 - 暴击率
*                 3 - 暴击回避率
*                 4 - 魔法回避率
*                 5 - 魔法反射率
*                 6 - 反击率
*                 7 - HP自动恢复率
*                 8 - MP自动恢复率
*                 9 - TP自动恢复率
*  [上昇量]     - 能力值的上升量(数字)
*
* --------
* ・一定条件下增加追加能力值(XParameter Boost Ex)
* <passiveXPBSTEX[能力值编号]:[上升量],[判定条件],[判定值]>
*  [能力值编号]   - 参考passiveXPBST
*  [上升量]       - 参考passiveXPBST
*  [判定条件]     - 参考passivePBSTEX
*  [判定值]       - 参考passivePBSTEX
*
* 例) MP最大时追加5%的HP自动恢复:
* <passiveXPBSTEX7:5,MPUP,100>
*
* --------
* ・增加特殊能力值(SParameter Boost)
* <passiveSPBST[能力值编号]:[上升量]>
*  [能力值编号] - 需要增加的追加能力值的编号(数字)
*                 0 - 受到攻击几率
*                 1 - 防御效果
*                 2 - 恢复效果
*                 3 - 药理知识
*                 4 - MP消耗率
*                 5 - TP补充率
*                 6 - 受到的物理伤害倍率
*                 7 - 受到的魔法伤害倍率
*                 8 - 地形伤害倍率
*                 9 - 经验值获得率
*  [上升量]     - 能力值的上升量(数字)
*
* --------
* ・一定条件下增加特殊能力值(XParameter Boost Ex)
* <passiveSPBSTEX[能力值编号]:[上升量],[判定条件],[判定值]>
*  [能力值编号]   - 参考passiveSPBST
*  [上升量]       - 参考passiveSPBST
*  [判定条件]     - 参考passivePBSTEX
*  [判定值]       - 参考passivePBSTEX
*
* 例) TP50%以上时被攻击率减半:
* <passiveSPBSTEX0:50,TPUP,50>
*
* --------
* ※可以实现但不推荐 (推荐使用passivePBSTEX)
* ・一定HP以下增加通常能力值(Indomitable)
* <passiveINDM[能力值编号]:[剩余HP比例],[上升量(%)]>
*  [能力值编号] - 参考passivePBST
*  [剩余HP比例] - 发挥效果时剩余HP的百分比(数字)
*  [上升量(%)]  - 能力值的上升量(数字)
*                 如果没有%则代表数值上升，有%代表百分比上升，
*                 百分比上升时基准为没有装备时的数值。
*
* --------
* ※可以实现但不推荐 (推荐使用passiveXPBSTEX)
* ・一定HP以下增加追加能力值(XIndomitable)
* <passiveXINDM[能力值编号]:[剩余HP比例],[上升量(%)]>
*  [能力值编号] - 参考passiveXPBST
*  [剩余HP比例] - 发挥效果时剩余HP的百分比(数字)
*  [上升量]     - 能力值的上升量(数字)
*
* --------
* ※可以实现但不推荐 (推荐使用passiveSPBSTEX)
* ・一定HP以下增加特殊能力值(SIndomitable)
* <passiveSINDM[能力值编号]:[剩余HP比例],[上升量(%)]>
*  [能力值编号] - 参考passiveSPBST
*  [剩余HP比例] - 发挥效果时剩余HP的百分比(数字)
*  [上升量]     - 能力值的上升量(数字)
*
* --------
* ・属性有效度设定(Element Rate)
* <passiveELEM[属性编号]:[有效度]>
*  [属性编号] - 有效度对应的属性编号(2位数字)
*  [有效度]   - 对应属性的有效度的百分比(数字)
*               与职业和装备等的属性有效度采用乘算。
*
* ・元素攻击力增加(Element UP)
* <passiveELUP[属性编号]:[增加量(%)]>
*  [属性编号] - 增强攻击力的元素属性(普通攻击:-1,无:00,物理:01)(2位数字)
*  [增加量]   - 增强攻击力的百分比(数字)
*
* --------
* ・状态有效度设定(State Rate)
* <passiveSTAT[状态编号]:[有效度]>
*  [状态编号] - 有效度对应的状态编号(4位数字)
*  [有效度]   - 对应状态的有效度的百分比(数字)
*               与职业和装备等的状态有效度采用乘算。
*
* --------
* ・状态无效化(State Regist)
* <passiveSTREG[状态编号]>
*  [状态编号] - 无效化的状态(4位数字)
*
* --------
* ・攻击追加状态(Attack State)
* <passiveATKST[状态编号]:[付与率]>
*  [状态编号] - 攻击时付与的状态(4位数字)
*  [付与率]   - 对应状态付与率的百分比(数字)
*                   与职业和装备等的付与率采用乘算。
*
* --------
* ・伤害倍率(Harm Ride)
* <passiveHarmRi:[加伤率]>
*  [加伤率]   - 最终伤害加伤的百分比(数字)
*                   与最终伤害计算采用乘算。
*
* --------
* ・爆伤增加(Harm Ride)
* <passiveCrHarmRi:[加伤率]>
*  [加伤率]   - 爆伤加成的百分比(数字)
*
* --------
* ・属性伤害减免(Harm Relief)
* <passiveHarmRe[属性编号]:[减伤值]>
*  [减伤值]   - 受到属性伤害后的减免数值(数字)
*
* --------
* ・追加技能类型(Add Skill Type)
* <passiveAST[技能类型编号]>
*  [技能类型编号] - 追加的技能类型的编号(2位数字)
*
* --------
* ・武器装备时增加的能力值UP(Weapon Mastery)
* <passiveWPNM[武器类型]:[上升量(%)]>
*  [武器类型]   - 武器类型的编号(2位数字)
*  [上升量(%)]  - 装备时能力值的上升量
*                 如果没有%则代表数值上升，有%代表百分比上升(数字)
*
* --------
* ・防具装备时增加的能力值UP(Armor Mastery)
* <passiveARMM[防具类型]:[上升量(%)]>
*  [防具类型]   - 防具类型的编号(2位数字)
*  [上升量(%)]  - 装备时能力值的上升量
*                 如果没有%则代表数值上升，有%代表百分比上升(数字)
*
* --------
* ・先制攻击率增加(Preemptive)
* <passivePREE:[上升量]>
*  [上升量] - 先制攻击率的增加量(数字)
*
* --------
* ・被偷袭率下降(Anti Surprise)
* <passiveASUP:[下降量]>
*  [下降量] - 被偷袭率的下降量(数字)
*
* --------
* ・增加金钱获取量(Gold Rate)
* <passiveGRUP:[上升量]>
*  [上升量] - 金钱获取量增加%(数字)
*
* --------
* ・增加物品掉率(Item Rate)
* <passiveIRUP:[上升量]>
*  [上升量] - 物品掉率增加%(数字)
*
* --------
* ・增加TP上限(Extra TP)
* <passiveEXTTP:[上升量]>
*  [上升量] - TP上限增加量
*
* --------
* ・增加输出的治疗量(Heal UP)
* <passiveHEUP:[上升量]>
*  [上升量] - 治疗量增加量%(数字)
*
* --------
* ・行动回数追加(Action Plus)
* <passiveAPLUS:[追加概率]>
*  [追加概率(%)] - 行动回数追加的概率%(数字)
*
* --------
* ・自动战斗状态(Auto Battle)
* <passiveAUTO>
*
* --------
* ・防御状态(Guard)
* <passiveGUARD>
*
* --------
* ・掩护状态(Substitute)
* <passiveSUBS>
*
* --------
* ・TP保留状态(Preserve Tp)
* <passivePRETP>
*
*/

var Imported = Imported || {};
var Star = Star || {};
Star.dsPassiveSkill = Star.dsPassiveSkill || {};
Imported.dsPassiveSkill = true;

var dsPassiveSkill = dsPassiveSkill || {};
dsPassiveSkill.parameters = PluginManager.parameters('dsPassiveSkill');
dsPassiveSkill.parameters.hideA = Number(dsPassiveSkill.parameters['被动技能的技能类型A'] || 0);
dsPassiveSkill.parameters.hideB = Number(dsPassiveSkill.parameters['被动技能的技能类型B'] || 0);

const PASSIVE_TAGS = [
    'passiveEWPN', 'passiveEARM', 'passivePBST', 'passivePBSTEX',
    'passiveXPBST', 'passiveXPBSTEX', 'passiveSPBST', 'passiveSPBSTEX',
    'passiveINDM', 'passiveXINDM', 'passiveSINDM', 'passiveELEM',
    'passiveELUP', 'passiveSTAT', 'passiveSTREG', 'passiveATKST',
    'passiveHarmRi', 'passiveCrHarmRi', 'passiveHarmRe', 'passiveAST',
    'passiveWPNM', 'passiveARMM', 'passivePREE', 'passiveASUP',
    'passiveGRUP', 'passiveIRUP', 'passiveEXTTP', 'passiveHEUP',
    'passiveAPLUS', 'passiveAUTO', 'passiveGUARD', 'passiveSUBS',
    'passivePRETP'
];

// 辅助函数：检查是否为被动技能标签
function isPassiveTag(tag) {
    return PASSIVE_TAGS.some(prefix => tag.startsWith(prefix));
}

(function (exports) {
    'use strict';
    var isNotAString = function(args) {
        return String(args) !== args;
    };
    //--------------------------------------------------------------------------
    /** Utility */
    function Utility() { }

    Utility.calcParamBoost = function (baseParam, metaData) {
        var ret = 0;
        var re = /([-]?\d+(?:\.\d+)?)(%?)/i;
        var match = re.exec(metaData);
        if (match) {
            if (match[2] === '%') {
                var rate = Number(match[1]) * 0.01;
                ret = Math.floor(baseParam * rate);
            }
            else {
                ret = Number(match[1]);
            }
        }
        return ret;
    };

    Utility.convertEscapeCharacters = function (metaData) {
        var ret = 0;
        var re = /([-]?\d+(?:\.\d+)?)/i;
        var match = re.exec(metaData);
        if (match) {
            ret = Number(match[1]) * 0.01;
        }
        return ret;
    };
    Utility.calcXParamBoost = function (metaData) {
    // 提取数值部分（支持负号、小数、百分号）
    var match = /([-]?\d*\.?\d+)\s*[%％]?/.exec(metaData);
    if (match) {
        var numValue = parseFloat(match[1]);
        if (!isNaN(numValue)) {
                return numValue * 0.01;
        }
    }
    return 0; // 默认返回0
};

    Utility.calcSParamBoost = function (metaData) {
        var ret = 0;
        var re = /([-]?\d+(?:\.\d+)?)/i;
        var match = re.exec(metaData);
        if (match) {
            ret = Number(match[1]) * 0.01;
        }
        return ret;
    };
    //--------------------------------------------------------------------------
    /** Game_Actor */
    // Game_Actor.prototype.iteratePassiveSkill = function (metaName, callback) {
        // this.skills().forEach(function (skill) {
            // if (skill && skill.meta[metaName]) {
                // callback(skill.meta[metaName]);
            // }
        // });
    // };
	
	Game_Actor.prototype.iteratePassiveSkill = function(metaName, callback) {
		if(!this._passiveSkillCache) this.refreshPassiveSkillCache();
		const cachedData = this._passiveSkillCache[metaName];
		if (cachedData) {
			for (const metaData of cachedData) {
				callback(metaData);
			}
		}
	};
	
	// Game_Actor.prototype.refreshPassiveSkillCache = function() {
    // this._passiveSkillCache = {};
    // const skills = this.skills();
    
    // for (const skill of skills) {
        // if (!skill) continue;
        // this.addSkillToPassiveCache(skill);
    // }
// };

	Game_Actor.prototype.refreshPassiveSkillCache = function() {
    this._passiveSkillCache = {};
    const skills = this.skills();
    for (const skill of skills) {
        if (!skill) continue;
        
        for (const [metaName, metaData] of Object.entries(skill.meta)) {
            if (!this._passiveSkillCache[metaName]) {
                this._passiveSkillCache[metaName] = [];
            }
            this._passiveSkillCache[metaName].push(metaData);
        }
    }
	};
	
	//学习技能时更新缓存
	var _Game_Actor_learnSkill = Game_Actor.prototype.learnSkill;
	Game_Actor.prototype.learnSkill = function(skillId) {
		if(!this._passiveSkillCache) this.refreshPassiveSkillCache();
	const hadSkill = this._skills.includes(skillId);
	const skill = $dataSkills[skillId];
    _Game_Actor_learnSkill.call(this, skillId);
	//console.log(this._name,'学习技能', skillId)
	// 只处理新学习的被动技能
    if (!hadSkill && skill && skill.meta) {
        this.addSkillToPassiveCache(skill);
    }
	};

	//遗忘技能时更新缓存
	var _Game_Actor_forgetSkill = Game_Actor.prototype.forgetSkill;
	Game_Actor.prototype.forgetSkill = function(skillId) {
		if(!this._passiveSkillCache) this.refreshPassiveSkillCache();
		const skill = $dataSkills[skillId];
		const hadSkill = this._skills.includes(skillId);
    _Game_Actor_forgetSkill.call(this, skillId);
	//console.log(this._name,'遗忘技能', skillId)
    // 只处理实际遗忘的被动技能
    if (hadSkill && skill && skill.meta) {
        this.removeSkillFromPassiveCache(skill);
    }
	};
	
	// 添加技能到缓存
	Game_Actor.prototype.addSkillToPassiveCache = function(skill) {
    if (!this._passiveSkillCache) this._passiveSkillCache = {};
    
    for (const [tag, metaData] of Object.entries(skill.meta)) {
        if (isPassiveTag(tag)) {
            if (!this._passiveSkillCache[tag]) {
                this._passiveSkillCache[tag] = [];
            }
            this._passiveSkillCache[tag].push(metaData);
        }
    }
};

	// 从缓存移除技能
	Game_Actor.prototype.removeSkillFromPassiveCache = function(skill) {
    if(!this._passiveSkillCache) this.refreshPassiveSkillCache();
    
    for (const [tag, metaData] of Object.entries(skill.meta)) {
        if (isPassiveTag(tag) && this._passiveSkillCache[tag]) {
            const index = this._passiveSkillCache[tag].indexOf(metaData);
            if (index !== -1) {
                this._passiveSkillCache[tag].splice(index, 1);
                
                // 清理空数组
                if (this._passiveSkillCache[tag].length === 0) {
                    delete this._passiveSkillCache[tag];
                }
            }
        }
    }
};

    Game_Actor.prototype.evaluateCondition = function (condition, value) {
        var ret = false;
        switch (condition) {
            case 'HPUP': ret = (this.hpRate() >= value * 0.01) ? true : false; break;
            case 'HPLW': ret = (this.hpRate() <= value * 0.01) ? true : false; break;
            case 'MPUP': ret = (this.mpRate() >= value * 0.01) ? true : false; break;
            case 'MPLW': ret = (this.mpRate() <= value * 0.01) ? true : false; break;
            case 'TPUP': ret = (this.tpRate() >= value * 0.01) ? true : false; break;
            case 'TPLW': ret = (this.tpRate() <= value * 0.01) ? true : false; break;
        }
        return ret;
    };

    var _Game_Actor_paramBase = Game_Actor.prototype.paramBase;
    Game_Actor.prototype.paramBaseDirect = function (paramId) {
        return _Game_Actor_paramBase.call(this, paramId);
    };

    Game_Actor.prototype.paramBaseBoost = function (paramId) {
        var baseParam = this.paramBaseDirect(paramId);
        var ret = 0;
        var tagPBST = 'passivePBST' + ('0' + paramId).slice(-1);
        this.iteratePassiveSkill(tagPBST, function (metaData) {
            ret += Utility.calcParamBoost(baseParam, metaData);
        });
        var tagPBSTEX = 'passivePBSTEX' + ('0' + paramId).slice(-1);
        this.iteratePassiveSkill(tagPBSTEX, function (metaData) {
            var splitData = metaData.split(',');
            if (this.evaluateCondition(splitData[1], Number(splitData[2]))) {
                ret += Utility.calcParamBoost(baseParam, splitData[0]);
            }
        }.bind(this));
        var tagINDM = 'passiveINDM' + ('0' + paramId).slice(-1);
        this.iteratePassiveSkill(tagINDM, function (metaData) {
            var re = /(\d+)\,([-]?\d+(?:\.\d+)?)(%?)/i;
            var match = re.exec(metaData);
            if (match) {
                if (this.hpRate() <= Number(match[1]) * 0.01) {
                    if (match[3] === '%') {
                        var rate = Number(match[2]) * 0.01;
                        ret += Math.floor(baseParam * rate);
                    }
                    else {
                        ret += Number(match[2]);
                    }
                }
            }
        }.bind(this));
        return ret;
    };

    Game_Actor.prototype.paramBase = function (paramId) {
        var ret = this.paramBaseDirect(paramId);
        ret += this.paramBaseBoost(paramId);
        return ret;
    };

    var _Game_Actor_paramPlus = Game_Actor.prototype.paramPlus;
    Game_Actor.prototype.paramPlusDirect = function (paramId) {
        return _Game_Actor_paramPlus.call(this, paramId);
    };

    Game_Actor.prototype.paramPlusBoost = function (paramId) {
        var ret = 0;
        this.equips().forEach(function (item) {
            if (item) {
                if (DataManager.isWeapon(item)) {
                    var tag = 'passiveWPNM' + ('00' + item.wtypeId).slice(-2);
                    this.iteratePassiveSkill(tag, function (metaData) {
                        if (item.params[paramId] > 0) {
                            ret += Utility.calcParamBoost(item.params[paramId], metaData);
                        }
                    });
                }
                else if (DataManager.isArmor(item)) {
                    var tag = 'passiveARMM' + ('00' + item.atypeId).slice(-2);
                    this.iteratePassiveSkill(tag, function (metaData) {
                        if (item.params[paramId] > 0) {
                            ret += Utility.calcParamBoost(item.params[paramId], metaData);
                        }
                    });
                }
            }
        }, this);
        return ret;
    };

    Game_Actor.prototype.paramPlus = function (paramId) {
        var ret = this.paramPlusDirect(paramId);
        ret += this.paramPlusBoost(paramId);
        return ret;
    };

    var _Game_Actor_xparam = Game_Actor.prototype.xparam;
    Game_Actor.prototype.xparamDirect = function (xparamId) {
        return _Game_Actor_xparam.call(this, xparamId);
    };

    Game_Actor.prototype.xparam = function (xparamId) {
        var ret = this.xparamDirect(xparamId);
        var tagPBST = 'passiveXPBST' + ('0' + xparamId).slice(-1);
        this.iteratePassiveSkill(tagPBST, function (metaData) {
            ret += Utility.calcXParamBoost(metaData);
        });
        var tagPBSTEX = 'passiveXPBSTEX' + ('0' + xparamId).slice(-1);
        this.iteratePassiveSkill(tagPBSTEX, function (metaData) {
            var splitData = metaData.split(',');
            if (this.evaluateCondition(splitData[1], Number(splitData[2]))) {
                ret += Utility.calcXParamBoost(splitData[0]);
            }
        }.bind(this));
        var tagINDM = 'passiveXINDM' + ('0' + xparamId).slice(-1);
        this.iteratePassiveSkill(tagINDM, function (metaData) {
            var re = /(\d+)\,([-]?\d+(?:\.\d+)?)/i;
            var match = re.exec(metaData);
            if (match) {
                if (this.hpRate() <= Number(match[1]) * 0.01) {
                    ret += Number(match[2]) * 0.01;
                }
            }
        }.bind(this));
        return ret;
    };

    var _Game_Actor_sparam = Game_Actor.prototype.sparam;
    Game_Actor.prototype.sparamDirect = function (sparamId) {
        return _Game_Actor_sparam.call(this, sparamId);
    };

    Game_Actor.prototype.sparam = function (sparamId) {
        var ret = this.sparamDirect(sparamId);
        var tagPBST = 'passiveSPBST' + ('0' + sparamId).slice(-1);
        this.iteratePassiveSkill(tagPBST, function (metaData) {
            ret += Utility.calcSParamBoost(metaData);
        });
        var tagPBSTEX = 'passiveSPBSTEX' + ('0' + sparamId).slice(-1);
        this.iteratePassiveSkill(tagPBSTEX, function (metaData) {
            var splitData = metaData.split(',');
            if (this.evaluateCondition(splitData[1], Number(splitData[2]))) {
                ret += Utility.calcSParamBoost(splitData[0]);
            }
        }.bind(this));
        var tagINDM = 'passiveSINDM' + ('0' + sparamId).slice(-1);
        this.iteratePassiveSkill(tagINDM, function (metaData) {
            var re = /(\d+)\,([-]?\d+(?:\.\d+)?)/i;
            var match = re.exec(metaData);
            if (match) {
                if (this.hpRate() <= Number(match[1]) * 0.01) {
                    ret += Number(match[2]) * 0.01;
                }
            }
        }.bind(this));
        return ret;
    };

    var _Game_Actor_elementRate = Game_Actor.prototype.elementRate;
    Game_Actor.prototype.elementRate = function (elementId) {
        var ret = _Game_Actor_elementRate.call(this, elementId);
        var tag = 'passiveELEM' + ('00' + elementId).slice(-2);
        this.iteratePassiveSkill(tag, function (metaData) {
            var re = /([-]?\d+(?:\.\d+)?)/i;
            var match = re.exec(metaData);
            if (match) {
                ret *= Number(match[1]) * 0.01;
            }
        });
        return ret;
    };

    var _Game_Actor_stateRate = Game_Actor.prototype.stateRate;
    Game_Actor.prototype.stateRate = function (stateId) {
        var ret = _Game_Actor_stateRate.call(this, stateId);
        var tag = 'passiveSTAT' + ('0000' + stateId).slice(-4);
        this.iteratePassiveSkill(tag, function (metaData) {
            var re = /([-]?\d+(?:\.\d+)?)/i;
            var match = re.exec(metaData);
            if (match) {
                ret *= Number(match[1]) * 0.01;
            }
        });
        return ret;
    };

    var _Game_Actor_stateResistSet = Game_Actor.prototype.stateResistSet;
	Game_Actor.prototype.stateResistSet = function() {
        var ret = _Game_Actor_stateResistSet.call(this);
        if(!this._passiveSkillCache) this.refreshPassiveSkillCache();
        // 直接从缓存中获取所有被动状态抵抗ID
        const stateIds = Object.keys(this._passiveSkillCache)
            .filter(key => key.startsWith('passiveSTREG'))
            .map(key => Number(key.replace('passiveSTREG', '')));
        
        // 添加唯一的状态ID
        stateIds.forEach(stateId => {
            if (!ret.contains(stateId)) {
                ret.push(stateId);
            }
        });
        
        return ret;
    };
	
    // Game_Actor.prototype.stateResistSet = function () {
        // var ret = _Game_Actor_stateResistSet.call(this);
        // this.skills().forEach((skill) => {
            // if (!!skill) {
                // var re = /<passiveSTREG(\d+)>/ig;
                // var match = re.exec(skill.note);
                // while (match !== null) {
                    // const stateId = Number(match[1]);
                    // if (!ret.contains(stateId)) {
                        // ret.push(stateId);
                    // }
                    // match = re.exec(skill.note);
                // }
            // }
        // });
        // return ret;
    // };

    var _Game_Actor_attackStates = Game_Actor.prototype.attackStates;
	Game_Actor.prototype.attackStates = function() {
        var ret = _Game_Actor_attackStates.call(this);
        if(!this._passiveSkillCache) this.refreshPassiveSkillCache();
        // 直接从缓存中获取所有攻击附加状态ID
        const stateIds = Object.keys(this._passiveSkillCache)
            .filter(key => key.startsWith('passiveATKST'))
            .map(key => Number(key.replace('passiveATKST', '')));
        
        // 添加唯一的状态ID
        stateIds.forEach(stateId => {
            if (!ret.contains(stateId)) {
                ret.push(stateId);
            }
        });
        
        return ret;
    };
	
    // Game_Actor.prototype.attackStates = function () {
        // var ret = _Game_Actor_attackStates.call(this);
        // this.skills().forEach((skill) => {
            // if (!!skill) {
                // var re = /<passiveATKST(\d+)>/ig;
                // var match = re.exec(skill.note);
                // while (match !== null) {
                    // const stateId = Number(match[1]);
                    // if (!ret.contains(stateId)) {
                        // ret.push(stateId);
                    // }
                    // match = re.exec(skill.note);
                // }
            // }
        // });
        // return ret;
    // };

    var _Sprite_Actor_updateFrame = Sprite_Actor.prototype.updateFrame;
	Sprite_Actor.prototype.updateFrame = function() {
        _Sprite_Actor_updateFrame.call(this);
        if (!this._mainSprite || !this._actor) return;
        
        const scale = this._actor._passiveCache?.SvPngFd || 1;
        this._mainSprite.scale.x = scale;
        this._mainSprite.scale.y = scale;
    };

    var _Game_Actor_attackStatesRate = Game_Actor.prototype.attackStatesRate;
    Game_Actor.prototype.attackStatesRate = function (stateId) {
        var ret = _Game_Actor_attackStatesRate.call(this, stateId);
        var tag = 'passiveATKST' + ('0000' + stateId).slice(-4);
        this.iteratePassiveSkill(tag, function (metaData) {
            var re = /([-]?\d+(?:\.\d+)?)/i;
            var match = re.exec(metaData);
            if (match) {
                ret += Number(match[1]) * 0.01;
            }
        });
        return ret;
    };
	
	// Game_Actor 扩展 - 被动效果缓存
Game_Actor.prototype.initPassiveCache = function() {
    this._passiveCache = {
		okadd: false,
        // 元素减伤
        harmRe: {},
		// 穿透减伤 (新增)
        penetrateHarmRe: {
            fixed: {},   // 固定穿透值
            percent: {}  // 百分比穿透值
        },
		// 元素伤害加成
        elementAmplify: {},   // 按元素ID存储加成百分比
        itemRateUp: 0,        // 物品掉率加成
        // 技能加伤 {skillId: {rate: 百分比加成, flat: 固定值}}
        skillPass: {},
        // 技能类型加伤 {type: 加成值}
        skillTypeDvup: {},
        // 装备类型加伤 {type: 加成值}
        SkETypeHarmRi: {},
        // 全局加伤
        globalHarmRi: 0,
        // 暴击加伤
        critHarmRi: 0,
        // 状态效果
        states: {
            // 恢复效果修改
            DBHPLSteal: 1,
        },
		// 攻击次数相关
        atkk: 0,
        againUse: {
            bySkill: {},
            byType: { Zj: 0, Mf: 0 },
            all: 0
        },
		traits: {
            againatk: 0,  // 攻击次数
            againaction: 0  // 再次行动
        },
        // 暴击率增加
        critPush: {
            bySkill: {},
            byType: { Zj: 0, Mf: 0 },
            all: 0
        },
        // 消耗减少
        consumeReduce: {
            bySkill: {},
            byType: { Zj: 0, Mf: 0 },
            all: 0
        },
        // 必中
        certainHit: {
            global: false,
            bySkill: {}
        },
		//图像放大
		SvPngFd: 1,
		//装备类型覆盖
		SkEquipType: 0,
		//装备类型叠加
        SkETypeAll: [],
		//元素类型覆盖
		damageElement: 0
    };
	
};


Game_Actor.prototype.refreshPassiveCache = function() {
    const cache = this._passiveCache;
    if (typeof invalidateBattlerStateCache === 'function') invalidateBattlerStateCache(this);
    const _inBattle = $gameParty.inBattle();
    //【DeepSeek·未经Codex/Claude检验】v0.51：刷新前完整复位本函数解析的字段，避免连续 refresh 重复累计（harmRe 等）。
    // 未在此列出的字段由其它模块维护，不能误清：okadd（开战增量开关）、_yunGrowth、_passiveCacheSig/Dirty 等。
    cache.harmRe = {};
    cache.penetrateHarmRe.fixed = {};
    cache.penetrateHarmRe.percent = {};
    cache.skillPass = {};
    cache.skillTypeDvup = {};
    cache.SkETypeHarmRi = {};
    cache.globalHarmRi = 0;
    cache.critHarmRi = 0;
    cache.states = cache.states || {};
    cache.states.DBHPLSteal = 1;
    cache.SvPngFd = 1;
    cache.SkEquipType = 0;
    cache.SkETypeAll = [];
    cache.damageElement = 0;
    // 元素增伤和掉率每场战斗都要能从开战时学会的羁绊里解析出来，
    // 所以每次刷新都先清空，再在下方统一解析（不再区分战斗内外）。
    cache.elementAmplify = {};
    cache.itemRateUp = 0;
    if (!_inBattle) {
        // traits 只在战斗外解析（下方仍有 !$gameParty.inBattle() 守卫）；战斗内保留战斗外构建值，不能误清。
        cache.traits = { againatk: 0, againaction: 0 };
    }
    cache.recPushStates = []; // 恢复时添加状态
    cache.pushStates = [];    // 伤害时给目标添加状态
    cache.pushSelfStates = []; // 伤害时给自己添加状态
	cache.atkk = 0;
    cache.againUse = { bySkill: {}, byType: { Zj: 0, Mf: 0 }, all: 0 };
    cache.critPush = { bySkill: {}, byType: { Zj: 0, Mf: 0 }, all: 0 };
    cache.consumeReduce = { bySkill: {}, byType: { Zj: 0, Mf: 0 }, all: 0 };
    cache.certainHit = { global: false, bySkill: {} };
    // 解析顺序：装备 -> 技能 -> 状态
    const objects = this.equips().concat(this.skills(), this.states()).filter(Boolean);

    objects.forEach(obj => {
        const meta = obj.meta || {};
        const note = obj.note || {};
		
		// 解析图像放大
		if (meta.SvPngFd) {
            const match = /(\d+)/.exec(meta.SvPngFd);
            if (match) {
                this._passiveCache.SvPngFd = Number(match[1]);
            }
        }
        // 1. 解析 passiveELUP 标签 (技能被动)
        for (const key in meta) {
            if (key.startsWith("passiveELUP")) {
                const elementIdStr = key.replace("passiveELUP", "");
                // 移除前导零并转换为数字
                const elementId = parseInt(elementIdStr.replace(/^0+/, ''), 10);
                const valueStr = meta[key].trim();
                
                // 提取数字值 (如 "6%" -> 6)
                const match = /([+-]?\d+(?:\.\d+)?)/.exec(valueStr);
                if (match && !isNaN(elementId)) {
                    const value = Number(match[1]);
                    if (!cache.elementAmplify[elementId]) {
                        cache.elementAmplify[elementId] = 0;
                    }
                    cache.elementAmplify[elementId] += value;
                }
            }
        }
		// 1. 解析traits参数
        if (obj.traits && !$gameParty.inBattle()) {
            obj.traits.forEach(trait => {
                if (trait.code === 34) {
                    cache.traits.againatk += trait.value;
                } else if (trait.code === 61) {
                    cache.traits.againaction += trait.value;
                }
            });
        }
        
        // 2. 解析passiveAPLUS标签
        if (meta.passiveAPLUS && !$gameParty.inBattle()) {
            const value = meta.passiveAPLUS.trim();
            const numValue = parseFloat(value.replace("%", ""));
            
            if (!isNaN(numValue)) {
                cache.traits.againaction += numValue / 100;
            }
        }
		// 2. 解析 Element Amplify 标签 (装备被动)
        for (const key in meta) {
            if (key.startsWith("Element Amplify ")) {
                // 提取元素ID (如 "Element Amplify 11" -> 11)
                const elementIdMatch = /Element Amplify (\d+)/.exec(key);
                if (elementIdMatch) {
                    const elementId = parseInt(elementIdMatch[1], 10);
                    const valueStr = meta[key].trim();
                    
                    // 提取百分比值 (如 "+300%" -> 300)
                    const valueMatch = /([+-]?\d+(?:\.\d+)?)%/.exec(valueStr);
                    if (valueMatch && !isNaN(elementId)) {
                        const value = Number(valueMatch[1]);
                        if (!cache.elementAmplify[elementId]) {
                            cache.elementAmplify[elementId] = 0;
                        }
                        cache.elementAmplify[elementId] += value;
                    }
                }
            }
        }
		
		// 3. 解析 passiveIRUP 标签
        if (meta.passiveIRUP) {
            const value = parseFloat(meta.passiveIRUP);
            if (!isNaN(value)) {
                cache.itemRateUp += value;
            }
        }
        // 1. 解析元素减伤 passiveHarmReXX
		const regexPassiveHarmRe = /<passiveHarmRe(\d+):\s*([\d.]+)>/g;
        let matchPassiveHarmRe;
        while ((matchPassiveHarmRe = regexPassiveHarmRe.exec(note)) !== null) {
            const elementId = parseInt(matchPassiveHarmRe[1], 10);
            const numValue = parseFloat(matchPassiveHarmRe[2]);
            
            if (!isNaN(elementId) && !isNaN(numValue)) {
                cache.harmRe[elementId] = (cache.harmRe[elementId] || 0) + numValue;
            }
        }
		
        // for (let i = 0; i < $dataSystem.elements.length; i++) {
            // const key = `passiveHarmRe${('0' + i).slice(-2)}`;
            // if (meta[key]) {
                // const match = /(\d+)/.exec(meta[key]);
                // if (match) {
                    // cache.harmRe[i] = (cache.harmRe[i] || 0) + Number(match[1]);
                // }
            // }
        
        
		// 解析穿透 DepassiveHarmReXX / DepassiveHarmRe（无元素 ID = 全部元素生效）。
        // 同一对象 note 内“完全相同”的标签只计一次；不同对象、不同数值仍累加（v0.51）。
        parseDepassiveHarmRe(note, cache.penetrateHarmRe.percent, cache.penetrateHarmRe.fixed);

        // 2. 解析技能加伤 SkillPassXXXX
        for (const key in meta) {
            if (key.startsWith("SkillPass")) {
                const skillId = Number(key.replace("SkillPass", ""));
                const value = meta[key].trim();
                const isPercent = value.includes("%");
                const numValue = parseFloat(value);
                
                if (!isNaN(numValue)) {
                    cache.skillPass[skillId] = cache.skillPass[skillId] || { rate: 0, flat: 0 };
                    
                    if (isPercent) {
                        cache.skillPass[skillId].rate += numValue / 100;
                    } else {
                        cache.skillPass[skillId].flat += numValue;
                    }
                }
            }
        }
        
        // 3. 解析技能类型加伤 SkillTypesDvupX
		const regexSkillTypesDvup = /<SkillTypesDvup([A-Za-z]+):\s*([\d.]+%?)>/g;
        let matchSkillTypesDvup;
        while ((matchSkillTypesDvup = regexSkillTypesDvup.exec(note)) !== null) {
            const type = matchSkillTypesDvup[1]; // 获取类型字母（A、B、C等）
            const value = matchSkillTypesDvup[2];
            const numValue = parseFloat(value.replace("%", ""));
            
            if (!isNaN(numValue)) {
                cache.skillTypeDvup[type] = 
                    (cache.skillTypeDvup[type] || 0) + numValue / 100;
            }
        }
		
        // for (const key in meta) {
            // if (key.startsWith("SkillTypesDvup")) {
                // const type = key.replace("SkillTypesDvup", "");
                // const value = meta[key].trim();
                // const numValue = parseFloat(value.replace("%", ""));
                
                // if (!isNaN(numValue)) {
                    // cache.skillTypeDvup[type] = (cache.skillTypeDvup[type] || 0) + numValue / 100;
                // }
            // }
        // }
        
		// 解析装备类型加伤
		const regexSkETypeHarmRi = /<SkETypeHarmRi(\d+):\s*([\d.]+%?)>/g;
        let matchSkETypeHarmRi;
        while ((matchSkETypeHarmRi = regexSkETypeHarmRi.exec(note)) !== null) {
            const typeId = parseInt(matchSkETypeHarmRi[1], 10);
            const value = matchSkETypeHarmRi[2];
            const numValue = parseFloat(value);
            
            if (!isNaN(numValue) && !isNaN(typeId)) {
                // 存储为百分比数值，例如50%存为0.5
                const percentValue = numValue / 100;
                if (!cache.SkETypeHarmRi[typeId]) cache.SkETypeHarmRi[typeId] = 0;
                cache.SkETypeHarmRi[typeId] += percentValue;
            }
        }
		
		// for (const key in meta) {
            // if (key.startsWith("SkETypeHarmRi")) {
                // const type = key.replace("SkETypeHarmRi", "");
                // const value = meta[key].trim();
                // const numValue = parseFloat(value.replace("%", ""));
                
                // if (!isNaN(numValue)) {
                    // cache.SkETypeHarmRi[type] = (cache.SkETypeHarmRi[type] || 0) + numValue / 100;
                // }
            // }
        // }
		
        // 4. 解析全局加伤 passiveHarmRi
		var re = /<passiveHarmRi:([-]?\d+(?:\.\d+)?)(%?)>/ig;
                    var match = re.exec(note);
                    while (match !== null) {
                        cache.globalHarmRi += Number(match[1]) / 100;// 加伤倍率
                        match = re.exec(note);
                    }
					
        // if (meta.passiveHarmRi) {
            // const value = meta.passiveHarmRi.trim();
            // const numValue = parseFloat(value.replace("%", ""));
            
            // if (!isNaN(numValue)) {
                // cache.globalHarmRi += numValue / 100;
            // }
        // }
        
        // 5. 解析暴击加伤 passiveCrHarmRi
		re = /<passiveCrHarmRi:([-]?\d+(?:\.\d+)?)(%?)>/ig;
		match = re.exec(note);
		while (match !== null) {
        cache.critHarmRi += Number(match[1]) / 100;
        match = re.exec(note);
    }
					
        // if (meta.passiveCrHarmRi) {
            // const value = meta.passiveCrHarmRi.trim();
            // const numValue = parseFloat(value.replace("%", ""));
            
            // if (!isNaN(numValue)) {
                // cache.critHarmRi += numValue / 100;
            // }
        // }
        
        // 6. 解析恢复效果修改 DBHPLSteal
        if (meta.DBHPLSteal) {
            const value = meta.DBHPLSteal.trim();
            const match = /(\d+)(%?)/.exec(value);
            
            if (match && match[2] === "%") {
                cache.states.DBHPLSteal *= Number(match[1]) / 100;
            }
        }
        
        // 7. 恢复时添加状态 RecPushStateXXXX
		const regexRecPushState = /<RecPushState(\d+):\s*(\d+)%?>/g;
        let matchRecPushState;
        while ((matchRecPushState = regexRecPushState.exec(note)) !== null) {
            const stateId = parseInt(matchRecPushState[1], 10);
            const probability = parseFloat(matchRecPushState[2]);
            
            if (!isNaN(probability)) {
                cache.recPushStates.push({
                    stateId: stateId,
                    probability: probability
                });
            }
        }
		
        // for (const key in meta) {
            // if (key.startsWith("RecPushState")) {
                // const stateId = Number(key.replace("RecPushState", ""));
                // const value = meta[key].trim();
                // const probability = parseFloat(value.replace("%", ""));
                
                // if (!isNaN(probability)) {
                    // cache.recPushStates.push({
                        // stateId: stateId,
                        // probability: probability
                    // });
                // }
            // }
        // }
        
        // 8. 伤害时给目标添加状态 PushStateXXXX
		const regexPushState = /<PushState(\d+):\s*(\d+)%?>/g;
        let matchPushState;
        while ((matchPushState = regexPushState.exec(note)) !== null) {
            const stateId = parseInt(matchPushState[1], 10);
            const probability = parseFloat(matchPushState[2]);
            
            if (!isNaN(probability)) {
                cache.pushStates.push({
                    stateId: stateId,
                    probability: probability
                });
            }
        }
		
        // for (const key in meta) {
            // if (key.startsWith("PushState")) {
                // const stateId = Number(key.replace("PushState", ""));
                // const value = meta[key].trim();
                // const probability = parseFloat(value.replace("%", ""));
                
                // if (!isNaN(probability)) {
                    // cache.pushStates.push({
                        // stateId: stateId,
                        // probability: probability
                    // });
                // }
            // }
        // }
        
        // 9. 伤害时给自己添加状态 PushsubStateXXXX
		const regexPushsubState = /<PushsubState(\d+):\s*(\d+)%?>/g;
        let matchPushsubState;
        while ((matchPushsubState = regexPushsubState.exec(note)) !== null) {
            const stateId = parseInt(matchPushsubState[1], 10);
            const probability = parseFloat(matchPushsubState[2]);
            
            if (!isNaN(probability)) {
                cache.pushSelfStates.push({
                    stateId: stateId,
                    probability: probability
                });
            }
        }
		
        // for (const key in meta) {
            // if (key.startsWith("PushsubState")) {
                // const stateId = Number(key.replace("PushsubState", ""));
                // const value = meta[key].trim();
                // const probability = parseFloat(value.replace("%", ""));
                
                // if (!isNaN(probability)) {
                    // cache.pushSelfStates.push({
                        // stateId: stateId,
                        // probability: probability
                    // });
                // }
            // }
        // }
        
        // 10. 技能元素覆盖 SkillElementXXXX
        // for (const key in meta) {
            // if (key.startsWith("SkillElement")) {
                // const skillId = Number(key.replace("SkillElement", ""));
                // const elementId = Number(meta[key].trim());
                
                // if (!isNaN(elementId)) {
                    // cache.skillElementOverride = cache.skillElementOverride || {};
                    // cache.skillElementOverride[skillId] = elementId;
                // }
            // }
        // }
		
		// 解析atkk标签 攻击次数
        if (meta.atkk) {
            const match = /(\d+)/.exec(meta.atkk);
            if (match) cache.atkk += parseInt(match[1], 10);
        }

        // 解析AgainUse标签 再次释放
        for (const key in meta) {
            if (key.startsWith("AgainUse")) {
                const value = parseInt(meta[key], 10);
                
                if (key === "AgainUseZj") cache.againUse.byType.Zj += value;
                else if (key === "AgainUseMf") cache.againUse.byType.Mf += value;
                else if (key === "AgainUseAll") cache.againUse.all += value;
                else if (key.startsWith("AgainUse") && !isNaN(key.substr(8))) {
                    const skillId = parseInt(key.substr(8), 10);
                    cache.againUse.bySkill[skillId] = (cache.againUse.bySkill[skillId] || 0) + value;
                }
            }
        }

        // 解析CritPush标签 暴击率
		const regexSkillCriPush = /<SkillCriPush(\w+):\s*(\d+)>/g;
        let matchSkillCriPush;
        while ((matchSkillCriPush = regexSkillCriPush.exec(note)) !== null) {
            const type = matchSkillCriPush[1];
            const numValue = parseInt(matchSkillCriPush[2], 10);
            
            if (!isNaN(numValue)) {
                if (type === 'Zj') cache.critPush.byType.Zj += numValue;
                else if (type === 'Mf') cache.critPush.byType.Mf += numValue;
                else if (type === 'All') cache.critPush.all += numValue;
            }
        }
		
        // for (const key in meta) {
            // if (key.startsWith("SkillCriPush")) {
                // const value = parseInt(meta[key], 10);
                
                // if (key === "SkillCriPushZj") cache.critPush.byType.Zj += value;
                // else if (key === "SkillCriPushMf") cache.critPush.byType.Mf += value;
                // else if (key === "SkillCriPushAll") cache.critPush.all += value;
                // else if (key.startsWith("SkillCriPush") && !isNaN(key.substr(12))) {
                    // const skillId = parseInt(key.substr(12), 10);
                    // cache.critPush.bySkill[skillId] = (cache.critPush.bySkill[skillId] || 0) + value;
                // }
            // }
        // }

        // 解析ConsumeReduce标签 消耗
        for (const key in meta) {
            if (key.startsWith("ConsumeReduce")) {
                const value = parseInt(meta[key], 10);
                
                if (key === "ConsumeReduceZj") cache.consumeReduce.byType.Zj += value;
                else if (key === "ConsumeReduceMf") cache.consumeReduce.byType.Mf += value;
                else if (key === "ConsumeReduceAll") cache.consumeReduce.all += value;
                else if (key.startsWith("ConsumeReduce") && !isNaN(key.substr(13))) {
                    const skillId = parseInt(key.substr(13), 10);
                    cache.consumeReduce.bySkill[skillId] = (cache.consumeReduce.bySkill[skillId] || 0) + value;
                }
            }
        }

        // 解析必中标签
        if (meta.SkillCertainHitss) cache.certainHit.global = true;
        
        for (const key in meta) {
            if (key.startsWith("SkillCertainHit")) {
                const skillId = parseInt(meta[key], 10);
                if (!isNaN(skillId)) cache.certainHit.bySkill[skillId] = true;
            }
        }
		
	//解析装备类型覆盖
		if (meta.SkEquipType) {
            const value = Number(meta.SkEquipType);
            if (!isNaN(value)) cache.SkEquipType = value;
        }
        
	//解析装备类型叠加
        if (meta.SkETypeAll) {
            const value = Number(meta.SkETypeAll);
            if (!isNaN(value)) cache.SkETypeAll.push(value);
        }
		
		//解析元素类型覆盖
		if (meta.DamageElements) {
        const elementId = Number(meta.DamageElements);
        if (!isNaN(value)) cache.damageElement = elementId;
		}
	});
};
//单独meta解析
function updatePassiveCache(meta, cache, isAddition) {
    if (!meta) return;
    
    const multiplier = isAddition ? 1 : -1;
	
    // 1. 元素减伤
    for (let i = 0; i < $dataSystem.elements.length; i++) {
        const key = `passiveHarmRe${('0' + i).slice(-2)}`;
        if (meta[key]) {
            const value = parseFloat(meta[key]);
            if (!isNaN(value)) {
                cache.harmRe[i] = (cache.harmRe[i] || 0) + value * multiplier;
                if (cache.harmRe[i] < 0) cache.harmRe[i] = 0;
            }
        }
    
	// 解析穿透减伤 DepassiveHarmReXX (新增)
        const penetrateKey = `DepassiveHarmRe${('0' + i).slice(-2)}`;
        if (meta[penetrateKey]) {
            const value = meta[penetrateKey].trim();
            const isPercent = value.includes("%");
            const numValue = parseFloat(value);
            
            if (!isNaN(numValue)) {
                if (isPercent) {
                    if (isAddition) {
                        cache.penetrateHarmRe.percent[i] = (cache.penetrateHarmRe.percent[i] || 0) + numValue;
                    } else {
                        cache.penetrateHarmRe.percent[i] = (cache.penetrateHarmRe.percent[i] || 0) - numValue;
                        if (cache.penetrateHarmRe.percent[i] < 0) cache.penetrateHarmRe.percent[i] = 0;
                    }
                } else {
                    if (isAddition) {
                        cache.penetrateHarmRe.fixed[i] = (cache.penetrateHarmRe.fixed[i] || 0) + numValue;
                    } else {
                        cache.penetrateHarmRe.fixed[i] = (cache.penetrateHarmRe.fixed[i] || 0) - numValue;
                        if (cache.penetrateHarmRe.fixed[i] < 0) cache.penetrateHarmRe.fixed[i] = 0;
                    }
                }
            }
        }
	}
    // 解析图像放大
		if (meta.SvPngFd) {
            const match = /(\d+)/.exec(meta.SvPngFd);
            if (match) {
                cache.SvPngFd = Number(match[1]);
            }
        }
		
    // 2. 全局加伤
    if (meta.passiveHarmRi) {
        const value = parseFloat(meta.passiveHarmRi);
        if (!isNaN(value)) {
            cache.globalHarmRi += (value / 100) * multiplier;
            if (cache.globalHarmRi < 0) cache.globalHarmRi = 0;
        }
    }
    
    // 3. 暴击加伤
    if (meta.passiveCrHarmRi) {
        const value = parseFloat(meta.passiveCrHarmRi);
        if (!isNaN(value)) {
            cache.critHarmRi += (value / 100) * multiplier;
            if (cache.critHarmRi < 0) cache.critHarmRi = 0;
        }
    }
	
    // 解析装备类型加伤
		for (const key in meta) {
            if (key.startsWith("SkETypeHarmRi")) {
                const type = key.replace("SkETypeHarmRi", "");
                const value = meta[key].trim();
                const numValue = parseFloat(value.replace("%", ""));
                
                if (!isNaN(numValue)) {
                    cache.SkETypeHarmRi[type] = (cache.SkETypeHarmRi[type] || 0) + numValue / 100;
                }
            }
        }
		
    // 4. 恢复效果修改
    if (meta.DBHPLSteal) {
        const match = /(\d+)(%?)/.exec(meta.DBHPLSteal);
        if (match && match[2] === "%") {
            if (isAddition) {
                cache.states.DBHPLSteal *= Number(match[1]) / 100;
            } else {
                // 恢复效果修改不可逆，重置为1
                cache.states.DBHPLSteal = 1;
            }
        }
    }
    
    // 5. 技能加伤
    for (const key in meta) {
        if (key.startsWith("SkillPass")) {
            const skillId = Number(key.replace("SkillPass", ""));
            const value = meta[key].trim();
            const isPercent = value.includes("%");
            const numValue = parseFloat(value);
            
            if (!isNaN(numValue)) {
                cache.skillPass[skillId] = cache.skillPass[skillId] || { rate: 0, flat: 0 };
                
                if (isPercent) {
                    cache.skillPass[skillId].rate += (numValue / 100) * multiplier;
                    if (cache.skillPass[skillId].rate < 0) cache.skillPass[skillId].rate = 0;
                } else {
                    cache.skillPass[skillId].flat += numValue * multiplier;
                    if (cache.skillPass[skillId].flat < 0) cache.skillPass[skillId].flat = 0;
                }
            }
        }
    }
    
    // 6. 技能类型加伤
    for (const key in meta) {
        if (key.startsWith("SkillTypesDvup")) {
            const type = key.replace("SkillTypesDvup", "");
            const value = meta[key].trim();
            const numValue = parseFloat(value.replace("%", ""));
            
            if (!isNaN(numValue)) {
                cache.skillTypeDvup[type] = (cache.skillTypeDvup[type] || 0) + (numValue / 100) * multiplier;
                if (cache.skillTypeDvup[type] < 0) cache.skillTypeDvup[type] = 0;
            }
        }
    }
    
    // 7. 状态添加效果
    const updateStateEffects = (stateId, probability, array) => {
        if (isAddition) {
            array.push({
                stateId: stateId,
                probability: probability
            });
        } else {
            // 移除匹配的状态效果
            for (let i = array.length - 1; i >= 0; i--) {
                if (array[i].stateId === stateId) {
                    array.splice(i, 1);
                    break;
                }
            }
        }
    };
    
    // 恢复时添加状态
    for (const key in meta) {
        if (key.startsWith("RecPushState")) {
            const stateId = Number(key.replace("RecPushState", ""));
            const value = meta[key].trim();
            const probability = parseFloat(value.replace("%", ""));
            
            if (!isNaN(probability)) {
                updateStateEffects(stateId, probability, cache.recPushStates);
            }
        }
    }
    
    // 伤害时给目标添加状态
    for (const key in meta) {
        if (key.startsWith("PushState")) {
            const stateId = Number(key.replace("PushState", ""));
            const value = meta[key].trim();
            const probability = parseFloat(value.replace("%", ""));
            
            if (!isNaN(probability)) {
                updateStateEffects(stateId, probability, cache.pushStates);
            }
        }
    }
    
    // 伤害时给自己添加状态
    for (const key in meta) {
        if (key.startsWith("PushsubState")) {
            const stateId = Number(key.replace("PushsubState", ""));
            const value = meta[key].trim();
            const probability = parseFloat(value.replace("%", ""));
            
            if (!isNaN(probability)) {
                updateStateEffects(stateId, probability, cache.pushSelfStates);
            }
        }
    }
    // 更新atkk 攻击次数
    if (meta.atkk) {
        const match = /(\d+)/.exec(meta.atkk);
        if (match) cache.atkk += parseInt(match[1], 10) * multiplier;
    }
    
    // 更新AgainUse 再次释放
    for (const key in meta) {
        if (key.startsWith("AgainUse")) {
            const value = parseInt(meta[key], 10) * multiplier;
            
            if (key === "AgainUseZj") cache.againUse.byType.Zj += value;
            else if (key === "AgainUseMf") cache.againUse.byType.Mf += value;
            else if (key === "AgainUseAll") cache.againUse.all += value;
            else if (key.startsWith("AgainUse") && !isNaN(key.substr(8))) {
                const skillId = parseInt(key.substr(8), 10);
                if (!cache.againUse.bySkill[skillId]) cache.againUse.bySkill[skillId] = 0;
                cache.againUse.bySkill[skillId] += value;
            }
        }
    }
    
    // 更新CritPush 暴击率
    for (const key in meta) {
        if (key.startsWith("SkillCriPush")) {
            const value = parseInt(meta[key], 10) * multiplier;
            
            if (key === "SkillCriPushZj") cache.critPush.byType.Zj += value;
            else if (key === "SkillCriPushMf") cache.critPush.byType.Mf += value;
            else if (key === "SkillCriPushAll") cache.critPush.all += value;
            else if (key.startsWith("SkillCriPush") && !isNaN(key.substr(12))) {
                const skillId = parseInt(key.substr(12), 10);
                if (!cache.critPush.bySkill[skillId]) cache.critPush.bySkill[skillId] = 0;
                cache.critPush.bySkill[skillId] += value;
            }
        }
    }
    
    // 更新ConsumeReduce 消耗
    for (const key in meta) {
        if (key.startsWith("ConsumeReduce")) {
            const value = parseInt(meta[key], 10) * multiplier;
            
            if (key === "ConsumeReduceZj") cache.consumeReduce.byType.Zj += value;
            else if (key === "ConsumeReduceMf") cache.consumeReduce.byType.Mf += value;
            else if (key === "ConsumeReduceAll") cache.consumeReduce.all += value;
            else if (key.startsWith("ConsumeReduce") && !isNaN(key.substr(13))) {
                const skillId = parseInt(key.substr(13), 10);
                if (!cache.consumeReduce.bySkill[skillId]) cache.consumeReduce.bySkill[skillId] = 0;
                cache.consumeReduce.bySkill[skillId] += value;
            }
        }
    }
    
    // 更新必中标签
    if (meta.SkillCertainHitss) cache.certainHit.global = isAddition;
    
    for (const key in meta) {
        if (key.startsWith("SkillCertainHit")) {
            const skillId = parseInt(meta[key], 10);
            if (!isNaN(skillId)) cache.certainHit.bySkill[skillId] = isAddition;
        }
    }
	//解析装备类型覆盖
	if (meta.SkEquipType) {
            const value = Number(meta.SkEquipType);
            if (!isNaN(value)) cache.SkEquipType = value;
        }
		
	//解析装备类型叠加
        if (meta.SkETypeAll) {
            const value = Number(meta.SkETypeAll);
            if (!isNaN(value)) cache.SkETypeAll.push(value);
        }
    // 8. 技能元素覆盖
    // for (const key in meta) {
        // if (key.startsWith("SkillElement")) {
            // const skillId = Number(key.replace("SkillElement", ""));
            // const elementId = Number(meta[key].trim());
            
            // if (!isNaN(elementId)) {
                // if (isAddition) {
                    // cache.skillElementOverride = cache.skillElementOverride || {};
                    // cache.skillElementOverride[skillId] = elementId;
                // } else {
                    // if (cache.skillElementOverride && cache.skillElementOverride[skillId]) {
                        // delete cache.skillElementOverride[skillId];
                    // }
                // }
            // }
        // }
    // }
}


//【DeepSeek·未经Codex/Claude检验】v0.51 被动缓存生命周期：
// 状态/装备/技能变化只置脏；在下一次 refresh / 伤害结算 / 状态面板读取前按签名惰性重建一次，
// 避免旧实现“add 后判断 !isStateAffected”永不生效、remove 被旧链绕过、以及每次变化全量重算。
function passiveCacheSignature(battler) {
    var parts = [];
    try {
        if (battler._states) parts.push('S' + battler._states.join(','));
        if (battler._skills) parts.push('K' + battler._skills.join(','));
        if (typeof battler.equips === 'function') {
            var eq = battler.equips() || [];
            parts.push('E' + eq.map(function (item) {
                return item ? ((item.baseItemId || item.id) + ':' + (item.note ? item.note.length : 0)) : '0';
            }).join(','));
        }
        if (typeof battler.enemyId === 'function') parts.push('N' + battler.enemyId());
    } catch (e) { /* 预览副本等特殊情况忽略 */ }
    return parts.join('|');
}
function markPassiveCacheDirty(battler) {
    if (battler && battler._passiveCache) battler._passiveCacheDirty = true;
}
// krz/GT 等插件给 states() 做了缓存；直接改 _states 后必须让缓存失效，否则重建读到旧状态列表（穿透不生效）。
function invalidateBattlerStateCache(battler) {
    if (!battler) return;
    battler._statescache2 = undefined;
    battler.need_refresh_states = true;
    battler._basestatecache = undefined;
    battler.need_refresh_basestates = true;
    battler._passiveStatesRaw = undefined;
    battler.need_refresh_passiveStates = true;
    battler._statelist = undefined;
    battler.need_refreshstatelist = undefined;
}
function recordPassiveCacheSignature(battler) {
    if (!battler || !battler._passiveCache) return;
    battler._passiveCacheSig = passiveCacheSignature(battler);
    battler._passiveCacheDirty = false;
}
function ensurePassiveCacheUpToDate(battler) {
    if (!battler || !battler._passiveCache || typeof battler.refreshPassiveCache !== 'function') return;
    if (!battler._passiveCacheDirty) return; // 热路径：绝大多数 refresh 调用直接返回
    // 开战构建阶段由 Scene_Battle.start 最后统一 refresh；此时不重复重建。
    if (battler.isActor && battler.isActor() && $gameParty.inBattle() && !battler._passiveCache.okadd) return;
    if (battler._passiveCacheSig === passiveCacheSignature(battler)) {
        battler._passiveCacheDirty = false;
        return;
    }
    invalidateBattlerStateCache(battler);
    battler.refreshPassiveCache();
}

var _Game_Battler_addState = Game_Battler.prototype.addState;
    Game_Battler.prototype.addState = function(stateId) {
        var _wasAffected = this.isStateAffected(stateId);
        markPassiveCacheDirty(this); // 先置脏：原生 addState 内部的 refresh 会按新状态重建
        _Game_Battler_addState.call(this, stateId);
        if (!_wasAffected && this.isStateAffected(stateId)) ensurePassiveCacheUpToDate(this);
    };

var _Game_Battler_removeState = Game_Battler.prototype.removeState;
Game_Battler.prototype.removeState = function(stateId) {
    var _wasAffected = this.isStateAffected(stateId);
    if (_wasAffected) markPassiveCacheDirty(this);
    var out = _Game_Battler_removeState.apply(this, arguments);
    if (_wasAffected && !this.isStateAffected(stateId)) ensurePassiveCacheUpToDate(this);
    return out;
};
// krz_state_re 先于本插件加载，Game_Actor.removeState 走加载时捕获的旧链；这里补一层确保移除后重建。
var _Game_Actor_removeState = Game_Actor.prototype.removeState;
Game_Actor.prototype.removeState = function(stateId) {
    var _wasAffected = this.isStateAffected(stateId);
    if (_wasAffected) markPassiveCacheDirty(this);
    var out = _Game_Actor_removeState.apply(this, arguments);
    if (_wasAffected && !this.isStateAffected(stateId)) ensurePassiveCacheUpToDate(this);
    return out;
};

var _Game_BattlerBase_eraseState = Game_BattlerBase.prototype.eraseState;
Game_BattlerBase.prototype.eraseState = function(stateId) {
    if (this.isStateAffected(stateId)) markPassiveCacheDirty(this);
    return _Game_BattlerBase_eraseState.apply(this, arguments);
};

var _Game_BattlerBase_clearStates = Game_BattlerBase.prototype.clearStates;
Game_BattlerBase.prototype.clearStates = function() {
    markPassiveCacheDirty(this);
    var out = _Game_BattlerBase_clearStates.apply(this, arguments);
    ensurePassiveCacheUpToDate(this);
    return out;
};

if (typeof Game_Battler.prototype.removeStateCompletely === 'function') {
    var _Game_Battler_removeStateCompletely = Game_Battler.prototype.removeStateCompletely;
    Game_Battler.prototype.removeStateCompletely = function(stateId) {
        var _wasAffected = this.isStateAffected(stateId);
        markPassiveCacheDirty(this);
        var out = _Game_Battler_removeStateCompletely.apply(this, arguments);
        if (_wasAffected) ensurePassiveCacheUpToDate(this);
        return out;
    };
}

var _Game_Battler_refresh = Game_Battler.prototype.refresh;
Game_Battler.prototype.refresh = function() {
    var out = _Game_Battler_refresh.apply(this, arguments);
    ensurePassiveCacheUpToDate(this);
    return out;
};

// 装备/技能变化：先置脏，再尝试立即重建（战斗中换装/学技能由各角色模块触发，次数少）。
['changeEquip', 'forceChangeEquip', 'discardEquip', 'learnSkill', 'forgetSkill'].forEach(function (name) {
    var old = Game_Actor.prototype[name];
    if (typeof old !== 'function') return;
    Game_Actor.prototype[name] = function() {
        markPassiveCacheDirty(this);
        var out = old.apply(this, arguments);
        ensurePassiveCacheUpToDate(this);
        return out;
    };
});

	// 状态添加处理器
	// 【DeepSeek·未经Codex/Claude检验】v0.50：兼容两种标签写法，并拒绝非法状态 ID。
	//   <Tag1331: 100%>  规范写法：状态 ID 写在键里，值里是概率（现有装备/技能都这样写）
	//   <Tag: 1331>      兼容写法：状态 ID 写在值里，概率缺省 100%
	// 解析不出合法状态 ID 时只警告并跳过，绝不把 0/NaN 传给 addState
	// （$dataStates[0] 为 null，会崩在 Star_StateBook 等读取 state.meta 的地方）。
	const processStateTags = function(actor, tagPrefix, callback) {
    // 获取所有可能包含状态标签的对象
    const objects = actor.equips().concat(actor.skills()).filter(Boolean);
    const stateTable = (typeof $dataStates !== 'undefined' && $dataStates) || [];

    objects.forEach(obj => {
        const meta = obj.meta || {};

        // 遍历所有 meta 键
        for (const key in meta) {
            // 检查键名前缀是否匹配
            if (!key.startsWith(tagPrefix)) continue;

            const rawValue = meta[key];
            const keyRest = key.slice(tagPrefix.length).trim();
            let stateId = NaN;
            let probability = NaN;

            if (/^\d+$/.test(keyRest)) {
                // <Tag1331: 100%>：状态 ID 在键里，值里是概率
                stateId = Number(keyRest);
                if (typeof rawValue === 'string') {
                    probability = parseFloat(rawValue.replace('%', '').trim());
                }
            } else if (keyRest === '') {
                // <Tag: 1331>：状态 ID 在值里，概率缺省 100%
                const text = (typeof rawValue === 'string') ? rawValue.trim() : '';
                const match = /^(\d+)(?:\s*[:：]\s*(\d+(?:\.\d+)?)\s*%?)?$/.exec(text);
                if (match) {
                    stateId = Number(match[1]);
                    if (match[2] !== undefined) probability = parseFloat(match[2]);
                }
            }

            // 空概率/非法概率按 100% 处理（与原有"写了标签就附加"的行为一致）
            if (isNaN(probability)) probability = 100;

            if (!Number.isInteger(stateId) || stateId <= 0 || !stateTable[stateId]) {
                console.warn('[dsPassiveSkill] 忽略无效状态标签 <' + key + ': ' + String(rawValue).trim() +
                    '>：状态 ID ' + stateId + ' 不存在或非法');
                continue;
            }

            callback(stateId, probability);
        }
    });
};
    // 优化后的战斗开始处理
const DsScene_Battle_prototype_start = Scene_Battle.prototype.start;
Scene_Battle.prototype.start = function() {
    DsScene_Battle_prototype_start.call(this);
    // 第一阶段：处理装备和技能上的状态添加标签
    $gameParty.battleMembers().forEach(actorId => {
        const actor = actorId;
        if (!actor) return;
        
		// 重置缓存
		actor.initPassiveCache();
        // 为自己添加状态
        processStateTags(actor, "StartPushState", (stateId, probability) => {
            if (Math.random() * 100 < probability) {
                actor.addState(stateId);
            }
        });
		
		// 为随机队友添加状态
        processStateTags(actor, "StartRomActPushState", (stateId, probability) => {
            if (Math.random() * 100 < probability) {
                const members = $gameParty.battleMembers().filter(id => id !== actor);
                if (members.length > 0) {
                    const target = members[Math.floor(Math.random() * members.length)];
                    target.addState(stateId);
                }
            }
        });
        
        // 为随机敌人添加状态
        processStateTags(actor, "StartRomEmePushState", (stateId, probability) => {
            if (Math.random() * 100 < probability && $gameTroop.aliveMembers().length > 0) {
                const target = $gameTroop.aliveMembers()[Math.floor(Math.random() * $gameTroop.aliveMembers().length)];
                target.addState(stateId);
            }
        });
		
		// 为随机目标加状态
        processStateTags(actor, "StartRomPushState", (stateId, probability) => {
            if (Math.random() * 100 < probability) {
                const allTargets = $gameParty.battleMembers().map(actor => actor)
                    .concat($gameTroop.aliveMembers());
                if (allTargets.length > 0) {
                    const target = allTargets[Math.floor(Math.random() * allTargets.length)];
                    target.addState(stateId);
                }
            }
        });
        
        // 为所有敌人添加状态
        processStateTags(actor, "StartAEPushState", (stateId, probability) => {
            if (Math.random() * 100 < probability) {
                $gameTroop.aliveMembers().forEach(enemy => enemy.addState(stateId));
            }
        });
    
        // 为全队添加状态
        processStateTags(actor, "StartWTPushState", (stateId, probability) => {
            if (Math.random() * 100 < probability) {
                $gameParty.battleMembers().forEach(actor => {
                    actor.addState(stateId);
                });
            }
        });
		actor._passiveCache.okadd = true;
	});
    // 第二阶段：刷新所有角色的缓存（包括新添加的状态）
    $gameParty.battleMembers().forEach(actorId => {
        if (actorId) actorId.refreshPassiveCache();
    });
	// 初始化所有敌人的被动缓存
    $gameTroop.members().forEach(enemy => {
        if (enemy) enemy.refreshPassiveCache();
    });
}
// 在Game_Enemy类中添加被动缓存
Game_Enemy.prototype.initPassiveCache = function() {
    this._passiveCache = {
        harmRe: {},          // 元素减伤
        penetrateHarmRe: {   // 穿透减伤
            fixed: {},
            percent: {}
        }
    };
};

Game_Enemy.prototype.refreshPassiveCache = function() {
    this.initPassiveCache();
    if (typeof invalidateBattlerStateCache === 'function') invalidateBattlerStateCache(this);
    const cache = this._passiveCache;
    
    // 解析技能中的标签
    this.skills().forEach(skill => {
        if (skill) this.parsePassiveTags(skill.note, cache);
    });
    
    // 解析状态中的标签
    this.states().forEach(state => {
        if (state) this.parsePassiveTags(state.note, cache);
    });
};

// 解析标签的通用方法
Game_Enemy.prototype.parsePassiveTags = function(note, cache) {
    // 解析 passiveHarmReXX 标签
    const regexHarmRe = /<passiveHarmRe(\d+):\s*([\d.]+)>/g;
    let match;
    while ((match = regexHarmRe.exec(note)) !== null) {
        const elementId = parseInt(match[1], 10);
        const value = parseFloat(match[2]);
        if (!isNaN(elementId) && !isNaN(value)) {
            cache.harmRe[elementId] = (cache.harmRe[elementId] || 0) + value;
        }
    }
    
    // 解析 DepassiveHarmReXX 标签
    // const regexPenetrate = /<DepassiveHarmRe(\d+):\s*([\d.]+%?)>/g;
    // while ((match = regexPenetrate.exec(note)) !== null) {
        // const elementId = parseInt(match[1], 10);
        // const value = match[2];
        // const isPercent = value.includes('%');
        // const numValue = parseFloat(value);
        
        // if (!isNaN(elementId) && !isNaN(numValue)) {
            // if (isPercent) {
                // cache.penetrateHarmRe.percent[elementId] = 
                    // (cache.penetrateHarmRe.percent[elementId] || 0) + numValue;
            // } else {
                // cache.penetrateHarmRe.fixed[elementId] = 
                    // (cache.penetrateHarmRe.fixed[elementId] || 0) + numValue;
            // }
        // }
    // }
};

//【DeepSeek·未经Codex/Claude检验】v0.51：穿透标签解析（无元素ID=全部元素；支持负值；同对象重复标签只计一次）
function depassiveAllElements() {
    // 与伤害端实际活跃元素同口径：[1..9, 11..15]；排除 10（治疗）与无名称元素。
    var out = [];
    var n = ($dataSystem && $dataSystem.elements) ? $dataSystem.elements.length : 16;
    for (var i = 1; i < n; i++) {
        if (i === 10) continue;
        if (!$dataSystem.elements[i]) continue;
        out.push(i);
    }
    if (!out.length) out = [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15];
    return out;
}
function parseDepassiveHarmRe(note, percentMap, fixedMap) {
    if (!note || typeof note !== 'string') return;
    // 【Claude·未经Codex检验】v0.57：无元素编号的 <DepassiveHarmRe: X%> 不再生效（原数据是说明数值的20倍，已在数据里改成分元素标签）。
    const re = /<DepassiveHarmRe(\d+):\s*([+-]?[\d.]+%?)>/g;
    const seen = {};
    let m;
    while ((m = re.exec(note)) !== null) {
        const idText = m[1];
        const valueText = m[2];
        const key = (idText === '' ? 'ALL' : String(parseInt(idText, 10))) + '|' + valueText;
        if (seen[key]) continue; // 同一对象内完全相同标签只计一次
        seen[key] = 1;
        const numValue = parseFloat(valueText);
        if (!isFinite(numValue)) continue;
        const isPercent = valueText.indexOf('%') >= 0;
        const elements = idText === '' ? depassiveAllElements() : [parseInt(idText, 10)];
        for (let i = 0; i < elements.length; i++) {
            const e = elements[i];
            if (!isFinite(e)) continue;
            if (isPercent) percentMap[e] = (percentMap[e] || 0) + numValue;
            else fixedMap[e] = (fixedMap[e] || 0) + numValue;
        }
    }
}

// 记录刷新签名：任何一次 refreshPassiveCache 都视为“已与当前装备/技能/状态一致”。
[Game_Actor, Game_Enemy].forEach(function (Type) {
    var old = Type.prototype.refreshPassiveCache;
    if (typeof old !== 'function') return;
    Type.prototype.refreshPassiveCache = function() {
        var out = old.apply(this, arguments);
        recordPassiveCacheSignature(this);
        return out;
    };
});

    // 增加攻击次数
    var _Game_Action_prototype_numRepeats = Game_Action.prototype.numRepeats;
    Game_Action.prototype.numRepeats = function () {
        const repeats = _Game_Action_prototype_numRepeats.call(this);
    const subject = this.subject();
    const item = this.item();
    if (!item || !subject._passiveCache) return repeats;
	let totalRepeats = subject._passiveCache.atkk ? repeats + subject._passiveCache.atkk : repeats;
    let againCan = 0;
    if (subject._passiveCache.againUse) {
        const againUse = subject._passiveCache.againUse;
        
        // 特定技能再次使用概率
        if (againUse.bySkill[item.id]) {
            againCan += againUse.bySkill[item.id];
        }
        
        // 按类型增加的再次使用概率
        const stypeId = item.stypeId;
        if (stypeId === 1) againCan += againUse.byType.Zj; // 战技
        else if (stypeId === 2) againCan += againUse.byType.Mf; // 魔法
        
        // 全局再次使用概率
        againCan += againUse.all;
    }
    
    // 概率判定是否增加一次行动
    if (Math.random() * 100 < againCan) {
        totalRepeats += 1;
    }
    
    return Math.floor(totalRepeats);
};

	//暴击修改
    var _Game_Action_prototype_itemCri = Game_Action.prototype.itemCri;
	Game_Action.prototype.itemCri = function(target) {
    const subject = this.subject();
    const item = this.item();
    if (!item.damage.critical) return 0;
    let critPush = 0;
	if(subject.isActor()){
    if (subject._passiveCache.critPush) {
        const critCache = subject._passiveCache.critPush;
        //特定技能暴击率增加
        if (critCache.bySkill[item.id]) {
            critPush += critCache.bySkill[item.id] / 100;
        }
        //按类型暴击率增加
        const stypeId = item.stypeId;
        if (stypeId === 1) critPush += critCache.byType.Zj / 100; // 战技
        else if (stypeId === 2) critPush += critCache.byType.Mf / 100; // 魔法
        //全局暴击率增加
        critPush += critCache.all / 100;
    }
	return (subject.cri + critPush) * (1 - target.cev);
	} else {
		return this.item().damage.critical ? (subject.cri + critPush) * (1 - target.cev) : 0;
	}
};
    
	//技能MP消耗修改
    var _Game_BattlerBase_prototype_skillMpCost = Game_BattlerBase.prototype.skillMpCost;
	Game_BattlerBase.prototype.skillMpCost = function(skill) {
    const baseCost = _Game_BattlerBase_prototype_skillMpCost.call(this, skill);
    if (!this.isActor() || !this._passiveCache) return baseCost;
    
    let reducePercent = 0;
    
    if (this._passiveCache.consumeReduce) {
        const consumeCache = this._passiveCache.consumeReduce;
        
        // 特定技能消耗减少
        if (consumeCache.bySkill[skill.id]) {
            reducePercent += consumeCache.bySkill[skill.id];
        }
        
        // 按类型消耗减少
        const stypeId = skill.stypeId;
        if (stypeId === 1) reducePercent += consumeCache.byType.Zj; // 战技
        else if (stypeId === 2) reducePercent += consumeCache.byType.Mf; // 魔法
        
        // 全局消耗减少
        reducePercent += consumeCache.all;
    }
    
    // 确保减少百分比不超过100%
    reducePercent = Math.min(reducePercent, 100);
    return Math.floor(baseCost * (1 - reducePercent / 100));
};
    
	//技能TP消耗修改
    var _Game_BattlerBase_prototype_skillTpCost = Game_BattlerBase.prototype.skillTpCost;
	Game_BattlerBase.prototype.skillTpCost = function(skill) {
    const baseCost = _Game_BattlerBase_prototype_skillTpCost.call(this, skill);
    if (!this.isActor() || !this._passiveCache) return baseCost;
    
    let reducePercent = 0;
    
    if (this._passiveCache.consumeReduce) {
        const consumeCache = this._passiveCache.consumeReduce;
        
        // 特定技能消耗减少
        if (consumeCache.bySkill[skill.id]) {
            reducePercent += consumeCache.bySkill[skill.id];
        }
        
        // 按类型消耗减少
        const stypeId = skill.stypeId;
        if (stypeId === 1) reducePercent += consumeCache.byType.Zj; // 战技
        else if (stypeId === 2) reducePercent += consumeCache.byType.Mf; // 魔法
        
        // 全局消耗减少
        reducePercent += consumeCache.all;
    }
    
    // 确保减少百分比不超过100%
    reducePercent = Math.min(reducePercent, 100);
    return Math.floor(baseCost * (1 - reducePercent / 100));
};

    // 技能命中更改
    const _Game_Action_prototype_itemHit = Game_Action.prototype.itemHit;
	Game_Action.prototype.itemHit = function(target) {
    const subject = this.subject();
    const item = this.item();
    
    // 全局必中或特定技能必中
    if (this.subject().isActor() && subject._passiveCache?.certainHit) {
        const certainHit = subject._passiveCache.certainHit;
        if (certainHit.global || certainHit.bySkill[item.id]) {
            return 1;
        }
    }
    
    return _Game_Action_prototype_itemHit.call(this, target);
};

    var _Game_Action_prototype_itemCnt = Game_Action.prototype.itemCnt;
	Game_Action.prototype.itemCnt = function(target) {
    const subject = this.subject();
    const item = this.item();
    
    // 全局必中或特定技能必中
    if (this.subject().isActor() && subject._passiveCache?.certainHit) {
        const certainHit = subject._passiveCache.certainHit;
        if (certainHit.global || certainHit.bySkill[item.id]) {
            return 0;
        }
    }
    
    return _Game_Action_prototype_itemCnt.call(this, target);
};
    
    var _Game_Action_prototype_itemMrf = Game_Action.prototype.itemMrf;
   Game_Action.prototype.itemMrf = function(target) {
    const subject = this.subject();
    const item = this.item();
    
    // 全局必中或特定技能必中
    if (this.subject().isActor() && subject._passiveCache?.certainHit) {
        const certainHit = subject._passiveCache.certainHit;
        if (certainHit.global || certainHit.bySkill[item.id]) {
            return 0;
        }
    }
    
    return _Game_Action_prototype_itemMrf.call(this, target);
};

	//伤害计算流程
    var _Game_Action_prototype_makeDamageValue = Game_Action.prototype.makeDamageValue;
    Game_Action.prototype.makeDamageValue = function(target, critical) {
    Star.dsPassiveSkill.GetAction = this;
    const item = this.item();
    const subject = this.subject();
    const originalElement = item.damage.elementId;
    const isActorSubject = subject.isActor();
    const isDamageType = item.damage.type === 1;
    const isHealType = item.damage.type === 3;
    if (isActorSubject && isDamageType) {
        // 从缓存获取元素修改
        const cache = subject._passiveCache;
        if (cache.damageElement != 0) {
            item.damage.elementId = cache.damageElement;
        }
    }
    
    // 2. 计算基础伤害值
    let ret = _Game_Action_prototype_makeDamageValue.call(this, target, critical);
    // 3. 伤害减免计算
    let HarmRE = 0;
    if (isDamageType) {
        // 从目标缓存获取元素减伤
            const targetCache = target._passiveCache;
            HarmRE = targetCache.harmRe[item.damage.elementId] || 0;
        
        // 穿透减伤（从攻击者缓存获取）
        if (isActorSubject) {
            const subjectCache = subject._passiveCache;
            const penetrateCache = subjectCache.penetrateHarmRe;
            const elementId = item.damage.elementId;
            
            // 固定穿透
            const fixedPenetrate = penetrateCache.fixed[elementId] || 0;
            HarmRE = Math.max(0, HarmRE - fixedPenetrate);
            
            // 百分比穿透
            const percentPenetrate = penetrateCache.percent[elementId] || 0;
            if (percentPenetrate > 0) {
                HarmRE = Math.max(0, HarmRE * (1 - Math.min(percentPenetrate, 100) / 100));
            }
        }
    }
    
    // 4. 伤害加成计算
    let HarmRI = 1;
    let HarmRIGDA = 1;
    let HarmRIGDB = 0;
    
    if (isActorSubject && isDamageType) {
        const cache = subject._passiveCache;
        
        // 全局加伤
        HarmRI += cache.globalHarmRi;
		// 武器类型加伤 - 新增部分
        if (cache.SkETypeHarmRi) {
            // 检查角色是否装备了特定武器类型
            for (const [wtypeIdStr, bonus] of Object.entries(cache.SkETypeHarmRi)) {
                const wtypeId = parseInt(wtypeIdStr, 10);
                if (!isNaN(wtypeId) && subject.isWtypeEquipped(wtypeId)) {
                    HarmRI += bonus;
                }
            }
        }
		
        // 技能特定加伤
        if (cache.skillPass[item.id]) {
            HarmRIGDA += cache.skillPass[item.id].rate;
            HarmRIGDB += cache.skillPass[item.id].flat;
        }
        
        // 技能类型加伤
        if (item.meta.SkillTypes) {
            try {
                const types = JSON.parse(item.meta.SkillTypes);
                types.forEach(type => {
                    if (cache.skillTypeDvup[type]) {
                        HarmRI += cache.skillTypeDvup[type];
                    }
                });
            } catch (e) {
                console.error("解析SkillTypes错误:", e);
            }
        }
    }
    item.damage.elementId = originalElement;
    //ret = ret * HarmRI;
    // 5. 恢复效果处理
    if (ret < 0 && target.isActor()) {
        // 从目标缓存获取恢复效果修改
        const targetCache = target._passiveCache;
        ret *= targetCache.states.DBHPLSteal;
        
        // 恢复时添加状态（从攻击者缓存获取）
		if (subject._passiveCache && subject._passiveCache.recPushStates) {
            subject._passiveCache.recPushStates.forEach(({ stateId, probability }) => {
                if (Math.random() * 100 < probability && !target.isStateAffected(stateId)) {
                    target.addState(stateId);
                }
            });
        }
        return Math.round(ret * HarmRI);
    } else if(HarmRE < ret){
	// 7. 伤害时添加状态（从攻击者缓存获取）
    if (ret > 0 && isActorSubject && isDamageType) {
        // 给目标添加状态
        if (subject._passiveCache.pushStates) {
            subject._passiveCache.pushStates.forEach(({ stateId, probability }) => {
                if (Math.random() * 100 < probability && !target.isStateAffected(stateId)) {
                    target.addState(stateId);
                }
            });
        }
        
        // 给攻击者自己添加状态
        if (subject._passiveCache.pushSelfStates) {
            subject._passiveCache.pushSelfStates.forEach(({ stateId, probability }) => {
                if (Math.random() * 100 < probability && !subject.isStateAffected(stateId)) {
                    subject.addState(stateId);
                }
            });
        }
    }
	//console.log('基础伤害',ret,'HarmRE减伤',HarmRE,'HarmRI总加伤', HarmRI, 'HarmRIGDA技能加伤倍率', HarmRIGDA, 'HarmRIGDB技能固定加伤', HarmRIGDB)
	return Math.round((ret - HarmRE) * HarmRI * HarmRIGDA + HarmRIGDB );
	} else {
		return 0;
	}
};

	//爆伤计算
    var _Game_Action_prototype_applyCritical = Game_Action.prototype.applyCritical;
	Game_Action.prototype.applyCritical = function(damage) {
    const baseDamage = _Game_Action_prototype_applyCritical.call(this, damage);
    const subject = this.subject();
    const item = this.item();
    
    // 只有伤害技能才应用暴击伤害加成
    if (!subject || !item || item.damage.type !== 1) {
        return baseDamage;
    }
    
    // Zero base damage must stay zero; avoid 0/0 propagating NaN.
    if (damage === 0) return 0;
    const CrHarmRI = baseDamage / damage;
    const bonus = Number(subject._passiveCache?.critHarmRi) || 0;
    // A critical damage penalty cannot turn an offensive hit into healing
    // or erase it. Preserve all positive multipliers and native mitigation.
    return damage * Math.max(1, CrHarmRI + bonus);
};

    var _Game_Actor_addedSkillTypes = Game_Actor.prototype.addedSkillTypes;
    Game_Actor.prototype.addedSkillTypes = function () {
        var ret = _Game_Actor_addedSkillTypes.call(this);
        var skillTypesMax = $dataSystem.skillTypes.length;
        for (var ii = 1; ii < skillTypesMax; ii++) {
            if (ret.indexOf(ii) < 0) {
                var tag = 'passiveAST' + ('00' + ii).slice(-2);
                var find = false;
                this.iteratePassiveSkill(tag, function (metaData) {
                    find = true;
                });
                if (find) {
                    ret.push(ii);
                }
            }
        }
        return ret;
    };

    var _Game_Actor_isEquipWtypeOk = Game_Actor.prototype.isEquipWtypeOk;
    Game_Actor.prototype.isEquipWtypeOk = function (wtypeId) {
        var ret = _Game_Actor_isEquipWtypeOk.call(this, wtypeId);
        var tag = 'passiveEWPN' + ('00' + wtypeId).slice(-2);
        this.iteratePassiveSkill(tag, function (metaData) {
            ret = true;
        });
        return ret;
    };

    var _Game_Actor_isEquipAtypeOk = Game_Actor.prototype.isEquipAtypeOk;
    Game_Actor.prototype.isEquipAtypeOk = function (atypeId) {
        var ret = _Game_Actor_isEquipAtypeOk.call(this, atypeId);
        var tag = 'passiveEARM' + ('00' + atypeId).slice(-2);
        this.iteratePassiveSkill(tag, function (metaData) {
            ret = true;
        });
        return ret;
    };

    var _Game_Actor_actionPlusSet = Game_Actor.prototype.actionPlusSet;
    Game_Actor.prototype.actionPlusSet = function () {
        var ret = _Game_Actor_actionPlusSet.call(this);
        var tag = 'passiveAPLUS';
        this.iteratePassiveSkill(tag, function (metaData) {
            var re = /(\d+)/i;
            var match = re.exec(metaData);
            if (match) {
                ret.push(Number(match[1]) * 0.01);
            }
        });
        return ret;
    };

    var _Game_Actor_isAutoBattle = Game_Actor.prototype.isAutoBattle;
    Game_Actor.prototype.isAutoBattle = function () {
        var ret = _Game_Actor_isAutoBattle.call(this);
        var tag = 'passiveAUTO';
        this.iteratePassiveSkill(tag, function (metaData) {
            ret = true;
        });
        return ret;
    };

    var _Game_Actor_isGuard = Game_Actor.prototype.isGuard;
    Game_Actor.prototype.isGuard = function () {
        var ret = _Game_Actor_isGuard.call(this);
        var tag = 'passiveGUARD';
        this.iteratePassiveSkill(tag, function (metaData) {
            ret = true;
        });
        return ret;
    };

    var _Game_Actor_isSubstitute = Game_Actor.prototype.isSubstitute;
    Game_Actor.prototype.isSubstitute = function () {
        var ret = _Game_Actor_isSubstitute.call(this);
        var tag = 'passiveSUBS';
        this.iteratePassiveSkill(tag, function (metaData) {
            ret = true;
        });
        return ret;
    };

    var _Game_Actor_isPreserveTp = Game_Actor.prototype.isPreserveTp;
    Game_Actor.prototype.isPreserveTp = function (flagId) {
        var ret = _Game_Actor_isPreserveTp.call(this);
        var tag = 'passivePRETP';
        this.iteratePassiveSkill(tag, function (metaData) {
            ret = true;
        });
        return ret;
    };

    var _Game_Actor_maxTp = Game_Actor.prototype.maxTp;
    Game_Actor.prototype.maxTp = function () {
        var ret = _Game_Actor_maxTp.call(this);
        this.iteratePassiveSkill('passiveEXTTP', function (metaData) {
            ret += Number(metaData);
        });
        return ret;
    };

    var _Game_Actor_isWtypeEquipped = Game_Actor.prototype.isWtypeEquipped;
	Game_Actor.prototype.isWtypeEquipped = function(wtypeId) {
    // 使用缓存优化
    const cache = this._passiveCache || {};
    
    // 检查 SkETypeAll 标签
    if (cache.SkETypeAll?.some(type => this.weapons().some(w => w.wtypeId === type))) {
        return true;
    }
    
    // 检查 SkEquipType 标签
    if (cache.SkEquipType) {
        return cache.SkEquipType === wtypeId;
    }
    
    // 默认处理
    return _Game_Actor_isWtypeEquipped.call(this, wtypeId);
};
    //--------------------------------------------------------------------------
    /** Game_Action */
    var _Game_Action_executeDamage = Game_Action.prototype.executeDamage;
    Game_Action.prototype.executeDamage = function (target, value) {
        // 元素攻击力改为元素伤害增加
        // value = this.applyPassiveElementRate(value);
        value = this.applyPassiveHealRate(value);
        _Game_Action_executeDamage.call(this, target, value);
    };

    Game_Action.prototype.applyPassiveElementRate = function (value) {
        var ret = value;
        if (this.subject().isActor()) {
            var tag = 'passiveELUP' + ('00' + this.item().damage.elementId).slice(-2);
            this.subject().iteratePassiveSkill(tag, function (metaData) {
                var re = /([-]?\d+(?:\.\d+)?)/i;
                var match = re.exec(metaData);
                if (match) {
                    ret = Number(match[1]) <= -100 ? 0 : Math.floor(ret * (1 + Number(match[1]) * 0.01));
					
                }
            });
        }
        return ret;
    };

    Game_Action.prototype.applyPassiveHealRate = function (value) {
        var ret = value;
        if (value < 0 && this.subject().isActor()) {
            this.subject().iteratePassiveSkill('passiveHEUP', function (metaData) {
                ret *= (1 + Number(metaData) * 0.01);
            });
        }
        return ret;
    };
    //--------------------------------------------------------------------------
    /** Game_Party */
    var _Game_Party_ratePreemptive = Game_Party.prototype.ratePreemptive;
    Game_Party.prototype.ratePreemptive = function (troopAgi) {
        var rate = _Game_Party_ratePreemptive.call(this, troopAgi);
        this.battleMembers().some(function (actor) {
            actor.iteratePassiveSkill('passivePREE', function (metaData) {
                rate += Number(metaData) * 0.01;
            });
        });
        return rate.clamp(0.0, 1.0);
    };

    var _Game_Party_rateSurprise = Game_Party.prototype.rateSurprise;
    Game_Party.prototype.rateSurprise = function (troopAgi) {
        var rate = _Game_Party_rateSurprise.call(this, troopAgi);
        this.battleMembers().some(function (actor) {
            actor.iteratePassiveSkill('passiveASUP', function (metaData) {
                rate -= Number(metaData) * 0.01 * rate;
            });
        });
        return rate.clamp(0.0, 1.0);
    };

    /*var _Game_Enemy_goldRate = Game_Enemy.prototype.goldRate;
    Game_Enemy.prototype.goldRate = function () {
        var rate = 1;
        $gameParty.battleMembers().some(function (actor) {
            actor.iteratePassiveSkill('passiveGRUP', function (metaData) {
                rate += Number(metaData) * 0.01 * rate;
            });
        });
        return _Game_Enemy_goldRate.call(this) * rate;
    };*/

     Game_Troop.prototype.goldTotal = function () {
     var rate = 1;
     $gameParty.battleMembers().some(function (actor) {
     actor.iteratePassiveSkill('passiveGRUP', function (metaData) {
     rate += Number(metaData) * 0.01 * rate;
     });
     });
     return Math.floor(this.deadMembers().reduce(function (r, enemy) {
     return r + enemy.gold()*rate;
     }, 0) * this.goldRate());
     };

    var _Game_Enemy_dropItemRate = Game_Enemy.prototype.dropItemRate;
    Game_Enemy.prototype.dropItemRate = function () {
        var rate = 1;
        $gameParty.battleMembers().some(function (actor) {
            actor.iteratePassiveSkill('passiveIRUP', function (metaData) {
                rate += Number(metaData) * 0.01 * rate;
				//console.log(actor._name,metaData,rate)
            });
        });
        
				//console.log(rate, _Game_Enemy_dropItemRate.call(this), _Game_Enemy_dropItemRate.call(this) * rate)
        return _Game_Enemy_dropItemRate.call(this) * rate;
    };

    

    // Game_Enemy.prototype.makeDropItems = function () {
    // var rate = 1;
    // $gameParty.battleMembers().some(function (actor) {
    // actor.iteratePassiveSkill('passiveIRUP', function (metaData) {
    // rate += Number(metaData) * 0.01 * rate;
    // });
    // });
    // $gameParty.DropGlUp = $gameParty.DropGlUp || 0;
    // rate += $gameParty.DropGlUp * 0.01 * rate;
    // return this.enemy().dropItems.reduce(function (r, di) {
    // if (di.kind > 0 && Math.random() * di.denominator < this.dropItemRate()*rate) {
    // return r.concat(this.itemObject(di.kind, di.dataId));
    // } else {
    // return r;
    // }
    // }.bind(this), []);
    // };
    //--------------------------------------------------------------------------
    /** Window_ActorCommand */
    Window_ActorCommand.prototype.addSkillCommands = function () {
        var skillTypes = this._actor.addedSkillTypes();
        skillTypes.sort(function (a, b) {
            return a - b;
        });
        skillTypes.forEach(function (stypeId) {
            if (stypeId != dsPassiveSkill.parameters.hideA && stypeId != dsPassiveSkill.parameters.hideB) {
                var name = $dataSystem.skillTypes[stypeId];
                this.addCommand(name, 'skill', true, stypeId);
            }
        }, this);
    };

}((this.dsPassiveSkill = this.dsPassiveSkill || {})));

(() => {
    const _Game_Action_makeDamageValue = Game_Action.prototype.makeDamageValue;
    Game_Action.prototype.makeDamageValue = function(target, critical) {
        let damage = _Game_Action_makeDamageValue.call(this, target, critical);
        const user = this.subject();
        const elemId = this.item().damage.elementId;
        let rate = 1;

        user.traitObjects().forEach(obj => {
            const note = obj.note;
            const physReg = note.match(/<SelfPhysRate:(\d+\.?\d+)>/i);
            if (physReg && elemId === 1) {
                rate *= Number(physReg[1]);
            }
            const elemReg = note.match(/<SelfElemRate:(\d+\.?\d+)>/i);
            if (elemReg && elemId >= 2 && elemId <= 9) { // 只对元素 ID 2~9 生效
                rate *= Number(elemReg[1]);
            }
        });

        damage *= rate;
        return damage;
    };
})();