// Star_JiBanSiklls
//
// 角色羁绊技能
var Imported = Imported || {};
Imported.Star_JiBanSiklls = true;
/*:
 * @plugindesc 角色羁绊技能
 * @author Star

 * @param JiBan List 1-25
 * @text ----羁绊列表1-25----
 * @default
 *
 * @param JiBan 1
 * @text 羁绊1
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 2
 * @text 羁绊2
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 3
 * @text 羁绊3
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 4
 * @text 羁绊4
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 5
 * @text 羁绊5
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 6
 * @text 羁绊6
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 7
 * @text 羁绊7
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 8
 * @text 羁绊8
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 9
 * @text 羁绊9
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 10
 * @text 羁绊10
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 11
 * @text 羁绊11
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 12
 * @text 羁绊12
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 13
 * @text 羁绊13
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 14
 * @text 羁绊14
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 15
 * @text 羁绊15
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 16
 * @text 羁绊16
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 17
 * @text 羁绊17
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 18
 * @text 羁绊18
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 19
 * @text 羁绊19
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 20
 * @text 羁绊20
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 21
 * @text 羁绊21
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 22
 * @text 羁绊22
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 23
 * @text 羁绊23
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 24
 * @text 羁绊24
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 25
 * @text 羁绊25
 * @parent JiBan List 1-25
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan List 26-50
 * @text ----羁绊列表26-50----
 * @default
 *
 * @param JiBan 26
 * @text 羁绊26
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 27
 * @text 羁绊27
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 28
 * @text 羁绊28
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 29
 * @text 羁绊29
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 30
 * @text 羁绊30
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 31
 * @text 羁绊31
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 32
 * @text 羁绊32
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 33
 * @text 羁绊33
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 34
 * @text 羁绊34
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 35
 * @text 羁绊35
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 36
 * @text 羁绊36
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 37
 * @text 羁绊37
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 38
 * @text 羁绊38
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 39
 * @text 羁绊39
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 40
 * @text 羁绊40
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 41
 * @text 羁绊41
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 42
 * @text 羁绊42
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 43
 * @text 羁绊43
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 44
 * @text 羁绊44
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 45
 * @text 羁绊45
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 46
 * @text 羁绊46
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 47
 * @text 羁绊47
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 48
 * @text 羁绊48
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 49
 * @text 羁绊49
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 50
 * @text 羁绊50
 * @parent JiBan List 26-50
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan List 51-75
 * @text ----羁绊列表51-75----
 * @default
 *
 * @param JiBan 51
 * @text 羁绊51
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 52
 * @text 羁绊52
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 53
 * @text 羁绊53
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 54
 * @text 羁绊54
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 55
 * @text 羁绊55
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 56
 * @text 羁绊56
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 57
 * @text 羁绊57
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 58
 * @text 羁绊58
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 59
 * @text 羁绊59
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 60
 * @text 羁绊60
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 61
 * @text 羁绊61
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 62
 * @text 羁绊62
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 63
 * @text 羁绊63
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 64
 * @text 羁绊64
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 65
 * @text 羁绊65
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 66
 * @text 羁绊66
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 67
 * @text 羁绊67
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 68
 * @text 羁绊68
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 69
 * @text 羁绊69
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 70
 * @text 羁绊70
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 71
 * @text 羁绊71
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 72
 * @text 羁绊72
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 73
 * @text 羁绊73
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 74
 * @text 羁绊74
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 75
 * @text 羁绊75
 * @parent JiBan List 51-75
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan List 76-100
 * @text ----羁绊列表76-100----
 * @default
 *
 * @param JiBan 76
 * @text 羁绊76
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 77
 * @text 羁绊77
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 78
 * @text 羁绊78
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 79
 * @text 羁绊79
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 80
 * @text 羁绊80
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 81
 * @text 羁绊81
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 82
 * @text 羁绊82
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 83
 * @text 羁绊83
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 84
 * @text 羁绊84
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 85
 * @text 羁绊85
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 86
 * @text 羁绊86
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 87
 * @text 羁绊87
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 88
 * @text 羁绊88
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 89
 * @text 羁绊89
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 90
 * @text 羁绊90
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 91
 * @text 羁绊91
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 92
 * @text 羁绊92
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 93
 * @text 羁绊93
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default
 *
 * @param JiBan 94
 * @text 羁绊94
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 95
 * @text 羁绊95
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 96
 * @text 羁绊96
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 97
 * @text 羁绊97
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 98
 * @text 羁绊98
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 99
 * @text 羁绊99
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 100
 * @text 羁绊100
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 101
 * @text 羁绊101
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 102
 * @text 羁绊102
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 103
 * @text 羁绊103
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 104
 * @text 羁绊104
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 105
 * @text 羁绊105
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 106
 * @text 羁绊106
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 107
 * @text 羁绊107
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 108
 * @text 羁绊108
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 109
 * @text 羁绊109
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 110
 * @text 羁绊110
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 111
 * @text 羁绊111
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 112
 * @text 羁绊112
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 113
 * @text 羁绊113
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 114
 * @text 羁绊114
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 115
 * @text 羁绊115
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 116
 * @text 羁绊116
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 117
 * @text 羁绊117
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 118
 * @text 羁绊118
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 119
 * @text 羁绊119
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 120
 * @text 羁绊120
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 121
 * @text 羁绊121
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 122
 * @text 羁绊122
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 123
 * @text 羁绊123
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 124
 * @text 羁绊124
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 125
 * @text 羁绊125
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 126
 * @text 羁绊126
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 127
 * @text 羁绊127
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 128
 * @text 羁绊128
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 129
 * @text 羁绊129
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 130
 * @text 羁绊130
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 131
 * @text 羁绊131
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 132
 * @text 羁绊132
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 133
 * @text 羁绊133
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 134
 * @text 羁绊134
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 135
 * @text 羁绊135
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 136
 * @text 羁绊136
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 * @param JiBan 137
 * @text 羁绊137
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 138
 * @text 羁绊138
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 139
 * @text 羁绊139
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 140
 * @text 羁绊140
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 141
 * @text 羁绊141
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 142
 * @text 羁绊142
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 143
 * @text 羁绊143
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 144
 * @text 羁绊144
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 145
 * @text 羁绊145
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 146
 * @text 羁绊146
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 147
 * @text 羁绊147
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 148
 * @text 羁绊148
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 149
 * @text 羁绊149
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 150
 * @text 羁绊150
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 151
 * @text 羁绊151
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 152
 * @text 羁绊152
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 153
 * @text 羁绊153
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 154
 * @text 羁绊154
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 *
 * @param JiBan 155
 * @text 羁绊155
 * @parent JiBan List 76-100
 * @type struct<JiBan>
 * @default 
 *
 */
/* ---------------------------------------------------------------------------
 * struct<JiBan>
 * ---------------------------------------------------------------------------
 */
/*~struct~JiBan:
 *
 * @param JiBanName
 * @text 羁绊名称
 *
 * @param JiBanActNum
 * @Number 羁绊人数
 * @desc 羁绊触发人数
 
 * @param JiBanActId
 * @type Actor[]
 * @text 羁绊角色
 * @desc 羁绊角色
 
 * @param JiBanNeceActId
 * @type Actor
 * @text 必要羁绊角色
 * @desc 该羁绊角色在场才触发
 
 * @param JiBanSkiId
 * @type Skill[]
 * @desc 羁绊技能ID(直接输入ID都学会该技能 输入数组则分别学会对应位置的技能)
 * @default 0
 
 * @param JiBanNote
 * @text 羁绊备注
 * @type note
 * @desc 羁绊备注
 * @default ""
 
 @help
    羁绊人物数组内数字是人物的ID(参考数据库角色页面ID)
	技能与羁绊人物数组对应 数字是技能的ID(参考数据库技能页面ID)
 */
/*
// 旧接口
 * @param JiBan Actors
 * @type Actor[]
 * @desc 羁绊人物设置
 * @default ["[\"2\",[\"1\",\"2\"],[\"1\",\"2\"]]","[\"3\", [\"4\",\"3\",\"1\"], [\"4\",\"3\"]]"]
 
 * @param JiBan Skills
 * @type skill[]
 * @desc 羁绊人物技能设置
 * @default ["200","199"]
  *
*/

var Star = Star || {};
var parameters = PluginManager.parameters('Star_JiBanSiklls');
var JiBanActors = [];
var JiBanSkills = [];
var $dataStarJiBanOpt = [null];
var $dataStarJiBanOptN = [null];

Star.ActorsRanksSkill_Jiban = Star.ActorsRanksSkill_Jiban || {
    RanksActors: [],
    parameters: parameters,
    // 缓存上一次的战斗队伍成员
    lastBattleMemberIds: null,
    // 缓存上一次的羁绊技能状态
    lastActiveJiBans: new Set()
};

// 覆盖DataManager.isDatabaseLoaded
Star.ActorsRanksSkill_Jiban.DataManager_isDatabaseLoaded = DataManager.isDatabaseLoaded;
DataManager.isDatabaseLoaded = function() {
    if (!Star.ActorsRanksSkill_Jiban.DataManager_isDatabaseLoaded.call(this))
        return false;
    if (!Star._loaded_Star_Jiban) {
        this.Star_GetJiBanOpt();
        Star._loaded_Star_Jiban = true;
    }
    return true;
};

// 解析羁绊配置
DataManager.Star_GetJiBanOpt = function() {
    $dataStarJiBanOpt = [null];
    $dataStarJiBanOptN = [null];
    
    try {
        var PeiZiLoad = JSON.parse(StorageManager.load("JibanPeiZiLoad")) || "";
    } catch (e) {
        var PeiZiLoad = "";
    }
    
    var Jsparameters = JSON.stringify(PluginManager.parameters('Star_JiBanSiklls'));
    
    for (var i = 1; i <= 200; i++) {
        var paramValue = Star.ActorsRanksSkill_Jiban.parameters['JiBan ' + i] || 'null';
        try {
            var JiBanOptData = JSON.parse(paramValue);
            if (JiBanOptData) {
                this.Star_JiBanDatabaseAdd(i, JiBanOptData);
                
                // 只在配置变化时重新生成组合
                if (PeiZiLoad !== Jsparameters && $dataStarJiBanOpt[i]) {
                    $dataStarJiBanOptN[i] = getRandomArrUp(
                        $dataStarJiBanOpt[i].JiBanActId, 
                        $dataStarJiBanOpt[i].JiBanActNum
                    );
                }
            }
        } catch (e) {
            console.error("解析羁绊配置错误 (ID:" + i + "):", e);
        }
    }

    // 尝试加载缓存
    if (PeiZiLoad === Jsparameters) {
        try {
            var cachedData = StorageManager.load("JibanDateLoad");
            if (cachedData) {
                $dataStarJiBanOptN = JSON.parse(cachedData);
            } else {
                this.generateJiBanCombinations();
            }
        } catch (e) {
            this.generateJiBanCombinations();
        }
    } else {
        this.generateJiBanCombinations();
    }
    
    StorageManager.save("JibanPeiZiLoad", JSON.stringify(Jsparameters));
    StorageManager.save("JibanDateLoad", JSON.stringify($dataStarJiBanOptN));
    Star.ActorsRanksSkill_Jiban.parameters = {};
};

// 生成羁绊组合
DataManager.generateJiBanCombinations = function() {
    for (var i = 1; i <= 200; i++) {
        if ($dataStarJiBanOpt[i]) {
            $dataStarJiBanOptN[i] = getRandomArrUp(
                $dataStarJiBanOpt[i].JiBanActId, 
                $dataStarJiBanOpt[i].JiBanActNum
            );
        }
    }
};

// 添加羁绊到数据库
DataManager.Star_JiBanDatabaseAdd = function(id, data) {
    if (!data) return;
    
    try {
        var JiBanName = data['JiBanName'] || '';
        
        // 安全解析数组
        var JiBanActId = [];
        try {
            JiBanActId = JSON.parse(data['JiBanActId'] || '[]');
        } catch (e) {
            console.warn("JiBanActId解析失败，使用默认空数组:", e);
        }
        
        // 转换为数字数组
        var JiBanActIdN = JiBanActId.map(id => Number(id));
        
        // 处理必要角色ID
        var JiBanNeceActId = data['JiBanNeceActId'];
        if (JiBanNeceActId) {
            JiBanNeceActId = Number(JiBanNeceActId);
        }
        
        // 处理羁绊人数
        var JiBanActNum = Number(data['JiBanActNum'] || 0);
        
        // 处理技能ID
        var JiBanSkiId = data['JiBanSkiId'];
        try {
            // 尝试解析为数组
            JiBanSkiId = JSON.parse(JiBanSkiId);
            if (Array.isArray(JiBanSkiId)) {
                // 数组元素也转成数字，和 isLearnedSkill/forgetSkill 的数字判断保持一致
                JiBanSkiId = JiBanSkiId.map(Number);
            } else {
                // 如果不是数组，转换为数字
                JiBanSkiId = Number(JiBanSkiId) || 0;
            }
        } catch (e) {
            // 解析失败，直接转换为数字
            JiBanSkiId = Number(JiBanSkiId) || 0;
        }

        $dataStarJiBanOpt[id] = {
            name: JiBanName,
            id: id,
            JiBanActId: JiBanActIdN,
            JiBanNeceActId: JiBanNeceActId,
            JiBanActNum: JiBanActNum,
            JiBanSkiId: JiBanSkiId
        };
    } catch (e) {
        console.error("添加羁绊到数据库失败 (ID:" + id + "):", e);
    }
};

// 旧存档兼容：早期版本可能把羁绊技能 ID 以字符串写进角色 _skills，
// 战斗异常结束时也会留下重复条目。读档时统一转数字并去重，只处理能转成数字的字符串，
// 其它技能原样保留、顺序不变；本函数可重复调用（幂等）。
DataManager.Star_JiBanNormalizeSkillIds = function(actors) {
    if (!actors || !actors._data) return;
    Object.keys(actors._data).forEach(function(key) {
        var actor = actors._data[key];
        if (!actor || !Array.isArray(actor._skills)) return;
        var seen = {};
        actor._skills = actor._skills.map(function(skillId) {
            if (typeof skillId === 'string' && /^\d+$/.test(skillId)) {
                return Number(skillId);
            }
            return skillId;
        }).filter(function(skillId) {
            if (typeof skillId === 'number') {
                if (seen[skillId]) return false;
                seen[skillId] = true;
            }
            return true;
        });
    });
};

// 包在 extractSaveContents 外层：此时 $gameActors 已换成刚读出来的存档内容。
var _Star_JiBan_extractSaveContents = DataManager.extractSaveContents;
DataManager.extractSaveContents = function(contents) {
    _Star_JiBan_extractSaveContents.call(this, contents);
    DataManager.Star_JiBanNormalizeSkillIds($gameActors);
};

// 存储管理覆盖
Star.ActorsRanksSkill_Jiban.StorageManagerLocalFilePath = StorageManager.localFilePath;
StorageManager.localFilePath = function(savefileId) {
    if (savefileId === "JibanPeiZiLoad") {
        return this.localFileDirectoryPath() + "RpgJibanPeiZiLoaded.rpgsave";
    } else if (savefileId === "JibanDateLoad") {
        return this.localFileDirectoryPath() + "RpgJibanDateLoaded.rpgsave";
    }
    return Star.ActorsRanksSkill_Jiban.StorageManagerLocalFilePath.call(this, savefileId);
};

Star.ActorsRanksSkill_Jiban.StorageManagerWebStorageKey = StorageManager.webStorageKey;
StorageManager.webStorageKey = function(savefileId) {
    if (savefileId === "JibanPeiZiLoad") {
        return "RpgJibanPeiZiLoaded";
    } else if (savefileId === "JibanDateLoad") {
        return "RpgJibanDateLoaded";
    }
    return Star.ActorsRanksSkill_Jiban.StorageManagerWebStorageKey.call(this, savefileId);
};

// 场景事件处理
// 退出整队刷新技能
if (Scene_Party) {
    Star.ActorsRanksSkill_Jiban.ScPconF = Scene_Party.prototype.commandFinish;
    Scene_Party.prototype.commandFinish = function() {
        // 只在队伍成员变化时刷新
        if (Star.ActorsRanksSkill_Jiban.hasBattleMembersChanged()) {
            Star.ActorsRanksSkill_Jiban.GetActors();
        }
        Star.ActorsRanksSkill_Jiban.ScPconF.call(this);
    };
}

// 退出仓库刷新技能
if (typeof Star_Scene_ActorWarehouse !== 'undefined') {
    Star.ActorsRanksSkill_Jiban.ScAWcNs = Star_Scene_ActorWarehouse.prototype.cancelNowScene;
    Star_Scene_ActorWarehouse.prototype.cancelNowScene = function() {
        // 只在队伍成员变化时刷新
        if (Star.ActorsRanksSkill_Jiban.hasBattleMembersChanged()) {
            Star.ActorsRanksSkill_Jiban.GetActors();
        }
        Star.ActorsRanksSkill_Jiban.ScAWcNs.call(this);
    };
}

// 战斗开始刷新羁绊技能
Star.ActorsRanksSkill_Jiban.BattleManager_startBattle = BattleManager.startBattle;
BattleManager.startBattle = function() {
    // 只在队伍成员变化时刷新
    if (Star.ActorsRanksSkill_Jiban.hasBattleMembersChanged()) {
        Star.ActorsRanksSkill_Jiban.GetActors();
    }
    Star.ActorsRanksSkill_Jiban.BattleManager_startBattle.call(this);
};

// 检查战斗队伍是否发生变化
Star.ActorsRanksSkill_Jiban.hasBattleMembersChanged = function() {
    const currentMembers = $gameParty.battleMembers()
        .filter(actor => actor)
        .map(actor => actor.actorId());
    
    const lastMembers = this.lastBattleMemberIds || [];
    
    // 创建成员ID的Set进行比较
    const currentSet = new Set(currentMembers);
    const lastSet = new Set(lastMembers);
    
    // 比较Set大小和内容
    if (currentSet.size !== lastSet.size) return true;
    for (const id of currentSet) {
        if (!lastSet.has(id)) return true;
    }
    
    return false;
};

// 高效获取队伍人物组合
Star.ActorsRanksSkill_Jiban.GetActors = function() {
    // 获取当前战斗成员
    const battleMembers = $gameParty.battleMembers();
    const activeActors = battleMembers.filter(actor => actor).map(actor => actor.actorId());
    
    // 更新缓存
    this.lastBattleMemberIds = [...activeActors];
    
    // 清空之前的组合
    this.RanksActors = [];
    
	// 处理单人队伍情况
    if (activeActors.length < 2) {
        this.handleSingleMemberCase();
        return;
    }
	
    // 生成所有可能的组合 (2-5人)
    this.generateCombinations(activeActors);
    this.SkillsNew();
};

// 生成组合方法（已扩展支持5人）
Star.ActorsRanksSkill_Jiban.generateCombinations = function(activeActors) {
    const combinations = [];
    
    // 生成2人组合
    for (let i = 0; i < activeActors.length; i++) {
        for (let j = i + 1; j < activeActors.length; j++) {
            combinations.push([activeActors[i], activeActors[j]]);
        }
    }
    
    // 生成3人组合
    for (let i = 0; i < activeActors.length; i++) {
        for (let j = i + 1; j < activeActors.length; j++) {
            for (let k = j + 1; k < activeActors.length; k++) {
                combinations.push([activeActors[i], activeActors[j], activeActors[k]]);
            }
        }
    }
    
    // 生成4人组合
    if (activeActors.length >= 4) {
        for (let i = 0; i < activeActors.length; i++) {
            for (let j = i + 1; j < activeActors.length; j++) {
                for (let k = j + 1; k < activeActors.length; k++) {
                    for (let l = k + 1; l < activeActors.length; l++) {
                        combinations.push([activeActors[i], activeActors[j], activeActors[k], activeActors[l]]);
                    }
                }
            }
        }
    }
    
    // 生成5人组合（新增）
    if (activeActors.length >= 5) {
        for (let i = 0; i < activeActors.length; i++) {
            for (let j = i + 1; j < activeActors.length; j++) {
                for (let k = j + 1; k < activeActors.length; k++) {
                    for (let l = k + 1; l < activeActors.length; l++) {
                        for (let m = l + 1; m < activeActors.length; m++) {
                            combinations.push([activeActors[i], activeActors[j], activeActors[k], activeActors[l], activeActors[m]]);
                        }
                    }
                }
            }
        }
    }
    
    this.RanksActors = combinations;
};

// 处理单人队伍情况
Star.ActorsRanksSkill_Jiban.handleSingleMemberCase = function() {
    // 清除所有激活的羁绊技能
    for (const jiBanId of this.lastActiveJiBans) {
        const jiBan = $dataStarJiBanOpt[jiBanId];
        if (!jiBan) continue;
        
        const skillIds = jiBan.JiBanSkiId;
        const combos = $dataStarJiBanOptN[jiBanId] || [];
        
        for (const combo of combos) {
            for (let i = 0; i < combo.length; i++) {
                const actorId = combo[i];
                const actor = $gameActors.actor(actorId);
                if (actor) {
                    let skillId;
                    if (Array.isArray(skillIds)) {
                        skillId = skillIds[i % skillIds.length];
                    } else {
                        skillId = skillIds;
                    }
                    actor.forgetSkill(skillId);
					console.log('单人队伍',actor._name,skillId)
                }
            }
        }
    }
    
    // 清空激活羁绊记录
    this.lastActiveJiBans.clear();
};

// 优化技能刷新
Star.ActorsRanksSkill_Jiban.SkillsNew = function() {
    // 没有有效队伍时不处理
    if (this.RanksActors.length === 0) return;
    
    // 创建当前组合的快速查找结构
    const currentComboSet = new Set();
    this.RanksActors.forEach(combo => {
        // 排序后生成唯一键
        const key = combo.slice().sort((a, b) => a - b).join('-');
        currentComboSet.add(key);
    });
    
    // 当前激活的羁绊
    const currentActiveJiBans = new Set();
    
    // 处理所有羁绊配置
    for (let jiBanId = 1; jiBanId < $dataStarJiBanOpt.length; jiBanId++) {
        const jiBan = $dataStarJiBanOpt[jiBanId];
        if (!jiBan) continue;
        
        const skillIds = jiBan.JiBanSkiId;
        const combos = $dataStarJiBanOptN[jiBanId] || [];
        
        // 处理每个预定义组合
        for (const combo of combos) {
            // 生成组合的唯一键
            const comboKey = combo.slice().sort((a, b) => a - b).join('-');
            
            // 检查组合是否激活
            if (currentComboSet.has(comboKey)) {
                // 检查必要角色条件
                const hasNecessary = !jiBan.JiBanNeceActId || 
                                     combo.includes(jiBan.JiBanNeceActId);
                
                if (hasNecessary) {
                    currentActiveJiBans.add(jiBanId);
                    // 添加技能
                    for (let i = 0; i < combo.length; i++) {
                        const actorId = combo[i];
                        const actor = $gameActors.actor(actorId);
                        if (actor) {
                            let skillId;
                            if (Array.isArray(skillIds)) {
                                // 使用对应的技能ID
                                skillId = skillIds[i % skillIds.length];
                            } else {
                                // 单个技能ID
                                skillId = skillIds;
                            }
                            
                            // 学习技能
                            actor.learnSkill(skillId);
                        }
                    }
                }
            }
        }
    }
    // 处理不再激活的羁绊技能
    for (let jiBanId of Star.ActorsRanksSkill_Jiban.lastActiveJiBans) {
        if (!currentActiveJiBans.has(jiBanId)) {
            const jiBan = $dataStarJiBanOpt[jiBanId];
            if (!jiBan) continue;
            
            const skillIds = jiBan.JiBanSkiId;
            const combos = $dataStarJiBanOptN[jiBanId] || [];
            $.toaster({ message : '羁绊：'+$dataStarJiBanOpt[jiBanId].name+'失效！'});
            
            for (const combo of combos) {
                for (let i = 0; i < combo.length; i++) {
                    const actorId = combo[i];
                    const actor = $gameActors.actor(actorId);
                    if (actor) {
                        let skillId;
                        if (Array.isArray(skillIds)) {
                            skillId = skillIds[i % skillIds.length];
                        } else {
                            skillId = skillIds;
                        }
                        
                        // 遗忘技能
                        actor.forgetSkill(skillId);
                    }
                }
            }
        }
    }
	//播报羁绊激活情况
	const ActiveJiBans = [...currentActiveJiBans];
	for (let jihuo = 0; jihuo < ActiveJiBans.length; jihuo++) {
    $.toaster({ message : '羁绊：'+$dataStarJiBanOpt[ActiveJiBans[jihuo]].name+'激活！'});
    }
    
    // 更新缓存
    Star.ActorsRanksSkill_Jiban.lastActiveJiBans = currentActiveJiBans;
};

// 随机组合生成
function getRandomArrUp(Arr, Len) {
    const result = [];
    const n = Arr.length;
    
    // 递归生成组合
    function backtrack(start, current) {
        if (current.length === Len) {
            result.push([...current]);
            return;
        }
        
        for (let i = start; i < n; i++) {
            current.push(Arr[i]);
            backtrack(i + 1, current);
            current.pop();
        }
    }
    
    backtrack(0, []);
    return result;
}