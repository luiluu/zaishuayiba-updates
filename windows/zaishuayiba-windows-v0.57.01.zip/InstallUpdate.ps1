﻿# 定位游戏本体、识别已知文本换行差异、输出完整版本诊断。
param([string]$GameDir='')
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$here=$PSScriptRoot
$transcript=$false

function Get-TextHash([string]$File) {
 $bytes=[IO.File]::ReadAllBytes($File)
 try {$text=[Text.UTF8Encoding]::new($false,$true).GetString($bytes)} catch {return ''}
 $text=$text.TrimStart([char]0xFEFF).Replace("`r`n","`n").Replace("`r","`n")
 $hash=[Security.Cryptography.SHA256]::Create()
 try {return ([BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($text)))).Replace('-','').ToLowerInvariant()} finally {$hash.Dispose()}
}
# 按真实首页选择目录，隔离外层启动配置与内容层配置。
function Get-GameCandidate([string]$Folder) {
 if(-not(Test-Path -LiteralPath (Join-Path $Folder 'Game.exe') -PathType Leaf)){return}
 $pkgPath=Join-Path $Folder 'package.json'
 if(-not(Test-Path -LiteralPath $pkgPath -PathType Leaf)){return}
 try{$pkg=Get-Content -LiteralPath $pkgPath -Raw -Encoding UTF8 | ConvertFrom-Json}catch{return}
 if([string]$pkg.name -ne 'com.kyo.zaishuayiba157.windows'){return}
 $found=@()
 foreach($sub in @('','www','resources/app.nw','assets/game')) {
  $content=if($sub){Join-Path $Folder $sub}else{$Folder}
  if((Test-Path -LiteralPath (Join-Path $content 'index.html') -PathType Leaf) -and (Test-Path -LiteralPath (Join-Path $content 'js/plugins.js') -PathType Leaf) -and (Test-Path -LiteralPath (Join-Path $content 'data/System.json') -PathType Leaf)) {
   $main=if($sub){$sub+'/index.html'}else{'index.html'}
   $found+=@([PSCustomObject]@{game=(Resolve-Path -LiteralPath $Folder).ProviderPath;content=(Resolve-Path -LiteralPath $content).ProviderPath;main=$main;prefix=$sub;launcher=$pkgPath;launcherSHA=(Get-FileHash -LiteralPath $pkgPath -Algorithm SHA256).Hash.ToLowerInvariant()})
  }
 }
 $matching=@($found | Where-Object {$_.main -eq ([string]$pkg.main).Replace('\','/').TrimStart('./')})
 if($matching.Count -eq 1){return $matching[0]}
 if($found.Count -eq 1){return $found[0]}
 if($found.Count -gt 1){throw '存在多套完整游戏内容且启动配置无法定位，请保留目录并提供安装日志；未修改游戏。'}
}
function Resolve-GameTarget([string]$Requested) {
 $start=if($Requested){$Requested.Trim('"')}else{$here}
 if(Test-Path -LiteralPath $start -PathType Container) {
  $exact=Get-GameCandidate $start
  if($exact){return $exact}
  $found=@();$queue=@([PSCustomObject]@{path=$start;depth=0})
  while($queue.Count) {
   $node=$queue[0];$queue=@($queue | Select-Object -Skip 1)
   if($node.depth -ge 2){continue}
   foreach($child in @(Get-ChildItem -LiteralPath $node.path -Directory -ErrorAction SilentlyContinue | Where-Object {$_.Name -notin @('更新文件','更新备份','save','.git')} | Select-Object -First 128)) {
    $candidate=Get-GameCandidate $child.FullName
    if($candidate){$found+=@($candidate)}else{$queue+=@([PSCustomObject]@{path=$child.FullName;depth=$node.depth+1})}
   }
  }
  if($found.Count -eq 1){return $found[0]}
  if($found.Count -gt 1){
   Write-Host '发现多个游戏目录，请选择要更新的那个：'
   for($i=0;$i -lt $found.Count;$i++){Write-Host (($i+1).ToString()+'. '+$found[$i].game)}
   $answer=Read-Host '输入序号';$pick=0
   if([int]::TryParse($answer,[ref]$pick) -and $pick -ge 1 -and $pick -le $found.Count){return $found[$pick-1]}
   throw '未选择有效的游戏目录。'
  }
  if(-not $Requested){$parent=Split-Path -Parent $start;$above=Get-GameCandidate $parent;if($above){return $above}}
 }
 $manual=Read-Host '请输入 Game.exe 所在文件夹路径（先完整解压游戏）'
 $manual=$manual.Trim('"');$candidate=Get-GameCandidate $manual
 if($candidate){return $candidate}
 throw '未找到包含 Game.exe、js/plugins.js 和 data/System.json 的完整游戏目录。请勿选择压缩包内的虚拟路径。'
}
try {
 try {Start-Transcript -LiteralPath (Join-Path $here 'install-update.log') -Append -Force | Out-Null;$transcript=$true} catch {Write-Host '无法在更新包目录写入日志，请确认目录可写。'}
 Write-Host '正在检查更新包与游戏目录……'
 $manifestPath=Join-Path $here '更新清单.json'
 if(-not(Test-Path -LiteralPath $manifestPath -PathType Leaf)){throw '缺少更新清单.json。请先完整解压内容更新包，再将本安装器放进同一目录。'}
 $manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
 if(-not $manifest.files -or @($manifest.files).Count -eq 0){throw '更新清单为空或格式不正确。'}
 $version=if($manifest.releaseVersion){[string]$manifest.releaseVersion}else{[string]$manifest.version}
 $target=Resolve-GameTarget $GameDir
 $game=$target.game;$content=$target.content
 $isNested=$game -ne $content
 if($isNested){Write-Host ('二合一／分层目录：启动首页使用 '+$target.main)}
 Write-Host ('游戏目录：'+$game)
 Write-Host ('内容目录：'+$content)
 Write-Host '正在确认游戏已退出……'
 $running=Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'Game.exe' -and $_.ExecutablePath -and [IO.Path]::GetDirectoryName($_.ExecutablePath).TrimEnd('\') -eq $game.TrimEnd('\')}
 if($running){throw '游戏仍在运行。请先保存进度并正常退出游戏，再安装更新。'}
 $textCompatibility=@{}
 $compatPath=Join-Path $here '已知文本校验.json'
 if(Test-Path -LiteralPath $compatPath -PathType Leaf){
  $compat=Get-Content -LiteralPath $compatPath -Raw -Encoding UTF8 | ConvertFrom-Json
  foreach($row in @($compat.files)){$textCompatibility[[string]$row.path]=@($row.variants)}
 }
 $mismatches=@()
 foreach($entry in $manifest.files){
  $rel=[string]$entry.path
  if([IO.Path]::IsPathRooted($rel) -or $rel -match '(^|[\\/])\.\.([\\/]|$)' -or $rel -match '(^|[\\/])save([\\/]|$)' -or $rel -match '\.rpgsave$'){throw '更新路径无效。'}
  $src=Join-Path (Join-Path $here '更新文件') $rel;$dst=Join-Path $content $rel
  if(-not(Test-Path -LiteralPath $src -PathType Leaf)){throw ('缺少更新文件：'+$rel+'。请完整解压整个更新包。')}
  if((Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.after){throw ('更新文件校验失败：'+$rel)}
  $current='missing';if(Test-Path -LiteralPath $dst -PathType Leaf){$current=(Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash.ToLowerInvariant()}
  $allowed=@($entry.before)+@($entry.after);$accepted=$current -in $allowed
  if(-not $accepted -and $current -ne 'missing' -and $textCompatibility.ContainsKey($rel)){
   $normal=Get-TextHash $dst
   foreach($known in $textCompatibility[$rel]){
    if($known.rawSHA256 -in $allowed -and $normal -eq $known.textSHA256){$accepted=$true;Write-Host ('已识别同版本文本的换行/BOM差异：'+$rel);break}
   }
  }
  if(-not $accepted){$mismatches+=@([PSCustomObject]@{path=$rel;actualSHA256=$current;acceptedSHA256=$allowed})}
 }
 if($mismatches.Count){
  $diagnostic=[PSCustomObject]@{targetVersion=$version;gameDirectory=$game;contentDirectory=$content;files=$mismatches}
  $diagnosticPath=Join-Path $here '安装版本诊断.json'
  [IO.File]::WriteAllText($diagnosticPath,($diagnostic | ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))
  foreach($row in $mismatches){Write-Host ('版本不匹配：'+$row.path);Write-Host ('实际 SHA-256：'+$row.actualSHA256)}
  Write-Host ('完整诊断：'+$diagnosticPath)
  throw '版本校验未通过，未修改任何游戏文件。请核对上面的游戏本体目录；若目录正确，请提供安装版本诊断.json与列出的原文件以匹配该版本。'
 }
 Write-Host ('校验完成，正在备份 '+@($manifest.files).Count+' 个文件……')
 $backup=Join-Path (Join-Path $game '更新备份') ($version+'_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
 New-Item -ItemType Directory -Path $backup | Out-Null
 $journal=@()
 $launcherSaved=Join-Path $backup '平台入口/package.json'
 if($isNested){New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($launcherSaved)) -Force | Out-Null;Copy-Item -LiteralPath $target.launcher -Destination $launcherSaved}
 if((Get-FileHash -LiteralPath $target.launcher -Algorithm SHA256).Hash.ToLowerInvariant() -ne $target.launcherSHA){throw '启动配置在安装期间已改变，请重新运行安装器。'}
 foreach($entry in $manifest.files){$dst=Join-Path $content $entry.path;$saved=Join-Path $backup $entry.path;$existed=Test-Path -LiteralPath $dst;$journal+=@{path=$entry.path;existed=$existed};if($existed){New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($saved)) -Force | Out-Null;Copy-Item -LiteralPath $dst -Destination $saved}}
 [IO.File]::WriteAllText((Join-Path $backup '安装回退清单.json'),($journal | ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
 try {
  $n=0
  foreach($entry in $manifest.files){$dst=Join-Path $content $entry.path;New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($dst)) -Force | Out-Null;Copy-Item -LiteralPath (Join-Path (Join-Path $here '更新文件') $entry.path) -Destination $dst -Force;if((Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash.ToLower() -ne $entry.after){throw ('安装校验失败：'+$entry.path)};$n++;if($n%20 -eq 0 -or $n -eq @($manifest.files).Count){Write-Host ('正在安装 '+$n+'／'+@($manifest.files).Count)}}

  if($isNested){
   $outer=Get-Content -LiteralPath $launcherSaved -Raw -Encoding UTF8 | ConvertFrom-Json
   $outer.main=$target.main
   $outer | Add-Member -NotePropertyName releaseVersion -NotePropertyValue $version -Force
   $outer | Add-Member -NotePropertyName releaseNumber -NotePropertyValue ([int]$manifest.releaseNumber) -Force
   if($outer.window){$outer.window.title='再刷一把：西游（mod_KYO） '+$version;$outer.window.icon=$target.prefix+'/icon/icon.png'}
   [IO.File]::WriteAllText($target.launcher,($outer | ConvertTo-Json -Depth 16),[Text.UTF8Encoding]::new($false))
  }
  $launch=Get-Content -LiteralPath $target.launcher -Raw -Encoding UTF8 | ConvertFrom-Json
  if($launch.main -ne $target.main -or -not(Test-Path -LiteralPath (Join-Path $game $launch.main) -PathType Leaf)){throw '安装后启动首页校验失败。'}
  $receipt=[PSCustomObject]@{releaseVersion=$version;gameDirectory=$game;contentDirectory=$content;startupMain=$launch.main;launcherBeforeSHA256=$target.launcherSHA;launcherAfterSHA256=(Get-FileHash -LiteralPath $target.launcher -Algorithm SHA256).Hash.ToLowerInvariant()}
  [IO.File]::WriteAllText((Join-Path $backup '启动入口校验.json'),($receipt | ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
  Write-Host ('启动首页已校验：'+$launch.main)
 } catch {
  Write-Host '安装中断，正在还原原文件……'
  $originalError=$_
  $rollbackErrors=@()
  if($isNested -and (Test-Path -LiteralPath $launcherSaved)){try{Copy-Item -LiteralPath $launcherSaved -Destination $target.launcher -Force}catch{$rollbackErrors+='平台入口/package.json'}}
  foreach($j in $journal){try{$dst=Join-Path $content $j.path;if($j.existed){$saved=Join-Path $backup $j.path;if(-not(Test-Path -LiteralPath $dst) -or (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $saved -Algorithm SHA256).Hash){Copy-Item -LiteralPath $saved -Destination $dst -Force}}else{Remove-Item -LiteralPath $dst -Force -ErrorAction SilentlyContinue}}catch{$rollbackErrors+=$j.path}}
  if($rollbackErrors.Count){throw ('回退未完成，请保留备份目录并联系维护者：'+$backup+'；文件：'+($rollbackErrors -join '、'))}
  throw $originalError
 }
 Write-Host ($version+' 更新已安装。')
 Write-Host '安装未覆盖 save 文件夹；首次载入后完成兼容处理。'
 Write-Host ('旧文件备份：'+$backup)
 if($env:KYO_HOTFIX_INSTALL_QA){[IO.File]::WriteAllText($env:KYO_HOTFIX_INSTALL_QA,($manifest | ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))}
 if($transcript){Stop-Transcript | Out-Null;$transcript=$false}
 exit 0
} catch {
 Write-Host ('安装未完成：'+$_.Exception.Message)
 if($transcript){Stop-Transcript | Out-Null}
 exit 1
}
