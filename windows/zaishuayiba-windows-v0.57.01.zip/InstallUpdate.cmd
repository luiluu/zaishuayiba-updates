@echo off
setlocal
chcp 65001 >nul 2>&1
if not exist "%~dp0InstallUpdate.ps1" (
 echo ERROR: InstallUpdate.ps1 is missing.
 echo Extract ALL files from the update ZIP before running this installer.
 if not defined KYO_INSTALL_NOPAUSE pause
 exit /b 2
)
set "KYO_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%KYO_PS%" (
 echo ERROR: Windows PowerShell was not found.
 if not defined KYO_INSTALL_NOPAUSE pause
 exit /b 3
)
echo Starting update installer...
"%KYO_PS%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0InstallUpdate.ps1" %*
set "KYO_RESULT=%ERRORLEVEL%"
echo.
echo Installer exit code: %KYO_RESULT%
echo Log: "%~dp0install-update.log"
if not defined KYO_INSTALL_NOPAUSE pause
exit /b %KYO_RESULT%
