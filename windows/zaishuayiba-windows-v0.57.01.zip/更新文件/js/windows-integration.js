/* 【Codex·未经Claude检验】 Windows saves and window integration. 核查状态：未经claude检验。 */
(function () {
    'use strict';
    var run = SceneManager.run;
    SceneManager.run = function () {
        var updateTitle = Scene_Boot.prototype.updateDocumentTitle;
        Scene_Boot.prototype.updateDocumentTitle = function () {
            updateTitle.apply(this, arguments);
            var title = nw.App.manifest.window && nw.App.manifest.window.title;
            if (title) { document.title = title; nw.Window.get().title = title; }
        };
        StorageManager.localFileDirectoryPath = function () { return WindowsPort.save; };
        if (StorageManager.drill_COGS_parentDirectoryPath) {
            StorageManager.drill_COGS_parentDirectoryPath = function () { return WindowsPort.root + require('path').sep; };
        }
        var catchException = SceneManager.catchException;
        SceneManager.catchException = function (error) {
            WindowsPort.log('scene-error', String(error && error.stack || error));
            return catchException.apply(this, arguments);
        };
        // QA instrumentation is supplied only to the isolated test copy, never to the ZIP.
        if (WindowsPort.qa) {
            var script = document.createElement('script');
            script.src = 'js/windows-qa.js';
            document.body.appendChild(script);
        }
        return run.apply(this, arguments);
    };
})();
