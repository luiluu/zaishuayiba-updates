/* Windows host adapter. */
(function () {
    'use strict';
    var fs = require('fs'), path = require('path'), os = require('os');
    var qa = process.env.KYO_WINDOWS_QA || '';
    var root = qa && process.env.KYO_WINDOWS_QA_ROOT ? path.resolve(process.env.KYO_WINDOWS_QA_ROOT) :
        path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'), '再刷一把 1.57');
    var save = path.join(root, 'save');
    var candidates = [process.mainModule && path.dirname(process.mainModule.filename), nw.App.startPath,
        path.dirname(process.execPath), path.join(path.dirname(process.execPath), 'package.nw')];
    // v0.46 二合一包：游戏资源在 Game.exe 旁的 assets/game。
    candidates.push(path.join(nw.App.startPath || '', 'assets', 'game'), path.join(path.dirname(process.execPath), 'assets', 'game'));
    try { candidates.push(path.dirname(decodeURIComponent(location.pathname).replace(/^\/([A-Za-z]:)/, '$1'))); } catch (e) {}
    var bundle = candidates.find(function (p) { return p && fs.existsSync(path.join(p, 'index.html')); });
    if (!bundle) throw new Error('无法找到游戏资源目录。请完整解压后运行 Game.exe。');
    fs.mkdirSync(save, { recursive: true });
    fs.mkdirSync(path.join(root, 'logs'), { recursive: true });
    function log(kind, value) {
        fs.appendFileSync(path.join(root, 'logs', 'runtime.log'),
            JSON.stringify({ time: new Date().toISOString(), kind: kind, value: value }) + '\n');
    }
    // Explicitly supplied legacy saves can be imported once; existing destination files always win.
    // The distribution contains no seed saves, author key, feedback queue, or personal settings.
    var marker = path.join(root, 'windows-save-import-v1.json'), prior = null;
    try { prior = JSON.parse(fs.readFileSync(marker, 'utf8')); } catch (e) { prior = null; }
    if (!prior || !Array.isArray(prior.imported) || prior.imported.length === 0) {
        var seed = path.join(bundle, 'save'), imported = [];
        if (fs.existsSync(seed)) fs.readdirSync(seed).forEach(function (name) {
            if (!/^(?:[\w-]+\.rpgsave|yunshang_orders_v1\.json)$/i.test(name)) return;
            var src = path.join(seed, name), dst = path.join(save, name);
            if (fs.lstatSync(src).isFile() && !fs.existsSync(dst)) {
                fs.copyFileSync(src, dst, fs.constants.COPYFILE_EXCL);
                imported.push(name);
            }
        });
        fs.writeFileSync(marker, JSON.stringify({ time: new Date().toISOString(), imported: imported }, null, 2));
    }
    // Legacy MV plugins still resolve resources through mainModule.filename.
    if (!process.mainModule) process.mainModule = { filename: path.join(bundle, 'index.html') };
    window.WindowsPort = { root: root, save: save + path.sep, bundle: bundle, qa: qa, log: log };
    window.addEventListener('error', function (e) {
        log('error', { message: e.message, file: e.filename, line: e.lineno, stack: e.error && e.error.stack });
    });
    window.addEventListener('unhandledrejection', function (e) {
        log('unhandledrejection', String(e.reason && e.reason.stack || e.reason));
    });
    // 游戏内更新模块独立成文件，随内容更新一起替换；文件缺失时保持原有启动行为。
    try {
        var updateScript = document.createElement('script');
        updateScript.src = 'js/windows-updater.js';
        updateScript.async = false;
        updateScript.onerror = function () { log('update-script-missing', 'js/windows-updater.js'); };
        (document.body || document.head || document.documentElement).appendChild(updateScript);
    } catch (error) {
        log('update-script-error', String(error && error.stack || error));
    }
    log('boot', { platform: process.platform, nw: process.versions.nw, node: process.versions.node, arch: process.arch, qa: qa, bundle: bundle });
})();
