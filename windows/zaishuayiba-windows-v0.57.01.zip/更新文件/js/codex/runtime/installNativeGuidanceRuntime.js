// 【Codex·未经Claude检验】v0.05 真气规则与提示同步；未经claude检验。
// v2.0（第二阶段）：区段里程碑（首次进入新区段时原生对话介绍本段重点，每段一次）、修行建议（方桌大厅「商店向导」→「下一步建议」：
//   待选奖励/可突破、下一个守层者、本段可刷的副本Boss与专属掉落、战力构成短板）。区段表由构建脚本从数据生成（G.ATLAS）。
// 修行指引（第一阶段，2026-10-09）：状态界面新增「修行」页——真气与境界、难度对照、提示；战力条旁显示真气。
// v1.4：战力构成显示 P2 软上限与 P3 后的生效值（实际→生效）。
// v1.3：「修行」页新增战力构成（CodexZones，只读）。
// v1.2：难度技能名单补上 6241 强者压制·削弱、10300 轮回模式·洪荒压制。
// v1.1：Boss 预告——首次遇到某个 Boss（每条路线）时用原生战斗消息介绍；之后只提示本场真气。
// 只读：不改任何数值、不写存档。难度技能名单与无画面引擎 decomp.cjs 一致。
window.CodexRuntime.register('installNativeGuidanceRuntime',function(){
 'use strict';
 var G=window.CodexGuide={version:2,sub:1};
 var MANAGED=[6241,10300,5561,5547,5548,5549,5562,5564,5980,5968,5969,5970,5971,5972,5973,6250,6251,6252,6253,6168,6216,6235,8100,8105,8106,8107,8108,8109,8110,8111];
 for(var i=2872;i<=2897;i++)MANAGED.push(i);for(i=7201;i<=7215;i++)MANAGED.push(i);
 G.difficultySkillIds=MANAGED;
 function num(v){v=Number(v);return isFinite(v)?v:0;}
 function group(n){var s=String(Math.round(Math.abs(n))),out='';while(s.length>3){out=','+s.slice(-3)+out;s=s.slice(0,-3);}return (n<0?'−':'')+s+out;}
 function pct(v,sign){var t=group(v*100)+'%';return sign&&v>0?'+'+t:t;}
 function mult(v){if(!(v>0))return '×0';if(v>=1000)return '×'+group(v);if(v>=1)return '×'+v.toFixed(1);if(v>=0.1)return '×'+v.toFixed(2);if(v>=1e-4)return '×'+Number(v.toPrecision(2)).toFixed(Math.max(2,1-Math.floor(Math.log10(v))));var e=Math.floor(Math.log10(v)),m=v/Math.pow(10,e);return '×'+m.toFixed(1)+'e'+e;}
 G.format={group:group,pct:pct,mult:mult};
 // 面板专用格式：整数不加千分位；×N 一律换成伤害 +N%／−N%。
 function fmtAbsPct(p){var a=Math.abs(p);if(a>=100)return String(Math.round(a));if(a>=99)return Math.min(99.9,a).toFixed(1);return String(Math.round(a));}
 function pct0(v){v=num(v);var p=v*100;return (p<0?'−':'')+fmtAbsPct(p)+'%';}
 function signedPct0(v){v=num(v);var t=pct0(v);return v>0?'+'+t:t;}
 function dmgPct(v){v=num(v);if(!(v>0))return '−100%';if(v>=1)return '+'+Math.round((v-1)*100)+'%';
  return '−'+fmtAbsPct((1-v)*100)+'%';}
 function statPct(v){v=num(v);var p=v*100;if(p<0&&Math.abs(p)>=999.5)return '−'+(Math.abs(p)/100).toFixed(1)+'点';return pct0(v);}
 function mult1(v){v=num(v);if(!(v>0))return '×0';return '×'+(v>=1?v.toFixed(1):v.toFixed(2));}
 function bigPanel(v){v=num(v);var a=Math.abs(v);return a>=1e12?(v/1e12).toFixed(1)+'万亿':a>=1e8?(v/1e8).toFixed(1)+'亿':a>=1e4?(v/1e4).toFixed(1)+'万':String(Math.round(v));}
 var MIJING_IDS={爆伤:[6309,6310,6311,6312],结算伤害:[6325,6326,6327,6328]};
 var MIJING_LV=['Lv1','Lv2','Lv3','LvMax'];
 function nextMijing(actor,key){
  var ids=MIJING_IDS[key],lv=0;
  if(ids&&actor&&actor.isLearnedSkill)ids.forEach(function(id,i){if(actor.isLearnedSkill(id))lv=i+1;});
  if(lv>=4)return null;
  return '秘境抽奖·'+key+'·'+MIJING_LV[lv];
 }
 G.format.pct0=pct0;G.format.dmgPct=dmgPct;G.format.bigPanel=bigPanel;G.mijingNext=nextMijing;
 function settlement(a){
  var prod=1,seen={};
  a.skills().concat(a.equips().filter(Boolean)).forEach(function(o){var m,re=/<Start(?:WT)?PushState(\d+):\s*100%>/gi;
   while((m=re.exec(o.note||''))){var id=num(m[1]);if(seen[id])continue;seen[id]=1;var st=$dataStates[id],k=st&&/<Custom Confirm Effect>[\s\S]*?value\s*\*\s*([\d.]+)[\s\S]*?<\/Custom Confirm Effect>/i.exec(st.note||'');if(k)prod*=num(k[1]);}});
  return prod;}
 function snap(a){['initPassiveCache','refreshPassiveCache','refreshPassiveSkillCache'].forEach(function(f){if(a[f])a[f]();});a.refresh();var pc=a._passiveCache||{};
  return {cri:num(a.cri),hit:num(a.hit),crit:num(pc.critHarmRi),fin:num(pc.globalHarmRi),atk:num(a.atk),mat:num(a.mat),settle:settlement(a)};}
 // 难度对照：同一角色「现状」与「去掉难度技能（含补强）」相减
 G.compare=function(actor){
  var now=snap(actor),copy=JsonEx.makeDeepCopy(actor);
  copy.skills().filter(function(s){return MANAGED.indexOf(s.id)>=0;}).forEach(function(s){copy.forgetSkill(s.id);});
  var base=snap(copy);snap(actor);
  return {now:now,base:base,diff:{cri:now.cri-base.cri,hit:now.hit-base.hit,crit:now.crit-base.crit,fin:now.fin-base.fin,atk:base.atk?now.atk/base.atk:1,mat:base.mat?now.mat/base.mat:1,settle:base.settle?now.settle/base.settle:1}};};
 G.context=function(){var Z=window.CodexZhenqi,route=Z?Z.route():{name:'—',key:'normal'},floor=Math.max(1,Math.min(33,num($gameVariables.value(20))||1));
  return {route:route,floor:floor,comp:Z?Z.compFor(route.key,floor):1};};
 // 建议：按优先级给出全部适用项，页面只显示前两条。
 G.panelSuggestions=function(actor,c){
  var out=[],Z=window.CodexZhenqi,s=Z&&Z.state(actor);
  if(s&&s.pending)out.push({key:'pending',text:'选择突破奖励（菜单「真气」）'});
  if(s&&s.canBreak&&s.next)out.push({key:'break',text:'挑战「'+Z.REALMS[s.realm+1].trial+'」突破境界（菜单「真气」）'});
  var critLow=c.now.cri<1,hitLow=c.now.hit<1;
  if(critLow||hitLow)out.push({key:'crit',text:'镶嵌「宝珠·鹰眼」（菜单「宝珠坊」）'});
  if(1.5+c.now.crit<=1){var b=nextMijing(actor,'爆伤');
   out.push({key:'critHarm',text:b?'学习「'+b+'」（方桌大厅·秘境被动书兑换）':'服用加暴伤的丹药（来源见物品说明）'});}
  if(c.diff.atk<0.5||c.diff.mat<0.5){var pill=c.now.atk>=c.now.mat?'裂山霸力丹':'九霄焚天丹';
   out.push({key:'atk',text:'服用「'+pill+'」（蜜雪冰城·洪荒女皇）'});}
  if(c.now.settle<0.5){var b2=nextMijing(actor,'结算伤害');
   out.push({key:'settle',text:b2?'学习「'+b2+'」（方桌大厅·秘境被动书兑换）':'服用加结算伤害的丹药（来源见物品说明）'});}
  if(!out.length)out.push({key:'ok',text:'挑战副本Boss获取真气'});
  return out;};
 G.challenge=function(c){
  var n=0;if(c.now.cri<1)n++;if(1.5+c.now.crit<=1)n++;if(c.now.hit<1)n++;if(c.diff.atk<0.5||c.diff.mat<0.5)n++;
  return n?'属性不足（'+n+'项）':c.now.settle<0.5?'属性达标，伤害偏低':'可以挑战';};
 G.tips=function(actor,c){return G.panelSuggestions(actor,c).map(function(x){
  return (x.key==='pending'||x.key==='break'?'\\C[17]':x.key==='ok'?'\\C[3]':'\\C[2]')+x.text;});};
 // ---- 战力条旁显示真气 ----
 if(Scene_Status.prototype.refreshCombatPowerSummary){
  var _rcp=Scene_Status.prototype.refreshCombatPowerSummary;
  Scene_Status.prototype.refreshCombatPowerSummary=function(){
   var before=this._codexPowerSignature;_rcp.apply(this,arguments);
   var Z=window.CodexZhenqi,a=this.actor(),sp=this._codexPowerSprite;if(!Z||!a||!sp)return;
   var s=Z.state(a),sig=[a.actorId(),s.name,s.rate.toFixed(1),s.pending,s.capped].join('|');
   if(before===this._codexPowerSignature&&this._codexZqSig===sig)return;this._codexZqSig=sig;
   var b=sp.bitmap,w=300;b.clearRect(b.width-w,0,w,36);b.fillRect(b.width-w,0,w,36,'rgba(12,25,35,0.45)');
   b.fontSize=18;b.textColor=s.capped||s.pending?'rgb(255,170,120)':'rgb(150,220,255)';
   b.drawText('真气·'+s.name+' '+mult(s.rate)+(s.pending?'（待选）':s.capped?'（瓶颈）':''),b.width-w,0,w-12,36,'right');};
 }
 // ---- 修行面板：第一页「修行」与第二页「修行·详细」 ----
 function ratioOf(base,now){return base?now/base:1;}
 var panelCache={key:null,value:null};
 function panelData(a){
  var pc=a._passiveCache||{};
  var key=JSON.stringify([a.actorId(),a.level,a.atk,a.mat,a.cri,a.hit,pc.critHarmRi,pc.globalHarmRi,a._codexZhenqi,a._codexZonesLast,a._skills,a._states,a._stateCounter,a._buffs,a._paramPlus,a._equips&&a._equips.map(function(e){return e&&e._itemId;}),$gameVariables.value(20)]);
  if(panelCache.key!==key){var Z=window.CodexZhenqi;panelCache={key:key,value:{c:G.compare(a),ctx:G.context(),s:Z&&Z.state(a)}};}
  return panelCache.value;
 }
 G.panelRows=function(a){
  var rows=[],pd=panelData(a),Z=window.CodexZhenqi,c=pd.c,ctx=pd.ctx,s=pd.s;
  function head(t){rows.push({type:'head',text:t});}function line(t){rows.push({type:'text',text:t});}
  head(ctx.route.name+'·第'+ctx.floor+'层');
  line('挑战评估：'+G.challenge(c));
  if(s){
   line('境界：\\C[6]'+s.name+'\\C[0]　真气：伤害 \\C[3]'+dmgPct(s.rate)+'\\C[0]');
   if(!s.next)line('境界：已至道祖');
   else if(s.capped&&s.canBreak)line('突破条件：挑战「'+Z.REALMS[s.realm+1].trial+'」（菜单「真气」）');
   else if(s.capped)line('突破条件：通关第'+s.gate.required+'层（已通关'+s.gate.passed+'层）');
   else line('下一境所需真气：'+bigPanel(s.need)+'点');
   if(s.pending)line('\\C[17]待选突破奖励：'+s.pending+'项（菜单「真气」）\\C[0]');
  }else line('境界：—　真气：伤害 +0%');
  if(ctx.comp>1.0001)line('天道加持：伤害 '+dmgPct(ctx.comp)+'（本层自动获得）');
  line((c.now.settle<0.5?'\\C[2]':'')+'结算伤害：'+dmgPct(c.now.settle)+(c.now.settle>=1?'':'（本层难度削弱）')+(c.now.settle<0.5?'\\C[0]':''));
  var req=[];
  req.push('暴击率 '+(c.now.cri>=1?'√':'\\C[2]×（差'+pct0(1-c.now.cri)+'）\\C[0]'));
  var cm=1.5+c.now.crit;
  req.push('暴伤 '+(cm>1?'√':'\\C[2]×（差'+pct0(1-cm)+'）\\C[0]'));
  req.push('命中 '+(c.now.hit>=1?'√':'\\C[2]×（差'+pct0(1-c.now.hit)+'）\\C[0]'));
  var ar=Math.max(num(c.diff.atk),num(c.diff.mat));
  req.push('攻击 '+(ar>=0.5?'√':'\\C[2]×（压至'+Math.round(ar*100)+'%）\\C[0]'));
  line('必备属性：'+req.join('　'));
  var sug=G.panelSuggestions(a,c).slice(0,2);
  line('建议：1. '+sug[0].text);
  if(sug[1])line('　2. '+sug[1].text);
  line('详细数据：见「修行·详细」页');
  return rows;};
 G.detailRows=function(a){
  var rows=[],K=window.CodexZones,zp=K&&K.profile(a),Z=window.CodexZhenqi,pd=panelData(a);
  if(!zp)return rows;
  function head(t){rows.push({type:'head',text:t});}function line(t){rows.push({type:'text',text:t});}
  var s=pd.s;
  if(s){
   head('真气');
   line('境界：'+s.name+'　真气：'+bigPanel(s.qi)+'点');
   line('真气：伤害 '+dmgPct(s.rate));
   var d=Z.data(a),df=Z.DAOFA.filter(function(k){return d.daofa[k];}).map(function(k){return Z.DAOFA_NAME[k];});
   line('道法：'+(df.length?df.join('、'):'未领悟'));
   line('来源：守层者（每层一次）、副本Boss、神兵试炼、溢出再动（每场最多10次）');
   rows.push({type:'blank'});
  }
  head('战力构成');
  var last=a._codexZonesLast,cp=K.cap?K.cap(a):null;
  if(last&&cp){cp={floor:last.floor,classFactor:last.classFactor,selfComp:last.selfComp||1,share:last.share,zones:last.zones,rows:Object.keys(last.rows).reduce(function(o,k){o[k]={actual:last.rows[k][0],effective:last.rows[k][1]};return o;},{})};zp=Object.assign({},zp,{difficulty:last.difficulty,parts:last.top.map(function(x){return {zone:x[0],what:x[1],factor:x[2]};})});}
  line('\\C[8]'+(last?'以下取最近一场战斗（第 '+last.floor+' 层）的数值。':'还没有战斗记录：以下为菜单估算，打一场后会更准。')+'\\C[0]');
  var ZONE_NAME={'装备':'装备','人物自身':'人物自身','外部':'外部','真气':'真气','难度补偿':'难度影响'};
  K.ZONES.forEach(function(z){var sh=cp?cp.share[z]:zp.share[z],tg=zp.target[z]||0;
   var fill=tg>0?Math.max(0,Math.min(5,Math.floor(sh/tg*5+1e-9))):0;
   line((ZONE_NAME[z]||z)+'：'+'■'.repeat(fill)+'□'.repeat(5-fill)+' '+Math.round(sh*100)+'%（目标'+Math.round(tg*100)+'%）');});
  line('本层难度：'+dmgPct(zp.difficulty));
  if(pd.ctx.comp>1.0001)line('天道加持：伤害 '+dmgPct(pd.ctx.comp));
  var top=(zp.parts||[]).filter(function(x){return x.zone!=='难度'&&x.factor>0;}).sort(function(x,y){return Math.abs(Math.log(y.factor))-Math.abs(Math.log(x.factor));}).slice(0,3);
  if(top.length)line('\\C[8]最大来源：'+top.map(function(x){return (ZONE_NAME[x.zone]||x.zone)+'·'+x.what+' '+dmgPct(x.factor);}).join('；')+'\\C[0]');
  line('\\C[8]超出本层预算的部分收益递减\\C[0]');
  line('\\C[8]角色专属机制（变身、形态、追击等）在出手时生效，未计入此表。\\C[0]');
  var c=pd.c,ctx=pd.ctx;
  rows.push({type:'blank'});
  head('难度对照　'+ctx.route.name+'·第'+ctx.floor+'层');
  rows.push({type:'cols',cells:['项目','难度影响','不含难度','实际'],system:true});
  rows.push({type:'cols',cells:['暴击率',dmgPct(ratioOf(c.base.cri,c.now.cri)),statPct(c.base.cri),statPct(c.now.cri)],warn:c.now.cri<1});
  var bm=1.5+num(c.base.crit),nm=1.5+num(c.now.crit);
  rows.push({type:'cols',cells:['暴伤',mult1(bm?nm/bm:1),mult1(bm),mult1(nm)],warn:nm<=1});
  rows.push({type:'cols',cells:['命中',dmgPct(ratioOf(c.base.hit,c.now.hit)),statPct(c.base.hit),statPct(c.now.hit)],warn:c.now.hit<1});
  rows.push({type:'cols',cells:['终伤',dmgPct(ratioOf(c.base.fin,c.now.fin)),signedPct0(c.base.fin),signedPct0(c.now.fin)]});
  rows.push({type:'cols',cells:['物攻',dmgPct(c.diff.atk),bigPanel(c.base.atk),bigPanel(c.now.atk)],warn:c.diff.atk<0.5});
  rows.push({type:'cols',cells:['魔攻',dmgPct(c.diff.mat),bigPanel(c.base.mat),bigPanel(c.now.mat)],warn:c.diff.mat<0.5});
  line('结算伤害·本层难度：'+dmgPct(c.diff.settle));
  line('结算伤害·你的被动：'+dmgPct(c.base.settle));
  line('结算伤害·合计：'+dmgPct(c.now.settle));
  line('\\C[8]暴击率：还需减去敌人暴击闪避\\C[0]');
  line('\\C[8]结算伤害：开战时获得的状态合计\\C[0]');
  return rows;};
 function panelInset(win){
  var U=window.CodexV019||window.CodexU;
  if(!U||!U.padRects)return 0;
  var rects=U.padRects()||[];if(!rects.length)return 0;
  var inset=0,top=win.y+win.height*0.35;
  rects.forEach(function(r){if(r.y+r.height>top&&r.x<Graphics.boxWidth*0.45)inset=Math.max(inset,r.x+r.width+12);});
  if(!inset)inset=140;
  return Math.min(180,Math.round(inset));}
 function drawPanelRows(y,lineIndex){
  var rows=this.buildRows(),lh=this.lineHeight(),inset=this._codexInset?panelInset(this):0,w=this.availableWidth()-inset,pad=this.textPadding()+inset,self=this;
  var colW=[Math.floor(w*0.16),Math.floor(w*0.28),Math.floor(w*0.26),Math.floor(w*0.26)];
  rows.forEach(function(r,i){var k=i+lineIndex;if(k<0)return;var yy=y+k*lh;if(yy>self.contentsHeight())return;
   if(r.type==='blank')return;
   if(r.type==='head'){self.changeTextColor(self.systemColor());self.drawText('【'+r.text+'】',pad,yy,w-pad*2);self.resetTextColor();return;}
   if(r.type==='text'){self.drawTextEx(r.text,pad,yy);return;}
   var x=pad;r.cells.forEach(function(cell,j){
    if(r.system)self.changeTextColor(self.systemColor());else if(j===0)self.changeTextColor(self.normalColor());else if(r.warn&&j===3)self.changeTextColor(self.textColor(2));else self.resetTextColor();
    self.drawText(cell,x,yy,colW[j]-pad,j===0?'left':'right');x+=colW[j];});
   self.resetTextColor();});}
 if(typeof JAH_Window_Status_Base!=='undefined'&&window.JahwsUF&&JahwsUF.StatusMenuCore){
  function panelWindow(ctor,pageRows,useInset){
   ctor.prototype=Object.create(JAH_Window_Status_Base.prototype);ctor.prototype.constructor=ctor;ctor.prototype._codexInset=useInset;
   ctor.prototype.initialize=function(){this._rows=[];JAH_Window_Status_Base.prototype.initialize.call(this);};
   ctor.prototype.buildRows=function(){
    var a=this._actor;if(!a)return[];
    var key=JSON.stringify([a.actorId(),a._codexZhenqi,a._codexZonesLast,a._skills,a._equips&&a._equips.map(function(e){return e&&e._itemId;}),$gameVariables.value(20)]);
    if(this._rowsKey===key)return this._rows;this._rowsKey=key;this._rows=pageRows(a);return this._rows;};
   ctor.prototype.getLineCount=function(){return this.getHeaderLineCount()+(this._actor?this.buildRows().length:0);};
   ctor.prototype.drawPageBlock=drawPanelRows;
  }
  window.JAH_Window_Status_Zhenqi=function(){this.initialize.apply(this,arguments);};
  window.JAH_Window_Status_ZhenqiDetail=function(){this.initialize.apply(this,arguments);};
  panelWindow(JAH_Window_Status_Zhenqi,G.panelRows,true);
  panelWindow(JAH_Window_Status_ZhenqiDetail,G.detailRows,false);
  var P=JahwsUF.StatusMenuCore.Param;
  function addPage(win,name){if(P.PageWindows.slice(0,P.TotalPages).indexOf(win)<0){P.PageWindows[P.TotalPages]=win;P.PageNames[P.TotalPages]=name;P.TotalPages+=1;}}
  addPage('JAH_Window_Status_Zhenqi','修行');
  addPage('JAH_Window_Status_ZhenqiDetail','修行·详细');
 }
 // ---- Boss 预告 ----
 var ELEM_SKIP=[0,10];
 function big(v){v=num(v);var a=Math.abs(v);return a>=1e16?v.toExponential(2).replace('e+','e'):a>=1e12?(v/1e12).toFixed(2)+'万亿':a>=1e8?(v/1e8).toFixed(2)+'亿':a>=1e4?(v/1e4).toFixed(2)+'万':String(Math.round(v));}
 function flatOf(enemy){
  var out={},pc=enemy._passiveCache||{};Object.keys(pc.harmRe||{}).forEach(function(k){if(num(pc.harmRe[k])>0)out[k]=num(pc.harmRe[k]);});
  if(!Object.keys(out).length){var notes=[enemy.enemy().note||''];(enemy.enemy().actions||[]).forEach(function(x){var s=$dataSkills[x.skillId];if(s)notes.push(s.note||'');});
   notes.forEach(function(n){var m,re=/<passiveHarmRe(\d+):\s*(\d+)>/g;while((m=re.exec(n))){var k=String(num(m[1]));out[k]=Math.max(out[k]||0,num(m[2]));}});}
  return Object.keys(out).map(function(k){return {e:num(k),v:out[k]};}).sort(function(x,y){return y.v-x.v;});}
 G.format.big=big;
 function elementName(e){return ($dataSystem.elements[e]||'').replace(/\\[^\]]*\]/g,'')||('属性'+e);}
 G.bossInfo=function(){
  var Z=window.CodexZhenqi,b=Z&&Z._battle;if(!b||b.trial)return null;
  var enemies=$gameTroop.members().filter(function(e){return e.isAlive()&&Z.isBossEnemy(e);});if(!enemies.length&&!b.guardianFloor)return null;
  var boss=enemies[0]||$gameTroop.members()[0];if(!boss)return null;
  var flat=flatOf(boss);
  var absorb=[],immune=[],weak=[];
  for(var e=1;e<$dataSystem.elements.length;e++){if(ELEM_SKIP.indexOf(e)>=0||!$dataSystem.elements[e])continue;var r=num(boss.elementRate(e));if(r<0)absorb.push(elementName(e));else if(r===0)immune.push(elementName(e));else if(r>=1.5)weak.push(elementName(e));}
  var marks=[];if(window.CodexBossDifficulty&&CodexBossDifficulty.hasHyperArmor&&CodexBossDifficulty.hasHyperArmor(boss))marks.push('霸体');
  boss.states().forEach(function(s){if(s&&s.name&&s.iconIndex&&marks.length<5&&marks.indexOf(s.name)<0)marks.push(s.name);});
  var f=b.guardianFloor||b.floor,c=b.route.coef,members=$gameParty.battleMembers(),unfirst=0;
  if(b.guardianFloor)members.forEach(function(a){var d=Z.data(a);if(!d.firsts[b.route.key+':'+f])unfirst++;});
  var gain=b.guardianFloor?{first:Z.COEF.first*f*c,win:Z.COEF.guardian*f*c,unfirst:unfirst}:{win:Z.bossReward(f,c)};
  var best=null,pierce=0;
  members.forEach(function(a){var top=0,name='';
   a.skills().concat([$dataSkills[a.attackSkillId()]]).forEach(function(s){if(!s||!s.damage||[1,5].indexOf(s.damage.type)<0)return;
    try{var x=new Game_Action(a);x.setSkill(s.id);x._codexPowerPreview=true;var v=num(x.makeDamageValue(boss,false));if(v>top){top=v;name=s.name;}}catch(err){}});
   if(top>0)pierce++;if(!best||top>best.v)best={a:a.name(),s:name,v:top};});
  return {key:b.route.key+':'+b.troopId,boss:boss,count:enemies.length,guardian:b.guardianFloor,floor:f,route:b.route,comp:b.comp,flat:flat,absorb:absorb,immune:immune,weak:weak,marks:marks,gain:gain,best:best,pierce:pierce,members:members.length};};
 G.bossLines=function(i){
  var L=[];
  L.push('\\C[6]【Boss 预告】\\C[0]'+i.boss.name()+(i.count>1?' 等 '+i.count+' 名':'')+'（'+i.route.name+'·第 '+i.floor+' 层'+(i.guardian?'守层者':'')+'）');
  L.push('生命 '+big(i.boss.mhp)+'　物防 '+big(i.boss.def)+'　魔防 '+big(i.boss.mdf)+(i.comp>1?'　天道加持 '+mult(i.comp):''));
  var same=i.flat.length>=3&&i.flat.every(function(r){return r.v===i.flat[0].v;});
  L.push('固定减伤（每击）：'+(!i.flat.length?'无':same?'所有元素 '+big(i.flat[0].v):i.flat.slice(0,3).map(function(r){return elementName(r.e)+' '+big(r.v);}).join('，')));
  var el=[];if(i.absorb.length)el.push('吸收 '+i.absorb.join('、'));if(i.immune.length)el.push('免疫 '+i.immune.join('、'));if(i.weak.length)el.push('弱点 '+i.weak.join('、'));
  L.push('元素：'+(el.length?el.join('；'):'无特殊')+(i.marks.length?'　状态：'+i.marks.join('、'):''));
  L.push('本场真气（每人）：'+(i.guardian?(i.gain.unfirst?'首通 +'+group(i.gain.first)+'（'+i.gain.unfirst+' 人未得）＋':'')+'胜利 +'+group(i.gain.win):'胜利 +'+group(i.gain.win))+'，另加溢出再动');
  L.push(i.best&&i.best.v>0?'最高单击：'+i.best.a+'「'+i.best.s+'」约 '+big(i.best.v)+'　'+i.pierce+'/'+i.members+' 人能打穿固定减伤':'\\C[2]没有人能打穿固定减伤：提升扣减伤前的单击（攻击、技能与元素增伤、终伤、暴击、真气、结算类被动）或固定减伤穿透，或换角色；结算类被动也能帮助打穿。\\C[0]');
  return L;};
 G.seen=function(key,set){var s=$gameSystem._codexGuideSeen||($gameSystem._codexGuideSeen={});if(set)s[key]=1;return !!s[key];};
 // 【Codex·未经Claude检验】 不在开战时生成预告或扫描全队技能；手动查询接口保留。
 G.PREVIEW_ENABLED=false;

 // ---- 第二阶段：区段里程碑与修行建议 ----
 G.ATLAS=/*ATLAS*/[{"key":"a","lo":0,"hi":6,"title":"神魔之塔 1～6 层","intro":"守层者每层只能打一次，首通给大量真气；副本Boss可以反复刷，胜利给肝帝积分抽奖券（方桌大厅赌场换积分）和真气，并有 20% 掉未鉴定神秘珠（菜单「宝珠坊」鉴定，层数越高品质越好）。不知道下一步做什么，可以问方桌大厅入口的「商店向导」→「下一步建议」。","power":null,"special":["\\C[4]流派书\\C[0]：4层 远古海滩→洞窟深处的「双刀」帕奇掉星爆气流斩一组。"],"bosses":[{"f":1,"where":"方间林地→嘤嘤怪的巢穴","n":1},{"f":2,"where":"溪流森林→土地庙内","n":1},{"f":3,"where":"训练场→伐木者小屋","n":1},{"f":4,"where":"远古海滩→洞窟深处","n":1},{"f":5,"where":"群狼森林→原神空间","n":1},{"f":6,"where":"哥布林部族→哥布林英雄谷","n":1}]},{"key":"b","lo":7,"hi":12,"title":"神魔之塔 7～12 层","intro":"真气攒到大圆满后，打开菜单「真气」（或方桌大厅「闭关」）打瓶颈之战突破大境界，突破有固定奖励和自选奖励；这里还能挑战神兵试炼，降服后可指定本命兵。","power":null,"special":[],"bosses":[{"f":7,"where":"科维努斯镇→夜雨寺","n":1},{"f":7,"where":"科维努斯镇→珈蓝寺","n":1},{"f":7,"where":"荒废的猪猪农场→夜雨寺","n":1},{"f":7,"where":"荒废的猪猪农场→珈蓝寺","n":1},{"f":8,"where":"回音谷→哀嚎迷窟","n":1},{"f":9,"where":"游牧民营地→女神道场","n":1},{"f":10,"where":"雷蹄崖→先祖禁地","n":1},{"f":11,"where":"地下河→地下河实验洞窟","n":5},{"f":12,"where":"冰封洞穴→北风高原","n":1}]},{"key":"c","lo":13,"hi":15,"title":"神魔之塔 13～15 层","intro":"13层起可在方桌大厅「破阵·投影」开启洪荒：从十五种诅咒里自选五种，越重奖励越多（抽奖券、权能掉率）；洪荒路线的不朽存在通关后才会掉权能书，普通副本Boss不掉。","power":["权能·无尽空间","权能·气运昌隆"],"special":["\\C[4]心之钢／狂妄\\C[0]：13层 要塞遗址→深渊·未知存在（哼～、哈～）。","\\C[4]流派书\\C[0]：13层 要塞遗址→深渊·无垠／无尽虚空的黝石巨人掉巨型岩球一组。"],"bosses":[{"f":13,"where":"溪流谷地→魔晶洞穴","n":1},{"f":13,"where":"要塞遗址→深渊·无垠虚空","n":4},{"f":13,"where":"要塞遗址→深渊·无尽虚空","n":4},{"f":13,"where":"要塞遗址→深渊·未知存在","n":2},{"f":14,"where":"神谕森林→浅析之谷","n":1},{"f":15,"where":"黑暗废墟→大神机械实验室","n":1},{"f":15,"where":"黑暗废墟→废墟深处","n":1},{"f":15,"where":"黑暗废墟→深渊·星辰之河","n":3},{"f":15,"where":"黑暗废墟→深渊·星辰大海","n":3},{"f":15,"where":"黑暗废墟→深渊·未知存在","n":5}]},{"key":"d","lo":16,"hi":18,"title":"神魔之塔 16～18 层","intro":"装备、外部、真气、难度影响四类按进度有预算，超出部分收益递减（外部开立方，其余开平方）；「修行·详细」页能看到哪一类溢出、哪一类不足。","power":["权能·命运指引","权能·生命之火"],"special":[],"bosses":[{"f":17,"where":"妖精湖→深渊·未知存在","n":5},{"f":17,"where":"妖精湖→深渊·生命神所","n":3},{"f":17,"where":"妖精湖→风精灵沉眠墓地","n":1},{"f":18,"where":"恶魔城外围→恶魔城","n":2}]},{"key":"e","lo":19,"hi":21,"title":"神魔之塔 19～21 层","intro":"专属掉落集中在深渊副本：同一个Boss可以反复刷，书上写有来源。","power":["权能·因果丝线","权能·轮回不止"],"special":["\\C[4]流派书\\C[0]：19层 天空圣殿→深渊·众神／诸神黄昏的四臂魔猿掉滑稽拳、超滑稽拳。","\\C[4]专属被动书\\C[0]：19层 天空圣殿→古龙祭坛的「古龙」普拉顿掉九阳淬体图。"],"bosses":[{"f":19,"where":"天空圣殿→古龙祭坛","n":1},{"f":19,"where":"天空圣殿→深渊·众神黄昏","n":5},{"f":19,"where":"天空圣殿→深渊·悬空圣域","n":4},{"f":19,"where":"天空圣殿→深渊·悬空神域","n":4},{"f":19,"where":"天空圣殿→深渊·未知存在","n":4},{"f":19,"where":"天空圣殿→深渊·诸神黄昏","n":5},{"f":20,"where":"喜乐天→深渊·未知存在","n":6},{"f":20,"where":"喜乐天→深渊·魔王之渊","n":4},{"f":20,"where":"喜乐天→深渊·魔神之渊","n":4},{"f":20,"where":"喜乐天→食人魔的晚宴","n":1},{"f":21,"where":"威德天→东海湾","n":1}]},{"key":"f","lo":22,"hi":25,"title":"神魔之塔 22～25 层","intro":"后段敌人有固定减伤：打不穿就提高攻击、技能增伤、暴击、真气或固定减伤穿透；结算类倍率也在固定减伤之前计算。","power":["权能·时之主宰","权能·死之掌握"],"special":["\\C[4]流派书\\C[0]：24层 速行天→深渊·未知存在的图斯之剑掉先天破体无形剑气一组。","\\C[4]专属被动书\\C[0]：22层 月行天→剥皮教堂的「哥布林太上皇」劳勃掉九秘:行字诀【强化版】。"],"bosses":[{"f":22,"where":"月行天→剥皮教堂","n":1},{"f":22,"where":"月行天→深渊·未知存在","n":6},{"f":22,"where":"月行天→深渊·浊之深渊1","n":7},{"f":22,"where":"月行天→深渊·蚀之魔渊1","n":7},{"f":23,"where":"娑罗天→陈塘关","n":1},{"f":24,"where":"速行天→深渊·未知存在","n":6},{"f":24,"where":"速行天→深渊·痛苦深渊","n":5},{"f":24,"where":"速行天→熊族桃园","n":1},{"f":25,"where":"上行天→桂树小屋","n":4}]},{"key":"g","lo":26,"hi":33,"title":"神魔之塔 26～33 层","intro":"终点难度按「强者」标定，弱者需要更多养成；「修行·详细」页的战力构成和难度对照可以帮你判断差在哪。","power":["权能·阴阳合一·阴","权能·阴阳合一·阳"],"special":["\\C[4]专属被动书\\C[0]：26层 兜率宫→丹房的三清投影掉炎黄后裔；28层 众分天→西天的恶·如来掉传承升华。"],"bosses":[{"f":26,"where":"影照天→丹房","n":3},{"f":26,"where":"影照天→深渊·孽镜深渊","n":6},{"f":26,"where":"影照天→深渊·未知存在","n":13},{"f":27,"where":"慧行天→墓池","n":4},{"f":28,"where":"众分天→深渊·妄语深渊","n":6},{"f":28,"where":"众分天→深渊·未知存在","n":6},{"f":28,"where":"众分天→西天","n":1},{"f":29,"where":"住轮天→深渊·无为深渊","n":6},{"f":29,"where":"住轮天→老君密室","n":1},{"f":29,"where":"住轮天→老君密室","n":1}]}];
 function floorNow(){var Z=window.CodexZhenqi;return Z?Z.progressFloor():Math.max(0,num($gameVariables.value(20))-1);}
 G.segmentOf=function(f){var A=G.ATLAS||[];for(var i=0;i<A.length;i++)if(f>=A[i].lo&&f<=A[i].hi)return A[i];return A[A.length-1]||null;};
 function page(text){return [{code:101,indent:0,parameters:['',0,0,2]},{code:401,indent:0,parameters:['<WordWrap>'+text]}];}
 function pagesOf(texts){var L=[];texts.forEach(function(t){L=L.concat(page(t));});L.push({code:0,indent:0,parameters:[]});return L;}
 function bossSummary(seg,max){
  var b=seg.bosses||[],shown=b.slice(0,max).map(function(x){return x.f+'层 '+x.where+(x.n>1?'（'+x.n+'个）':'');});
  return shown.join('、')+(b.length>max?' 等 '+b.length+' 处':'');}
 // 【Codex·未经Claude检验】 获取说明与不朽存在专属奖励一致。
 function powerLine(seg){
  var H=window.CodexHonghuang;if(!H||!H.isHonghuang()||!seg.power)return '';
  return '\\C[4]洪荒权能\\C[0]：本段不朽存在通关后掉'+seg.power.join('、')+'，每场每本 '+(H.powerChance()*100).toFixed(1)+'%（诅咒倍率×'+H.curseBonus().toFixed(1)+'）。';}
 G.milestoneTexts=function(seg){
  var t=['\\C[6]'+seg.title+'\\C[0]　'+seg.intro];
  if(seg.bosses&&seg.bosses.length)t.push('\\C[4]可反复刷的副本Boss\\C[0]：'+bossSummary(seg,4)+'。');
  var more=(seg.special||[]).slice(),pw=powerLine(seg);if(pw)more.push(pw);
  if(more.length)t.push(more.join(''));
  return t;};
 G.MILESTONE_ENABLED=true;
 var _smu=Scene_Map.prototype.update;
 Scene_Map.prototype.update=function(){
  _smu.apply(this,arguments);
  try{
   if(!G.MILESTONE_ENABLED||!G.ATLAS||!$gameSystem||$gameMap.isEventRunning()||$gameMessage.isBusy()||$gamePlayer.isTransferring())return;
   this._codexMsTick=(this._codexMsTick||0)+1;if(this._codexMsTick%30)return;
   var seg=G.segmentOf(floorNow());if(!seg||G.seen('seg:'+seg.key))return;
   G.seen('seg:'+seg.key,true);$gameMap._interpreter.setup(pagesOf(G.milestoneTexts(seg)),0);
  }catch(e){console.error('[Guide] milestone',e);}};
 function shortName(a){return a.name();}
 G.adviceTexts=function(){
  var Z=window.CodexZhenqi,K=window.CodexZones,f=floorNow(),seg=G.segmentOf(f),out=[];
  var route=Z?Z.route().name:'—',mem=$gameParty.members(),pend=[],cap=[];
  if(Z)mem.forEach(function(a){var s=Z.state(a);if(s.pending)pend.push(shortName(a));else if(s.canBreak)cap.push(shortName(a)+'→'+s.next.name);});
  var p1='\\C[6]修行建议\\C[0]　路线：'+route+'，已通过第'+f+'层，'+(f>=33?'守层者已全部通过，真气主要靠副本Boss、神兵试炼和溢出再动。':'下一个守层者在第'+(f+1)+'层（每层只能打一次，首通给大量真气）。');
  if(pend.length)p1+='\\C[2]待选奖励\\C[0]：'+pend.slice(0,6).join('、')+(pend.length>6?' 等':'')+'——打开菜单「真气」补选。';
  if(cap.length)p1+='\\C[2]可突破\\C[0]：'+cap.slice(0,4).join('、')+(cap.length>4?' 等':'')+'——打开菜单「真气」打瓶颈之战。';
  out.push(p1);
  if(seg){var p2='\\C[4]'+seg.title+'\\C[0]可反复刷：'+bossSummary(seg,5)+'。胜利给抽奖券（另加 层数÷3 张）和真气（1～15层保留原奖励的1/3，16～25层保留1/2，26～33层保留2/3）；同一个副本Boss打满 1／10／50 次另给 10／30／100 张券，10 次后权能和专属书掉率×2、50 次后×3；每场另有 10% 掉神秘珠（宝珠坊鉴定，一半出原作宝珠）。';
   var sp=(seg.special||[]).join('');var pw=powerLine(seg);out.push(p2);if(sp||pw)out.push(sp+pw);}
  var RC=window.$dataCodexRaces,bands=RC&&RC.bands,band=-1;
  if(bands)bands.forEach(function(b,i){if(f>=b[0]&&f<=b[1])band=i;});
  var entry='\\C[4]养成入口\\C[0]：菜单「宝珠坊」鉴定、分解并查看套装；「种族祝福」逐人换族与进阶；菜单「真气」突破、领奖与挑战神兵试炼，大厅「闭关」也可操作。';
  if(band>=0){var rs=$gameSystem._codexRaceSupply;entry+='本段副本Boss提供'+$dataItems[RC.stones[band]].name+'，'+(!rs||!rs.first||!rs.first[band+2]?'首次胜利1份，':'')+'每累计5场再1份。';}
  out.push(entry);
  if(K&&K.cap){
   var rows=[],over={},weak={};
   var adviceMembers=$gameParty.battleMembers(),adviceParty=$gameParty;
   try{window.$gameParty=JsonEx.makeDeepCopy(adviceParty);
   adviceMembers.forEach(function(a){
    try{var r=K.cap(a,Math.max(1,f));if(!r)return;var best=null;
     ['装备','外部','真气'].forEach(function(k){var x=r.rows[k];if(!x)return;var fill=x.budget>1?Math.log(Math.max(1,x.actual))/Math.log(x.budget):1;
      if(fill>1)over[k]=(over[k]||0)+1;if(!best||fill<best.fill)best={k:k,fill:fill};});
     if(best&&best.fill<0.8){rows.push(shortName(a)+' '+best.k+' '+Math.round(best.fill*100)+'%');weak[best.k]=(weak[best.k]||0)+1;}
    }catch(e){}});
   }finally{window.$gameParty=adviceParty;}
   var TIP={'装备':'换更高品质的装备（每件按品质加战力）','外部':'学被动书、经书（人族首领、洪荒女皇），刷专属掉落','真气':'刷副本Boss、首通守层者、神兵试炼，大圆满后闭关突破'};
   var p4='\\C[4]战力短板\\C[0]（填到预算的几成，「修行·详细」页有明细）：';
   if(rows.length){p4+=rows.slice(0,5).join('；')+'。';var top=Object.keys(weak).sort(function(x,y){return weak[y]-weak[x];})[0];p4+='建议：'+TIP[top]+'。';}
   else p4+='出战成员的装备、外部、真气都已接近或超过预算。';
   var ov=Object.keys(over);if(ov.length)p4+='已溢出：'+ov.join('、')+'（超出部分收益递减，外部减得最多，优先补别的类）。';
   out.push(p4);}
  return out;};
 G.advise=function(interp){interp.setupChild(pagesOf(G.adviceTexts()),interp._eventId);};
 // 旧档在方桌大厅读档时，地图事件位置取自存档：改版向导、商店向导按当前地图数据摆回（2026-10-10 移到入塔门口两侧，面向下）。
 G.GUIDE_NOTES=['<Codex Guide v1>','<CodexEconomy: guide>'];
 G.placeGuides=function(){
  if(!window.$gameMap||$gameMap.mapId()!==4||!window.$dataMap||!$dataMap.events)return 0;var n=0;
  $dataMap.events.forEach(function(ev){if(!ev||G.GUIDE_NOTES.indexOf(String(ev.note||'').trim())<0)return;var e=$gameMap.event(ev.id);if(!e){e=$gameMap._events[ev.id]=new Game_Event($gameMap.mapId(),ev.id);n++;}
   var pg=ev.pages[0],dir=pg&&pg.image&&pg.image.direction||2;
   if(e.x!==ev.x||e.y!==ev.y){e.locate(ev.x,ev.y);n++;}if(e.direction()!==dir)e.setDirection(dir);});
  return n;};
 var _guideMapLoaded=Scene_Map.prototype.onMapLoaded;
 Scene_Map.prototype.onMapLoaded=function(){G.placeGuides();var out=_guideMapLoaded.apply(this,arguments);G.placeGuides();return out;};
 // 【Claude·未经Codex检验】v0.37：玩家更新日志改为每版一个只读文件 data/PlayerChangelog/vX.XX.json（{"version","pages":[…]}）。
 // 改版向导「更新日志」标签后的脚本把这些页面插到原有页面（v0.36及以前，仍在Map004）之前；以后出新版只新增文件，不再改Map004。
 // 手机宿主每个文件最多认16个旧版本，每版改同一文件会让早期玩家无法直接导入累计包。
 G.CHANGELOG_FIRST=37;
 G.versionLabel=function(seq){var minor=String(seq%100);return 'v'+Math.floor(seq/100)+'.'+(minor.length<2?'0'+minor:minor);};
 // 【Codex·未经Claude检验】v0.50重整：内容版本独立于APK／NW外壳，首页与日志共用。
 G.releaseInfo=function(){if(G._releaseInfo!==undefined)return G._releaseInfo;
  try{var x=new XMLHttpRequest();x.open('GET','data/ContentVersion.json',false);if(x.overrideMimeType)x.overrideMimeType('application/json');x.send();
   var d=JSON.parse(x.responseText);if((!x.status||x.status===200)&&d&&/^v\d+\.\d{2}(?:\.\d{2})?$/.test(d.releaseVersion)&&Number.isInteger(d.releaseNumber)&&d.releaseNumber>=0){return G._releaseInfo=d;}}
  catch(e){}return G._releaseInfo=null;};
 G.readChangelog=function(seq){
  try{var x=new XMLHttpRequest();x.open('GET','data/PlayerChangelog/'+G.versionLabel(seq)+'.json',false);if(x.overrideMimeType)x.overrideMimeType('application/json');x.send();
   if(x.status&&x.status!==200)return null;if(!x.responseText)return null;var d=JSON.parse(x.responseText);
   return d&&Array.isArray(d.pages)?d:null;}catch(e){return null;}};
 G.changelogEntries=function(){if(G._changelog)return G._changelog;var out=[];
  // 【Codex·未经Claude检验】v0.58：空 pages 表示已登记的跳号，仅跳过该页；不截断后续日志。
  var release=G.releaseInfo(),end=release?Math.min(release.releaseNumber,G.CHANGELOG_FIRST+899):G.CHANGELOG_FIRST+899;
  for(var seq=G.CHANGELOG_FIRST;seq<=end;seq++){var d=G.readChangelog(seq);if(!d)break;if(d.pages.length)out.unshift(d);}
  return G._changelog=out;};
 G.injectChangelog=function(interp){
  var list=interp&&interp._list;if(!list)return 0;var at=interp._index,ind=list[at]?list[at].indent:0,face=['People5_mvt',7,0,2];
  for(var i=at+1;i<list.length;i++)if(list[i].code===101){face=list[i].parameters.slice();break;}
  var cmds=[];
  G.changelogEntries().forEach(function(d){d.pages.forEach(function(page){
   cmds.push({code:101,indent:ind,parameters:face.slice()});
   String(page).split('\n').forEach(function(line){cmds.push({code:401,indent:ind,parameters:[line]});});
   cmds.push({code:102,indent:ind,parameters:[['更早的更新','返回'],1,0,2,0]},{code:402,indent:ind,parameters:[0,'更早的更新']},{code:0,indent:ind+1,parameters:[]},
    {code:402,indent:ind,parameters:[1,'返回']},{code:119,indent:ind+1,parameters:['主菜单']},{code:0,indent:ind+1,parameters:[]},{code:404,indent:ind,parameters:[]});});});
  if(cmds.length)interp._list=list.slice(0,at+1).concat(cmds,list.slice(at+1));
  return cmds.length;};

 // 首页右下角的内容版本不读取旧外壳标题，也不参与游戏进度保存。
 G.addTitleVersion=function(scene){if(scene._codexContentVersionSprite)return;var d=G.releaseInfo(),latest=d||G.changelogEntries()[0];
  var label=latest&&(latest.releaseVersion||latest.version);if(!label)return;
  var b=new Bitmap(216,42),sp=new Sprite(b);sp.x=Math.max(12,Graphics.width-234);sp.y=Math.max(12,Graphics.height-58);
  b.fillRect(0,0,216,42,'rgba(10,18,24,0.76)');b.fontSize=24;b.textColor='#f3dfac';b.outlineColor='rgba(0,0,0,0.9)';b.outlineWidth=4;
  b.drawText('版本 '+label,12,0,192,42,'center');scene._codexContentVersionText='版本 '+label;scene._codexContentVersionSprite=sp;scene.addChild(sp);};
 var _titleCreate=Scene_Title.prototype.create;
 Scene_Title.prototype.create=function(){var out=_titleCreate.apply(this,arguments);G.addTitleVersion(this);return out;};

 return G;
});
