// 【Codex·未经Claude检验】v0.13 修复头顶商店／装备详情缓存失效；未经claude检验。
// 【Codex·未经Claude检验】 v0.05 "头顶": independent native crown and durable growth ledger.
window.CodexRuntime.register("installNativeDemonCrownRuntime", function () {
 'use strict';
 var W=window,D=W.CodexDemonCrown={version:1,armorId:7940,iconIndex:290000,limit:1000,dropRate:0.03};
 var ledger=null,store=null,mutating=false,trade=0,battle=null,legacyKey=null;
 function copy(v){return JSON.parse(JSON.stringify(v));}
 function num(v){v=Number(v);return isFinite(v)?v:0;}
 function uid(){if(Utils.isNwjs())return require('crypto').randomBytes(16).toString('hex');if(W.crypto&&W.crypto.getRandomValues){var a=new Uint32Array(4);W.crypto.getRandomValues(a);return Array.prototype.map.call(a,function(v){return v.toString(16);}).join('-');}return Date.now().toString(36)+'-'+(++D.uidSerial)+'-'+Math.random().toString(36).slice(2);} 
 D.uidSerial=0;
 function wrap(o,k,f){var old=o&&o[k];if(typeof old!=='function')return;o[k]=function(){return f.call(this,old,arguments);};}
 function hash(s){s=String(s);if(Utils.isNwjs())return require('crypto').createHash('sha256').update(s).digest('hex');var h=2166136261;for(var n=0;n<s.length;n++){h^=s.charCodeAt(n);h=Math.imul(h,16777619);}return (h>>>0).toString(16)+':'+s.length;}
 function storage(){
  if(store)return store;
  if(Utils.isNwjs()){
   var fs=require('fs'),path=require('path'),dir=StorageManager.localFileDirectoryPath(),file=path.join(dir,'crown_progress_v1.json');
   store={read:function(){return fs.existsSync(file)?fs.readFileSync(file,'utf8'):null;},write:function(text){
    fs.mkdirSync(dir,{recursive:true});var tmp=file+'.'+uid()+'.tmp',fd;
    try{fd=fs.openSync(tmp,'wx');fs.writeFileSync(fd,text);fs.fsyncSync(fd);fs.closeSync(fd);fd=null;fs.renameSync(tmp,file);}
    finally{if(fd!=null)fs.closeSync(fd);if(fs.existsSync(tmp))fs.unlinkSync(tmp);}
   }};
  }else if(W.AndroidInterface&&typeof AndroidInterface.readcrown==='function'&&typeof AndroidInterface.writecrown==='function'){
   // v0.05 host: durable record can travel with exported JSON. Preserve .7 storage.
   store={read:function(){var raw=AndroidInterface.readcrown();if(raw===null||raw===undefined){raw=localStorage.getItem('codex_crown_progress_v1');if(raw)AndroidInterface.writecrown(raw);}return raw;},write:function(s){AndroidInterface.writecrown(s);}};
  }else store={read:function(){return localStorage.getItem('codex_crown_progress_v1');},write:function(s){localStorage.setItem('codex_crown_progress_v1',s);}};
  return store;
 }
 function readLedger(){
  if(!ledger){var raw=storage().read(),l=raw?JSON.parse(raw):{version:1,profiles:{},legacy:{}};
   if(l.version!==1||!l.profiles||typeof l.profiles!=='object')throw Error('"头顶"成长记录损坏或版本不兼容');
   l.legacy=l.legacy||{};ledger=l;
  }return ledger;
 }
 function commit(l){storage().write(JSON.stringify(l));ledger=l;}
 function newProfile(){return {revision:0,items:{},battles:{},worldDeaths:{}};}
 function profile(){
  var l=readLedger(),id=$gameSystem._codexCrownProfile;
  if(id&&!l.profiles[id])throw Error('此存档的"头顶"成长记录缺失');
  if(!id){
   var identity=$gameSystem._yunProfile?('yun:'+String($gameSystem._yunProfile)):legacyKey;
   id=identity&&l.legacy[identity];
   if(!id){id=uid();var n=copy(l);n.profiles[id]=newProfile();if(identity)n.legacy[identity]=id;commit(n);}
   $gameSystem._codexCrownProfile=id;
  }return ledger.profiles[id];
 }
 function fail(e){
  if(!D.storageError){console.error('"头顶"成长记录暂不可用',e);if(W.$&&$.toaster)$.toaster({message:'"头顶"成长记录暂不可用，请恢复对应成长记录后重开游戏'});}
  D.storageError=String(e&&e.message||e);
  ($dataArmors||[]).forEach(function(i){if(D.isGear(i)&&i._codexCrownUid)(i.traits||[]).forEach(function(t){if(t._codexCrown)t.value=1;});});
 }
 function safely(f){if(D.storageError)return false;try{return f();}catch(e){fail(e);return false;}}
 D.baseId=function(i){return num(i&&(i.originalBaseItemId||i.baseItemId||i.id));};
 D.isGear=function(i){return !!i&&(D.baseId(i)===D.armorId||/<CodexDemonCrown>/i.test(i.note||''));};
 D.bonus=function(i){return Math.max(0,Math.min(D.limit,num(i&&i._codexCrownBonus)));};
 D.next=function(b){b=Math.max(0,Math.min(D.limit,num(b)));return b+(1-b/D.limit);};
 D.display=function(v){return String(Math.round(num(v)));};
 D.gear=function(a){return a&&a.equips?a.equips().filter(D.isGear)[0]||null:null;};
 function real(a){return !!(a&&a.actorId&&W.$gameActors&&$gameActors._data[a.actorId()]===a);}
 function actors(){return W.$gameActors?($gameActors._data||[]).filter(Boolean):[];}
 function owned(){
  if(!W.$gameParty)return [];
  var out=$gameParty.armors().filter(D.isGear);
  actors().forEach(function(a){out=out.concat(a.equips().filter(D.isGear));});
  return out.filter(function(i,n){return D.baseId(i)===D.armorId&&i.id>=DataManager._baseArmorsLength&&out.indexOf(i)===n;});
 }
 function describe(i){
  if(!D.isGear(i))return;
  i.name='"头顶"';i.baseItemName='"头顶"';i.priorityName='"头顶"';
  i.description='神武\n欲加冕成王，必承其重';i.iconIndex=D.iconIndex;
  var quality=W.CodexHeartsteel?CodexHeartsteel.quality(i):12;
  i.note=String(i.note||'').replace(/<(quality|ici):\s*\d+>/gi,'')+'\n<quality:'+quality+'>\n<ici:'+quality+'>\n';
  i.meta=i.meta||{};i.meta.quality=String(quality);i.meta.ici=String(quality);
  var b=D.bonus(i),rate=1+b/100;
  i.traits=(i.traits||[]).filter(function(t){return !t._codexCrown;});
  for(var n=0;n<8;n++)i.traits.push({code:21,dataId:n,value:D.storageError?1:rate,_codexCrown:true});
  var note=String(i.note||'').replace(/<pos=APs text=成长[：:]八项全属性[^>]*>\s*/g,'');
  i.note=note+'\n<pos=APs text=成长：八项全属性＋'+D.display(b)+'% size=18 color=rgba(255,255,255,1) line=false align=0>\n';
  delete i.descParams;
 }
 D.describe=describe;
 function refresh(a){a.need_refresh=true;if(a._ParamCache2)a._ParamCache2=[];if(a.refresh)a.refresh();if(W.CodexZones&&CodexZones.invalidate)CodexZones.invalidate(a);}
 function find(id){return ($dataArmors||[]).filter(function(i){return i&&i._codexCrownUid===id;})[0]||null;}
 function grantSpec(r,id){
  var i=find(id);
  if(!i){
   i=copy(r.spec);i.id=$dataArmors.length;i._codexCrownUid=id;i.nonIndependent=false;i.DXRPSNewItem=false;
   $dataArmors.push(i);DataManager._independentArmors.push(i);$gameParty._armors[i.id]=1;
  }
  i._codexCrownBonus=r.bonus;describe(i);return i;
 }
 function remove(i){
  actors().forEach(function(a){a.equips().forEach(function(e,k){if(e&&e._codexCrownUid===i._codexCrownUid)a.forceChangeEquip(k,null);});});
  if($gameParty.numItems(i)>0)$gameParty.loseItem(i,$gameParty.numItems(i),false);
 }
 function replay(){
  var p=profile();mutating=true;
  try{
   Object.keys(p.items).forEach(function(id){var r=p.items[id],i=find(id);
    if(r.removed){if(i)remove(i);return;}
    grantSpec(r,id);
   });
   actors().forEach(function(a){if(a.equips().some(D.isGear))refresh(a);});
   if(W.CodexCombatPower&&CodexCombatPower.clearCache)CodexCombatPower.clearCache();
  }finally{mutating=false;}
 }
 D.replay=function(){return safely(replay);};
 function transaction(f){
  profile();var n=copy(ledger),p=n.profiles[$gameSystem._codexCrownProfile],out=f(p);p.revision++;
  commit(n);replay();return out;
 }
 function spec(){
  var base=$dataArmors[D.armorId],dataLength=$dataArmors.length,independentLength=DataManager._independentArmors.length,i;
  try{i=DreamX.RandomPrefixSuffix.makeItem(base);}
  finally{$dataArmors.length=dataLength;DataManager._independentArmors.length=independentLength;}
  i.id=0;i.baseItemId=D.armorId;i.originalBaseItemId=D.armorId;i.baseItemName='"头顶"';i.priorityName='"头顶"';
  i.nonIndependent=false;i.DXRPSNewItem=false;i._codexCrownBonus=0;describe(i);return i;
 }
 function itemRow(){return {spec:spec(),bonus:0,removed:false};}
 D.grant=function(){return safely(function(){var id=uid();transaction(function(p){p.items[id]=itemRow();});return find(id);});};
 D.record=function(){return safely(function(){return copy(profile());});};
 function adopt(){
  var list=owned().filter(function(i){return !i._codexCrownUid;});if(!list.length)return;
  transaction(function(p){list.forEach(function(i){var id=uid();i._codexCrownUid=id;var s=copy(i);s.id=0;p.items[id]={spec:s,bonus:D.bonus(i),removed:false};});});
 }
 D.isDropBattle=function(){
  if(!W.$gameMap||$gameMap.mapId()!==162||[539,540,541,542].indexOf($gameTroop._troopId)<0)return false;
  var Y=W.CodexYunshang;return !!(Y&&Y.isImmortalClear&&Y.isImmortalClear());
 };
 function begin(){
  if(D.storageError){battle=null;return;}
  safely(function(){
   adopt();var wears=$gameParty.battleMembers().filter(function(a){return real(a)&&a.isAlive()&&D.gear(a)&&D.gear(a)._codexCrownUid;}).map(function(a){return {actor:a.actorId(),uid:D.gear(a)._codexCrownUid};});
   var eligible=D.isDropBattle();if(!wears.length&&!eligible){battle=null;return;}
   var ordinal=num($gameSystem._codexCrownEncounterSeq),key='b:'+ordinal,p=profile(),row=p.battles[key];
   if(!row){transaction(function(n){n.battles[key]={troop:$gameTroop._troopId,map:$gameMap.mapId(),eligible:eligible,roll:eligible?Math.random():null,wears:wears,deaths:{},settled:false};});row=profile().battles[key];}
   battle={key:key,ordinal:ordinal,wears:wears.map(function(x){return {actor:x.actor,uid:x.uid,valid:row.wears.some(function(y){return y.actor===x.actor&&y.uid===x.uid;})};}),deathSerial:{},sameEncounter:row.map===$gameMap.mapId()&&row.troop===$gameTroop._troopId,finished:false};
  });
 }
 function finish(result){
  var b=battle;if(!b||b.finished)return;b.finished=true;
  safely(function(){
   var row=profile().battles[b.key];if(!row)throw Error('战斗成长记录缺失');
   if(!row.settled){
    var winners=b.wears.filter(function(x){var a=$gameActors._data[x.actor],i=a&&D.gear(a);return x.valid&&a&&a.isAlive()&&$gameParty.battleMembers().indexOf(a)>=0&&i&&i._codexCrownUid===x.uid;});
    transaction(function(p){
     var r=p.battles[b.key];r.settled=true;r.result=num(result);
     if(result!==0||!b.sameEncounter)return;
     winners.forEach(function(x){var g=p.items[x.uid];if(g&&!g.removed)g.bonus=D.next(g.bonus);});
     if(r.eligible&&r.roll<D.dropRate){r.dropUid=uid();p.items[r.dropUid]=itemRow();}
    });
    if(result===0&&profile().battles[b.key].dropUid&&W.$&&$.toaster)$.toaster({message:'获得了"头顶"！'});
   }
   $gameSystem._codexCrownEncounterSeq=b.ordinal+1;
  });
  battle=null;
 }
 function death(a){
  if(mutating||!real(a)||D.storageError)return;var i=D.gear(a);if(!i||!i._codexCrownUid)return;
  safely(function(){
   var id=a.actorId(),itemId=i._codexCrownUid,key,serial;
   if(battle){
    serial=(battle.deathSerial[id]||0)+1;battle.deathSerial[id]=serial;key=id+':'+serial+':'+itemId;
    if(profile().battles[battle.key].deaths[key])return;
    transaction(function(p){p.battles[battle.key].deaths[key]=true;var r=p.items[itemId];if(r&&!r.removed)r.bonus*=0.5;});
   }else{
    serial=num($gameSystem._codexCrownWorldDeathSeq);key='w:'+serial+':'+id+':'+itemId;
    $gameSystem._codexCrownWorldDeathSeq=serial+1;
    if(profile().worldDeaths[key])return;
    transaction(function(p){p.worldDeaths[key]=true;var r=p.items[itemId];if(r&&!r.removed)r.bonus*=0.5;});
   }
  });
 }
 wrap(Game_Battler.prototype,'addNewState',function(old,args){
  var id=args[0],before=id===this.deathStateId()&&!this.isDeathStateAffected(),out=old.apply(this,args);
  if(before&&this.isDeathStateAffected())death(this);return out;
 });
 ['changeEquip','forceChangeEquip','discardEquip'].forEach(function(k){wrap(Game_Actor.prototype,k,function(old,args){
  var out=old.apply(this,args);if(battle&&real(this)){var a=this,i=D.gear(a);battle.wears.forEach(function(x){if(x.actor===a.actorId()&&(!i||i._codexCrownUid!==x.uid))x.valid=false;});}return out;
 });});
 wrap(Game_Actor.prototype,'tradeItemWithParty',function(old,args){trade++;try{return old.apply(this,args);}finally{trade--;}});
 wrap(Game_Party.prototype,'gainItem',function(old,args){
  var i=args[0],count=num(args[1]);if(this!==W.$gameParty||mutating||!D.isGear(i))return old.apply(this,args);
  if(count>0&&!i.baseItemId){var got=[];for(var n=0;n<count;n++){var g=D.grant();if(g)got.push(g);}return got;}
  if(count<0&&!trade&&i._codexCrownUid&&(this.numItems(i)>0||args[2]&&this.checkItemIsEquipped(i))){
   var success=safely(function(){transaction(function(p){var r=p.items[i._codexCrownUid];if(r)r.removed=true;});return true;});
   return success;
  }
  return old.apply(this,args);
 });
 wrap(BattleManager,'setup',function(old,args){battle=null;return old.apply(this,args);});
 wrap(BattleManager,'startBattle',function(old,args){begin();return old.apply(this,args);});
 wrap(BattleManager,'endBattle',function(old,args){var out=old.apply(this,args);finish(args[0]);return out;});
 wrap(DataManager,'setupNewGame',function(old,args){
  ledger=null;battle=null;legacyKey=null;D.storageError=null;var out=old.apply(this,args);
  $gameSystem._codexCrownEncounterSeq=0;$gameSystem._codexCrownWorldDeathSeq=0;safely(profile);return out;
 });
 wrap(DataManager,'extractSaveContents',function(old,args){
  ledger=null;battle=null;D.storageError=null;legacyKey='legacy:'+hash(JsonEx.stringify(args[0]));mutating=true;
  var out;try{out=old.apply(this,args);}finally{mutating=false;}
  safely(function(){profile();adopt();replay();});return out;
 });
 wrap(DataManager,'makeSaveContents',function(old,args){if(!mutating&&!D.storageError)safely(function(){adopt();replay();});return old.apply(this,args);});
 if(W.RJO&&RJO.HE)wrap(RJO.HE,'getDescParams',function(old,args){
  var i=args[0];if(D.isGear(i))describe(i);var out=old.apply(this,args);
  if(D.isGear(i)&&i.descParams)i.descParams.forEach(function(r){if(typeof r[0]==='string')r[0]=r[0].replace(/[-+]?\d+\.\d+/g,function(v){return D.display(v);});});
  return out;
 });
 // 【Codex·未经Claude检验】v0.13 Rebuild invalidated crown help before native equip windows read it.
 // describe()/ledger replay intentionally invalidates help; both windows require an array.
 [W.Window_ShopInfo,W.Window_ItemStatus].forEach(function(WindowClass){
  if(!WindowClass)return;
  wrap(WindowClass.prototype,'drawEquipInfo',function(old,args){
   var item=args[0];
   if(D.isGear(item)&&!Array.isArray(item.descParams)&&W.RJO&&RJO.HE&&typeof RJO.HE.getDescParams==='function')RJO.HE.getDescParams(item,2);
   return old.apply(this,args);
  });
 });
 if(W.CodexQualityIcons){
  wrap(CodexQualityIcons,'lookup',function(old,args){return Number(args[0])===D.iconIndex?{demonCrownArt:true,item:W.$dataArmors&&$dataArmors[D.armorId],source:0}:old.apply(this,args);});
  wrap(CodexQualityIcons,'bitmap',function(old,args){
   if(!args[0]||!args[0].demonCrownArt)return old.apply(this,args);
   var b=ImageManager.loadSystem('Codex_DemonCrown');if(!b.isReady()){b.addLoadListener(args[1]||function(){});return null;}return b;
  });
 }
 // No public cheat setter or test-only reward rates are exposed in production.
 return D;
});
