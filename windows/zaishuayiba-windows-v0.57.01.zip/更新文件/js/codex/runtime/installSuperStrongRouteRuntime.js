// 【Claude·未经Codex检验】v0.14 超强者与强者路线压制（2026-10-14）。核查状态：未经Codex检验。
// 依据：design/framework/超强者与强者路线压制_方案_v0.1.md；用户 10-14 确认：灭世也压、强者「天灾以下」不含天灾、承伤与辅助型都做。
// 1. 分档系数按路线取值（五乘区修正与修行页同源）：超强者 洪荒+0.10、灭世+0.08、天灾+0.06、地狱+0.02；强者 普通／困难／地狱−0.02。
// 2. 超强者在天灾、地狱受到敌人的伤害 ×1.2、×1.5。
// 3. 超强者给「其他队友」的治疗、护盾、增益状态，天灾 ×0.8、地狱 ×0.5。超强者自身的部分由第 1、2 项负责，不重复压。
//    增益状态：属性、元素、承伤、终伤爆伤等数值按比例向「无效果」收缩；无敌、免疫、行动限制与脚本特效不变。
// 只改运行时计算，不写入额外存档数据以外的内容；增益来源标记随状态解除而清除。
window.CodexRuntime.register('installSuperStrongRouteRuntime', function() {
  'use strict';
  var W = window, K = W.CodexZones, D = W.CodexBossDifficulty;
  if (!K || !D || !K.classFactor) throw new Error('路线压制缺少五乘区或超强者名单');
  var LOW = {'弱者': -0.1, '强者': -0.02, '超强者': 0.02};
  var R = W.CodexRouteSuppress = {version: 1,
    BAND: {normal: LOW, hard: LOW, hell: LOW,
      calamity: {'弱者': -0.1, '强者': 0, '超强者': 0.06},
      doom: {'弱者': -0.1, '强者': 0, '超强者': 0.08},
      primordial: {'弱者': -0.1, '强者': 0, '超强者': 0.10}},
    TAKEN: {calamity: 1.2, hell: 1.5},
    SUPPORT: {calamity: 0.8, hell: 0.5},
    NAME: {normal: '普通', hard: '困难', hell: '地狱', calamity: '天灾', doom: '灭世', primordial: '洪荒'}};
  function num(v) { v = Number(v); return isFinite(v) ? v : 0; }
  function inBattle() { return !!(W.$gameParty && $gameParty.inBattle()); }
  function isActor(b) { return !!(b && b.isActor && b.isActor()); }
  // 路线由开局开关决定。状态列表等高频路径会反复读取：开关对象不变、路线开关没被改写时复用上次结果。
  var ROUTE_SWITCHES = [2483, 2463, 2487, 2462, 2489, 2461, 2494, 2500], routeMemo = {sw: null, key: 'primordial'};
  R.route = function() {
    var Z = W.CodexZhenqi, sw = W.$gameSwitches || null;
    if (sw && routeMemo.sw === sw) return routeMemo.key;
    routeMemo.key = Z && Z.route ? Z.route().key : 'primordial'; routeMemo.sw = sw;
    return routeMemo.key;
  };
  var setSwitch = Game_Switches.prototype.setValue;
  Game_Switches.prototype.setValue = function(id) { if (ROUTE_SWITCHES.indexOf(Number(id)) >= 0) routeMemo.sw = null; return setSwitch.apply(this, arguments); };
  R.band = function(cls, route) { var t = R.BAND[route || R.route()] || R.BAND.primordial; return t[cls] !== undefined ? t[cls] : 0; };
  R.taken = function() { return R.TAKEN[R.route()] || 1; };
  R.support = function() { return R.SUPPORT[R.route()] || 1; };
  R.isSuper = function(b) { return isActor(b) && D.isSuperStrong(b); };
  // 给「其他角色」的支援才压；同一角色（含持武、附身用的代理对象）不算
  R.otherScale = function(source, target) {
    if (!inBattle() || !R.isSuper(source) || !isActor(target) || target.actorId() === source.actorId()) return 1;
    return R.support();
  };
  R.actingSubject = function() { return inBattle() && W.BattleManager ? BattleManager._subject : null; };
  function toward(r, k) { return 1 + (num(r) - 1) * k; }

  // ---- 1. 分档系数 ----
  K.classFactor = function(cls, floor) { return Math.exp(R.band(cls) * K.totalRef(Math.max(1, floor || 1))); };

  // ---- 2. 承伤、3a. 技能治疗 ----
  (W.CodexDamageHooks = W.CodexDamageHooks || []).push({name: 'route-suppress', build: function(action, target, f) {
    if (f.options && f.options.reference) return;
    var a = f.subject, type = f.item && f.item.damage ? f.item.damage.type : 0;
    if (type === 3 || type === 4) {
      var k = R.otherScale(a, target);
      if (k !== 1) { f.healingMultiplier *= k; f.origins.push('路线压制·治疗 ×' + k); }
      return;
    }
    if (R.isSuper(target) && a && a.isEnemy && a.isEnemy()) {
      var t = R.taken();
      if (t !== 1) { f.incomingMultiplier *= t; f.origins.push('路线压制·承伤 ×' + t); }
    }
  }});

  // ---- 3b. 效果栏回复（HP／MP）----
  ['itemEffectRecoverHp', 'itemEffectRecoverMp'].forEach(function(name) {
    var old = Game_Action.prototype[name];
    Game_Action.prototype[name] = function(target, effect) {
      var k = R.otherScale(this.subject(), target);
      if (k !== 1) effect = {code: effect.code, dataId: effect.dataId, value1: num(effect.value1) * k, value2: num(effect.value2) * k};
      return old.call(this, target, effect);
    };
  });

  // ---- 3c. 护盾：原生护盾（技能公式 b.addShield）、谷雨／璇／屠苏 ----
  var addShield = Game_Battler.prototype.addShield;
  if (addShield) Game_Battler.prototype.addShield = function(value) {
    var k = R.otherScale(R.actingSubject(), this);
    return addShield.call(this, k !== 1 ? Math.floor(num(value) * k) : value);
  };
  var L = W.CodexShieldLedger;
  if (L && L.grant) {
    var grant = L.grant;
    // 只压谷雨的新护盾；璇、屠苏在各自的护盾量函数里压，避免移光等迁移再压一次
    L.grant = function(target, source, amount, turns, owner, opts) {
      if (source === 'guyu.shield' && owner) {
        var k = R.otherScale($gameActors.actor(owner), target);
        if (k !== 1) amount = num(amount) * k;
      }
      return grant.apply(this, [target, source, amount, turns, owner, opts]);
    };
  }
  var X = W.CodexXuan, T = W.CodexTusu;
  if (X) {
    if (X.shieldAmount) { var xs = X.shieldAmount; X.shieldAmount = function(a, t) { return xs.apply(this, arguments) * R.otherScale(a, t); }; }
    // 共宿：宿主获得的直接伤害增益与双防
    if (X.hostDamageRate) { var xh = X.hostDamageRate; X.hostDamageRate = function(t) { var r = xh.apply(this, arguments); return inBattle() && r > 0 ? r * R.support() : r; }; }
    if (X.gongsuDefenseRate) { var xg = X.gongsuDefenseRate; X.gongsuDefenseRate = function(a) { var r = xg.apply(this, arguments); return inBattle() && R.isSuper(a) ? r * R.support() : r; }; }
  }
  if (T) {
    if (T.shieldAmount) { var ts = T.shieldAmount; T.shieldAmount = function(a, t) { return ts.apply(this, arguments) * R.otherScale(a, t); }; }
    // 锁定、和鸣（持武者增伤）与护阵（持武者减伤）都是给其他队友的效果
    ['lockRate', 'hemingRate', 'huzhenRate'].forEach(function(n) {
      if (!T[n]) return; var old = T[n];
      T[n] = function(a) { var r = old.apply(this, arguments); return inBattle() && R.isSuper(a) ? toward(r, R.support()) : r; };
    });
  }

  // ---- 3d. 增益状态：超强者行动中施加给其他队友的状态，按比例收缩数值 ----
  var cache = new Map();
  var PASSIVE = /<((?:De)?passive(?:HarmRi|CrHarmRi|HarmRe\d+|ELUP\d+))(\s*:\s*)([+-]?\d+(?:\.\d+)?)(\s*%?\s*)>/gi;
  var AMPLIFY = /<(Element Amplify \d+)(\s*:\s*)([+-]?\d+(?:\.\d+)?)(%\s*)>/gi;
  function round4(v) { return Math.round(v * 10000) / 10000; }
  function scaleMap(obj, fn) { if (!obj || typeof obj !== 'object') return obj; var out = Array.isArray(obj) ? obj.slice() : Object.assign({}, obj); Object.keys(out).forEach(function(k) { if (typeof out[k] === 'number') out[k] = fn(out[k]); }); return out; }
  function scaleTrait(t, k) {
    if ([11, 12, 13, 21, 23].indexOf(t.code) >= 0) return {code: t.code, dataId: t.dataId, value: toward(t.value, k)};
    if (t.code === 22 || t.code === 61) return {code: t.code, dataId: t.dataId, value: num(t.value) * k};
    return t;
  }
  R.scaledState = function(s, k) {
    var key = s.id + '|' + k, c = cache.get(key);
    if (c) return c;
    c = Object.assign({}, s);
    c.traits = (s.traits || []).map(function(t) { return scaleTrait(t, k); });
    c.note = String(s.note || '').replace(PASSIVE, function(_, n, sep, v, tail) { return '<' + n + sep + round4(num(v) * k) + tail + '>'; })
      .replace(AMPLIFY, function(_, n, sep, v, tail) { var x = round4(num(v) * k); return '<' + n + sep + (x >= 0 ? '+' : '') + x + tail + '>'; });
    DataManager.extractMetadata(c);
    var add = function(v) { return v * k; }, rate = function(v) { return toward(v, k); };
    if (s.elementAmplify) c.elementAmplify = scaleMap(s.elementAmplify, add);
    if (s.elementAmplifyN) c.elementAmplifyN = scaleMap(s.elementAmplifyN, add);
    if (s.elementMagnify) c.elementMagnify = scaleMap(s.elementMagnify, rate);
    if (s.plusXParams) c.plusXParams = scaleMap(s.plusXParams, add);
    if (s.flatXParams) c.flatXParams = scaleMap(s.flatXParams, add);
    if (s.rateXParams) c.rateXParams = scaleMap(s.rateXParams, rate);
    if (typeof s.critMultBonus === 'number') c.critMultBonus = s.critMultBonus * k;
    if (typeof s.flatCritBonus === 'number') c.flatCritBonus = s.flatCritBonus * k;
    c._codexRouteScale = k;
    cache.set(key, c);
    return c;
  };
  // 状态列表读取极频繁：原列表（krz 缓存）与标记都没变时复用上次的结果；缓存只在内存，不进存档。
  var states = Game_Actor.prototype.states, views = new WeakMap(), serial = 0;
  function touched() { serial++; }
  function sameList(a, b) { if (a === b) return true; if (!a || a.length !== b.length) return false; for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return false; return true; }
  Game_Actor.prototype.states = function() {
    var list = states.apply(this, arguments), m = this._codexRouteStates;
    if (!m || !inBattle()) return list;
    var k = R.support();
    if (k === 1) return list;
    var v = views.get(this);
    if (v && v.k === k && v.serial === serial && sameList(v.src, list)) return v.out;
    var out = list.map(function(s) { return s && m[s.id] && !s._codexRouteScale ? R.scaledState(s, k) : s; });
    views.set(this, {src: list.slice(), k: k, serial: serial, out: out});
    return out;
  };
  // 先记来源再交给原流程，原流程里的被动缓存刷新就能读到收缩后的状态；没加上则恢复原记录。
  // 只标记我方角色；真气等模块在 Game_Actor 上有自己的 addState／eraseState，所以包在 Game_Actor 上。
  var A = Game_Actor.prototype, addState = A.addState;
  A.addState = function(stateId) {
    if (!inBattle()) return addState.apply(this, arguments);
    var src = R.actingSubject(), m = this._codexRouteStates, prior = m ? m[stateId] : undefined, mark;
    if (R.otherScale(src, this) !== 1) mark = src.actorId();
    else if (src) mark = 0;
    if (mark !== undefined) { if (mark) (this._codexRouteStates = m || {})[stateId] = mark; else if (m) delete m[stateId]; touched(); }
    var outer = adding, out;
    adding = mark ? stateId : 0;
    try { out = addState.apply(this, arguments); } finally { adding = outer; }
    if (mark !== undefined && !this.isStateAffected(stateId)) {
      if (prior !== undefined) (this._codexRouteStates = this._codexRouteStates || {})[stateId] = prior;
      else if (this._codexRouteStates) delete this._codexRouteStates[stateId];
      touched();
    } else if (mark !== prior && (mark || prior) && K.invalidate) K.invalidate(this);
    return out;
  };
  // 原流程在加状态时可能先擦除再重加（重叠规则），这期间不清除刚记下的来源。
  var adding = 0, erase = A.eraseState;
  A.eraseState = function(stateId) {
    var m = this._codexRouteStates;
    if (m && m[stateId] !== undefined && adding !== stateId) { delete m[stateId]; if (!Object.keys(m).length) delete this._codexRouteStates; touched(); }
    return erase.apply(this, arguments);
  };
  // 被动缓存在战斗中按状态增量加减（dsPassiveSkill 移除时读 $dataStates）；移除带来源标记的状态时，
  // 减去的是收缩后的数值，与全量重建时计入的数值一致。
  var removeState = A.removeState;
  A.removeState = function(stateId) {
    var m = this._codexRouteStates, k = R.support(), base = W.$dataStates && $dataStates[stateId];
    if (!m || !m[stateId] || !inBattle() || k === 1 || !base) return removeState.apply(this, arguments);
    $dataStates[stateId] = R.scaledState(base, k);
    try { return removeState.apply(this, arguments); } finally { $dataStates[stateId] = base; }
  };
  var clear = A.clearStates;
  A.clearStates = function() { if (this._codexRouteStates) { delete this._codexRouteStates; touched(); } return clear.apply(this, arguments); };
  return R;
});
