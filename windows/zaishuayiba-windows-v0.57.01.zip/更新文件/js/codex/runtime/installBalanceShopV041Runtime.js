// 【Codex·未经Claude检验】v0.41 explicit legacy cleanup, shop policy and native ownership checks.
window.CodexRuntime.register('installBalanceShopV041Runtime',function(){
 'use strict';var W=window,R=W.CodexBalance41={version:41};
 function alias(o,k,f){var old=o&&o[k];if(typeof old==='function')o[k]=function(){return f.call(this,old,arguments);};}
 function real(i){return W.CodexAbyssMerchant?CodexAbyssMerchant.real(i):i;}
 R.findWeapon=function(actor){var id=actor.actorId();return $gameParty.weapons().concat(($gameActors._data||[]).filter(Boolean).reduce(function(out,a){return out.concat((a._equips||[]).map(function(e){return e.object();}).filter(Boolean));},[])).some(function(i){i=real(i);return i&&DataManager.isWeapon(i)&&CodexAbyssMerchant.absorbOwners(i).indexOf(id)>=0;});};
 var ownership=new WeakMap(),ownershipRevision=0;
 R.hasWeapon=function(a){var cached=ownership.get($gameParty);if(!cached||cached.revision!==ownershipRevision){cached={revision:ownershipRevision,actors:{}};ownership.set($gameParty,cached);}var id=a.actorId();if(cached.actors[id]===undefined)cached.actors[id]=R.findWeapon(a);return cached.actors[id];};
 [Game_Party.prototype,Game_Item.prototype].forEach(function(p){['gainItem','registerNewItem','removeIndependentItem','setObject'].forEach(function(k){alias(p,k,function(old,args){ownershipRevision++;return old.apply(this,args);});});});
 alias(Game_Actor.prototype,'skills',function(old,args){var out=old.apply(this,args);return out.filter(function(s){return !(this.actorId()===163&&s.id===10169)&&!(s.id===10455&&!R.hasWeapon(this));},this);});
 alias(Game_Actor.prototype,'learnSkill',function(old,args){if(this.actorId()===163&&Number(args[0])===10169)return;return old.apply(this,args);});
 R.normalizeSword=function(i){if(!i||i.wtypeId===undefined||Number(i.originalBaseItemId||i.baseItemId||i.id)!==89||i._codexZhuxianWeapon41===41)return false;
  var n=0;i.traits=(i.traits||[]).filter(function(t){if(t.code===21&&t.dataId===0&&t.value===10&&n<2){n++;return false;}return true;});
  i.note=String(i.note||'').replace(',生命值+2000%','').replace('专属技能伤害+1000%','专属技能伤害+100%');i._codexZhuxianWeapon41=41;delete i.descParams;if(W.CodexAbyssMerchant)CodexAbyssMerchant.touch();return true;
 };
 R.normalizeRelic=function(i){
  if(!i||i.atypeId===undefined||Number(i.originalBaseItemId||i.baseItemId||i.id)!==123||i._codexZhuxianRelic41===41)return false;
  if(W.CodexImportedEffects)CodexImportedEffects.normalize(i);
  var old=[150,50,50,10,10,10,10,10];
  if(i.paramPlusPerLevel)i.paramPlusPerLevel=i.paramPlusPerLevel.map(function(v,p){return v+18-old[p];});
  i.note=String(i.note||'').replace(/<(mhp|mmp|atk|mat|def|mdf|agi|luk) Param \+\d+ per Level>/gi,function(t,k){return '<'+k+' Param +18 per Level>';}).replace('法宝每级增加10全属性','法宝每级增加18全属性');
  i._codexZhuxianRelic41=41;delete i.descParams;return true;
 };
 R.syncActors=function(){(DataManager._independentWeapons||[]).forEach(R.normalizeSword);(DataManager._independentArmors||[]).forEach(R.normalizeRelic);($gameActors._data||[]).forEach(function(a){if(!a)return;if(a.actorId()===163)a.forgetSkill(10169);if(a.actorId()===162){var prior=a.isLearnedSkill(9997);if(prior)a.forgetSkill(9997);if(prior||a.level>=60)a.learnSkill(10512);}CodexQiyuBalance.refreshActor(a);});};
 alias(DataManager,'extractSaveContents',function(old,args){ownershipRevision++;R.repairSavedParams(args[0]);var out=old.apply(this,args);R.syncActors();return out;});
 // Unlimited only at user-requested shops. Other vendors retain their existing inventory limits.
 R.passiveBook=function(i){return !!(i&&DataManager.isItem(i)&&((i.effects||[]).some(function(e){return e.code===43&&$dataSkills[e.dataId]&&($dataSkills[e.dataId].stypeId===4||$dataSkills[e.dataId].stypeId===6&&/<Hide in Battle>/i.test($dataSkills[e.dataId].note||''));})||/被动书/.test(i.name)));};
 R.leftBought=function(){if($gameSystem._codexLeftBought41===undefined){var consumed=0;Object.keys($gameSystem._inventories||{}).forEach(function(k){var inv=$gameSystem._inventories[k],n=inv&&inv._itemStock&&inv._itemStock[1914];if(n!==undefined&&Number.isFinite(Number(n)))consumed+=Math.max(0,5-Number(n));});$gameSystem._codexLeftBought41=Math.min(8,consumed);}return $gameSystem._codexLeftBought41;};
 alias(Game_Interpreter.prototype,'command302',function(old,args){$gameTemp._codexShopPolicy41={pawn:this._mapId===204,chief:this._mapId===4&&this._eventId===54};try{return old.apply(this,args);}finally{$gameTemp._codexShopPolicy41=null;}});
 alias(Scene_Shop.prototype,'prepare',function(old,args){var ctx=$gameTemp._codexShopPolicy41||{},copy=Array.prototype.slice.call(args);copy[0]=(copy[0]||[]).map(function(g){g=g.slice();if(g[0]===0&&g[2]===1&&R.passiveBook($dataItems[g[1]]))g[3]=Math.ceil(g[3]*13/10);return g;});ctx.chiefPassive=!!(ctx.chief&&copy[0].some(function(g){return g[0]===0&&R.passiveBook($dataItems[g[1]]);}));var out=old.apply(this,copy),base=this._inventory;
  this._codexShopPolicy41={pawn:!!ctx.pawn,chief:!!ctx.chief};
  // KMS is optional per event branch. A facade supplies one global eight-book quota even in unstocked shops.
  var inv=base?Object.create(base):new Game_ShopInventory('__codexUnmanaged41');var nativeManaged=inv.isStockManaged,nativeStock=inv.getStock,nativeMax=inv.getStockMax;
  inv.isStockManaged=function(item){if(item&&item.id===1914&&DataManager.isItem(item))return true;if(ctx.pawn||ctx.chiefPassive||ctx.chief&&R.passiveBook(item))return false;return base?nativeManaged.call(this,item):false;};
  inv.getStock=function(item){return item&&item.id===1914&&DataManager.isItem(item)?Math.max(0,8-R.leftBought()):nativeStock.call(this,item);};
  inv.getStockMax=function(item){return item&&item.id===1914&&DataManager.isItem(item)?8:nativeMax.call(this,item);};
  var lose=inv.loseStock;inv.loseStock=function(item,n){if(item&&item.id===1914&&DataManager.isItem(item))return;return lose.call(this,item,n);};
  var gain=inv.gainStock;inv.gainStock=function(item,n){if(item&&item.id===1914&&DataManager.isItem(item))return;return gain.call(this,item,n);};
  this._inventory=inv;return out;});
 alias(Scene_Shop.prototype,'doBuy',function(old,args){var n=Number(args[0]),left=this._item&&this._item.id===1914&&DataManager.isItem(this._item);if(left&&(n>8-R.leftBought()||n<=0))return;var out=old.apply(this,args);if(left)$gameSystem._codexLeftBought41=R.leftBought()+n;return out;});
 // Star's shared random buffer may have five draws left while an eight-stat roll needs eight.
 R.ensureStatRandom=function(base,item){
  if(!base||base.randomVariance<0||!item||!Array.isArray(item.params))return;
  var need=item.params.slice(0,8).filter(function(v){return v!==0;}).length,p=$gameParty,pool=p.RomDreamX||[],at=p.RomDreamXNum||0,len=Star.RomGetItems.RomLength;
  if(pool.length===len&&at<=Star.RomGetItems.RomLengthRef&&(at+need>pool.length||pool.slice(at,at+need).some(function(v){return !Number.isFinite(v);}))) {
   p.RomDreamX=Array.from({length:len},function(){return Math.random();});p.RomDreamXNum=0;
  }
 };
 alias(ItemManager,'randomizeInitialStats',function(old,args){R.ensureStatRandom(args[0],args[1]);return old.apply(this,args);});
 // JSON converts NaN to null. Restore only invalid white stats from the native base;
 // the lost random roll cannot be inferred, so no replacement roll is invented.
 R.repairSavedParams=function(contents){
  if(!contents)return [];
  var repaired=[];['weapons','armors'].forEach(function(k){var db=k==='weapons'?$dataWeapons:$dataArmors;(contents[k]||[]).forEach(function(i){
   if(!i||!Array.isArray(i.params))return;var b=db[Number(i.originalBaseItemId||i.baseItemId||0)];if(!b||!Array.isArray(b.params))return;
   var changed=[];for(var n=0;n<8;n++)if(i.params[n]===null||i.params[n]===undefined||!Number.isFinite(i.params[n])){i.params[n]=Number.isFinite(b.params[n])?b.params[n]:0;changed.push(n);}
   if(changed.length){delete i.descParams;repaired.push({kind:k,id:i.id,stats:changed});}
  });});R.lastParamRepairs=repaired;return repaired;
 };
 return R;
});
