// 【Codex·未经Claude检验】v0.05 五乘区语义缓存；未经claude检验。
// 【Claude·未经Codex检验】v0.07 手机性能：同一次行动复用修正值，画像副本共用一次序列化；修正公式不变。
// 【Claude·未经Codex检验】黄泉卡顿第二轮：画像副本不复制krz状态列表缓存（副本内按_states重建），修正公式不变。
// 五乘区记账（战力框架重制 P1，2026-10-09）＋ P2 预算软上限（用户选方案 B：只压超出部分）＋ P3 装备品阶倍率与分档系数（用户 10-09 确认，与 P2 同时生效）：按来源把角色的伤害乘区归到
// 装备、人物自身（含法宝）、外部、真气、难度补偿五类，另列难度。不改任何伤害（P2 才按预算修正）。
// 口径（设计稿 v0.3）：
// - 属性：在副本上逐类拿掉来源，看物攻/魔攻掉多少；攻防比值的影响按「攻÷(攻＋防)」的弹性计入（参照当前层守层者的防御）。
// - 终伤、爆伤、元素增伤（加算池）：池子的倍率按各类在池中的数值比例分到各类（对数按比例拆分，乘回去等于原倍率）。
// - 结算（确认效果 value*k）：归到推送该状态的来源所在的类。
// - 熟练度、法宝：人物自身；真气加成：真气；天道补偿：难度补偿。
// - 角色专属机制的伤害钩子（变身、形态等）在动作中生效，静态面板不计，归人物自身并注明。
window.CodexRuntime.register('installNativePowerZonesRuntime',function(){
 'use strict';
 var K=window.CodexZones={version:1,ZONES:['装备','人物自身','外部','真气','难度补偿'],
  TARGET:{'弱者':{'装备':.4,'人物自身':.1,'外部':.2,'真气':.1,'难度补偿':.1},'强者':{'装备':.4,'人物自身':.2,'外部':.2,'真气':.1,'难度补偿':.1},'超强者':{'装备':.4,'人物自身':.3,'外部':.2,'真气':.1,'难度补偿':.1}}};
 var SELF_EXTRA=[5968,5969,5970,5971,5972,5973,6216,6241];
 function num(v){v=Number(v);return isFinite(v)?v:0;}
 function difficultyIds(){var G=window.CodexGuide,ids=(G&&G.difficultySkillIds)||[];return ids.filter(function(id){return SELF_EXTRA.indexOf(id)<0;});}
 K.classOf=function(actor){var D=window.CodexBossDifficulty,id=actor.actorId();if(D&&D.superStrongIds&&D.superStrongIds.indexOf(id)>=0)return '超强者';if(D&&D.strongIds&&D.strongIds.indexOf(id)>=0)return '强者';return '弱者';};
 var advCache=null;
 function advancedSkills(actorId){
  if(!advCache){advCache={};var pp=PluginManager.parameters('Star_ActorAdvanced')||{};Object.keys(pp).forEach(function(k){if(!/^Advanced \d+$/.test(k)||!pp[k])return;try{var o=JSON.parse(pp[k]),id=num(o.AdvancedActId);JSON.parse(o.AdvancedSkiId||'[]').forEach(function(s){(advCache[id]=advCache[id]||{})[num(s)]=1;});}catch(e){}});}
  return advCache[actorId]||{};}
 // 技能归类
 K.skillZone=function(actor,s){
  if(!s)return null;var note=s.note||'';
  if(/<CodexZhenqi:/.test(note))return '真气';
  if(SELF_EXTRA.indexOf(s.id)>=0)return '人物自身';
  if(difficultyIds().indexOf(s.id)>=0)return '难度';
  var cls=$dataClasses[actor.currentClass().id],learn=(cls&&cls.learnings||[]).some(function(l){return l.skillId===s.id;});
  if(learn||advancedSkills(actor.actorId())[s.id]||/^天赋:/.test(s.name||''))return '人物自身';
  if((s.occasion===0||s.occasion===1)&&!/<Hide in Battle>/i.test(note))return null; // 主动技能本身不算乘区
  return '外部';};
 K.equipZone=function(actor,i){var et=actor.equipSlots()[i];return ($dataSystem.equipTypes[et]||'')==='法宝'?'人物自身':'装备';};
 // 状态来源：被谁推送就归谁；没人推送的常驻状态算外部（破阵、挑战奖励等），战斗中的临时状态算人物自身
 function pushedBy(actor){var map={};
  function scan(o,zone){if(!o||!zone)return;var m,re=/<Start(?:WT)?PushState(\d+):\s*\d+%>/gi;while((m=re.exec(o.note||'')))if(!map[num(m[1])])map[num(m[1])]=zone;}
  actor.equips().forEach(function(e,i){if(e)scan(e,K.equipZone(actor,i));});
  actor.skills().forEach(function(s){scan(s,K.skillZone(actor,s));});
  return map;}
 K.stateZone=function(actor,st,map){map=map||pushedBy(actor);if(map[st.id])return map[st.id];return st.removeAtBattleEnd||st.autoRemovalTiming?'人物自身':'外部';};
 // 各类来源的对象清单
 function objectsByZone(actor){
  var out={},map=pushedBy(actor);function add(z,o){if(!z||!o)return;(out[z]=out[z]||[]).push(o);}
  actor.equips().forEach(function(e,i){if(e)add(K.equipZone(actor,i),e);});
  actor.skills().forEach(function(s){add(K.skillZone(actor,s),s);});
  actor.states().forEach(function(st){add(K.stateZone(actor,st,map),st);});
  return {objects:out,pushed:map};}
 function sumTag(objs,re){return (objs||[]).reduce(function(t,o){var m,r=new RegExp(re.source,'gi'),v=0;while((m=r.exec(o.note||'')))v+=num(m[1]);return t+v;},0);}
 // 加算池拆分：先由正值来源把池子从 base 抬到 base＋P（按各自数值比例分对数），再由负值来源压到实际值（同样按比例）。
 // 乘回去等于实际倍率；正负几乎抵消时也不会出现极端值。floor 为池子下限（爆伤 1、终伤 0）。
 function splitPool(base,sums,floor){var P=0,N=0,out={};Object.keys(sums).forEach(function(z){if(sums[z]>0)P+=sums[z];else if(sums[z]<0)N-=sums[z];});
  var top=base+P,M=Math.max(floor===undefined?1e-9:Math.max(1e-9,floor),base+P-N);
  if(P>0){var up=Math.log(top/base);Object.keys(sums).forEach(function(z){if(sums[z]>0)out[z]=Math.exp(up*sums[z]/P);});}
  if(N>0){var down=Math.log(M/top);Object.keys(sums).forEach(function(z){if(sums[z]<0)out[z]=Math.exp(down*(-sums[z])/N);});}
  return {M:M/base,parts:out};}
 // 属性：副本上逐类拿掉。行动主体可能是以真实角色为原型的代理对象（如持握屠苏出招），深拷贝只复制自身属性，
 // 所以先沿原型链找到真正持有 _skills 的角色再复制。
 function actorOwner(actor){var src=actor;while(src&&!Object.prototype.hasOwnProperty.call(src,'_skills'))src=Object.getPrototypeOf(src);return src&&src!==Object.prototype?src:actor;}
 // krz_state_re 的 _statescache2／_statelist 只是 states()／typestates() 的缓存，内含整份状态数据的拷贝，
 // 占角色序列化的大半。副本不带这两项，并标记需重建，副本内的状态列表按 _states 重新取得。
 var STATE_CACHES=['_statescache2','_statelist'];
 function withoutStateCaches(o){var s=Object.create(Object.getPrototypeOf(o));Object.keys(o).forEach(function(k){if(STATE_CACHES.indexOf(k)<0)s[k]=o[k];});return s;}
 function rebuiltCaches(c){c.need_refresh_states=true;c.need_refreshstatelist=undefined;return c;}
 function cloneActor(actor){var owner=actorOwner(actor);return cloneSource&&cloneSource.owner===owner?rebuiltCaches(JsonEx.parse(cloneSource.raw)):JsonEx.makeDeepCopy(owner);}
 function statOf(copy,id){['refreshPassiveSkillCache','initPassiveCache','refreshPassiveCache'].forEach(function(f){if(copy[f])copy[f]();});copy.refresh();return Math.max(1,num(copy.param(id)));}
 // 注意：菜单里没有开战推送的状态（装备开局状态、难度状态等），菜单画像只是估算；战斗中的画像才准，修行页优先显示最近一场战斗
 function strip(actor,zones){
  var c=cloneActor(actor),map=pushedBy(actor);
  c.equips().forEach(function(e,i){if(e&&zones.indexOf(K.equipZone(actor,i))>=0)c._equips[i].setObject(null);});
  c.skills().forEach(function(s){var z=K.skillZone(actor,s);if(z&&zones.indexOf(z)>=0)c.forgetSkill(s.id);});
  c.states().forEach(function(st){if(zones.indexOf(K.stateZone(actor,st,map))>=0)c.eraseState(st.id);});
  if(zones.indexOf('外部')>=0){c._paramPlus=[0,0,0,0,0,0,0,0];c.pushattribute=[];c._codexPills={};}
  return c;}
 K.referenceDefense=function(){var Z=window.CodexZhenqi,f=Z?Math.max(1,Z.progressFloor()):1,tid=0;
  if(Z)Object.keys(Z.GUARDIANS).forEach(function(t){if(Z.GUARDIANS[t]===f&&num(t)!==245)tid=num(t);});
  var tr=tid&&$dataTroops[tid],e=tr&&tr.members[0]&&new Game_Enemy(tr.members[0].enemyId,0,0);return e?{def:num(e.def),mdf:num(e.mdf),floor:f}:{def:0,mdf:0,floor:f};};
 // 五个副本来自同一角色状态：只序列化一次，再分别解析，结果与逐次深拷贝相同。
 var cloneSource=null;
 function statZones(actor,paramId,defense){
  var owner=actorOwner(actor);cloneSource={owner:owner,raw:JsonEx.stringify(withoutStateCaches(owner))};
  try{
  var now=statOf(cloneActor(actor),paramId),zs=['装备','人物自身','外部'],drop={},base=statOf(strip(actor,zs),paramId);
  zs.forEach(function(z){drop[z]=Math.max(0,now-statOf(strip(actor,[z]),paramId));});
  }finally{cloneSource=null;}
  var rate=function(a){return CodexDamage.defenseRate(a,defense);},L=Math.log(now*rate(now))-Math.log(base*rate(base)),T=zs.reduce(function(t,z){return t+drop[z];},0),out={};
  zs.forEach(function(z){if(T>0&&drop[z])out[z]=Math.exp(L*drop[z]/T);});
  return {now:now,base:base,parts:out};}
 // 结算：开局推送与身上状态的 value*k
 function settlementZones(actor,objs){
  var out={},seen={},map=objs.pushed;
  function add(id,zone){if(seen[id]||!zone)return;seen[id]=1;var st=$dataStates[id],k=st&&/<Custom Confirm Effect>[\s\S]*?value\s*\*\s*([\d.]+)[\s\S]*?<\/Custom Confirm Effect>/i.exec(st.note||'');if(k)out[zone]=(out[zone]||1)*num(k[1]);}
  Object.keys(map).forEach(function(id){add(num(id),map[id]);});
  actor.states().forEach(function(st){add(st.id,K.stateZone(actor,st,map));});
  return out;}
 function masteryRate(actor){var lv=Object.keys(actor._skillMasteryLevels||{}).map(function(k){return num(actor._skillMasteryLevels[k]);}).sort(function(a,b){return b-a;}).slice(0,5);
  var avg=lv.length?lv.reduce(function(a,b){return a+b;},0)/lv.length:0;return 1+0.1*avg;}
 // A refresh is not a semantic loadout change. Cache follows the values used
 // by profile, including resource conditions; cache metadata is never saved.
 // Keep long immutable note text out of the per-action JSON signature. Identity
 // tokens are invalidated by exact note equality and mutable numeric contents.
 // This preserves the previous cache's dependencies, including in-place edits.
 var objectTokens=new WeakMap(),tokenSerial=0;
 function objectToken(o,kind){if(!o)return null;
  var values=kind==='skill'?[o.id]:kind==='state'?[o.id,o.traits]:[o.id,o.params,o.traits,o.level,o.paramPlusPerLevel,o.passiveStates,o._codexHeartsteelHp,o._codexHeartsteelStacks,o._codexHubrisFame];
  var key=JSON.stringify(values),c=objectTokens.get(o),note=o.note;
  if(!c||c.kind!==kind||c.key!==key||c.note!==note){c={kind:kind,key:key,note:note,token:++tokenSerial};objectTokens.set(o,c);}return c.token;
 }
 function signature(actor){var Z=window.CodexZhenqi,gear=actor.equips(),skills=actor.skills(),states=actor.states(),objects=gear.concat(skills,states).filter(Boolean);
  var conditional=actor.actorId()>=167||objects.some(function(o){return /passive\w*(?:EX|INDM)|(?:hp|mp|tp)Rate|\.(?:hp|mp|tp)\b|Custom (?:Param|Passive)/i.test(o.note||'');});
  return JSON.stringify([actor.actorId(),actor.level,actor._AdvancedNum,actor._skills,skills.map(function(s){return objectToken(s,'skill');}),states.map(function(s){return objectToken(s,'state');}),gear.map(function(e){return objectToken(e,'gear');}),actor._states,actor._stateCounter,actor._buffs,actor._paramPlus,actor.pushattribute,actor._equipSuitsStateIDs,actor._codexZhenqi&&[actor._codexZhenqi.qi,actor._codexZhenqi.realm,actor._codexZhenqi.daofa],Z&&Z.route().key,Z&&Z.progressFloor(),actor._codexPills,actor._skillMasteryLevels,actor._codexRace,actor._codexRacePower,actor._garouForm,actor._garouEvolution,actor._codexRavenSoul,actor._codexRavenStage,actor._codexRavenMythTurns,actor._codexSukuna,actor._codexHubrisBuff,$gameParty.inBattle(),conditional?[actor.hp,actor.mp,actor.tp,$gameTroop.turnCount(),$gameVariables._data]:null]);}

 // 【Codex·未经Claude检验】F003：刷新真实角色同时使代理角色画像失效；缓存和修订号不写入存档。
 var cache=new WeakMap(),revisions=new WeakMap();
 K.invalidate=function(actor){if(!actor)return;var owner=actorOwner(actor);revisions.set(owner,(revisions.get(owner)||0)+1);};
 var refreshActor=Game_Actor.prototype.refresh;
 Game_Actor.prototype.refresh=function(){K.invalidate(this);return refreshActor.apply(this,arguments);};
 K.profile=function(actor,force){
  if(!actor||!actor.isActor||!actor.isActor())return null;
  if(window.CodexZhenqi)CodexZhenqi.data(actor);
  var sig=signature(actor),c=cache.get(actor);if(!force&&c&&c.sig===sig)return c.value;
  var objs=objectsByZone(actor),O=objs.objects,ref=K.referenceDefense(),phys=actor.atk>=actor.mat,stat=statZones(actor,phys?2:4,phys?ref.def:ref.mdf);
  var zones={},parts=[];function mul(z,f,what){if(!z||!(f>0)||f===1)return;zones[z]=(zones[z]||1)*f;parts.push({zone:z,what:what,factor:f});}
  Object.keys(stat.parts).forEach(function(z){mul(z,stat.parts[z],phys?'物攻（含攻防比值）':'魔攻（含攻防比值）');});
  var finalSums={},critSums={};['装备','人物自身','外部','真气','难度'].forEach(function(z){finalSums[z]=sumTag(O[z],/<passiveHarmRi:\s*([+-]?[\d.]+)%?>/)/100;critSums[z]=sumTag(O[z],/<passiveCrHarmRi:\s*([+-]?[\d.]+)%?>/)/100;});
  var fin=splitPool(1,finalSums,0);Object.keys(fin.parts).forEach(function(z){mul(z,fin.parts[z],'终伤');});
  var crit=splitPool(1.5,critSums,1);Object.keys(crit.parts).forEach(function(z){mul(z,crit.parts[z],'爆伤（按暴击）');});
  var best=0,bestE=0;for(var e=1;e<$dataSystem.elements.length;e++){var t=0;Object.keys(O).forEach(function(z){t+=sumTag(O[z],new RegExp('<passiveELUP'+('00'+e).slice(-2)+':\\s*([+-]?[\\d.]+)%?>'));});if(t>best){best=t;bestE=e;}}
  if(bestE){var elemSums={};Object.keys(O).forEach(function(z){elemSums[z]=sumTag(O[z],new RegExp('<passiveELUP'+('00'+bestE).slice(-2)+':\\s*([+-]?[\\d.]+)%?>'))/100;});var el=splitPool(1,elemSums,0);Object.keys(el.parts).forEach(function(z){mul(z,el.parts[z],'元素增伤（'+$dataSystem.elements[bestE]+'）');});}
  var set=settlementZones(actor,objs);Object.keys(set).forEach(function(z){mul(z,set[z],'结算倍率');});
  mul('人物自身',masteryRate(actor),'技能熟练度');
  var Z=window.CodexZhenqi;if(Z){mul('真气',Z.rate(actor),'真气加成');mul('难度补偿',Z.compFor(Z.route().key,Math.max(1,ref.floor)),'天道补偿');}
  var native=Object.assign({},zones),eq=K.equipQuality(actor);
  mul('装备',eq,'装备品阶（P3）');mul('人物自身',K.classFactor(K.classOf(actor),ref.floor),'分档系数（P3）');mul('人物自身',K.selfComp(actor),'角色补偿');
  var cls=K.classOf(actor),target=K.TARGET[cls],ref100=0,ln={};
  K.ZONES.forEach(function(z){ln[z]=Math.log(zones[z]||1);});
  var total=K.ZONES.reduce(function(t,z){return t+Math.max(0,ln[z]);},0);
  var value={actorId:actor.actorId(),cls:cls,zones:zones,native:native,equipQuality:eq,ln:ln,total:total,difficulty:zones['难度']||1,parts:parts,target:target,
   share:K.ZONES.reduce(function(o,z){o[z]=total?Math.max(0,ln[z])/total:0;return o;},{}),stat:stat,element:bestE,floor:ref.floor,physical:phys,
   note:'角色专属机制（变身、形态、追击等）的伤害钩子在动作中生效，未计入此面板，属人物自身。'};
  cache.set(actor,{sig:signature(actor),value:value});return value;};
 // ---- P2：四个共同乘区的进度预算与软上限（人物自身不设）----
 // 强者基准总量 T（对数）按路线与楼层插值；洪荒实测：33 层约 31、21 层约 20。其他路线没有参照存档，暂按洪荒（测试参数）。
 K.T_ANCHORS=[[1,2],[21,20],[33,31]];
 // P3：装备品阶倍率（每件已装备、法宝除外：×(1＋a×品质)）与分档系数（弱者 e^(−0.1T)、强者 1、超强者 e^(+0.1T)）。
 // a 原定 0.03；因同时取消原弱者/强者补强，按真实战斗复测（强者伤害中位数 ×1.19≈不变）标定为 0.04（10-09）。
 K.EQUIP_A=0.04;
 K.BAND={'弱者':-0.1,'强者':0,'超强者':0.1};
 K.equipQuality=function(actor){var f=1;actor.equips().forEach(function(e,i){if(!e||K.equipZone(actor,i)!=='装备')return;var m=/<quality\s*:\s*(\d+)>/i.exec(e.note||'');f*=1+K.EQUIP_A*(m?num(m[1]):0);});return f;};
 K.classFactor=function(cls,floor){return Math.exp((K.BAND[cls]||0)*K.totalRef(Math.max(1,floor||1)));};
 K.CAPPED=['装备','外部','真气','难度补偿'];
 K.ENABLED=true;
 K.totalRef=function(floor){var a=K.T_ANCHORS;if(floor<=a[0][0])return a[0][1];for(var i=1;i<a.length;i++)if(floor<=a[i][0]){var p=a[i-1],q=a[i];return p[1]+(q[1]-p[1])*(floor-p[0])/(q[0]-p[0]);}return a[a.length-1][1];};
 K.budget=function(zone,floor){var share=K.TARGET['强者'][zone];return Math.exp(share*K.totalRef(floor));};
 // 2026-10-10 收尾：外部溢出最多（毕业档超预算上万倍），超出部分改开立方；其余三类仍开平方。
 K.CAP_POWER={'外部':1/3};
 K.softCap=function(F,B,zone){return F>B?B*Math.pow(F/B,K.CAP_POWER[zone]||0.5):F;};
 // 人物自身按角色补偿（不设上限）：八重樱、奈叶自身机制偏弱（毕业档自身占比 8%、中期 5%），用户 10-10 同意破例补 ×5.0。
 K.SELF_COMP={92:5,108:5};
 K.selfComp=function(actor){return K.SELF_COMP[actor&&actor.actorId?actor.actorId():0]||1;};
 K.cap=function(actor,floor){
  var p=K.profile(actor);if(!p)return null;floor=Math.max(1,Math.min(33,floor||p.floor));
  var cf=K.classFactor(p.cls,floor),sc=K.selfComp(actor),z=Object.assign({},p.native);z['装备']=(z['装备']||1)*p.equipQuality;z['人物自身']=(z['人物自身']||1)*cf*sc;
  var rows={},c=p.equipQuality*cf*sc;K.CAPPED.forEach(function(k){var F=z[k]||1,B=K.budget(k,floor),E=K.softCap(F,B,k);rows[k]={actual:F,budget:B,effective:E};c*=E/F;});
  var eff={};K.ZONES.forEach(function(k){eff[k]=rows[k]?rows[k].effective:(z[k]||1);});var tot=K.ZONES.reduce(function(t,k){return t+Math.max(0,Math.log(eff[k]));},0);
  var share={};K.ZONES.forEach(function(k){share[k]=tot?Math.max(0,Math.log(eff[k]))/tot:0;});
  return {floor:floor,rows:rows,correction:c,classFactor:cf,selfComp:sc,zones:z,effective:eff,share:share,total:tot};};
 // 多段、连击与扩散都属于同一次行动：首段算出的修正值供本次行动其余各段使用，
 // 避免每段伤害都因HP／TP变化重算整套画像。只存在内存，不写入存档。
 var actionMemo=new WeakMap();
 K.correction=function(actor){
  if(!K.ENABLED||!actor||!actor.isActor||!actor.isActor())return 1;
  // 预算与分档系数按玩家进度（已到达的最高层），不按本场战斗所在层：回低层刷怪不会被额外压低
  // 修正只是估算倍率，出错时退回 ×1，不能让整次伤害计算失败
  var Z=window.CodexZhenqi,floor=Z?Math.max(1,Z.progressFloor()):1,r;
  var action=$gameParty.inBattle()&&BattleManager._action,owner=actorOwner(actor),memo=action&&actionMemo.get(action),hit=memo&&memo.get(owner);
  if(hit&&hit.floor===floor)return hit.value;
  try{r=K.cap(actor,floor);}catch(e){if(!K._warned){K._warned=1;console.warn('五乘区修正跳过：',e&&e.message);}return 1;}if(!r)return 1;
  if(action){if(!memo){memo=new Map();actionMemo.set(action,memo);}memo.set(owner,{floor:floor,value:r.correction});}
  if($gameParty.inBattle()){var p=K.profile(actor);actor._codexZonesLast={floor:floor,correction:r.correction,classFactor:r.classFactor,selfComp:r.selfComp,share:r.share,rows:Object.keys(r.rows).reduce(function(o,k){o[k]=[r.rows[k].actual,r.rows[k].effective];return o;},{}),zones:r.zones,difficulty:p.difficulty,top:p.parts.filter(function(x){return x.zone!=='难度';}).sort(function(x,y){return Math.abs(Math.log(y.factor))-Math.abs(Math.log(x.factor));}).slice(0,3).map(function(x){return [x.zone,x.what,x.factor];})};}
  return r.correction;};
 var _amd=Game_Action.prototype.applyMinimumDamage;
 Game_Action.prototype.applyMinimumDamage=function(value,baseDamage,target){
  return _amd.apply(this,arguments);};
 // 2026-10-10：五乘区修正改在伤害结算里、扣固定减伤之前乘（growthMultiplier）；参考预览不计
 (window.CodexDamageHooks=window.CodexDamageHooks||[]).push({name:'zones-correction',build:function(action,target,f){
  if(f.options&&f.options.reference)return;var a=f.subject;if(!a||!a.isActor||!a.isActor()||!target||!target.isEnemy||!target.isEnemy())return;
  var c=K.correction(a);if(c>0&&c!==1){f.growthMultiplier*=c;f.origins.push('五乘区修正 ×'+c.toPrecision(3));}}});
 return K;
});
