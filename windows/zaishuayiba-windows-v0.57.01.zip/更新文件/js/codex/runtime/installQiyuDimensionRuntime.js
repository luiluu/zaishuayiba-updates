// 【Codex·未经Claude检验】v0.41 删除失效异次元被动，不再自动补回。
// 【Codex·未经Claude检验】v0.25 琦玉旧档与法宝迁移；未经claude检验。
window.CodexRuntime.register("installQiyuDimensionRuntime", function() {
  var Q=window.CodexQiyuBalance={revision:25,actorId:163,armorId:124};
  var linePairs=[["<pos=APs text=\\c[1]特效：所有属性*101% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]效果：所有属性×1.1 size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：法宝每级增加10全属性 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]效果：法宝每级全属性+18 size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：所有专属技能伤害增加15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]效果：专属技能伤害+99% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<mhp Param +150 per Level>","<mhp Param +18 per Level>"],["<mmp Param +50 per Level>","<mmp Param +18 per Level>"],["<atk Param +100 per Level>","<atk Param +18 per Level>"],["<mat Param +10 per Level>","<mat Param +18 per Level>"],["<def Param +10 per Level>","<def Param +18 per Level>"],["<mdf Param +10 per Level>","<mdf Param +18 per Level>"],["<agi Param +10 per Level>","<agi Param +18 per Level>"],["<luk Param +10 per Level>","<luk Param +18 per Level>"],["<SkillPass9934:15%>","<SkillPass9934:99%>"],["<SkillPass9938:15%>","<SkillPass9938:99%>"],["<SkillPass9939:15%>","<SkillPass9939:99%>"]];
  Q.normalizeRelic=function(item) {
    if(!item || !item.atypeId || Number(item.originalBaseItemId||item.baseItemId||item.id)!==124 || item._codexQiyuBalanceRevision===25)return false;
    // Complete the older imported-equipment migration before applying this revision.
    if(window.CodexImportedEffects)CodexImportedEffects.normalize(item);
    var lines=String(item.note||'').split(/\r?\n/);
    linePairs.forEach(function(pair){var i=lines.indexOf(pair[0]);if(i>=0)lines[i]=pair[1];});
    item.note=lines.join('\n');
    for(var p=0;p<8;p++) {
      // Authored traits precede random/augment traits: only replace one native trait.
      var t=(item.traits||[]).find(function(t){return t.code===21&&t.dataId===p&&Math.abs(t.value-1.01)<1e-10;});
      if(t)t.value=1.1;
    }
    var oldGrowth=[150,50,100,10,10,10,10,10];
    if(item.paramPlusPerLevel)item.paramPlusPerLevel=item.paramPlusPerLevel.map(function(v,p){return v+18-oldGrowth[p];});
    item.meta=item.meta||{};
    [9934,9938,9939].forEach(function(id){var key='SkillPass'+id,cur=item.meta[key];item.meta[key]=String((cur===undefined?15:parseFloat(cur))+84)+'%';});
    item._codexQiyuBalanceRevision=25;
    if(window.RJO&&RJO.HE&&RJO.HE.getDescParams){delete item.descParams;RJO.HE.getDescParams(item,2);}
    return true;
  };
  Q.refreshActor=function(actor) {
    actor._skillsCache=undefined;actor._passiveSkillCache=null;
    actor._cacheBaseParam={};actor._baseParamCache=[];actor._ParamCache2=[];actor._xparamCache2=[];actor._sparamCache2=[];actor._cacheParamBuffRate={};
    actor.need_refresh_param=[1,1,1,1,1,1,1,1];actor.need_refresh_xparam=[1,1,1,1,1,1,1,1,1,1];actor.need_refresh_sparam=[1,1,1,1,1,1,1,1,1,1];
    actor.need_refresh=true;actor.need_refresh_states=true;actor.need_refresh_basestates=true;actor.need_refresh_passiveStates=true;
    if(window.CP&&CP.MagicWeaponManager&&CP.MagicWeaponManager.BATTLE_CACHE)delete CP.MagicWeaponManager.BATTLE_CACHE[actor.actorId()];
    if(actor.refreshPassiveSkillCache)actor.refreshPassiveSkillCache();
    if(actor.initPassiveCache)actor.initPassiveCache();
    if(actor.refreshPassiveCache)actor.refreshPassiveCache();
    actor.refresh();
  };
  Q.sync=function() {
    var changed=[];
    (DataManager._independentArmors||[]).forEach(function(i){if(Q.normalizeRelic(i))changed.push(i);});
    if(!window.$gameActors)return;
    ($gameActors._data||[]).forEach(function(actor){
      if(!actor)return;
      var dirty=false;
      actor.equips().forEach(function(i){if(Q.normalizeRelic(i))changed.push(i);if(changed.indexOf(i)>=0)dirty=true;});
      if(actor.actorId()===163) {
        // 【Codex·未经Claude检验】v0.36：清理旧档异次元状态；结算减伤已解除。
        actor._skills=(actor._skills||[]).filter(function(id){return id!==10264;});
        actor.removeState(2626);
        actor.forgetSkill(10169);
        actor._codexQiyuBalanceRevision=25;dirty=true;
      }
      if(dirty)Q.refreshActor(actor);
    });
  };
  function isQiyuSkill(action) {
    var subject=action.subject(),skill=action.item();
    return subject&&subject.isActor&&subject.isActor()&&subject.actorId()===163&&skill&&DataManager.isSkill(skill);
  }
  // Preserve the existing guaranteed hit and counter/reflection immunity.
  ['itemHit','itemEva','itemCnt','itemMrf'].forEach(function(name){var old=Game_Action.prototype[name];Game_Action.prototype[name]=function(target){return isQiyuSkill(this)?(name==='itemHit'?1:0):old.call(this,target);};});
  var oldAddState=Game_Actor.prototype.addState;
  Game_Actor.prototype.addState=function(id){if(this.actorId()===163&&id===2626)return;return oldAddState.apply(this,arguments);};
  var oldExtract=DataManager.extractSaveContents;
  DataManager.extractSaveContents=function(){var out=oldExtract.apply(this,arguments);Q.sync();return out;};
  var oldRegister=DataManager.registerNewItem;
  DataManager.registerNewItem=function(){var out=oldRegister.apply(this,arguments);Q.normalizeRelic(out);return out;};
  var oldGain=Game_Party.prototype.gainIndependentItem;
  Game_Party.prototype.gainIndependentItem=function(){var out=oldGain.apply(this,arguments);(out||[]).forEach(Q.normalizeRelic);return out;};
  ['changeEquip','forceChangeEquip'].forEach(function(name){var old=Game_Actor.prototype[name];Game_Actor.prototype[name]=function(slot,item){Q.normalizeRelic(item);return old.apply(this,arguments);};});
});
