/* 贝吉特形态战斗图兜底：状态 2771～2774 的移除或旧存档可能留下空图名，
   按当前剩余的最高形态补回，避免 Sprite_Actor 请求 img/sv_actors/undefined.png。 */
window.CodexRuntime.register('installVegettoFormRuntime', function() {
    'use strict';
    if (window.CodexVegettoForm) return window.CodexVegettoForm;
    var FORMS = [[2774, 'clbjt'], [2773, 'cjbjt3'], [2772, 'cjbjt2'], [2771, 'bjtc1']];
    function activeForm(actor) {
        if (!actor || !Array.isArray(actor._states)) return '';
        for (var i = 0; i < FORMS.length; i++) {
            if (actor._states.indexOf(FORMS[i][0]) >= 0) return FORMS[i][1];
        }
        return '';
    }
    var base = Game_Actor.prototype.battlerName;
    Game_Actor.prototype.battlerName = function() {
        var name = base.apply(this, arguments);
        // 换装卡有自己的显示规则，优先保留。
        if (window.CodexCostumes && CodexCostumes.active(this) && name) return name;
        var data = this.actor ? this.actor() : null;
        var original = data ? data.battlerName : '';
        if (name && name !== original) return name;
        return activeForm(this) || name || original;
    };
    window.CodexVegettoForm = {version: 1, activeForm: activeForm};
    return window.CodexVegettoForm;
});
