// 符文之语重做（用户 2026-10-10：每件装备最多一条，避免装备在伤害中占比过高）。
// 原插件 Star_EquipmentMosaic 要求「强化孔全部用完」且整串符石与配方完全一致，同名词条直接覆盖原装备的值。
// 本模块接管镶嵌后的判定：
//  1. 结尾匹配：每镶一颗，检查最近镶入的几颗是否与某个配方一致（取最长的配方），不要求孔用完；
//     但若刚做成的配方正好是某个更长配方的开头，且剩余孔位还够镶完那个更长的，先挂起不结算（用户 2026-10-27）；
//     下一颗没接上更长配方、或孔用完时，再结算挂起的那条；
//  2. 每件装备最多一条符文之语（RW.MAX）；已经做成的旧符文之语算一条；
//  3. 合并时同名数值词条相加（原装备＋模板），不再覆盖；
//  4. 读档时对已镶符石但没触发的装备补一次匹配（只加不减）。
window.CodexRuntime.register('installNativeRunewordRuntime', function () {
  'use strict';
  var RW = window.CodexRuneword = {version: 1, MAX: 1};
  var S = window.Star && Star.EquipmentMosaic, base = S && S.ItemManager_applyIUSEffects;
  if (!base || typeof ItemManager === 'undefined') return;
  function recipes() { return (window.$dataStarEMosaicOpt || []).filter(function (r) { return r && r.EMosaicZID && r.EMosaicZID.length; }); }
  function kindOf(r, item) {
    if (r.EMosaicWId && item.wtypeId && (r.EMosaicWtepy || []).indexOf(item.wtypeId) >= 0) return 'weapon';
    if (r.EMosaicAId && item.atypeId && (r.EMosaicAtepy || []).indexOf(item.etypeId) >= 0) return 'armor';
    return null;
  }
  function template(r, item) { var k = kindOf(r, item); return k === 'weapon' ? $dataWeapons[r.EMosaicWId] : k === 'armor' ? $dataArmors[r.EMosaicAId] : null; }
  // 旧版已做成的符文之语：原插件把模板备注追加到装备备注里（名称前缀会在之后的强化中被引擎重建掉，不可靠）。
  RW.legacy = function (item) {
    if (!item || item._codexRunewords || !item.note) return false;
    return recipes().some(function (r) { var t = template(r, item); return t && t.note && item.note.indexOf('\n' + t.note) >= 0; });
  };
  RW.count = function (item) { return item ? (item._codexRunewords || []).length + (RW.legacy(item) ? 1 : 0) : 0; };
  RW.match = function (item) {
    var ids = item && item.slotsAppliedId || [], best = null;
    recipes().forEach(function (r) {
      var z = r.EMosaicZID; if (z.length > ids.length || !template(r, item)) return;
      if (ids.slice(ids.length - z.length).join(',') !== z.join(',')) return;
      if (!best || z.length > best.EMosaicZID.length) best = r;
    });
    return best;
  };
  // 挂起：刚做成的配方（从第 start 颗起）若能沿着更长配方继续镶完，就先不结算。
  function pendingOf(item, ids) {
    var p = item._codexRunewordPending, r = p && $dataStarEMosaicOpt[p.id];
    if (!r || ids.slice(p.start, p.start + r.EMosaicZID.length).join(',') !== r.EMosaicZID.join(',')) return null;
    return {r: r, start: p.start};
  }
  RW.canGrow = function (item, ids, start, len) {
    var left = Math.max(0, Number(item.upgradeSlots) || 0), k = ids.length - start, head = ids.slice(start).join(',');
    if (!left) return false;
    return recipes().some(function (r) {
      var z = r.EMosaicZID;
      return z.length > Math.max(k, len) && z.length - k <= left && template(r, item) && z.slice(0, k).join(',') === head;
    });
  };
  RW.decide = function (item) {
    var ids = item && item.slotsAppliedId || [], best = RW.match(item), c = best && {r: best, start: ids.length - best.EMosaicZID.length};
    var p = pendingOf(item, ids);
    if (p && (!c || p.r.EMosaicZID.length >= c.r.EMosaicZID.length)) c = p;
    if (!c) { delete item._codexRunewordPending; return null; }
    if (RW.canGrow(item, ids, c.start, c.r.EMosaicZID.length)) { item._codexRunewordPending = {id: c.r.id, start: c.start}; return null; }
    delete item._codexRunewordPending;
    return c.r;
  };
  function num(v) { var m = /^\s*(-?\d+(?:\.\d+)?)\s*(%?)\s*$/.exec(String(v)); return m ? {n: Number(m[1]), p: m[2]} : null; }
  // 【Codex·未经Claude检验】F002：在临时对象上解析备注，仅合并新增贡献，不清空装备运行时字段。
  function parsedElements(note){var x={note:note||''};DataManager.processElementNotetags2([null,x]);return x;}
  function mergeElements(item,before,after){
    ['elementAmplify','elementAmplifyN','elementReflect','elementMagnify'].forEach(function(field){
      var a=before[field],b=after[field],current=item[field]=item[field]||{};
      Object.keys(b).forEach(function(k){var delta=b[k]-(a[k]||0);if(delta)current[k]=(current[k]||0)+delta;});
    });
    var absorb=item.elementAbsorb=item.elementAbsorb||[];
    after.elementAbsorb.forEach(function(k){if(absorb.indexOf(k)<0)absorb.push(k);});
    item.elementNull=!!(item.elementNull||after.elementNull);
    var rates=item.elementForcedRate=item.elementForcedRate||{};
    Object.keys(after.elementForcedRate).forEach(function(k){if(!Object.prototype.hasOwnProperty.call(before.elementForcedRate,k)||after.elementForcedRate[k]!==before.elementForcedRate[k])rates[k]=after.elementForcedRate[k];});
  }
  // 旧符语的百分比元素增伤可由原生备注、已记录强化石和现有孔内宝珠精确还原。
  // 必须在旧孔位重排之前修复，避免从已丢增伤的装备卸珠后留下负值。
  RW.repairElements=function(item){
    if(!item||item._codexRunewordElements||!RW.count(item)||!DataManager.processElementNotetags2)return false;
    var rebuilt=parsedElements(item.note),gemLines=[],upgrades=[];
    (item.augmentSlotItems||[]).forEach(function(t,i){
      var m=/^(item|weapon|armor) (\d+)$/i.exec(t||''),db=m&&(m[1].toLowerCase()==='item'?$dataItems:m[1].toLowerCase()==='weapon'?$dataWeapons:$dataArmors),g=db&&db[Number(m[2])],type=String((item.augmentSlots||[])[i]||'').toUpperCase().trim();
      if(g)(g.augmentDataAttach&&g.augmentDataAttach[type]||[]).forEach(function(line){if(/^ELEMENT AMPLIFY .*:[ ]+[+-]\d+[%％]$/i.test(line.trim()))gemLines.push({line:line,gem:g,slot:i});});
    });
    (item.slotsAppliedId||[]).forEach(function(id){var g=$dataItems[id];if(g)((item.wtypeId?g.upgradeWeaponEffect:g.upgradeArmorEffect)||[]).forEach(function(line){if(/^ELEMENT AMPLIFY .*:[ ]+[+-]\d+[%％]$/i.test(line.trim()))upgrades.push({line:line,gem:g});});});
    upgrades.forEach(function(x){ItemManager.processIUSEffect(x.line,rebuilt,x.gem);});
    gemLines.forEach(function(x){ItemManager.processAugmentEffect(x.line,rebuilt,x.gem,x.slot,true);});
    var changed=JSON.stringify(item.elementAmplify||{})!==JSON.stringify(rebuilt.elementAmplify);
    item.elementAmplify=rebuilt.elementAmplify;item._codexRunewordElements=1;
    return changed;
  };
  RW.apply = function (item, r) {
    var tpl = template(r, item); if (!tpl) return false;
    for (var i = 0; i < item.params.length; i++) item.params[i] += Number(tpl.params[i]) || 0;
    (tpl.traits || []).forEach(function (t) { item.traits.push(JSON.parse(JSON.stringify(t))); });
    item.meta = item.meta || {};
    var re = /<([^<>:]+)(:?)([^>]*)>/g, m;
    while ((m = re.exec(tpl.note || ''))) {
      if (m[2] !== ':') { item.meta[m[1]] = true; continue; }
      var old = item.meta[m[1]], a = old === undefined || old === true ? null : num(old), b = num(m[3]);
      item.meta[m[1]] = a && b ? ' ' + (Math.round((a.n + b.n) * 1e6) / 1e6) + (a.p || b.p) : m[3];
    }
    item._codexRunewordName = tpl.name;  // 名称前缀在引擎重建名称时补回（见 updateItemName）
    var beforeElements=DataManager.processElementNotetags2&&parsedElements(item.note);
    item.note += '\n' + tpl.note;  // 按备注逐条累加的词条本来就会相加；按单值读取的已在 meta 中相加
    if (DataManager.processWULNotetags1) DataManager.processWULNotetags1([null, item]);
    if (beforeElements) mergeElements(item,beforeElements,parsedElements(item.note));
    item._codexRunewordElements=1;
    $gameParty.StarEMosaicOpt = $gameParty.StarEMosaicOpt || [];
    $gameParty.StarEMosaicOpt[r.id] = true;
    (item._codexRunewords = item._codexRunewords || []).push(r.id);
    if (ItemManager.updateItemName) ItemManager.updateItemName(item); else item.name = tpl.name + item.name;
    if(ItemManager.augmentRefreshParty)ItemManager.augmentRefreshParty(item);
    return true;
  };
  var updateName = ItemManager.updateItemName;
  if (updateName) ItemManager.updateItemName = function (item) {
    updateName.apply(this, arguments);
    if (item && item._codexRunewordName && !(item.priorityName && item.priorityName.length) && String(item.name).indexOf(item._codexRunewordName) !== 0) item.name = item._codexRunewordName + item.name;
  };
  RW.check = function (item) {
    if (!item || !(DataManager.isWeapon(item) || DataManager.isArmor(item)) || RW.count(item) >= RW.MAX) return false;
    var r = RW.decide(item); return r ? RW.apply(item, r) : false;
  };
  function refreshHelp(item) { if (window.RJO && RJO.HE && RJO.HE.getDescParams) RJO.HE.getDescParams(item, item.wtypeId ? 1 : 2); }
  ItemManager.applyIUSEffects = function (mainItem, effectItem) {
    base.call(this, mainItem, effectItem);  // 原生强化孔结算（含记录镶入顺序）
    var formed=RW.check(mainItem);
    refreshHelp(mainItem);
    if(!formed&&ItemManager.augmentRefreshParty)ItemManager.augmentRefreshParty(mainItem);
  };
  // 旧档：已镶符石但没有触发的装备补一次匹配。
  RW.catchUp = function () {
    var n = 0;
    [window.$dataWeapons, window.$dataArmors].forEach(function (db) {
      (db || []).forEach(function (item) {
        if(item&&item.baseItemId&&RW.repairElements(item)){refreshHelp(item);if(ItemManager.augmentRefreshParty)ItemManager.augmentRefreshParty(item);}
        if (item && item.slotsAppliedId && item.slotsAppliedId.length && item.baseItemId && RW.check(item)) { refreshHelp(item); n++; }
      });
    });
    return n;
  };
  var extract = DataManager.extractSaveContents;
  DataManager.extractSaveContents = function () {
    var out = extract.apply(this, arguments);
    try { RW.catchUp(); } catch (e) { console.error('符文之语补匹配失败', e); }
    return out;
  };
});
