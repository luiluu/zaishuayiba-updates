// 洪荒减法（成长与难度重构 v0.5 的 S1～S3，用户 2026-10-09「按建议走」）：
// - 诅咒三档（S3）：15 种诅咒分轻／中／重，开洪荒时 15 种里自选 5 种；奖励倍率＝所选诅咒档位系数相乘（轻 1、中 1.2、重 1.5）。
//   旧档按角色已学的诅咒技能（7201～7215）算倍率，不改存档。
// 【Codex·未经Claude检验】 权能只在不朽存在胜利后的原生奖励事件判定，普通副本Boss不掉。
// - 洪荒奖励：副本 Boss 发券（公共事件 1439）在洪荒基础 5 张之外，加发 5×(倍率−1) 张。
// - v4：权能掉率再乘不朽存在熟练度系数（CodexEconomy.powerFactor：10 次 ×2、50 次 ×3）。
// - v3：Boss 所在层沿地图树取（深渊地图名里没有层数）。
// - 权能（S2，v2）：开局不再送书；洪荒路线的不朽存在按区段掉「权能·X」书（道具备注 <CodexPower: 区段>），
//   现仅不朽存在有效通关，每场每本 3%×诅咒倍率，由本模块掷骰（不吃掉率加成，否则后期全队掉率 ×十万级会必掉）。旧权能与已学的不变。
window.CodexRuntime.register('installNativeHonghuangRuntime',function(){
 'use strict';
 var H=window.CodexHonghuang={version:6,POWER_RATE:0.03,SEGMENTS:[[0,15],[16,18],[19,21],[22,25],[26,99]],BASE_TICKET:5,TICKET:1639,
  FACTOR:{'轻':1,'中':1.2,'重':1.5},
  // 【DeepSeek·未经Codex/Claude检验】v0.52：用户指定重排诅咒档位（只改分档与显示/倍率，不改诅咒实际效果）。
  TIER:{7205:'轻',7206:'轻',7209:'轻',7210:'轻',7211:'轻',7214:'轻',
        7203:'中',7207:'中',7208:'中',7212:'中',7213:'中',
        7201:'重',7202:'重',7204:'重',7215:'重'}};
 function num(v){v=Number(v);return isFinite(v)?v:0;}
 function curseHolder(){
  var m=$gameParty&&$gameParty.members();if(!m)return null;
  for(var i=0;i<m.length;i++){if(H.curseIds(m[i]).length)return m[i];}
  return m[0]||null;}
 // 与真气模块的路线判断一致：2483（洪荒）或 2463（洪荒补强）任一开着
 H.isHonghuang=function(){return !!($gameSwitches&&($gameSwitches.value(2483)||$gameSwitches.value(2463)));};
 H.curseIds=function(actor){
  if(!actor||!actor._skills)return [];
  return actor._skills.filter(function(id){return !!H.TIER[id];}).sort(function(a,b){return a-b;});};
 H.curseBonus=function(actor){
  var ids=H.curseIds(actor||curseHolder());
  return ids.reduce(function(r,id){return r*(H.FACTOR[H.TIER[id]]||1);},1);};
 H.curseLabel=function(i){
  var id=7200+num(i),s=$dataSkills[id],t=H.TIER[id]||'轻';
  var m=s&&/<pos=APs text=(?:\\c\[\d+\])?效果:(.*?) size=/.exec(s.note||'');
  return '【'+t+(H.FACTOR[t]>1?'·×'+H.FACTOR[t]:'')+'】'+(s?s.name:'')+(m?'（'+m[1].replace(/​/g,'')+'）':'');};
 H.ticketBonus=function(){return Math.max(0,Math.round(H.BASE_TICKET*(H.curseBonus()-1)));};
 H.grantTicketBonus=function(){
  if(!H.isHonghuang())return 0;
  var n=H.ticketBonus();
  if(n>0){$gameParty.gainItem($dataItems[H.TICKET],n);
   if(window.$&&$.toaster)$.toaster({message:'洪荒诅咒加成（×'+H.curseBonus().toFixed(1)+'）：肝帝积分抽奖券额外+'+n});}
  return n;};
 var POW=null;
 function powers(){
  if(POW)return POW;POW={};
  ($dataItems||[]).forEach(function(it){var m=it&&/<CodexPower:\s*(\d+)>/.exec(it.note||'');if(m)(POW[m[1]]=POW[m[1]]||[]).push(it.id);});
  return POW;}
 H.segment=function(floor){for(var i=0;i<H.SEGMENTS.length;i++){var r=H.SEGMENTS[i];if(floor>=r[0]&&floor<=r[1])return i+1;}return H.SEGMENTS.length;};
 // v3：深渊副本地图名里没有层数，沿地图树往上找（例：24层 速行天 > 熊族桃园 > 深渊:痛苦深渊 > 深渊:未知存在）
 var CN=['零','一','二','三','四','五','六','七','八','九','十'];
 function parseFloor(t){var m=/(\d+)\s*层/.exec(t||'');if(m)return num(m[1]);m=/([一二三四五六七八九十]+)层/.exec(t||'');if(!m)return 0;
  var s=m[1];if(s.indexOf('十')<0)return CN.indexOf(s);var p=s.split('十');return (p[0]?CN.indexOf(p[0]):1)*10+(p[1]?CN.indexOf(p[1]):0);}
 H.mapFloor=function(mapId){var i=mapId,guard=0;while(i&&$dataMapInfos[i]&&guard++<20){var f=parseFloor($dataMapInfos[i].name);if(f)return f;i=$dataMapInfos[i].parentId;}return 0;};
 H.bossFloor=function(){var Z=window.CodexZhenqi,f=H.mapFloor($gameMap.mapId());if(f)return f;return Z?Z.progressFloor():num($gameVariables.value(20))-1;};
 H.powerChance=function(){return Math.min(1,H.POWER_RATE*H.curseBonus());};
 // 【Codex·未经Claude检验】 记录本次战斗身份与胜利，不用永久通关开关放开普通Boss。
 var powerBattle=null;
 ['setupNewGame','extractSaveContents'].forEach(function(name){var old=DataManager[name];DataManager[name]=function(){powerBattle=null;return old.apply(this,arguments);};});
 var setupBattle=BattleManager.setup;
 BattleManager.setup=function(){powerBattle=null;return setupBattle.apply(this,arguments);};
 var startPowerBattle=BattleManager.startBattle;
 BattleManager.startBattle=function(){
  var Y=window.CodexYunshang;
  powerBattle={eligible:H.isHonghuang()&&!!(Y&&Y.isImmortalClear&&Y.isImmortalClear()),
   troop:$gameTroop._troopId,floor:H.bossFloor(),won:false,rolled:false};
  return startPowerBattle.apply(this,arguments);
 };
 var endPowerBattle=BattleManager.endBattle;
 BattleManager.endBattle=function(result){
  if(powerBattle)powerBattle.won=result===0;
  return endPowerBattle.apply(this,arguments);
 };
 // 原生胜利奖励CE1439调用；只有本次不朽存在胜利，且每战只判定一次。
 H.rollPower=function(rand){
  if(!powerBattle||!powerBattle.eligible||!powerBattle.won||powerBattle.rolled)return [];
  powerBattle.rolled=true;rand=rand||Math.random;
  var E=window.CodexEconomy,seg=H.segment(powerBattle.floor),ids=powers()[seg]||[],p=Math.min(1,H.powerChance()*(E&&E.powerFactor?E.powerFactor(powerBattle.troop):1)),got=[];
  ids.forEach(function(id){if(rand()<p){$gameParty.gainItem($dataItems[id],1);got.push(id);}});
  if(got.length&&window.$&&$.toaster)got.forEach(function(id){$.toaster({message:'洪荒权能掉落：'+$dataItems[id].name+'！'});});
  return got;};
 // 【Codex·未经Claude检验】 v0.04 洪荒权能学习、付费遗忘和旧档首次整理；未经claude检验。
 H.POWER_LIMITS={'超强者':3,'强者':4,'弱者':6};H.FORGET_ITEM=3044;
 var powerSkillCache=null,forgetPermit=null;
 H.powerSkills=function(){
  if(!powerSkillCache){powerSkillCache=[];($dataItems||[]).forEach(function(it){
   if(!it||!/<CodexPower:\s*\d+>/.test(it.note||''))return;
   (it.effects||[]).forEach(function(e){if(e.code===43&&powerSkillCache.indexOf(e.dataId)<0)powerSkillCache.push(e.dataId);});
  });}return powerSkillCache.slice();
 };
 H.isPowerSkill=function(id){return H.powerSkills().indexOf(Number(id))>=0;};
 H.learnedPowers=function(a){return a&&a._skills?H.powerSkills().filter(function(id){return a._skills.indexOf(id)>=0;}):[];};
 H.powerClass=function(a){var K=window.CodexZones,D=window.CodexBossDifficulty,id=a.actorId();if(K&&K.classOf)return K.classOf(a);if(D&&D.superStrongIds&&D.superStrongIds.indexOf(id)>=0)return '超强者';if(D&&D.strongIds&&D.strongIds.indexOf(id)>=0)return '强者';return '弱者';};
 H.powerLimit=function(a){return H.POWER_LIMITS[H.powerClass(a)];};
 H.powerLearnReason=function(a,id){if(!a||!a.isActor||!a.isActor())return '请选择角色';if(H.learnedPowers(a).indexOf(id)>=0)return '已经学会这项权能';if(H.learnedPowers(a).length>=H.powerLimit(a))return H.powerClass(a)+'最多学习'+H.powerLimit(a)+'本权能书，请先遗忘已有权能';return '';};
 H.canLearnPower=function(a,id){return H.isPowerSkill(id)&&!H.powerLearnReason(a,id);};
 var learnPower=Game_Actor.prototype.learnSkill;
 Game_Actor.prototype.learnSkill=function(id){if(H.isPowerSkill(id)&&H.powerLearnReason(this,Number(id)))return false;return learnPower.apply(this,arguments);};
 var forgetPower=Game_Actor.prototype.forgetSkill;
 Game_Actor.prototype.forgetSkill=function(id){if(H.isPowerSkill(id)&&$gameActors&&$gameActors._data[this.actorId()]===this&&(!forgetPermit||forgetPermit.actor!==this||forgetPermit.id!==Number(id)))return false;return forgetPower.apply(this,arguments);};
 function removePower(a,id){var before=forgetPermit;forgetPermit={actor:a,id:id};try{a.forgetSkill(id);}finally{forgetPermit=before;}}
 function refreshPower(a){a.refresh();if(window.CodexCombatPower&&CodexCombatPower.clearCache)CodexCombatPower.clearCache();}
 var effectTest=Game_Action.prototype.testItemEffect;
 Game_Action.prototype.testItemEffect=function(a,e){if(e.code===43&&H.isPowerSkill(e.dataId))return H.canLearnPower(a,e.dataId);return effectTest.apply(this,arguments);};
 var effectLearn=Game_Action.prototype.itemEffectLearnSkill;
 Game_Action.prototype.itemEffectLearnSkill=function(a,e){if(H.isPowerSkill(e.dataId)&&!H.canLearnPower(a,e.dataId))return;return effectLearn.apply(this,arguments);};
 function powerBook(item){return item&&/<CodexPower:\s*\d+>/.test(item.note||'')&&(item.effects||[]).filter(function(e){return e.code===43&&H.isPowerSkill(e.dataId);})[0];}
 var actorOK=Scene_ItemBase.prototype.onActorOk;
 Scene_ItemBase.prototype.onActorOk=function(){var e=powerBook(this.item()),targets=this.itemTargetActors();if(e&&targets.length===1){var reason=H.powerLearnReason(targets[0],e.dataId);if(reason){SoundManager.playBuzzer();if(window.$&&$.toaster)$.toaster({message:reason});this._actorWindow.activate();return;}}return actorOK.apply(this,arguments);};
 H.powerMigration=function(){
  if(!$gameSystem._codexPowerLimitMigration){var actors=$gameActors&&$gameActors._data||[];$gameSystem._codexPowerLimitMigration={version:1,free:actors.filter(function(a){return a&&H.learnedPowers(a).length>H.powerLimit(a);}).map(function(a){return a.actorId();})};}
  return $gameSystem._codexPowerLimitMigration;
 };
 H.pendingPowerActors=function(){var m=H.powerMigration();return m.free.map(function(id){return $gameActors._data[id];}).filter(function(a){return a&&H.learnedPowers(a).length>H.powerLimit(a);});};
 H.completePowerKeep=function(a,keep){
  var ids=H.learnedPowers(a),m=H.powerMigration(),limit=H.powerLimit(a),unique=keep.filter(function(id,i){return keep.indexOf(id)===i;});
  if(m.free.indexOf(a.actorId())<0||ids.length<=limit||unique.length!==limit||unique.some(function(id){return ids.indexOf(id)<0;}))return {ok:false,reason:'保留数量或权能选择无效'};
  var removed=ids.filter(function(id){return unique.indexOf(id)<0;});removed.forEach(function(id){removePower(a,id);});
  m.free=m.free.filter(function(id){return id!==a.actorId();});refreshPower(a);return {ok:true,removed:removed};
 };
 H.forgetLearnedPower=function(a,id){
  if(!a||H.learnedPowers(a).indexOf(id)<0)return {ok:false,reason:'角色尚未学会这项权能'};
  if(H.powerMigration().free.indexOf(a.actorId())>=0&&H.learnedPowers(a).length>H.powerLimit(a))return {ok:false,reason:'请先完成旧档免费权能整理'};
  var item=$dataItems[H.FORGET_ITEM];if(!$gameParty.hasItem(item))return {ok:false,reason:'缺少权能遗忘符'};
  removePower(a,id);$gameParty.loseItem(item,1);refreshPower(a);return {ok:true};
 };
 var powerNewGame=DataManager.setupNewGame;
 DataManager.setupNewGame=function(){var result=powerNewGame.apply(this,arguments);$gameSystem._codexPowerLimitMigration={version:1,free:[]};return result;};
 function choosePower(scene,rows,ok,cancel,info){if(scene._helpWindow)scene._helpWindow.hide();CodexYunshang.choose(scene,rows,ok,cancel,info);}
 function Scene_PowerKeep(){this.initialize.apply(this,arguments);}
 Scene_PowerKeep.prototype=Object.create(Scene_MenuBase.prototype);Scene_PowerKeep.prototype.constructor=Scene_PowerKeep;
 Scene_PowerKeep.prototype.create=function(){Scene_MenuBase.prototype.create.call(this);this.nextActor();};
 Scene_PowerKeep.prototype.nextActor=function(){var a=H.pendingPowerActors()[0];if(!a){SceneManager.pop();return;}this._powerActor=a;this._keep=[];this.showKeep();};
 Scene_PowerKeep.prototype.showKeep=function(){
  var self=this,a=this._powerActor,limit=H.powerLimit(a),rows=H.learnedPowers(a).map(function(id){var on=self._keep.indexOf(id)>=0;return {id:id,label:(on?'■ ':'□ ')+$dataSkills[id].name,enabled:on||self._keep.length<limit};});
  rows.push({done:true,label:'确认保留 '+this._keep.length+' / '+limit,enabled:this._keep.length===limit});
  choosePower(this,rows,function(row){if(row.done)return self.confirmKeep();var i=self._keep.indexOf(row.id);if(i>=0)self._keep.splice(i,1);else self._keep.push(row.id);self.showKeep();},function(){SoundManager.playBuzzer();self.showKeep();},['旧档权能整理 · '+a.name(),'请选择保留'+limit+'本，其余权能将遗忘','本次免费；以后每本消耗1枚遗忘符']);
 };
 Scene_PowerKeep.prototype.confirmKeep=function(){var self=this,a=this._powerActor;choosePower(this,[{done:true,label:'确认保留所选权能'},{label:'重新选择'}],function(row){if(!row.done)return self.showKeep();var r=H.completePowerKeep(a,self._keep);if(!r.ok)return self.showKeep();self.nextActor();},function(){self.showKeep();},['确认整理 · '+a.name(),'保留'+this._keep.length+'本，遗忘'+(H.learnedPowers(a).length-this._keep.length)+'本','本次不消耗道具，也不返还权能书']);};
 H.Scene_PowerKeep=Scene_PowerKeep;
 var mapStart=Scene_Map.prototype.start;
 Scene_Map.prototype.start=function(){mapStart.apply(this,arguments);if(H.pendingPowerActors().length)SceneManager.push(Scene_PowerKeep);};
 H.openPowerForget=function(scene){
  function back(){if(scene._itemActionWindow){scene._itemActionWindow.hide();scene._itemActionWindow.deactivate();}scene._itemWindow.refresh();scene.activateItemWindow();}
  function actors(){var rows=$gameParty.allMembers().map(function(a){return {actor:a,label:a.name()+'  '+H.learnedPowers(a).length+' / '+H.powerLimit(a),enabled:H.learnedPowers(a).length>0};});choosePower(scene,rows,function(row){skills(row.actor);},back,['权能遗忘符','选择角色；每遗忘一本消耗1枚，不返还书','剩余道具：'+$gameParty.numItems($dataItems[H.FORGET_ITEM])]);}
  function skills(a){choosePower(scene,H.learnedPowers(a).map(function(id){return {id:id,label:$dataSkills[id].name};}),function(row){confirm(a,row.id);},actors,[a.name()+' · '+H.powerClass(a),'已学权能 '+H.learnedPowers(a).length+' / '+H.powerLimit(a),'选择想要遗忘的一项权能']);}
  function confirm(a,id){choosePower(scene,[{yes:true,label:'消耗1枚，遗忘这项权能'},{label:'取消'}],function(row){if(!row.yes)return skills(a);var r=H.forgetLearnedPower(a,id);scene._itemWindow.refresh();choosePower(scene,[{label:'返回物品'}],back,back,[r.ok?'遗忘完成：'+a.name()+' · '+$dataSkills[id].name:r.reason,'剩余权能：'+H.learnedPowers(a).length+' / '+H.powerLimit(a)]);},function(){skills(a);},['确认遗忘 · '+a.name(),$dataSkills[id].name,'消耗1枚权能遗忘符，不返还权能书']);}
  scene._itemWindow.deactivate();if(scene._itemActionWindow){scene._itemActionWindow.hide();scene._itemActionWindow.deactivate();}actors();
 };
 var itemUsePower=Scene_Item.prototype.onActionUse;
 Scene_Item.prototype.onActionUse=function(){if(this.item()&&this.item().id===H.FORGET_ITEM)return H.openPowerForget(this);return itemUsePower.apply(this,arguments);};

 return H;
});
