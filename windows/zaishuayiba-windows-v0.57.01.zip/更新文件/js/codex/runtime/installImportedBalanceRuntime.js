// 【Codex·未经Claude检验】v0.36：移除拳一异次元制约，保留其他角色与历史迁移。
// 【Codex·未经Claude检验】v0.35：恢复v0.04缩减的12.27专属效果系数，保护后续独立改动。
// 【Codex·未经Claude检验】v0.29 移除12.27异界制约，仅拳一保留×0.01。
// 【Codex·未经Claude检验】v0.02；核查状态：未经claude检验。
/* 12.27 imports: final outgoing settlement rate and retired actor preservation.
 * Install after the native runtime factories. The database grants passive 10264
 * through actor traits; the fixed manifest IDs make its effect permanent even
 * when a save has removed learned skills or all removable states.
 */
window.CodexRuntime.register('installImportedBalanceRuntime', function() {
    'use strict';
// 【Codex·未经Claude检验】v0.02；未经claude检验。
// 12.27 actors: battle drops, including DreamX weapon affixes, require actual participation.
(function(W){
 'use strict';
 if(W.CodexImportedDrops)return;
 var seen=Object.create(null),recording=false,dropDepth=0,ownerCache=new WeakMap();
 function reset(){seen=Object.create(null);recording=false;dropDepth=0;}
 function remember(members){if(!recording)return;members.forEach(function(a){if(a&&a.actorId&&(!a.isAppeared||a.isAppeared())&&(!W.CodexImportedBalance||!CodexImportedBalance.isDisabledActor(a))&&(!W.CodexBossDifficulty||CodexBossDifficulty.canDeploy(a)))seen[a.actorId()]=true;});}
 function groups(item){
  if(!item||!item.wtypeId)return [];
  var note=String(item.note||''),meta=String(item.meta&&item.meta.req_actors||''),cached=ownerCache.get(item);
  if(cached&&cached.note===note&&cached.meta===meta)return cached.groups;
  var result=[],rx=/<req_actors\s*:\s*([^>]+)>/gi,match;
  function add(text){var ids=(text.match(/\d+/g)||[]).map(Number);if(ids.some(function(id){return id>=141&&id<=166;}))result.push(ids);}
  while((match=rx.exec(note)))add(match[1]);
  if(!result.length&&meta)add(meta);
  ownerCache.set(item,{note:note,meta:meta,groups:result});return result;
 }
 function eligible(item){return groups(item).every(function(ids){return ids.some(function(id){return !!seen[id];});});}
 function isDrops(){return dropDepth>0||!!(recording&&W.$gameParty&&$gameParty.inBattle());}
 function filter(items){return Array.isArray(items)?items.filter(eligible):items;}
 function wrap(object,key,fn){var old=object[key];if(typeof old!=='function')return;object[key]=function(){return fn.call(this,old,arguments);};}
 function inDrops(fn,self,args){dropDepth++;try{return fn.apply(self,args);}finally{dropDepth--;}}
 function rewards(){if(BattleManager._rewards)BattleManager._rewards.items=filter(BattleManager._rewards.items);}
 W.CodexImportedDrops={version:'v0.02',actorRange:[141,166],eligible:eligible,participants:function(){return Object.keys(seen).map(Number);}};
 wrap(Game_Party.prototype,'battleMembers',function(old,args){var members=old.apply(this,args);remember(members);return members;});
 wrap(BattleManager,'setup',function(old,args){reset();return old.apply(this,args);});
 wrap(BattleManager,'startBattle',function(old,args){recording=true;remember($gameParty.battleMembers());return old.apply(this,args);});
 wrap(BattleManager,'endBattle',function(old,args){remember($gameParty.battleMembers());recording=false;return old.apply(this,args);});
 [DataManager].forEach(function(o){['setupNewGame','extractSaveContents'].forEach(function(k){wrap(o,k,function(old,args){reset();return old.apply(this,args);});});});
 wrap(Scene_Title.prototype,'start',function(old,args){reset();return old.apply(this,args);});
 [Game_Enemy.prototype,Game_Troop.prototype].forEach(function(o){wrap(o,'makeDropItems',function(old,args){return filter(inDrops(old,this,args));});});
 ['makeRewards','convertPrefixSuffix','displayDropItems','gainDropItems'].forEach(function(k){wrap(BattleManager,k,function(old,args){
  rewards();var result=inDrops(old,this,args);rewards();return result;
 });});
 wrap(Game_Party.prototype,'gainItem',function(old,args){if(isDrops()&&args[1]>0&&!eligible(args[0]))return;return old.apply(this,args);});
 if(W.DreamX&&DreamX.RandomPrefixSuffix){
  var D=DreamX.RandomPrefixSuffix;
  wrap(D,'isValidItem',function(old,args){return (!isDrops()||eligible(args[0]))&&old.apply(this,args);});
  // Explicit <prefix>/<suffix> lists can become empty after filtering. Keep the base item.
  ['combineWithBaseItem','evaluateCustomEffect'].forEach(function(k){wrap(D,k,function(old,args){if(isDrops()&&!args[0])return;return old.apply(this,args);});});
 }
})(window);

// 小猫剑圣 v1.0: native records, per-hit Game_Action, natural-round lifecycle.
(function(W){
'use strict';
if(W.CodexCat)return;
var I={"actor":178,"class":176,"relic":7999,"horn":2899,"stone":2900,"enemy":1999,"troop":1999,"icon":280000,"skill":{"slash":10437,"cross":10438,"flurry":10439,"holy":10440,"sword":10441,"speed":10442,"heart":10443,"advanced":10444,"echo":10445,"trial":10446,"claw":10447,"charge":10448,"breath":10449,"tail":10450},"state":{"heart1":2713,"heart2":2714,"heart3":2715,"read":2716,"scar":2717},"ce":{"recruit":9017,"trial":9018},"advancedConfig":358}, C=W.CodexCat={version:'1.0.1',ids:I}, gearDepth=0,withoutSword=0,rawSwordParams=0,gearViews=new WeakMap();
function alias(o,k,fn){var old=o[k];o[k]=function(){return fn.call(this,old,arguments);};}
function own(a){return !!(a&&a.isActor&&a.isActor()&&a.actorId()===I.actor);}
function learned(a,k){return own(a)&&Array.isArray(a._skills)&&a._skills.indexOf(I.skill[k])>=0;}
function advanced(a){return own(a)&&a.level>=35&&Number(a._AdvancedNum)>=1&&learned(a,'advanced');}
function key(s){if(!s)return '';for(var k in I.skill)if(I.skill[k]===s.id)return k;return '';}
var active=['slash','cross','flurry','holy'];
function kit(s){return active.indexOf(key(s))>=0;}
function sword(a){var e=a&&a._equips&&a._equips[0]&&a._equips[0].object();return !!(e&&DataManager.isWeapon(e)&&e.wtypeId===2);}
function relic(a){return own(a)&&a._equips&&a._equips.some(function(e){var o=e&&e.object();return o&&(o.baseItemId||o.id)===I.relic;});}
function enabledSword(a){return learned(a,'sword')&&sword(a);}
C.is=own;C.advanced=advanced;C.hasSword=sword;C.hasRelic=relic;
function round(){return $gameTroop?Math.max(1,$gameTroop.turnCount()):1;}
function data(a){return a._codexCatBattle||(a._codexCatBattle={heart:0,holyReady:0,bellRound:0});}
function marks(t){return t&&t._codexCatMarks||{};}
function mark(a,t,k){var m=marks(t)[a.actorId()];return !!(m&&m[k]>=round()&&t.isAlive()&&t.hp>0);}
function syncMarks(t){
 if(!t)return;var all=marks(t), read=false,scar=false;
 Object.keys(all).forEach(function(id){read=read||all[id].read>=round();scar=scar||all[id].scar>=round();});
 ['read','scar'].forEach(function(k){var yes=k==='read'?read:scar,id=I.state[k];if(yes&&!t.isStateAffected(id))t.addState(id);else if(!yes&&t.isStateAffected(id))t.removeState(id);});
}
function put(a,t,k){if(!t||!t.isAlive()||t.hp<=0)return;t._codexCatMarks=t._codexCatMarks||{};var m=t._codexCatMarks[a.actorId()]||(t._codexCatMarks[a.actorId()]={});m[k]=round()+1;syncMarks(t);}
function consume(a,t,k){var yes=mark(a,t,k),m=marks(t)[a.actorId()];if(m)delete m[k];syncMarks(t);return yes;}
function heart(a,n){var d=data(a);d.heart=Math.max(0,Math.min(3,n));['heart1','heart2','heart3'].forEach(function(k,i){var id=I.state[k];if(i+1===d.heart){if(!a.isStateAffected(id))a.addState(id);}else if(a.isStateAffected(id))a.removeState(id);});}
C.heart=function(a){return a&&a._codexCatBattle?Number(a._codexCatBattle.heart)||0:0;};
C.mark=mark;C.putMark=put;
function reset(a){if(!own(a))return;delete a._codexCatBattle;['heart1','heart2','heart3'].forEach(function(k){if(a.isStateAffected(I.state[k]))a.removeState(I.state[k]);});}
// Sword contribution views are scoped to stat/cache calculations. Equipment
// ownership, independent instance ids and inventory always use real objects.
function doubled(e){
 var stamp=JSON.stringify([e.params,e.traits,e.level,e.elementAmplify,e.elementAmplifyN,e.elementMagnify,e.paramPlusPerLevel]),cached=gearViews.get(e);if(cached&&cached.stamp===stamp&&cached.note===e.note)return cached.view;
 var o=Object.assign({},e);o.params=(e.params||[]).map(function(v){return Number(v)*2;});
 o.traits=(e.traits||[]).map(function(t){var n=Object.assign({},t);if([11,21,23].indexOf(t.code)>=0)n.value=1+(t.value-1)*2;else if([22,33,34,61].indexOf(t.code)>=0)n.value=t.value*2;return n;});
 // Transform values, never identifiers, learning requirements, cooldowns or caps.
 o.note=String(e.note||'').replace(/<([^<>:]+):\s*([+-]?[\d.]+)(%?)\s*>/g,function(full,k,v,p){
  if(/^(?:hp|mp|atk|def|mat|mdf|agi|luk|atkk|passive(?:PBST\d+|XPST\d+|SPST\d+|HarmRi|CrHarmRi|HarmRe\d+|ELUP\d+|IRUP|APLUS)|DepassiveHarmRe\d+|SkillPass\d+|SkETypeHarmRi\d+|SkillTypesDvup[A-Z]|Element Amplify \d+|Element Magnify \d+|Push(?:Self|sub)?State\d+)$/i.test(k.trim()))return '<'+k+': '+(Number(v)*2)+p+'>';
  return full;
 });
 DataManager.extractMetadata(o);
 ['elementAmplify','elementAmplifyN'].forEach(function(k){if(e[k]){o[k]=Object.assign({},e[k]);Object.keys(o[k]).forEach(function(id){o[k][id]*=2;});}});
 if(e.elementMagnify){o.elementMagnify=Object.assign({},e.elementMagnify);Object.keys(o.elementMagnify).forEach(function(id){o.elementMagnify[id]=1+(o.elementMagnify[id]-1)*2;});}
 if(e.paramPlusPerLevel)o.paramPlusPerLevel=e.paramPlusPerLevel.map(function(v){return v*2;});
 gearViews.set(e,{stamp:stamp,note:e.note,view:o});return o;
}
C.swordView=doubled;
alias(Game_Actor.prototype,'equips',function(old,args){var out=old.apply(this,args);if(own(this)&&withoutSword)return out.map(function(e,i){return i===0?null:e;});return gearDepth&&!rawSwordParams&&enabledSword(this)?out.map(function(e,i){return i===0&&e?doubled(e):e;}):out;});
alias(Game_Actor.prototype,'paramPlus',function(old,args){if(!enabledSword(this))return old.apply(this,args);rawSwordParams++;try{var full=old.apply(this,args),bare;withoutSword++;try{bare=old.apply(this,args);}finally{withoutSword--;}return full+(full-bare);}finally{rawSwordParams--;}});
['traitObjects','refreshPassiveCache','elementAmplifyRate','elementAmplifyNRate','elementMagnifyRate','criticalMultiplierBonus'].forEach(function(k){if(typeof Game_Actor.prototype[k]!=='function')return;alias(Game_Actor.prototype,k,function(old,args){if(!enabledSword(this))return old.apply(this,args);gearDepth++;try{return old.apply(this,args);}finally{gearDepth--;}});});
// This wrapper is outside G_StateParam's final fixed additions and keeps caps.
alias(Game_Actor.prototype,'param',function(old,args){var p=args[0],v=old.apply(this,args);if(!own(this))return v;var r=1;if(p===6&&learned(this,'speed')&&this.level>=10)r*=1.88;if([2,6,7].indexOf(p)>=0&&relic(this))r*=1.6;return Math.round(Math.max(this.paramMin(p),Math.min(this.paramMax(p),v*r)));});
alias(Game_Actor.prototype,'sparam',function(old,args){var v=old.apply(this,args);return enabledSword(this)?v*(args[0]===6?.8:args[0]===7?.88:1):v;});
alias(Game_Actor.prototype,'isDualWield',function(old,args){return own(this)?false:old.apply(this,args);});
// 【Codex·未经Claude检验】 副手槽从小猫布局移除，头部现在可正常使用槽1。
alias(Game_Actor.prototype,'equipSlots',function(old,args){var slots=old.apply(this,args);return own(this)?slots.filter(function(type){return type!==2;}):slots;});
alias(Game_Actor.prototype,'initEquips',function(old,args){var out=old.apply(this,args);if(own(this))this._codexCatEquipLayout=2;return out;});
['changeEquip','forceChangeEquip'].forEach(function(k){alias(Game_Actor.prototype,k,function(old,args){if(own(this)&&args[1]&&args[1].etypeId===2)return;return old.apply(this,args);});});
// 旧档先移动Game_Item引用，原生独立装备表恢复后再将原副手实例退回背包。
function migrateSlots(a){if(!own(a)||a._codexCatEquipLayout===2)return null;
 var removed=a._equips&&a._equips.splice(1,1)[0];a._codexCatEquipLayout=2;
 delete a._initEquipActored;delete a.initEquipActored;return removed;
}
alias(Game_Actor.prototype,'makeActionTimes',function(old,args){var n=old.apply(this,args);return n+(advanced(this)&&learned(this,'speed')?1:0);});
function legal(a,s){var k=key(s), lv={slash:1,cross:10,flurry:20,holy:30};if(active.indexOf(k)>=0)return own(a)&&sword(a)&&learned(a,k)&&a.level>=lv[k]&&(k!=='holy'||!(a._codexCatBattle&&a._codexCatBattle.holyReady>round()));if(k==='trial')return own(a)&&a.level>=35&&sword(a)&&!$gameParty.inBattle();if(k==='echo')return false;return true;}
alias(Game_Actor.prototype,'meetsSkillConditions',function(old,args){if(!legal(this,args[0]))return false;if(own(this)&&args[0]&&args[0].stypeId===1&&!sword(this))return false;return old.apply(this,args);});
alias(Game_BattlerBase.prototype,'meetsSkillConditions',function(old,args){return legal(this,args[0])&&old.apply(this,args);});
alias(Game_BattlerBase.prototype,'canUse',function(old,args){if(args[0]&&args[0].id===I.horn&&DataManager.isItem(args[0])&&$gameParty._actors.indexOf(I.actor)>=0)return false;return old.apply(this,args);});
// Do not let native repeats duplicate a complete chain. The captured native
// multiplier is applied separately to every authored segment exactly once.
var nativeRepeats=Game_Action.prototype.numRepeats;
alias(Game_Action.prototype,'numRepeats',function(old,args){return own(this.subject())&&kit(this.item())?1:old.apply(this,args);});
// 【Codex·未经Claude检验】进阶结算翻倍，基础成长至少保留一半，避免同配置进阶后单段伤害下降。
function growth(a){var l=a.level;if(l>=35){if(!advanced(a))return 1;var al=[35,50,60,70,81],ar=[.30,.45,.62,.80,.875];if(l>=81)return ar[4];for(var j=1;j<al.length;j++)if(l<=al[j])return Math.max(.5,ar[j-1]+(ar[j]-ar[j-1])*(l-al[j-1])/(al[j]-al[j-1]));return 1;}var ls=[1,10,20,30,35],rs=[.06,.15,.3,.7,1];for(var i=1;i<ls.length;i++)if(l<=ls[i])return rs[i-1]+(rs[i]-rs[i-1])*(l-ls[i-1])/(ls[i]-ls[i-1]);return 1;}
C.growth=growth;
C.mastery=function(a){var levels=a&&a._skillMasteryLevels||{},cap=W.$gameVariables?Number($gameVariables.value(8)):0;return Math.max.apply(null,[0].concat(active.filter(function(k){return learned(a,k);}).map(function(k){return Math.min(cap,Number(levels[I.skill[k]])||0);})));};
var weights={slash:1,cross:5/6,flurry:.35,holy:10/3,echo:5/6};
C.formula=function(a,s,t){var k=key(s),snap=a._codexCatFormula, agi=snap?snap.agi:a.agi, weight=weights[k]||0,rate=snap?snap.rate:1,master=C.mastery(a);return (a.atk*1500+agi*3000)*weight*growth(a)*(1+master)*rate;};
C.helpText=function(text,item,a){
 var k=key(item),h=a&&a._codexCatBattle?C.heart(a):0,g=C.growth(a),weight=weights[k]||0;
 function n(v){return String(Math.round(v*1000)/1000);}
 if(/^伤害[：:]/.test(text)&&weight)return '伤害：[己·物理攻击×'+n(1500*weight*g)+'＋己·速度×'+n(3000*weight*g)+']×[1＋剑技等级]×[1＋剑技等级×0.1]';
 if(k==='sword'&&/抱剑护身/.test(text)){if(!a.agi)return '效果：抱剑护身，速度提供物理及元素固定减伤';var s=a.agi;return '效果：抱剑护身，物理减伤'+Math.min(16000,Math.floor(3*s),15030+Math.floor(s/8))+'；元素减伤'+Math.min(18000,Math.floor(3.2*s),16400+Math.floor(2*s/11));}
 if(k==='trial'&&/哈基米独自挑战守誓巨龙/.test(text))return '效果：哈基米独自挑战守誓巨龙，巨龙使用固定试炼难度';
 if(k==='heart'&&/进阶后专属剑技/.test(text))return advanced(a)?'效果：专属剑技结算伤害+100%':'条件：进阶后专属剑技结算伤害+100%';
 if(k==='speed'&&/进阶后额外/.test(text))return advanced(a)?'效果：额外行动＋1':'条件：进阶后额外获得1次行动';
 if(k==='heart'&&/进阶后终技/.test(text))return advanced(a)?'效果：终技消费剑心，追加同层数神圣剑段；满层冷却减1':'条件：进阶后终技消费剑心，追加同层数神圣剑段；满层冷却减1';
 if(k==='holy'&&/冷却4/.test(text))return advanced(a)?'冷却时间：'+(h===3?3:4)+'个自然回合；'+(h?'消耗剑心追加'+h+'段神圣剑影':'施放时消耗剑心，每层追加1段神圣剑影，满层冷却3回合'):'冷却时间：4个自然回合；进阶后消耗剑心追加神圣剑影，满层冷却3回合';
 return text;
};
C.helpItem=function(item,a){if(!item||item.id!==I.skill.holy||!advanced(a))return item;var view=Object.assign({},item);view.meta=Object.assign({},item.meta,{quality:'10',ici:'10'});view.note=String(item.note).replace(/<quality:9>/,'<quality:10>').replace(/<ici:9>/,'<ici:10>');if(item.descParams)view.descParams=item.descParams.map(function(r){var row=r.slice();if(/品质/.test(row[0])){row[0]='品质：'+RJO.IQ.QualitiesName[10];row[2]=RJO.IQ.QualitiesColor[10];}return row;});return view;};
alias(Window_Base.prototype,'drawItemName',function(old,args){var a=W.$gameActors&&$gameActors._data[I.actor],copy=Array.prototype.slice.call(args);copy[0]=C.helpItem(args[0],a);return old.apply(this,copy);});
function begin(action,t){
 if(action._catCast)return action._catCast;
 var a=action.subject(),k=key(action.item()),d=data(a);
 var c=action._catCast={actor:a,target:t,key:k,heart:learned(a,'heart')?d.heart:0,agi:a.agi,read:mark(a,t,'read'),scar:mark(a,t,'scar'),count:Math.max(1,Math.floor(nativeRepeats.call(action))),steps:[],hits:[],chain:false,done:false,action:action};
 build(c,k,false);return c;
}
function build(c,k,chain){
 var a=c.actor,t=c.target,h=c.heart, rd=mark(a,t,'read'), sc=mark(a,t,'scar'),n=0, sure=rd&&k!=='slash';
 c.phaseKey=k;c.phaseChain=chain;c.hits=[];
 if(k==='slash')n=1+(h>=1?1:0);
 if(k==='cross')n=2+(h>=2?2:0);
 if(k==='flurry'){var speed=!chain?(c.agi>=t.agi*1.5?2:c.agi>t.agi?1:0):0;n=4+(h>=3?2:0)+speed+(sc?2:0);if(sc)consume(a,t,'scar');if(rd)consume(a,t,'read');}
 if(k==='holy'){
  c.consumed=sc||rd;if(sc)consume(a,t,'scar');if(rd)consume(a,t,'read');
  var echoes=advanced(a)?h:0;n=1;if(echoes)heart(a,0);
  data(a).holyReady=round()+(advanced(a)&&h===3?3:4);
  c.steps.push({key:k,rate:1,sure:sure});for(var j=0;j<(sc?2:0)+echoes;j++)c.steps.push({key:'echo',rate:1,sure:sure});
 }else for(var i=0;i<n;i++)c.steps.push({key:k,rate:chain?.6:1,sure:sure});
 c.segment=0;c.segmentRepeat=0;
}
function completePhase(c){
 var a=c.actor,t=c.target,k=c.phaseKey;
 if(k==='slash')put(a,t,'read');
 if(k==='cross')for(var i=0;i<c.hits.length;i+=2)if(c.hits[i]&&c.hits[i+1]){put(a,t,'scar');break;}
 if(c.phaseChain){c.done=true;return;}
 var next=k==='slash'?'cross':k==='cross'&&c.read?'flurry':k==='flurry'&&c.scar?'slash':k==='holy'&&c.consumed?'slash':null;
 if(next&&learned(a,next)&&a.isAlive()&&t.isAlive()&&t.hp>0) {c.chain=true;build(c,next,true);}else c.done=true;
}
C.begin=begin;
C.strike=function(action,t,manager){
 var c=begin(action,t),a=c.actor;if(c.done||!a.isAlive()||!t.isAlive()||t.hp<=0){c.done=true;return false;}
 var step=c.steps[c.segment],child=new Game_Action(a);child.setSkill(I.skill[step.key]);child.setTarget(t.index());child._codexInternal=true;child._catSegment=true;child._catSure=step.sure;child._catWeak=step.sure;
 var origin=c.key==='holy'?I.skill.holy:I.skill[step.key];
 a._codexCatFormula={agi:c.agi,rate:step.rate,master:a.skillMasteryLevel(origin)};
 var prior=manager&&manager._action;
 try {
  if(manager){manager._action=child;manager.invokeAction(a,t);}else child.apply(t);
  var r=t.result();c.hits[c.segment]=c.hits[c.segment]===false?false:!!(r&&r.isHit());
  c.lastResult={key:step.key,hit:r.isHit(),damage:r.hpDamage,critical:r.critical,chain:c.phaseChain};
  if(C.trace)C.trace.push(Object.assign({actor:a.actorId(),target:t.index(),round:round()},c.lastResult));
 }finally{delete a._codexCatFormula;if(manager)manager._action=prior;}
 data(a).recent=t;
 c.segmentRepeat++;if(c.segmentRepeat>=c.count){c.segmentRepeat=0;c.segment++;}
 if(c.segment>=c.steps.length){c.steps=[];completePhase(c);}
 return !c.done&&a.isAlive()&&t.isAlive()&&t.hp>0;
};
// Sequence commands queue one native hit at a time; death terminates the queue.
alias(BattleManager,'processActionSequence',function(old,args){
 var name=String(args[0]).toUpperCase(),act=this._action,a=act&&act.subject();
 if((name==='CAT BEGIN'||name==='CAT STRIKE')&&own(a)&&kit(act.item())){
  var t=act._catCast&&act._catCast.target||this._targets[0];if(!t||!t.isAlive())return true;
  if(name==='CAT BEGIN'){begin(act,t);this._actionList.unshift(['CAT STRIKE',[]]);return true;}
  if(C.strike(act,t,this)){this._actionList.unshift(['CAT STRIKE',[]]);this._actionList.unshift(['WAIT',['6']]);}
  return true;
 }
 return old.apply(this,args);
});
alias(Game_Action.prototype,'itemCri',function(old,args){return this._catWeak&&learned(this.subject(),'heart')?1:old.apply(this,args);});
alias(Game_Action.prototype,'itemHit',function(old,args){return this._catSure?1:old.apply(this,args);});
alias(Game_Action.prototype,'itemEva',function(old,args){return this._catSure?0:old.apply(this,args);});
alias(Game_Action.prototype,'itemCnt',function(old,args){return this._catSure?0:old.apply(this,args);});
function endCast(action){var c=action&&action._catCast;if(!c||c.ended)return;c.ended=true;if(c.chain&&learned(c.actor,'heart')&&c.actor.isAlive())heart(c.actor,C.heart(c.actor)+1);}
C.endCast=endCast;
alias(BattleManager,'endAction',function(old,args){var action=this._action,a=this._subject;if(own(a)&&action){endCast(action);if(action.isGuard()&&learned(a,'heart')&&relic(a)&&a.isAlive()){var d=data(a);if(d.bellRound!==round()){d.bellRound=round();heart(a,d.heart+1);var t=d.recent;if(t&&t.isAlive()){var m=marks(t)[a.actorId()];if(m){['read','scar'].forEach(function(k){if(m[k]>=round())m[k]=round()+1;});syncMarks(t);}}}}}return old.apply(this,args);});
alias(BattleManager,'endTurn',function(old,args){var was=this._enteredEndPhase,out=old.apply(this,args);if(!was&&this._enteredEndPhase){var r=round();$gameTroop.members().forEach(function(t){var m=marks(t);Object.keys(m).forEach(function(id){['read','scar'].forEach(function(k){if(m[id][k]<=r)delete m[id][k];});});syncMarks(t);});}return out;});
// Add fixed speed protection through the existing damage frame cache; restore
// immediately so preview and native settlement cannot permanently add it twice.
W.CodexDamageHooks=W.CodexDamageHooks||[];
W.CodexDamageHooks.push({id:'cat-sword',build:function(action,target,f){
 var a=action.subject();if(!enabledSword(a)||(!kit(action.item())&&key(action.item())!=='echo'))return;
 f.normalAdd+=6;f.elementAdd[1]=(f.elementAdd[1]||0)+6;f.elementAdd[8]=(f.elementAdd[8]||0)+6;
 if(learned(a,'heart')){f.finalAdd+=8;f.criticalAdd+=12;if(advanced(a))f.settlementMultiplier*=2;}
},enter:function(action,target,f){
 var protect=enabledSword(target),dragon=target&&target.enemyId&&target.enemyId()===I.enemy;if(!protect&&!dragon)return;
 var previous=target._passiveCache,c=Object.assign({},previous||{});c.harmRe=Object.assign({},c.harmRe||{});
 if(protect){var s=target.agi;c.harmRe[1]=(c.harmRe[1]||0)+Math.min(16000,Math.floor(3*s),15030+Math.floor(s/8));[2,3,4,5,6,7,8,9,11,12,13,14,15].forEach(function(e){c.harmRe[e]=(c.harmRe[e]||0)+Math.min(18000,Math.floor(3.2*s),16400+Math.floor(2*s/11));});}
 if(dragon&&((round()-1)%5)!==3){c.harmRe[1]=(c.harmRe[1]||0)+1e11;c.harmRe[8]=(c.harmRe[8]||0)+5e10;}
 target._passiveCache=c;return function(){if(previous===undefined)delete target._passiveCache;else target._passiveCache=previous;};
}});
// Native common-event recruitment, with one reusable independent relic.
C.recruit=function(){
 if($gameParty._actors.indexOf(I.actor)>=0)return false;
 var a=$gameActors.actor(I.actor);a._AdvancedNum=Number(a._AdvancedNum)||0;a.forgetSkill(6235);a.learnSkill(6216);var base=$dataArmors[I.relic],slot=a.equipSlots().indexOf(13);
 if(slot<0||!a.canEquip(base))throw Error('抱剑喵铃装备槽不可用');
 if(!$gameSystem._codexCatRelicGranted){
  var item=a.equips()[slot];if(!item||(item.baseItemId||item.id)!==I.relic)item=$gameParty.getMatchingBaseItem&&$gameParty.getMatchingBaseItem(base,false);
  if(!item)item=$gameParty.gainIndependentItem?$gameParty.gainIndependentItem(base,1)[0]:($gameParty.gainItem(base,1),base);
  if(!item)throw Error('抱剑喵铃生成失败');a.changeEquip(slot,item);if(a.equips()[slot]!==item)throw Error('抱剑喵铃装备失败');$gameSystem._codexCatRelicGranted=true;
 }
 // A normal native starter sword; inventory owns the instance and keeps it on removal.
 if(!sword(a)&&!a._codexCatStarterGranted){var wp=$dataWeapons[2],item=$gameParty.gainIndependentItem?$gameParty.gainIndependentItem(wp,1)[0]:($gameParty.gainItem(wp,1),wp);a.changeEquip(0,item);if(!sword(a))throw Error('初始练习剑装备失败');a._codexCatStarterGranted=true;}
 $gameParty.addActor(I.actor);return true;
};
alias(Scene_Shop.prototype,'prepare',function(old,args){var goods=args[0]||[];if($gameMap.mapId()===132&&goods.some(function(g){return g[0]===0&&$dataItems[g[1]]&&/^伙伴号角：/.test($dataItems[g[1]].name);})&&!goods.some(function(g){return g[0]===0&&g[1]===I.horn;}))goods.push([0,I.horn,0,0]);return old.call(this,goods,args[1]);});
function notify(s){if(W.$&&$.toaster)$.toaster({message:s});}
function restoreTrial(result){var d=$gameSystem&&$gameSystem._codexCatTrial;if(!d)return;$gameParty._actors=d.actors;$gameParty._battleMembers=d.members;$gameParty._BattleMaxSize=d.max;delete $gameSystem._codexCatTrial;$gamePlayer.refresh();if(result===0&&!$gameSystem._codexCatTrialWon){$gameSystem._codexCatTrialWon=true;$gameParty.gainItem($dataItems[I.stone],1);notify('守誓巨龙认可了你的剑。获得小猫进阶石×1！');}if(result===2){var a=$gameActors.actor(I.actor);if(a.isDead())a.setHp(1);notify('试炼未通过，可再次挑战。');}}
C.startTrial=function(interpreter){
 var a=$gameActors._data[I.actor];if($gameParty.inBattle()||!a||$gameParty._actors.indexOf(I.actor)<0||a.level<35||!sword(a)){notify('小猫剑圣达到35级并装备剑后，才能挑战。');return false;}
 $gameSystem._codexCatTrial={actors:$gameParty._actors.slice(),members:$gameParty._battleMembers&&$gameParty._battleMembers.slice(),max:$gameParty._BattleMaxSize};
 $gameParty._actors=[I.actor];$gameParty._BattleMaxSize=1;$gameParty._battleMembers=[I.actor];$gamePlayer.refresh();
 try{BattleManager.setup(I.troop,false,true);if(W.CodexZhenqi)CodexZhenqi._battle=null;BattleManager.setEventCallback(function(result){var d=$gameSystem._codexCatTrial;if(d)d.result=result;});if(interpreter)interpreter.setWaitMode('battle');SceneManager.push(Scene_Battle);return true;}catch(e){restoreTrial(-1);throw e;}
};
C.restoreTrial=restoreTrial;
alias(BattleManager,'startBattle',function(old,args){$gameParty.allMembers().forEach(reset);var out=old.apply(this,args);if($gameSystem._codexCatTrial){var a=$gameActors.actor(I.actor);a.recoverAll();a.setTp(a.maxTp());}return out;});
alias(BattleManager,'endBattle',function(old,args){try{return old.apply(this,args);}finally{if($gameSystem._codexCatTrial)$gameSystem._codexCatTrial.result=args[0];$gameParty.allMembers().forEach(reset);$gameTroop.members().forEach(function(t){delete t._codexCatMarks;['read','scar'].forEach(function(k){if(t.isStateAffected(I.state[k]))t.removeState(I.state[k]);});});}});
alias(Scene_Battle.prototype,'terminate',function(old,args){try{return old.apply(this,args);}finally{var d=$gameSystem._codexCatTrial;if(d)restoreTrial(d.result===undefined?-1:d.result);}});
alias(Game_Enemy.prototype,'makeActions',function(old,args){if(this.enemyId()!==I.enemy)return old.apply(this,args);Game_Battler.prototype.makeActions.call(this);var n=BattleManager.isOTB()?round():Math.max(1,$gameTroop.turnCount()+1),k=['claw','charge','breath',null,'tail'][(n-1)%5];if(k){this._actions[0].setSkill(I.skill[k]);this._actions[0].setTarget(0);}else this.clearActions();this.setActionState('waiting');});
alias(BattleManager,'startAction',function(old,args){var a=this._subject,s=a&&a.currentAction()&&a.currentAction().item();if(a&&a.enemyId&&a.enemyId()===I.enemy&&s&&s.id===I.skill.charge){this._logWindow.push('addText','巨龙昂首蓄息！下一回合将喷出铜焰，架剑防御！');}return old.apply(this,args);});
// 【Codex·未经Claude检验】固定预算的个人试炼不继承塔内挑战的怪物强化。
// Keep player debuffs/build, sword marks and combat-inflicted states unchanged.
var trialDifficultyStates=[1271,1284,1460,1461,1462,1463,1464,1465,1466,1467,1469,1470,1471,1633,1634,1636,1641,1643,1657,1658,1659,1682];
C.trialDifficultyStates=trialDifficultyStates.slice();
function trialDragon(a){return a&&a.enemyId&&a.enemyId()===I.enemy&&$gameSystem&&$gameSystem._codexCatTrial&&$gameTroop&&$gameTroop._troopId===I.troop;}
alias(Game_Enemy.prototype,'addState',function(old,args){if(trialDragon(this)&&trialDifficultyStates.indexOf(Number(args[0]))>=0)return;return old.apply(this,args);});
// The solo trial has an authored level-35 budget. Install its final parameter
// getter after the game's tower/difficulty aliases, preserving all other bosses.
var dragonParamsInstalled=false;
alias(DataManager,'isDatabaseLoaded',function(old,args){var ok=old.apply(this,args);/* 【Claude·未经Codex检验】v0.44 强者名单改由角色备注 <KyoTier> 决定 */if(ok&&!dragonParamsInstalled){dragonParamsInstalled=true;alias(Game_Enemy.prototype,'param',function(native,argv){return this.enemyId()===I.enemy?Number($dataEnemies[I.enemy].params[argv[0]]):native.apply(this,argv);});}return ok;});
// 【Codex·未经Claude检验】 单次布局迁移；法宝等级、独立ID、词条、镶嵌与其余装备对象不变。
alias(DataManager,'extractSaveContents',function(old,args){
 var contents=args[0],legacy=contents&&contents.actors&&contents.actors._data[I.actor],changed=own(legacy)&&legacy._codexCatEquipLayout!==2,removed=migrateSlots(legacy);
 var out=old.apply(this,args);if($gameSystem._codexCatTrial)restoreTrial(-1);
 var a=$gameActors._data[I.actor];if(a){if(removed&&removed.object())$gameParty.gainItem(removed.object(),1,false);reset(a);if(changed){a.refresh();if(a.refreshPassiveCache)a.refreshPassiveCache();}}
 return out;
});
// Custom icons use the existing native windows and an isolated atlas.
function ownIcon(n){return n>=I.icon&&n<I.icon+9;}
function drawIcon(w,n,x,y,size){var b=ImageManager.loadSystem('CatSwordSaint_Icons'),c=w.contents;function draw(){if(w.contents===c)c.blt(b,(n-I.icon)*32,0,32,32,x,y,size,size);}if(!b.isReady())b.addLoadListener(draw);else draw();}
alias(Window_Base.prototype,'drawIcon',function(old,args){if(ownIcon(args[0]))return drawIcon(this,args[0],args[1],args[2],32);return old.apply(this,args);});
if(Window_Base.prototype.DXDrawLargeIcon)alias(Window_Base.prototype,'DXDrawLargeIcon',function(old,args){var i=this._item||args[0];if(i&&ownIcon(i.iconIndex))return drawIcon(this,i.iconIndex,8,8,128);return old.apply(this,args);});
if(W.Window_ItemStatus)alias(Window_ItemStatus.prototype,'drawLargeIcon',function(old,args){if(this._item&&ownIcon(this._item.iconIndex))return drawIcon(this,this._item.iconIndex,0,0,128);return old.apply(this,args);});
})(window);

    var W = window;
    if (W.CodexImportedBalance) return W.CodexImportedBalance;
    var contexts = [], settled = [], direct = [], reflections = [], migrating = false;
    var B = W.CodexImportedBalance = {
        version: 1,
        passiveSkillId: 10264,
        importedActorIds: [141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166],
        disabledActorIds: [141,143,144,145,146,152,157,160,161,166],
        disabledHornIds: [245,255,256,257,274,359,394,440,456,494]
    };
    function actorId(actor) {
        if (typeof actor === 'number' || typeof actor === 'string') return Number(actor);
        return actor && actor.isActor && actor.isActor() ? Number(actor.actorId ? actor.actorId() : actor._actorId) : 0;
    }
    // 【Codex·未经Claude检验】v0.36：拳一也解除异次元结算减伤。
    B.outgoingRate = function(actor) { return 1; };
    B.isDisabledActor = function(actor) { return B.disabledActorIds.indexOf(actorId(actor)) >= 0; };
    B.isDisabledHorn = function(item) {
        return !!(item && B.disabledHornIds.indexOf(Number(item.id)) >= 0 &&
            (!W.DataManager || !DataManager.isItem || DataManager.isItem(item)));
    };
    function subjectOf(action) { return action && action.subject ? action.subject() : null; }
    function withContext(action, target, targets, fn, self, args, preScaled, source) {
        contexts.push({action: action, subject: source || subjectOf(action), target: target, targets: targets,
            preScaled: !!preScaled});
        try { return fn.apply(self, args); }
        finally { contexts.pop(); }
    }
    function activeContext() { return contexts.length ? contexts[contexts.length - 1] : null; }
    function eligible(ctx, target) {
        if (!ctx || !target || !ctx.subject || ctx.subject === target || B.outgoingRate(ctx.subject) === 1) return false;
        return ctx.target ? ctx.target === target : !!(ctx.targets && ctx.targets.indexOf(target) >= 0);
    }
    function eligibleSettlement(ctx, target) {
        return eligible(ctx, target) || !!(ctx && ctx.action && reflections.indexOf(ctx.action) >= 0 &&
            target === ctx.subject && B.outgoingRate(ctx.subject) < 1);
    }
    function isMarked(list, target, resource) {
        for (var i = list.length - 1; i >= 0; i--) if (list[i].target === target && list[i].resource === resource) return true;
        return false;
    }
    // RPG Maker settles integer damage. Values below one point may become zero;
    // there is deliberately no minimum-one damage after the permanent debuff.
    function reduced(value, ctx) { return Math.floor(Number(value) * B.outgoingRate(ctx.subject)); }
    function scaledNegative(value, target, resource) {
        var ctx = activeContext();
        if (Number(value) < 0 && eligible(ctx, target) && !ctx.preScaled &&
            !isMarked(settled, target, resource) && !isMarked(direct, target, resource)) return -reduced(-value, ctx);
        return value;
    }
    function wrapActionContext(name) {
        var old = Game_Action.prototype[name];
        if (typeof old !== 'function') return;
        Game_Action.prototype[name] = function(target) {
            if (B.isDisabledActor(subjectOf(this)) || B.isDisabledHorn(this.item && this.item())) return;
            return withContext(this, target, null, old, this, arguments, false);
        };
    }
    // Keep executeDamage's input unchanged. YEP pre/react scripts can finish
    // their modifiers, and post-damage scripts retain the original `value`.
    // Each authored extra hit is then reduced once at its own settlement.
    wrapActionContext('apply');
    wrapActionContext('executeDamage');
    ['Hp','Mp'].forEach(function(kind) {
        var name = 'execute' + kind + 'Damage', resource = kind.toLowerCase();
        var old = Game_Action.prototype[name];
        if (typeof old !== 'function') return;
        Game_Action.prototype[name] = function(target, value) {
            if (B.isDisabledActor(subjectOf(this)) || B.isDisabledHorn(this.item && this.item())) return;
            var action = this, args = Array.prototype.slice.call(arguments);
            return withContext(action, target, null, function() {
                var ctx = activeContext();
                if (Number(value) > 0 && eligibleSettlement(ctx, target) && !isMarked(settled, target, resource)) args[1] = reduced(value, ctx);
                settled.push({target: target, resource: resource});
                try { return old.apply(action, args); }
                finally { settled.pop(); }
            }, this, [], false);
        };
    });
    // Actor gainHp has an own wrapper in krz_state_re.js which captures the
    // previous battler function. Wrap both entry points with a shared guard.
    function wrapGain(type, resource) {
        if (!type || !type.prototype) return;
        var name = resource === 'hp' ? 'gainHp' : 'gainMp';
        var old = type.prototype[name];
        if (typeof old !== 'function') return;
        type.prototype[name] = function(value) {
            var args = Array.prototype.slice.call(arguments);
            args[0] = scaledNegative(value, this, resource);
            direct.push({target: this, resource: resource});
            try { return old.apply(this, args); }
            finally { direct.pop(); }
        };
    }
    ['hp','mp'].forEach(function(resource) {
        wrapGain(W.Game_Battler, resource);
        if (W.Game_Actor && Object.prototype.hasOwnProperty.call(Game_Actor.prototype, resource === 'hp' ? 'gainHp' : 'gainMp')) wrapGain(Game_Actor, resource);
        var name = resource === 'hp' ? 'setHp' : 'setMp', old = Game_BattlerBase.prototype[name];
        if (typeof old !== 'function') return;
        Game_BattlerBase.prototype[name] = function(value) {
            var ctx = activeContext(), args = Array.prototype.slice.call(arguments), before = Number(this[resource]);
            if (Number(value) < before && eligible(ctx, this) && !ctx.preScaled &&
                !isMarked(settled, this, resource) && !isMarked(direct, this, resource)) args[0] = before - reduced(before - Number(value), ctx);
            direct.push({target: this, resource: resource});
            try { return old.apply(this, args); }
            finally { direct.pop(); }
        };
    });
    // Script sequences bypass Game_Action.apply. Restrict their fallback to the
    // current sequence targets, so unrelated ally costs and turn damage stay intact.
    if (W.BattleManager) {
        var reflect = BattleManager.invokeMagicReflection;
        if (typeof reflect === 'function') BattleManager.invokeMagicReflection = function() {
            // MV leaves _reflectionTarget on the action after reflection. Use a
            // scoped marker so later HP costs can never inherit that exception.
            reflections.push(this._action);
            try { return reflect.apply(this, arguments); }
            finally { reflections.pop(); }
        };
        ['processActionSequence','actionHpModify','actionMpModify'].forEach(function(name) {
            var old = BattleManager[name];
            if (typeof old !== 'function') return;
            BattleManager[name] = function() {
                if (B.isDisabledActor(subjectOf(this._action)) || B.isDisabledHorn(this._action && this._action.item && this._action.item())) return false;
                var targets = this._targets || [];
                if (name !== 'processActionSequence' && this.makeActionTargets && arguments[1]) targets = this.makeActionTargets(arguments[1][0]);
                return withContext(this._action, null, targets, old, this, arguments, false);
            };
        });
    }
    // Bailong's A.C.S optimization uses target.setHp for a merged tail. Reduce
    // the per-hit value BEFORE that optimization computes/clamps its total. Its
    // gainHp and recordBulk paths then receive the same already-reduced value.
    // Only the plugin's exact, damage-only authored loop has this exception.
    function isAcsLoop(item) {
        if (!item) return false;
        var code = String(item.customPostDamageEval || '').replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/[^\n\r]*/g, '').replace(/\s+/g, '');
        return /^if\(user\._costmp>0\)\{for\((?:let|var)i=1;i<user\._costmp;i\+\+\)\{target\.gainHp\(-value\);target\.startDamagePopup\(\);?\}\}$/.test(code);
    }
    function ensureAcsCompatibility() {
        var old = Game_Action.prototype.applyPostDamageEval;
        if (typeof old !== 'function' || old.__codexImportedAcs) return;
        var replacement = function(target, value) {
            if (B.isDisabledActor(subjectOf(this)) || B.isDisabledHorn(this.item && this.item())) return;
            var ctx = activeContext(), action = this;
            if (!old.__bailongAcsShapeExtreme || !isAcsLoop(this.item && this.item()) || Number(value) <= 0 ||
                !eligibleSettlement({action: this, subject: subjectOf(this), target: target}, target) || (ctx && ctx.preScaled)) return old.apply(this, arguments);
            var args = Array.prototype.slice.call(arguments);
            args[1] = reduced(value, {subject: subjectOf(this)});
            // Avoid the plugin's positive-integer fast path falling back to an
            // enormous no-op loop when the debuff rounds the per-hit value to zero.
            if (args[1] <= 0) return;
            return withContext(action, target, null, old, this, args, true);
        };
        replacement.__codexImportedAcs = true;
        replacement.__bailongAcsShapeExtreme = old.__bailongAcsShapeExtreme;
        replacement.__r126ShapeExtreme = old.__r126ShapeExtreme;
        Game_Action.prototype.applyPostDamageEval = replacement;
    }
    ensureAcsCompatibility();
    if (W.DataManager && typeof DataManager.isDatabaseLoaded === 'function') {
        var databaseLoaded = DataManager.isDatabaseLoaded;
        DataManager.isDatabaseLoaded = function() {
            var loaded = databaseLoaded.apply(this, arguments);
            if (loaded) ensureAcsCompatibility();
            return loaded;
        };
    }
    // These two shipped React scripts author damage on behalf of a persistent
    // state rather than the current attacking action. Limit the source override
    // to their direct gain/set calls; returning `value` still uses the action's
    // normal settlement wrapper after this context has been popped.
    var stateEval = Game_Action.prototype.customEffectEval;
    if (typeof stateEval === 'function') Game_Action.prototype.customEffectEval = function(target, stateId, type, side) {
        if (type !== 'reactState' || (Number(stateId) !== 1341 && Number(stateId) !== 2550)) return stateEval.apply(this, arguments);
        var source = Number(stateId) === 1341 && side && side.stateOrigin ? side.stateOrigin(1341) : side;
        var victim = Number(stateId) === 2550 ? subjectOf(this) : target;
        if (!source || !victim) return stateEval.apply(this, arguments);
        return withContext(this, victim, null, stateEval, this, arguments, false, source);
    };
    // YEP normally takes the source from BattleManager._subject. Counterattacks
    // use a new Game_Action while that field still points at the first attacker.
    // Preserve the actual applying action's source when an action adds a state.
    var addState = Game_Battler.prototype.addState;
    if (typeof addState === 'function') Game_Battler.prototype.addState = function(stateId) {
        var ctx = activeContext(), addable = this.isStateAddable && this.isStateAddable(stateId);
        var out = addState.apply(this, arguments);
        if (ctx && ctx.action && ctx.subject && addable && this.isStateAffected(stateId) && this.setStateOrigin) this.setStateOrigin(stateId, ctx.subject);
        return out;
    };
    // krz_state_re regenerates by writing _hp directly. For one regeneration
    // call, expose copies with externally applied imported negative HRG removed.
    // The native integer contribution of those traits is then reduced once.
    // Never edit the shared database objects, and never round a negative 0.01
    // value down to an accidental minimum-one point of damage.
    // The original method still owns REC, difficulty, maximum slip damage,
    // immortality and its HP settlement behavior.
    var regenerateHp = Game_Battler.prototype.regenerateHp;
    if (typeof regenerateHp === 'function') Game_Battler.prototype.regenerateHp = function() {
        if (this.need_refresh && this.refresh) this.refresh();
        var battler = this, objects = this.traitObjects(), changed = false;
        var scaledObjects = objects.map(function(obj) {
            if (!obj || !W.$dataStates || $dataStates[obj.id] !== obj || !battler.stateOrigin) return obj;
            var source = battler.stateOrigin(obj.id), rate = B.outgoingRate(source);
            if (!source || source === battler || rate === 1) return obj;
            var altered = false, traits = (obj.traits || []).map(function(trait) {
                if (trait.code === 22 && trait.dataId === 7 && Number(trait.value) < 0) {
                    altered = true;
                    return {code: trait.code, dataId: trait.dataId, value: 0};
                }
                return trait;
            });
            if (!altered) return obj;
            changed = true;
            var copy = Object.assign({}, obj); copy.traits = traits; return copy;
        });
        if (!changed) return regenerateHp.apply(this, arguments);
        var mhp = this.mhp, rec = this.rec, fullValue = Math.floor(mhp * this.hrg * rec);
        var keys = ['traitObjects','_xparam','_xparamCache2','need_refresh_xparam','_regenHprefresh','_regenHpcache'];
        var saved = keys.map(function(key) { return Object.getOwnPropertyDescriptor(battler, key); });
        this.traitObjects = function() { return scaledObjects; };
        // Both YEP ExtraParam and krz cache xparams. These temporary caches must
        // not outlive the converted traits or mask a later source replacement.
        this._xparam = {}; this._xparamCache2 = [];
        this.need_refresh_xparam = (this.need_refresh_xparam || []).slice();
        this.need_refresh_xparam[7] = 1;
        try {
            var otherValue = Math.floor(mhp * this.hrg * rec);
            var importedDamage = Math.max(0, otherValue - fullValue);
            this._regenHpcache = otherValue - Math.floor(importedDamage * rate);
            this._regenHprefresh = false;
            return regenerateHp.apply(this, arguments);
        }
        finally {
            keys.forEach(function(key, index) {
                if (saved[index]) Object.defineProperty(battler, key, saved[index]);
                else delete battler[key];
            });
        }
    };
    function refreshParty() {
        if (W.$gamePlayer && $gamePlayer.refresh) $gamePlayer.refresh();
        if (W.$gameMap && $gameMap.requestRefresh) $gameMap.requestRefresh();
    }
    // Move IDs only. $gameActors objects, equipment, learned skills and inventory
    // remain serialized unchanged. Battle slots remain fixed-length for YEP.
    B.migrateParty = function(party) {
        if (!party || migrating) return false;
        migrating = true;
        var changed = false;
        try {
            party._actors = party._actors || [];
            var retired = [];
            [party._actors, party._battleMembers || []].forEach(function(ids) {
                ids.forEach(function(id) { if (B.isDisabledActor(id) && retired.indexOf(Number(id)) < 0) retired.push(Number(id)); });
            });
            if (retired.length) {
                party._saveactors = party._saveactors || [];
                retired.forEach(function(id) { if (party._saveactors.indexOf(id) < 0) party._saveactors.push(id); });
                party._actors = party._actors.filter(function(id) { return !B.isDisabledActor(id); });
                changed = true;
            }
            if (retired.length && !party._actors.length) {
                function validReplacement(id) { return Number(id) > 0 && !B.isDisabledActor(id) && W.$dataActors && $dataActors[Number(id)]; }
                var stored = (party._saveactors || []).filter(validReplacement);
                var starters = (W.$dataSystem && $dataSystem.partyMembers || []).filter(validReplacement);
                // This game's System.partyMembers is empty because the intro
                // event creates the protagonist. Actor 1 is its safe last resort.
                var replacement = Number(stored[0] || starters[0] || (validReplacement(1) ? 1 : 0));
                if (replacement) {
                    party._actors.push(replacement);
                    party._saveactors = (party._saveactors || []).filter(function(id) { return Number(id) !== replacement; });
                }
            }
            if (Array.isArray(party._battleMembers)) {
                for (var i = 0; i < party._battleMembers.length; i++) {
                    if (B.isDisabledActor(party._battleMembers[i])) { party._battleMembers[i] = 0; changed = true; }
                }
                if (changed && !party._battleMembers.some(function(id) { return Number(id) > 0; }) && party._actors.length) party._battleMembers[0] = party._actors[0];
            }
            ['_menuActorId','_targetActorId'].forEach(function(key) {
                if (B.isDisabledActor(party[key])) { party[key] = Number(party._actors[0]) || 0; changed = true; }
            });
            return changed;
        } finally { migrating = false; }
    };
    function migrate(party) { var changed = B.migrateParty(party); if (changed) refreshParty(); }
    if (W.DataManager && DataManager.extractSaveContents) {
        var extract = DataManager.extractSaveContents;
        DataManager.extractSaveContents = function() { var out = extract.apply(this, arguments); migrate(W.$gameParty); return out; };
    }
    ['setupStartingMembers','setupBattleTestMembers','initializeBattleMembers','rearrangeActors','swapOrder'].forEach(function(name) {
        var old = Game_Party.prototype[name];
        if (typeof old !== 'function') return;
        Game_Party.prototype[name] = function() {
            B.migrateParty(this);
            var out = old.apply(this, arguments);
            migrate(this);
            return out;
        };
    });
    var addActor = Game_Party.prototype.addActor;
    Game_Party.prototype.addActor = function(id) { if (B.isDisabledActor(id)) return; return addActor.apply(this, arguments); };
    ['allMembers','battleMembers'].forEach(function(name) {
        var old = Game_Party.prototype[name];
        Game_Party.prototype[name] = function() { return old.apply(this, arguments).filter(function(actor) { return actor && !B.isDisabledActor(actor); }); };
    });
    ['setMenuActor','setTargetActor'].forEach(function(name) {
        var old = Game_Party.prototype[name];
        if (typeof old !== 'function') return;
        Game_Party.prototype[name] = function(actor) { if (!actor || B.isDisabledActor(actor)) return; return old.apply(this, arguments); };
    });
    ['canInput','canMove','isFormationChangeOk','isBattleMember'].forEach(function(name) {
        var old = Game_Actor.prototype[name];
        if (typeof old !== 'function') return;
        Game_Actor.prototype[name] = function() { return !B.isDisabledActor(this) && old.apply(this, arguments); };
    });
    var canUse = Game_BattlerBase.prototype.canUse;
    Game_BattlerBase.prototype.canUse = function(item) { return !B.isDisabledActor(this) && !B.isDisabledHorn(item) && canUse.apply(this, arguments); };
    var useItem = Game_Battler.prototype.useItem;
    Game_Battler.prototype.useItem = function(item) { if (B.isDisabledActor(this) || B.isDisabledHorn(item)) return; return useItem.apply(this, arguments); };
    var valid = Game_Action.prototype.isValid;
    Game_Action.prototype.isValid = function() { return !B.isDisabledActor(subjectOf(this)) && !B.isDisabledHorn(this.item && this.item()) && valid.apply(this, arguments); };
    var global = Game_Action.prototype.applyGlobal;
    Game_Action.prototype.applyGlobal = function() { if (B.isDisabledActor(subjectOf(this)) || B.isDisabledHorn(this.item && this.item())) return; return global.apply(this, arguments); };
    if (W.Scene_Shop && Scene_Shop.prototype.prepare) {
        var prepare = Scene_Shop.prototype.prepare;
        Scene_Shop.prototype.prepare = function(goods, purchaseOnly) {
            return prepare.call(this, (goods || []).filter(function(row) { return !(Number(row[0]) === 0 && B.disabledHornIds.indexOf(Number(row[1])) >= 0); }), purchaseOnly);
        };
    }
    if (W.Window_ShopBuy && Window_ShopBuy.prototype.isEnabled) {
        var shopEnabled = Window_ShopBuy.prototype.isEnabled;
        Window_ShopBuy.prototype.isEnabled = function(item) { return !B.isDisabledHorn(item) && shopEnabled.apply(this, arguments); };
    }
    // Warehouse removes an item by its displayed index, so keep retired rows in
    // the list as disabled entries rather than changing the index mapping.
    if (W.Star_Window_PartyList) {
        ['isCurrentItemEnabled','actorIsEnabled'].forEach(function(name) {
            var old = Star_Window_PartyList.prototype[name];
            if (typeof old !== 'function') return;
            Star_Window_PartyList.prototype[name] = function(actor) {
                actor = actor || (this.curActor && this.curActor());
                return !B.isDisabledActor(actor) && old.apply(this, arguments);
            };
        });
    }
    if (W.Star_Scene_ActorWarehouse && Star_Scene_ActorWarehouse.prototype.onActorOk) {
        var warehouseOk = Star_Scene_ActorWarehouse.prototype.onActorOk;
        Star_Scene_ActorWarehouse.prototype.onActorOk = function() {
            var list = this._listWindow, id = list && list._data && list._data[list.index()];
            if (B.isDisabledActor(id)) {
                if (W.SoundManager && SoundManager.playBuzzer) SoundManager.playBuzzer();
                list.activate();
                return;
            }
            var out = warehouseOk.apply(this, arguments); migrate(W.$gameParty); return out;
        };
    }
    if (W.Scene_Party && Scene_Party.prototype.switchActors) {
        var switchActors = Scene_Party.prototype.switchActors;
        Scene_Party.prototype.switchActors = function() {
            if (this._listWindow && B.isDisabledActor(this._listWindow.item())) {
                if (W.SoundManager && SoundManager.playBuzzer) SoundManager.playBuzzer();
                return;
            }
            var out = switchActors.apply(this, arguments); migrate(W.$gameParty); return out;
        };
    }

    // 【Codex·未经Claude检验】12.27 authored effect/skill coefficient balance, not base stats.
    // 【Codex·未经Claude检验】v0.35：精确恢复原缩减项，旧实例只迁移一次。
    var IB=W.CodexImportedEffects={revision:2,patches:{"Weapons":{"52":{"lines":[["<pos=APs text=\\c[1]特效:小破刀(物理伤害+3%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:小破刀(物理伤害+30%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +3%>","<Element Amplify 1: +30%>"]],"traits":[[{"code":22,"dataId":0,"value":0.01},{"code":22,"dataId":0,"value":0.1}],[{"code":22,"dataId":2,"value":0.01},{"code":22,"dataId":2,"value":0.1}]],"meta":{"Element Amplify 1":[" +3%"," +30%"]},"elements":{"1":0.27}},"53":{"lines":[["<pos=APs text=\\c[1]特效:斩月(物理伤害+10%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:斩月(物理伤害+100%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:斩月(双攻*100.5%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:斩月(双攻*105%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +10%>","<Element Amplify 1: +100%>"]],"traits":[[{"code":22,"dataId":0,"value":0.05},{"code":22,"dataId":0,"value":0.5}],[{"code":22,"dataId":2,"value":0.05},{"code":22,"dataId":2,"value":0.5}],[{"code":21,"dataId":2,"value":1.005},{"code":21,"dataId":2,"value":1.05}],[{"code":21,"dataId":4,"value":1.005},{"code":21,"dataId":4,"value":1.05}]],"meta":{"Element Amplify 1":[" +10%"," +100%"]},"elements":{"1":0.9}},"67":{"lines":[["<pos=APs text=\\c[1]特效:卍解-斩月(物理，暗黑伤害+15%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:卍解-斩月(物理，暗黑伤害+150%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:卍解-斩月(双攻*101.5%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:卍解-斩月(双攻*115%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:卍解-斩月(所有敌人种类增伤+1%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:卍解-斩月(所有敌人种类增伤+10%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +15%>","<Element Amplify 1: +150%>"],["<Element Amplify 9: +15%>","<Element Amplify 9: +150%>"],["<EnemyRaceBo01:1%>","<EnemyRaceBo01: 10%>"],["<EnemyRaceBo02:1%>","<EnemyRaceBo02: 10%>"],["<EnemyRaceBo03:1%>","<EnemyRaceBo03: 10%>"],["<EnemyRaceBo04:1%>","<EnemyRaceBo04: 10%>"],["<EnemyRaceBo05:1%>","<EnemyRaceBo05: 10%>"],["<EnemyRaceBo06:1%>","<EnemyRaceBo06: 10%>"],["<EnemyRaceBo07:1%>","<EnemyRaceBo07: 10%>"],["<EnemyRaceBo08:1%>","<EnemyRaceBo08: 10%>"],["<EnemyRaceBo09:1%>","<EnemyRaceBo09: 10%>"],["<EnemyRaceBo10:1%>","<EnemyRaceBo10: 10%>"]],"traits":[[{"code":22,"dataId":0,"value":0.1},{"code":22,"dataId":0,"value":1}],[{"code":22,"dataId":2,"value":0.1},{"code":22,"dataId":2,"value":1}],[{"code":21,"dataId":2,"value":1.015},{"code":21,"dataId":2,"value":1.15}],[{"code":21,"dataId":4,"value":1.015},{"code":21,"dataId":4,"value":1.15}]],"meta":{"Element Amplify 1":[" +15%"," +150%"],"Element Amplify 9":[" +15%"," +150%"],"EnemyRaceBo01":["1%"," 10%"],"EnemyRaceBo02":["1%"," 10%"],"EnemyRaceBo03":["1%"," 10%"],"EnemyRaceBo04":["1%"," 10%"],"EnemyRaceBo05":["1%"," 10%"],"EnemyRaceBo06":["1%"," 10%"],"EnemyRaceBo07":["1%"," 10%"],"EnemyRaceBo08":["1%"," 10%"],"EnemyRaceBo09":["1%"," 10%"],"EnemyRaceBo10":["1%"," 10%"]},"elements":{"1":1.35,"9":1.35}},"68":{"lines":[["<pos=APs text=\\c[1]特效:虚与死神之力(物理，暗黑伤害+30%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:虚与死神之力(物理，暗黑伤害+300%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:虚与死神之力(双攻*103%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:虚与死神之力(双攻*120%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:虚与死神之力(所有敌人种类增伤+2%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:虚与死神之力(所有敌人种类增伤+20%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +30%>","<Element Amplify 1: +300%>"],["<Element Amplify 9: +30%>","<Element Amplify 9: +300%>"],["<EnemyRaceBo01:2%>","<EnemyRaceBo01: 20%>"],["<EnemyRaceBo02:2%>","<EnemyRaceBo02: 20%>"],["<EnemyRaceBo03:2%>","<EnemyRaceBo03: 20%>"],["<EnemyRaceBo04:2%>","<EnemyRaceBo04: 20%>"],["<EnemyRaceBo05:2%>","<EnemyRaceBo05: 20%>"],["<EnemyRaceBo06:2%>","<EnemyRaceBo06: 20%>"],["<EnemyRaceBo07:2%>","<EnemyRaceBo07: 20%>"],["<EnemyRaceBo08:2%>","<EnemyRaceBo08: 20%>"],["<EnemyRaceBo09:2%>","<EnemyRaceBo09: 20%>"],["<EnemyRaceBo10:2%>","<EnemyRaceBo10: 20%>"]],"traits":[[{"code":22,"dataId":0,"value":0.1},{"code":22,"dataId":0,"value":1}],[{"code":22,"dataId":2,"value":0.1},{"code":22,"dataId":2,"value":1}],[{"code":21,"dataId":2,"value":1.03},{"code":21,"dataId":2,"value":1.3}],[{"code":21,"dataId":4,"value":1.03},{"code":21,"dataId":4,"value":1.3}]],"meta":{"Element Amplify 1":[" +30%"," +300%"],"Element Amplify 9":[" +30%"," +300%"],"EnemyRaceBo01":["2%"," 20%"],"EnemyRaceBo02":["2%"," 20%"],"EnemyRaceBo03":["2%"," 20%"],"EnemyRaceBo04":["2%"," 20%"],"EnemyRaceBo05":["2%"," 20%"],"EnemyRaceBo06":["2%"," 20%"],"EnemyRaceBo07":["2%"," 20%"],"EnemyRaceBo08":["2%"," 20%"],"EnemyRaceBo09":["2%"," 20%"],"EnemyRaceBo10":["2%"," 20%"]},"elements":{"1":2.7,"9":2.7}},"69":{"lines":[["<pos=APs text=\\c[1]特效:卍解-灭却师之力(最终伤害，暴击伤害+25%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:卍解-灭却师之力(最终伤害，暴击伤害+250%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:卍解-灭却师之力(双攻*103%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:卍解-灭却师之力(双攻*120%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:卍解-灭却师之力(所有敌人种类增伤+2%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:卍解-灭却师之力(所有敌人种类增伤+20%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<EnemyRaceBo01:2%>","<EnemyRaceBo01: 20%>"],["<EnemyRaceBo02:2%>","<EnemyRaceBo02: 20%>"],["<EnemyRaceBo03:2%>","<EnemyRaceBo03: 20%>"],["<EnemyRaceBo04:2%>","<EnemyRaceBo04: 20%>"],["<EnemyRaceBo05:2%>","<EnemyRaceBo05: 20%>"],["<EnemyRaceBo06:2%>","<EnemyRaceBo06: 20%>"],["<EnemyRaceBo07:2%>","<EnemyRaceBo07: 20%>"],["<EnemyRaceBo08:2%>","<EnemyRaceBo08: 20%>"],["<EnemyRaceBo09:2%>","<EnemyRaceBo09: 20%>"],["<EnemyRaceBo10:2%>","<EnemyRaceBo10: 20%>"],["<passiveCrHarmRi:25>","<passiveCrHarmRi:250>"],["<passiveHarmRi:25>","<passiveHarmRi:250>"]],"traits":[[{"code":22,"dataId":0,"value":0.1},{"code":22,"dataId":0,"value":1}],[{"code":22,"dataId":2,"value":0.1},{"code":22,"dataId":2,"value":1}],[{"code":21,"dataId":2,"value":1.03},{"code":21,"dataId":2,"value":1.3}],[{"code":21,"dataId":4,"value":1.03},{"code":21,"dataId":4,"value":1.3}]],"meta":{"EnemyRaceBo01":["2%"," 20%"],"EnemyRaceBo02":["2%"," 20%"],"EnemyRaceBo03":["2%"," 20%"],"EnemyRaceBo04":["2%"," 20%"],"EnemyRaceBo05":["2%"," 20%"],"EnemyRaceBo06":["2%"," 20%"],"EnemyRaceBo07":["2%"," 20%"],"EnemyRaceBo08":["2%"," 20%"],"EnemyRaceBo09":["2%"," 20%"],"EnemyRaceBo10":["2%"," 20%"],"passiveCrHarmRi":["25","250"],"passiveHarmRi":["25","250"]},"elements":{}},"70":{"lines":[["<pos=APs text=\\c[1]特效:卍解-斩月(物理，暗黑伤害+40%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:卍解-斩月(物理，暗黑伤害+400%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:卍解-斩月(终伤，爆伤+30%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:卍解-斩月(终伤，爆伤+300%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:卍解-斩月(双攻*105%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:卍解-斩月(双攻*150%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:卍解-斩月(所有敌人种类增伤+3%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:卍解-斩月(所有敌人种类增伤+30%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +40%>","<Element Amplify 1: +400%>"],["<Element Amplify 9: +40%>","<Element Amplify 9: +400%>"],["<EnemyRaceBo01:3%>","<EnemyRaceBo01: 30%>"],["<EnemyRaceBo02:3%>","<EnemyRaceBo02: 30%>"],["<EnemyRaceBo03:3%>","<EnemyRaceBo03: 30%>"],["<EnemyRaceBo04:3%>","<EnemyRaceBo04: 30%>"],["<EnemyRaceBo05:3%>","<EnemyRaceBo05: 30%>"],["<EnemyRaceBo06:3%>","<EnemyRaceBo06: 30%>"],["<EnemyRaceBo07:3%>","<EnemyRaceBo07: 30%>"],["<EnemyRaceBo08:3%>","<EnemyRaceBo08: 30%>"],["<EnemyRaceBo09:3%>","<EnemyRaceBo09: 30%>"],["<EnemyRaceBo10:3%>","<EnemyRaceBo10: 30%>"],["<passiveCrHarmRi:30>","<passiveCrHarmRi:300>"],["<passiveHarmRi:30>","<passiveHarmRi:300>"]],"traits":[[{"code":22,"dataId":0,"value":0.1},{"code":22,"dataId":0,"value":1}],[{"code":22,"dataId":2,"value":0.1},{"code":22,"dataId":2,"value":1}],[{"code":21,"dataId":2,"value":1.05},{"code":21,"dataId":2,"value":1.5}],[{"code":21,"dataId":4,"value":1.05},{"code":21,"dataId":4,"value":1.5}]],"meta":{"Element Amplify 1":[" +40%"," +400%"],"Element Amplify 9":[" +40%"," +400%"],"EnemyRaceBo01":["3%"," 30%"],"EnemyRaceBo02":["3%"," 30%"],"EnemyRaceBo03":["3%"," 30%"],"EnemyRaceBo04":["3%"," 30%"],"EnemyRaceBo05":["3%"," 30%"],"EnemyRaceBo06":["3%"," 30%"],"EnemyRaceBo07":["3%"," 30%"],"EnemyRaceBo08":["3%"," 30%"],"EnemyRaceBo09":["3%"," 30%"],"EnemyRaceBo10":["3%"," 30%"],"passiveCrHarmRi":["30","300"],"passiveHarmRi":["30","300"]},"elements":{"1":3.6,"9":3.6}},"71":{"lines":[["<pos=APs text=\\c[1]特效:斩月(物理伤害+30%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:斩月(物理伤害+300%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:斩月(双攻*102%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:斩月(双攻*120%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +30%>","<Element Amplify 1: +300%>"]],"traits":[[{"code":22,"dataId":0,"value":0.1},{"code":22,"dataId":0,"value":1}],[{"code":22,"dataId":2,"value":0.1},{"code":22,"dataId":2,"value":1}],[{"code":21,"dataId":2,"value":1.02},{"code":21,"dataId":2,"value":1.2}],[{"code":21,"dataId":4,"value":1.02},{"code":21,"dataId":4,"value":1.2}]],"meta":{"Element Amplify 1":[" +30%"," +300%"]},"elements":{"1":2.7}},"72":{"lines":[["<pos=APs text=\\c[1]特效:卍解-斩月(物理，暗黑伤害+30%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:卍解-斩月(物理，暗黑伤害+300%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:卍解-斩月(双攻*102.5%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:卍解-斩月(双攻*125%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:卍解-斩月(所有敌人种类增伤+1%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:卍解-斩月(所有敌人种类增伤+10%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +30%>","<Element Amplify 1: +300%>"],["<Element Amplify 9: +30%>","<Element Amplify 9: +300%>"],["<EnemyRaceBo01:1%>","<EnemyRaceBo01: 10%>"],["<EnemyRaceBo02:1%>","<EnemyRaceBo02: 10%>"],["<EnemyRaceBo03:1%>","<EnemyRaceBo03: 10%>"],["<EnemyRaceBo04:1%>","<EnemyRaceBo04: 10%>"],["<EnemyRaceBo05:1%>","<EnemyRaceBo05: 10%>"],["<EnemyRaceBo06:1%>","<EnemyRaceBo06: 10%>"],["<EnemyRaceBo07:1%>","<EnemyRaceBo07: 10%>"],["<EnemyRaceBo08:1%>","<EnemyRaceBo08: 10%>"],["<EnemyRaceBo09:1%>","<EnemyRaceBo09: 10%>"],["<EnemyRaceBo10:1%>","<EnemyRaceBo10: 10%>"]],"traits":[[{"code":22,"dataId":0,"value":0.1},{"code":22,"dataId":0,"value":1}],[{"code":22,"dataId":2,"value":0.1},{"code":22,"dataId":2,"value":1}],[{"code":21,"dataId":2,"value":1.025},{"code":21,"dataId":2,"value":1.25}],[{"code":21,"dataId":4,"value":1.025},{"code":21,"dataId":4,"value":1.25}]],"meta":{"Element Amplify 1":[" +30%"," +300%"],"Element Amplify 9":[" +30%"," +300%"],"EnemyRaceBo01":["1%"," 10%"],"EnemyRaceBo02":["1%"," 10%"],"EnemyRaceBo03":["1%"," 10%"],"EnemyRaceBo04":["1%"," 10%"],"EnemyRaceBo05":["1%"," 10%"],"EnemyRaceBo06":["1%"," 10%"],"EnemyRaceBo07":["1%"," 10%"],"EnemyRaceBo08":["1%"," 10%"],"EnemyRaceBo09":["1%"," 10%"],"EnemyRaceBo10":["1%"," 10%"]},"elements":{"1":2.7,"9":2.7}},"73":{"lines":[["<pos=APs text=\\c[1]祥瑞(独特技能伤害+10%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]祥瑞(独特技能伤害+100%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]麒麟俱灭(爆伤+20%  终伤+20%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]麒麟俱灭(爆伤+200%  终伤+200%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]神圣伤害+15%  命中 暴击+3.5% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]神圣伤害+150%  命中 暴击+35% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<passiveCrHarmRi:10%>","<passiveCrHarmRi:100%>"],["<passiveHarmRi:10%>","<passiveHarmRi:100%>"],["<SkillPass10098:10%>","<SkillPass10098: 100%>"],["<SkillPass10099:10%>","<SkillPass10099: 100%>"],["<SkillPass10100:10%>","<SkillPass10100: 100%>"]],"traits":[[{"code":21,"dataId":1,"value":0.95},{"code":21,"dataId":1,"value":0.5}],[{"code":22,"dataId":0,"value":0.035},{"code":22,"dataId":0,"value":0.35}],[{"code":22,"dataId":2,"value":0.035},{"code":22,"dataId":2,"value":0.35}]],"meta":{"passiveCrHarmRi":["10%","100%"],"passiveHarmRi":["10%","100%"],"SkillPass10098":["10%"," 100%"],"SkillPass10099":["10%"," 100%"],"SkillPass10100":["10%"," 100%"]},"elements":{}},"74":{"lines":[["<pos=APs text=\\c[1]祥瑞(独特技能伤害+20%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]祥瑞(独特技能伤害+200%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]麒麟俱灭(爆伤+15%  终伤+20%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]麒麟俱灭(爆伤+150%  终伤+200%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]神圣伤害+20%  命中 暴击+5% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]神圣伤害+200%  命中 暴击+50% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<passiveCrHarmRi:15%>","<passiveCrHarmRi:150%>"],["<passiveHarmRi:20%>","<passiveHarmRi:200%>"],["<SkillPass10098:20%>","<SkillPass10098: 200%>"],["<SkillPass10099:20%>","<SkillPass10099: 200%>"],["<SkillPass10100:20%>","<SkillPass10100: 200%>"]],"traits":[[{"code":22,"dataId":0,"value":0.05},{"code":22,"dataId":0,"value":0.5}],[{"code":22,"dataId":2,"value":0.05},{"code":22,"dataId":2,"value":0.5}]],"meta":{"passiveCrHarmRi":["15%","150%"],"passiveHarmRi":["20%","200%"],"SkillPass10098":["20%"," 200%"],"SkillPass10099":["20%"," 200%"],"SkillPass10100":["20%"," 200%"]},"elements":{}},"75":{"lines":[["<pos=APs text=\\c[1]祥瑞(独特技能伤害+30%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]祥瑞(独特技能伤害+300%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]麒麟俱灭(爆伤+20%  终伤+20%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]麒麟俱灭(爆伤+200%  终伤+200%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]神圣伤害+25%  命中 暴击+10% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]神圣伤害+250%  命中 暴击+100% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<passiveCrHarmRi:20%>","<passiveCrHarmRi:200%>"],["<passiveHarmRi:20%>","<passiveHarmRi:200%>"],["<SkillPass10098:30%>","<SkillPass10098: 300%>"],["<SkillPass10099:30%>","<SkillPass10099: 300%>"],["<SkillPass10100:30%>","<SkillPass10100: 300%>"]],"traits":[[{"code":21,"dataId":1,"value":1.1},{"code":21,"dataId":1,"value":2}],[{"code":22,"dataId":0,"value":0.1},{"code":22,"dataId":0,"value":1}],[{"code":22,"dataId":2,"value":0.1},{"code":22,"dataId":2,"value":1}]],"meta":{"passiveCrHarmRi":["20%","200%"],"passiveHarmRi":["20%","200%"],"SkillPass10098":["30%"," 300%"],"SkillPass10099":["30%"," 300%"],"SkillPass10100":["30%"," 300%"]},"elements":{}},"76":{"lines":[["<pos=APs text=\\c[1]特效:造成所有伤害结果*125% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:造成所有伤害结果*350% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:神圣伤、冰伤 、黑暗伤 、火伤 、大地、 奥术、 自然、 物理 、雷电 阴阳 混沌伤+60% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:神圣伤、冰伤 、黑暗伤 、火伤 、大地、 奥术、 自然、 物理 、雷电 阴阳 混沌伤+600% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:攻击力能力值*120% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:攻击力能力值*300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +60%>","<Element Amplify 1: +600%>"],["<Element Amplify 2: +60%>","<Element Amplify 2: +600%>"],["<Element Amplify 3: +60%>","<Element Amplify 3: +600%>"],["<Element Amplify 4: +60%>","<Element Amplify 4: +600%>"],["<Element Amplify 5: +60%>","<Element Amplify 5: +600%>"],["<Element Amplify 6: +60%>","<Element Amplify 6: +600%>"],["<Element Amplify 7: +60%>","<Element Amplify 7: +600%>"],["<Element Amplify 8: +60%>","<Element Amplify 8: +600%>"],["<Element Amplify 9: +60%>","<Element Amplify 9: +600%>"],["<Element Amplify 11: +60%>","<Element Amplify 11: +600%>"],["<Element Amplify 12: +60%>","<Element Amplify 12: +600%>"],["<passiveHarmRi:45>","<passiveHarmRi:450>"],["<passiveCrHarmRi:45>","<passiveCrHarmRi:450>"],["<StartPushState2718: 100%>","<StartPushState2301: 100%>"]],"traits":[[{"code":21,"dataId":2,"value":1.2},{"code":21,"dataId":2,"value":3}]],"meta":{"Element Amplify 1":[" +60%"," +600%"],"Element Amplify 2":[" +60%"," +600%"],"Element Amplify 3":[" +60%"," +600%"],"Element Amplify 4":[" +60%"," +600%"],"Element Amplify 5":[" +60%"," +600%"],"Element Amplify 6":[" +60%"," +600%"],"Element Amplify 7":[" +60%"," +600%"],"Element Amplify 8":[" +60%"," +600%"],"Element Amplify 9":[" +60%"," +600%"],"Element Amplify 11":[" +60%"," +600%"],"Element Amplify 12":[" +60%"," +600%"],"passiveHarmRi":["45","450"],"passiveCrHarmRi":["45","450"],"StartPushState2718":[" 100%",null]},"elements":{"1":5.4,"2":5.4,"3":5.4,"4":5.4,"5":5.4,"6":5.4,"7":5.4,"8":5.4,"9":5.4,"11":5.4,"12":5.4}},"77":{"lines":[["<pos=APs text=\\c[1]特效:神兵(最终伤害+15%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:神兵(最终伤害+150%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:炎舞(火焰伤害+30%，攻击属性：火焰) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:炎舞(火焰伤害+300%，攻击属性：火焰) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=暴击率+30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率+300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 2: +30%>","<Element Amplify 2: +300%>"],["<passiveHarmRi:15>","<passiveHarmRi:150>"]],"traits":[[{"code":22,"dataId":2,"value":0.3},{"code":22,"dataId":2,"value":3}]],"meta":{"Element Amplify 2":[" +30%"," +300%"],"passiveHarmRi":["15","150"]},"elements":{"2":2.7}},"78":{"lines":[["<pos=APs text=\\c[1]特效:仙剑(最终伤害+50%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:仙剑(最终伤害+500%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:剑道(物理伤害+120%，攻击属性：物理) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:剑道(物理伤害+1200%，攻击属性：物理) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=暴击率/命中率+300% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率/命中率+3000% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +120%>","<Element Amplify 1: +1200%>"],["<passiveHarmRi:50>","<passiveHarmRi:500>"]],"traits":[[{"code":22,"dataId":2,"value":1},{"code":22,"dataId":2,"value":10}],[{"code":22,"dataId":2,"value":1},{"code":22,"dataId":2,"value":10}],[{"code":22,"dataId":2,"value":1},{"code":22,"dataId":2,"value":10}],[{"code":22,"dataId":0,"value":1},{"code":22,"dataId":0,"value":10}],[{"code":22,"dataId":0,"value":1},{"code":22,"dataId":0,"value":10}],[{"code":22,"dataId":0,"value":1},{"code":22,"dataId":0,"value":10}]],"meta":{"Element Amplify 1":[" +120%"," +1200%"],"passiveHarmRi":["50","500"]},"elements":{"1":10.8}},"79":{"lines":[["<pos=APs text=暴击率+20% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率+200% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:往生枪法(普通攻击变成往生秘传枪法，每三段为重击，附加目标当前生命值0.2%伤害) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:往生枪法(普通攻击变成往生秘传枪法，每三段为重击，附加目标当前生命值2%伤害) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:五星武器(终伤+18%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:五星武器(终伤+180%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:双攻*108% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:双攻*180% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:最大生命值*114%  size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:最大生命值240%  size=18 color=rgba(255,255,255,1) line=false align=0>"]],"traits":[[{"code":22,"dataId":2,"value":0.2},{"code":22,"dataId":2,"value":2}],[{"code":21,"dataId":2,"value":1.08},{"code":21,"dataId":2,"value":1.8}],[{"code":21,"dataId":4,"value":1.08},{"code":21,"dataId":4,"value":1.8}],[{"code":21,"dataId":0,"value":1.14},{"code":21,"dataId":0,"value":2.4}]],"meta":{},"elements":{}},"80":{"lines":[["<pos=APs text=\\c[1]特效:硬币(最终伤害+60%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:硬币(最终伤害+600%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:电击公主(雷电伤害+100%，攻击属性：雷电) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:电击公主(雷电伤害+1000%，攻击属性：雷电) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:超电磁炮(专属技能伤害+100%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:超电磁炮(专属技能伤害+1000%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=暴击率+30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率+300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 5: +100%>","<Element Amplify 5: +1000%>"],["<DepassiveHarmRe04:5%>","<DepassiveHarmRe04: 50%>"],["<passiveHarmRi:60>","<passiveHarmRi:600>"],["<SkillPass10048:100%>","<SkillPass10048: 1000%>"],["<SkillPass10049:100%>","<SkillPass10049: 1000%>"]],"traits":[[{"code":22,"dataId":2,"value":0.3},{"code":22,"dataId":2,"value":3}]],"meta":{"Element Amplify 5":[" +100%"," +1000%"],"DepassiveHarmRe04":["5%"," 50%"],"passiveHarmRi":["60","600"],"SkillPass10048":["100%"," 1000%"],"SkillPass10049":["100%"," 1000%"]},"elements":{"5":9}},"81":{"lines":[["<pos=APs text=\\c[1]特效:神兵(最终伤害+60%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:神兵(最终伤害+600%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:黑夜行者(物理伤害+100%，攻击属性：物理) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:黑夜行者(物理伤害+1000%，攻击属性：物理) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:星爆气流斩(星爆气流斩专属伤害+500%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:星爆气流斩(星爆气流斩专属伤害+5000%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=暴击率+30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率+300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +100%>","<Element Amplify 1: +1000%>"],["<DepassiveHarmRe01:5%>","<DepassiveHarmRe01: 50%>"],["<passiveHarmRi:60>","<passiveHarmRi:600>"],["<SkillPass9973:500%>","<SkillPass9973: 5000%>"]],"traits":[[{"code":22,"dataId":2,"value":0.3},{"code":22,"dataId":2,"value":3}]],"meta":{"Element Amplify 1":[" +100%"," +1000%"],"DepassiveHarmRe01":["5%"," 50%"],"passiveHarmRi":["60","600"],"SkillPass9973":["500%"," 5000%"]},"elements":{"1":9}},"82":{"lines":[["<pos=APs text=\\c[1]特效:神兵(最终伤害+60%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:神兵(最终伤害+600%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:烈火(火焰伤害+100%，攻击属性：火焰) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:烈火(火焰伤害+1000%，攻击属性：火焰) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:爆裂魔法(爆裂魔法专属伤害+500%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:爆裂魔法(爆裂魔法专属伤害+5000%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=暴击率+30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率+300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 2: +100%>","<Element Amplify 2: +1000%>"],["<DepassiveHarmRe02:5%>","<DepassiveHarmRe02: 50%>"],["<passiveHarmRi:60>","<passiveHarmRi:600>"],["<SkillPass10007:100%>","<SkillPass10007: 1000%>"]],"traits":[[{"code":22,"dataId":2,"value":0.3},{"code":22,"dataId":2,"value":3}]],"meta":{"Element Amplify 2":[" +100%"," +1000%"],"DepassiveHarmRe02":["5%"," 50%"],"passiveHarmRi":["60","600"],"SkillPass10007":["100%"," 1000%"]},"elements":{"2":9}},"83":{"lines":[["<pos=APs text=\\c[1]特效:神兵(最终伤害+60%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:神兵(最终伤害+600%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:火雾战士(火炎伤害+100%，攻击属性：火伤) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:火雾战士(火炎伤害+1000%，攻击属性：火伤) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:天破壤碎(天破壤碎专属伤害+100%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:天破壤碎(天破壤碎专属伤害+1000%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=暴击率+30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率+300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 2: +100%>","<Element Amplify 2: +1000%>"],["<DepassiveHarmRe02:5%>","<DepassiveHarmRe02: 50%>"],["<passiveHarmRi:60>","<passiveHarmRi:600>"],["<SkillPass9973:100%>","<SkillPass9973: 1000%>"]],"traits":[[{"code":22,"dataId":2,"value":0.3},{"code":22,"dataId":2,"value":3}]],"meta":{"Element Amplify 2":[" +100%"," +1000%"],"DepassiveHarmRe02":["5%"," 50%"],"passiveHarmRi":["60","600"],"SkillPass9973":["100%"," 1000%"]},"elements":{"2":9}},"85":{"lines":[["<pos=APs text=\\c[1]特效:神兵(最终伤害+60%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:神兵(最终伤害+600%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:枪炮大师(无属性伤害+30%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:枪炮大师(无属性伤害+300%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:病娇(巴雷特/加特林专属伤害+50%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:病娇(巴雷特/加特林专属伤害+500%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=暴击率+30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率+300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 0: +30%>","<Element Amplify 0: +300%>"],["<DepassiveHarmRe01:10%>","<DepassiveHarmRe01: 100%>"],["<passiveHarmRi:60>","<passiveHarmRi:600>"],["<SkillPass10023:50%>","<SkillPass10023: 500%>"],["<SkillPass10028:50%>","<SkillPass10028: 500%>"]],"traits":[[{"code":22,"dataId":2,"value":0.3},{"code":22,"dataId":2,"value":3}]],"meta":{"Element Amplify 0":[" +30%"," +300%"],"DepassiveHarmRe01":["10%"," 100%"],"passiveHarmRi":["60","600"],"SkillPass10023":["50%"," 500%"],"SkillPass10028":["50%"," 500%"]},"elements":{"0":2.7}},"86":{"lines":[["<pos=APs text=\\c[1]特效:神宠(最终伤害+60%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:神宠(最终伤害+600%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:上神(神圣伤害+100%，攻击属性：神圣) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:上神(神圣伤害+1000%，攻击属性：神圣) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:弦月乱舞(弦月乱舞专属伤害+100%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:弦月乱舞(弦月乱舞专属伤害+1000%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=暴击率+30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率+300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 8: +100%>","<Element Amplify 8: +1000%>"],["<DepassiveHarmRe08:5%>","<DepassiveHarmRe08: 50%>"],["<passiveHarmRi:60>","<passiveHarmRi:600>"],["<SkillPass5801:100%>","<SkillPass5801: 1000%>"]],"traits":[[{"code":22,"dataId":2,"value":0.3},{"code":22,"dataId":2,"value":3}]],"meta":{"Element Amplify 8":[" +100%"," +1000%"],"DepassiveHarmRe08":["5%"," 50%"],"passiveHarmRi":["60","600"],"SkillPass5801":["100%"," 1000%"]},"elements":{"8":9}},"87":{"lines":[["<pos=APs text=\\c[1]特效:神兵(最终伤害+60%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:神兵(最终伤害+600%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:星火燎原(火焰/物理伤害+120%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:星火燎原(火焰/物理伤害+1200%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:火之领域(专属技能伤害+150%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:火之领域(专属技能伤害+1500%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=暴击率+50% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率+500% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +120%>","<Element Amplify 1: +1200%>"],["<Element Amplify 2: +120%>","<Element Amplify 2: +1200%>"],["<DepassiveHarmRe01:8%>","<DepassiveHarmRe01: 80%>"],["<DepassiveHarmRe01:8%>","<DepassiveHarmRe01: 80%>"],["<passiveHarmRi:60>","<passiveHarmRi:600>"],["<SkillPass10055:150%>","<SkillPass10055: 1500%>"],["<SkillPass10056:150%>","<SkillPass10056: 1500%>"],["<SkillPass10057:150%>","<SkillPass10057: 1500%>"],["<SkillPass10058:150%>","<SkillPass10058: 1500%>"]],"traits":[[{"code":22,"dataId":2,"value":0.3},{"code":22,"dataId":2,"value":3}]],"meta":{"Element Amplify 1":[" +120%"," +1200%"],"Element Amplify 2":[" +120%"," +1200%"],"DepassiveHarmRe01":["8%"," 80%"],"passiveHarmRi":["60","600"],"SkillPass10055":["150%"," 1500%"],"SkillPass10056":["150%"," 1500%"],"SkillPass10057":["150%"," 1500%"],"SkillPass10058":["150%"," 1500%"]},"elements":{"1":10.8,"2":10.8}},"88":{"lines":[["<pos=APs text=\\c[1]特效:神兵(最终伤害+60%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:神兵(最终伤害+600%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:血梅香(物理伤害+100%,火焰伤害+150%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:血梅香(物理伤害+1000%,火焰伤害+1500%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:赤团开时斜飞去(专属技能伤害+150%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:赤团开时斜飞去(专属技能伤害+1500%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=暴击率+30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率+300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +100%>","<Element Amplify 1: +1000%>"],["<Element Amplify 2: +150%>","<Element Amplify 2: +1500%>"],["<DepassiveHarmRe01:5%>","<DepassiveHarmRe01: 50%>"],["<DepassiveHarmRe02:10%>","<DepassiveHarmRe02: 100%>"],["<passiveHarmRi:60>","<passiveHarmRi:600>"],["<SkillPass6289:150%>","<SkillPass6289: 1500%>"],["<SkillPass10067:150%>","<SkillPass10067: 1500%>"],["<SkillPass10070:150%>","<SkillPass10070: 1500%>"],["<SkillPass10071:150%>","<SkillPass10071: 1500%>"]],"traits":[[{"code":22,"dataId":2,"value":0.3},{"code":22,"dataId":2,"value":3}]],"meta":{"Element Amplify 1":[" +100%"," +1000%"],"Element Amplify 2":[" +150%"," +1500%"],"DepassiveHarmRe01":["5%"," 50%"],"DepassiveHarmRe02":["10%"," 100%"],"passiveHarmRi":["60","600"],"SkillPass6289":["150%"," 1500%"],"SkillPass10067":["150%"," 1500%"],"SkillPass10070":["150%"," 1500%"],"SkillPass10071":["150%"," 1500%"]},"elements":{"1":9,"2":13.5}},"89":{"lines":[["<pos=APs text=\\c[1]特效:神兵(最终伤害+60%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:神兵(最终伤害+600%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:大妖(物理伤害+100%,生命值+200%,攻击属性：物理) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:大妖(物理伤害+1000%,生命值+2000%,攻击属性：物理) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:尧天(专属技能伤害+100%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:尧天(专属技能伤害+1000%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=暴击率+30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率+300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +100%>","<Element Amplify 1: +1000%>"],["<DepassiveHarmRe01:5%>","<DepassiveHarmRe01: 50%>"],["<passiveHarmRi:60>","<passiveHarmRi:600>"]],"traits":[[{"code":22,"dataId":2,"value":0.3},{"code":22,"dataId":2,"value":3}],[{"code":21,"dataId":0,"value":1.9},{"code":21,"dataId":0,"value":10}],[{"code":21,"dataId":0,"value":1.9},{"code":21,"dataId":0,"value":10}]],"meta":{"Element Amplify 1":[" +100%"," +1000%"],"DepassiveHarmRe01":["5%"," 50%"],"passiveHarmRi":["60","600"]},"elements":{"1":9}},"90":{"lines":[["<pos=APs text=\\c[1]特效:神武(最终伤害+100%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:神武(最终伤害+1000%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<DepassiveHarmRe01:10%>","<DepassiveHarmRe01: 100%>"],["<passiveHarmRi:100>","<passiveHarmRi:1000>"]],"traits":[],"meta":{"DepassiveHarmRe01":["10%"," 100%"],"passiveHarmRi":["100","1000"]},"elements":{}},"91":{"lines":[["<pos=APs text=\\c[1]特效:仙气(最终伤害+150%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:仙气(最终伤害+1500%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:超赛红(物理伤害+300%，攻击属性：物理) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:超赛红(物理伤害+3000%，攻击属性：物理) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:大道(专属技能伤害+150%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:大道(专属技能伤害+1500%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=暴击率+100% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率+1000% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +300%>","<Element Amplify 1: +3000%>"],["<DepassiveHarmRe01:15%>","<DepassiveHarmRe01: 150%>"],["<passiveHarmRi:150>","<passiveHarmRi:1500>"],["<SkillPass9944:150%>","<SkillPass9944: 1500%>"],["<SkillPass9945:150%>","<SkillPass9945: 1500%>"],["<SkillPass9948:150%>","<SkillPass9948: 1500%>"],["<SkillPass9949:150%>","<SkillPass9949: 1500%>"]],"traits":[[{"code":22,"dataId":2,"value":1},{"code":22,"dataId":2,"value":10}]],"meta":{"Element Amplify 1":[" +300%"," +3000%"],"DepassiveHarmRe01":["15%"," 150%"],"passiveHarmRi":["150","1500"],"SkillPass9944":["150%"," 1500%"],"SkillPass9945":["150%"," 1500%"],"SkillPass9948":["150%"," 1500%"],"SkillPass9949":["150%"," 1500%"]},"elements":{"1":27}},"92":{"lines":[["<pos=APs text=\\c[3]特效:真·神兵(最终伤害+500%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[3]特效:真·神兵(最终伤害+5000%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[4]特效:真·极道(物理伤害+1000%，攻击属性：物理) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[4]特效:真·极道(物理伤害+10000%，攻击属性：物理) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[5]特效:真·剑舞(普通攻击变为释放万剑归宗 万剑归宗专属伤害+300%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[5]特效:真·剑舞(普通攻击变为释放万剑归宗 万剑归宗专属伤害+3000%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[7]特效:真·破败(无视敌人物理抗性+20%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[7]特效:真·破败(无视敌人物理抗性+200%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[8]特效:真·统领(暴击率+100% 全闪避+100%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[8]特效:真·统领(暴击率+1000% 全闪避+1000%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +1000%>","<Element Amplify 1: +10000%>"],["<DepassiveHarmRe01:20%>","<DepassiveHarmRe01: 200%>"],["<passiveHarmRi:500>","<passiveHarmRi:5000>"],["<SkillPass9926:300%>","<SkillPass9926: 3000%>"]],"traits":[[{"code":22,"dataId":2,"value":1},{"code":22,"dataId":2,"value":10}],[{"code":22,"dataId":3,"value":1},{"code":22,"dataId":3,"value":10}],[{"code":22,"dataId":4,"value":1},{"code":22,"dataId":4,"value":10}],[{"code":22,"dataId":5,"value":1},{"code":22,"dataId":5,"value":10}],[{"code":22,"dataId":6,"value":1},{"code":22,"dataId":6,"value":10}]],"meta":{"pos=APs text=\\c[3]特效":["真·神兵(最终伤害+500%) size=18 color=rgba(255,255,255,1) line=false align=0","真·神兵(最终伤害+5000%) size=18 color=rgba(255,255,255,1) line=false align=0"],"pos=APs text=\\c[4]特效":["真·极道(物理伤害+1000%，攻击属性：物理) size=18 color=rgba(255,255,255,1) line=false align=0","真·极道(物理伤害+10000%，攻击属性：物理) size=18 color=rgba(255,255,255,1) line=false align=0"],"pos=APs text=\\c[5]特效":["真·剑舞(普通攻击变为释放万剑归宗 万剑归宗专属伤害+300%) size=18 color=rgba(255,255,255,1) line=false align=0","真·剑舞(普通攻击变为释放万剑归宗 万剑归宗专属伤害+3000%) size=18 color=rgba(255,255,255,1) line=false align=0"],"pos=APs text=\\c[7]特效":["真·破败(无视敌人物理抗性+20%) size=18 color=rgba(255,255,255,1) line=false align=0","真·破败(无视敌人物理抗性+200%) size=18 color=rgba(255,255,255,1) line=false align=0"],"pos=APs text=\\c[8]特效":["真·统领(暴击率+100% 全闪避+100%) size=18 color=rgba(255,255,255,1) line=false align=0","真·统领(暴击率+1000% 全闪避+1000%) size=18 color=rgba(255,255,255,1) line=false align=0"],"Element Amplify 1":[" +1000%"," +10000%"],"DepassiveHarmRe01":["20%"," 200%"],"passiveHarmRi":["500","5000"],"SkillPass9926":["300%"," 3000%"]},"elements":{"1":90}},"93":{"lines":[["<pos=APs text=\\c[1]特效:神迹(最终伤害+100%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:神迹(最终伤害+1000%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:领主(全伤+80%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:领主(全伤+800%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:吞噬星空(普通攻击变为吞噬吧，黑炎！ 专属伤害+300%) size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:吞噬星空(普通攻击变为吞噬吧，黑炎！ 专属伤害+3000%) size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=暴击率+30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率+300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +80%>","<Element Amplify 1: +800%>"],["<Element Amplify 2: +80%>","<Element Amplify 2: +800%>"],["<Element Amplify 3: +80%>","<Element Amplify 3: +800%>"],["<Element Amplify 4: +80%>","<Element Amplify 4: +800%>"],["<Element Amplify 5: +80%>","<Element Amplify 5: +800%>"],["<Element Amplify 6: +80%>","<Element Amplify 6: +800%>"],["<Element Amplify 7: +80%>","<Element Amplify 7: +800%>"],["<Element Amplify 8: +80%>","<Element Amplify 8: +800%>"],["<Element Amplify 9: +80%>","<Element Amplify 9: +800%>"],["<passiveHarmRi:100>","<passiveHarmRi:1000>"],["<SkillPass5636:300%>","<SkillPass5636: 3000%>"]],"traits":[[{"code":22,"dataId":2,"value":0.3},{"code":22,"dataId":2,"value":3}]],"meta":{"Element Amplify 1":[" +80%"," +800%"],"Element Amplify 2":[" +80%"," +800%"],"Element Amplify 3":[" +80%"," +800%"],"Element Amplify 4":[" +80%"," +800%"],"Element Amplify 5":[" +80%"," +800%"],"Element Amplify 6":[" +80%"," +800%"],"Element Amplify 7":[" +80%"," +800%"],"Element Amplify 8":[" +80%"," +800%"],"Element Amplify 9":[" +80%"," +800%"],"passiveHarmRi":["100","1000"],"SkillPass5636":["300%"," 3000%"]},"elements":{"1":7.2,"2":7.2,"3":7.2,"4":7.2,"5":7.2,"6":7.2,"7":7.2,"8":7.2,"9":7.2}},"94":{"lines":[["<pos=APs text=\\c[2]特效:造成所有伤害结果*170% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[2]特效:造成所有伤害结果*800% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[3]特效:神圣伤、冰伤 、黑暗伤 、火伤 、大地、 奥术、 自然、 物理 、雷电 阴阳 混沌伤+100% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[3]特效:神圣伤、冰伤 、黑暗伤 、火伤 、大地、 奥术、 自然、 物理 、雷电 阴阳 混沌伤+1000% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[4]特效:攻击力能力值*190% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[4]特效:攻击力能力值*1000% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[6]特效:爆伤终伤+120% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[6]特效:爆伤终伤+1200% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +100%>","<Element Amplify 1: +1000%>"],["<Element Amplify 2: +100%>","<Element Amplify 2: +1000%>"],["<Element Amplify 3: +100%>","<Element Amplify 3: +1000%>"],["<Element Amplify 4: +100%>","<Element Amplify 4: +1000%>"],["<Element Amplify 5: +100%>","<Element Amplify 5: +1000%>"],["<Element Amplify 6: +100%>","<Element Amplify 6: +1000%>"],["<Element Amplify 7: +100%>","<Element Amplify 7: +1000%>"],["<Element Amplify 8: +100%>","<Element Amplify 8: +1000%>"],["<Element Amplify 9: +100%>","<Element Amplify 9: +1000%>"],["<Element Amplify 11: +100%>","<Element Amplify 11: +1000%>"],["<Element Amplify 12: +100%>","<Element Amplify 12: +1000%>"],["<passiveHarmRi:120>","<passiveHarmRi:1200>"],["<passiveCrHarmRi:120>","<passiveCrHarmRi:1200>"],["<Element Amplify 13: +100%>","<Element Amplify 13: +1000%>"],["<Element Amplify 14: +100%>","<Element Amplify 14: +1000%>"],["<Element Amplify 15: +100%>","<Element Amplify 15: +1000%>"]],"traits":[[{"code":21,"dataId":2,"value":1.9},{"code":21,"dataId":2,"value":10}]],"meta":{"pos=APs text=\\c[2]特效":["造成所有伤害结果*170% size=18 color=rgba(255,255,255,1) line=false align=0","造成所有伤害结果*800% size=18 color=rgba(255,255,255,1) line=false align=0"],"pos=APs text=\\c[3]特效":["神圣伤、冰伤 、黑暗伤 、火伤 、大地、 奥术、 自然、 物理 、雷电 阴阳 混沌伤+100% size=18 color=rgba(255,255,255,1) line=false align=0","神圣伤、冰伤 、黑暗伤 、火伤 、大地、 奥术、 自然、 物理 、雷电 阴阳 混沌伤+1000% size=18 color=rgba(255,255,255,1) line=false align=0"],"pos=APs text=\\c[4]特效":["攻击力能力值*190% size=18 color=rgba(255,255,255,1) line=false align=0","攻击力能力值*1000% size=18 color=rgba(255,255,255,1) line=false align=0"],"pos=APs text=\\c[6]特效":["爆伤终伤+120% size=18 color=rgba(255,255,255,1) line=false align=0","爆伤终伤+1200% size=18 color=rgba(255,255,255,1) line=false align=0"],"Element Amplify 1":[" +100%"," +1000%"],"Element Amplify 2":[" +100%"," +1000%"],"Element Amplify 3":[" +100%"," +1000%"],"Element Amplify 4":[" +100%"," +1000%"],"Element Amplify 5":[" +100%"," +1000%"],"Element Amplify 6":[" +100%"," +1000%"],"Element Amplify 7":[" +100%"," +1000%"],"Element Amplify 8":[" +100%"," +1000%"],"Element Amplify 9":[" +100%"," +1000%"],"Element Amplify 11":[" +100%"," +1000%"],"Element Amplify 12":[" +100%"," +1000%"],"passiveHarmRi":["120","1200"],"passiveCrHarmRi":["120","1200"],"Element Amplify 13":[" +100%"," +1000%"],"Element Amplify 14":[" +100%"," +1000%"],"Element Amplify 15":[" +100%"," +1000%"]},"elements":{"1":9,"2":9,"3":9,"4":9,"5":9,"6":9,"7":9,"8":9,"9":9,"11":9,"12":9,"13":9,"14":9,"15":9}}},"Armors":{"48":{"lines":[["<pos=APs text=暴击、命中+0.1% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击、命中+1% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：女帝独有技能伤害+30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：女帝独有技能伤害+300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass9908:30%>","<SkillPass9908: 300%>"],["<SkillPass9909:30%>","<SkillPass9909: 300%>"],["<SkillPass9910:30%>","<SkillPass9910: 300%>"],["<SkillPass9914:30%>","<SkillPass9914: 300%>"],["<SkillPass9924:30%>","<SkillPass9924: 300%>"],["<SkillPass9925:30%>","<SkillPass9925: 300%>"]],"traits":[[{"code":22,"dataId":2,"value":0.001},{"code":22,"dataId":2,"value":0.01}],[{"code":22,"dataId":0,"value":0.001},{"code":22,"dataId":0,"value":0.01}]],"meta":{"SkillPass9908":["30%"," 300%"],"SkillPass9909":["30%"," 300%"],"SkillPass9910":["30%"," 300%"],"SkillPass9914":["30%"," 300%"],"SkillPass9924":["30%"," 300%"],"SkillPass9925":["30%"," 300%"]},"elements":{}},"49":{"lines":[["<pos=APs text=\\c[1]全属性*102% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]全属性*120% size=18 color=rgba(255,255,255,1) line=false align=0>"]],"traits":[[{"code":22,"dataId":2,"value":0.001},{"code":22,"dataId":2,"value":0.01}],[{"code":22,"dataId":0,"value":0.001},{"code":22,"dataId":0,"value":0.01}]],"meta":{},"elements":{}},"77":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：所有专属技能伤害增加15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有专属技能伤害增加150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass9972:15%>","<SkillPass9972: 150%>"],["<SkillPass9973:15%>","<SkillPass9973: 150%>"],["<SkillPass9974:15%>","<SkillPass9974: 150%>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.01},{"code":21,"dataId":1,"value":1.1}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}]],"meta":{"SkillPass9972":["15%"," 150%"],"SkillPass9973":["15%"," 150%"],"SkillPass9974":["15%"," 150%"]},"elements":{}},"96":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：所有专属技能伤害增加15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有专属技能伤害增加150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass9972:15%>","<SkillPass9972: 150%>"],["<SkillPass9973:15%>","<SkillPass9973: 150%>"],["<SkillPass9974:15%>","<SkillPass9974: 150%>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.01},{"code":21,"dataId":1,"value":1.1}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}]],"meta":{"SkillPass9972":["15%"," 150%"],"SkillPass9973":["15%"," 150%"],"SkillPass9974":["15%"," 150%"]},"elements":{}},"115":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：所有专属技能伤害增加15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有专属技能伤害增加150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass10006:15%>","<SkillPass10006: 150%>"],["<SkillPass10007:15%>","<SkillPass10007: 150%>"],["<SkillPass10008:15%>","<SkillPass10008: 150%>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.01},{"code":21,"dataId":1,"value":1.1}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}]],"meta":{"SkillPass10006":["15%"," 150%"],"SkillPass10007":["15%"," 150%"],"SkillPass10008":["15%"," 150%"]},"elements":{}},"116":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：所有专属技能伤害增加15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有专属技能伤害增加150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：火伤+15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：火伤+150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass5769:15%>","<SkillPass5769: 150%>"],["<SkillPass10015:15%>","<SkillPass10015: 150%>"],["<SkillPass10016:15%>","<SkillPass10016: 150%>"],["<passiveELUP02:20%>","<passiveELUP02:200%>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.01},{"code":21,"dataId":1,"value":1.1}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}]],"meta":{"SkillPass5769":["15%"," 150%"],"SkillPass10015":["15%"," 150%"],"SkillPass10016":["15%"," 150%"],"passiveELUP02":["20%","200%"]},"elements":{}},"117":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：所有专属技能伤害增加15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有专属技能伤害增加150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass10020:15%>","<SkillPass10020: 150%>"],["<SkillPass10023:15%>","<SkillPass10023: 150%>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.01},{"code":21,"dataId":1,"value":1.1}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}]],"meta":{"SkillPass10020":["15%"," 150%"],"SkillPass10023":["15%"," 150%"]},"elements":{}},"118":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：所有专属技能伤害增加15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有专属技能伤害增加150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass5801:15%>","<SkillPass5801: 150%>"],["<SkillPass10035:15%>","<SkillPass10035: 150%>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.01},{"code":21,"dataId":1,"value":1.1}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}]],"meta":{"SkillPass5801":["15%"," 150%"],"SkillPass10035":["15%"," 150%"]},"elements":{}},"119":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：所有专属技能伤害增加15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有专属技能伤害增加150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass10048:15%>","<SkillPass10048: 150%>"],["<SkillPass10049:15%>","<SkillPass10049: 150%>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.01},{"code":21,"dataId":1,"value":1.1}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}]],"meta":{"SkillPass10048":["15%"," 150%"],"SkillPass10049":["15%"," 150%"]},"elements":{}},"120":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：所有专属技能伤害增加15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有专属技能伤害增加150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：火伤+30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：火伤+300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass10055:15%>","<SkillPass10055: 150%>"],["<SkillPass10056:15%>","<SkillPass10056: 150%>"],["<SkillPass10057:15%>","<SkillPass10057: 150%>"],["<SkillPass10058:15%>","<SkillPass10058: 150%>"],["<passiveELUP02:30%>","<passiveELUP02:300%>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.01},{"code":21,"dataId":1,"value":1.1}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}]],"meta":{"SkillPass10055":["15%"," 150%"],"SkillPass10056":["15%"," 150%"],"SkillPass10057":["15%"," 150%"],"SkillPass10058":["15%"," 150%"],"passiveELUP02":["30%","300%"]},"elements":{}},"122":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：所有专属技能伤害增加15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有专属技能伤害增加150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：火伤+50% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：火伤+500% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass6289:15%>","<SkillPass6289: 150%>"],["<SkillPass10067:15%>","<SkillPass10067: 150%>"],["<SkillPass10070:15%>","<SkillPass10070: 150%>"],["<SkillPass10071:15%>","<SkillPass10071: 150%>"],["<passiveELUP02:50%>","<passiveELUP02:500%>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.01},{"code":21,"dataId":1,"value":1.1}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}]],"meta":{"SkillPass6289":["15%"," 150%"],"SkillPass10067":["15%"," 150%"],"SkillPass10070":["15%"," 150%"],"SkillPass10071":["15%"," 150%"],"passiveELUP02":["50%","500%"]},"elements":{}},"123":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：所有专属技能伤害增加15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有专属技能伤害增加150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：物理伤害+30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：物理伤害+300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<passiveELUP01:30%>","<passiveELUP01:300%>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.01},{"code":21,"dataId":1,"value":1.1}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}]],"meta":{"passiveELUP01":["30%","300%"]},"elements":{}},"124":{"lines":[["<pos=APs text=\\c[1]特效：物理伤害+100% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：物理伤害+1000% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass5574:15%>","<SkillPass5574: 150%>"],["<passiveELUP01:100%>","<passiveELUP01:1000%>"]],"traits":[],"meta":{"SkillPass5574":["15%"," 150%"],"passiveELUP01":["100%","1000%"]},"elements":{}},"125":{"lines":[["<pos=APs text=\\c[1]特效：所有专属技能伤害增加30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有专属技能伤害增加300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：物理伤害+50% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：物理伤害+500% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass9944:15%>","<SkillPass9944: 150%>"],["<SkillPass9945:15%>","<SkillPass9945: 150%>"],["<SkillPass9948:15%>","<SkillPass9948: 150%>"],["<SkillPass9949:15%>","<SkillPass9949: 150%>"],["<passiveELUP01:50%>","<passiveELUP01:500%>"]],"traits":[[{"code":21,"dataId":0,"value":1.1},{"code":21,"dataId":0,"value":2}],[{"code":21,"dataId":1,"value":1.1},{"code":21,"dataId":1,"value":2}],[{"code":21,"dataId":2,"value":1.1},{"code":21,"dataId":2,"value":2}],[{"code":21,"dataId":3,"value":1.1},{"code":21,"dataId":3,"value":2}],[{"code":21,"dataId":4,"value":1.1},{"code":21,"dataId":4,"value":2}],[{"code":21,"dataId":6,"value":1.1},{"code":21,"dataId":6,"value":2}],[{"code":21,"dataId":5,"value":1.1},{"code":21,"dataId":5,"value":2}],[{"code":21,"dataId":7,"value":1.1},{"code":21,"dataId":7,"value":2}]],"meta":{"SkillPass9944":["15%"," 150%"],"SkillPass9945":["15%"," 150%"],"SkillPass9948":["15%"," 150%"],"SkillPass9949":["15%"," 150%"],"passiveELUP01":["50%","500%"]},"elements":{}},"126":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：所有专属技能伤害增加15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有专属技能伤害增加150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：物理伤害+30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：物理伤害+300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass9926:15%>","<SkillPass9926: 150%>"],["<passiveELUP01:30%>","<passiveELUP01:300%>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.01},{"code":21,"dataId":1,"value":1.1}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}]],"meta":{"SkillPass9926":["15%"," 150%"],"passiveELUP01":["30%","300%"]},"elements":{}},"127":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：所有专属技能伤害增加15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有专属技能伤害增加150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效：全伤+15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：全伤+150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass6289:15%>","<SkillPass6289: 150%>"],["<SkillPass10067:15%>","<SkillPass10067: 150%>"],["<SkillPass10070:15%>","<SkillPass10070: 150%>"],["<SkillPass10071:15%>","<SkillPass10071: 150%>"],["<passiveELUP01:15%>","<passiveELUP01:150%>"],["<passiveELUP02:15%>","<passiveELUP02:150%>"],["<passiveELUP03:15%>","<passiveELUP03:150%>"],["<passiveELUP04:15%>","<passiveELUP04:150%>"],["<passiveELUP05:15%>","<passiveELUP05:150%>"],["<passiveELUP06:15%>","<passiveELUP06:150%>"],["<passiveELUP07:15%>","<passiveELUP07:150%>"],["<passiveELUP08:15%>","<passiveELUP08:150%>"],["<passiveELUP09:15%>","<passiveELUP09:150%>"],["<passiveELUP11:15%>","<passiveELUP11: 150%>"],["<passiveELUP12:15%>","<passiveELUP12: 150%>"],["<passiveELUP13:15%>","<passiveELUP13: 150%>"],["<passiveELUP14:15%>","<passiveELUP14: 150%>"],["<passiveELUP15:15%>","<passiveELUP15: 150%>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.01},{"code":21,"dataId":1,"value":1.1}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}]],"meta":{"SkillPass6289":["15%"," 150%"],"SkillPass10067":["15%"," 150%"],"SkillPass10070":["15%"," 150%"],"SkillPass10071":["15%"," 150%"],"passiveELUP01":["15%","150%"],"passiveELUP02":["15%","150%"],"passiveELUP03":["15%","150%"],"passiveELUP04":["15%","150%"],"passiveELUP05":["15%","150%"],"passiveELUP06":["15%","150%"],"passiveELUP07":["15%","150%"],"passiveELUP08":["15%","150%"],"passiveELUP09":["15%","150%"],"passiveELUP11":["15%"," 150%"],"passiveELUP12":["15%"," 150%"],"passiveELUP13":["15%"," 150%"],"passiveELUP14":["15%"," 150%"],"passiveELUP15":["15%"," 150%"]},"elements":{}},"128":{"lines":[["<pos=APs text=暴击率+6% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=暴击率+60% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=命中率+6% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=命中率+60% size=18 color=rgba(255,255,255,1) line=false align=0>"]],"traits":[[{"code":22,"dataId":0,"value":0.06},{"code":22,"dataId":0,"value":0.6}],[{"code":22,"dataId":2,"value":0.06},{"code":22,"dataId":2,"value":0.6}]],"meta":{},"elements":{}},"129":{"lines":[["<pos=APs text=\\c[1]特效:造成所有伤害结果*125% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:造成所有伤害结果*350% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:神圣伤、冰伤 、黑暗伤 、火伤 、大地、 奥术、 自然、 物理 、雷电 阴阳 混沌伤+60% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:神圣伤、冰伤 、黑暗伤 、火伤 、大地、 奥术、 自然、 物理 、雷电 阴阳 混沌伤+600% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:攻击力能力值*120% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:攻击力能力值*300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<Element Amplify 1: +60%>","<Element Amplify 1: +600%>"],["<Element Amplify 2: +60%>","<Element Amplify 2: +600%>"],["<Element Amplify 3: +60%>","<Element Amplify 3: +600%>"],["<Element Amplify 4: +60%>","<Element Amplify 4: +600%>"],["<Element Amplify 5: +60%>","<Element Amplify 5: +600%>"],["<Element Amplify 6: +60%>","<Element Amplify 6: +600%>"],["<Element Amplify 7: +60%>","<Element Amplify 7: +600%>"],["<Element Amplify 8: +60%>","<Element Amplify 8: +600%>"],["<Element Amplify 9: +60%>","<Element Amplify 9: +600%>"],["<Element Amplify 11: +60%>","<Element Amplify 11: +600%>"],["<Element Amplify 12: +60%>","<Element Amplify 12: +600%>"],["<passiveHarmRi:45>","<passiveHarmRi:450>"],["<passiveCrHarmRi:45>","<passiveCrHarmRi:450>"],["<StartPushState2718: 100%>","<StartPushState2301: 100%>"]],"traits":[[{"code":21,"dataId":2,"value":1.2},{"code":21,"dataId":2,"value":3}]],"meta":{"pos=APs text=\\c[1]特效":["攻击力能力值*120% size=18 color=rgba(255,255,255,1) line=false align=0","攻击力能力值*300% size=18 color=rgba(255,255,255,1) line=false align=0"],"Element Amplify 1":[" +60%"," +600%"],"Element Amplify 2":[" +60%"," +600%"],"Element Amplify 3":[" +60%"," +600%"],"Element Amplify 4":[" +60%"," +600%"],"Element Amplify 5":[" +60%"," +600%"],"Element Amplify 6":[" +60%"," +600%"],"Element Amplify 7":[" +60%"," +600%"],"Element Amplify 8":[" +60%"," +600%"],"Element Amplify 9":[" +60%"," +600%"],"Element Amplify 11":[" +60%"," +600%"],"Element Amplify 12":[" +60%"," +600%"],"passiveHarmRi":["45","450"],"passiveCrHarmRi":["45","450"],"StartPushState2718":[" 100%",null]},"elements":{"1":5.4,"2":5.4,"3":5.4,"4":5.4,"5":5.4,"6":5.4,"7":5.4,"8":5.4,"9":5.4,"11":5.4,"12":5.4}},"130":{"lines":[["<pos=APs text=物理、魔法闪避+5%  size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=物理、魔法闪避+50%  size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:终伤 爆伤+5% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:终伤 爆伤+50% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<passiveHarmRi:5>","<passiveHarmRi:50>"],["<passiveCrHarmRi:5>","<passiveCrHarmRi:50>"]],"traits":[[{"code":22,"dataId":1,"value":0.05},{"code":22,"dataId":1,"value":0.5}],[{"code":22,"dataId":4,"value":0.05},{"code":22,"dataId":4,"value":0.5}]],"meta":{"pos=APs text=\\c[1]特效":["终伤 爆伤+5% size=18 color=rgba(255,255,255,1) line=false align=0","终伤 爆伤+50% size=18 color=rgba(255,255,255,1) line=false align=0"],"passiveHarmRi":["5","50"],"passiveCrHarmRi":["5","50"]},"elements":{}},"131":{"lines":[["<pos=APs text=物理魔法闪避+10%  size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=物理魔法闪避+100%  size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:全伤、终伤、爆伤+10% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:全伤、终伤、爆伤+100% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<passiveHarmRi:10>","<passiveHarmRi:100>"],["<passiveCrHarmRi:10>","<passiveCrHarmRi:100>"],["<Element Amplify 9: +10%>","<Element Amplify 9: +100%>"],["<Element Amplify 1: +10%>","<Element Amplify 1: +100%>"],["<Element Amplify 2: +10%>","<Element Amplify 2: +100%>"],["<Element Amplify 3: +10%>","<Element Amplify 3: +100%>"],["<Element Amplify 4: +10%>","<Element Amplify 4: +100%>"],["<Element Amplify 5: +10%>","<Element Amplify 5: +100%>"],["<Element Amplify 6: +10%>","<Element Amplify 6: +100%>"],["<Element Amplify 7: +10%>","<Element Amplify 7: +100%>"],["<Element Amplify 8: +10%>","<Element Amplify 8: +100%>"]],"traits":[[{"code":22,"dataId":1,"value":0.1},{"code":22,"dataId":1,"value":1}],[{"code":22,"dataId":4,"value":0.1},{"code":22,"dataId":4,"value":1}],[{"code":21,"dataId":0,"value":1.005},{"code":21,"dataId":0,"value":1.05}]],"meta":{"pos=APs text=\\c[1]特效":["全伤、终伤、爆伤+10% size=18 color=rgba(255,255,255,1) line=false align=0","全伤、终伤、爆伤+100% size=18 color=rgba(255,255,255,1) line=false align=0"],"passiveHarmRi":["10","100"],"passiveCrHarmRi":["10","100"],"Element Amplify 9":[" +10%"," +100%"],"Element Amplify 1":[" +10%"," +100%"],"Element Amplify 2":[" +10%"," +100%"],"Element Amplify 3":[" +10%"," +100%"],"Element Amplify 4":[" +10%"," +100%"],"Element Amplify 5":[" +10%"," +100%"],"Element Amplify 6":[" +10%"," +100%"],"Element Amplify 7":[" +10%"," +100%"],"Element Amplify 8":[" +10%"," +100%"]},"elements":{"1":0.9,"2":0.9,"3":0.9,"4":0.9,"5":0.9,"6":0.9,"7":0.9,"8":0.9,"9":0.9}},"132":{"lines":[["<pos=APs text=物理魔法闪避+10%  size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=物理魔法闪避+100%  size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:全伤+10%,终伤 爆伤+25% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:全伤+100%,终伤 爆伤+250% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:最大生命值,双防*102% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:最大生命值,双防*120% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<passiveHarmRi:25>","<passiveHarmRi:250>"],["<passiveCrHarmRi:25>","<passiveCrHarmRi:250>"],["<Element Amplify 9: +10%>","<Element Amplify 9: +100%>"],["<Element Amplify 2: +10%>","<Element Amplify 2: +100%>"],["<Element Amplify 3: +10%>","<Element Amplify 3: +100%>"],["<Element Amplify 4: +10%>","<Element Amplify 4: +100%>"],["<Element Amplify 5: +10%>","<Element Amplify 5: +100%>"],["<Element Amplify 6: +10%>","<Element Amplify 6: +100%>"],["<Element Amplify 7: +10%>","<Element Amplify 7: +100%>"],["<Element Amplify 8: +10%>","<Element Amplify 8: +100%>"],["<Element Amplify 1: +10%>","<Element Amplify 1: +100%>"]],"traits":[[{"code":22,"dataId":1,"value":0.1},{"code":22,"dataId":1,"value":1}],[{"code":22,"dataId":4,"value":0.1},{"code":22,"dataId":4,"value":1}],[{"code":21,"dataId":0,"value":1.02},{"code":21,"dataId":0,"value":1.2}],[{"code":21,"dataId":3,"value":1.02},{"code":21,"dataId":3,"value":1.2}],[{"code":21,"dataId":5,"value":1.02},{"code":21,"dataId":5,"value":1.2}]],"meta":{"pos=APs text=\\c[1]特效":["最大生命值,双防*102% size=18 color=rgba(255,255,255,1) line=false align=0","最大生命值,双防*120% size=18 color=rgba(255,255,255,1) line=false align=0"],"passiveHarmRi":["25","250"],"passiveCrHarmRi":["25","250"],"Element Amplify 9":[" +10%"," +100%"],"Element Amplify 2":[" +10%"," +100%"],"Element Amplify 3":[" +10%"," +100%"],"Element Amplify 4":[" +10%"," +100%"],"Element Amplify 5":[" +10%"," +100%"],"Element Amplify 6":[" +10%"," +100%"],"Element Amplify 7":[" +10%"," +100%"],"Element Amplify 8":[" +10%"," +100%"],"Element Amplify 1":[" +10%"," +100%"]},"elements":{"1":0.9,"2":0.9,"3":0.9,"4":0.9,"5":0.9,"6":0.9,"7":0.9,"8":0.9,"9":0.9}},"133":{"lines":[["<pos=APs text=全闪避+10%  size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=全闪避+100%  size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:终伤 爆伤-30% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:终伤 爆伤-300% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<passiveHarmRi:-30>","<passiveHarmRi:-300>"],["<passiveCrHarmRi:-30%>","<passiveCrHarmRi:-300%>"]],"traits":[[{"code":22,"dataId":1,"value":0.1},{"code":22,"dataId":1,"value":1}],[{"code":22,"dataId":3,"value":0.1},{"code":22,"dataId":3,"value":1}],[{"code":22,"dataId":4,"value":0.1},{"code":22,"dataId":4,"value":1}],[{"code":22,"dataId":5,"value":0.1},{"code":22,"dataId":5,"value":1}],[{"code":22,"dataId":6,"value":0.1},{"code":22,"dataId":6,"value":1}]],"meta":{"pos=APs text=\\c[1]特效":["终伤 爆伤-30% size=18 color=rgba(255,255,255,1) line=false align=0","终伤 爆伤-300% size=18 color=rgba(255,255,255,1) line=false align=0"],"passiveHarmRi":["-30","-300"],"passiveCrHarmRi":["-30%","-300%"]},"elements":{}},"134":{"lines":[["<pos=APs text=全闪避+30%  size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=全闪避+300%  size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:终伤 爆伤-15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:终伤 爆伤-150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<passiveHarmRi:-15>","<passiveHarmRi:-150>"],["<passiveCrHarmRi:-15%>","<passiveCrHarmRi:-150%>"]],"traits":[[{"code":22,"dataId":1,"value":0.3},{"code":22,"dataId":1,"value":3}],[{"code":22,"dataId":3,"value":0.3},{"code":22,"dataId":3,"value":3}],[{"code":22,"dataId":4,"value":0.3},{"code":22,"dataId":4,"value":3}],[{"code":22,"dataId":5,"value":0.3},{"code":22,"dataId":5,"value":3}],[{"code":22,"dataId":6,"value":0.3},{"code":22,"dataId":6,"value":3}],[{"code":21,"dataId":0,"value":1.05},{"code":21,"dataId":0,"value":1.5}],[{"code":21,"dataId":1,"value":1.05},{"code":21,"dataId":1,"value":1.5}]],"meta":{"pos=APs text=\\c[1]特效":["终伤 爆伤-15% size=18 color=rgba(255,255,255,1) line=false align=0","终伤 爆伤-150% size=18 color=rgba(255,255,255,1) line=false align=0"],"passiveHarmRi":["-15","-150"],"passiveCrHarmRi":["-15%","-150%"]},"elements":{}},"135":{"lines":[["<pos=APs text=全闪避+30%  size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=全闪避+300%  size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:终伤 爆伤+15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:终伤 爆伤+150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<passiveHarmRi:15>","<passiveHarmRi:150>"],["<passiveCrHarmRi:15%>","<passiveCrHarmRi:150%>"]],"traits":[[{"code":22,"dataId":1,"value":0.3},{"code":22,"dataId":1,"value":3}],[{"code":22,"dataId":3,"value":0.3},{"code":22,"dataId":3,"value":3}],[{"code":22,"dataId":4,"value":0.3},{"code":22,"dataId":4,"value":3}],[{"code":22,"dataId":5,"value":0.3},{"code":22,"dataId":5,"value":3}],[{"code":22,"dataId":6,"value":0.3},{"code":22,"dataId":6,"value":3}],[{"code":21,"dataId":0,"value":1.05},{"code":21,"dataId":0,"value":1.5}],[{"code":21,"dataId":1,"value":1.05},{"code":21,"dataId":1,"value":1.5}]],"meta":{"passiveHarmRi":["15","150"],"passiveCrHarmRi":["15%","150%"]},"elements":{}},"136":{"lines":[["<pos=APs text=\\c[1]特效:使用剑伤害+2.5% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:使用剑伤害+25% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:物攻,魔攻*102% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:物攻,魔攻*120% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:独特技能伤+15% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:独特技能伤+150% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass10072:15%>","<SkillPass10072: 150%>"],["<SkillPass10073:15%>","<SkillPass10073: 150%>"],["<SkillPass10074:15%>","<SkillPass10074: 150%>"],["<SkillPass10076:15%>","<SkillPass10076: 150%>"],["<SkillPass10075:15%>","<SkillPass10075: 150%>"],["<SkillPass10086:15%>","<SkillPass10086: 150%>"],["<SkillPass10087:15%>","<SkillPass10087: 150%>"],["<SkillPass10088:15%>","<SkillPass10088: 150%>"]],"traits":[[{"code":22,"dataId":1,"value":0.001},{"code":22,"dataId":1,"value":0.01}],[{"code":22,"dataId":3,"value":0.001},{"code":22,"dataId":3,"value":0.01}],[{"code":22,"dataId":4,"value":0.001},{"code":22,"dataId":4,"value":0.01}],[{"code":21,"dataId":2,"value":1.02},{"code":21,"dataId":2,"value":1.2}],[{"code":21,"dataId":4,"value":1.02},{"code":21,"dataId":4,"value":1.2}]],"meta":{"SkillPass10072":["15%"," 150%"],"SkillPass10073":["15%"," 150%"],"SkillPass10074":["15%"," 150%"],"SkillPass10076":["15%"," 150%"],"SkillPass10075":["15%"," 150%"],"SkillPass10086":["15%"," 150%"],"SkillPass10087":["15%"," 150%"],"SkillPass10088":["15%"," 150%"]},"elements":{}},"137":{"lines":[["<pos=APs text=\\c[1]特效:独特技能伤+5% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:独特技能伤+50% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:雷 物理+5.5% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:雷 物理+55% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass10092:15%>","<SkillPass10092: 150%>"],["<SkillPass10093:15%>","<SkillPass10093: 150%>"],["<SkillPass10094:15%>","<SkillPass10094: 150%>"],["<SkillPass10095:15%>","<SkillPass10095: 150%>"],["<SkillPass10096:15%>","<SkillPass10096: 150%>"],["<SkillPass7216:15%>","<SkillPass7216: 150%>"],["<SkillPass7217:15%>","<SkillPass7217: 150%>"]],"traits":[[{"code":22,"dataId":1,"value":0.001},{"code":22,"dataId":1,"value":0.01}],[{"code":22,"dataId":3,"value":0.001},{"code":22,"dataId":3,"value":0.01}],[{"code":22,"dataId":4,"value":0.001},{"code":22,"dataId":4,"value":0.01}]],"meta":{"pos=APs text=\\c[1]特效":["雷 物理+5.5% size=18 color=rgba(255,255,255,1) line=false align=0","雷 物理+55% size=18 color=rgba(255,255,255,1) line=false align=0"],"SkillPass10092":["15%"," 150%"],"SkillPass10093":["15%"," 150%"],"SkillPass10094":["15%"," 150%"],"SkillPass10095":["15%"," 150%"],"SkillPass10096":["15%"," 150%"],"SkillPass7216":["15%"," 150%"],"SkillPass7217":["15%"," 150%"]},"elements":{}},"138":{"lines":[["<pos=APs text=\\c[1]特效:冰 火 雷 伤害+5% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:冰 火 雷 伤害+50% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:物攻,魔攻*102% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:物攻,魔攻*120% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:独特技能伤+10% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:独特技能伤+100% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkillPass9954:10%>","<SkillPass9954:100%>"],["<SkillPass9956:10%>","<SkillPass9956:100%>"],["<SkillPass9957:10%>","<SkillPass9957:100%>"],["<SkillPass9959:10%>","<SkillPass9959:100%>"],["<SkillPass9962:10%>","<SkillPass9962:100%>"],["<SkillPass9963:10%>","<SkillPass9963:100%>"],["<Element Amplify 2: +5%>","<Element Amplify 2: +50%>"],["<Element Amplify 3: +5%>","<Element Amplify 3: +50%>"],["<Element Amplify 5: +5%>","<Element Amplify 5: +50%>"]],"traits":[[{"code":21,"dataId":2,"value":1.02},{"code":21,"dataId":2,"value":1.2}],[{"code":21,"dataId":4,"value":1.02},{"code":21,"dataId":4,"value":1.2}]],"meta":{"pos=APs text=\\c[1]特效":["独特技能伤+10% size=18 color=rgba(255,255,255,1) line=false align=0","独特技能伤+100% size=18 color=rgba(255,255,255,1) line=false align=0"],"SkillPass9954":["10%","100%"],"SkillPass9956":["10%","100%"],"SkillPass9957":["10%","100%"],"SkillPass9959":["10%","100%"],"SkillPass9962":["10%","100%"],"SkillPass9963":["10%","100%"],"Element Amplify 2":[" +5%"," +50%"],"Element Amplify 3":[" +5%"," +50%"],"Element Amplify 5":[" +5%"," +50%"]},"elements":{"2":0.45,"3":0.45,"5":0.45}},"139":{"lines":[["<pos=APs text=\\c[1]特效:使用太刀伤害+2.5% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:使用太刀伤害+25% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:物攻,魔攻*102% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:物攻,魔攻*120% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<pos=APs text=\\c[1]特效:独特技能伤+10% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效:独特技能伤+100% size=18 color=rgba(255,255,255,1) line=false align=0>"],["<SkETypeHarmRi11:2.5%>","<SkETypeHarmRi11:25%>"],["<SkillPass5600:10%>","<SkillPass5600:100%>"],["<SkillPass9950:10%>","<SkillPass9950:100%>"],["<SkillPass5602:10%>","<SkillPass5602:100%>"],["<SkillPass5603:10%>","<SkillPass5603:100%>"],["<SkillPass5604:10%>","<SkillPass5604:100%>"],["<SkillPass5606:10%>","<SkillPass5606:100%>"]],"traits":[[{"code":21,"dataId":2,"value":1.02},{"code":21,"dataId":2,"value":1.2}],[{"code":21,"dataId":4,"value":1.02},{"code":21,"dataId":4,"value":1.2}]],"meta":{"pos=APs text=\\c[1]特效":["独特技能伤+10% size=18 color=rgba(255,255,255,1) line=false align=0","独特技能伤+100% size=18 color=rgba(255,255,255,1) line=false align=0"],"SkETypeHarmRi11":["2.5%","25%"],"SkillPass5600":["10%","100%"],"SkillPass9950":["10%","100%"],"SkillPass5602":["10%","100%"],"SkillPass5603":["10%","100%"],"SkillPass5604":["10%","100%"],"SkillPass5606":["10%","100%"]},"elements":{}},"140":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% 魔法*120% 受击率*95% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% 魔法*300% 受击率*50% size=18 color=rgba(255,255,255,1) line=false align=0>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.2},{"code":21,"dataId":1,"value":3}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}],[{"code":23,"dataId":0,"value":0.95},{"code":23,"dataId":0,"value":0.5}],[{"code":22,"dataId":2,"value":0.2},{"code":22,"dataId":2,"value":2}]],"meta":{},"elements":{}},"141":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% 魔法*120% 受击率*95% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% 魔法*300% 受击率*50% size=18 color=rgba(255,255,255,1) line=false align=0>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.2},{"code":21,"dataId":1,"value":3}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}],[{"code":23,"dataId":0,"value":0.95},{"code":23,"dataId":0,"value":0.5}],[{"code":22,"dataId":2,"value":0.2},{"code":22,"dataId":2,"value":2}]],"meta":{},"elements":{}},"142":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% 魔法*120% 受击率*95% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% 魔法*300% 受击率*50% size=18 color=rgba(255,255,255,1) line=false align=0>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.2},{"code":21,"dataId":1,"value":3}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}],[{"code":23,"dataId":0,"value":0.95},{"code":23,"dataId":0,"value":0.5}],[{"code":22,"dataId":2,"value":0.2},{"code":22,"dataId":2,"value":2}]],"meta":{},"elements":{}},"143":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% 魔法*120% 受击率*95% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% 魔法*300% 受击率*50% size=18 color=rgba(255,255,255,1) line=false align=0>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.2},{"code":21,"dataId":1,"value":3}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}],[{"code":23,"dataId":0,"value":0.95},{"code":23,"dataId":0,"value":0.5}],[{"code":22,"dataId":2,"value":0.2},{"code":22,"dataId":2,"value":2}]],"meta":{},"elements":{}},"144":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% 魔法*120% 受击率*95% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% 魔法*300% 受击率*50% size=18 color=rgba(255,255,255,1) line=false align=0>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.2},{"code":21,"dataId":1,"value":3}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}],[{"code":23,"dataId":0,"value":0.95},{"code":23,"dataId":0,"value":0.5}],[{"code":22,"dataId":2,"value":0.2},{"code":22,"dataId":2,"value":2}]],"meta":{},"elements":{}},"145":{"lines":[["<pos=APs text=\\c[1]特效：所有属性*101% 魔法*120% 受击率*95% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=\\c[1]特效：所有属性*110% 魔法*300% 受击率*50% size=18 color=rgba(255,255,255,1) line=false align=0>"]],"traits":[[{"code":21,"dataId":0,"value":1.01},{"code":21,"dataId":0,"value":1.1}],[{"code":21,"dataId":1,"value":1.2},{"code":21,"dataId":1,"value":3}],[{"code":21,"dataId":2,"value":1.01},{"code":21,"dataId":2,"value":1.1}],[{"code":21,"dataId":3,"value":1.01},{"code":21,"dataId":3,"value":1.1}],[{"code":21,"dataId":4,"value":1.01},{"code":21,"dataId":4,"value":1.1}],[{"code":21,"dataId":6,"value":1.01},{"code":21,"dataId":6,"value":1.1}],[{"code":21,"dataId":5,"value":1.01},{"code":21,"dataId":5,"value":1.1}],[{"code":21,"dataId":7,"value":1.01},{"code":21,"dataId":7,"value":1.1}],[{"code":23,"dataId":0,"value":0.95},{"code":23,"dataId":0,"value":0.5}],[{"code":22,"dataId":2,"value":0.2},{"code":22,"dataId":2,"value":2}]],"meta":{},"elements":{}}}}};
    function sameTrait(a,b){return a&&a.code===b.code&&a.dataId===b.dataId&&Math.abs(a.value-b.value)<1e-9;}
    IB.normalize=function(item){
        if(!item||item._codexImportedBalanceRevision===2)return false;
        var typ=item.wtypeId!==undefined?'Weapons':item.atypeId!==undefined?'Armors':null;
        var id=Number(item.originalBaseItemId||item.baseItemId||item.id),p=typ&&IB.patches[typ][id];
        if(!p)return false;
        var reduced=item._codexImportedBalanceRevision===1 || p.lines.some(function(pair){return String(item.note||'').indexOf(pair[0])>=0;});
        if(!reduced){item._codexImportedBalanceRevision=2;return false;}
        var lines=String(item.note||'').split(/\r?\n/);
        p.lines.forEach(function(pair){var i=lines.indexOf(pair[0]);if(i>=0)lines[i]=pair[1];});
        item.note=lines.join('\n');
        // Base traits precede affix/augment traits; replace one occurrence per authored trait.
        var used={};p.traits.forEach(function(pair){var i=item.traits.findIndex(function(t,j){return !used[j]&&sameTrait(t,pair[0]);});if(i>=0){used[i]=true;item.traits[i]=Object.assign({},pair[1]);}});
        item.meta=item.meta||{};
        Object.keys(p.meta).forEach(function(k){var v=p.meta[k],cur=item.meta[k];if(cur===v[0]||cur===undefined)item.meta[k]=v[1];
          else if(typeof cur==='string'&&/^\s*[+-]?[\d.]+%?\s*$/.test(cur)&&typeof v[0]==='string'&&typeof v[1]==='string'){
            var n=parseFloat(cur)+parseFloat(v[1])-parseFloat(v[0]);item.meta[k]=String(Math.round(n*1e10)/1e10)+(cur.indexOf('%')>=0?'%':'');
          }
        });
        item.elementAmplify=item.elementAmplify||{};
        Object.keys(p.elements).forEach(function(k){item.elementAmplify[k]=(Number(item.elementAmplify[k])||0)+p.elements[k];});
        item._codexImportedBalanceRevision=2;
        if(W.RJO&&RJO.HE&&RJO.HE.getDescParams){delete item.descParams;RJO.HE.getDescParams(item,2);}
        return true;
    };
    IB.sync=function(){
        // Refresh only actors whose equipped instances or legacy state actually changed.
        // Inventory normalization still visits every instance, including unequipped gear.
        var changed=new Set();
        (DataManager._independentWeapons||[]).concat(DataManager._independentArmors||[]).forEach(function(i){if(IB.normalize(i))changed.add(i);});
        if(W.$gameActors)($gameActors._data||[]).forEach(function(a){if(!a||!a.equips)return;
            var dirty=false;a.equips().forEach(function(i){if(IB.normalize(i))changed.add(i);if(changed.has(i))dirty=true;});
            if(a.actorId()>=141&&a.actorId()<=166&&a._states&&a._states.indexOf(2301)>=0){var turns=a._stateTurns&&a._stateTurns[2301];a.removeState(2301);a.addState(2718);if(turns!==undefined)a._stateTurns[2718]=turns;dirty=true;}
            if(a.actorId()>=141&&a.actorId()<=166&&a._codexImportedEffectsRevision!==2){a._codexImportedEffectsRevision=2;dirty=true;}
            if(dirty){if(a.refreshPassiveSkillCache)a.refreshPassiveSkillCache();if(a.initPassiveCache)a.initPassiveCache();if(a.refreshPassiveCache)a.refreshPassiveCache();a.refresh();}
        });
    };
    var effectsExtract=DataManager.extractSaveContents;
    DataManager.extractSaveContents=function(){var out=effectsExtract.apply(this,arguments);IB.sync();return out;};
    var effectsRegister=DataManager.registerNewItem;
    DataManager.registerNewItem=function(){var out=effectsRegister.apply(this,arguments);IB.normalize(out);return out;};
    var effectsGain=Game_Party.prototype.gainIndependentItem;
    Game_Party.prototype.gainIndependentItem=function(){var out=effectsGain.apply(this,arguments);(out||[]).forEach(IB.normalize);return out;};
    var effectsChange=Game_Actor.prototype.changeEquip;
    Game_Actor.prototype.changeEquip=function(slot,item){IB.normalize(item);return effectsChange.apply(this,arguments);};
    // Older shared attacks retain their native database for other actors.
    var effectsFormula=Game_Action.prototype.evalDamageFormula;
    Game_Action.prototype.evalDamageFormula=function(target){var value=effectsFormula.apply(this,arguments),s=this.subject(),i=this.item();
      return s&&B.importedActorIds.indexOf(s.actorId&&s.actorId())>=0&&i&&[1,2,5,6].indexOf(i.damage.type)>=0&&!(i.id>=9906&&i.id<=10121||i.id===10169)?value:value;
    };

    // 【Codex·未经Claude检验】12.27 legacy 11/22 type tabs; preserve native skill IDs/effects.
    B.skillType=function(actor,item){
        if(!actor||B.importedActorIds.indexOf(actor.actorId())<0||!item||[7,8].indexOf(item.stypeId)<0)return item&&item.stypeId;
        if(/^被动/.test(item.description||'')||/<Hide in Battle>/i.test(item.note||''))return 4;
        return item.hitType===2||/^魔法/.test(item.description||'')?2:1;
    };
    var legacyTypes=Game_Actor.prototype.addedSkillTypes;
    Game_Actor.prototype.addedSkillTypes=function(){
        var types=legacyTypes.apply(this,arguments);
        if(B.importedActorIds.indexOf(this.actorId())<0)return types;
        types=types.filter(function(id){return id!==7&&id!==8;});
        this.skills().forEach(function(skill){var type=B.skillType(this,skill);if(type&&types.indexOf(type)<0)types.push(type);},this);
        return types;
    };
    var legacyCommands=Window_ActorCommand.prototype.addSkillCommands;
    Window_ActorCommand.prototype.addSkillCommands=function(){
        if(this._actor&&B.importedActorIds.indexOf(this._actor.actorId())>=0&&this._skillIndex){
            var id=this._actor.actorId()-1,n=this._actor.addedSkillTypes().length,i=this._skillIndex[id];
            if(!Number.isInteger(i)||i<0||i>=n)this._skillIndex[id]=0;
        }
        return legacyCommands.apply(this,arguments);
    };
    var legacyIncludes=Window_SkillList.prototype.includes;
    Window_SkillList.prototype.includes=function(item){
        var type=B.skillType(this._actor,item);
        if(item&&type!==item.stypeId)item=Object.assign({},item,{stypeId:type});
        return legacyIncludes.call(this,item);
    };


    migrate(W.$gameParty);
    return B;
});
