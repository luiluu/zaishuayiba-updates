// v0.53 方桌大厅 EV069（!smallbirds「一键升级乌鸦」）默认隐藏。
// 事件 69 第 0 页为默认空页（无图、无指令、无触发），第 1 页保留原菜单并以开关 2501 为条件；
// 本模块在进入地图和每帧更新时把 2501 同步为 window.CodexTestMode.enabled()，
// 因此测试模式关闭（含 30 分钟密码验证失效后被置回 false）时开关会自动变回 OFF，鸟回到空页。
// 只做薄封装：不改变 Scene_Map 原有逻辑，开关只在取值变化时写入，避免每帧触发地图刷新。
window.CodexRuntime.register('installTestGateRuntime', function() {
    'use strict';
    var SW = 2501;
    function want() {
        return !!(window.CodexTestMode && typeof window.CodexTestMode.enabled === 'function' && window.CodexTestMode.enabled());
    }
    function switches() {
        return (typeof $gameSwitches !== 'undefined' && $gameSwitches && typeof $gameSwitches.setValue === 'function') ? $gameSwitches : null;
    }
    function sync() {
        var s = switches();
        if (!s) return false;
        var on = want();
        if (s.value(SW) !== on) s.setValue(SW, on);
        return on;
    }
    // 进入地图（含读档、转场）时立即对齐一次。
    var onMapLoaded = Scene_Map.prototype.onMapLoaded;
    Scene_Map.prototype.onMapLoaded = function() {
        var result = onMapLoaded.apply(this, arguments);
        sync();
        return result;
    };
    // 每帧兜底：测试模式开关被切换、或密码验证 30 分钟到期自动失效时都能及时回收。
    var update = Scene_Map.prototype.update;
    Scene_Map.prototype.update = function() {
        var result = update.apply(this, arguments);
        sync();
        return result;
    };
    // 便于外部脚本/自检读取当前状态（不影响判定链）。
    var gate = window.CodexTestGate = {version: 1, switchId: SW, enabled: want, sync: sync};
    return gate;
});
