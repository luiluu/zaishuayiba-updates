// 【Codex·未经Claude检验】v0.28 装备说明框保持在左侧列表区域；未经claude检验。
// 【Claude·未经Codex检验】v0.18 星级移到结果行与详情的名字前面，品质文字不加星。
// 【Claude·未经Codex检验】v0.17 神话档星级：结果与详情显示星级，品质筛选可选神话★／★★／★★★，「品质高 → 低」先按七档再按旧档。
// 【Claude·未经Codex检验】v0.15 七档品质：检索名称与筛选按七档，「品质高 → 低」排序仍按旧档细分。
// 【Codex·未经Claude检验】v0.05 换装预览防重复与列表缓存；未经claude检验。
// 【Codex·未经Claude检验】v0.03 战力关闭时隐藏估算界面；未经claude检验。
// 【Codex·未经Claude检验】核查状态：未经claude检验。2026-10-11 装备检索同步当前元素名称。
/* Equipment search and party battle status. Read-only views; independent item IDs remain untouched. */
window.CodexRuntime.register('installEquipmentStatusRuntime', function() {
    'use strict';
    function powerEnabled(){return !!window.CodexCombatPower&&CodexCombatPower.enabled();}
    // The old comparison rows add fixed 20/40/60px offsets beyond the
    // calculated right edge. Allocate all columns inside the actual contents.
    if(window.Window_StatCompare){
      Window_StatCompare.prototype.drawItem=function(x,y,paramId){
        if(!this._actor)return;
        var pad=this.textPadding(),gap=8,right=this.contentsWidth()-pad,
            nameWidth=Math.min(Math.floor(this.contentsWidth()*.28),this._paramNameWidth||140),
            currentX=pad+nameWidth+gap,arrowWidth=this.textWidth('→')+12,
            valueWidth=Math.max(1,Math.floor((right-currentX-arrowWidth-gap*2)/2)),
            arrowX=currentX+valueWidth+gap,nextX=arrowX+arrowWidth+gap,
            current=this._actor.param(paramId),next=this._tempActor?this._tempActor.param(paramId):current;
        if(isNaN(next))next=current;
        this.drawDarkRect(x,y,this.contentsWidth(),this.lineHeight());
        this.changeTextColor(this.systemColor());this.drawText(TextManager.param(paramId),pad,y,nameWidth);
        this.resetTextColor();this.drawText(Yanfly.Util.toGroup(current),currentX,y,valueWidth,'right');
        this.changeTextColor(this.systemColor());this.drawText('→',arrowX,y,arrowWidth,'center');
        if(!this._tempActor)return;
        var diff=next-current,text=Yanfly.Util.toGroup(next);
        if(diff&&!isNaN(diff))text+=' ('+(diff>0?'+':'')+Yanfly.Util.toGroup(diff)+')';
        this.changeTextColor(this.paramchangeTextColor(diff));
        this.drawText(text,nextX,y,Math.max(1,right-nextX),'right');
      };
    }
    // Render at the available width before measuring height, then anchor in the
    // source list. Leave 12px for the native glow outside the help bitmap.
    if(window.Sprite_ItemHelp){
      var equipSetHelp=Sprite_ItemHelp.prototype.setItem;
      Sprite_ItemHelp.prototype.setItem=function(item){
        var scene=SceneManager._scene,source;
        if(scene instanceof Scene_Equip&&!this._isExtra&&scene._helpWindow===this){
          source=scene._itemWindow&&scene._itemWindow.visible?scene._itemWindow:scene._slotWindow;
        }
        if(!item||!source)return equipSetHelp.apply(this,arguments);
        var edge=Math.min(source.x+source.width,scene._compareWindow?scene._compareWindow.x:Graphics.boxWidth),
            available=Math.max(1,edge-source.x-24),match=String(item.note||'').match(/<HelpWidth:\s*(\d+)>/i),
            width=Math.min(available,match?Number(match[1]):RJO.HE.ItemDescWidth),view=Object.assign({},item);
        view.note=String(item.note||'').replace(/<HelpWidth:\s*\d+>/ig,'')+'\n<HelpWidth: '+width+'>';
        var out;try{out=equipSetHelp.call(this,view);}finally{this.item=item;}
        if(this.visible){
          var rect=source.itemRect(Math.max(0,source.index())),top=source.y+12,
              bottom=Graphics.boxHeight-12,below=source.y+source.standardPadding()+rect.y+rect.height+12,
              above=source.y+source.standardPadding()+rect.y-this.height-12;
          this.x=Math.max(source.x+12,edge-this.width-12);
          this.y=below+this.height<=bottom?below:above>=top?above:Math.max(top,bottom-this.height);
          this.updateGlowPos();
        }
        return out;
      };
    }

    window.addEventListener('codex-power-setting',function(){sceneSeen=null;sortRevision++;if(modal){if(modal.mode==='power')renderPower();else if(modal.mode==='gear')renderResults();}});
    var root = window, modal = null, host, panel, toolbar, sceneSeen, previousFocus, iconHost, iconButtons=[];
    var savedWindows = [], filter = defaults(), selectedKey = '', statusActor = 0, statusTab = '异常', statusQuery = '', powerActorId = 0;
    var categories = ['输出','防御','生存','控制','行动','资源','掉落','成长','特殊'];
    var params = ['生命','魔法','物攻','物防','魔攻','魔防','敏捷','幸运'];
    var xparams = ['命中率','闪避率','暴击率','暴击闪避','魔法闪避','魔法反射','反击率','生命再生','魔法再生','怒气再生'];
    var qualities = ['普通','优秀','精良','史诗','传说','不朽','神话'];
    function grade(q) { return root.CodexQuality ? root.CodexQuality.grade(Number(q) || 0) : Number(q) || 0; }
    function rank(q) { return root.CodexQuality && root.CodexQuality.rank ? root.CodexQuality.rank(Number(q) || 0) : Number(q) || 0; }
    function gradeText(q) { return qualities[grade(q)] || '普通'; }
    function starName(item) { return (root.CodexQuality && root.CodexQuality.stars ? root.CodexQuality.stars(item) : '') + text(item.name); }
    function subQualities() { return root.CodexQuality && root.CodexQuality.subGrades ? root.CodexQuality.subGrades().map(function(s){return ['L'+s.legacy,s.label];}) : []; }
    var cache = new WeakMap();
    function defaults() { return {query:'',category:'',term:'',sort:'quality',quality:'',type:'',scope:'all'}; }
    var inventoryRevision=0,sortRevision=0;
    function sortSettings(value) {
        value=value||ConfigManager.codexEquipmentSort||{};
        var allowed=['original','power','quality','count','name','term','param0','param1','param2','param3','param4','param5','param6','param7'];
        var sort=allowed.indexOf(value.sort)>=0?value.sort:'quality',term=typeof value.term==='string'?value.term.slice(0,500).replace(/全属性伤害/g,'全伤'):'';
        if(sort==='term'&&!term)sort='quality';return {sort:sort,term:term};
    }
    function defaultView(){var f=defaults(),stored=sortSettings();f.sort=stored.sort;f.sortTerm=stored.term;return f;}
    function setSort(sort,term){var next=sortSettings({sort:sort,term:term});ConfigManager.codexEquipmentSort=next;filter.sort=next.sort;filter.sortTerm=next.term;sortRevision++;ConfigManager.save();return next;}
    var configMake=ConfigManager.makeData,configApply=ConfigManager.applyData;
    ConfigManager.makeData=function(){var d=configMake.apply(this,arguments);d.codexEquipmentSort=sortSettings();return d;};
    ConfigManager.applyData=function(d){configApply.apply(this,arguments);this.codexEquipmentSort=sortSettings(d.codexEquipmentSort||{});filter=defaultView();sortRevision++;};
    var gainEquipment=Game_Party.prototype.gainItem;
    Game_Party.prototype.gainItem=function(item,amount){var out=gainEquipment.apply(this,arguments);if(equipment(item)&&amount)inventoryRevision++;return out;};
    function refreshSortedWindow(w){var selected=w.item&&w.item(),top=w.topRow&&w.topRow();w.refresh();var index=w._data.indexOf(selected);w.select(index>=0?index:Math.min(Math.max(0,w.index()),Math.max(0,w._data.length-1)));if(w.setTopRow&&top!==undefined)w.setTopRow(Math.min(top,w.maxTopRow()));if(w.updateHelp)w.updateHelp();}
    function text(s) { return String(s == null ? '' : s).replace(/全伤(?:害)?/g,'全属性伤害').replace(/\\[a-z]+\[[^\]]*\]/gi,'').replace(/\x1b[a-z]+\[[^\]]*\]/gi,'').replace(/<[^>]*>/g,'').replace(/\\[{}.!|><^]/g,'').trim(); }
    function alias(s) { return text(s).toLowerCase().replace(/最大\s*hp|生命值|血量|最大生命/gi,'生命').replace(/最大\s*mp|魔法值|法力/gi,'魔法').replace(/物理攻击|攻击力/g,'物攻').replace(/魔法攻击|魔法力/g,'魔攻').replace(/物理防御/g,'物防').replace(/魔法防御/g,'魔防').replace(/掉落率|掉落概率|掉宝率/g,'掉宝'); }
    function quality(item) { if(item.meta && item.meta.quality !== undefined)return Number(item.meta.quality)||0;var m=/<quality:\s*(\d+)>/i.exec(item.note||''); return m ? Number(m[1]) : Number(item.quality || 0); }
    function rawLines(note) {
        if(root.CodexElements&&CodexElements.normalizeEquipmentText)note=CodexElements.normalizeEquipmentText(note);
        var out=[], re=/<pos=APs\s+text=([\s\S]*?)\s+size=/gi, m;
        while ((m=re.exec(note||''))) { var line=text(root.CodexDisplay&&CodexDisplay.text?CodexDisplay.text(m[1]):m[1]); if(line && !/等级需求|需求等级|DreamX_bonus/i.test(line))out.push(line); }
        return out;
    }
    function kinds(line) {
        var s=alias(line), a=[];
        if (/掉宝|掉落|金币|金钱|寻宝|稀有/.test(s)) a.push('掉落');
        if (/经验|成长|熟练|升级|永久|盛名|叠生命/.test(s)) a.push('成长');
        if (/消耗|技能费用|回蓝|魔法再生|怒气|特技恢复|tp|mp/.test(s)) a.push('资源');
        if (/复活|回复|恢复|再生|生命|吸血|治疗|回血/.test(s)) a.push('生存');
        if (/减伤|防御|物防|魔防|闪避|回避|免疫|护盾|抗性|抵抗|受到/.test(s)) a.push('防御');
        if (/诅咒|中毒|剧毒|眩晕|麻痹|封印|沉默|灼伤|流血|睡眠|控制|削弱|减速/.test(s)) a.push('控制');
        if (/再动|行动|攻击次数|攻击速度|敏捷|先制|连击/.test(s)) a.push('行动');
        if (/物攻|魔攻|伤害|暴击|穿透|命中|攻击|全伤|增伤|元素/.test(s)) a.push('输出');
        return a.length ? a : ['特殊'];
    }
    function termKey(line) { return alias(line).replace(/全属性伤害/g,'全伤').replace(/^(?:混沌神话|神话|太古|mod)?特效\s*[:：]\s*/i,'').replace(/[+\-＋－]?\d+(?:\.\d+)?/g,'#').replace(/\s+/g,''); }
    function equipment(item) { return !!item && (DataManager.isWeapon(item) || DataManager.isArmor(item)); }
    function record(item) {
        var description=root.CodexElements&&CodexElements.normalizeEquipmentText?CodexElements.normalizeEquipmentText(item.description||''):item.description;
        if(root.CodexDisplay&&CodexDisplay.text)description=CodexDisplay.text(description);
        var signature=[item.note,item.description,quality(item),JSON.stringify(item.params||[])].join('|'), c=cache.get(item);
        if(c && c.signature===signature)return c.value;
        var base=DataManager.getBaseItem ? DataManager.getBaseItem(item) : item, baseLines=rawLines(base && base.note), remaining=baseLines.slice();
        var rows=rawLines(item.note).map(function(line){
            var i=remaining.indexOf(line), source=i>=0 || !item.baseItemId ? '固定' : '随机 / 附加'; if(i>=0)remaining.splice(i,1);
            var nums=line.match(/[+\-＋－]?\d+(?:\.\d+)?/g)||[], n=nums.length===1?Math.abs(Number(nums[0].replace('＋','+').replace('－','-'))):null;
            return {text:line,categories:kinds(line),key:termKey(line),number:n,source:source};
        });
        if(!rows.length && text(description))rows.push({text:text(description),categories:kinds(description),key:termKey(description),number:null,source:'固定'});
        var value={item:item,rows:rows,categories:categories.filter(function(cat){return rows.some(function(r){return r.categories.indexOf(cat)>=0;});}),search:alias(item.name+' '+description+' '+rows.map(function(r){return r.text;}).join(' ')),quality:quality(item)};
        cache.set(item,{signature:signature,value:value});return value;
    }
    function matches(item,f) {
        if(!equipment(item))return false;var r=record(item);
        if(f.type && (DataManager.isWeapon(item)?'w':'a')+String(DataManager.isWeapon(item)?item.wtypeId:item.etypeId)!==f.type)return false;
        if(/^L\d+$/.test(f.quality)){if(r.quality!==Number(f.quality.slice(1)))return false;}
        else if(f.quality!=='' && grade(r.quality)!==Number(f.quality))return false;
        if(f.category && r.categories.indexOf(f.category)<0)return false;
        if(f.term && !r.rows.some(function(row){return row.key===f.term;}))return false;
        return alias(f.query).split(/\s+/).filter(Boolean).every(function(q){return r.search.indexOf(q)>=0;});
    }
    function metric(item,f) {
        var r=record(item);
        if(f.sort==='count')return r.rows.length;
        if(f.sort==='power' && root.CodexCombatPower)return root.CodexCombatPower.equipment(item).total;
        if(/^param\d$/.test(f.sort))return Number((item.params||[])[Number(f.sort.slice(5))])||0;
        if(f.sort==='term') { var a=r.rows.filter(function(x){return x.key===(f.sortTerm||f.term) && x.number!==null;});return a.length ? Math.max.apply(null,a.map(function(x){return x.number;})) : -Infinity; }
        return rank(r.quality);
    }
    function compare(a,b,f) {
        if(f.sort==='original')return 0;
        if(f.sort==='name')return text(a.name).localeCompare(text(b.name),'zh-Hans');
        return metric(b,f)-metric(a,f) || rank(quality(b))-rank(quality(a)) || text(a.name).localeCompare(text(b.name),'zh-Hans') || Number(a.id)-Number(b.id);
    }
    function filterList(items,f) {
        // The remove-equipment entry stays available even when no equipment matches.
        var empty=items.filter(function(i){return i===null;});
        return items.filter(function(i){return equipment(i)&&matches(i,f);}).map(function(item,index){return {item:item,index:index};}).sort(function(a,b){return compare(a.item,b.item,f)||a.index-b.index;}).map(function(x){return x.item;}).concat(empty);
    }
    function collection() {
        var out=[], seen=new Set();
        function add(item,owner) { if(!equipment(item))return;var key=(DataManager.isWeapon(item)?'w':'a')+item.id+(item.baseItemId?'':':'+(owner||'bag'));if(seen.has(key))return;seen.add(key);out.push({item:item,owner:owner||'',key:key}); }
        $gameParty.weapons().concat($gameParty.armors()).forEach(function(i){add(i,'');});
        // Include existing reserve actor objects without creating or recruiting actors.
        ($gameActors._data||[]).filter(Boolean).forEach(function(a){a.equips().forEach(function(i){add(i,a.name());});});return out;
    }
    function stateDescription(s) {
        var note=s.note||'', m=/<(?:StateNote|STATE_HELP|ステートヘルプ)\s*>([\s\S]*?)<\/(?:StateNote|STATE_HELP|ステートヘルプ)\s*>/i.exec(note);
        return text(m ? m[1] : s.description) || traitDescription(s) || (s.id===1?'HP归零，无法行动；复活后解除。':Number(s.restriction)>0?['','只能攻击敌方','不分敌我攻击','会攻击队友','无法行动'][s.restriction]||'行动受到限制':'');
    }
    function pct(n) { return (n>0?'+':'')+(Math.round(n*1000)/10)+'%'; }
    function traitDescription(s) {
        return (s.traits||[]).map(function(t){
            if(t.code===21 && t.value!==1)return params[t.dataId]+pct(t.value-1);
            if(t.code===22 && t.value)return xparams[t.dataId]+pct(t.value);
            if(t.code===23)return ['受击概率','防御效果','治疗效果','药品效果','魔法消耗','怒气获得','物理承伤','魔法承伤','地形承伤','经验获得'][t.dataId]+'倍率 '+Math.round(t.value*100)+'%';
            if(t.code===62)return ['自动战斗','防御姿态：按当前防御效果减轻伤害','代替濒死队友承受攻击','保留怒气'][t.dataId]||'';
            if(t.code===61)return '额外行动概率 '+Math.round(t.value*100)+'%';
            if(t.code===33)return '攻击速度 '+t.value;
            if(t.code===34)return '额外攻击次数 '+t.value;
            if(t.code===11)return (($dataSystem.elements||[])[t.dataId]||'元素')+'承伤倍率 '+Math.round(t.value*100)+'%';
            if(t.code===13)return (($dataStates[t.dataId]||{}).name||'状态')+'施加倍率 '+Math.round(t.value*100)+'%';
            if(t.code===14)return '免疫 '+(($dataStates[t.dataId]||{}).name||'状态');
            if(t.code===42)return '封印 '+(($dataSystem.skillTypes||[])[t.dataId]||'技能类型');
            if(t.code===43)return '获得 '+(($dataSkills[t.dataId]||{}).name||'技能');
            return '';
        }).filter(Boolean).join('；');
    }
    function stateKind(s, passive) {
        if(passive)return '常驻';
        var m=/<BuffType:\s*([^>]+)>/i.exec(s.note||'');
        if(m && /减益|异常|削弱|持续伤害|debuff|诅咒|暗黑|沉默|混乱|魅惑|破甲|睡眠|麻痹|中毒|封印/i.test(m[1]))return '异常';
        if(m && /增益|强化|加成|buff/i.test(m[1]))return '增益';
        if(s.restriction>0 || s.id===1 || /诅咒|中毒|剧毒|疾病|睡眠|失明|封印|沉默|眩晕|麻痹|破甲|灼伤|流血|虚弱|异界制约|压制|威压/.test(s.name))return '异常';
        if((s.traits||[]).some(function(t){return t.code===21&&t.value<1 || t.code===22&&t.value<0 || t.code===42;}))return '异常';
        return /<Permanent>/i.test(s.note||'')?'常驻':'增益';
    }
    function visibleState(s) { return !!s && !!s.name && !/^角色(?:血量|蓝量|生命|魔法|物攻|魔攻|物防|魔防|敏捷|幸运)$/.test(s.name) && !/^\d+$/.test(s.name) && !/战斗形象|战斗换图|视觉辅助/.test(s.name) && !!stateDescription(s); }
    function stateRows(actor) {
        var active=actor._states||[], all=actor.states(), seen={}, result=[];
        all.forEach(function(s){
            if(!visibleState(s) || seen[s.id])return;seen[s.id]=true;
            var passive=active.indexOf(s.id)<0, turns=Number((actor._stateTurns||{})[s.id]), stack=actor.stateFloor?Number(actor.stateFloor(s.id)||1):1;
            var permanent=/<Permanent>/i.test(s.note||'');
            result.push({id:s.id,name:s.name,icon:Number(s.iconIndex)||0,kind:stateKind(s,passive),stack:stack,description:stateDescription(s),duration:window.CodexAlienation&&s.id===CodexAlienation.config.ids.corrosion?Math.max(1,Math.ceil(turns||0))+'回合':passive?'被动常驻':permanent?'常驻':s.autoRemovalTiming>0?(isFinite(turns)&&turns>0?Math.ceil(turns)+'回合':'本回合'):(s.removeAtBattleEnd?'本场战斗':'持续生效')});
        });
        (actor._buffs||[]).forEach(function(level,id){if(!level)return;var rate=actor.paramBuffRate?actor.paramBuffRate(id):1+level*.25;result.push({id:'buff'+id,icon:actor.buffIconIndex?actor.buffIconIndex(level,id):0,name:params[id]+(level>0?'强化':'弱化'),kind:level>0?'增益':'异常',stack:Math.abs(level),duration:Math.max(0,Math.ceil((actor._buffTurns||[])[id]||0))+'回合',description:params[id]+pct(rate-1)});});
        return result.sort(function(a,b){return ['异常','增益','常驻'].indexOf(a.kind)-['异常','增益','常驻'].indexOf(b.kind)||a.name.localeCompare(b.name,'zh-Hans');});
    }
    function el(tag,cls,content) { var e=document.createElement(tag);if(cls)e.className=cls;if(content!=null)e.textContent=content;return e; }
    function button(label,fn) { var b=el('button','',label);b.type='button';b.onclick=fn;return b; }
    function select(label,values,value,fn) { var wrap=el('label','cq-field');wrap.appendChild(el('span','',label));var s=el('select');s.setAttribute('aria-label',label);values.forEach(function(v){var o=el('option','',v[1]);o.value=v[0];s.appendChild(o);});s.value=value;s.onchange=function(){fn(s.value);};wrap.appendChild(s);return wrap; }
    function search(placeholder,value,fn) { var i=el('input');i.type='search';i.placeholder=placeholder;i.value=value;i.setAttribute('aria-label',placeholder);i.oninput=function(){fn(i.value);};return i; }
    function initDom() {
        if(host)return;
        var style=el('style');style.textContent=`
#cq-host{position:fixed;z-index:2147483000;color:#e5edf5;font:15px/1.55 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;pointer-events:none}#cq-host *{box-sizing:border-box}#cq-host button,#cq-host input,#cq-host select{font:inherit;color:inherit;border:1px solid #41546b;border-radius:7px;background:#1c2a3c;padding:6px 10px}#cq-host button{cursor:pointer}#cq-host button:hover,#cq-host button:focus-visible{background:#31455d;border-color:#b9d8fd}#cq-host input:focus,#cq-host select:focus{outline:2px solid #78aeed}#cq-host .cq-active{background:#315a82;border-color:#8bc9ff}#cq-toolbar{position:absolute;top:8px;right:8px;pointer-events:auto;display:flex;gap:6px}#cq-toolbar button{background:#122238ed;font-size:13px;padding:5px 9px}#cq-modal{position:absolute;inset:0;background:#101a2a;padding:14px;pointer-events:auto;display:flex;flex-direction:column;border:1px solid #657d96;border-radius:8px;box-shadow:0 10px 50px #0008}#cq-icons{position:absolute;inset:0;pointer-events:none}#cq-icons button{position:absolute;pointer-events:auto;padding:0;border:1px solid transparent;background:transparent;border-radius:4px}#cq-icons button:hover,#cq-icons button:focus-visible{border-color:#a7d5ff;background:#8bb9e333;outline:1px solid #a7d5ff}#cq-modal h2{font-size:23px;margin:0;color:#c2ddfc}#cq-modal h3{font-size:17px;margin:14px 0 7px;color:#a8cefb}.cq-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:9px}.cq-note{color:#a7b9ca;font-size:13px}.cq-filters{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:8px}.cq-filters input{width:100%}.cq-field{display:flex;align-items:center;gap:5px;font-size:13px}.cq-field select{max-width:260px}.cq-body{display:flex;gap:12px;flex:1;min-height:0}.cq-list{flex:0 0 43%;overflow-y:auto;border:1px solid #33475e;border-radius:7px;padding:5px}.cq-detail{flex:1;overflow-y:auto;border:1px solid #33475e;border-radius:7px;padding:13px}.cq-row{display:block;width:100%;text-align:left;margin-bottom:5px!important;white-space:normal}.cq-row strong{display:block;font-weight:600}.cq-row small{display:block;color:#adbed0;font-size:12px}.cq-count{margin:0 0 6px;color:#b7c9dc;font-size:13px}.cq-effect{padding:9px 10px;background:#1b293b;border-left:3px solid #83bafa;border-radius:4px;margin-bottom:7px;overflow-wrap:anywhere;white-space:pre-wrap}.cq-effect small{display:block;color:#9baec3;font-size:12px}.cq-danger{border-left-color:#ff989d}.cq-pills{display:flex;gap:7px;flex-wrap:wrap;margin:8px 0}.cq-pill{background:#213147;border:1px solid #3b506b;border-radius:5px;padding:3px 7px;font-size:13px}.cq-tabs{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px}.cq-footer{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:9px}.cq-empty{padding:20px;color:#b7c9dc}.cq-status .cq-list{flex-basis:29%}.cq-status .cq-effect{font-size:15px}.cq-status input{width:100%;margin-bottom:8px}.cq-title-meta{font-size:13px;color:#adc2d8}@media(max-width:700px){#cq-host{font-size:13px}#cq-modal{padding:8px}#cq-icons{position:absolute;inset:0;pointer-events:none}#cq-icons button{position:absolute;pointer-events:auto;padding:0;border:1px solid transparent;background:transparent;border-radius:4px}#cq-icons button:hover,#cq-icons button:focus-visible{border-color:#a7d5ff;background:#8bb9e333;outline:1px solid #a7d5ff}#cq-modal h2{font-size:18px}.cq-list{flex-basis:38%}.cq-field select{max-width:160px}.cq-note{font-size:11px}}
`;
        document.head.appendChild(style);host=el('div');host.id='cq-host';toolbar=el('div');toolbar.id='cq-toolbar';host.appendChild(toolbar);iconHost=el('div');iconHost.id='cq-icons';host.appendChild(iconHost);document.body.appendChild(host);
        ['pointerdown','mousedown','mouseup','click','touchstart','touchend','wheel'].forEach(function(type){host.addEventListener(type,function(e){e.stopPropagation();},{passive:false});});
        ['keydown','keyup','keypress'].forEach(function(type){host.addEventListener(type,function(e){e.stopPropagation();if(e.key==='Escape'&&modal){e.preventDefault();close();}if(e.key==='Tab'&&modal){var focusable=Array.from(panel.querySelectorAll('button,input,select')).filter(function(x){return !x.disabled;});var index=focusable.indexOf(document.activeElement);if(e.shiftKey&&index===0){e.preventDefault();focusable[focusable.length-1].focus();}else if(!e.shiftKey&&index===focusable.length-1){e.preventDefault();focusable[0].focus();}}});});
    }
    function position() { if(!host)return;var canvas=Graphics._canvas;if(!canvas)return;var rect=canvas.getBoundingClientRect();host.style.left=rect.left+'px';host.style.top=rect.top+'px';host.style.width=rect.width+'px';host.style.height=rect.height+'px'; }
    function collectWindows(node,out) { if(!node)return;(node.children||[]).forEach(function(c){if(c instanceof Window_Selectable && c.active){out.push(c);c.deactivate();}collectWindows(c,out);}); }
    function open(mode,actorId) {
        if(modal)return;initDom();position();previousFocus=document.activeElement;modal={mode:mode,scene:SceneManager._scene};savedWindows=[];collectWindows(modal.scene,savedWindows);Input.clear();TouchInput.clear();
        panel=el('section',mode==='status'?'cq-status':'');panel.id='cq-modal';panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');panel.setAttribute('aria-label',mode==='status'?'角色状态':mode==='power'?'角色战力':'装备词条检索');host.appendChild(panel);toolbar.style.display='none';iconHost.style.display='none';
        if(mode==='power'){var currentActor=modal.scene.actor&&modal.scene.actor();powerActorId=actorId||(currentActor&&currentActor.actorId())||0;renderPower();}else if(mode==='gear'){var stored=sortSettings();filter.sort=stored.sort;filter.sortTerm=stored.term;renderGear();}else{var current=BattleManager.actor&&BattleManager.actor();var actors=$gameParty.battleMembers();statusActor=actorId?Math.max(0,actors.findIndex(function(a){return a.actorId()===actorId;})):Math.max(0,actors.indexOf(current));statusQuery='';statusTab='全部';renderStatus();}
        var input=panel.querySelector('input');(input||panel.querySelector('button')).focus();
    }
    function close() {
        if(!modal)return;var same=modal.scene===SceneManager._scene;panel.remove();panel=null;modal=null;Input.clear();TouchInput.clear();
        if(same)savedWindows.forEach(function(w){w.activate();});savedWindows=[];
        if(previousFocus&&previousFocus.isConnected&&previousFocus.focus)previousFocus.focus();toolbar.style.display='';iconHost.style.display='';sceneSeen=null;
    }
    function header(title,subtitle) { var h=el('div','cq-head');var left=el('div');left.appendChild(el('h2','',title));left.appendChild(el('div','cq-note',subtitle));h.appendChild(left);h.appendChild(button('关闭 · Esc',close));panel.appendChild(h); }
    function gearSource() {
        var scene=modal.scene;
        if(scene instanceof Scene_Equip && scene._itemWindow && scene._itemWindow._slotId>=0 && savedWindows.indexOf(scene._itemWindow)>=0){return scene._itemWindow._cqOriginalData.filter(equipment).map(function(i){return {item:i,owner:'',key:(DataManager.isWeapon(i)?'w':'a')+i.id};});}
        return collection();
    }
    function renderGear() {
        panel.textContent='';header('装备词条检索','多个关键词用空格分开，将同时匹配；读取当前装备的真实效果。');
        var source=gearSource(), filters=el('div','cq-filters');
        filters.appendChild(search('搜索装备 / 词条，例如：暴击 掉宝',filter.query,function(v){filter.query=v;renderResults();}));
        filters.appendChild(select('分类',[['','全部分类']].concat(categories.map(function(c){return [c,c];})),filter.category,function(v){filter.category=v;renderResults();}));
        var types=[['','全部装备']], seen={};source.forEach(function(r){var i=r.item,key=(DataManager.isWeapon(i)?'w':'a')+String(DataManager.isWeapon(i)?i.wtypeId:i.etypeId);if(seen[key])return;seen[key]=true;types.push([key,DataManager.isWeapon(i)?'武器 · '+($dataSystem.weaponTypes[i.wtypeId]||i.wtypeId):($dataSystem.equipTypes[i.etypeId]||'防具')]);});
        filters.appendChild(select('部位',types,filter.type,function(v){filter.type=v;renderResults();}));
        filters.appendChild(select('品质',[['','全部品质']].concat(qualities.map(function(q,i){return [String(i),q];}),subQualities()),filter.quality,function(v){filter.quality=v;renderResults();}));
        filters.appendChild(select('位置',[['all','背包 + 已装备'],['bag','仅背包'],['worn','仅已装备']],filter.scope,function(v){filter.scope=v;renderResults();}));
        var terms={}, termOptions=[['','不限词条']];source.forEach(function(r){record(r.item).rows.forEach(function(row){if(!terms[row.key])terms[row.key]=row.text.replace(/[+\-＋－]?\d+(?:\.\d+)?/g,'…');});});
        Object.keys(terms).sort(function(a,b){return terms[a].localeCompare(terms[b],'zh-Hans');}).forEach(function(key){termOptions.push([key,terms[key]]);});
        filters.appendChild(select('指定词条',termOptions,filter.term,function(v){filter.term=v;if(filter.sort==='term')setSort('term',v);if(filter.sort==='term' && !source.some(function(r){return record(r.item).rows.some(function(row){return row.key===v&&row.number!==null;});}))filter.sort='quality';renderGear();}));
        var sorts=[['original','原有顺序'],['power','战力高 → 低'],['quality','品质高 → 低'],['count','词条多 → 少'],['name','名称顺序']].concat(params.map(function(p,i){return ['param'+i,p+'数值高 → 低'];}));if((filter.term||filter.sortTerm) && source.some(function(r){return record(r.item).rows.some(function(row){return row.key===(filter.term||filter.sortTerm)&&row.number!==null;});}))sorts.push(['term','单项词条数值高 → 低']);
        filters.appendChild(select('排序',sorts,filter.sort,function(v){setSort(v,filter.term||filter.sortTerm);renderResults();}));
        filters.appendChild(button('清空条件',function(){filter=defaultView();selectedKey='';renderGear();}));panel.appendChild(filters);
        panel.appendChild(el('div','cq-count'));var body=el('div','cq-body');body.appendChild(el('div','cq-list'));body.appendChild(el('div','cq-detail'));panel.appendChild(body);
        var footer=el('div','cq-footer');footer.appendChild(el('div','cq-note','详情按分类排列；数值排序读取装备当前属性，不改变装备。'));
        if(modal.scene instanceof Scene_Equip || modal.scene instanceof Scene_Item)footer.appendChild(button('应用到装备列表',applyFilter));panel.appendChild(footer);renderResults();
    }
    function renderResults() {
        var all=gearSource(), data=all.filter(function(r){return matches(r.item,filter)&&(!filter.scope||filter.scope==='all'||(filter.scope==='worn'?!!r.owner:!r.owner));});
        data.sort(function(a,b){return compare(a.item,b.item,filter);});
        var list=panel.querySelector('.cq-list');list.textContent='';panel.querySelector('.cq-count').textContent='找到 '+data.length+' / '+all.length+' 件装备';
        if(!data.some(function(r){return r.key===selectedKey;}))selectedKey=data.length?data[0].key:'';
        data.forEach(function(r){var rec=record(r.item),b=button('',function(){selectedKey=r.key;renderResults();});b.className='cq-row'+(r.key===selectedKey?' cq-active':'');b.appendChild(el('strong','',starName(r.item)));b.appendChild(el('small','',gradeText(rec.quality)+(powerEnabled()?' · 战力 '+CodexCombatPower.format(CodexCombatPower.equipment(r.item).total):'')+' · '+rec.rows.length+'条 · '+(r.owner?'已装备：'+r.owner:'背包')+' · '+rec.categories.join(' / ')));list.appendChild(b);});
        if(!data.length)list.appendChild(el('div','cq-empty','没有匹配装备。清空部分条件后重试。'));
        var detail=panel.querySelector('.cq-detail');detail.textContent='';var r=data.filter(function(x){return x.key===selectedKey;})[0];if(!r)return;
        detail.appendChild(el('h2','',starName(r.item)));detail.appendChild(el('div','cq-title-meta',gradeText(quality(r.item))+' · '+(r.owner?'已装备：'+r.owner:'背包')));
        if(powerEnabled()){var cp=root.CodexCombatPower,score=cp.equipment(r.item);detail.appendChild(el('h3','','装备战力 '+cp.format(score.total)));detail.appendChild(el('div','cq-note',cp.labels.map(function(label,i){return label+' '+cp.format(score.parts[i]);}).join(' · ')));detail.appendChild(el('div','cq-note','按当前属性、法宝等级和已识别战斗词条估算；品质与刷宝收益不直接加分。'));}
        var pills=el('div','cq-pills');(r.item.params||[]).forEach(function(n,i){if(n)pills.appendChild(el('span','cq-pill',params[i]+' '+n));});detail.appendChild(pills);
        if(text(r.item.description))detail.appendChild(el('div','cq-note',text(r.item.description)));
        var rec=record(r.item);categories.forEach(function(cat){var rows=rec.rows.filter(function(row){return row.categories[0]===cat;});if(!rows.length)return;detail.appendChild(el('h3','',cat));rows.sort(function(a,b){return a.key.localeCompare(b.key,'zh-Hans')||(b.number||0)-(a.number||0);});rows.forEach(function(row){var card=el('div','cq-effect',row.text);card.appendChild(el('small','',row.source+' · '+row.categories.join(' / ')));detail.appendChild(card);});});
        if(!rec.rows.length)detail.appendChild(el('div','cq-empty','无附加词条。基础属性见上方。'));
    }
    function renderPower() {
        panel.textContent='';if(!powerEnabled()){header('角色战力','战力显示与估算已关闭，可在设置中开启。');return;}var cp=root.CodexCombatPower,scene=modal.scene,actors=$gameParty.allMembers();
        var current=scene.actor&&scene.actor();if(current&&actors.indexOf(current)<0)actors=actors.concat([current]);
        var actor=actors.filter(function(a){return a.actorId()===powerActorId;})[0]||actors[0];
        if(!actor||!cp){header('角色战力','暂无可查看的角色。');return;}powerActorId=actor.actorId();
        var data=cp.actor(actor);header(actor.name()+' · 战力','等级 '+actor.level+' · 按当前装备、技能与成长评估。');
        var tabs=el('div','cq-tabs');actors.forEach(function(a){var b=button(a.name(),function(){powerActorId=a.actorId();renderPower();});if(a===actor)b.className='cq-active';tabs.appendChild(b);});panel.appendChild(tabs);
        var body=el('div','cq-body'),detail=el('div','cq-detail');body.appendChild(detail);panel.appendChild(body);
        var summary=el('div','cq-pills');[['总战力',data.total],['自身战力',data.self],['装备战力',data.gearScore||0]].forEach(function(row){summary.appendChild(el('span','cq-pill',row[0]+' '+cp.format(row[1])));});detail.appendChild(summary);detail.appendChild(CodexElements.createAttributes(actor,'人物属性'));detail.appendChild(CodexElements.createResistance(actor));
        detail.appendChild(el('h3','','能力构成'));cp.labels.forEach(function(label,i){var card=el('div','cq-effect');card.appendChild(el('strong','',label+' '+cp.format(data.parts[i])));card.appendChild(el('div','cq-note','自身 '+cp.format(data.selfParts[i])+' · 装备提升 '+cp.delta(data.gearParts[i])));detail.appendChild(card);});
        var ev=data.evaluation;detail.appendChild(el('div','cq-note','3回合平均输出 '+cp.format(ev.burst)+' · 10回合平均输出 '+cp.format(ev.sustained)));if(ev.coverage.unknown.length)detail.appendChild(el('div','cq-note','尚未完整评估的技能：'+ev.coverage.unknown.map(function(r){return r.name;}).join('、')));if(ev.routes&&ev.routes.length>1)detail.appendChild(el('div','cq-note','路线比较（中档防御，按 0.4×3回合＋0.6×10回合）：'+ev.routes.map(function(r){return (r.opening?'先施放'+r.opening:'不变身')+' '+cp.format(r.burst*0.4+r.sustained*0.6);}).join(' · ')+'；采用'+(ev.opening?'先施放'+ev.opening:'不变身')));if(ev.coverage.unmodeled&&ev.coverage.unmodeled.length)detail.appendChild(el('div','cq-note','战力未计入：'+ev.coverage.unmodeled.map(function(r){return r.name+'（'+r.reason+'）';}).join('、')));
        detail.appendChild(el('h3','','已穿装备'));if(!data.equipment.length)detail.appendChild(el('div','cq-empty','未穿装备，自身战力仍然有效。'));
        data.equipment.forEach(function(r){var card=el('div','cq-effect');card.appendChild(el('strong','',($dataSystem.equipTypes[r.item.etypeId]||'装备')+' · '+text(r.item.name)));card.appendChild(el('div','cq-title-meta','战力 '+cp.format(r.score.total)+(r.score.level?' · 法宝 '+r.score.level+'级':'')));card.appendChild(el('div','cq-note',cp.labels.map(function(label,i){return label+' '+cp.format(r.score.parts[i]);}).join(' · ')));detail.appendChild(card);});
        detail.appendChild(el('h3','','自身成长来源'));detail.appendChild(el('div','cq-note','等级、进阶、永久属性、当前灵魂与技能熟练度按实际效果计入；自身战力在卸下装备的条件下评估。装备综合提升包含百分比属性和机制联动。'));
        data.rows.filter(function(r){return Math.abs(r.value)>=1;}).sort(function(a,b){return b.value-a.value;}).slice(0,12).forEach(function(r){detail.appendChild(el('div','cq-title-meta',r.label+' '+cp.delta(r.value)));});
        var footer=el('div','cq-footer');footer.appendChild(el('div','cq-note','标准条件下的能力参考值；特殊脚本和条件触发仍逐步完善，不代表所有敌人的实战结果。'));footer.appendChild(button('返回游戏',close));panel.appendChild(footer);
    }
    function applyFilter() {
        var scene=modal.scene,w=scene._itemWindow;setSort(filter.sort,filter.term||filter.sortTerm);w._cqFilter=Object.assign({},filter);
        var old=w.item&&w.item();w.refresh();var i=w._data.indexOf(old);w.select(i>=0?i:0);if(w.updateHelp)w.updateHelp();close();
    }
    function renderStatus() {
        panel.textContent='';var actors=$gameParty.battleMembers();statusActor=Math.min(statusActor,Math.max(0,actors.length-1));var a=actors[statusActor];if(!a){close();return;}
        header(a.name()+' · 状态详情','查看时暂停战斗，关闭后继续。');
        var body=el('div','cq-body'),detail=el('div','cq-detail');body.appendChild(detail);panel.appendChild(body);
        var resource=el('div','cq-pills');resource.appendChild(el('span','cq-pill','HP '+a.hp+' / '+a.mhp));resource.appendChild(el('span','cq-pill','MP '+a.mp+' / '+a.mmp));resource.appendChild(el('span','cq-pill','TP '+a.tp));detail.appendChild(resource);detail.appendChild(CodexElements.createAttributes(a,'人物属性'));detail.appendChild(CodexElements.createResistance(a));
        var rows=stateRows(a),tabs=el('div','cq-tabs');['异常','增益','常驻','全部'].forEach(function(t){var count=t==='全部'?rows.length:rows.filter(function(r){return r.kind===t;}).length,b=button(t+' '+count,function(){statusTab=t;renderStatus();});if(t===statusTab)b.className='cq-active';tabs.appendChild(b);});detail.appendChild(tabs);
        detail.appendChild(search('搜索状态名称 / 效果',statusQuery,function(v){statusQuery=v;renderStatusCards();}));detail.appendChild(el('div','cq-cards'));renderStatusCards();
        var footer=el('div','cq-footer');footer.appendChild(el('div','cq-note','显示实际效果、剩余回合和层数。'));footer.appendChild(button('返回战斗',close));panel.appendChild(footer);
    }
    function renderStatusCards() {
        var a=$gameParty.battleMembers()[statusActor],cards=panel.querySelector('.cq-cards');cards.textContent='';
        var rows=a?stateRows(a).filter(function(r){return (statusTab==='全部'||r.kind===statusTab)&&alias(r.name+' '+r.description).indexOf(alias(statusQuery))>=0;}):[];
        if(!rows.length)cards.appendChild(el('div','cq-empty','没有'+(statusTab==='全部'?'':statusTab)+'状态符合当前条件。'));
        rows.forEach(function(r){var card=el('div','cq-effect'+(r.kind==='异常'?' cq-danger':''));card.appendChild(el('strong','',r.name));card.appendChild(el('div','cq-title-meta',r.kind+' · '+r.duration+(r.stack>1?' · '+r.stack+'层':'')));card.appendChild(el('div','',r.description));cards.appendChild(card);});
    }
    function iconWindows(scene) {
        var out=[];function visit(n){if(!n)return;if(typeof Window_BattleSideStates!=='undefined' && n instanceof Window_BattleSideStates)out.push(n);(n.children||[]).forEach(visit);}visit(scene._windowLayer);return out;
    }
    function updateIconButtons(scene) {
        if(!(scene instanceof Scene_Battle)){iconHost.style.display='none';return;}iconHost.style.display='';
        var windows=iconWindows(scene), scaleX=host.clientWidth/Graphics.width, scaleY=host.clientHeight/Graphics.height;
        windows.forEach(function(w,i){var b=iconButtons[i];if(!b){b=button('',function(){var actor=b._cqActor;if(actor)open('status',actor.actorId());});iconHost.appendChild(b);iconButtons[i]=b;}
            var visible=!!w._actor && w.visible,p=w.parent;while(p){if(!p.visible)visible=false;p=p.parent;}b.style.display=visible?'':'none';b._cqActor=w._actor;
            if(!visible)return;var pos=w.getGlobalPosition(),row=w._cqCurrentRow;
            b.style.left=(pos.x*scaleX)+'px';b.style.top=(pos.y*scaleY)+'px';b.style.width=(32*scaleX)+'px';b.style.height=(32*scaleY)+'px';
            var label=w._actor.name()+'：'+(row?row.name:'无图标状态')+'；点击查看全部状态';b.title=label;b.setAttribute('aria-label',label);
        });iconButtons.forEach(function(b,i){if(i>=windows.length)b.style.display='none';});
    }
    function updateToolbar(scene) {
        initDom();position();if(modal){if(modal.scene!==scene)close();return;}
        if(sceneSeen!==scene){sceneSeen=scene;toolbar.textContent='';
            if(scene instanceof Scene_Equip || scene instanceof Scene_Item){toolbar.appendChild(button('装备检索 / 排序',function(){open('gear');}));toolbar.appendChild(button('清除筛选',function(){if(scene._itemWindow){scene._itemWindow._cqFilter=null;scene._itemWindow.refresh();scene._itemWindow.select(0);scene._itemWindow.updateHelp();}filter=defaultView();}));}
            if(powerEnabled() && scene instanceof Scene_Status){var pb=button('查看角色战力',function(){open('power');});pb.dataset.power='true';toolbar.appendChild(pb);}
            
        }
        if(scene instanceof Scene_Item || scene instanceof Scene_Equip){var w=scene._itemWindow,b=toolbar.querySelector('button');if(w&&(w._cqInventoryRevision!==inventoryRevision||w._cqSortRevision!==sortRevision))refreshSortedWindow(w);if(b&&w){if(w._cqCountInventory!==inventoryRevision||w._cqCountSort!==sortRevision||w._cqCountData!==w._data){w._cqEquipmentCount=(w._data||[]).filter(equipment).length;w._cqCountInventory=inventoryRevision;w._cqCountSort=sortRevision;w._cqCountData=w._data;}var label=w._cqFilter?'词条筛选中 · '+w._cqEquipmentCount+'件':'装备检索 / 排序';if(b.textContent!==label)b.textContent=label;}}
        var pb=toolbar.querySelector('[data-power]');if(pb&&scene.actor){var actor=scene.actor(),cp=root.CodexCombatPower;if(actor){var data=cp.actor(actor);var label='战力 '+cp.format(data.total);if(pb.textContent!==label)pb.textContent=label;}}
        updateIconButtons(scene);
    }
    var makeList=Window_ItemList.prototype.makeItemList;
    Window_ItemList.prototype.makeItemList=function(){makeList.apply(this,arguments);this._cqOriginalData=(this._data||[]).slice();this._cqInventoryRevision=inventoryRevision;this._cqSortRevision=sortRevision;var f=Object.assign({},this._cqFilter||defaultView()),stored=sortSettings();f.sort=stored.sort;f.sortTerm=stored.term;var scene=SceneManager._scene;if(!(scene instanceof Scene_Item||scene instanceof Scene_Equip))return;if(scene instanceof Scene_Item && !this._cqOriginalData.some(equipment))return;var data=filterList(this._cqOriginalData,f);if(scene instanceof Scene_Item && f.scope!=='all'){var worn=new Set(collection().filter(function(r){return !!r.owner;}).map(function(r){return r.item;}));data=data.filter(function(i){return f.scope==='worn'?worn.has(i):$gameParty.numItems(i)>0;});}this._data=data;};
    var addCommands=Window_MenuCommand.prototype.addOriginalCommands;
    Window_MenuCommand.prototype.addOriginalCommands=function(){addCommands.apply(this,arguments);this.addCommand('装备检索','codexEquipmentQuery',true);if(powerEnabled())this.addCommand('角色战力','codexCombatPower',true);};
    var menuCommands=Scene_Menu.prototype.createCommandWindow;
    Scene_Menu.prototype.createCommandWindow=function(){menuCommands.apply(this,arguments);this._commandWindow.setHandler('codexEquipmentQuery',function(){open('gear');});this._commandWindow.setHandler('codexCombatPower',function(){open('power');});};
    // Command handlers are invoked after the menu deactivates itself.
    var openOriginal=open;open=function(mode,actorId){openOriginal(mode,actorId);if(modal && modal.scene instanceof Scene_Menu && savedWindows.indexOf(modal.scene._commandWindow)<0)savedWindows.push(modal.scene._commandWindow);};
    if(typeof Window_BattleSideStates!=='undefined'){
        Window_BattleSideStates.prototype.initialize=function(x,y,width,height,index){
            this._cqCycleIndex=0;this._cqCycleAt=0;this._cqRefreshAt=0;
            Window_BattleSideBase.prototype.initialize.call(this,x-36,y,36,height,index);this.refresh();
        };
        Window_BattleSideStates.prototype.refresh=function(){
            Window_BattleSideBase.prototype.refresh.call(this);this._cqRows=this._actor?stateRows(this._actor).filter(function(r){return r.icon>0;}):[];
            this._cqRefreshAt=Date.now()+500;if(this._actor)this._actor._needsStatusStateRefresh=undefined;this.drawCurrentState();
        };
        Window_BattleSideStates.prototype.drawCurrentState=function(){
            this.contents.clear();this._cqCurrentRow=null;this.visible=!!this._actor;if(!this._actor)return;
            var rows=this._cqRows||[],row=rows.length?rows[this._cqCycleIndex%rows.length]:null;this._cqCurrentRow=row;
            if(row){this.drawIcon(row.icon,0,0);if(row.stack>1){this.contents.fontSize=12;this.drawText(String(row.stack),0,12,30,'right');}}
            else{this.contents.fillRect(1,1,30,30,'rgba(20,35,55,.9)');this.contents.fontSize=22;this.drawText('i',0,0,32,'center');}
        };
        var sideUpdate=Window_BattleSideStates.prototype.update;Window_BattleSideStates.prototype.update=function(){
            sideUpdate.apply(this,arguments);var now=Date.now();if(now>this._cqRefreshAt)this.refresh();
            if(!modal && now>this._cqCycleAt){this._cqCycleAt=now+1400;this._cqCycleIndex++;this.drawCurrentState();}
        };
    }
    Window_BattleStatus.prototype.drawActorIcons=function(){};
    var spriteIcon=Sprite_StateIcon.prototype.update;Sprite_StateIcon.prototype.update=function(){spriteIcon.apply(this,arguments);if(this._battler&&this._battler.isActor&&this._battler.isActor())this.visible=false;};
    var battleUpdate=BattleManager.update;BattleManager.update=function(){if(modal&&modal.mode==='status')return;return battleUpdate.apply(this,arguments);};
    // Keep the old command as an entry to the new readable panel. Never force _phase='input'.
    Scene_Battle.prototype.commandStateHelp=function(){open('status');if(modal){var w=this._partyCommandWindow;if(w&&savedWindows.indexOf(w)<0 && w.isOpen())savedWindows.push(w);}};
    Scene_Battle.prototype.onTouchCallStateHelp=function(){return false;};
    var changeInput=Scene_Battle.prototype.changeInputWindow;Scene_Battle.prototype.changeInputWindow=function(){if(modal)return;return changeInput.apply(this,arguments);};
    var processTouch=Window_Selectable.prototype.processTouch;Window_Selectable.prototype.processTouch=function(){if(modal)return;return processTouch.apply(this,arguments);};
    var keyDown=Input._onKeyDown,keyUp=Input._onKeyUp;Input._onKeyDown=function(e){if(modal){if(e.key==='Escape'){e.preventDefault();close();}return;}return keyDown.apply(this,arguments);};Input._onKeyUp=function(e){if(modal)return;return keyUp.apply(this,arguments);};
    ['_onMouseDown','_onMouseUp','_onTouchStart','_onTouchEnd','_onWheel'].forEach(function(key){var fn=TouchInput[key];if(fn)TouchInput[key]=function(e){if(modal || host&&host.contains(e.target))return;return fn.apply(this,arguments);};});
    var updateScene=SceneManager.updateScene;SceneManager.updateScene=function(){var result=updateScene.apply(this,arguments);if(this._scene && this._sceneStarted)updateToolbar(this._scene);return result;};
    root.CodexEquipmentQuery={version:3,openPower:function(actorId){open('power',actorId);},sortSettings:sortSettings,setSort:setSort,record:record,matches:matches,filterList:filterList,compare:compare,collection:collection,defaults:defaults,open:function(){open('gear');},close:close,isOpen:function(){return !!modal;}};
    root.CodexPartyStatus={rows:stateRows,open:function(actorId){open('status',actorId);},close:close};
// 【Codex·未经Claude检验】v0.05 Android equipment preview and gesture transaction.
 var previewHelp=Window_EquipItem.prototype.updateHelp,previewUpdate=Window_EquipItem.prototype.update;
 function mobile(){return !!root.AndroidInterface;}
 function previewKey(w){var a=w._actor,i=w.item();return [a&&a.actorId(),a&&a._level,a&&(a._skills||[]).join(','),a&&(a._states||[]).join(','),a&&a._equips.map(function(e){return e._itemId;}).join(','),w._slotId,i&&i.id,i&&i.level,i&&i.note,inventoryRevision].join('|');}
 Window_EquipItem.prototype.updateHelp=function(){
  if(!mobile())return previewHelp.apply(this,arguments);
  if(!this.active||!this.visible){this._codexPreviewWanted=null;return;}var key=previewKey(this);if(key===this._codexPreviewDone)return;
  if(this._codexPreviewWanted!==key){this._codexPreviewWanted=key;this._codexPreviewAt=Date.now()+80;}this._codexPreviewArgs=arguments;
 };
 Window_EquipItem.prototype.update=function(){var out=previewUpdate.apply(this,arguments);if(mobile()&&this.active&&this.visible&&previewKey(this)!==this._codexPreviewDone&&!this._codexPreviewWanted)this.updateHelp();if(mobile()&&this.active&&this.visible&&this._codexPreviewWanted&&Date.now()>=this._codexPreviewAt){var key=previewKey(this);if(key!==this._codexPreviewWanted){this.updateHelp();return out;}if(key!==this._codexPreviewDone){this._codexPreviewDone=key;this._codexPreviewWanted=null;previewHelp.apply(this,this._codexPreviewArgs||[]);}}return out;};
 var equipOk=Scene_Equip.prototype.onItemOk,equipUpdate=Scene_Equip.prototype.update;
 Scene_Equip.prototype.onItemOk=function(){
  if(!mobile())return equipOk.apply(this,arguments);if(this._codexEquipBusy)return;
  this._codexEquipBusy=true;this._codexEquipCooldownStarted=false;this._codexEquipReadyAt=Date.now()+120;
  if(root.AndroidPort&&AndroidPort.releaseTouchKeys)AndroidPort.releaseTouchKeys();Input.clear();TouchInput.clear();
  try{return equipOk.apply(this,arguments);}finally{this._codexEquipReadyAt=Date.now()+120;this._codexEquipReturnActive=!!this._slotWindow.active;this._slotWindow.deactivate();this._itemWindow.deactivate();this._itemWindow._codexPreviewDone=null;this._itemWindow._codexPreviewWanted=null;}
 };
 Scene_Equip.prototype.update=function(){
  if(mobile()&&this._codexEquipBusy){if(!this._codexEquipCooldownStarted){this._codexEquipCooldownStarted=true;this._codexEquipReadyAt=Date.now()+120;}Input.clear();var held=TouchInput.isPressed();TouchInput.clear();if(!held&&Date.now()>=this._codexEquipReadyAt){this._codexEquipBusy=false;if(this._codexEquipReturnActive)this._slotWindow.activate();}}
  return equipUpdate.apply(this,arguments);
 };
 if(mobile())document.addEventListener('pointerdown',function(e){var s=SceneManager._scene;if(s instanceof Scene_Equip&&s._codexEquipBusy){e.preventDefault();e.stopImmediatePropagation();}},true);

    return {version:2};
});
