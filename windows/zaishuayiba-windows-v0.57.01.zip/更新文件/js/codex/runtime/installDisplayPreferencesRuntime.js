// 【Codex·未经Claude检验】v0.43：装备／技能按阅读顺序分区，合并短属性与施放信息；仅作用于显示副本。
// 【Codex·未经Claude检验】v0.23 玩家反馈与平衡修复；未经claude检验。
// 【Codex·未经Claude检验】v0.05 真气道法当前数值帮助；未经claude检验。
// 【Codex·未经Claude检验】核查状态：未经claude检验。2026-10-11 全伤显示统一为全属性伤害，不改机械备注。
// Retina text/display support and persistent native options.
window.CodexRuntime.register('installDisplayPreferencesRuntime',function(){
 'use strict';
 var D=window.CodexDisplay={density:Math.min(2,Math.max(1,window.devicePixelRatio||1))};
 // Expand before measuring/formatting, including cached old-save help text.
 D.text=function(text){return typeof text==='string'?text.replace(/全伤(?:害)?/g,'全属性伤害'):text;};
 var measureText=Bitmap.prototype.measureTextWidth;
 Bitmap.prototype.measureTextWidth=function(text){return measureText.call(this,D.text(text));};
 var convertText=Window_Base.prototype.convertEscapeCharacters;
 Window_Base.prototype.convertEscapeCharacters=function(text){return convertText.call(this,D.text(text));};
 var addMessage=Game_Message.prototype.add;
 Game_Message.prototype.add=function(text){return addMessage.call(this,D.text(text));};
 if(window.RJO&&RJO.HE){
  var desc=RJO.HE.getDescParams;
  // 【Codex·未经Claude检验】v0.36：白字属性统一排在蓝字特效之前。
  D.equipmentRows=function(item){
   if(!item||!item.descParams||!(item.wtypeId!==undefined||item.atypeId!==undefined))return;
   var stats=[],rows=[],first=-1;
   item.descParams.forEach(function(row){
    var raw=String(row[0]||''),plain=raw.replace(/\\c\[\d+\]/gi,''),color=String(row[2]||'').replace(/\s/g,'').toLowerCase();
    var white=!/\\c\[[1-9]\d*\]/i.test(raw)&&(!color||/^(?:#fff(?:fff)?|white|rgba?\(255,255,255(?:,1)?\))$/.test(color));
    if(white&&/^(?:最大生命值|最大魔法值|生命值|魔法值|物理攻击力?|魔法攻击力?|攻击力|防御力|魔法防御|敏捷|幸运|命中率?|暴击(?:率|伤害)?|反击率?|闪避率?|魔法闪避率?|攻击速度|全属性(?:伤害)?|全闪避|暴击闪避率?|魔法反射率?|魔法反击率?|物理魔法闪避|爆闪|爆伤|攻击次数|(?:物|魔|火|冰|雷|暗|光|水|土|风|毒)伤|每级全属性|进化后每级全属性)[：:＋+－\-\d、， ,/]/.test(plain)){stats.push(row);return;}
    if(first<0&&/^\\c\[1\](?:特效|效果|成长)[：:]/i.test(raw))first=rows.length;
    rows.push(row);
   });
   if(first>=0&&stats.length){rows.splice.apply(rows,[first,0].concat(stats));item.descParams=rows;}
  };
  RJO.HE.getDescParams=function(item,type){var result=desc.apply(this,arguments);if(item&&item.descParams)item.descParams.forEach(function(row){row[0]=D.text(row[0]);});D.equipmentRows(item);return result;};
 }

 D.fontFace='"CodexUserUI", "PingFang SC", "Microsoft YaHei UI", sans-serif';
 // Load the exact user-provided font before the first game scene draws text.
 var userFace=new FontFace('CodexUserUI','url("fonts/FZLanTYJW_ZhongCu.TTF")');
 document.fonts.add(userFace);userFace.load().catch(function(error){D.fontError=String(error);});
 var bootReady=Scene_Boot.prototype.isReady;
 Scene_Boot.prototype.isReady=function(){
  if(D.fontError)throw new Error('指定字体载入失败：'+D.fontError);
  return bootReady.apply(this,arguments)&&userFace.status==='loaded';
 };
 function fontFace(){return D.fontFace;}
 [Window_Base,Window_Message,Window_ChoiceList,Window_ScrollText].forEach(function(Type){Type.prototype.standardFontFace=fontFace;});
 if(window.Yanfly&&Yanfly.Param)['ChineseFont','DefaultFont','MSGFontName','MSGCNFontName','MSGKRFontName'].forEach(function(k){Yanfly.Param[k]=D.fontFace;});
 if(window.LGP&&LGP.Param)LGP.Param.BDPfontFamily=D.fontFace;
 var initBitmap=Bitmap.prototype.initialize;
 Bitmap.prototype.initialize=function(){
  initBitmap.apply(this,arguments);this.outlineColor="rgba(0,0,0,0.45)";
  var face=fontFace(this.fontFace),outline=Math.min(0.75,this.outlineWidth);
  Object.defineProperty(this,'fontFace',{configurable:true,get:function(){return face;},set:function(value){face=fontFace(value);}});
  Object.defineProperty(this,'outlineWidth',{configurable:true,get:function(){return outline;},set:function(value){outline=Math.min(0.75,Math.max(0,Number(value)||0));}});
 };
 var style=document.createElement('style');
 style.textContent='body,button,input,textarea,select,.toast,.toaster,#cq-host,#cq-host *{font-family:'+D.fontFace+' !important;-webkit-font-smoothing:antialiased}';document.head.appendChild(style);
 if(window.Yanfly&&Yanfly.Param)Yanfly.Param.MSGFontOutline=0.75;
 var make=ConfigManager.makeData;
 ConfigManager.makeData=function(){var data=make.apply(this,arguments);data.cq=!!this.cq;data.CombatDamageShow=!!this.CombatDamageShow;return data;};
 var apply=ConfigManager.applyData;
 ConfigManager.applyData=function(data){apply.apply(this,arguments);this.cq=!!data.cq;if(Object.prototype.hasOwnProperty.call(data,'CombatDamageShow'))this.CombatDamageShow=!!data.CombatDamageShow;else this.CombatDamageShow=true;};
 var change=Window_Options.prototype.changeValue;
 Window_Options.prototype.changeValue=function(symbol,value){
  var before=ConfigManager[symbol],out=change.apply(this,arguments);
  if((symbol==='cq'||symbol==='CombatDamageShow')&&before!==ConfigManager[symbol])ConfigManager.save();
  return out;
 };
 // The legacy tile shader addresses a fixed 2048-pixel atlas. Its raw
 // texSubImage2D uploads and UVs must never inherit Retina canvas density.
 var initTileAtlas=PIXI.tilemap.TileRenderer.prototype.initBounds;
 PIXI.tilemap.TileRenderer.prototype.initBounds=function(){
  var resolution=PIXI.settings.RESOLUTION;PIXI.settings.RESOLUTION=1;
  try{return initTileAtlas.apply(this,arguments);}finally{PIXI.settings.RESOLUTION=resolution;}
 };
 // Pixi4 uses renderer.resolution for scissor masks even when an offscreen
 // filter/snapshot has a different density. Use the bound target's pixels.
 function installScissor(renderer){
 var manager=renderer.maskManager,scissor=manager.pushScissorMask;
 manager.pushScissorMask=function(){
  var renderer=this.renderer,rt=renderer._activeRenderTarget,resolution=renderer.resolution;
  if(rt&&rt.resolution)renderer.resolution=rt.resolution;
  try{return scissor.apply(this,arguments);}finally{renderer.resolution=resolution;}
 };
 }
 // Keep menu text at Retina density throughout the native window layer filter.
 WindowLayer.voidFilter.resolution=D.density;
 var createRenderer=Graphics._createRenderer;
 Graphics._createRenderer=function(){
  var oldResolution=PIXI.settings.RESOLUTION;PIXI.settings.RESOLUTION=D.density;
  try{createRenderer.apply(this,arguments);}finally{PIXI.settings.RESOLUTION=oldResolution;}
  if(this._renderer){this._renderer.resolution=D.density;installScissor(this._renderer);this._renderer.roundPixels=true;this._renderer.resize(this._width,this._height);}
 };
 // Promote only generated text canvases. Original art and icon atlases retain
 // their physical pixels and use nearest-neighbor sampling in the actor adapter.
 var physicalCreateTexture=Bitmap.prototype._createBaseTexture;
 function textCreateTexture(source){
  if(!this._codexDensity)return physicalCreateTexture.call(this,source);
  this.__baseTexture=new PIXI.BaseTexture(source,PIXI.SCALE_MODES.LINEAR,this._codexDensity);
  this.__baseTexture.mipmap=false;
 }
 function textResize(width,height){
  var r=this._codexDensity;
  this._codexWidth=Math.max(1,width||0);this._codexHeight=Math.max(1,height||0);
  this._canvas.width=Math.ceil(this._codexWidth*r);this._canvas.height=Math.ceil(this._codexHeight*r);
  this._context.setTransform(r,0,0,r,0,0);this._context.imageSmoothingEnabled=false;
  this._context.globalAlpha=(this._paintOpacity==null?255:this._paintOpacity)/255;
  if(this.__baseTexture){this.__baseTexture.resolution=r;this.__baseTexture.update();}
  this._setDirty();
 }
 function promote(bitmap){
  var r=D.density;
  if(r<=1||!bitmap||bitmap._codexDensity||bitmap._image||bitmap._url||!bitmap.isReady())return bitmap;
  var w=bitmap.width,h=bitmap.height;
  if(w>4096||h>4096)return bitmap;
  var old=document.createElement('canvas');old.width=w;old.height=h;old.getContext('2d').drawImage(bitmap._canvas,0,0);
  bitmap._codexDensity=r;bitmap._codexWidth=w;bitmap._codexHeight=h;
  Object.defineProperty(bitmap,'width',{configurable:true,get:function(){return this._codexWidth;}});
  Object.defineProperty(bitmap,'height',{configurable:true,get:function(){return this._codexHeight;}});
  bitmap._createBaseTexture=textCreateTexture;bitmap.resize=textResize;
  bitmap.getPixel=function(x,y){var p=this._context.getImageData(Math.floor(x*r),Math.floor(y*r),1,1).data;return '#'+[p[0],p[1],p[2]].map(v=>v.toString(16).padStart(2,'0')).join('');};
  bitmap.getAlphaPixel=function(x,y){return this._context.getImageData(Math.floor(x*r),Math.floor(y*r),1,1).data[3];};
  textResize.call(bitmap,w,h);
  bitmap._context.drawImage(old,0,0,w,h);bitmap.smooth=true;bitmap._setDirty();
  return bitmap;
 }
 D.promoteText=promote;
 var drawText=Bitmap.prototype.drawText;
 Bitmap.prototype.drawText=function(){arguments[0]=D.text(arguments[0]);promote(this);return drawText.apply(this,arguments);};
 var createContents=Window_Base.prototype.createContents;
 Window_Base.prototype.createContents=function(){var out=createContents.apply(this,arguments);promote(this.contents);return out;};
 var blt=Bitmap.prototype.blt;
 Bitmap.prototype.blt=function(source,sx,sy,sw,sh,dx,dy,dw,dh){
  if(!source||!source._codexDensity)return blt.apply(this,arguments);
  var r=source._codexDensity;dw=dw||sw;dh=dh||sh;
  if(sx<0||sy<0||sw<=0||sh<=0||dw<=0||dh<=0||sx+sw>source.width||sy+sh>source.height)return;
  this._context.globalCompositeOperation='source-over';this._context.drawImage(source._canvas,sx*r,sy*r,sw*r,sh*r,dx,dy,dw,dh);this._setDirty();
 };

 // ItemQuality replaces the normal help background with transparent glow
 // windows. Keep their quality border but cover the underlying list text.
 if(typeof Sprite_ItemHelp!=='undefined'){
  var drawHelpBackground=Sprite_ItemHelp.prototype.drawBackground;
  Sprite_ItemHelp.prototype.drawBackground=function(){
   var out=drawHelpBackground.apply(this,arguments),opacity=this.bitmap.paintOpacity;
   this.bitmap.paintOpacity=255;
   try{this.bitmap.fillRect(1,1,Math.max(0,this.width-2),Math.max(0,this.height-2),'#161c25');}
   finally{this.bitmap.paintOpacity=opacity;}
   return out;
  };
 }

 // Group native explanations without altering skills, equipment or save data.
 var characterHelpCopies={"10122":{"rows":["装备限制：无","目标：敌方单体","伤害属性：黑暗","命中：魔法；渡鸦施放时必中","暴击：可","段数：1","消耗：25MP","伤害：(魔攻×78＋最大魔法×39)×魄×阶位系数；防御按攻防比例结算","阶位系数：0～5阶依次为9／6.9／3.9／2／1.3／1","效果：命中后每次施放回复2%最大魔法；追加命中不重复回复"],"source":["消耗:25MP","攻击次数:1","目标:单个敌人","能否暴击:是","命中类型:魔法；渡鸦施放时必中","伤害属性:黑暗","装备限制:无","命中后每次施放回复最大魔法的2%；追加命中不重复回复","阶位系数:0～5阶为9／6.9／3.9／2／1.3／1","－敌魔防×(1－穿透率)÷11","伤害:(魔攻×78＋最大魔法×39)×魄×阶位系数"]},"10133":{"rows":["效果：残响达到3层时，强化下一次魔法并触发冥界收割","冥界收割：对命中且存活的目标追加本次伤害100%","解锁:35级且完成第3次进阶"],"source":["冥界收割:对命中且存活的目标追加本次伤害100%","效果:残响达到3层后，下一次魔法触发冥界收割","解锁:35级且完成第3次进阶"]},"10137":{"rows":["效果：可查看当前灵魂数与进阶阶位；灵魂达标后自动获得进阶印","规则：成功进阶清空本阶灵魂，下一阶重新收集","效果：专属魔法暴击率随魂海进度提高；15万灵魂时最高＋1000%","效果：魔法再释放＋15%；触发时追加一次命中，不重复扣费","成长：爆伤／终伤按等级线性增长，1级均为0","成长：10／25级：爆伤＋20%／＋80%；终伤＋15%／＋60%","成长：40／55级：爆伤＋180%／＋300%；终伤＋140%／＋240%","成长：70级：爆伤＋500%、终伤＋399%；70～81级保持此加成"],"source":["专属魔法暴击率:随魂海进度最高＋1000%（15万魂）","效果:灵魂达标时自动获得进阶印","效果:可查看当前灵魂数与进阶阶位","魔法再释放＋15%：触发时额外命中一次，不重复扣费","成功进阶后本阶灵魂清零，下一阶重新收集","终伤与爆伤按等级线性插值，1级均为0","10级 爆伤＋20% 终伤＋15%；25级＋80%／＋60%","40级 爆伤＋180% 终伤＋140%；55级＋300%／＋240%","70级 爆伤＋500% 终伤＋399%；70～81级保持此加成"]},"10156":{"rows":["成长：5～15级，共鸣伤害由×1.15平滑提高至×1.66","成长：15～50级由×1.66提高至×1.80；50～60级继续提高至×2","节点：50／55／60级分别为×1.80／×1.90／×2.00","成长：暴击率5／15／70级分别＋15%／＋95%／＋888%，其间平滑增长"],"source":["50／55／60级时×1.80／1.90／2.00","5～15级:共鸣伤害×1.15平滑增至×1.66；15～50级增至×1.80","50～60级:共鸣伤害×1.80平滑增至×2","暴击率5级＋15%，15级＋95%，70级＋888%，其间平滑成长"]},"10157":{"rows":["效果：最大生命＋15000；物防、魔防各＋5000；速度＋1000","解锁:30级且完成第1次进阶"],"source":["效果:最大生命+15000，物理防御、魔法防御各+5000，速度+1000","解锁:30级且完成第1次进阶"]},"10185":{"rows":["效果：紫电双斩、霆影横渡、八雷飞渡伤害＋99%","效果：赤雨·黄泉归葬伤害＋33%；暴击率＋999%","联动：八雷飞渡造成伤害前，施加两次集真赤"],"source":["特效:八雷飞渡伤害前施加两次集真赤","特效:暴击率＋999%","特效:紫电双斩、霆影横渡、八雷飞渡战技伤害＋99%","特效:终结战技赤雨·黄泉归葬伤害＋33%"]},"10196":{"rows":["效果：强化战技施放时，只扣除其他存活队友生命一次；每人至少保留1点生命","血契：累计本场实际扣血，提升对应强化战技的伤害倍率","倍率：1＋min(累计扣血÷(5×自身最大生命),上限－1)","上限：寒川映月进阶前×1.8，进阶后×2.5","上限：霜痕尽裂×1.25；碎月穿霜×1.5"],"source":["特效:强化战技每次只扣其他存活队友生命一次","特效:每名队友至少保留1生命；本场实际扣血累计","倍率:1＋min(累计扣血÷(5×自身最大生命),上限－1)","上限:霜痕尽裂×1.25，碎月穿霜×1.5","上限:寒川映月进阶前×1.8，进阶后×2.5"]},"10205":{"rows":["限制：游戏难度惩罚仍生效","效果：每回合额外行动1次；免疫战斗负面状态与属性减益","成长：最大生命＋角色等级×10%；物攻、速度＋角色等级×5%","成长：暴击率＋角色等级×10%；爆伤、终伤＋角色等级×40%","效果：咒具本体、武器库追击与反弹伤害×3","成长：主要咒具威力随等级平滑提升；20级后增幅逐步趋缓，50级前后连续过渡。"],"source":["特效:咒具本体、武器库追击、反弹伤害×3","效果:暴击伤害、最终伤害+角色等级×40%","效果:暴击率+角色等级×10%","效果:物理攻击、速度+角色等级×5%","效果:最大生命+角色等级×10%；咒具伤害随平滑曲线成长","限制:游戏难度惩罚仍生效","特效:免疫战斗负面状态与属性减益","特效:再动+1","主要咒具20级前沿用早期成长，其后平滑趋缓；无50级突然冲顶"]},"10239":{"rows":["属性：生命、魔法各＋7500；双攻、双防、速度各＋1500；幸运＋750","术式威力：88888","熟练成长：主动技能每级增伤15%，另沿用角色熟练增幅","效果：每场战斗开场至少60TP，不超过当前TP上限"],"source":["术式威力:88888；主动熟练每级增伤15%，另沿用本体熟练增幅","属性:生命、魔法各＋7500；双攻、双防、速度各＋1500；幸运＋750"]},"10265":{"rows":["效果：受到敌方伤害技能命中后，有33%概率以流水岩碎拳反击","反击规则：每次敌方施放最多触发一次，多段攻击不重复触发"],"source":["效果:受到敌方伤害技能命中后，有33%概率以流水岩碎拳反击","反击:每次敌方施放最多触发一次；多段攻击不会重复触发"]},"10270":{"rows":["装备限制：无","目标：敌方单体；学会云丝展幅后为全体","伤害类型：魔法；元素：奥术","命中：必中；可暴击","段数：基础一段；双针并行后每段拆为两段","冷却：无","效果：种下符针，在敌人行动前引爆；唤醒中的队友命中可提前引爆一枚","效果：目标下次伤害行动的伤害降低33%","基础伤害：66.66×魔攻","防御：按攻防比例结算，最多减伤95%","熟练成长：每级伤害提高999%"],"source":["段数：基础一段；双针并行后每段拆为两段","冷却：无","技能熟练：每级伤害提高999%","目标下次伤害行动造成的伤害降低33%","唤醒中的队友命中可提前引爆一枚符针","效果：种下符针，在敌人行动前引爆","有效魔攻＝max(0，魔攻－目标魔防×10%)","基础伤害：66.66×有效魔攻","目标：敌方单体；学会云丝展幅后为全体","命中：必中；可暴击","伤害类型：魔法；元素：奥术","装备限制：无"]},"10273":{"rows":["装备限制：无","目标：一名存活、出场且穿戴天衣的队友","冷却：3回合","效果：唤醒目标天衣的神纹，持续本回合及下一回合","重复施放：只刷新持续时间，不重复发放首次唤醒奖励","解锁条件：35级，完成第1次进阶"],"source":["冷却：3回合","刷新唤醒不重复发放首次唤醒奖励","再次施放只刷新持续时间","持续：本回合及下一回合","效果：唤醒目标天衣的神纹","目标：一名存活且穿戴天衣的出场队友","装备限制：无","解锁条件：35级，完成第1次进阶"]},"10274":{"rows":["装备限制：无","目标：敌方单体；学会云丝展幅后为全体","伤害类型：魔法；元素：奥术","命中：必中；可暴击","施放前：选择一名处于唤醒状态的队友","代价：提前结束所选队友的唤醒","冷却：3回合","段数：基础一段；双针并行后每段拆为两段","基础伤害：246.21×魔攻×剩余回合数","防御：按攻防比例结算，最多减伤95%","熟练成长：每级伤害提高999%","解锁条件：50级，完成第2次进阶"],"source":["段数：基础一段；双针并行后每段拆为两段","冷却：3回合","技能熟练：每级伤害提高999%","代价：提前结束所选队友的唤醒","有效魔攻＝max(0，魔攻－目标魔防×5%)","基础伤害：246.21×有效魔攻×剩余回合数","施放前：选择一名处于唤醒状态的队友","目标：敌方单体；学会云丝展幅后为全体","命中：必中；可暴击","伤害类型：魔法；元素：奥术","装备限制：无","解锁条件：50级，完成第2次进阶"]},"10276":{"rows":["生效条件：已学会本被动","效果：自身单体伤害技能扩展为敌方全体；主目标100%，其他目标50%","成长：生命、魔攻、敏捷变为基础成长的1.5倍","成长：25级起，每级爆伤＋188%、终伤＋18.88%；25级计入第一份加成","成长规则：随后续节点替换倍率，不重复相乘"],"source":["成长倍率随后续节点替换，不重复相乘","主目标伤害100%，其他目标伤害50%","自身单体伤害技能扩展为敌方全体","25级计入第一份加成","25级起，每级增加爆伤188%、终伤18.88%","成长：生命、魔攻、敏捷变为基础成长的1.5倍","生效条件：已学会本被动"]},"10281":{"rows":["生效条件：云裳存活、出场且已学会本被动","效果：开场唤醒全部出场天衣穿戴者，持续前两个回合","成长：50级且完成二阶后，生命、魔攻、敏捷累计变为4倍","成长规则：替换前一节点的倍率，不重复相乘","解锁条件：55级，完成第2次进阶"],"source":["成长倍率替换前一节点，不重复相乘","生命、魔攻、敏捷累计变为4倍","成长说明：50级且完成二阶后，","持续：前两个回合","效果：开场唤醒全部出场天衣穿戴者","生效条件：云裳存活、出场且已学会本被动","解锁条件：55级，完成第2次进阶"]},"10287":{"rows":["使用方式：技能菜单→被动→天衣铺","可用场合：战斗外；无MP、TP消耗","制作条件：云裳35级，且没有正在制作的订单","制作材料：不朽天丝×15","完成条件：云裳出场累计十个完整战斗回合","功能：制作、领取、进阶与战前配置","制作规则：按当前等级与进阶，随机制作一件可用天衣","进阶方式：选择所需天衣，消耗后完成进阶"],"source":["进阶时选择所需天衣，消耗后完成进阶","按当前等级与进阶，随机制作一件可用天衣","完成条件：云裳出场累计十个完整战斗回合","制作材料：不朽天丝×15","制作条件：云裳35级，且没有正在制作的订单","功能：制作、领取、进阶与战前配置","可用场合：战斗外；无MP、TP消耗","使用方式：技能菜单→被动→天衣铺"]},"10127":{"rows":["目标：自己","命中：必中","基础消耗：180MP／0TP","效果：进入神话形态3回合；每有敌人死亡，剩余时间＋1回合，最多5回合","解锁:完成第5次进阶"],"source":["持续：进入时3回合，敌人死亡后剩余时间＋1，最多5回合","命中类型:必中","目标:自己","装备限制:无","效果:每有敌人死亡延长1回合，最多持续5回合","效果:进入神话形态，持续3回合","基础消耗：180MP／0TP；实际消耗以技能列表为准","解锁:完成第5次进阶","条件:完成第五次进阶"]},"10168":{"rows":["生效条件：奈叶出场","效果：队友击败敌人时，奈叶的“适应”成长同样触发一次","成长：每次永久增加最大生命10、最大魔法30"],"source":["效果:队友击败敌人时，奈叶的“适应”成长同样触发一次；最大生命永久+10，最大魔法永久+30"]},"10194":{"rows":["成长：20级生命＋100%；25级冰伤＋100%；30级普通战技＋100%","成长：35级物攻＋100%；40级生命再＋100%；45级强化战技＋100%"],"source":["生效条件：已习得本被动且达到对应等级；以下当前星魂随实际角色显示","星魂预览：35级物攻＋100%；40级生命再＋100%；45级强化战技＋100%","星魂预览：20级生命＋100%；25级冰伤＋100%；30级普通战技＋100%"]},"10203":{"rows":["效果：最大魔法的100%转为最大生命，魔攻的100%转为物攻；转化后最大魔法、魔攻均为0","效果：速度高于对手时，提高物理命中与闪避，最多各＋30%","限制：仅影响物理命中与闪避；必中不受闪避影响","说明：装备属性参与转化；魔法恢复不转为生命恢复","速度加成：min(30%，max(0，自身速度÷对手速度－1)×15%)"],"source":["说明:魔法恢复不转为生命恢复；装备属性参与转化","限制:仅物理命中、闪避生效；必中不受闪避影响","速度加成:min(30%,max(0,自身速度÷对手速度－1)×15%)","效果:自身速度高于对手时，命中、闪避最多各+30%","特效:绝影:速度优势转化为物理命中与闪避","特效:最大魔法、魔法攻击固定为0","特效:魔法攻击的100%转为物理攻击","特效:最大魔法的100%转为最大生命"]},"10277":{"rows":["效果：每个原伤害段拆为两段，每段55.5%；群攻其他目标比例提高至66%","成长：生命、魔攻、敏捷累计变为2倍；替换前一节点，不重复相乘"],"source":["成长倍率替换前一节点，不重复相乘","群攻的其他目标伤害比例提高至66%","每个原伤害段拆为两段，每段55.5%","成长：生命、魔攻、敏捷累计变为2倍","生效条件：已学会本被动"]},"10278":{"rows":["效果：每个命中敌人种下两枚符针，每枚为原符针伤害的55.5%；群攻其他目标比例提高至77%","成长：生命、魔攻、敏捷累计变为2.5倍；替换前一节点，不重复相乘","解锁条件：35级，完成第1次进阶"],"source":["成长倍率替换前一节点，不重复相乘","群攻的其他目标伤害比例提高至77%","每枚符针为原符针伤害的55.5%","每个命中敌人种下两枚符针","成长：生命、魔攻、敏捷累计变为2.5倍","生效条件：已学会本被动","解锁条件：35级，完成第1次进阶"]},"10279":{"rows":["效果：符针改为三枚，每枚为原符针伤害的40%","成长：生命、魔攻、敏捷累计变为3倍；替换前一节点，不重复相乘","解锁条件：40级，完成第1次进阶"],"source":["成长倍率替换前一节点，不重复相乘","符针数量改为三枚，每枚为原符针伤害的40%","成长：生命、魔攻、敏捷累计变为3倍","生效条件：已学会本被动","解锁条件：40级，完成第1次进阶"]},"10280":{"rows":["生效条件：云裳出场","来源：已登记的不朽存在战斗胜利","效果：每累计两次有效通关，额外获得一份不朽天丝","规则：在正常天丝奖励之外结算；同一次战斗不重复发放","解锁条件：45级，完成第1次进阶"],"source":["同一次战斗结算不重复发放","额外奖励在正常天丝奖励之外结算","每累计两次有效通关，额外获得一份不朽天丝","来源：已登记的不朽存在战斗胜利","生效条件：云裳出场且已学会本被动","解锁条件：45级，完成第1次进阶"]}};
 function characterHelpTarget(item){
  if(!item)return false;
  if(window.CodexCat && /<CodexCat:/.test(item.note||""))return true;
  // Catalogue/mastery/power panels pass shallow display copies.
  if(item.stypeId!==undefined)return Number(item.id)>=10122&&Number(item.id)<=10299;
  if(item.wtypeId===undefined&&item.atypeId===undefined)return false;
  var id=Number(item.originalBaseItemId||item.baseItemId||item.id);
  return id===4001||(id>=4577&&id<=4581)||
   [7904,7905,7906,7908,7909,7910,7911].indexOf(id)>=0||(id>=7920&&id<=7935);
 }
 function plainHelpText(text){return String(text||'').replace(/(?:\\|\x1b)c\[\d+\]/gi,'');}
 function helpNoteRows(note){var rows=[],re=/<pos=APs\s+text=([\s\S]*?)\s+size=/gi,m;while((m=re.exec(String(note||''))))rows.push(plainHelpText(m[1]));return rows;}
 function compactHelpText(text){
  return plainHelpText(text).replace(/^([^:：]{1,18}):/,'$1：')
   .replace(/^命中类型：/,'命中：').replace(/^能否暴击：是$/,'暴击：可').replace(/^能否暴击：否$/,'暴击：不可')
   .replace(/^(?:攻击次数|实际段数)：/,'段数：').replace(/^特效：/,'效果：')
   .replace(/^(?:熟练成长|技能熟练|成长规则|成长说明|节点)[：:]/,'成长：')
   .replace(/^伤害受技能等级加成。$/,'成长：伤害随技能等级提高')
   .replace(/^目标：(?:单个敌人|单体敌人|敌人单体)$/,'目标：敌方单体').replace(/^目标：(?:所有敌人|全体敌人|敌人全体)$/,'目标：敌方全体').replace(/^能否暴击：能$/,'暴击：可').replace(/^能否暴击：不能$/,'暴击：不可').replace(/^等级成长[：:]/,'成长：')
   .replace(/；实际消耗以技能列表为准/g,'').replace(/；无(?:MP、TP|魔法、TP)消耗/g,'')
   .replace(/^生效条件：(.+?)(?:且|、)已(?:学会|习得)本被动$/,'生效条件：$1');
 }
 function ordinaryUnlockText(text){
  return /^(?:人物等级解锁|解锁等级|解锁(?:条件)?)[：:]\s*(?:[\u4e00-\u9fff]{0,4})?\d+级?\s*$/.test(plainHelpText(text));
 }
 function helpResourceCost(text){
  return /^(?:(?:基础)?(?:MP|TP)?)?消耗[：:]/.test(text)&&/(?:MP|TP|魔法)/.test(text)&&!/(?:行动|生命|残梦|朔望|唤醒)/.test(text);
 }
 function helpInfo(text){
  return /^(?:类型|元素|武器限制|专属|(?:生效|完成|制作|双重集真赤)?条件|装备限制|使用限制|限制|(?:(?:基础)?(?:MP|TP)?)?消耗|代价|制作材料|材料|目标|伤害类型|伤害属性|命中(?:类型)?|能否暴击|暴击|攻击次数|实际段数|段数|冷却(?:时间)?|准备时间|可用场合|使用方式|施放前|时点|来源|当前等级|当前经验|法宝经验|等级需求|等级上限|法宝形态|咒具熟练|进阶继承|储存上限)[：:]/.test(text)||/^(?:当前咒具|切换至此咒具)/.test(text);
 }
 function helpGrowth(text){
  return /^(?:成长|熟练成长|技能熟练|每级|法宝每级|星魂预览|节点|升级)/.test(text)||
   /(?:随等级|按等级|每级|平滑|线性|成长|熟练度提高|实际成长上限)/.test(text);
 }
 function helpFormula(text){
  return /^(?:基础治疗|基础护盾|伤害|真实伤害|斩击|体术|自动斩击|每段(?:基础)?|基础伤害|基式|有效魔攻|有效双防|蓄势附加伤害|阶位系数|魄倍率|冠冕倍率|形态系数|防御系数|速度加成|倍率|术式威力|生命增量|魔法增量|魔攻增量)[：:=＝]/.test(text)||/^[＋+×－−-]/.test(text);
 }
 // Resolve the actor whose native panel is showing this skill. Reading a help
 // panel must never create actors, teach skills or synchronize progression.
 function characterHelpActor(item,options){
  if(options&&options.actor)return options.actor;
  var scene=SceneManager._scene;
  if(window.CodexCat && /<CodexCat:/.test(item && item.note||"")){var ca=$gameActors._data[CodexCat.ids.actor];if(ca)return ca;return {actorId:function(){return CodexCat.ids.actor;},level:1,_AdvancedNum:0,_skills:[],_skillMasteryLevels:{},_characterHelpPreview:true};}
  if(scene){
   if(scene._actorSkillList&&scene._actorSkillList.visible&&scene._actorSkillList._actor)return scene._actorSkillList._actor;
   if(typeof Scene_Battle!=='undefined'&&scene instanceof Scene_Battle){
    var list=scene._skillWindow;if(list&&list.visible&&list._actor)return list._actor;
   }
   if(scene._actor&&!(typeof Scene_ActorBook!=='undefined'&&scene instanceof Scene_ActorBook))return scene._actor;
  }
  var tagged=/<CodexTusu:/.test(String(item&&item.note||''))?176:/<CodexXuan:/.test(String(item&&item.note||''))?177:/<GuyuSkill:/.test(String(item&&item.note||''))?175:0;
  var id=Number(item&&item.id),owner=tagged|| (id<=10139?167:id<=10167?168:id===10168?166:id===10170?167:id<=10186?169:id<=10202?170:id<=10228?171:id<=10249?172:id<=10269?173:id<=10287?174:175);
  var stored=$gameActors&&$gameActors._data&&$gameActors._data[owner];if(stored)return stored;
  if(scene&&scene._actorSkillList&&scene._actorSkillList._actor&&scene._actorSkillList._actor.actorId()===owner)return scene._actorSkillList._actor;
  // The catalogue can preview an unowned role. Use initial-state data without
  // constructing a Game_Actor or altering the saved actor registry.
  var initial=Number($dataActors[owner]&&$dataActors[owner].initialLevel||1);
  return {actorId:function(){return owner;},isActor:function(){return true;},level:initial,_level:initial,_AdvancedNum:0,_codexRavenStage:0,_skills:[],_states:[],_skillMasteryLevels:{},
   isLearnedSkill:function(){return false;},isStateAffected:function(){return false;},equips:function(){return [];},_characterHelpPreview:true};
 }
 function helpNumber(n){return String(Math.round(Number(n)*1000000)/1000000);}
 function helpLearned(actor,id){return !!(actor&&actor._skills&&actor._skills.indexOf(id)>=0);}
 function currentHelpText(text,item,actor){
  if(!actor||item.stypeId===undefined)return text;
  var id=Number(item.id),who=actor.actorId(),lv=Number(actor.level||actor._level||1),rank=Number(actor._AdvancedNum||0);
  function learned(i){return helpLearned(actor,i);}
  var mastery=Number(actor._skillMasteryLevels&&actor._skillMasteryLevels[id]||0);
  if(window.CodexCat && /<CodexCat:/.test(item.note||""))return CodexCat.helpText(text,item,actor);
  text=text.replace(/角色等级[×*](\d+(?:\.\d+)?)%/g,function(_,n){return helpNumber(lv*Number(n))+'%';});
  text=text.replace(/1[＋+]技能等级[×*](\d+(?:\.\d+)?)%/g,function(_,n){return helpNumber(1+mastery*Number(n)/100);});
  if(helpResourceCost(text)&&actor.skillMpCost&&actor.skillTpCost){
   var mp=actor.skillMpCost(item),tp=actor.skillTpCost(item),cost=[];if(mp)cost.push(helpNumber(mp)+'MP');if(tp)cost.push(helpNumber(tp)+'TP');return cost.length?'消耗：'+cost.join('／'):null;
  }
  if(DYN2_SKIP[id])return text;
  // 通用：分阶列表只取当前阶；「X%＋每阶Y%」直接算出；条件式文字改为当前状态或不显示。
  text=helpCurrentTiers(text,who===167?Number(actor._codexRavenStage||rank):rank);
  var gate=/^(?:([^：:]{1,8})[：:])?(\d+)级起(.+)$/.exec(text);if(gate){if(lv<Number(gate[2]))return null;text=(gate[1]||'效果')+'：'+gate[3];}
  if(/进阶后(?:由|替换为)|第[一二三四五六七八九十\d]+次进阶后由|(?:\d+级)?进阶后替换/.test(text))return null;
  text=text.replace(/进阶后获得对应形态的/,'获得当前形态的').replace(/×\(1\)$/,'');
  if(who===167&&window.CodexRaven){
   text=text.replace(/[－-]敌魔防×\(1[－-]穿透率\)÷11/,'');if(/^敌魔防扣除同步/.test(text))return null;
   var R=CodexRaven,stage=Math.max(0,Math.min(5,Number(actor._codexRavenStage||0))),p=Math.min(1,Math.max(0,Number(actor._codexRavenSoul||0)/150000));
   function ravenHas(i){var gate=R.SKILL_GATE[i]||[1,0];return learned(i)&&lv>=gate[0]&&stage>=gate[1];}
   if(helpResourceCost(text)&&actor._characterHelpPreview)return '基础消耗：'+(item.mpCost?item.mpCost+'MP＋':'')+helpNumber((item.mpCostPer||0)*100)+'%最大MP';
   if(/^阶位系数：/.test(text))return '阶位系数：'+helpNumber(R.skillCoefficient(actor,id));
   if(/^魄倍率：/.test(text))return '魄倍率：'+helpNumber(R.legionStrikeRate(actor));
   if(/^冠冕倍率：/.test(text))return '冠冕倍率：'+helpNumber(R.crownRate(actor));
   if(id===10122&&/(?:回复|恢复).*2%/.test(text))return '效果：命中后每次施放回复2%最大魔法；追加命中不重复回复';
   if(id===10124&&/二阶命中|三阶起由夜蚀/.test(text))return stage===2?'效果：命中施加黑暗侵蚀':null;
   if([10128,10135].indexOf(id)>=0&&/^本阶魂海门槛/.test(text))return stage<5?'本阶魂海门槛：'+R.REQUIRE[stage+1]:'当前进阶：已完成五阶';
   if(id===10130&&/^(?:成长|效果|联动)：/.test(text))return '效果：当前魔防穿透率'+helpNumber((1-R.defenseFactor(actor))*100)+'%';
   if(id===10131&&/进阶次数|魂海进度|每提高1%/.test(text)){
    if(/最终伤害/.test(text))return '效果：专属魔法最终伤害倍率×'+helpNumber(ravenHas(id)?1+1.5*Math.min(1,(stage+p)/5):1);
    if(/黑暗/.test(text))return null;
   }
   if(id===10131&&/专属黑暗魔法伤害/.test(text))return '效果：专属黑暗魔法伤害＋'+helpNumber(ravenHas(id)?200+p*100:0)+'%';
   if(id===10131&&/^限制：魂海进度/.test(text))return '魂海进度：'+helpNumber(p*100)+'%';
   if(id===10137){
    if(/暴击率随魂海|15万灵魂时/.test(text))return '效果：专属魔法暴击率＋'+helpNumber(learned(id)?p*1000:0)+'%';
    if(/^成长：/.test(text)){var pool=learned(id)?R.growthPools(actor):{critical:0,final:0};return '成长：当前爆伤＋'+helpNumber(pool.critical)+'%；终伤＋'+helpNumber(pool.final)+'%';}
   }
   if(id===10138&&/爆伤和终伤/.test(text)){var pool=learned(10137)?R.growthPools(actor):{critical:0,final:0};return '成长：当前爆伤＋'+helpNumber(pool.critical)+'%；终伤＋'+helpNumber(pool.final)+'%';}
   if(id===10139&&/^五阶习得/.test(text))return stage===5&&ravenHas(10136)?'效果：当前魂海溢出已计入冠冕倍率':null;
   if(id===10136){if(/^五阶后/.test(text))return stage===5&&ravenHas(id)?'效果：当前魂海溢出已计入冠冕倍率':null;if(/^60级且五阶/.test(text))return lv>=60&&stage===5&&ravenHas(id)?'伤害：专属攻击结算倍率×4.25':null;}
  }
  if(who===168){
   var dragon=!!($gameParty.inBattle()&&rank>=3&&learned(10161)&&actor.isStateAffected(2592));
   if(id===10144&&(/^30[～~]35级/.test(text)||/^效果：人形/.test(text)))return '成长：当前人形双防倍率×'+helpNumber(!dragon&&lv>=30&&learned(id)?1.25*(1+.25*Math.min(1,(lv-30)/5)):1);
   if(id===10145&&/^40[～~]45级/.test(text))return '成长：当前人形速度倍率×'+helpNumber(!dragon&&lv>=40&&learned(id)?1.1*(1+.25*Math.min(1,(lv-40)/5)):1);
   if(id===10145&&/^效果：人形/.test(text))return '效果：当前人形物攻、魔攻各×'+helpNumber(!dragon&&lv>=40&&learned(id)?1.1:1);
   if(id===10161&&/^三阶黑龙/.test(text))return dragon?'伤害：黑龙专属攻击基式×24.85':null;
   if(id===10156&&/^成长：|^成长：?节点：/.test(text)){
    var active=learned(id),damage=lv>=60?2:lv>=50?1.8+.02*(lv-50):lv>=15?1.66+.14*(lv-15)/35:1.15+.051*Math.max(0,lv-5);
    var crit=lv<5?0:lv<=15?.15+.08*(lv-5):.95+7.93*Math.min(1,(lv-15)/55);
    return /暴击/.test(text)?'成长：当前暴击率＋'+helpNumber(active?crit*100:0)+'%':'成长：当前人形共鸣伤害倍率×'+helpNumber(active&&!dragon?damage:1);
   }
  }
  if(who===169&&id===10173&&/习得八雷贯心后|双重集真赤条件/.test(text))return learned(10185)?'效果：主目标伤害前施加两次集真赤':null;
  if(who===170&&id===10196&&/^上限：寒川映月/.test(text))return '上限：寒川映月×'+(learned(10202)?'2.5':'1.8');
  if(who===171&&id===10205&&/主要咒具威力|主要咒具20级/.test(text)&&window.CodexToji)return '成长：主要咒具当前成长系数×'+helpNumber(CodexToji.outputGrowth(actor,true));
  if(who===171&&/^成长：.*平滑成长系数/.test(text)&&window.CodexToji)return '成长：当前咒具成长系数×'+helpNumber(CodexToji.outputGrowth(actor,[10216,10217,10218,10219].indexOf(id)>=0));
  if(who===172&&window.CodexSukuna){
   if(/^术式威力：/.test(text)||id>=10247&&id<=10249&&/^\d+级术式系数/.test(text))return '术式威力：'+CodexSukuna.coefficient(actor);
   if(id>=10247&&id<=10249&&/^获得精研/.test(text)){function hasRefine(i){var m=$dataSkills[i].meta;return learned(i)&&lv>=Number(m.CodexUnlockLevel||1)&&rank>=Number(m.CodexUnlockRank||0);}return '当前成长上限：'+(hasRefine(10247)?hasRefine(10249)?99:hasRefine(10248)?70:60:50)+'级';}
   if(id===10242&&/^领域内：/.test(text)){var stored=actor._codexSukuna,emp=stored&&stored.emp||0,dom=stored&&stored.domain>0&&actor.isStateAffected(2636);return dom&&emp&&actor.isStateAffected(2639)?'领域内：当前一次斩击提高'+helpNumber((.35+(emp-1)*.05)*100)+'%':null;}
   if(id===10242&&/^斩击强化：/.test(text)){var emp=actor._codexSukuna&&actor._codexSukuna.emp||0,awake=actor.isStateAffected(2639),dom=actor._codexSukuna&&actor._codexSukuna.domain>0&&actor.isStateAffected(2636);return emp&&awake?'斩击强化：当前一次斩击提高'+helpNumber(((dom?.35:.2)+(emp-1)*.05)*100)+'%':'斩击强化：当前未储存';}
  }
  if(who===173&&window.CodexGarou){
   var G=CodexGarou,form=G.form(actor);
   if(/^形态系数：/.test(text))return '形态系数：'+form.damage_scale;
   if(id===10266&&/^增伤：/.test(text))return '增伤：每层增加'+(form.passives.evolution_enabled?form.passives.evolution_base_per_stack_percent:0)+'%伤害';
   if(id===10267&&/^破防：/.test(text))return '破防：每层无视'+form.passives.analysis_defense_ignore_percent_per_stack+'%物防';
   if(id===10267&&/^星空：/.test(text))return form.passives.analysis_magic_defense_ignore_percent_per_stack?'破防：每层无视'+form.passives.analysis_magic_defense_ignore_percent_per_stack+'%魔防；最多无视99%':null;
   if(id===10269){var m=form.form_multiplier;if(/^形态：/.test(text))return '形态：'+form.name;if(/^四臂：/.test(text))return '效果：当前每回合行动'+form.actions_per_round+'次';if(/^星空：/.test(text))return '效果：生命×'+m.mhp+'；速度×'+m.agi+'；物攻×'+m.atk+'；魔攻×'+m.mat+'；双防×'+m.defense;}
  }
  if(who===174&&window.CodexYunshang){
   var C=CodexYunshang.config;
   function yunHas(i){var g=C.gates[i]||[1,0];return learned(i)&&lv>=g[0]&&rank>=g[1];}
   if(/^目标：.*学会云丝展幅/.test(text))return yunHas(10276)?'目标：敌方全体':'目标：敌方单体';
   if(/^段数：基础一段/.test(text))return '段数：'+(yunHas(10277)?2:1);
   if(id>=10276&&id<=10281&&/^成长：/.test(text)){
    var multiplier=lv>=50&&rank>=2?4:lv>=40&&rank>=1?3:lv>=35&&rank>=1?2.5:lv>=30?2:lv>=25?1.5:1;
    if(/爆伤|终伤/.test(text)){var p=yunHas(10276)?CodexYunshang.offensiveGrowth(actor):{crit:0,final:0};return '成长：当前爆伤＋'+helpNumber(p.crit*100)+'%；终伤＋'+helpNumber(p.final*100)+'%';}
    return '成长：当前生命、魔攻、敏捷基础成长倍率×'+multiplier;
   }
   if(id>=10276&&id<=10281&&/^成长规则：/.test(text))return null;
   if(id===10276&&/其他目标50%/.test(text))return yunHas(10276)?'效果：单体伤害技能扩展为敌方全体；主目标100%，其他目标'+(yunHas(10278)?77:yunHas(10277)?66:50)+'%':null;
  }
  // Character progression clauses describe only the currently matching branch.
  // Retain action triggers, target conditions, durations and real usage limits.
  var range=/^(?:效果：)?([0-9]+)[～~]([0-9]+)阶(?:[：:]|(?=命中))/.exec(text);
  if(range){var current=who===167?Number(actor._codexRavenStage||0):rank;if(current<Number(range[1])||current>Number(range[2]))return null;text=text.replace(range[0],'效果：');}
  var gate=/^(?:效果：)?([一二三四五六七八九]|\d+)阶(?:起|时)[：:]?/.exec(text);
  if(gate){var n=Number(gate[1])||'一二三四五六七八九'.indexOf(gate[1])+1;if(rank<n)return null;text=text.replace(gate[0],'效果：');}
  var levelGate=/^(\d+)级起[：:]/.exec(text);if(levelGate){if(lv<Number(levelGate[1]))return null;text=text.replace(levelGate[0],'效果：');}
  if(who===168&&/^效果：人形/.test(text)&&dragon)return null;
  if(who===168&&/^(?:效果|特效)：黑龙形态下/.test(text)&&!dragon)return null;
  return text;
 }
 function helpCurrentTiers(text,rank){
  var tier=/[（(](?:按[^（）()]*?)?0[～~](\d)阶[）)]/.exec(text)||/[（(]?(?:按[^（）()，,]*?)?0[～~](\d)阶(?:依次为)?[）)]?/.exec(text);
  if(tier){var n=Number(tier[1])+1,idx=Math.max(0,Math.min(n-1,rank)),list=new RegExp('(×?)((?:[\\d.]+%?)(?:[／/][\\d.]+%?){'+(n-1)+'})').exec(text);
   if(list){var vals=list[2].split(/[／/]/);text=text.replace(list[0],list[1]+vals[idx]).replace(tier[0],'').replace(/[，,；;：:]\s*$/,'').replace(/：\s*[，,]/,'：');}}
  text=text.replace(/(\d+(?:\.\d+)?)%[＋+]每阶(\d+(?:\.\d+)?)%/g,function(_,b,s){return helpNumber(Number(b)+Number(s)*rank)+'%';}).replace(/×\((\d+(?:\.\d+)?%)\)/g,'×$1');
  return text;
 }
 // 进阶带来的系数变化：比较该次进阶前后，同一角色主动技能显示的公式/成长数值。
 function helpRankChanges(item,actor){
  if(!actor||actor._characterHelpPreview||!window.$dataStarAdvancedOpt||item.stypeId===undefined)return [];
  if(window.Guyu&&Guyu.isGuyu(actor))return []; // 谷雨的进阶只加储备上限，已写在「成长：储备比例」

  var who=actor.actorId(),id=Number(item.id),rank=-1,owned=[];
  $dataStarAdvancedOpt.forEach(function(e){if(!e||Number(e.AdvancedActId)!==who)return;var list=e.AdvancedSkiId||[];owned=owned.concat(list);if(list.map(Number).indexOf(id)>=0&&rank<0)rank=Number(e.AdvancedActNum)+1;});
  if(rank<1||Number(actor._AdvancedNum||0)<rank)return [];
  var first=$dataStarAdvancedOpt.filter(function(e){return e&&Number(e.AdvancedActId)===who&&Number(e.AdvancedActNum)+1===rank;}).map(function(e){return (e.AdvancedSkiId||[]).map(Number);})[0]||[];
  var holder=first.filter(function(i){return $dataSkills[i]&&$dataSkills[i].stypeId===4;})[0]||first[0];if(holder!==id)return [];
  var cls=$dataClasses[actor._classId],ids=(cls?cls.learnings.map(function(l){return l.skillId;}):[]).concat(owned.map(Number)),out=[],seen={};
  function proxy(r){var p=Object.create(actor);p._AdvancedNum=r;if(who===167)p._codexRavenStage=r;return p;}
  var before=proxy(rank-1),after=proxy(rank);
  var groups={},order=[];
  ids.forEach(function(sid){if(seen[sid]||sid===id)return;seen[sid]=true;var s=$dataSkills[sid];if(!s)return;
   helpNoteRows(s.note).forEach(function(raw){var text=compactHelpText(raw);if(helpInfo(text)||helpResourceCost(text)||/^伤害[：:]/.test(text)||!/\d/.test(text))return;
    var a,b;try{a=currentHelpText(text,s,before);b=currentHelpText(text,s,after);}catch(e){return;}
    if(!a||!b||a===b)return;var ia=a.indexOf('：'),ib=b.indexOf('：');if(ia<1||ib<1||a.slice(0,ia)!==b.slice(0,ib))return;
    var label=a.slice(0,ia),va=a.slice(ia+1),vb=b.slice(ib+1);if(/^0$/.test(va)||va.length>24||vb.length>24)return;
    va=va.replace(/\d+\.\d{3,}/g,function(n){return helpNumber(Math.round(Number(n)*100)/100);});vb=vb.replace(/\d+\.\d{3,}/g,function(n){return helpNumber(Math.round(Number(n)*100)/100);});var key=label+'|'+va+'|'+vb;if(!groups[key]){groups[key]={label:label,va:va,vb:vb,names:[]};order.push(key);}if(groups[key].names.indexOf(s.name)<0)groups[key].names.push(s.name);});});
  function span(a,b){var i=0,j=0;while(i<a.length&&i<b.length&&a[i]===b[i])i++;while(i>0&&/[\d.]/.test(a[i-1]))i--;
   while(j<a.length-i&&j<b.length-i&&a[a.length-1-j]===b[b.length-1-j])j++;while(j>0&&/[\d.%]/.test(a.charAt(a.length-j)))j--;
   return a.slice(0,i)+a.slice(i,a.length-j)+'→'+b.slice(i,b.length-j)+a.slice(a.length-j);}
  order.forEach(function(key){var g=groups[key],n=g.names,who=n.length<=2?n.join('、'):n.slice(0,2).join('、')+'等'+n.length+'项';out.push('进阶变化：'+g.label+' '+span(g.va,g.vb)+'（'+who+'）');});
  return out.slice(0,6);
 }
 function characterHelpStamp(item){var actor=characterHelpActor(item);return actor?JSON.stringify([actor.actorId(),actor._level,actor._AdvancedNum,actor._codexRavenStage,actor._codexRavenSoul,actor._states,actor._skills,actor._skillMasteryLevels,actor._codexJingliuBloodTotal]):'';}

 // 原有角色技能：同一套分组与配色，不改动其文字以外的内容。
 function genericHelpView(item){
  var header=[],formula=[],info=[],effects=[],growth=[],footer=[],elementRows=[],seen={};
  item.descParams.forEach(function(row){
   var raw=String(row[0]||''),plain=plainHelpText(raw);if(!plain.trim())return;
   if(row[0]===item.name||row[0]===item.description||/^品质[：:]/.test(plain)||/^(?:战技|魔法|被动|呼吸法|其他|功法|鬼灭呼吸法)$/.test(plain)){header.push(row);return;}
   if(/^(?:购买价格|出售价格|无法出售)/.test(plain)){footer.push(row);return;}
   if(/^(?:伤害属性|攻击属性|触发攻击属性)[：:]/.test(plain)){var er=row.slice();er[0]='\\c[0]'+raw.replace(/^(?:\\c\[\d+\])+/i,'');er[2]='rgba(235,240,247,1)';er[3]=false;er[4]=0;elementRows.push(er);return;}
   var text=compactHelpText(plain.replace(/^对象[：:]/,'目标：').replace(/^(MP|TP)消耗[：:]\s*(\d+)\s*$/,'消耗：$2$1')).replace(/^冷却时间：/,'冷却：').replace(/^特性：/,'效果：')
    .replace(/[-－]\s*\[敌·(?:物抗|魔抗|物防|魔防)\s*[*×]\s*[\d.]+\](?:\s*[*×]\s*\[[^\]]*\])*/g,'').replace(/[-－]\s*敌·(?:物抗|魔抗|物防|魔防)(?:\s*[*×]\s*[\d.]+)?/g,'').replace(/\(\s*\)/g,'');
   if(ordinaryUnlockText(text)||/^(?:装备限制|冷却)[：:]无$/.test(text)||seen[text])return;seen[text]=true;
   var s=row.slice();s[2]='rgba(235,240,247,1)';s[3]=false;s[4]=0;
   if(helpInfo(text)){s[0]='\\c[0]'+text.replace(/([\u4e00-\u9fff])[:]/g,'$1：');info.push(s);}else if(helpFormula(text)){s[0]='\\c[5]'+text;formula.push(s);}
   else if(helpGrowth(text)){s[0]='\\c[3]'+text;growth.push(s);}else{s[0]='\\c[1]'+text;effects.push(s);}
  });
  var priority=['伤害属性','目标','伤害类型','命中','暴击','段数','冷却','准备时间'],basic=[],other=[];
  elementRows.concat(info).forEach(function(row){var label=plainHelpText(row[0]).split('：')[0],rank=priority.indexOf(label);(rank<0?other:basic).push({row:row,rank:rank});});
  basic.sort(function(a,b){return a.rank-b.rank;});info=basic.concat(other).map(function(r){return r.row;});
  var body=formula.concat(info,effects,growth),sizes={};body.forEach(function(r){sizes[r[1]]=(sizes[r[1]]||0)+1;});var common=Number(Object.keys(sizes).sort(function(a,b){return sizes[b]-sizes[a];})[0]);if(common)body.forEach(function(r){r[1]=common;});
  var compact=[];info.forEach(function(row){var last=compact[compact.length-1],left=last&&plainHelpText(last[0]),right=plainHelpText(row[0]);
   var pair=left&&((/^命中[：:]/.test(left)&&/^暴击[：:]/.test(right))||(/^(?:暴击|段数)[：:]/.test(left)&&/^(?:段数|冷却)[：:]/.test(right)));
   if(pair&&left.length+right.length<=28&&last[1]===row[1])last[0]+='；'+String(row[0]).replace(/^\\c\[0\]/,'');else compact.push(row.slice());});info=compact;
  var groups=[header,formula,info,effects,growth,footer].filter(function(g){return g.length;});
  groups.forEach(function(group,i){if(i<groups.length-1){var last=group[group.length-1].slice();last[3]=true;group[group.length-1]=last;}});
  var view=Object.assign({},item);view.descParams=[].concat.apply([],groups);return view;
 }
 function characterHelpView(item,options){
  if(!item||!item.descParams)return item;
  if(!characterHelpTarget(item))return item.stypeId!==undefined?genericHelpView(item):item;
  var scene=SceneManager._scene,listCosts=options&&options.listCosts;
  if(listCosts===undefined)listCosts=(typeof Scene_Battle!=='undefined'&&scene instanceof Scene_Battle)||(typeof Scene_Skill!=='undefined'&&scene instanceof Scene_Skill);
  var texts=helpNoteRows(item.note),extra={},skill=item.stypeId!==undefined,actor=characterHelpActor(item,options);
  if(window.CodexCat)item=CodexCat.helpItem(item,actor);
  texts.forEach(function(t){extra[t]=true;});
  var copy=skill&&characterHelpCopies[item.id],useCopy=copy&&JSON.stringify(texts)===JSON.stringify(copy.source);
  var header=[],info=[],effects=[],growth=[],formula=[],footer=[],authored=[],seen={},elementRows=[];
  var hasAuthoredCost=texts.some(helpResourceCost),hasActualSegments=texts.some(function(t){return /^实际段数[：:]/.test(t);});
  function keep(text){
   if(!text||ordinaryUnlockText(text)||/^(?:装备限制|冷却(?:时间)?)[：:]无$/.test(text))return false;
   // 【Codex·未经Claude检验】F004：旧帮助副本和动态新增行也遵守不显示解锁前提的约定。
   if(/^(?:人物等级解锁|解锁等级|解锁(?:条件)?)[：:]/.test(text))return false;
   if(/^条件[：:]/.test(text)&&/(?:\d+级|进阶)/.test(text))return false;
   if(/^(?:生效)?条件[：:]已(?:学会|习得)本被动$/.test(text)||/^条件[：:]完成第?[一二三四五六七八九十\d]+次?进阶$/.test(text))return false;
   if(skill&&helpResourceCost(text)&&(listCosts||/^(?:基础)?消耗[：:]0MP[／/]0TP$/.test(text)))return false;
   return true;
  }
  item.descParams.forEach(function(row){
   var text=plainHelpText(row[0]);
   if(extra[text]){authored.push(row);return;}
   // New-character summaries repeat the full mechanics immediately below.
   if(skill&&row[0]===item.description)return;
   if(row[0]===item.name||row[0]===item.description||/^品质[：:]/.test(text)){header.push(row);return;}
   if(/^(?:伤害属性|攻击属性|触发攻击属性)[：:]/.test(text)){var er=row.slice();er[0]='\\c[0]'+String(row[0]).replace(/^(?:\\c\[\d+\])+/i,'');er[2]='rgba(235,240,247,1)';er[3]=false;er[4]=0;elementRows.push(er);return;}
   if(/^(?:购买价格|出售价格|无法出售)/.test(text)){footer.push(row);return;}
   if(/^(?:MP消耗|TP消耗)[：:]/.test(text)){
    if(listCosts||hasAuthoredCost)return;
    text=compactHelpText(text).replace(/^(MP|TP)消耗：/,'基础$1消耗：');
   }
   if(/^(?:MP消耗|TP消耗|基础MP消耗|基础TP消耗|分类|咒具熟练)[：:]|^(?:当前咒具|切换至此咒具)/.test(text)||/^(?:特效|效果)[：:]/.test(text)){
    var dynamic=row.slice();dynamic[0]=text;authored.push(dynamic);
   }else if(text)header.push(row);
  });
  if(useCopy&&authored.length){
   var nativeRows=authored.filter(function(row){return !extra[plainHelpText(row[0])];}),prototype=authored.filter(function(row){return extra[plainHelpText(row[0])];})[0]||authored[0];
   authored=copy.rows.map(function(text){var row=prototype.slice();row[0]=text;row[3]=false;row[4]=0;return row;}).concat(nativeRows);
  }
  var joined=[];
  authored.forEach(function(row){
   var raw=plainHelpText(row[0]),text=compactHelpText(raw),last=joined[joined.length-1];
   if(hasActualSegments&&/^攻击次数[：:]/.test(raw))return;
   if(/^实际段数[：:]/.test(raw)&&texts.some(function(t){return /^攻击次数[：:]/.test(t)&&/追加伤害另计/.test(t);}))text+='（追加伤害另计）';
   text=currentHelpText(text,item,actor);
   if(!text||!keep(text))return;
   if(/^消耗[：:]\s*(?:自己)?[一二三四五六七八九十\d]+次?/.test(text)&&/行动/.test(text))text=text.replace(/^消耗[：:]/,'代价：');
   if(last&&/^[＋+×－−-]/.test(text)&&/^(?:伤害|每段(?:基础)?|基础伤害|基式)[：:=＝]/.test(last[0])){last[0]+=text;return;}
   if(last&&/^[＋+×－−-]/.test(last[0])&&/^(?:伤害|每段(?:基础)?|基础伤害|基式)[：:=＝]/.test(text)){text+=last[0];joined.pop();}
   var next=row.slice();next[0]=text;next[3]=false;next[4]=0;joined.push(next);
  });
  joined.forEach(function(row){
   var text=row[0];if(seen[text])return;seen[text]=true;
   var styled=row.slice();styled[2]='rgba(235,240,247,1)';
   if(/^专属[：:]/.test(text)){styled[0]='\\c[2]'+text;header.push(styled);}
   else if(helpInfo(text)){styled[0]='\\c[0]'+text.replace(/([\u4e00-\u9fff])[:]/g,'$1：');info.push(styled);}
   else if(helpFormula(text)){styled[0]='\\c[5]'+text;formula.push(styled);}
   else if(helpGrowth(text)){
    if(!/^(?:成长|每级|法宝每级|星魂预览|升级)/.test(text))text='成长：'+text;
    styled[0]='\\c[3]'+text;growth.push(styled);
   }else{styled[0]='\\c[1]'+text;effects.push(styled);}
  });
  if(actor&&!actor._characterHelpPreview&&actor.actorId()===167&&Number(item.id)===10137&&window.CodexRaven&&CodexRaven.growthRate){var gtxt='成长：冥河成长倍率×'+helpNumber(CodexRaven.growthRate(actor));if(!seen[gtxt]){seen[gtxt]=true;var gp=(growth[0]||effects[0]||info[0]||header[0]).slice();gp[0]='\\c[3]'+gtxt;gp[2]='rgba(235,240,247,1)';gp[3]=false;gp[4]=0;growth.push(gp);}}
  helpRankChanges(item,actor).forEach(function(text){if(seen[text])return;seen[text]=true;var proto=(effects[0]||info[0]||header[0]||[text,14,'rgba(235,240,247,1)',false,0]).slice();proto[0]='\\c[1]'+text;proto[2]='rgba(235,240,247,1)';proto[3]=false;proto[4]=0;effects.push(proto);});
  var sizeRow=info[0]||formula[0]||effects[0];if(sizeRow)elementRows.forEach(function(r){r[1]=sizeRow[1];});info=elementRows.concat(info);
  // Put adjacent basic fields together even when note insertion reverses their order.
  var priority=['目标','伤害类型','伤害属性','命中','暴击','段数','冷却','准备时间'];
  var basic=[],other=[];
  info.forEach(function(row){var label=plainHelpText(row[0]).split('：')[0],rank=priority.indexOf(label);(rank<0?other:basic).push({row:row,rank:rank});});
  basic.sort(function(a,b){return a.rank-b.rank;});info=basic.concat(other).map(function(r){return r.row;});
  var compactInfo=[];
  info.forEach(function(row){
   var last=compactInfo[compactInfo.length-1],left=last&&plainHelpText(last[0]),right=plainHelpText(row[0]);
   var pair=left&&((/^目标[：:]/.test(left)&&/^伤害(?:属性|类型)[：:]/.test(right))||
    (/^命中[：:]/.test(left)&&/^暴击[：:]/.test(right))||
    (/^(?:暴击|段数)[：:]/.test(left)&&/^(?:段数|冷却)[：:]/.test(right)));
   if(pair&&left.length+right.length<=28&&last[1]===row[1])last[0]+='；'+String(row[0]).replace(/^\\c\[0\]/,'');
   else compactInfo.push(row.slice());
  });
  var groups=[header,formula,compactInfo,effects,growth,footer].filter(function(g){return g.length;});
  groups.forEach(function(group,i){if(i<groups.length-1){var last=group[group.length-1].slice();last[3]=true;group[group.length-1]=last;}});
  var view=Object.assign({},item);view.descParams=[].concat.apply([],groups);return view;
 }
 // 谷雨／屠苏／璇的「成长：」行只显示当前数值，按技能所属角色（不是正在查看的持武者／宿主）的等级计算。
 function growthOwner(item,options){
  var n=String(item&&item.note||''),id=/<CodexTusu:/.test(n)?176:/<CodexXuan:/.test(n)?177:/<GuyuSkill:/.test(n)?175:0;if(!id)return null;
  var context=characterHelpActor(item,options);
  if(context&&context.actorId()===id)return context;
  var a=window.$gameActors&&$gameActors._data&&$gameActors._data[id];
  return a||{level:Number($dataActors[id]&&$dataActors[id].initialLevel||1),_AdvancedNum:0,isLearnedSkill:function(){return false;}};
 }
 function nowGrowthRows(item,options){
  if(window.CodexDemonCrown&&CodexDemonCrown.isGear(item))return ["成长：八项全属性＋"+Math.round(CodexDemonCrown.bonus(item))+"%"];
  var B=window.CodexBinding,a=growthOwner(item,options);if(!B||!a)return null;
  var lv=Number(a.level)||1,rank=Math.max(0,Math.min(5,Number(a._AdvancedNum)||0));
  var c=function(v,l){return B.curve(a,v,l);},pct=function(n){return helpNumber(Math.round(n*1000)/10)+'%';},x=function(n){return helpNumber(Math.round(n*100)/100);};
  var W7=[[.1,.2,.35,.5,.65,.8,1],[1,10,20,30,40,50,60]],w=c(W7[0],W7[1]);
  var coef=function(M,k){return M&&M.coefficient?M.coefficient(k,a):0;};
  var tusu={10312:'zhanfeng',10313:'hengsao',10314:'dianshe',10315:'guanri',10317:'chiling',10318:'zhenji',10319:'jianqi',10323:'zhenhun',10324:'body_phys',10325:'body_mag'}[item.id];
  if(tusu)return ['成长：伤害系数'+coef(window.CodexTusu,tusu)];
  var lock='锁定倍率×'+x(c([1.3,1.5],[20,60])),heming='和鸣倍率×'+x(c([1.2,1.5],[20,60])),huzhen='护阵倍率×'+x(c([.85,.70],[20,60]));
  var hg='回光系数'+x(c([10,20],[1,60])),hgf=pct(c([.20,.35],[1,60])),lbf=pct(c([.15,.35],[1,60])),gs='双防共享比例'+pct(window.CodexXuan?CodexXuan.gongsuDefenseRate(a):0),offense='直接伤害提高'+pct(window.CodexXuan?CodexXuan.gongsuDamageRate(a):0);
  var shadow='成长：星影人数'+(lv>=60?'全部队友':lv>=50?'3名':lv>=40?'2名':lv>=30?'1名':'0名');
  // 五兵淬纹（屠苏）、星盾流转（璇）：由法宝词条改成的成长被动，按所属角色当前等级显示。
  var passive=(String(item.note||'').match(/<Codex(?:Tusu|Xuan):\s*(passive\.(?:temper|relay))\s*>/)||[])[1];
  if(passive==='passive.temper'&&window.CodexTusu&&CodexTusu.temperRate){var tr=function(k){return '×'+x(CodexTusu.temperRate(a,k));};
   return ['成长：剑气纵横伤害'+tr('support.jianqi'),'成长：横扫、点射、贯日伤害'+tr('arm.hengsao'),'成长：金汤护盾量、敕令伤害'+tr('support.jintang'),'成长：震击、镇魂重击伤害'+tr('arm.zhenji')];}
  if(passive==='passive.relay')return ['成长：接力比例'+pct(lv>=60?.3:lv>=20?.2:0)];
  switch(Number(item.id)){
   // 借一枝春色、先许一枝开（谷雨成长被动，不需要装备法宝）：按谷雨当前等级。
   case 10290:return [lv>=10?'成长：转移比例可选25%／50%／75%':'成长：转移比例50%'];
   case 10298:return ['成长：待绽比例'+(lv>=60?'50%':'35%')+'；花荫倍率×'+(lv>=60?'1.2':lv>=20?'1.1':'1')];
   case 10288:return ['成长：治疗比例'+pct(c([.25,.30,.35,.40],[1,20,40,60]))];
   case 10293:return ['成长：队友储备比例'+pct(c([1,1.25,1.5,1.75],[1,20,40,60])+.15*rank),'成长：绽放系数'+x(c([5,6,7,8],[1,20,40,60]))];
   case 10292:return ['成长：归春系数'+x(c([33,50],[40,60]))];
   case 10316:return ['成长：'+huzhen];
   case 10320:return ['成长：'+lock];
   case 10321:return ['成长：成长权重'+pct(w)+'；保底比例'+pct(c([.1,.3],[1,60]))];
   case 10322:return ['成长：'+heming];
   case 10358:return ['成长：成长权重'+pct(w)];
   case 10359:return ['成长：'+lock+'；'+heming,'成长：'+huzhen,'成长：挫势－'+pct(1-c([.90,.80],[20,60]))+'（霸体目标－'+pct(1-c([.85,.70],[20,60]))+'）','成长：横扫对后续目标增伤'+pct(c([1,1.2],[20,60])-1)];
   case 10360:return ['成长：额外提高'+pct(lv>=40?c([1,1.2],[40,60])-1:0)];
   case 10335:return ['成长：'+hg+'；保底比例'+hgf];
   case 10336:return ['成长：成长权重'+pct(w)+'；保底比例'+lbf];
   case 10337:return ['成长：伤害系数'+coef(window.CodexXuan,'lengguang')];
   case 10338:case 10363:return [shadow];
   case 10339:return ['成长：'+gs,'成长：'+offense];
   case 10361:return ['成长：'+hg+'；回光保底比例'+hgf,'成长：璃壁成长权重'+pct(w)+'；璃壁保底比例'+lbf];
   case 10362:return ['成长：'+gs.replace('双防共享比例','共宿比例')+'；额外默契'+(lv>=20?Math.floor(c([1,3],[20,60])):0)+'点'];
  }
  return null;
 }
 function nowGrowthView(item,view,options){
  var rows=view&&view.descParams&&nowGrowthRows(item,options);if(!rows)return view;
  var out=[],old=[];view.descParams.forEach(function(r){if(/^成长[：:]/.test(plainHelpText(r[0])))old.push(r);});
  if(!old.length)return view;var line=old[old.length-1][3];
  view.descParams.forEach(function(r){
   if(r!==old[0]&&old.indexOf(r)>=0)return;
   if(r!==old[0]){out.push(r);return;}
   rows.forEach(function(text,k){var v=r.slice();v[0]='\\c[3]'+text;v[3]=k===rows.length-1?line:false;out.push(v);});
  });
  var copy=Object.assign({},view);copy.descParams=out;return copy;
 }
 var characterHelpViewBase=characterHelpView;
 characterHelpView=function(item,options){return nowGrowthView(item,characterHelpViewBase(item,options),options);};
 var DYN2_IDS=[10122, 10123, 10124, 10125, 10126, 10127, 10128, 10129, 10130, 10131, 10132, 10133, 10134, 10135, 10136, 10137, 10138, 10139, 10140, 10141, 10142, 10143, 10144, 10145, 10146, 10147, 10148, 10149, 10150, 10151, 10152, 10153, 10154, 10155, 10156, 10157, 10158, 10159, 10160, 10161, 10162, 10163, 10164, 10165, 10166, 10167, 10170, 10171, 10172, 10173, 10174, 10175, 10176, 10177, 10178, 10179, 10180, 10181, 10182, 10183, 10184, 10185, 10186, 10187, 10188, 10189, 10190, 10191, 10192, 10193, 10194, 10195, 10196, 10200, 10201, 10202, 10203, 10204, 10205, 10206, 10207, 10208, 10209, 10210, 10211, 10212, 10213, 10214, 10215, 10216, 10217, 10218, 10219, 10220, 10221, 10222, 10223, 10224, 10225, 10226, 10229, 10230, 10231, 10232, 10233, 10234, 10235, 10236, 10237, 10238, 10239, 10240, 10241, 10242, 10243, 10244, 10245, 10246, 10247, 10248, 10249, 10250, 10251, 10252, 10253, 10254, 10255, 10256, 10257, 10258, 10259, 10260, 10261, 10262, 10263, 10264, 10265, 10266, 10267, 10268, 10269, 10270, 10271, 10272, 10273, 10274, 10275, 10276, 10277, 10278, 10279, 10280, 10281, 10282, 10283, 10284, 10285, 10286, 10287];
 // 第二批（渡鸦～云裳）：说明行按「前缀」换成当前数值；这些技能不再走旧的逐角色改写。
 var DYN2_SKIP={};DYN2_IDS.forEach(function(i){DYN2_SKIP[i]=true;});
 function dyn2(item,a){
  var id=Number(item.id),who=a&&a.actorId?a.actorId():0,lv=Number(a&&(a.level||a._level))||1,rank=Number(a&&a._AdvancedNum)||0,out={};
  var n2=function(v){return helpNumber(Math.round(Number(v)*100)/100);},pc=function(v){return helpNumber(Math.round(Number(v)*10)/10)+'%';};
  var learned=function(i){return helpLearned(a,i);};
  var R=window.CodexRaven,M=window.CodexMira,J=window.CodexJingliu,TJ=window.CodexToji,S=window.CodexSukuna,G=window.CodexGarou,Y=window.CodexYunshang;
  if(who===167&&R){
   var st=Math.max(0,Math.min(5,Number(a._codexRavenStage||0))),soul=Number(a._codexRavenSoul||0),p=Math.min(1,Math.max(0,soul/150000));
   var has=function(i){var g=R.SKILL_GATE[i]||[1,0];return learned(i)&&lv>=g[0]&&st>=g[1];};
   if(id>=10122&&id<=10126)out['成长：魄倍率']='成长：魄倍率'+n2(R.legionStrikeRate(a))+'；阶位系数'+n2(R.skillCoefficient(a,id));
   if(id===10128||id===10135)out['成长：下一阶门槛']=st<5?'成长：下一阶门槛'+R.REQUIRE[st+1]+'灵魂（已有'+Math.floor(soul)+'）':'成长：已完成五阶';
   if(id===10130)out['成长：魔防穿透率']='成长：魔防穿透率'+pc((1-R.defenseFactor(a))*100);
   if(id===10131)out['成长：专属黑暗']='成长：专属黑暗魔法伤害＋'+pc(has(id)?200+p*100:0)+'；专属魔法最终伤害×'+n2(has(id)?1+1.5*Math.min(1,(st+p)/5):1);
   if(id===10137){var gp=learned(id)?R.growthPools(a):{critical:0,final:0};out['成长：爆伤']='成长：爆伤＋'+pc(gp.critical)+'；终伤＋'+pc(gp.final);
    out['成长：专属魔法暴击率']='成长：专属魔法暴击率＋'+pc(learned(id)?p*1000:0);out['成长：冥河成长倍率']='成长：冥河成长倍率×'+n2(R.growthRate(a));}
   if(id===10138)out['成长：魄倍率']='成长：魄倍率'+n2(R.legionStrikeRate(a));
   if(id===10139)out['成长：冠冕倍率']='成长：冠冕倍率×'+n2(R.crownRate(a));
  }
  if(who===168){
   var dragon=!!($gameParty&&$gameParty.inBattle()&&rank>=3&&learned(10161)&&a.isStateAffected&&a.isStateAffected(2592));
   if(id===10144)out['成长：人形物防']='成长：人形物防、魔防×'+n2(!dragon&&lv>=30&&learned(id)?1.25*(1+.25*Math.min(1,(lv-30)/5)):1);
   if(id===10145)out['成长：人形速度']='成长：人形速度×'+n2(!dragon&&lv>=40&&learned(id)?1.1*(1+.25*Math.min(1,(lv-40)/5)):1);
   if(id===10156){var on=learned(id),dmg=lv>=60?2:lv>=50?1.8+.02*(lv-50):lv>=15?1.66+.14*(lv-15)/35:1.15+.051*Math.max(0,lv-5);
    var cr=lv<5?0:lv<=15?.15+.08*(lv-5):.95+7.93*Math.min(1,(lv-15)/55);
    out['成长：共鸣倍率']='成长：共鸣倍率×'+n2(on&&!dragon&&lv>=5?dmg:1)+'；暴击率＋'+pc(on?cr*100:0);}
  }
  if(who===169&&id>=10171&&id<=10174){var seg=(id===10174?6:2)+Math.min(6,Math.floor(Number(a.luk||0)/6666));out['段数：']='段数：'+seg+'（幸运每6666点＋1段，最多＋6）';}
  if(who===170){
   if(id===10194&&J&&J.visibleSoulRows){var rows=J.visibleSoulRows(a).map(function(t){return String(t).split('：').pop();});out['成长：已解锁星魂']='成长：已解锁星魂：'+(rows.length?rows.join('；'):'无');}
   if(id===10196)out['成长：寒川映月上限']='成长：寒川映月上限×'+(learned(10202)?'2.5':'1.8');
  }
  if(who===171&&TJ){
   if(id===10205){out['成长：最大生命']='成长：最大生命＋'+pc(lv*10)+'；物攻、速度＋'+pc(lv*5);out['成长：暴击率']='成长：暴击率＋'+pc(lv*10)+'；爆伤、终伤＋'+pc(lv*40);}
   if(id===10205||id===10211||(id>=10216&&id<=10223))out['成长：咒具成长系数']='成长：咒具成长系数×'+helpNumber(Math.round(TJ.outputGrowth(a,id===10205||(id>=10216&&id<=10219))*1000)/1000);
  }
  if(who===172&&S){
   if([10239,10247,10248,10249].indexOf(id)>=0)out['成长：术式威力']='成长：术式威力'+S.coefficient(a);
   if(id===10242){var emp=a._codexSukuna&&a._codexSukuna.emp||0,awake=a.isStateAffected&&a.isStateAffected(2639),dom=a._codexSukuna&&a._codexSukuna.domain>0&&a.isStateAffected&&a.isStateAffected(2636);
    out['成长：斩击强化']=emp&&awake?'成长：斩击强化：下一次斩击＋'+pc(((dom?.35:.2)+(emp-1)*.05)*100):'成长：斩击强化：未储存';}
  }
  if(who===173&&G&&G.form){
   var f=G.form(a),ps=f.passives||{};
   if(id>=10250&&id<=10263)out['成长：形态系数']='成长：形态系数'+f.damage_scale;
   if(id===10266)out['成长：每层进化']='成长：每层进化伤害＋'+(ps.evolution_enabled?ps.evolution_base_per_stack_percent:0)+'%';
   if(id===10267)out['成长：每层无视']='成长：每层无视物防'+(ps.analysis_defense_ignore_percent_per_stack||0)+'%'+(ps.analysis_magic_defense_ignore_percent_per_stack?'、魔防'+ps.analysis_magic_defense_ignore_percent_per_stack+'%（最多99%）':'');
   if(id===10269)out['成长：当前形态']='成长：当前形态：'+f.name+(f.actions_per_round>1?'；每回合行动'+f.actions_per_round+'次':'');
  }
  if(who===174&&Y){
   var C=Y.config,yh=function(i){var g=C.gates[i]||[1,0];return learned(i)&&lv>=g[0]&&rank>=g[1];};
   if([10270,10271,10274].indexOf(id)>=0){out['目标：']='目标：'+(yh(10276)?'敌方全体':'敌方单体');out['段数：']='段数：'+(yh(10277)?2:1);}
   var mul=lv>=50&&rank>=2?4:lv>=40&&rank>=1?3:lv>=35&&rank>=1?2.5:lv>=30?2:lv>=25?1.5:1;
   if(id>=10276&&id<=10281&&id!==10280){var t='成长：生命、魔攻、敏捷成长×'+mul;
    if(id===10276){var og=yh(10276)?Y.offensiveGrowth(a):{crit:0,final:0};t+='；爆伤＋'+pc(og.crit*100)+'；终伤＋'+pc(og.final*100);}
    out['成长：生命、魔攻、敏捷成长']=t;}
  }
  return out;
 }
 function dyn2View(item,view){
  if(!view||!view.descParams||!DYN2_SKIP[Number(item&&item.id)])return view;
  var map;try{map=dyn2(item,characterHelpActor(item));}catch(e){return view;}
  var keys=Object.keys(map);if(!keys.length)return view;
  var copy=Object.assign({},view);
  // 同一行可能并排两个字段（如「目标：…；伤害属性：…」），只换以该前缀开头的那一段。
  copy.descParams=view.descParams.map(function(r){var raw=String(r[0]||''),plain=plainHelpText(raw),done=false,color=(raw.match(/^(?:\\c\[\d+\])+/i)||[''])[0];
   var whole=keys.filter(function(k){return /^成长/.test(k)&&plain.indexOf(k)===0;})[0];
   if(whole){var w=r.slice();w[0]=color+map[whole];return w;}
   var parts=plain.split('；').map(function(part){var hit=null;keys.forEach(function(k){if(!hit&&part.indexOf(k)===0)hit=k;});if(!hit)return part;done=true;return map[hit];});
   if(!done)return r;var row=r.slice();row[0]=color+parts.join('；');return row;});
  return copy;
 }
 var characterHelpViewP1=characterHelpView;
 characterHelpView=function(item,options){return dyn2View(item,characterHelpViewP1(item,options));};
 // 停用技能（<CodexRetired>）：仍保留在角色身上（旧档与标记兼容），技能列表不显示。
 var nativeSkillListIncludes=Window_SkillList.prototype.includes;
 Window_SkillList.prototype.includes=function(item){if(item&&item.meta&&item.meta.CodexRetired)return false;return nativeSkillListIncludes.apply(this,arguments);};
 var terminologyView=characterHelpView;
 characterHelpView=function(item,options){var view=terminologyView(item,options);if(!view||!view.descParams)return view;var copy=Object.assign({},view);copy.descParams=view.descParams.map(function(row){var result=row.slice();result[0]=D.text(result[0]);return result;});D.equipmentRows(copy);return copy;};
 D.characterHelpView=characterHelpView;
 // 【Codex·未经Claude检验】v0.43 display views only: scan metadata first, preserve every mechanical effect and original colors.
 D.readableView=function(item){
  if(!item||!Array.isArray(item.descParams)||item._codexReadable43||item.stypeId===undefined&&item.wtypeId===undefined&&item.atypeId===undefined)return item;
  var skill=item.stypeId!==undefined,head=[],intro=[],meta=[],stats=[],effects=[],growth=[],conditions=[],footer=[],seenMeta={};
  function plain(t){return String(t==null?'':t).replace(/\\c\[\d+\]/gi,'').replace(/\x1bc\[\d+\]/gi,'').trim();}
  function white(r){return !/\\c\[[1-9]\d*\]|\x1bc\[[1-9]\d*\]/i.test(r[0])&&/^(?:#fff(?:fff)?|white|rgba?\(255,255,255(?:,1)?\))$/.test(String(r[2]||'#ffffff').replace(/\s/g,'').toLowerCase());}
  item.descParams.forEach(function(source,index){
   if(!Array.isArray(source))return;var r=source.slice(),t=plain(r[0]);if(!t)return;r[1]=index===0?Math.min(26,Number(r[1])||24):20;r[3]=false;r[4]=index===0?1:0;
   if(index>0&&r[0]===item.description){intro.push(r);return;}
   if(index===0||r[0]===item.name||/^品质[：:]/.test(t)){head.push(r);return;}
   if(/^(?:购买价格|出售价格|无法出售)/.test(t)){footer.push(r);return;}
   if(skill&&/^(?:目标|对象|伤害属性|攻击属性|伤害类型|命中|暴击|段数|冷却(?:时间)?|准备时间|消耗|MP消耗|TP消耗)[：:]/.test(t)){if(!seenMeta[t])meta.push(r);seenMeta[t]=true;return;}
   if(!skill&&/^(?:装备类型|武器类型|防具类型|装备位置|装备限制|等级需求|专属角色|使用角色)[：:]/.test(t)){conditions.push(r);return;}
   if(!skill&&white(r)&&/^(?:最大生命值|最大魔法值|生命值|魔法值|物理攻击力?|魔法攻击力?|攻击力|防御力|魔法防御|敏捷|幸运|命中率?|暴击(?:率|伤害)?|反击率?|闪避率?|魔法闪避率?|攻击速度|全属性(?:伤害)?|全闪避|暴击闪避率?|魔法反射率?|魔法反击率?|物理魔法闪避|爆闪|爆伤|攻击次数|(?:物|魔|火|冰|雷|暗|光|水|土|风|毒)伤|每级全属性|进化后每级全属性)[：:＋+－\-\d、， ,/]/.test(t)){stats.push(r);return;}
   if(skill&&/^成长[：:]/.test(t)){growth.push(r);return;}effects.push(r);
  });
  function pairs(rows){var out=[];rows.forEach(function(r){var last=out[out.length-1],a=last&&plain(last[0]),b=plain(r[0]);if(last&&last[2]===r[2]&&a.indexOf('　')<0&&a.length+b.length<=26&&!/[\n\r]|\\[iIvVnN]\[/.test(last[0]+r[0]))last[0]+='　'+r[0];else out.push(r.slice());});return out;}
  function group(label,rows){if(!rows.length)return [];return [[label,20,'#ffe499',false,0]].concat(rows);}
  var rows=head.concat(skill?group('施放信息',pairs(meta)):group('基础属性',pairs(stats)),group(skill?'伤害与效果':'装备特效',effects),group('当前成长',growth),group('装备条件',conditions),group('补充说明',intro),group('价格信息',pairs(footer))),view=Object.assign({},item);
  view.descParams=rows;view._codexReadable43=true;return view;
 };
 if(typeof Sprite_ItemHelp!=='undefined'){
  ['getTextHeight','drawContents'].forEach(function(method){
   var nativeMethod=Sprite_ItemHelp.prototype[method];
   Sprite_ItemHelp.prototype[method]=function(){
    var original=this.item;this.item=D.readableView(characterHelpView(original));
    try{return nativeMethod.apply(this,arguments);}finally{this.item=original;}
   };
  });
  // Position against the visible game area after the new item's height is known.
  var nativeHelpSetItem=Sprite_ItemHelp.prototype.setItem;
  Sprite_ItemHelp.prototype.setItem=function(item){
   var za=typeof characterHelpActor==='function'?characterHelpActor(item):null;if(window.CodexZhenqi&&za){var zv=CodexZhenqi.skillView(item,za);if(zv!==item&&!zv.descParams&&window.RJO&&RJO.HE)RJO.HE.getDescParams(zv,3);item=zv;}
   var out=nativeHelpSetItem.call(this,item);
   if(characterHelpTarget(item)&&!this._isExtra&&this.visible){
    this.x=Math.max(12,Math.min(this.x,Graphics.boxWidth-this.width-12));
    this.y=Math.max(12,Math.min(this.y,Graphics.boxHeight-this.height-12));this.updateGlowPos();
   }
   this._codexCharacterHelpStamp=characterHelpStamp(item);return out;
  };
  var nativeHelpUpdate=Sprite_ItemHelp.prototype.update;
  Sprite_ItemHelp.prototype.update=function(){
   nativeHelpUpdate.apply(this,arguments);
   if(this.visible&&characterHelpTarget(this.item)&&Graphics.frameCount%12===0){
    var stamp=characterHelpStamp(this.item);if(stamp!==this._codexCharacterHelpStamp){
     var x=this.x,y=this.y;this.setItem(this.item);this.x=x;this.y=Math.max(12,Math.min(y,Graphics.boxHeight-this.height-12));this.updateGlowPos();
    }
   }
  };
 }

 // Keep frequent actions together and preserve all original command handlers/ext IDs.
 var nativeMenuList=Window_MenuCommand.prototype.makeCommandList;
 Window_MenuCommand.prototype.makeCommandList=function(){
  nativeMenuList.apply(this,arguments);
  // 2026-10-10：按用途分四组——角色养成、强化系统、图鉴收集、存档与设置；未列出的新命令排在图鉴之后、存档之前。
  var order=['物品','技能','装备','状态','真气','整队','种族祝福','宠物','制作','宝珠坊','异化工坊','人物图鉴','怪物图鉴','成就'];
  function rank(command){
   var i=order.indexOf(command.name);if(i>=0)return i;
   if(command.name==='存档'||command.symbol==='save')return 20;
   if(command.symbol==='options')return 23;
   if(command.symbol==='codexGM')return 24;
   if(command.symbol==='gameEnd')return 25;
   return 15;
  }
  this._list=this._list.filter(function(c){return c.name!=='天赋学习'&&c.symbol!=='codexCombatPower'&&c.symbol!=='codexEquipmentQuery'&&c.symbol!=='codexCostumes'&&c.name!=='队列跟随';})
   .map(function(c,i){return {command:c,index:i};}).sort(function(a,b){return rank(a.command)-rank(b.command)||a.index-b.index;})
   .map(function(row){return row.command;});
 };

 // 2026-10-10：「队列跟随」「角色换装」从主菜单移到设置（角色换装原本就在设置里）。
 // 队列跟随沿用原公共事件 4「集合」：变量 24 为 0＝伙伴跟随，1＝不跟随；随存档保存，标题画面不可改。
 function followInGame(){return !!($gameMap&&$gameMap.mapId()>0&&$gameVariables&&$gamePlayer);}
 var followList=Window_Options.prototype.makeCommandList,followStatus=Window_Options.prototype.statusText,
  followGet=Window_Options.prototype.getConfigValue,followSet=Window_Options.prototype.setConfigValue;
 Window_Options.prototype.makeCommandList=function(){followList.apply(this,arguments);this.addCommand('队列跟随','codexFollow',followInGame());};
 Window_Options.prototype.statusText=function(i){if(this.commandSymbol(i)==='codexFollow'&&!followInGame())return '进入游戏';return followStatus.apply(this,arguments);};
 Window_Options.prototype.getConfigValue=function(symbol){if(symbol==='codexFollow')return followInGame()&&$gameVariables.value(24)===0;return followGet.apply(this,arguments);};
 Window_Options.prototype.setConfigValue=function(symbol,value){
  if(symbol!=='codexFollow')return followSet.apply(this,arguments);
  if(!followInGame())return;
  $gameVariables.setValue(24,value?0:1);if(value)$gamePlayer.showFollowers();else $gamePlayer.hideFollowers();$gamePlayer.refresh();};
 ['cursorLeft','cursorRight'].forEach(function(k){var old=Window_Options.prototype[k];Window_Options.prototype[k]=function(){if(this.commandSymbol(this.index())==='codexFollow'&&!followInGame())return;return old.apply(this,arguments);};});
 // 主菜单右侧角色栏一页 5 人（原 4 人）：每格约 138 像素，四行状态行距 36→33；选物品/技能对象的窗口不变。
 var menuRows=Window_MenuStatus.prototype.numVisibleRows,menuLine=Window_MenuStatus.prototype.lineHeight;
 Window_MenuStatus.prototype.numVisibleRows=function(){return this instanceof Window_MenuActor?menuRows.apply(this,arguments):5;};
 Window_MenuStatus.prototype.lineHeight=function(){return this instanceof Window_MenuActor?menuLine.apply(this,arguments):33;};

 // Star_Designation calls Bitmap.drawIcon(icon,x,y,scale), while the later
 // KDCore extension replaces it with (x,y,icon,size). Route self-owned title
 // canvases explicitly and preserve KDCore's convention everywhere else.
 var kdBitmapIcon=Bitmap.prototype.drawIcon;
 Bitmap.prototype.drawIcon=function(icon,x,y,scale){
  if(this.contents!==this)return kdBitmapIcon.apply(this,arguments);
  var bitmap=this,atlas=ImageManager.loadSystem('IconSet'),size=32*(Number(scale)||1);
  var key=x+','+y,token={icon:icon};
  this._codexDesignationDraws=this._codexDesignationDraws||{};this._codexDesignationDraws[key]=token;
  function paint(){
   if(bitmap._codexDesignationDraws[key]!==token)return;
   var overlays=icon>=6000&&$gameSystem.overlayIcons&&$gameSystem.overlayIcons[icon-6000];
   (overlays?overlays.map(function(row){return row.index;}):[icon]).forEach(function(id){
    if(id<=0)return;var smooth=bitmap._context.imageSmoothingEnabled;bitmap._context.imageSmoothingEnabled=false;
    try{bitmap.blt(atlas,id%16*32,Math.floor(id/16)*32,32,32,x+16,y,size,size);}finally{bitmap._context.imageSmoothingEnabled=smooth;}
   });
  }
  if(atlas.isReady())paint();else atlas.addLoadListener(paint);
 };
 // Offline Mac play must display the already selected title independently of
 // the optional online same-screen plugin. Do not alter unlocks or selection.
 var updateCharacter=Sprite_Character.prototype.update;
 Sprite_Character.prototype.update=function(){
  updateCharacter.apply(this,arguments);
  if(this._character!==$gamePlayer||this._nameSpriteOL)return;
  var name=String($gamePlayer.DesignationName||''),icon=Number($gamePlayer.DesignationIcon)||0;
  if(!name&&!icon){if(this._codexDesignation)this._codexDesignation.visible=false;return;}
  var label=this._codexDesignation;
  if(!label){
   label=this._codexDesignation=new Sprite(new Bitmap(180,58));label.anchor.set(0.5,1);
   label.y=-Math.max(36,Number(PluginManager.parameters('Star_Designation').offsetY)||48);
   this.addChild(label);
  }
  label.visible=!$gamePlayer.isTransparent();
  var signature=[name,icon,$gamePlayer.DesignationColor].join('|');
  if(label._codexSignature===signature)return;label._codexSignature=signature;
  var bitmap=label.bitmap;bitmap.clear();bitmap.fontSize=16;bitmap.fontBold=false;
  bitmap.textColor=$gamePlayer.DesignationColor||'#ffffff';bitmap.drawText(name,0,32,180,24,'center');
  var atlas=ImageManager.loadSystem('IconSet');
  function paintIcon(){
   if(label._codexSignature!==signature)return;
   var indices=icon>=6000&&$gameSystem.overlayIcons&&$gameSystem.overlayIcons[icon-6000];
   (indices?indices.map(function(row){return row.index;}):[icon]).forEach(function(id){
    if(id<=0)return;var sx=id%16*32,sy=Math.floor(id/16)*32;
    bitmap.blt(atlas,sx,sy,32,32,74,0,32,32);
   });
  }
  if(atlas.isReady())paintIcon();else atlas.addLoadListener(paintIcon);
 };
});
