// 【Codex·未经Claude检验】v0.34：一线生机与天道注视统一现行弱者判定，修复旧档误领。
// Extracted from the verified native runtime; installer order is maintained by main.js.
// 【Claude·未经Codex检验】v0.44 强弱分类统一读角色备注 <KyoTier>（CodexTier），本文件不再写编号名单。
window.CodexRuntime.register("installStrongActorClassificationRuntime", function() {
  function installStrongActorClassificationRuntime() {
    var replacements={5968:5969,5970:5971,5972:5973,6235:6216};
    var weakStates=[1035,1273,1274,1276,1277,1279,1280];
    function isStrongActor(actor) {
      if (!actor || !actor.actorId) return false;
      return CodexTier.isNonWeak(actor); // 【Claude·未经Codex检验】v0.44 超强者和强者都用强者版技能
    }
    // Share the same native-roster/runtime-tag eligibility used by the weak
    // challenge; actor quality and the actor's current passives are not identity.
    var H = window.CodexHeavenGaze = { version: 'v0.34', chanceSkillId: 6212, gazeSkillId: 6213 };
    H.isWeak = function(actor) {
      if (!window.CodexWeakChallenge) throw new Error('天道注视：弱者分类尚未就绪');
      return CodexWeakChallenge.isWeak(actor);
    };
    function refreshHeaven(actor) {
      if (actor.refreshPassiveSkillCache) actor.refreshPassiveSkillCache();
      if (actor.initPassiveCache && actor.refreshPassiveCache) {
        actor.initPassiveCache(); actor.refreshPassiveCache();
      }
      actor.refresh();
    }
    H.repair = function(actor) {
      if (!actor || !actor.actor || !actor.actor() || !actor.actor().name || H.isWeak(actor) || !actor.isLearnedSkill(H.chanceSkillId)) return false;
      actor.forgetSkill(H.chanceSkillId);
      actor.learnSkill(H.gazeSkillId);
      refreshHeaven(actor);
      return true;
    };
    H.apply = function(grantWeakChance) {
      for (var id = 1; id < $dataActors.length; id++) {
        var data = $dataActors[id];
        if (!data || !data.name) continue;
        var actor = $gameActors.actor(id);
        if (H.isWeak(actor)) {
          if (grantWeakChance) actor.learnSkill(H.chanceSkillId);
        } else {
          H.repair(actor);
          actor.learnSkill(H.gazeSkillId);
        }
      }
    };
    var oldLearn=Game_Actor.prototype.learnSkill;
    Game_Actor.prototype.learnSkill=function(skillId) {
      if (Number(skillId) === H.chanceSkillId && !H.isWeak(this)) return;
      if (isStrongActor(this) && replacements[skillId]) skillId=replacements[skillId];
      return oldLearn.call(this,skillId);
    };
    var oldAddState=Game_Actor.prototype.addState;
    Game_Actor.prototype.addState=function(stateId) {
      if (isStrongActor(this) && weakStates.indexOf(stateId)>=0) return;
      return oldAddState.call(this,stateId);
    };
    function repair(actor) {
      if (!isStrongActor(actor)) return;
      var changed=false;
      Object.keys(replacements).forEach(function(id) {
        var weak=Number(id);
        if (!actor.isLearnedSkill(weak)) return;
        actor.forgetSkill(weak);
        actor.learnSkill(replacements[id]);
        changed=true;
      });
      if (changed && actor.refreshPassiveSkillCache) actor.refreshPassiveSkillCache();
      if (changed && actor.initPassiveCache && actor.refreshPassiveCache) {
        actor.initPassiveCache(); actor.refreshPassiveCache();
      }
      weakStates.forEach(function(stateId) {
        if (!actor.isStateAffected(stateId)) return;
        if (actor.removeStateCompletely) actor.removeStateCompletely(stateId);
        else actor.removeState(stateId);
        if (actor.isStateAffected(stateId)) actor.eraseState(stateId);
      });
    }
    var oldExtract=DataManager.extractSaveContents;
    DataManager.extractSaveContents=function(contents) {
      oldExtract.call(this,contents);
      var actors=$gameActors && $gameActors._data;
      if (!actors) return;
      actors.forEach(H.repair);
      actors.forEach(repair);
    };
  }

  // 道具公共事件必须正常执行；短小且无地图指令的换装卡事件可留在背包执行，
  // 其余事件在地图跑完后安全返回背包，保留菜单栈与道具选择位置。

return installStrongActorClassificationRuntime.apply(this, arguments);
});
