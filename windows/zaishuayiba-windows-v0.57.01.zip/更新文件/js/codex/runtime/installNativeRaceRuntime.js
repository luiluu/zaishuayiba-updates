// 【Codex·未经Claude检验】核查状态：未经claude检验。战斗行动菜单不强制打开种族帮助面板。
/* Seven selectable race blessings. Own-action mechanics share native damage,
   OTB turns and source shields; legacy states never run alongside this module. */
window.CodexRuntime.register('installNativeRaceRuntime', function () {
 'use strict';
 window.$dataCodexRaces=null;
 DataManager._databaseFiles.push({name:'$dataCodexRaces',src:'CodexRaces.json'});
 var R=window.CodexRaces={version:2,random:function(){return Math.random();}},roots=new WeakMap(),current=null,hit=null,derived=0,syncing=0,lastEnd=-1,serial=0,supply=null;
 function C(){return window.$dataCodexRaces;}
 function num(v){v=Number(v);return isFinite(v)?v:0;}
 function actor(a){return a&&a.isActor&&a.isActor();}
 function live(a){return a&&a.isAlive()&&a.hp>0;}
 function battle(){return !!($gameParty&&$gameParty.inBattle());}
 function turn(){return Math.max(1,$gameTroop&&$gameTroop.turnCount()||1);}
 function alias(o,k,f){var old=o[k];if(!old)return;o[k]=function(){return f.call(this,old,arguments);};}
 function tell(t){if(window.$&&$.toaster)$.toaster({message:t});}
 function allActors(){return $gameActors?$gameActors._data.filter(function(a){return a&&$dataActors[a.actorId()]&&$dataActors[a.actorId()].name;}):[];}
 function skillInfo(id){if(!C())return null;for(var r=0;r<7;r++){var n=C().skills[r].indexOf(Number(id));if(n>=0)return {race:r,rank:n+1};}return null;}
 function data(a){return actor(a)&&a._codexRace||null;}
 function rate(a){var d=data(a);return d&&d.race>=0?C().rates[d.rank-1]:0;}
 function state(a){var d=a._codexRaceBattle;if(!d||d.battle!==serial)d=a._codexRaceBattle={battle:serial,maxHp:a.mhp,godTurn:-1,bloodTurn:-1,capTurn:-1,gainTurn:-1,spendTurn:-1,echoTurn:-1,humanTurn:-1,humanExtra:false,ghostPrevious:null,ghostCurrent:null,poison:[]};return d;}
 function invalidate(a){
  a._passiveSkillCache=null;a._skillsCache=undefined;a._cacheBaseParam={};a._baseParamCache=[];a._ParamCache2=[];a._xparamCache2=[];a._sparamCache2=[];a._cacheParamBuffRate={};
  a.need_refresh_param=[1,1,1,1,1,1,1,1];a.need_refresh_xparam=[1,1,1,1,1,1,1,1,1,1];a.need_refresh_sparam=[1,1,1,1,1,1,1,1,1,1];a.need_refresh=true;a.need_refresh_states=true;a.need_refresh_basestates=true;a.need_refresh_passiveStates=true;
  a._statescache2=undefined;a._basestatecache=undefined;a._passiveStatesRaw=undefined;a._regenHprefresh=true;a._regenMprefresh=true;
  if(a.initPassiveCache)a.initPassiveCache();if(a.refreshPassiveCache)a.refreshPassiveCache();a.refresh();
 }
 function cleanupStates(a){if(!C())return;C().legacyStates.forEach(function(id){if(a._states&&a._states.indexOf(id)>=0){a._states=a._states.filter(function(n){return n!==id;});if(a._stateTurns)delete a._stateTurns[id];if(a._stateCounter)delete a._stateCounter[id];if(a._stateOrigin)delete a._stateOrigin[id];}});delete a._stackingPoison;}
 function sync(a){var d=data(a);if(!d||!C())return;syncing++;try{a._skills=(a._skills||[]).filter(function(id){return !skillInfo(id);});if(d.race>=0)a._skills.push(C().skills[d.race][d.rank-1]);a._skills.sort(function(x,y){return x-y;});cleanupStates(a);invalidate(a);}finally{syncing--;}}
 R.data=data;R.rate=rate;R.battleState=state;R.skillInfo=skillInfo;
 R.label=function(a){var d=data(a);return d&&d.race>=0?C().names[d.race]+'族祝福·'+['Ⅰ','Ⅱ','Ⅲ','Ⅳ','Ⅴ','Ⅵ','Ⅶ'][d.rank-1]+'阶':'待选择种族祝福';};
 R.effects=function(r,rank){var s=C()&&$dataSkills[C().skills[r][rank-1]];return s?s.description.split('；'):[];};
 function migrateActor(a){
  if(!actor(a)||!C()||data(a))return;
  var old=(a._skills||[]).map(skillInfo).filter(Boolean),rank=old.reduce(function(n,x){return Math.max(n,x.rank);},1),types=Array.from(new Set(old.map(function(x){return x.race;}))),defaultRace=$gameSystem._codexRaceDefault;
  a._codexRace={race:types.length===1?types[0]:types.length>1?-1:defaultRace==null?-1:defaultRace,rank:rank,free:true,blood:false,legacy:old};sync(a);
 }
 R.migrate=function(){
  if(!C()||!$gameSystem)return;
  if($gameSystem._codexRaceDefault==null){var chosen=[285,282,283,284,286,287,281].map(function(id,i){return $gameSwitches.value(id)?i:-1;}).filter(function(i){return i>=0;});if(chosen.length===1)$gameSystem._codexRaceDefault=chosen[0];}
  allActors().forEach(migrateActor);
  if(!$gameSystem._codexRaceMigration){
   var log={},items=$gameParty._items||{},out={};
   Object.keys(C().legacyItems).forEach(function(k){var n=num(items[k]),id=C().legacyItems[k];if(n&&Number(k)!==id){delete items[k];out[id]=(out[id]||0)+n;log[k]=n;}});
   Object.keys(out).forEach(function(k){items[k]=num(items[k])+out[k];});
   $gameSystem._codexRaceMigration={version:2,materials:log};
   var floor=window.CodexZhenqi?CodexZhenqi.progressFloor():0;$gameSystem._codexRaceSupply={counts:{},first:{}};C().bands.forEach(function(b,i){if(floor>=b[0])$gameSystem._codexRaceSupply.first[i+2]=true;});
  }
 };
 // Keep the first-choice guide by the tower; afterwards leave the entrance clear.
 R.relocateGuide=function(){
  if(!$gameSystem||!$gameMap||$gameMap.mapId()!==4||!$dataMap||!$dataMap.events)return;
  var source=$dataMap.events[22],gambler=$dataMap.events[47],guide=$gameMap.event(22);
  if(!source||source.note!=='<CodexRaceGuide>'||!gambler||!guide)return;
  var chosen=$gameSystem._codexRaceGuideChosen||$gameSystem._codexRaceDefault!=null||$gameSelfSwitches.value([4,22,'A'])||[285,282,283,284,286,287,281].some(function(id){return $gameSwitches.value(id);});
  var x=chosen?gambler.x+1:source.x,y=chosen?gambler.y:source.y;
  if(guide.x!==x||guide.y!==y){guide.locate(x,y);guide.setDirection(2);}
 };
 function guideChosen(){$gameSystem._codexRaceGuideChosen=true;R.relocateGuide();}
 R.setDefault=function(r){
  if(battle()||!C()||r<0||r>6)return false;$gameSystem._codexRaceDefault=r;
  allActors().forEach(function(a){migrateActor(a);if(a._codexRace.race<0&&a._codexRace.legacy.length===0){a._codexRace.race=r;sync(a);}});
  $gameParty.allMembers().forEach(function(a){migrateActor(a);if(data(a).race<0&&data(a).legacy.length===0){data(a).race=r;sync(a);}});
  [285,282,283,284,286,287,281].forEach(function(id,i){$gameSwitches.setValue(id,i===r);});guideChosen();tell('开局默认祝福：'+C().names[r]+'族');return true;
 };
 function validActor(a){return actor(a)&&$gameParty.allMembers().indexOf(a)>=0;}
 R.change=function(a,r){
  if(battle()||!validActor(a)||r<0||r>6)return {ok:false,reason:'只能在战斗外调整队伍角色'};migrateActor(a);var d=data(a);if(d.race===r)return {ok:false,reason:'已经是这个种族'};
  if(!d.free&&$gameParty.numItems($dataItems[C().water])<1)return {ok:false,reason:'需要一份忘情水'};
  var ratio=a.mhp?a.hp/a.mhp:0,mpRatio=a.mmp?a.mp/a.mmp:0;
  if(!d.free)$gameParty.loseItem($dataItems[C().water],1);d.free=false;d.race=r;d.blood=false;d.legacy=[];delete a._codexRaceBattle;sync(a);a._hp=ratio>0?Math.max(1,Math.floor(a.mhp*ratio)):0;a._mp=Math.floor(a.mmp*mpRatio);a.refresh();guideChosen();return {ok:true};
 };
 R.upgrade=function(a,rank){
  if(battle()||!validActor(a)||rank<2||rank>7)return {ok:false,reason:'只能在战斗外进阶'};migrateActor(a);var d=data(a),item=$dataItems[C().stones[rank-2]];
  if(d.race<0)return {ok:false,reason:'请先选择一种祝福'};if(d.rank!==rank-1)return {ok:false,reason:'需要先拥有第'+(rank-1)+'阶祝福'};if($gameParty.numItems(item)<1)return {ok:false,reason:'缺少'+item.name};
  var ratio=a.mhp?a.hp/a.mhp:0,mpRatio=a.mmp?a.mp/a.mmp:0;$gameParty.loseItem(item,1);d.rank=rank;sync(a);a._hp=ratio>0?Math.max(1,Math.floor(a.mhp*ratio)):0;a._mp=Math.floor(a.mmp*mpRatio);a.refresh();return {ok:true};
 };
 alias(DataManager,'extractSaveContents',function(old,args){var out=old.apply(this,args);clearBattle();supply=null;R.migrate();return out;});
 alias(DataManager,'setupNewGame',function(old,args){var out=old.apply(this,args);clearBattle();supply=null;if(C()){$gameSystem._codexRaceMigration={version:2,materials:{}};$gameSystem._codexRaceSupply={counts:{},first:{}};allActors().forEach(migrateActor);}return out;});
 alias(Game_Actor.prototype,'setup',function(old,args){var out=old.apply(this,args);if($gameSystem&&C())migrateActor(this);return out;});
 alias(Game_Party.prototype,'addActor',function(old,args){var out=old.apply(this,args),a=$gameActors.actor(args[0]);migrateActor(a);return out;});
 alias(Game_Actor.prototype,'learnSkill',function(old,args){var info=skillInfo(args[0]);if(!syncing&&info&&C()){if(!data(this))this._codexRace={race:info.race,rank:info.rank,free:true,blood:false,legacy:[]};else if(data(this).race===info.race)data(this).rank=Math.max(data(this).rank,info.rank);sync(this);return;}return old.apply(this,args);});
 alias(Game_Party.prototype,'gainItem',function(old,args){var item=args[0],n=args[1];if(C()&&item&&DataManager.isItem(item)&&n>0&&C().legacyItems[item.id]&&C().legacyItems[item.id]!==item.id)args[0]=$dataItems[C().legacyItems[item.id]];return old.apply(this,args);});
 alias(Game_Actor.prototype,'param',function(old,args){var v=old.apply(this,args),d=data(this),q=rate(this);if(!d||d.race<0)return v;if(d.race===2)v*=1.03;if(d.race===4&&args[0]===1)v*=1+q;if(d.race===6&&args[0]===0)v*=1+q;return Math.round(v);});
 R.weaponBody=function(eq,p){
  if(!eq||!DataManager.isWeapon(eq))return 0;var value=num(eq.params&&eq.params[p]);
  // Augment attach effects alter params. Subtract their signed flat changes;
  // weapon base and ordinary upgrades stay in the body value.
  var names=['(?:max\\s*hp|mhp|hp)','(?:max\\s*mp|mmp|mp)','(?:atk|attack)','(?:def|defense)','(?:mat|magic attack)','(?:mdf|magic defense)','(?:agi|agility)','(?:luk|luck)'],slots=eq.augmentSlotItems||[];
  slots.forEach(function(tag,i){var m=/^item (\d+)$/i.exec(tag||''),gem=m&&$dataItems[Number(m[1])],type=String((eq.augmentSlots||[])[i]||'').toUpperCase().trim();if(!gem||!type)return;var effects=(gem.augmentDataAttach||{})[type]||[];effects.forEach(function(line){var x=new RegExp('^'+names[p]+'\\s*:\\s*([+-]\\d+)$','i').exec(String(line).trim());if(x)value-=num(x[1]);});});
  return Math.max(0,value);
 };
 alias(Game_Actor.prototype,'paramPlus',function(old,args){var v=old.apply(this,args);if(data(this)&&data(this).race===5)v+=this.weapons().reduce(function(n,eq){return n+R.weaponBody(eq,args[0])*rate(this)/2;}.bind(this),0);return v;});
 ['skillMpCost','skillTpCost'].forEach(function(k){alias(Game_Actor.prototype,k,function(old,args){var n=old.apply(this,args);return data(this)&&data(this).race===4&&n>0?Math.max(1,Math.ceil(n*(1-rate(this)/2))):n;});});
 function flags(x){return !x||x._codexInternal||x._yunDerived||x._garouDerived||x._garouTriggered||x._tojiInternal||x._sukunaInternal||x._guyuInternal||x._codexRaceDerived||x._codexRavenDerived||x._codexMiraDerived;}
 function eligible(x,finishing){
  if(!x||!x.item()||!x.isSkill()||flags(x)||derived)return false;
  var f=window.CodexAlienation&&CodexAlienation.frame();if(f&&['active'].indexOf(f.kind)<0)return false;
  var root=current;if(root&&(root.action!==x||root.ended&&!finishing))return false;
  return true;
 }
 function group(x){return C().skillGroups[x.item().id]||x.item().id;}
 R.weaponMatches=function(a,x){
  if(!a||!x||!x.isSkill()||flags(x)||!a.weapons().length)return false;
  if(x.isAttack()||x.item().id===a.attackSkillId())return true;
  var types=C().weaponSkills[x.item().id]||[];var grants=a.weapons().some(function(eq){var id=eq.baseItemId||eq.originalBaseItemId||eq.id;return (C().weaponGrants[id]||[]).indexOf(x.item().id)>=0;});if(grants)return true;
  return types.some(function(t){return a.isWtypeEquipped(t);});
 };
 function rootFor(x){return roots.get(x)||null;}
 function prey(x,targets){
  targets=Array.from(new Set((targets||[]).filter(function(t){return live(t)&&t.isEnemy&&t.isEnemy();})));if(!targets.length)return null;
  var chosen=x._codexRacePreyIndex;if(chosen!=null){var manual=targets.filter(function(t){return t.index()===chosen;})[0];if(manual)return manual;}
  var boss=targets.filter(function(t){return window.CodexBossDifficulty&&CodexBossDifficulty.isBoss(t);});if(boss.length)targets=boss;
  // 【Claude·未经Codex检验】v0.19 妖族卡顿：每个候选各做一次预演要整份复制游戏状态，一次行动还会判定两三次。
  // 改为：唯一候选直接选；同一帧同一行动同一批候选复用结果；多个候选在同一个隔离副本里依次预演。选法（取预演伤害最高、并列取靠前）不变。
  if(targets.length===1)return targets[0];
  var key=Graphics.frameCount+':'+targets.map(function(t){return t.index();}).join(','),memo=preyMemo.get(x);
  if(memo&&memo.key===key&&targets.indexOf(memo.best)>=0)return memo.best;
  var values=R.probeValues(x,targets),best=targets[0],score=-Infinity;
  targets.forEach(function(t,i){var v=values[i];if(v>score){best=t;score=v;}});
  preyMemo.set(x,{key:key,best:best});return best;
 }
 var preyMemo=new WeakMap(),probeOwn=['param','paramBase','xparam','sparam','elementRate','traitObjects','skills','equips','criticalMultiplierBonus','skillMasteryLevel','iteratePassiveSkill'];
 R.probeValues=function(x,targets){
  var troop=$gameTroop.members(),slots=targets.map(function(t){return troop.indexOf(t);});
  if(window.CodexDamage&&CodexDamage.previewBatch&&slots.every(function(i){return i>=0;})){
   try{return CodexDamage.previewBatch(x,targets[0],function(copy){var members=$gameTroop.members();return slots.map(function(i){var c=members[i];probeOwn.forEach(function(k){if(Object.prototype.hasOwnProperty.call(troop[i],k)&&typeof troop[i][k]==='function')c[k]=troop[i][k];});try{return CodexDamage.calculate(copy,c,{preview:true,isolated:true,raceProbe:true}).value;}catch(e){return 0;}});});}catch(e){}
  }
  return targets.map(function(t){try{return CodexDamage.calculate(x,t,{preview:true,raceProbe:true}).value;}catch(e){return 0;}});
 };
 R.begin=function(x,targets){
  if(!x)return null;var a=x.subject(),d=data(a),s=actor(a)?state(a):null,r={id:++R.actionSerial,action:x,subject:a,targets:targets||[],records:[],incoming:[],ended:false,prey:null,low:false,divine:s&&s.godTurn!==turn(),blood:false,echo:false,counter:null};
  roots.set(x,r);if(d&&d.race===1){r.prey=prey(x,targets);r.low=!!(r.prey&&r.prey.hp/r.prey.mhp<=.3);}
  if(s&&s.counter){if(!live(s.counter.target)||s.counter.until<turn())delete s.counter;else if(s.spendTurn!==turn())r.counter=s.counter.target;}
  return r;
 };R.actionSerial=0;
 function activate(x,r){
  if(!eligible(x)||!actor(r.subject))return;if(data(r.subject)&&data(r.subject).race===1&&r.prey){state(r.subject).lastPrey=r.prey;tell(r.subject.name()+'·猎物：'+r.prey.name());}var a=r.subject,d=data(a),s=state(a),q=rate(a);if(!d)return;
  if(d.race===3&&d.blood&&s.bloodTurn!==turn()&&x.item().damage.type===1&&(x.isPhysical()||($dataCodexDamage.skills[x.item().id]||{}).mode==='mixed')){
   var threshold=(a.isAutoBattle()||$gameParty.isHangUp&&$gameParty.isHangUp())?.5:.3;
   if(a.hp>=s.maxHp*threshold){s.bloodTurn=turn();r.blood=true;a._hp=Math.max(1,a.hp-Math.max(1,Math.ceil(s.maxHp*.03)));a.refresh();tell(a.name()+'发动血契');}
  }
  r.echo=d.race===4&&s.echoTurn!==turn()&&s.ghostPrevious&&s.ghostPrevious.turn===turn()-1&&s.ghostPrevious.group===group(x)&&!x.isAttack()&&[1,3,4,5].indexOf(x.item().damage.type)>=0;
 }
 alias(BattleManager,'startAction',function(old,args){var x=this._subject&&this._subject.currentAction(),r=R.begin(x,[]);current=r;var out=old.apply(this,args);if(r){if(data(r.subject)&&data(r.subject).race===1){r.prey=prey(x,this._targets);r.low=!!(r.prey&&r.prey.hp/r.prey.mhp<=.3);}activate(x,r);}return out;});
 alias(Game_Action.prototype,'makeTargets',function(old,args){var ts=old.apply(this,args),r=rootFor(this);if(r&&r.targets.length===0){r.targets=ts.slice();if(data(this.subject())&&data(this.subject()).race===1){r.prey=prey(this,ts);r.low=!!(r.prey&&r.prey.hp/r.prey.mhp<=.3);}}return ts;});
 function damageKind(f){return ['percent','fixed','settled'].indexOf(f.kind)<0;}
 CodexDamageHooks.push({name:'race-blessings',build:function(x,t,f){
  var a=f.subject,d=data(a);if(!d||d.race<0||!eligible(x)||f.options.raceProbe||x._codexRaceSuppress||!damageKind(f))return;
  var q=rate(a),r=rootFor(x),s=battle()?state(a):null,preview=!!f.options.preview,power=x._codexPowerPreview&&a._codexRacePower,heal=[3,4].indexOf(f.item.damage.type)>=0;
  if(d.race===0){if(heal)f.healingMultiplier*=1+q;else{f.magicalDamageMultiplier*=1+q;if(power?!power.godUsed:r?r.divine:!s||s.godTurn!==turn())f.magicalDefenseRate*=1-q/2;}f.origins.push('神族祝福');}
  if(heal)return;
  if(d.race===3){f.physicalDamageMultiplier*=1+q;f.criticalAdd+=q/2;if(r&&r.blood||power&&(x._codexRacePowerBlood||R.powerBlood(a,f.item)))f.physicalDamageMultiplier*=1+q/2;f.origins.push('魔族祝福'+(r&&r.blood?'·血契':''));}
  if(d.race===5&&R.weaponMatches(a,x)){f.finalMultiplier*=1+q;f.origins.push('灵族兵器精通');}
  if(d.race===1){var hunter=r?r.prey:t,low=r?r.low:t.hp/t.mhp<=.3;if(hunter===t){f.physicalDefenseRate*=1-q;f.magicalDefenseRate*=1-q;f.flatMitigationRate*=1-q;f.finalMultiplier*=1+(low?q:q/2);f.origins.push('妖族猎物'+(low?'·收割':''));}}
  if(d.race===6&&r&&r.counter===t){f.finalMultiplier*=1+1.5*q;f.origins.push('蛮族反攻');}
 }});
 function record(r,t){var row=r.records.filter(function(v){return v.target===t;})[0];if(!row){row={target:t,damage:0,hpHeal:0,mpHeal:0};r.records.push(row);}return row;}
 function direct(x){var spec=(window.$dataCodexDamage&&$dataCodexDamage.skills[x.item().id])||{};return eligible(x)&&['percent','settled'].indexOf(spec.kind)<0&&[1,5].indexOf(x.item().damage.type)>=0;}
 alias(Game_Action.prototype,'executeHpDamage',function(old,args){
  var x=this,t=args[0],r=rootFor(x),before=t.hp,shield=num(t.shield),prior=hit,context=null;
  if(r&&direct(x))hit=context={action:x,root:r,source:x.subject(),limited:false};
  try{return old.apply(this,args);}finally{
   hit=prior;var loss=Math.max(0,before-t.hp),used=Math.max(0,shield-num(t.shield)),healed=Math.max(0,t.hp-before);if(context&&context.limited)t.result().hpDamage=loss;
   if(r&&eligible(x)&&!derived){var row=record(r,t);if(direct(x))row.damage+=loss+used;if(x.item().damage.type===3)row.hpHeal+=healed;
    if(loss+used>0&&actor(r.subject)&&data(r.subject)&&data(r.subject).race===0&&(x.isMagical()||(window.$dataCodexDamage&&$dataCodexDamage.skills[x.item().id]||{}).mode==='mixed'))state(r.subject).godTurn=turn();
    if(loss+used>0&&r.counter===t){var s=state(r.subject);s.spendTurn=turn();r.counterUsed=true;}
   }
   if(r&&direct(x)&&r.subject.isEnemy()&&actor(t)&&loss+used>0){var inc=r.incoming.filter(function(v){return v.target===t;})[0];if(!inc){inc={target:t,loss:0};r.incoming.push(inc);}inc.loss+=loss+used;}
  }
 });
 alias(Game_Action.prototype,'executeMpDamage',function(old,args){var t=args[0],before=t.mp,r=rootFor(this);try{return old.apply(this,args);}finally{if(r&&eligible(this)&&this.item().damage.type===4)record(r,t).mpHeal+=Math.max(0,t.mp-before);}});
 R.limitHp=function(t,hp){
  if(!hit||derived||hp>=t.hp||!battle()||!actor(t)||!data(t)||data(t).race!==6||!hit.source.isEnemy()||!eligible(hit.action))return hp;
  var f=window.CodexAlienation&&CodexAlienation.frame();if(f&&f.kind!=='active')return hp;
  var s=state(t),r=hit.root,cap=s.cap;
  if(s.capTurn!==turn()){s.capTurn=turn();s.cap={root:r.id,spent:0};cap=s.cap;}
  if(!cap||cap.root!==r.id)return hp;
  var capRate=.75-2*rate(t);if(Math.abs(capRate-.45)<1e-9)capRate=.5;var max=Math.floor(s.maxHp*capRate),loss=Math.min(t.hp-hp,Math.max(0,max-cap.spent));cap.spent+=Math.min(t.hp,loss);if(loss<t.hp-hp)hit.limited=true;return t.hp-loss;
 };
 function immune(t,x,poison){
  if(!live(t))return true;if(poison)return !t.isStateAffected(poison)||t.isStateResist(poison);
  if(!x)return false;var type=x.isPhysical()?t.pdr:x.isMagical()?t.mdr:1;if(type===0)return true;
  var es=CodexElements.actionElements(x);return es.length&&es.every(function(e){return t.elementRate(e)<=0;});
 }
 R.settledDamage=function(t,n,x,poison){
  if(n<=0||immune(t,x,poison))return 0;derived++;try{
   var before=t.hp,r=CodexShieldLedger.absorbRaceDamage(t,Math.floor(n));t.clearResult();t._hp=Math.max(0,t.hp-r.remaining);t.refresh();t.result().hpAffected=true;t.result().hpDamage=before-t.hp;t.startDamagePopup();if(t.isDead())t.performCollapse();return before-t.hp+r.absorbed;
  }finally{derived--;}
 };
 function healEcho(t,n,mp){if(!live(t)||n<=0)return 0;var before=mp?t.mp:t.hp;derived++;try{if(mp)t._mp=Math.min(t.mmp,t.mp+Math.floor(n));else t._hp=Math.min(t.mhp,t.hp+Math.floor(n));t.refresh();t.clearResult();if(mp)t.result().mpDamage=before-t.mp;else{t.result().hpAffected=true;t.result().hpDamage=before-t.hp;}t.startDamagePopup();return (mp?t.mp:t.hp)-before;}finally{derived--;}}
 R.finish=function(r){
  if(!r||r.ended)return;r.ended=true;var a=r.subject,d=data(a),q=rate(a),s=actor(a)?state(a):null,total=r.records.reduce(function(n,v){return n+v.damage+v.hpHeal+v.mpHeal;},0);
  if(d&&eligible(r.action,true)){
   if(d.race===2){var id=C().poisons[d.rank-1];r.records.forEach(function(v){if(v.damage<=0||!live(v.target))return;r.action.itemEffectAddState(v.target,{code:21,dataId:id,value1:1,value2:0});if(v.target.isStateAffected(id)){var p=s.poison.filter(function(p){return p.target===v.target&&p.id===id&&p.turn===turn();})[0];if(p)p.amount+=v.damage*q/2;else s.poison.push({target:v.target,id:id,amount:v.damage*q/2,turn:turn()});}});}
   if(d.race===4&&total>0&&!r.action.isAttack()&&[1,3,4,5].indexOf(r.action.item().damage.type)>=0){s.ghostCurrent={group:group(r.action),turn:turn()};if(r.echo){s.echoTurn=turn();r.records.forEach(function(v){if(v.damage>0)R.settledDamage(v.target,v.damage*q,r.action);if(v.hpHeal>0)healEcho(v.target,v.hpHeal*q,false);if(v.mpHeal>0)healEcho(v.target,v.mpHeal*q,true);});}}
   if(r.counterUsed)delete s.counter;
  }
  r.incoming.forEach(function(v){var d=data(v.target);if(!live(v.target)||!d||d.race!==6)return;var s=state(v.target);if(!s.counter&&s.gainTurn!==turn()&&v.loss>=s.maxHp*.1&&live(a)){s.gainTurn=turn();s.counter={target:a,until:turn()+1};tell(v.target.name()+'准备反攻'+a.name());}});
 };
 alias(BattleManager,'endAction',function(old,args){var r=current;try{R.finish(r);return old.apply(this,args);}finally{if(current===r)current=null;hit=null;}});
 // Counter/reflection are independent numeric sources, never the original active root.
 ['invokeCounterAttack','invokeMagicReflection'].forEach(function(k){alias(BattleManager,k,function(old,args){var prev=current;current=null;derived++;try{return old.apply(this,args);}finally{derived--;current=prev;}});});
 alias(Game_Action.prototype,'apply',function(old,args){
  if(current||!battle()||flags(this)||derived)return old.apply(this,args);
  var r=R.begin(this,[args[0]]);current=r;activate(this,r);try{return old.apply(this,args);}finally{R.finish(r);current=null;hit=null;}
 });
 R.withRoot=function(x,targets,fn){var prev=current,r=R.begin(x,targets);current=r;activate(x,r);try{return fn(r);}finally{R.finish(r);current=prev;hit=null;}};
 function clearPoison(t,id){allActors().forEach(function(a){var s=a._codexRaceBattle;if(s)s.poison=(s.poison||[]).filter(function(p){return p.target!==t||(id!=null&&p.id!==id);});});}
 alias(Game_BattlerBase.prototype,'eraseState',function(old,args){if(C()&&C().poisons.indexOf(args[0])>=0)clearPoison(this,args[0]);return old.apply(this,args);});
 alias(Game_BattlerBase.prototype,'clearStates',function(old,args){clearPoison(this,null);return old.apply(this,args);});
 [Game_Actor.prototype,Game_Enemy.prototype].forEach(function(proto){alias(proto,'die',function(old,args){var t=this;if(t._codexRaceBattle)delete t._codexRaceBattle.counter;allActors().forEach(function(a){var s=a._codexRaceBattle;if(s&&s.counter&&s.counter.target===t)delete s.counter;});return old.apply(this,args);});});
 alias(Game_Party.prototype,'removeActor',function(old,args){var a=$gameActors.actor(args[0]);if(a&&a._codexRaceBattle)delete a._codexRaceBattle.counter;return old.apply(this,args);});
 R.poisonInfo=function(t){var rows=[];allActors().forEach(function(a){var s=a._codexRaceBattle;if(!s)return;(s.poison||[]).forEach(function(p){if(p.target===t&&p.turn===turn()&&t.isStateAffected(p.id))rows.push(a.name()+'：'+Math.floor(p.amount));});});return rows.length?'毒鸡汤（回合末） '+rows.join('；'):'';};
 alias(Window_BattleEnemy.prototype,'updateHelp',function(old,args){var out=old.apply(this,args),t=this.enemy(),info=t&&R.poisonInfo(t);if(info&&this._helpWindow){this._helpWindow.setText(t.name()+'\n'+info);this._helpWindow.show();}return out;});
 function human(a,r){var s=state(a);if(s.humanTurn!==r){s.humanTurn=r;s.humanExtra=!!(live(a)&&a.canMove()&&data(a)&&data(a).race===2&&R.random()<rate(a)/2);}return s.humanExtra;}
 alias(BattleManager,'makeActionOrders',function(old,args){var out=old.apply(this,args);if(this.isOTB&&this.isOTB())$gameParty.battleMembers().forEach(function(a){var s=state(a),r=turn();if(s.humanInserted===r)return;s.humanInserted=r;if(human(a,r)&&this._actionBattlers.indexOf(a)>=0){var last=this._actionBattlers.lastIndexOf(a);this._actionBattlers.splice(last+1,0,a);tell(a.name()+'九九六：额外行动');}}.bind(this));return out;});
 alias(Game_Actor.prototype,'makeActionTimes',function(old,args){var n=old.apply(this,args);if(!battle()||BattleManager.isOTB&&BattleManager.isOTB())return n;var r=turn();if(BattleManager._phase==='input')r=($gameTroop.turnCount()||0)+1;return n+(human(this,r)?1:0);});
 R.roundEnd=function(){var r=turn();if(lastEnd===r)return;lastEnd=r;
  allActors().forEach(function(a){var s=a._codexRaceBattle;if(!s)return;var list=s.poison||[];s.poison=[];list.forEach(function(p){if(p.turn===r)R.settledDamage(p.target,p.amount,null,p.id);});s.ghostPrevious=s.ghostCurrent&&s.ghostCurrent.turn===r?s.ghostCurrent:null;s.ghostCurrent=null;if(s.counter&&s.counter.until<=r)delete s.counter;});
  C().poisons.forEach(function(id){$gameTroop.members().concat($gameParty.battleMembers()).forEach(function(t){if(t.isStateAffected(id))t.removeState(id);});});
 };
 alias(BattleManager,'endTurn',function(old,args){var out=old.apply(this,args);if(this._enteredEndPhase)R.roundEnd();return out;});
 alias(Game_Battler.prototype,'removeState',function(old,args){var id=args[0],out=old.apply(this,args),t=this;if(C()&&C().poisons.indexOf(id)>=0&&!t.isStateAffected(id))allActors().forEach(function(a){var s=a._codexRaceBattle;if(s)s.poison=(s.poison||[]).filter(function(p){return p.target!==t||p.id!==id;});});return out;});
 function clearBattle(){current=null;hit=null;derived=0;roots=new WeakMap();lastEnd=-1;allActors().forEach(function(a){delete a._codexRaceBattle;});}
 alias(BattleManager,'startBattle',function(old,args){clearBattle();serial++;var out=old.apply(this,args);$gameParty.battleMembers().forEach(function(a){state(a);});return out;});
 alias(BattleManager,'setup',function(old,args){var out=old.apply(this,args);supply={floor:window.CodexHonghuang?CodexHonghuang.bossFloor():0,won:false,claimed:false};return out;});
 alias(BattleManager,'endBattle',function(old,args){if(supply)supply.won=args[0]===0;try{return old.apply(this,args);}finally{clearBattle();}});
 R.claimInbox=function(){var s=$gameSystem._codexRaceSupply;if(!s||!s.inbox)return;Object.keys(s.inbox).forEach(function(k){var item=$dataItems[k],n=Math.min(s.inbox[k],Math.max(0,$gameParty.maxItems(item)-$gameParty.numItems(item)));if(n){$gameParty.gainItem(item,n);s.inbox[k]-=n;}if(s.inbox[k]<=0)delete s.inbox[k];});};
 R.claimSupply=function(){
  if(!supply||!supply.won||supply.claimed)return [];supply.claimed=true;var rank=0;C().bands.forEach(function(b,i){if(supply.floor>=b[0]&&supply.floor<=b[1])rank=i+2;});if(!rank)return [];
  var s=$gameSystem._codexRaceSupply=$gameSystem._codexRaceSupply||{counts:{},first:{}},n=s.counts[rank]=(s.counts[rank]||0)+1,total=0;
  if(!s.first[rank]){s.first[rank]=true;total++;}if(n>=5){s.counts[rank]=n%5;total++;}if(total){var item=$dataItems[C().stones[rank-2]],before=$gameParty.numItems(item);$gameParty.gainItem(item,total);var pending=total-($gameParty.numItems(item)-before);if(pending>0){s.inbox=s.inbox||{};s.inbox[item.id]=(s.inbox[item.id]||0)+pending;}tell('获得'+item.name+'×'+total+(pending?'；背包已满，暂存祝福管理':''));}return [rank,total,s.counts[rank]];
 };
 alias(CodexEconomy,'bossReward',function(old,args){var out=old.apply(this,args);if(out)R.claimSupply();return out;});
 // Standard shops merge the seven legacy entries while retaining native currency costs.
 alias(Scene_Shop.prototype,'prepare',function(old,args){if(C()){var seen={},goods=args[0]||[];args[0]=goods.map(function(row){row=row.slice();if(row[0]===0&&C().legacyItems[row[1]])row[1]=C().legacyItems[row[1]];return row;}).filter(function(row){var key=JSON.stringify(row);if(seen[key])return false;seen[key]=true;return true;});}return old.apply(this,args);});
 alias(Window_ShopBuy.prototype,'isEnabled',function(old,args){var item=args[0],rank=item&&C()&&C().stones.indexOf(item.id)+2;if(rank>=2){var floor=window.CodexZhenqi?CodexZhenqi.progressFloor():0;if(floor<C().bands[rank-2][0])return false;}return old.apply(this,args);});
 function choose(scene,rows,ok,cancel,lines){var folded=[];(lines||[]).forEach(function(t){var line='',width=0;Array.from(String(t)).forEach(function(ch){var n=ch.charCodeAt(0)>255?2:1;if(width+n>48){folded.push(line);line='';width=0;}line+=ch;width+=n;});if(line)folded.push(line);});CodexYunshang.choose(scene,rows,ok,cancel,folded);}
 function racePage(scene,a,back){
  var d=data(a),rows=C().names.map(function(n,r){return {label:n+'族'+(d.race===r?'（当前）':''),race:r};});
  choose(scene,rows,function(row){var lines=R.effects(row.race,d.rank).concat(['保留当前阶位；'+(d.free?'本次调整免费':'消耗忘情水×1')]);choose(scene,[{label:'确定选择'},{label:'返回'}],function(answer){if(answer.label==='返回')return racePage(scene,a,back);var result=R.change(a,row.race);tell(result.ok?a.name()+'：'+R.label(a):result.reason);actorPage(scene,a,back);},function(){racePage(scene,a,back);},lines);},back,[a.name()+' 当前：'+R.label(a)]);
 }
 function actorPage(scene,a,back,requested){
  migrateActor(a);var d=data(a),rows=[{label:'调整种族',key:'race'}];if(d.race>=0&&d.rank<7)rows.push({label:'进阶至第'+(requested||d.rank+1)+'阶',key:'rank'});if(d.race===3)rows.push({label:'血契：'+(d.blood?'开启':'关闭'),key:'blood'});
  choose(scene,rows,function(row){if(row.key==='race')return racePage(scene,a,back);if(row.key==='blood'){d.blood=!d.blood;return actorPage(scene,a,back);}var rank=requested||d.rank+1;choose(scene,[{label:'确定进阶'},{label:'返回'}],function(answer){if(answer.label==='确定进阶'){var result=R.upgrade(a,rank);tell(result.ok?a.name()+'：'+R.label(a):result.reason);}actorPage(scene,a,back);},function(){actorPage(scene,a,back);},['消耗'+$dataItems[C().stones[rank-2]].name+'×1'].concat(R.effects(d.race,rank)));},back,[a.name()+'：'+R.label(a)].concat(d.race>=0?R.effects(d.race,d.rank):['旧档多族请先选择一种；最高阶位已保留']));
 }
 R.openMenu=function(options){
  if(battle()||!C())return false;options=options||{};R.migrate();R.claimInbox();
  CodexBinding.openMenu(function(scene){function members(){choose(scene,$gameParty.allMembers().map(function(a){return {label:a.name()+' · '+R.label(a),actor:a};}),function(row){actorPage(scene,row.actor,members,options.rank);},function(){scene.popScene();},['调整角色祝福；换族保留阶位','进阶材料七族通用；每名角色首次调整免费']);}
   function defaults(){choose(scene,C().names.map(function(n,r){return {label:n+'族',race:r};}),function(row){choose(scene,[{label:'确定开局默认'},{label:'返回'}],function(answer){if(answer.label==='返回')return defaults();R.setDefault(row.race);members();},function(){scene.popScene();},R.effects(row.race,1).concat(['新招募角色默认继承该族，可逐人调整']));},function(){scene.popScene();},['选择开局默认祝福']);}if($gameSystem._codexRaceDefault==null)defaults();else members();
  });return true;
 };
 alias(Window_MenuCommand.prototype,'addOriginalCommands',function(old,args){var out=old.apply(this,args);this.addCommand('种族祝福','codexRace',!battle());return out;});
 alias(Scene_Menu.prototype,'createCommandWindow',function(old,args){var out=old.apply(this,args);this._commandWindow.setHandler('codexRace',function(){R.openMenu();});return out;});
 alias(Game_Map.prototype,'setup',function(old,args){var out=old.apply(this,args);R.relocateGuide();return out;});
 alias(Scene_Map.prototype,'onMapLoaded',function(old,args){if(!this._transfer&&$dataMap&&$dataMap.events){$dataMap.events.forEach(function(ev){if(ev&&ev.note==='<CodexRaceGuide>')$gameMap._events[ev.id]=new Game_Event($gameMap.mapId(),ev.id);});R.relocateGuide();}return old.apply(this,args);});
 alias(Game_Action.prototype,'needsSelection',function(old,args){return data(this.subject())&&data(this.subject()).race===1&&this.isForOpponent()&&this.isForAll()&&this.isDamage()?true:old.apply(this,args);});
 alias(Scene_Battle.prototype,'onEnemyOk',function(old,args){var x=BattleManager.inputtingAction();if(x&&data(x.subject())&&data(x.subject()).race===1&&x.isForAll())x._codexRacePreyIndex=this._enemyWindow.enemyIndex();return old.apply(this,args);});
 alias(Window_ActorCommand.prototype,'makeCommandList',function(old,args){var out=old.apply(this,args);if(data(this._actor)&&data(this._actor).race===3)this.addCommand('血契：'+(data(this._actor).blood?'开':'关'),'raceBlood',true);return out;});
 alias(Scene_Battle.prototype,'createActorCommandWindow',function(old,args){var out=old.apply(this,args);this._actorCommandWindow.setHandler('raceBlood',function(){var a=BattleManager.actor();data(a).blood=!data(a).blood;this._actorCommandWindow.setup(a);this._actorCommandWindow.activate();}.bind(this));return out;});
 R.resetPowerCycle=function(a){a._codexRacePower={turn:0,godUsed:false,bloodUsed:false,echoUsed:false,previous:null,last:null};};
 R.startPowerTurn=function(a,turn){var p=a._codexRacePower;if(!p)R.resetPowerCycle(a);p=a._codexRacePower;p.previous=p.last&&p.last.turn===turn-1?p.last:null;p.last=null;p.turn=turn;p.godUsed=false;p.bloodUsed=false;p.echoUsed=false;};
 R.powerBlood=function(a,item){var d=data(a),p=a._codexRacePower;return !!(d&&d.race===3&&d.blood&&p&&!p.bloodUsed&&item.damage.type===1&&(item.hitType===1||($dataCodexDamage.skills[item.id]||{}).mode==='mixed')&&a.hp>=a.mhp*.5);};
 R.powerCost=function(a,item,cost){if(R.powerBlood(a,item))cost=Object.assign({},cost,{hp:cost.hp+Math.max(1,Math.ceil(a.mhp*.03)),raceBlood:true});return cost;};
 R.powerAdjust=function(x,target,value){
  var a=x.subject(),d=data(a),p=a._codexRacePower,q=rate(a),item=x.item();if(!d||!p||value<=0)return value;
  if(d.race===2)value*=1+q/2;
  if(d.race===4&&!x.isAttack()&&!p.echoUsed&&p.previous&&p.previous.group===group(x))value*=1+q;
  // The standard power scene weighs one target at 60%, three at 40%. Hunter buffs one in either case.
  if(d.race===1&&item.scope===2){var opts={preview:true,isolated:true,reference:true},normal=CodexDamage.calculate(x,target,opts).value,base;
   x._codexRaceSuppress=true;try{base=CodexDamage.calculate(x,target,opts).value;}finally{delete x._codexRaceSuppress;}if(normal>0)value=value/1.8*(1+.8*base/normal);}
  return value;
 };
 R.commitPowerRoot=function(a,item,value){var p=a._codexRacePower,d=data(a);if(!p||!d||value<=0)return;var key=C().skillGroups[item.id]||item.id;
  if(d.race===0&&(item.hitType===2||($dataCodexDamage.skills[item.id]||{}).mode==='mixed'))p.godUsed=true;
  if(R.powerBlood(a,item))p.bloodUsed=true;
  if(d.race===4&&item.id!==a.attackSkillId()){if(p.previous&&p.previous.group===key)p.echoUsed=true;p.last={group:key,turn:p.turn};}
 };
 R.status=function(a){var d=data(a);if(!d||d.race<0)return R.label(a);if(!battle())return R.label(a);var s=state(a),t=turn();if(d.race===6)return '蛮骨：'+(s.capTurn===t?'已用':'可用')+(s.counter?'；反攻：'+s.counter.target.name()+'（至第'+s.counter.until+'回合）':'');if(d.race===1)return s.lastPrey&&live(s.lastPrey)?'猎物：'+s.lastPrey.name():'猎物：单体沿用目标，群攻选择一名敌人';if(d.race===3)return '血契：'+(d.blood?'开启':'关闭');if(d.race===4)return '残响：'+(s.ghostPrevious&&s.ghostPrevious.turn===t-1?$dataSkills[s.ghostPrevious.group]&&$dataSkills[s.ghostPrevious.group].name||'准备好':'未准备');if(d.race===2)return '九九六：'+(s.humanExtra?'本回合额外行动':'本回合无额外行动');return R.label(a);};
 return R;
});
