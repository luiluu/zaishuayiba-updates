// 【Codex·未经Claude检验】v0.12 奥恩材料统一更名为锻造锤；未经claude检验。
// 【Codex·未经Claude检验】v0.08 面板文本优化；未经claude检验。
// Extracted from the verified native runtime; installer order is maintained by main.js.
window.CodexRuntime.register("installNativeHubrisRuntime", function() {
  function installNativeHubrisRuntime() {
    var H=window.CodexHeartsteel,U=window.CodexHubris={armorId:7902,leviathanId:7903,recipeId:458,materialId:2867};
    U.baseId=H.baseId;U.quality=H.quality;
    U.isHeart=function(i){return U.baseId(i)===U.armorId;};
    U.isLeviathan=function(i){return U.baseId(i)===U.leviathanId;};
    U.isGear=function(i){return U.isHeart(i)||U.isLeviathan(i);};
    U.gear=function(a){return a && a.isActor && a.isActor()?a.equips().filter(U.isGear)[0]:null;};
    U.growth=function(i){return Math.max(0,Math.floor(Number(i && i._codexHubrisFame)||0));};
    // v0.3 (2026-10-08): fame stages share the Heartsteel square-root curve.
    U.rateFor=function(i,k){return (U.isLeviathan(i)?1.2:1.1)+0.1*H.stageOf(k);};
    U.normalize=function(i){if(!U.isGear(i))return;var q=U.quality(i);i.note=(i.note||'').replace(/<(quality|ici):\s*\d+>/gi,'')+'\n<quality:'+q+'>\n<ici:'+q+'>\n';i.meta=i.meta||{};i.meta.quality=String(q);i.meta.ici=String(q);};

    // 【Codex·未经Claude检验】v0.08：明确当前扬名收益、参与要求与盛名结算。
    U.helpPatterns=[/^(?:盛名层数|盛名|扬名|Boss战|阶|参与|结算|增益|持续|穿透|扬名增益|本场待结算盛名)：/,
      /^等级需求：无$/,/^基础属性：物攻\+/,/^成长：(普通|盛名层数)/,
      /^效果：(物理伤害忽略|物防穿透|参与击杀|首领|增益刷新|扬名)/,/^条件：参与需/,/^进度：盛名/,/^本场成长：盛名/,/^当前增益：扬名/];

    U.helpRows=function(i){var k=U.growth(i),n=H.stageOf(k),lev=U.isLeviathan(i);return [
      '成长：盛名层数'+k+'；扬名时物理攻击×'+H.helpNumber(U.rateFor(i,k)),
      '进度：盛名升阶还需'+(H.stageNeed(n+1)-k)+'层',
      '效果：物防穿透'+(lev?27:18)+'%',
      '效果：参与击杀获得扬名；首领战中持续造成伤害也可触发',
      '效果：扬名积累盛名，胜利后保留',
      '效果：扬名持续'+(lev?4:3)+'个完整回合，触发回合不计',
      '效果：扬名刷新不叠加；死亡、卸装或战斗结束时清除'
    ];};
    U.describe=function(i){
      if(!U.isGear(i))return;
      i.description=String(i.description||'').replace(/^神武\n(?:13层[^\n]*|由狂妄原件[^\n]*)/,$dataArmors[U.baseId(i)].description);
      H.rewriteHelpRows(i,U.helpPatterns,U.helpRows(i));
      if(window.RJO&&RJO.HE&&RJO.HE.getDescParams)RJO.HE.getDescParams(i,2);
    };
    var hubrisDatabase=DataManager.isDatabaseLoaded;
    DataManager.isDatabaseLoaded=function(){var loaded=hubrisDatabase.apply(this,arguments);if(loaded&&!U._helpReady){U._helpReady=true;[U.armorId,U.leviathanId].forEach(function(id){U.describe($dataArmors[id]);});}return loaded;};
    U.ownedGear=function(){var items=$gameParty.armors().slice();$gameParty.allMembers().forEach(function(a){items=items.concat(a.equips().filter(U.isGear));});return items.filter(function(i,n){return U.isGear(i)&&i.id>=DataManager._baseArmorsLength&&items.indexOf(i)===n;});};
    U.forgeSources=function(){return U.ownedGear().filter(U.isHeart);};
    var tags=DataManager.processYanflyTags;
    DataManager.processYanflyTags=function(i){U.normalize(i);return tags.apply(this,arguments);};
    var register=DataManager.addNewIndependentItem;
    DataManager.addNewIndependentItem=function(base,i){var out=register.apply(this,arguments);if(U.isGear(i)){var id=U.baseId(i);i.baseItemId=id;i.originalBaseItemId=id;i._codexHubrisFame=U.growth(i);U.normalize(i);U.describe(i);}return out;};
    U.unlockForge=function(notify){
      if(!$gameParty)return;var was=!!$gameParty._codexAtaraxiaUnlocked;
      if(!was&&!U.ownedGear().length)return;
      $gameParty._codexAtaraxiaUnlocked=true;$gameParty.learnRecipe(U.recipeId);
      if(!was&&notify&&window.$&&$.toaster)$.toaster({message:'已解锁打造配方：杰作无我'});
    };
    var gain=Game_Party.prototype.gainItem;
    Game_Party.prototype.gainItem=function(i,n){var out=gain.apply(this,arguments);if(n>0&&U.isGear(i)&&this===$gameParty)U.unlockForge(true);return out;};
    var reset=Game_Party.prototype.resetKnownRecipes;
    Game_Party.prototype.resetKnownRecipes=function(){var out=reset.apply(this,arguments);if(this._codexAtaraxiaUnlocked)this.learnRecipe(U.recipeId);return out;};
    U.canForge=function(i){return !!($gameParty&&!$gameParty.inBattle()&&$gameParty._codexAtaraxiaUnlocked&&U.isHeart(i)&&U.forgeSources().indexOf(i)>=0&&$gameParty.numItems($dataItems[2530])>=200&&$gameParty.numItems($dataItems[U.materialId])>=5);};
    U.previewForge=function(i){
      if(!U.isHeart(i))return null;var v=JsonEx.makeDeepCopy(i),base=$dataArmors[U.armorId],master=$dataArmors[U.leviathanId];
      v.baseItemId=U.leviathanId;v.originalBaseItemId=U.leviathanId;
      for(var p=0;p<8;p++)v.params[p]+=master.params[p]-base.params[p];
      v.name=v.name.replace('狂妄','杰作无我');if(v.baseItemName)v.baseItemName=v.baseItemName.replace('狂妄','杰作无我');
      v.iconIndex=master.iconIndex;v.description=v.description.replace(base.description,master.description);
      v.note=v.note.replace('<CodexHubris>','<CodexAtaraxia>');
      ['基础属性:物攻+1000','穿透:自身物理伤害忽略18%目标物防','盛名:有效参与击杀后临时物攻+1000＋20×K','持续:触发回合不计，后续3个完整全局回合'].forEach(function(t,n){
        var replacement=['基础属性:物攻+1500','穿透:自身物理伤害忽略27%目标物防','盛名:有效参与击杀后临时物攻+1600＋30×K','持续:触发回合不计，后续4个完整全局回合'][n];v.note=v.note.replace('text='+t+' size=','text='+replacement+' size=');
      });
      v.meta=JsonEx.makeDeepCopy(v.meta||{});delete v.meta.CodexHubris;v.meta.CodexAtaraxia=true;U.describe(v);return v;
    };
    function restore(i,v){Object.keys(i).forEach(function(k){delete i[k];});Object.keys(v).forEach(function(k){i[k]=v[k];});}
    U.forge=function(i){
      if(!U.canForge(i))return null;var snapshot=JsonEx.makeDeepCopy(i),v=U.previewForge(i),frag=$dataItems[2530],core=$dataItems[U.materialId],f=$gameParty.numItems(frag),n=$gameParty.numItems(core);
      try{restore(i,v);$gameParty.loseItem(frag,200,false);$gameParty.loseItem(core,5,false);if($gameParty.numItems(frag)!==f-200||$gameParty.numItems(core)!==n-5)throw Error('Ataraxia material transaction failed');$gameParty.allMembers().forEach(function(a){if(a.equips().indexOf(i)>=0){a.need_refresh=true;a.refresh();}});}
      catch(e){restore(i,snapshot);$gameParty.gainItem(frag,f-$gameParty.numItems(frag),false);$gameParty.gainItem(core,n-$gameParty.numItems(core),false);throw e;}return i;
    };
    U.bindRecipe=function(){var r=window.$gameRecipes&&$gameRecipes[U.recipeId];if(!r||r._codexAtaraxiaBound)return;r._codexAtaraxiaBound=true;var count=r.getMaterialCount;
      r.getMaterialCount=function(m){return m._type==='armor'&&m._baseItemId===U.armorId?U.forgeSources().length:count.apply(this,arguments);};
      r.craftable=function(){return !!($gameParty&&!$gameParty.inBattle()&&$gameParty.recipeKnown(U.recipeId)&&this.hasMaterials()&&this.hasLevel());};r.amountCraftable=function(){return this.craftable()?1:0;};r.craft=function(){return U.forge(U._forgeSource);};U.unlockForge(false);
    };
    var recipes=DataManager.createRecipes;
    DataManager.createRecipes=function(){var out=recipes.apply(this,arguments);U.bindRecipe();return out;};U.bindRecipe();
    U.growthLabel='盛名层数';U.forgeGrowth=U.growth;
    U.forgeDetailLines=function(i){return i?['品质、词条、盛名与强化进度完整保留','基础物理攻击额外＋500','物理防御穿透由18%提高至27%','扬名时物理攻击×'+H.helpNumber(1.2+0.1*H.stageOf(U.growth(i))),'扬名持续4个完整回合']:['选择一件狂妄，含已装备的实例','品质、词条与盛名层数完整继承'];};
    U.forgeHelpText=function(i,picking,shown){return i?'选择: '+i.name+'\n品质、词条、盛名层数及强化进度保留'+(picking?(shown?'；按 Shift 返回升级预览':'；按 Shift 查看词条'):''):'杰作无我：选择一件狂妄升级；消耗200人道意志碎片与5锻造锤';};
    U.refresh=function(a){if(!a)return;a.need_refresh=true;if(a._ParamCache2)a._ParamCache2=[];a.refresh();};
    U.clearBuff=function(a){if(a&&a._codexHubrisBuff){delete a._codexHubrisBuff;U.refresh(a);}};
    U.activeBonus=function(a){var b=a._codexHubrisBuff;if(!b)return 0;if(!$gameParty.inBattle()||a.isDead()||!U.gear(a)||U.gear(a).id!==b.itemId||!b.rate){delete a._codexHubrisBuff;return 0;}return b.rate;};
    var finalParam=Game_Actor.prototype.param;
    Game_Actor.prototype.param=function(p){var v=finalParam.apply(this,arguments);if(p!==2)return v;var r=U.activeBonus(this);return r?Math.round(Math.min(this.paramMax(2),v*r)):v;};
    var refreshActor=Game_Actor.prototype.refresh;
    Game_Actor.prototype.refresh=function(){var b=this._codexHubrisBuff;if(b&&(!U.gear(this)||U.gear(this).id!==b.itemId))delete this._codexHubrisBuff;return refreshActor.apply(this,arguments);};
    var dieActor=Game_Actor.prototype.die;
    Game_Actor.prototype.die=function(){delete this._codexHubrisBuff;return dieActor.apply(this,arguments);};
    // Apply defense reduction only while the native physical formula reads
    // target parameters. All native hit/critical/element/guard processing remains.
    var formula=Game_Action.prototype.evalDamageFormula;
    Game_Action.prototype.evalDamageFormula=function(target){
      var i=U.gear(this.subject());if(!i||!this.isPhysical()||!this.item()||[1,5].indexOf(this.item().damage.type)<0)return formula.apply(this,arguments);
      var own=Object.getOwnPropertyDescriptor(target,'param'),nativeParam=target.param,rate=U.isLeviathan(i)?0.27:0.18;
      target.param=function(p){var v=nativeParam.apply(this,arguments);return p===3?v*(1-rate):v;};
      try{return formula.apply(this,arguments);}finally{if(own)Object.defineProperty(target,'param',own);else delete target.param;}
    };
    U.pending=function(i){var e=(U._ledger||[]).filter(function(e){return e.item===i;})[0];return e?e.gain:0;};
    U.enemyWeight=function(e){
      if(!$gameParty.inBattle()||$gameTroop._troopId===1||U._originalEnemies.indexOf(e)<0||e._codexHubrisExcluded)return 0;
      var name=e.enemy().name;if(/分身|复制|召唤物|练习|训练|木桩/.test(name))return 0;
      return /【未知存在】/.test(name)?10:/【首领】|【被封印者】/.test(name)?5:1;
    };
    U.noteDamage=function(action,target,before){
      var actor=action.subject(),i=U.gear(actor);
      if(!U._running||!i||!actor.isAlive()||!target.isEnemy()||before<=0||target.hp>=before||!U.enemyWeight(target))return;
      var rows=target._codexHubrisContributions||(target._codexHubrisContributions=[]),id=actor.actorId();
      rows=rows.filter(function(r){return r.actorId!==id;});rows.push({actorId:id,itemId:i.id,moves:actor._codexHubrisMoves||0});target._codexHubrisContributions=rows;
    };
    U.award=function(a,i,gain){
      var row=U._ledger.filter(function(x){return x.item===i;})[0];if(!row){row={item:i,gain:0};U._ledger.push(row);}row.gain+=gain;
      var master=U.isLeviathan(i),k=U.growth(i)+row.gain;
      a._codexHubrisBuff={itemId:i.id,rate:U.rateFor(i,k),round:$gameTroop.turnCount(),remaining:master?4:3};U.refresh(a);
    };
    U.qualified=function(e){return (e._codexHubrisContributions||[]).map(function(r){var a=$gameActors.actor(r.actorId),i=U.gear(a);return a&&a.isAlive()&&i&&i.id===r.itemId&&(a._codexHubrisMoves||0)-r.moves<=2?[a,i]:null;}).filter(Boolean);};
    // Boss HP segments: each newly reached 10% of max HP lost counts as one takedown.
    U.noteSegments=function(e){
      if(!U._running||!e.isEnemy()||!e.isAlive()||U.enemyWeight(e)<5||e.mhp<=0)return;
      var seg=Math.min(9,Math.floor((1-e.hp/e.mhp)*10+1e-9)),prev=e._codexHubrisSeg||0;if(seg<=prev)return;
      e._codexHubrisSeg=seg;U.qualified(e).forEach(function(p){U.award(p[0],p[1],seg-prev);});
    };
    U.settleDeaths=function(){
      if(!U._running)return;var deaths=U._deaths.splice(0);
      deaths.forEach(function(e){
        if(e.isAlive()||e._codexHubrisCounted)return;e._codexHubrisCounted=true;var gain=U.enemyWeight(e);if(!gain||!e._codexHubrisKilledByParty)return;
        (e._codexHubrisContributions||[]).forEach(function(r){
          var a=$gameActors.actor(r.actorId),i=U.gear(a);if(!a.isAlive()||!i||i.id!==r.itemId||(a._codexHubrisMoves||0)-r.moves>2)return;
          U.award(a,i,gain);
        });
      });
    };
    var setup=BattleManager.setup;
    BattleManager.setup=function(){var out=setup.apply(this,arguments);this._codexHubrisRewardRolled=false;U._ledger=[];U._deaths=[];U._depth=0;U._running=false;U._round=null;U._originalEnemies=$gameTroop.members().slice();U._originalEnemies.forEach(function(e){delete e._codexHubrisCounted;delete e._codexHubrisContributions;delete e._codexHubrisSeg;e._codexHubrisExcluded=e.isHidden();});return out;};
    var startBattle=BattleManager.startBattle;
    BattleManager.startBattle=function(){U._running=true;$gameParty.allMembers().forEach(function(a){U.clearBuff(a);a._codexHubrisMoves=0;});return startBattle.apply(this,arguments);};
    var hpDamage=Game_Action.prototype.executeHpDamage;
    Game_Action.prototype.executeHpDamage=function(t,v){var before=t.hp,out=hpDamage.apply(this,arguments);if(v>0){U.noteDamage(this,t,before);if(t.isEnemy()&&before>0&&t.isDead())t._codexHubrisKilledByParty=!!(this.subject()&&this.subject().isActor());else if(t.isEnemy()&&this.subject()&&this.subject().isActor())U.noteSegments(t);}return out;};
    // A revived enemy starts a fresh kill cycle. Contributions from its
    // previous life cannot qualify as assists for the next death.
    U.newEnemyLife=function(enemy){delete enemy._codexHubrisCounted;delete enemy._codexHubrisContributions;delete enemy._codexHubrisKilledByParty;delete enemy._codexHubrisSeg;};
    var enemyRevive=Game_Enemy.prototype.revive;
    Game_Enemy.prototype.revive=function(){var dead=this.hp<=0||this.isDead(),out=enemyRevive.apply(this,arguments);if(U._running&&dead&&this.hp>0)U.newEnemyLife(this);return out;};
    var enemyRefresh=Game_Enemy.prototype.refresh;
    Game_Enemy.prototype.refresh=function(){var out=enemyRefresh.apply(this,arguments);if(U._running&&this._codexHubrisCounted&&this.isAlive())U.newEnemyLife(this);return out;};
    var enemyDie=Game_Enemy.prototype.die;
    Game_Enemy.prototype.die=function(){var out=enemyDie.apply(this,arguments);if(U._running&&U._deaths.indexOf(this)<0)U._deaths.push(this);return out;};
    var apply=Game_Action.prototype.apply;
    Game_Action.prototype.apply=function(){U._depth++;try{return apply.apply(this,arguments);}finally{U._depth--;if(!U._depth)U.settleDeaths();}};
    var startAction=BattleManager.startAction;
    BattleManager.startAction=function(){var a=this._subject,action=a&&a.currentAction();if(action&&a.isActor()&&!action._codexHubrisStarted)action._codexHubrisStarted=true;return startAction.apply(this,arguments);};
    var endAction=BattleManager.endAction;
    BattleManager.endAction=function(){
      U.settleDeaths();var a=this._subject,action=this._action;
      if(a&&a.isActor()&&action&&action._codexHubrisStarted&&!action._codexHubrisFinished){action._codexHubrisFinished=true;if(a.isAlive()&&!action._forcing&&!action._tojiSuppressed)a._codexHubrisMoves=(a._codexHubrisMoves||0)+1;}
      return endAction.apply(this,arguments);
    };
    var endTurn=BattleManager.endTurn;
    BattleManager.endTurn=function(){var out=endTurn.apply(this,arguments);U.settleDeaths();var turn=$gameTroop.turnCount();if(this._phase==='turnEnd'&&U._round!==turn){U._round=turn;$gameParty.allMembers().forEach(function(a){var b=a._codexHubrisBuff;if(b&&turn>b.round){b.remaining--;if(b.remaining<=0)U.clearBuff(a);}});}return out;};
    U.clearReward=function(result){var troop=$gameTroop._troopId;if(result!==0||$gameMap.mapId()!==152||H.unknownHeartOrigin()!==38||(troop!==454&&troop!==455)||BattleManager._codexHubrisRewardRolled)return false;BattleManager._codexHubrisRewardRolled=true;if(Math.random()>=0.10)return false;$gameParty.gainItem($dataArmors[U.armorId],1,false);if(window.$&&$.toaster)$.toaster({message:'获得神武：狂妄！'});return true;};
    var endBattle=BattleManager.endBattle;
    BattleManager.endBattle=function(result){U.settleDeaths();if(result===0)U._ledger.forEach(function(e){e.item._codexHubrisFame=U.growth(e.item)+e.gain;U.describe(e.item);});U._running=false;U._ledger=[];$gameParty.allMembers().forEach(U.clearBuff);var out=endBattle.apply(this,arguments);U.clearReward(result);return out;};
    var load=DataManager.extractSaveContents;
    DataManager.extractSaveContents=function(){U._running=false;U._ledger=[];U._deaths=[];var out=load.apply(this,arguments);($dataArmors||[]).forEach(function(i){if(U.isGear(i)){U.normalize(i);U.describe(i);}});$gameParty.allMembers().forEach(U.clearBuff);U.unlockForge(false);return out;};
    // Native item help shows committed growth, this battle's pending growth,
    // and the actual remaining temporary attack benefit.

    U.helpView=function(i){
      var v=JsonEx.makeDeepCopy(i);U.describe(v);
      var pending=U.pending(i),a=$gameParty&&$gameParty.allMembers().filter(function(a){return U.gear(a)===i;})[0],b=a&&a._codexHubrisBuff,bonus=a&&U.activeBonus(a);
      if(pending)v.note+='\n<pos=APs text=本场成长：盛名＋'+pending+'层，胜利后保存 size=18 color=rgba(255,220,100,1) line=false align=0>';
      if(bonus)v.note+='\n<pos=APs text=当前增益：扬名使物理攻击×'+H.helpNumber(b.rate)+'；剩余'+b.remaining+'个完整回合'+($gameTroop.turnCount()===b.round?'（本回合不计）':'')+' size=18 color=rgba(255,220,100,1) line=false align=0>';
      RJO.HE.getDescParams(v,2);return H.groupHelpRows(v);
    };
    var help=Sprite_ItemHelp.prototype.setItem;
    Sprite_ItemHelp.prototype.setItem=function(i){return help.call(this,U.isGear(i)?U.helpView(i):i);};
    window.CodexDamageHooks.push({name:'hubris',build:function(x,t,f){
 var i=U.gear(x.subject());if(i&&x.isPhysical()&&[1,5].indexOf(x.item().damage.type)>=0)f.physicalDefenseRate*=U.isLeviathan(i)?.73:.82;
}});

  }



return installNativeHubrisRuntime.apply(this, arguments);
});
