// 【Codex·未经Claude检验】v0.03 魂灯进阶配方修复；未经claude检验。
// 货币合并与技能书整理（技能书货币商店整理方案 v0.1，用户 2026-10-09 确认）：
// - 天道币、逆天币、心法碎片并入肝帝积分（变量 206，1 个＝30 积分）；优秀/精良/史诗/神圣魂灯并入魂灯（原不朽魂灯）；
//   安慰奖 II 并入安慰奖券（原安慰奖 I）×1、III/IV ×1.5；金精铜钱并入诸神头颅 ×3；8 号当铺变身卡副本、免疫转换副本折成主书。
//   任何途径获得旧货币都在入包时折算；旧档读档时把背包一次性折算（记在 $gameSystem._codexEconomyV1）。
// - 固定数值书改百分比：技能备注 <CodexParamRate: 参数:百分比,...>，学会后该属性按总值 ×(1＋百分比)（dsPassiveSkill 的百分比只按无装备基础值算，太小）。
// - 方桌大厅「商店向导」：旧档读档时补上地图事件。
// 【Codex·未经Claude检验】 普通副本Boss熟练度提示只描述专属技能书，权能另由不朽存在奖励判定。
// v2（v0.5 发券递增与熟练度）：副本 Boss 胜利（公共事件 1439）按 Boss 所在层加发 层数÷3 张券；每个副本 Boss（敌群）累计胜利
//   1／10／50 次分别 +10／+30／+100 张，10 次后该 Boss 洪荒权能掉率 ×2、50 次后 ×3。记录在 $gameSystem._codexBossMastery。
// v3（S6 第二部分）：4 本顶级被动书从商店下架，改由指定副本 Boss 掉落（每场 5%×熟练度系数，本模块掷骰，不吃掉率加成）：
//   古龙普拉顿→九阳淬体图、哥布林太上皇劳勃→九秘:行字诀【强化版】、三清投影→炎黄后裔、恶·如来→传承升华。
window.CodexRuntime.register('installNativeEconomyRuntime',function(){
 'use strict';
 var E=window.CodexEconomy={version:3,BOOK_RATE:0.05,BOSS_BOOKS:{221:2240,377:2236,603:2237,604:2237,605:2237,695:2337},TICKET:1639,FLOOR_DIV:3,MASTERY:[[1,10,1],[10,30,2],[50,100,3]],SCORE:206,
  TO_SCORE:{2451:30,1919:30,1350:30},
  TO_ITEM:{184:[188,1],185:[188,1],186:[188,1],187:[188,1],2251:[2201,1],2301:[2201,1.5],2351:[2201,1.5],1234:[1233,3],
   1991:[1981,1],2495:[2475,1],2496:[2476,1],2497:[2477,1],2498:[2478,1],2499:[2479,1],2500:[2480,1],2501:[2481,1],2502:[2482,1],
   2503:[2483,1],2504:[2484,1],2505:[2485,1],2506:[2486,1],2508:[2509,1],2510:[2511,1],2512:[2513,1],2514:[2515,1],2516:[2517,1],
   2518:[2519,1],2520:[2521,1]},
  GUIDE_NOTE:'<CodexEconomy: guide>'};
 function num(v){v=Number(v);return isFinite(v)?v:0;}
 function addScore(n){$gameVariables.setValue(E.SCORE,num($gameVariables.value(E.SCORE))+n);}
 var _gain=Game_Party.prototype.gainItem;
 // 小数倍率（安慰奖 III/IV ×1.5）的零头累计在存档里，凑满一张再给
 function whole(target,q){var s=$gameSystem;if(!s)return Math.floor(q);var f=s._codexEcoFrac=s._codexEcoFrac||{},t=num(f[target])+q,n=Math.floor(t+1e-9);f[target]=t-n;return n;}
 E.redirect=function(party,item,amount){
  if(!item||!DataManager.isItem(item)||!(amount>0))return false;
  var id=item.id;
  if(E.TO_SCORE[id]){addScore(amount*E.TO_SCORE[id]);return true;}
  var t=E.TO_ITEM[id];
  if(t){var n=whole(t[0],amount*t[1]);if(n>0)_gain.call(party,$dataItems[t[0]],n,false);return true;}
  return false;};
 Game_Party.prototype.gainItem=function(item,amount,includeEquip){
  if(this===$gameParty&&E.redirect(this,item,amount))return;
  return _gain.apply(this,arguments);};
 E.convertInventory=function(){
  var items=$gameParty._items||{},log={};
  Object.keys(items).forEach(function(k){
   var id=Number(k),n=num(items[k]);if(!(n>0)||!(E.TO_SCORE[id]||E.TO_ITEM[id]))return;
   delete items[k];log[id]=n;
   if(E.TO_SCORE[id])addScore(n*E.TO_SCORE[id]);
   else{var t=E.TO_ITEM[id];_gain.call($gameParty,$dataItems[t[0]],Math.ceil(n*t[1]-1e-9),false);}
  });
  return log;};
 var _extract=DataManager.extractSaveContents;
 DataManager.extractSaveContents=function(contents){
  _extract.apply(this,arguments);
  try{if($gameSystem&&!$gameSystem._codexEconomyV1)$gameSystem._codexEconomyV1={at:Date.now(),converted:E.convertInventory()};}
  catch(e){console.error('货币折算失败',e);}};
 var _newGame=DataManager.setupNewGame;
 DataManager.setupNewGame=function(){_newGame.apply(this,arguments);$gameSystem._codexEconomyV1={at:Date.now(),converted:{}};};

 // 固定数值书改百分比（按总值）
 var RS=null,cache={};
 function rateSkills(){
  if(RS)return RS;RS={};
  ($dataSkills||[]).forEach(function(s){
   var m=s&&s.note&&/<CodexParamRate:\s*([^>]+)>/i.exec(s.note);if(!m)return;
   RS[s.id]=m[1].split(',').map(function(p){var a=p.split(':');return [num(a[0]),num(a[1])];}).filter(function(x){return x[0]>=0&&x[0]<8&&x[1];});});
  return RS;}
 E.paramRateBonus=function(actor,paramId){
  var sk=actor._skills||[],key=num(actor._codexPRv)+':'+sk.length,c=cache[actor.actorId()];
  if(!c||c.key!==key){var r=[0,0,0,0,0,0,0,0],T=rateSkills();sk.forEach(function(id){var t=T[id];if(t)t.forEach(function(x){r[x[0]]+=x[1];});});c=cache[actor.actorId()]={key:key,r:r};}
  return c.r[paramId]||0;};
 var _pr=Game_Actor.prototype.paramRate;
 Game_Actor.prototype.paramRate=function(paramId){
  var v=_pr.apply(this,arguments),b=E.paramRateBonus(this,paramId);
  return b?v*(1+b/100):v;};
 ['learnSkill','forgetSkill'].forEach(function(f){
  var o=Game_Actor.prototype[f];
  Game_Actor.prototype[f]=function(){this._codexPRv=num(this._codexPRv)+1;return o.apply(this,arguments);};});


 // ---- 副本 Boss：发券递增与熟练度 ----
 function bossFloor(){var H=window.CodexHonghuang;if(H&&H.bossFloor)return H.bossFloor();var Z=window.CodexZhenqi;return Z?Z.progressFloor():0;}
 E.masteryOf=function(troopId){var m=$gameSystem._codexBossMastery||{};return num(m[troopId]);};
 E.powerFactor=function(troopId){var n=E.masteryOf(troopId==null?$gameTroop._troopId:troopId),f=1;E.MASTERY.forEach(function(r){if(n>=r[0])f=r[2];});return f;};
 E.bossReward=function(){
  var t=num($gameTroop&&$gameTroop._troopId);if(!t)return null;
  var m=$gameSystem._codexBossMastery=$gameSystem._codexBossMastery||{},n=(m[t]=num(m[t])+1);
  var f=bossFloor(),extra=Math.floor(Math.max(0,f)/E.FLOOR_DIV),bonus=0,next=null;
  E.MASTERY.forEach(function(r){if(n===r[0])bonus+=r[1];if(!next&&n<r[0])next=r;});
  var total=extra+bonus;if(total>0)$gameParty.gainItem($dataItems[E.TICKET],total);
  var name=($dataTroops[t]&&$dataTroops[t].name||'').replace(/【[^】]*】/g,'').split(',')[0].trim();
  var msg=name+' 熟练度 '+n+' 次：抽奖券 +'+total+(extra?'（'+f+'层 +'+extra+(bonus?'，熟练度 +'+bonus:'')+'）':'')+(next?'，再打 '+(next[0]-n)+' 次领 +'+next[1]+(next[2]>1?'、专属书掉率×'+next[2]:''):'');
  if(window.$&&$.toaster)$.toaster({message:msg});
  var book=E.rollBossBook(t);
  return {troop:t,count:n,floor:f,extra:extra,bonus:bonus,book:book};};
 E.rollBossBook=function(t,rand){
  var id=E.BOSS_BOOKS[t];if(!id)return 0;rand=rand||Math.random;
  if(rand()<Math.min(1,E.BOOK_RATE*E.powerFactor(t))){$gameParty.gainItem($dataItems[id],1);if(window.$&&$.toaster)$.toaster({message:'副本Boss专属掉落：'+$dataItems[id].name+'！'});return id;}
  return 0;};
 // 旧档：方桌大厅补上「商店向导」
 var _oml=Scene_Map.prototype.onMapLoaded;
 Scene_Map.prototype.onMapLoaded=function(){
  if($dataMap&&$dataMap.events)$dataMap.events.forEach(function(ev){if(ev&&ev.note===E.GUIDE_NOTE&&!$gameMap._events[ev.id])$gameMap._events[ev.id]=new Game_Event($gameMap.mapId(),ev.id);});
  return _oml.apply(this,arguments);};
 // 【Codex·未经Claude检验】v0.03：货币合并后同步进阶材料，数量按原一比一折算。
 E.normalizeAdvanceCosts=function(){
  if(!window.$dataStarAdvancedOpt)return 0;var changed=0;
  $dataStarAdvancedOpt.forEach(function(row){if(!row||!Array.isArray(row.AdvancedItem))return;
   if(!row.AdvancedItem.some(function(pair){return pair[0]>=184&&pair[0]<=187;}))return;
   var costs=[],positions={};row.AdvancedItem.forEach(function(pair){var id=Number(pair[0]),count=Number(pair[1]);if(id>=184&&id<=187)id=188;
    if(Object.prototype.hasOwnProperty.call(positions,id))costs[positions[id]][1]+=count;else{positions[id]=costs.length;costs.push([id,count]);}
   });row.AdvancedItem=costs;changed++;
  });return changed;
 };
 E.normalizeAdvanceCosts();
 var costsLoaded=DataManager.isDatabaseLoaded;DataManager.isDatabaseLoaded=function(){var loaded=costsLoaded.apply(this,arguments);if(loaded)E.normalizeAdvanceCosts();return loaded;};

 // 【Codex·未经Claude检验】v0.08：大厅人族首领低阶、高阶功法分栏，旧档缓存页刷新。
 E.refreshManualShop=function(){
  if(!$gameMap||$gameMap.mapId()!==4||!window.$dataMap||!$dataMap.events[54])return;
  var event=$gameMap.event(54);if(!event)return;
  event._pageIndex=-2;event.refresh();
 };
 var manualShopLoaded=Scene_Map.prototype.onMapLoaded;
 Scene_Map.prototype.onMapLoaded=function(){var result=manualShopLoaded.apply(this,arguments);E.refreshManualShop();return result;};

 return E;
});
