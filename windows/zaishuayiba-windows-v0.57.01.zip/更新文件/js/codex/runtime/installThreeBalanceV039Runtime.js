// 【Codex·未经Claude检验】v0.39 legacy Vegetto weapon; preserve independent identity, cultivation, augments and absorbed affixes.
window.CodexRuntime.register('installThreeBalanceV039Runtime',function(){
 'use strict';
 var W=window,R=W.CodexThreeBalance39={version:39};
 function base(i){return Number(i&&(i.originalBaseItemId||i.baseItemId||i.id));}
 function number(v){return Number(parseFloat(v))||0;}
 function alias(o,k,fn){var old=o[k];if(typeof old==='function')o[k]=function(){return fn.call(this,old,arguments);};}
 R.normalize=function(i){
  if(!i||i.wtypeId===undefined||base(i)!==91||i._codexVegettoWeapon39===39)return false;
  if(W.CodexImportedEffects)CodexImportedEffects.normalize(i);
  var text=String(i.note||''),changed=false;
  function tag(key,oldValue,newValue,percent){
   var re=new RegExp('<'+key+':\\s*\\+?'+oldValue+(percent?'%':'')+'\\s*>','i');
   if(!re.test(text))return false;
   var all=new RegExp('<'+key+':\\s*([+\\-]?[\\d.]+)%?\\s*>','ig'),values=[],m;while((m=all.exec(text)))values.push(number(m[1]));
   text=text.replace(re,'<'+key+': '+(key.indexOf('Element Amplify')===0?'+':'')+newValue+(percent?'%':'')+'>');changed=true;
   i.meta=i.meta||{};var cur=i.meta[key];var sum=values.reduce(function(a,b){return a+b;},0),prior=cur===undefined?sum:values.length>1&&number(cur)===values[values.length-1]?sum:number(cur);i.meta[key]=String(prior+newValue-oldValue)+(percent?'%':'');return true;
  }
  tag('passiveHarmRi',1500,300,false);
  if(tag('Element Amplify 1',3000,500,true)){i.elementAmplify=i.elementAmplify||{};i.elementAmplify[1]=(i.elementAmplify[1]===undefined?30:Number(i.elementAmplify[1]))-25;}
  [9944,9945,9948,9949].forEach(function(sid){tag('SkillPass'+sid,1500,100,true);});
  var native=(i.traits||[]).filter(function(t){return t.code===22&&t.dataId===2&&Math.abs(t.value-10)<1e-9;})[0];if(native){native.value=3;changed=true;}
  text=text.replace('最终伤害+1500%','最终伤害+300%').replace('物理伤害+3000%','物理伤害+500%').replace('专属技能伤害+1500%','专属技能伤害+100%').replace('暴击率+1000%','暴击率+300%');
  i.note=text;i._codexVegettoWeapon39=39;
  if(changed){delete i.descParams;if(W.RJO&&RJO.HE&&RJO.HE.getDescParams)RJO.HE.getDescParams(i,1);}
  return changed;
 };
 R.sync=function(){
  var changed=new Set();(DataManager._independentWeapons||[]).forEach(function(i){if(R.normalize(i))changed.add(i);});
  if(W.$gameActors)($gameActors._data||[]).forEach(function(a){if(!a||!a.equips)return;var dirty=false;a.equips().forEach(function(i){if(R.normalize(i))changed.add(i);if(changed.has(i))dirty=true;});if(dirty){if(W.CodexQiyuBalance)CodexQiyuBalance.refreshActor(a);else a.refresh();}});
  if(changed.size){if(W.CodexAbyssMerchant)CodexAbyssMerchant.touch();if(W.CodexCombatPower)CodexCombatPower.clearCache();}
 };
 alias(DataManager,'extractSaveContents',function(old,args){var result=old.apply(this,args);R.sync();return result;});
 alias(DataManager,'registerNewItem',function(old,args){var result=old.apply(this,args);R.normalize(result);return result;});
 alias(Game_Party.prototype,'gainIndependentItem',function(old,args){var result=old.apply(this,args);(result||[]).forEach(R.normalize);return result;});
 ['changeEquip','forceChangeEquip'].forEach(function(k){alias(Game_Actor.prototype,k,function(old,args){R.normalize(args[1]);return old.apply(this,args);});});
});
