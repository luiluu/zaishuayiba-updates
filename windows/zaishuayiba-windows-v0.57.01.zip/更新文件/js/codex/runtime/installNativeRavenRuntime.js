// 【Codex·未经Claude检验】v0.29 渡鸦法宝生命／魔法调整。
// Extracted from the verified native runtime; installer order is maintained by main.js.
window.CodexRuntime.register("installNativeRavenRuntime", function() {
  function installNativeRavenRuntime() {
//=============================================================================
// 渡鸦原生数据库的运行时兼容层
// 角色、职业、技能与物品均由 data/*.json 加载；这里仅处理专属机制。
//=============================================================================
(function() {
    'use strict';

    var R = window.CodexRaven = window.CodexRaven || {};
    R.ACTOR_ID = 167;
    R.CLASS_ID = 165;
    // 4001 曾作为早期版本的普通武器编号保留；专属法宝现在使用
    // 不朽法宝商店同一套「防具型 Magic Weapon」规范。
    R.WEAPON_ID = 4001;
    R.ARTIFACT_ID = 4001;
    R.ASCENSION_ITEM_ID = 2901;
    R.HORN_ITEM_ID = 2902;
    R.HORN_COMMON_EVENT_ID = 9002;
    R.SKILL = { PECK: 10122, FEATHER: 10123, FEAST: 10124, JUDGMENT: 10125,
        SOULS: 10126, MYTH: 10127, FORGE: 10128, SOUL_LEDGER: 10137,
        LEGION: 10138, CROWN: 10139, MYTH_PASSIVE: 10170 };
    // Existing skills are distributed across level milestones.  Advancement
    // remains a second requirement for the stronger stages.
    R.SKILL_GATE = {
        10129: [5, 0], 10130: [10, 0], 10131: [15, 0],
        10123: [20, 1], 10132: [25, 0], 10124: [30, 2],
        10133: [35, 3], 10125: [40, 3], 10134: [45, 0],
        10126: [50, 4], 10138: [1, 0], 10139: [55, 3],
        10127: [1, 5], 10136: [60, 5], 10170: [1, 5]
    };
    // 每阶从零积累的铸印门槛；成功进阶清空本阶灵魂，窗口消耗进阶印。
    R.REQUIRE = [0, 3000, 12000, 35000, 80000, 150000];
    R.ARTIFACT_ICON = 9001;
    // 与原版 My_SkillTypeSwap 的技能分类保持一致。战斗栏位依次是
    // 「魔法／战技／其他／呼吸法」，菜单则额外完整显示被动及其余原版分类。
    // 专属伤害技能与神话封解均进入魔法栏。
    R.BATTLE_SKILL_TYPES = [2, 1, 5, 3];
    // 与作者的角色菜单保持相同的实际可用分类。7/8 在本项目中显示为
    // 「11/22」，原版角色不使用，不能因为渡鸦而额外暴露出来。
    R.MENU_SKILL_TYPES = [2, 1, 5, 3, 4];
    // 参照南宫恨阴阳扇的每级成长，将强度放回专属被动与技能联动。
    R.ARTIFACT_LEVEL_GROWTH = [12, 35, 0, 20, 45, 20, 45, 12];
    // 使用原游戏 CP_MagicWeapon 的法宝等级上限（当前插件参数为 888）。
    R.artifactMaxLevel = function() {
        return (window.CP && CP.MagicWeaponManager &&
            Number(CP.MagicWeaponManager.MAX_LEVEL)) || 888;
    };
    // 专属法宝的固定基础值在角色参数层结算，而非依赖独立装备对象。
    // 这样旧存档、随机词缀和法宝成长插件都无法把它误算成负面属性。
    R.ARTIFACT_BASE_BONUS = [100, 350, 0, 80, 150, 80, 90, 35];

    // 独立法宝图标，不改动原游戏巨大的 IconSet 图集。
    var _Window_Base_drawIcon = Window_Base.prototype.drawIcon;
    Window_Base.prototype.drawIcon = function(iconIndex, x, y) {
        if (iconIndex === R.ARTIFACT_ICON) {
            var bitmap = ImageManager.loadPicture('Raven_Artifact_Icon');
            if (bitmap.isReady()) this.contents.blt(bitmap, 0, 0, 32, 32, x, y);
            else if (bitmap.addLoadListener && this.refresh) bitmap.addLoadListener(this.refresh.bind(this));
            return;
        }
        _Window_Base_drawIcon.call(this, iconIndex, x, y);
    };

    // DreamX_RandomPrefixesSuffixes 将 6400 以上的图标编号视为“叠加
    // 图标”，并直接读取 $gameSystem.overlayIcons。渡鸦使用 9001 作为
    // 自定义法宝图标，因而在不朽法宝商店的放大图标绘制中会错误地把
    // 9001 当成随机词缀图标（9001 - 6400 = 2601），造成 undefined[2601]
    // 崩溃。这里在 DreamX 的大图绘制入口优先处理渡鸦图标。
    var _Window_Base_DXDrawLargeIcon = Window_Base.prototype.DXDrawLargeIcon;
    Window_Base.prototype.DXDrawLargeIcon = function() {
        if (this._item && this._item.iconIndex === R.ARTIFACT_ICON) {
            var bitmap = ImageManager.loadPicture('Raven_Artifact_Icon');
            var size = (window.Yanfly && Yanfly.Param && Yanfly.Param.ItemIconSize) || 64;
            if (bitmap.isReady()) {
                this.contents.blt(bitmap, 0, 0, bitmap.width, bitmap.height,
                    Math.floor((this.contentsWidth() - size) / 2), 0, size, size);
            } else if (bitmap.addLoadListener && this.refresh) {
                bitmap.addLoadListener(this.refresh.bind(this));
            }
            return;
        }
        if (_Window_Base_DXDrawLargeIcon) _Window_Base_DXDrawLargeIcon.call(this);
    };

    function raven(actor) { return actor && actor.isActor && actor.isActor() && actor.actorId() === R.ACTOR_ID; }
    function ravenSkillUnlocked(actor, skillId) {
        var gate = R.SKILL_GATE[skillId];
        return !gate || raven(actor) && Number(actor.level || actor._level || 1) >= gate[0] &&
            stage(actor) >= gate[1];
    }
    function hasRavenSkill(actor, skillId) {
        return ravenSkillUnlocked(actor, skillId) && !!(actor && (actor._skills && actor._skills.indexOf(skillId) >= 0 ||
            actor.isLearnedSkill && actor.isLearnedSkill(skillId)));
    }
    function soul(actor) { return Number(actor && actor._codexRavenSoul || 0); }
    function stage(actor) { return Number(actor && actor._codexRavenStage || 0); }
    function progress(actor) { return Math.min(1, Math.max(0, soul(actor) / R.REQUIRE[5])); }
    function isMyth(actor) { return raven(actor) && actor._codexRavenMythTurns > 0; }
    function mythPower(actor) { return isMyth(actor) && hasRavenSkill(actor, R.SKILL.MYTH_PASSIVE); }
    function active(actor) { return $gameParty && $gameParty.members().indexOf(actor) >= 0; }
    R.masteryCap = function() {
        var value = typeof $gameVariables !== 'undefined' && $gameVariables ?
            Number($gameVariables.value(8)) : 0;
        // 变量8由难度事件设定，其他地图还可追加技能等级上限。
        return Math.min(999, value > 0 ? Math.floor(value) : 8);
    };
    R.refreshMasteryLimit = function() {
        if (!$dataSkills) return;
        for (var id = R.SKILL.PECK; id <= R.SKILL.SOULS; id++) {
            if ($dataSkills[id]) $dataSkills[id].masteryMaxLevel = R.masteryCap();
        }
    };
    R.growthPools = function(actor) {
        var lv=Math.max(1,Math.min(70,Number(actor.level||actor._level||1)));
        var knots=[[1,0,0],[10,20,15],[25,80,60],[40,180,140],[55,300,240],[70,500,399]];
        for(var i=1;i<knots.length;i++)if(lv<=knots[i][0]){
            var a=knots[i-1],b=knots[i],p=(lv-a[0])/(b[0]-a[0]);
            return {critical:a[1]+p*(b[1]-a[1]),final:a[2]+p*(b[2]-a[2])};
        }
        return {critical:500,final:399};
    };
    // 【Claude·未经Codex检验】v0.53：成长池改在 refreshPassiveCache 之后叠加。
    // v0.51 起 refreshPassiveCache 开头会把 critHarmRi／globalHarmRi 复位为 0，原先加在 initPassiveCache 里的成长池会被清掉。
    var nativeRavenRefreshCache=Game_Actor.prototype.refreshPassiveCache;
    Game_Actor.prototype.refreshPassiveCache=function(){
        var out=nativeRavenRefreshCache.apply(this,arguments);
        if(raven(this)&&this._skills&&this._skills.indexOf(10137)>=0&&this._passiveCache){
            var p=R.growthPools(this);this._passiveCache.critHarmRi+=p.critical/100;
            this._passiveCache.globalHarmRi+=p.final/100;
        }
        return out;
    };
    R.legionStrikeRate = function(actor) {
        if (!raven(actor) || !hasRavenSkill(actor, R.SKILL.LEGION)) return 1;
        var index = Math.min(5, Math.max(0, stage(actor)));
        // Recalibrated attack basis; native final/critical pools now grow by level.
        return [6, 10, 20, 33, 66, 99][index] / 11;
    };
    // Five combat skills receive their own coefficient inside the attack/HP
    // base. This is not a global damage multiplier and does not scale defense.
    R.SKILL_COEFFICIENTS = {
        10122: [9, 6.9, 3.9, 2.0, 1.3, 1],
        10123: [0, 6.9, 3.9, 2.0, 1.3, 1],
        10124: [0, 0, 0.39, 0.19, 0.13, 0.1],
        10125: [0, 0, 0, 0.6, 0.39, 0.33],
        10126: [0, 0, 0, 0, 0.19, 0.2]
    };
    R.skillCoefficient = function(actor, skillId) {
        if (!raven(actor)) return 1;
        var rates = R.SKILL_COEFFICIENTS[skillId];
        return rates ? rates[Math.min(5, Math.max(0, stage(actor)))] : 1;
    };
    R.crownRate = function(actor) {
        if (!raven(actor) || !hasRavenSkill(actor, R.SKILL.CROWN)) return 1;
        var base = [1, 1, 1, 1.5, 1.5, 2][Math.min(5, Math.max(0, stage(actor)))];
        // 15万以后依然能成长，但不再靠线性加面板突破引擎的属性上限。
        var overflow = Math.max(0, soul(actor) - R.REQUIRE[5]);
        return stage(actor) >= 5 && hasRavenSkill(actor, 10136) ? base *
            (1 + 0.06 * Math.log(1 + overflow / R.REQUIRE[5]) / Math.LN2) : base;
    };

    R.defenseFactor = function(actor) {
        if (!raven(actor) || !hasRavenSkill(actor, 10130)) return 1;
        var p = progress(actor);
        var pierce = Math.min(0.90, 0.60 + 0.30 * p);
        if (mythPower(actor)) pierce = Math.min(0.95, pierce + 0.05);
        return 1 - pierce;
    };

    // Damage-pool redistribution scales the entire raw attack/defense basis.
    // Keep the stated penetration rate intact and normalize only its deduction.
    R.defenseDeduction = function(actor) {
        return R.defenseFactor(actor) / (raven(actor) && hasRavenSkill(actor, R.SKILL.LEGION) ? 11 : 1);
    };

    // 冥河成长倍率（用户 2026-10-07；2026-10-08 按数字规则取整，避开4）：按等级分段，使 70 级 15 万魂达到狂刀 1.4 倍，前中期不低于 0.6 倍。
    R.GROWTH = {"10": 16, "15": 35, "20": 50, "25": 33, "30": 27, "35": 191, "40": 22, "45": 6, "50": 7, "55": 3, "60": 1.2, "65": 1, "70": 2.66, "75": 2.66, "80": 2.66};
    R.growthRate = function(actor) {
        if (!raven(actor)) return 1;
        var lv = Number(actor.level || actor._level || 1), best = null;
        Object.keys(R.GROWTH).map(Number).sort(function(a, b) { return a - b; }).forEach(function(k) { if (best === null || lv >= k) best = k; });
        return Number(R.GROWTH[best]) || 1;
    };
    R.damageMultiplier = function(actor, item) {
        if (!raven(actor) || !item || !item.meta || !item.meta.CodexRavenDamage) return 1;
        var p = progress(actor);
        // 黑羽淬刃属于 10 级被动，未学会时不可提前享有其伤害增幅。
        var tempered = hasRavenSkill(actor, 10131);
        var magical = tempered ? 1 + 1.50 + p : 1;
        var darkness = tempered ? 1 + 2.00 + p : 1;
        var finalRate = tempered ? 1 + 1.50 * Math.min(1, (stage(actor) + p) / 5) : 1;
        if (hasRavenSkill(actor, 10136)) finalRate *= 1.10;
        if (mythPower(actor)) {
            magical += 1.00;
            darkness += 1.00;
            finalRate += 1.50;
        }
        var artifactRate = artifactEquipped(actor) ? 1.6 : 1;
        return (item.damage && item.damage.elementId === 9 ? darkness : magical) *
            finalRate * R.crownRate(actor) * artifactRate;
    };
    // Stable database prices at every rank. Existing native equipment and
    // mastery discounts remain authoritative; promotion never raises costs.
    function finishRavenDatabaseCompatibility() {
        if (!$dataActors || !$dataSkills || R._databaseInstalled) return;
        R._databaseInstalled = true;
        // 渡鸦在 Actors/Classes/Skills/Items/Armors 等原版 JSON 中。
        // 数据库加载期由原游戏插件统一解析备注，不再运行时造角色。
        if (!$dataActors[R.ACTOR_ID] || !$dataClasses[R.CLASS_ID] ||
                !$dataSkills[R.SKILL.PECK] || !$dataSkills[R.SKILL.MYTH_PASSIVE] ||
                !$dataArmors[R.ARTIFACT_ID]) {
            throw new Error('渡鸦数据库记录缺失，请同时覆盖 data 文件夹');
        }
        // 进阶窗口和角色图鉴使用 Star_ActorAdvanced 的表及 _AdvancedNum。
        // 逐阶登记五条原生记录，避免界面误认为最大进阶次数为 0。
        if (typeof $dataStarAdvancedOpt === 'undefined' || !Array.isArray($dataStarAdvancedOpt)) {
            throw new Error('原版角色进阶数据库尚未加载');
        }
        // 五阶沿用四阶已满足的 45 级门槛，不再额外要求 60 级。
        var ravenAdvanceLevels = [15, 25, 35, 45, 45];
        var ravenAdvanceSkills = [[10131], [10132], [10133], [10134],
            [R.SKILL.MYTH, R.SKILL.MYTH_PASSIVE]];
        for (var rank = 0; rank < 5; rank++) {
            if ($dataStarAdvancedOpt.some(function(entry) {
                return entry && entry.AdvancedActId === R.ACTOR_ID && entry.AdvancedActNum === rank;
            })) continue;
            $dataStarAdvancedOpt.push({
                id: $dataStarAdvancedOpt.length, name: '渡鸦·冥羽进阶',
                AdvancedActId: R.ACTOR_ID, AdvancedActNum: rank,
                AdvancedActNumMaX: 5, AdvancedActLevel: ravenAdvanceLevels[rank], AdvancedGold: 0,
                AdvancedItem: [[R.ASCENSION_ITEM_ID, 1]],
                AdvancedSkiId: ravenAdvanceSkills[rank], AdvancedForId: []
            });
        }

        var records = [$dataActors[R.ACTOR_ID], $dataClasses[R.CLASS_ID], $dataWeapons[R.WEAPON_ID], $dataArmors[R.ARTIFACT_ID], $dataItems[R.ASCENSION_ITEM_ID], $dataItems[R.HORN_ITEM_ID]];
        for (var recordSkillId = R.SKILL.PECK; recordSkillId <= R.SKILL.CROWN; recordSkillId++) {
            if ($dataSkills[recordSkillId]) records.push($dataSkills[recordSkillId]);
        }
        records.push($dataSkills[R.SKILL.MYTH_PASSIVE]);
        for (var r = 0; r < records.length; r++) {
            if (DataManager.extractMetadata) DataManager.extractMetadata(records[r]);
            else records[r].meta = records[r].meta || {};
        }

        // 关键兼容层：所有原版插件都在本插件之前完成了数据库注释解析。
        // 新建角色若只保留 RPG Maker 的基础字段，编队、状态页、战斗和
        // 技能树中的插件会直接读取 undefined（如 plusXParams、lifeSteal、
        // weaponUnleash 等）。以已被原版完整解析的同类记录为模板，只补
        // 缺失字段，保留渡鸦自己的职业、技能、属性和备注。
        function cloneRuntimeField(value) {
            if (Array.isArray(value)) return value.map(cloneRuntimeField);
            if (value && typeof value === 'object') {
                var copy = {};
                Object.keys(value).forEach(function(key) { copy[key] = cloneRuntimeField(value[key]); });
                return copy;
            }
            return value;
        }
        function firstRuntimeTemplate(group, preferredId) {
            if (group && group[preferredId]) return group[preferredId];
            if (!group) return null;
            for (var index = 0; index < group.length; index++) if (group[index]) return group[index];
            return null;
        }
        function inheritRuntimeFields(target, template) {
            if (!target || !template) return target;
            Object.keys(template).forEach(function(key) {
                if (target[key] === undefined) target[key] = cloneRuntimeField(template[key]);
            });
            return target;
        }
        inheritRuntimeFields($dataActors[R.ACTOR_ID], firstRuntimeTemplate($dataActors, 166));
        inheritRuntimeFields($dataClasses[R.CLASS_ID], firstRuntimeTemplate($dataClasses, 164));
        inheritRuntimeFields($dataWeapons[R.WEAPON_ID], firstRuntimeTemplate($dataWeapons, 1));
        inheritRuntimeFields($dataArmors[R.ARTIFACT_ID], firstRuntimeTemplate($dataArmors, 1));
        inheritRuntimeFields($dataItems[R.ASCENSION_ITEM_ID], firstRuntimeTemplate($dataItems, 1));
        inheritRuntimeFields($dataItems[R.HORN_ITEM_ID], firstRuntimeTemplate($dataItems, 1));
        for (var templateSkillId = R.SKILL.PECK; templateSkillId <= R.SKILL.CROWN; templateSkillId++) {
            if ($dataSkills[templateSkillId]) inheritRuntimeFields($dataSkills[templateSkillId], firstRuntimeTemplate($dataSkills, 1));
        }
        // HelpExtend、YEP_ShopMenuCore 与 DreamX 都是在静态数据库加载时
        // 给物品补运行时字段。渡鸦的号角/法宝在那之后创建，若不手动
        // 补齐：商店详情会读取 undefined.descParams，而购买会读取
        // undefined.DXRPSAffixChoices。专属物品不参与随机前后缀，故
        // 空数组既满足 DreamX 的数据契约，也明确使其返回 false。
        function installRuntimeItemFields(record, type) {
            // YEP_ItemCore 的背包详情页会直接调用 infoTextTop.split()。
            // 静态物品由其数据库读取器赋初值；运行时物品必须显式补齐。
            record.infoTextTop = record.infoTextTop === undefined ? '' : record.infoTextTop;
            record.infoTextBottom = record.infoTextBottom === undefined ? '' : record.infoTextBottom;
            record.infoEval = record.infoEval === undefined ? '' : record.infoEval;
            record.descParams = record.descParams || [];
            record.pos = record.pos || [1, 2, 2, 2, 2];
            record.DXRPSAffixChoices = record.DXRPSAffixChoices || [];
            record.DXRPSAugmentChoices = record.DXRPSAugmentChoices || [];
            record.DXRPSChosenAugments = record.DXRPSChosenAugments || [];
            if (window.RJO && RJO.HE && RJO.HE.getDescParams) {
                RJO.HE.getDescParams(record, type);
            }
        }
        installRuntimeItemFields($dataWeapons[R.WEAPON_ID], 1);
        installRuntimeItemFields($dataArmors[R.ARTIFACT_ID], 2);
        installRuntimeItemFields($dataItems[R.ASCENSION_ITEM_ID], 0);
        installRuntimeItemFields($dataItems[R.HORN_ITEM_ID], 0);

        // CP_MagicWeapon 仅在 DataManager.isDatabaseLoaded 的首次回调中
        // 解析静态数据库。渡鸦法宝是在那之后生成的，因而要复现该解析
        // 结果；否则备注有成长标签但升级不加属性、详情也无法读取等级。
        function installArtifactMagicWeaponFields(record) {
            if (!record) return record;
            record.initLevel = 1;
            record.level = Number(record.level || record.initLevel);
            record.exp = Number(record.exp || 0);
            record.expFormula = record.expFormula || null;
            record.maxLevel = R.artifactMaxLevel();
            record.useExp = Number(record.useExp || (window.CP && CP.MagicWeaponManager && CP.MagicWeaponManager.USE_EXP) || 1);
            record.equipLevelUpEffect = record.equipLevelUpEffect || null;
            record.paramPlusPerLevel = R.ARTIFACT_LEVEL_GROWTH.slice();
            record._isMagicWeaponCache = true;
            return record;
        }
        installArtifactMagicWeaponFields($dataArmors[R.ARTIFACT_ID]);
        // 同类原版专属法宝没有 ItemCore 额外文字块，装备基础数值、
        // 法宝等级与词条由现有窗口和插件解析，不另造一套信息界面。
        $dataArmors[R.ARTIFACT_ID].infoTextTop = '';
        $dataArmors[R.ARTIFACT_ID].infoTextBottom = '';
        $dataItems[R.HORN_ITEM_ID].infoTextTop = '使用后渡鸦加入队伍，并获得专属法宝「冥河断罪镰」。';

        // 兼容已购买的旧版独立法宝：它们已被复制进存档，不能只修复
        // 静态原型。读取或装备时统一补数据，不重置玩家已有的等级/经验。
        function isRavenArtifact(record) {
            return record && (record.baseItemId === R.ARTIFACT_ID ||
                (record.id === R.ARTIFACT_ID && record.etypeId === 13));
        }
        function isRavenHorn(record) {
            return record && (record.baseItemId === R.HORN_ITEM_ID ||
                (record.id === R.HORN_ITEM_ID && record.itypeId === 1 && /渡鸦/.test(record.name || '')));
        }
        function repairRavenArtifact(record) {
            if (!isRavenArtifact(record)) return record;
            if (record._codexRavenDisplayRevision !== 8) installRuntimeItemFields(record, 2);
            var oldLevel = record.level;
            var oldExp = record.exp;
            installArtifactMagicWeaponFields(record);
            if (oldLevel !== undefined && Number(oldLevel) > 0) record.level = Number(oldLevel);
            if (oldExp !== undefined && Number(oldExp) >= 0) record.exp = Number(oldExp);
            // 保留旧法宝等级/经验，统一旧独立装备的成长与新词条说明。
            record.note = $dataArmors[R.ARTIFACT_ID].note;
            record.description = $dataArmors[R.ARTIFACT_ID].description;
            if (DataManager.extractMetadata) DataManager.extractMetadata(record);
            record.meta['Max Level'] = String(R.artifactMaxLevel());
            // 独立法宝来自旧存档时没有 ItemCore 的详情缓存；以静态
            // 原型为准补回，确保背包和装备页都显示同一组成长说明。
            record.infoTextTop = $dataArmors[R.ARTIFACT_ID].infoTextTop;
            record.infoTextBottom = $dataArmors[R.ARTIFACT_ID].infoTextBottom;
            record.params = [0, 0, 0, 0, 0, 0, 0, 0];
            record.traits = $dataArmors[R.ARTIFACT_ID].traits.map(function(trait) {
                return { code: trait.code, dataId: trait.dataId, value: trait.value };
            });
            if (record._codexRavenDisplayRevision !== 8 && window.RJO && RJO.HE && RJO.HE.getDescParams) {
                RJO.HE.getDescParams(record, 2);
                record._codexRavenDisplayRevision = 8;
            }
            return record;
        }
        function repairRavenRuntimeItem(record) {
            if (isRavenArtifact(record)) return repairRavenArtifact(record);
            if (isRavenHorn(record)) {
                installRuntimeItemFields(record, 0);
                record.infoTextTop = $dataItems[R.HORN_ITEM_ID].infoTextTop || '';
                record.infoTextBottom = $dataItems[R.HORN_ITEM_ID].infoTextBottom || '';
            }
            return record;
        }
        R.repairRuntimeItem = repairRavenRuntimeItem;
        var _Game_Item_object_CodexRaven = Game_Item.prototype.object;
        Game_Item.prototype.object = function() {
            return repairRavenRuntimeItem(_Game_Item_object_CodexRaven.call(this));
        };
        // YEP_X_MoreCurrencies 只会在数据库加载期初始化这些字段。渡鸦
        // 记录在加载完成后创建，因此必须完整补齐（不能只补 itemBuyPrices）。
        function installCurrencyFields(record) {
            // YEP_CoreEngine 的 maxItems 直接读取 item.maxItem；运行时创建
            // 的号角没有经过原版数据库解析，传入 undefined 会在商店数量
            // 窗口的 toGroup/toLocaleString 中崩溃。
            record.maxItem = Number(record.maxItem || 99);
            record.proxyBuy = 0;
            record.variableBuyPrice = record.variableBuyPrice || {};
            record.variableBuyPrices = record.variableBuyPrices || [];
            record.variableSellPrice = record.variableSellPrice || {};
            record.variableSellPrices = record.variableSellPrices || [];
            record.itemBuyPrice = record.itemBuyPrice || {};
            record.itemBuyPrices = record.itemBuyPrices || [];
            record.itemSellPrice = record.itemSellPrice || {};
            record.itemSellPrices = record.itemSellPrices || [];
            record.weaponBuyPrice = record.weaponBuyPrice || {};
            record.weaponBuyPrices = record.weaponBuyPrices || [];
            record.weaponSellPrice = record.weaponSellPrice || {};
            record.weaponSellPrices = record.weaponSellPrices || [];
            record.armorBuyPrice = record.armorBuyPrice || {};
            record.armorBuyPrices = record.armorBuyPrices || [];
            record.armorSellPrice = record.armorSellPrice || {};
            record.armorSellPrices = record.armorSellPrices || [];
        }
        records.forEach(installCurrencyFields);
        var horn = $dataItems[R.HORN_ITEM_ID];
        horn.itemBuyPrice = { 188: 10 }; horn.itemBuyPrices = [188];
        horn.itemSellPrice = { 188: 1 }; horn.itemSellPrices = [188];
        // KMS 库存插件同样早于运行时物品解析；明确建立不朽号角的
        // 一次性库存，避免显示“售完”或因缺失字段异常。
        horn.shopStockCountMax = 1;
        horn.shopStockSupplyInterval = 0;
        horn.shopStockSupplyMode = 0;
        var artifact = $dataArmors[R.ARTIFACT_ID];
        // 不再让独立法宝对象的 params 参与基础属性结算；其基础值由下方
        // Game_Actor.paramPlus 统一提供，旧存档物品也会在读取时同步修复。
        artifact.params = [0, 0, 0, 0, 0, 0, 0, 0];
        artifact.variableBuyPrice = { 213: 30 }; artifact.variableBuyPrices = [213];
        artifact.variableSellPrice = { 213: 1 }; artifact.variableSellPrices = [213];
        artifact.shopStockCountMax = 1;
        artifact.shopStockSupplyInterval = 0;
        artifact.shopStockSupplyMode = 0;
        for (var sid = R.SKILL.PECK; sid <= R.SKILL.CROWN; sid++) {
            var ravenSkill = $dataSkills[sid];
            if (!ravenSkill) continue;
            ravenSkill.hpCost = ravenSkill.hpCost || 0;
            ravenSkill.hpCostPer = ravenSkill.hpCostPer || 0;
            ravenSkill.mpCostPer = ravenSkill.mpCostPer || 0;
            ravenSkill.tpCostPer = ravenSkill.tpCostPer || 0;
            ravenSkill.hpCostEval = ravenSkill.hpCostEval || '';
            ravenSkill.mpCostEval = ravenSkill.mpCostEval || '';
            ravenSkill.tpCostEval = ravenSkill.tpCostEval || '';
            ravenSkill.useItemCost = ravenSkill.useItemCost || [];
            ravenSkill.useWeaponCost = ravenSkill.useWeaponCost || [];
            ravenSkill.useArmorCost = ravenSkill.useArmorCost || [];
            // 与当前难度的变量8同步，含地图奖励额外提高的等级上限。
            ravenSkill.masteryMaxLevel = ravenSkill.meta && ravenSkill.meta.CodexRavenDamage ? R.masteryCap() : 0;
            ravenSkill.masteryFormula = function(level) { return 8 + level * 4; };
            ravenSkill.masteryDamage = function(value, level) { return value * (1 + level * 0.08); };
            ravenSkill.masteryMpCost = function(cost, level) { return Math.max(0, Math.floor(cost * (1 - level * 0.03))); };
            ravenSkill.masteryTpCost = function(cost, level) { return Math.max(0, Math.floor(cost * (1 - level * 0.02))); };
            ravenSkill.masteryHpCost = function(cost) { return cost; };
            ravenSkill.masteryCooldown = function(turns) { return turns; };
            if (DataManager.extractMetadata) DataManager.extractMetadata(ravenSkill);
            else ravenSkill.meta = ravenSkill.meta || {};
            // HelpExtend 只在原版静态数据库加载时解析 <pos=...> 技能
            // 详情。运行时创建的渡鸦技能必须主动走同一解析器，否则帮助
            // 窗口只会显示名称、品质和 MP 消耗，所有机制说明均为空白。
            if (window.RJO && RJO.HE && RJO.HE.getDescParams) {
                RJO.HE.getDescParams(ravenSkill, 3);
            }
        }
        R.refreshMasteryLimit();
    }

    var _DataManager_isDatabaseLoaded = DataManager.isDatabaseLoaded;
    DataManager.isDatabaseLoaded = function() { var ok = _DataManager_isDatabaseLoaded.call(this); if (ok) finishRavenDatabaseCompatibility(); return ok; };

    // ItemCore 的背包说明窗口不会回退到空字符串，而是直接对
    // infoTextTop/infoTextBottom 调用 split()。旧存档中的独立法宝/号角
    // 在光标移到其上之前没有机会经过物品迁移，故在 UI 边界再做一次
    // 无副作用的兜底；不会影响其他物品的原有说明。
    if (typeof Window_ItemInfo !== 'undefined') {
        function prepareRavenItemInfo(item) {
            if (!item) return;
            if (R.repairRuntimeItem) R.repairRuntimeItem(item);
            var isArtifact = item.etypeId === 13 && (item.baseItemId === R.ARTIFACT_ID || item.id === R.ARTIFACT_ID);
            var isHorn = item.itypeId === 1 && (item.baseItemId === R.HORN_ITEM_ID || (item.id === R.HORN_ITEM_ID && /渡鸦/.test(item.name || '')));
            if (!isArtifact && !isHorn) return;
            item.infoTextTop = item.infoTextTop == null ? '' : String(item.infoTextTop);
            item.infoTextBottom = item.infoTextBottom == null ? '' : String(item.infoTextBottom);
            item.infoEval = item.infoEval == null ? '' : String(item.infoEval);
        }
        var _Window_ItemInfo_drawInfoTextTop_CodexRaven = Window_ItemInfo.prototype.drawInfoTextTop;
        if (_Window_ItemInfo_drawInfoTextTop_CodexRaven) {
            Window_ItemInfo.prototype.drawInfoTextTop = function(dy) {
                prepareRavenItemInfo(this._item);
                return _Window_ItemInfo_drawInfoTextTop_CodexRaven.call(this, dy);
            };
        }
        var _Window_ItemInfo_drawInfoTextBottom_CodexRaven = Window_ItemInfo.prototype.drawInfoTextBottom;
        if (_Window_ItemInfo_drawInfoTextBottom_CodexRaven) {
            Window_ItemInfo.prototype.drawInfoTextBottom = function(dy) {
                prepareRavenItemInfo(this._item);
                return _Window_ItemInfo_drawInfoTextBottom_CodexRaven.call(this, dy);
            };
        }
    }

    function setupRaven(actor) {
        if (!raven(actor)) return;
        // 旧版本的渡鸦曾借用职业 1。迁移既有存档，并移除该职业遗留的
        // 狗逍遥技能，避免在技能菜单、图鉴和战斗中混入无关条目。
        if (actor._classId !== R.CLASS_ID && actor.changeClass) actor.changeClass(R.CLASS_ID, true);
        var legacyClassOneSkills = [160, 311, 502, 1746];
        if (actor._skills) actor._skills = actor._skills.filter(function(id) { return legacyClassOneSkills.indexOf(id) < 0; });
        actor._codexRavenSoul = Number(actor._codexRavenSoul || 0);
        actor._codexRavenStage = Math.min(5, Math.max(0, Number(actor._codexRavenStage || 0),
            Number(actor._AdvancedNum || 0)));
        actor._AdvancedNum = actor._codexRavenStage;
        if (actor._codexRavenForgedStage === undefined) actor._codexRavenForgedStage = -1;
        actor._codexRavenResidue = Number(actor._codexRavenResidue || 0);
        actor._codexRavenMythTurns = 0;
        // 基础被动由职业提供；强化被动与专属战技随进阶次数开放。
        // 灵魂仅影响铸印和持续成长，不再充当进阶的附加条件。
        var all = [];
        var learnings = ($dataClasses[R.CLASS_ID] && $dataClasses[R.CLASS_ID].learnings) || [];
        var actorLevel = Number(actor.level || actor._level || 1);
        learnings.forEach(function(learning) {
            if (learning && Number(learning.level || 1) <= actorLevel &&
                    ravenSkillUnlocked(actor, learning.skillId)) all.push(learning.skillId);
        });
        // 某些技能/装备插件会覆写 isLearnedSkill，使运行时生成角色的
        // 初始技能无法写入。直接保证 _skills 中存在 ID，再调用原有学习
        // 接口以刷新各插件缓存。
        actor._skills = (actor._skills || []).filter(function(id) {
            if (id === 10168) return false; // v6 reserves this ID for Nanoha
            if (id === R.SKILL.MYTH_PASSIVE) return all.indexOf(id) >= 0;
            return id < R.SKILL.PECK || id > R.SKILL.CROWN || all.indexOf(id) >= 0;
        });
        all.forEach(function(id) {
            if (actor._skills.indexOf(id) < 0) actor._skills.push(id);
            if (!actor.isLearnedSkill(id)) actor.learnSkill(id);
        });
        actor._skills.sort(function(a, b) { return a - b; });
        if (!hasRavenSkill(actor, 10132)) actor._codexRavenResidue = 0;
        if (!hasRavenSkill(actor, 10133)) actor._codexRavenHunter = false;
        // 直接移除旧存档的越阶技能后，同步原版被动插件的属性缓存。
        if (actor.refreshPassiveSkillCache) actor.refreshPassiveSkillCache();
        if (actor.initPassiveCache && actor.refreshPassiveCache) {
            actor.initPassiveCache();
            actor.refreshPassiveCache();
        }
        // Old saves can retain krz/BPC physical parameter caches. Invalidate them
        // once when adopting the mage build; souls, levels and mastery stay intact.
        if (actor._codexRavenMageRevision !== 1) {
            actor._codexRavenMageRevision = 1;
            actor.need_refresh = true;
            actor.refresh();
        }
    }
    var _Game_Actor_setup = Game_Actor.prototype.setup;
    Game_Actor.prototype.setup = function(actorId) { _Game_Actor_setup.call(this, actorId); setupRaven(this); };
    var _Game_Actor_levelUp_CodexRaven = Game_Actor.prototype.levelUp;
    Game_Actor.prototype.levelUp = function() {
        _Game_Actor_levelUp_CodexRaven.call(this);
        if (raven(this)) setupRaven(this);
    };
    var _Game_Actor_meetsSkillConditions_CodexRaven = Game_Actor.prototype.meetsSkillConditions;
    Game_Actor.prototype.meetsSkillConditions = function(skill) {
        return !(raven(this) && skill && !ravenSkillUnlocked(this, skill.id)) &&
            _Game_Actor_meetsSkillConditions_CodexRaven.call(this, skill);
    };
    var _Game_Actor_skillMasteryLevel_CodexRaven = Game_Actor.prototype.skillMasteryLevel;
    if (_Game_Actor_skillMasteryLevel_CodexRaven) {
        Game_Actor.prototype.skillMasteryLevel = function(skill) {
            var level = _Game_Actor_skillMasteryLevel_CodexRaven.call(this, skill);
            var id = typeof skill === 'number' ? skill : skill && skill.id;
            if (!raven(this) || id < R.SKILL.PECK || id > R.SKILL.SOULS) return level;
            return Math.min(level, R.masteryCap());
        };
    }
    var _Game_Actor_battlerName = Game_Actor.prototype.battlerName;
    Game_Actor.prototype.battlerName = function() {
        if (raven(this)) return isMyth(this) && $gameParty && $gameParty.inBattle() ?
            'Raven_Mythic_SV' : 'Raven_Normal_SV';
        return _Game_Actor_battlerName.call(this);
    };
    // 渡鸦的受击/濒死帧在战斗缩放后会显得持续俯伏。只替换渡鸦的
    // 显示动作；实际伤害、生命和死亡判定均保持原样。闪避为单次动作，
    // 播完会由引擎恢复待机；低生命则保持站立待机。
    var _Sprite_Actor_startMotion_CodexRaven = Sprite_Actor.prototype.startMotion;
    Sprite_Actor.prototype.startMotion = function(motionType) {
        if (this._actor && raven(this._actor)) {
            if (motionType === 'damage') motionType = 'evade';
            else if (motionType === 'dying') motionType = 'wait';
        }
        _Sprite_Actor_startMotion_CodexRaven.call(this, motionType);
    };
    var _Game_Actor_characterName_CodexRaven = Game_Actor.prototype.characterName;
    Game_Actor.prototype.characterName = function() {
        // 神话形态由战斗技能触发，仅改变战斗图，地图始终用普通形态。
        if (raven(this)) return '$Raven_Normal';
        return _Game_Actor_characterName_CodexRaven.call(this);
    };

    // 渡鸦披风在三帧间的变化较大，稍延长地图步行帧停留时间；
    // 只影响渡鸦作为队长或跟随者，不改全队移动速度和其他角色动画。
    var _Game_CharacterBase_animationWait_CodexRaven = Game_CharacterBase.prototype.animationWait;
    Game_CharacterBase.prototype.animationWait = function() {
        var wait = _Game_CharacterBase_animationWait_CodexRaven.call(this);
        var walkingActor = this.actor && this.actor();
        if (!walkingActor && typeof $gamePlayer !== 'undefined' && this === $gamePlayer &&
                $gameParty && $gameParty.leader) walkingActor = $gameParty.leader();
        return raven(walkingActor) ? Math.round(wait * 1.35) : wait;
    };

    // My_SkillTypeSwap 对原版角色重写了分类列表。渡鸦走同一套列表：
    // 菜单显示完整职业分类；战斗显示作者原本可左右切换的四个战斗栏。
    var _Game_Actor_addedSkillTypes_CodexRaven = Game_Actor.prototype.addedSkillTypes;
    Game_Actor.prototype.addedSkillTypes = function() {
        if (raven(this)) return ($gameParty && $gameParty.inBattle && $gameParty.inBattle()) ?
            R.BATTLE_SKILL_TYPES.slice() : R.MENU_SKILL_TYPES.slice();
        return _Game_Actor_addedSkillTypes_CodexRaven.call(this);
    };
    var _Game_Actor_addedSkillTypesForMenu_CodexRaven = Game_Actor.prototype.addedSkillTypesForMenu;
    Game_Actor.prototype.addedSkillTypesForMenu = function() {
        if (raven(this)) return R.MENU_SKILL_TYPES.slice();
        return _Game_Actor_addedSkillTypesForMenu_CodexRaven ?
            _Game_Actor_addedSkillTypesForMenu_CodexRaven.call(this) : this.addedSkillTypes();
    };

    // Explicit commands expose magic immediately, including existing saves.
    // Empty _skillTypes disables the old one-row left/right category pager.
    var _Window_ActorCommand_addSkillCommands_CodexRaven = Window_ActorCommand.prototype.addSkillCommands;
    Window_ActorCommand.prototype.addSkillCommands = function() {
        if (this._actor && raven(this._actor)) {
            this._skillTypes = [];
            var w = this;
            [2,1,5].forEach(function(id) {
                w.addCommand($dataSystem.skillTypes[id] || '技能', 'skill', true, id);
            });
            return;
        }
        _Window_ActorCommand_addSkillCommands_CodexRaven.call(this);
    };
    if (typeof Sprite_WindowArrow !== 'undefined') {
        var nativeArrowOpacity = Sprite_WindowArrow.prototype.updateOpacity;
        Sprite_WindowArrow.prototype.updateOpacity = function() {
            var a = this._parent && this._parent._actor;
            if (a && (a.actorId() === 167 || a.actorId() === 173)) {
                this.opacity = 0; return;
            }
            return nativeArrowOpacity.apply(this, arguments);
        };
    }

    // 被动应在菜单的「被动」分类中可见；其原版 <Hide in Battle> 注释会
    // 自行将其从战斗技能窗排除，不能再用全局过滤器把它从菜单抹掉。
    var _Window_SkillList_includes = Window_SkillList.prototype.includes;
    Window_SkillList.prototype.includes = function(item) {
        return _Window_SkillList_includes.call(this, item);
    };
    // 在菜单的被动技能帮助框中实时显示当前存档的灵魂，而非写死到数据库。
    var _Window_SkillList_updateHelp_CodexRaven = Window_SkillList.prototype.updateHelp;
    Window_SkillList.prototype.updateHelp = function() {
        _Window_SkillList_updateHelp_CodexRaven.call(this);
        if (!this._helpWindow || !this.item() || this.item().id !== R.SKILL.SOUL_LEDGER || !raven(this._actor)) return;
        var next = Math.min(5, stage(this._actor) + 1);
        var seals = $gameParty ? $gameParty.numItems($dataItems[R.ASCENSION_ITEM_ID]) : 0;
        var destination = stage(this._actor) >= 5 ? '已完成五阶；灵魂可继续积累' :
            '本阶达' + R.REQUIRE[next].toLocaleString() + '魂得印；进阶后清零';
        this._helpWindow.setText('灵魂：' + soul(this._actor).toLocaleString() +
            '　进阶：' + stage(this._actor) + '/5　进阶印：' + seals + '\n' + destination);
    };

    // 法宝随灵魂力成长：基础属性和灵魂成长均在角色参数层结算。
    function artifactEquipped(actor) {
        return raven(actor) && actor.equips && actor.equips().some(function(item) {
            return item && (item.baseItemId === R.ARTIFACT_ID || item.id === R.ARTIFACT_ID) &&
                item.etypeId === 13;
        });
    }
    R.artifactMagicAttackBonus = function(actor) {
        if (!artifactEquipped(actor)) return 0;
        return Math.floor(stage(actor) * 50 + soul(actor) * (0.02 + stage(actor) * 0.006));
    };
    R.artifactMpBonus = function(actor) {
        if (!artifactEquipped(actor)) return 0;
        return Math.floor(stage(actor) * 400 + soul(actor) * (0.04 + stage(actor) * 0.008));
    };
    var _Game_Actor_paramPlus = Game_Actor.prototype.paramPlus;
    Game_Actor.prototype.paramPlus = function(paramId) {
        var value = _Game_Actor_paramPlus.call(this, paramId);
        if (artifactEquipped(this)) value += R.ARTIFACT_BASE_BONUS[paramId] || 0;
        if (paramId === 4) value += R.artifactMagicAttackBonus(this);
        if (paramId === 1) value += R.artifactMpBonus(this);
        return value;
    };

    R.recruit = function() {
        if (!$gameSystem || !$gameParty) return false;
        if (!$gameParty.members().some(function(member) { return member && member.actorId() === R.ACTOR_ID; })) {
            $gameParty.addActor(R.ACTOR_ID);
        }
        var actor = $gameActors.actor(R.ACTOR_ID);
        setupRaven(actor);
        // The artifact is a join reward, not a load-time gift.  Existing
        // owners never receive a duplicate merely by using another horn.
        if (!$gameParty.hasItem($dataArmors[R.ARTIFACT_ID], true)) {
            $gameParty.gainItem($dataArmors[R.ARTIFACT_ID], 1, false);
        }
        $gameSystem._codexRavenJoined = true;
        if (window.$ && $.toaster) $.toaster({ message: '渡鸦加入队伍，获得专属法宝：冥河断罪镰！' });
        return true;
    };
    function restoreRavenState() {
        // Loading or starting a game must never insert a party member or a
        // reward.  We only initialise a Raven who already exists in the save.
        if (!$gameActors) return;
        var actor = $gameActors.actor(R.ACTOR_ID);
        if (actor) { setupRaven(actor); awardRavenAdvanceSeal(actor); }
    }
    // 存档中的定向装备配方只在首次读取该存档时加工。调用游戏自带的
    // DreamX 词条合成和 ItemCore 独立装备登记，不另造装备种类或词条。
    function applySavedEquipmentRecipes() {
        var recipe = $gameSystem && $gameSystem._codexTeamGearRecipeV1;
        if (!recipe || recipe.done || !Array.isArray(recipe.roles)) return;
        if (!window.DreamX || !DreamX.RandomPrefixSuffix ||
                !DreamX.RandomPrefixSuffix.combineWithBaseItem ||
                !DataManager.processYanflyTags || !DataManager.registerNewItem) {
            throw new Error('存档装备配方需要游戏原有的 DreamX 与 ItemCore 插件');
        }
        var ranges = [[3011, 3160], [4338, 4344], [4800, 4896], [4897, 4901]];
        function makeNativeEquip(baseId, ids, bonuses) {
            if (!Array.isArray(ids) || ids.length !== 6 ||
                    !Array.isArray(bonuses) || bonuses.length !== 8) {
                throw new Error('宝宝和圣器的词条或属性数量错误');
            }
            // 2 Mod + 1 太古 + 2 神话 + 1 混沌神话，全部取自原版防具词条。
            var slots = [0, 0, 1, 2, 2, 3];
            var base = $dataArmors[baseId];
            var item = JSON.parse(JSON.stringify(base));
            item.note = item.note.replace(/<Prefixes>[\s\S]*?<\/Prefixes>\s*/i, '');
            item.DXRPSAffixChoices = [];
            item.DXRPSAugmentChoices = item.DXRPSAugmentChoices || [];
            for (var j = 0; j < ids.length; j++) {
                var id = ids[j], limits = ranges[slots[j]];
                if (id < limits[0] || id > limits[1] || !$dataArmors[id]) {
                    throw new Error('存档词条不属于游戏原有品质或范围：' + id);
                }
                DreamX.RandomPrefixSuffix.combineWithBaseItem($dataArmors[id], item, 'prefix');
            }
            item.note = item.note.replace(/<Random Variance:\s*\d+>/i, '<Random Variance: 0>');
            item.note += '\n<ici:15>\n<quality:15>\n';
            item.meta = item.meta || {};
            item.meta.ici = '15';
            item.meta.quality = '15';
            item.DXRPSAffixChoices = [];
            item.DXRPSItem = true;
            item.DXRPSNewItem = true;
            item.originalBaseItemId = baseId;
            DataManager.processYanflyTags(item);
            // 游戏底材随机波动 ±1000／±500；配方选取上半区的具体值。
            item.randomVariance = 0;
            var equipment = DataManager.registerNewItem(item);
            if (!equipment || equipment.baseItemId !== baseId) {
                throw new Error('原生独立装备登记失败：' + base.name);
            }
            // ItemCore 创建独立物品时会用底材重设名称与 note；保留
            // DreamX 已合成的六条原生词条，以供装备详情和再次解析。
            equipment.name = item.name;
            equipment.baseItemName = item.name;
            equipment.note = item.note;
            for (var i = 0; i < 8; i++) equipment.params[i] += bonuses[i];
            if (window.RJO && RJO.HE && RJO.HE.getDescParams) {
                RJO.HE.getDescParams(equipment, 2);
            }
            $gameParty.registerNewItem(item, equipment);
            return equipment;
        }
        recipe.receipts = recipe.receipts || {};
        for (var r = 0; r < recipe.roles.length; r++) {
            var role = recipe.roles[r];
            var actor = $gameActors.actor(role.actorId);
            if (!actor || $gameParty.members().indexOf(actor) < 0) {
                throw new Error('装备目标角色不在当前队伍：' + role.actorId);
            }
            var gear = [
                { slot: 17, base: 4484, ids: role.baby, bonus: role.babyBonus },
                { slot: 14, base: 4485, ids: role.relic, bonus: role.relicBonus }
            ];
            for (var g = 0; g < gear.length; g++) {
                var key = role.actorId + ':' + gear[g].slot;
                if (recipe.receipts[key]) continue;
                var entry = gear[g];
                if (actor.equipSlots()[entry.slot] !== $dataArmors[entry.base].etypeId) {
                    throw new Error('目标角色装备栏与原版宝宝／圣器类型不一致');
                }
                var equipped = makeNativeEquip(entry.base, entry.ids, entry.bonus);
                actor.changeEquip(entry.slot, equipped);
                if (!actor.equips()[entry.slot] || actor.equips()[entry.slot].id !== equipped.id) {
                    throw new Error('角色未能装备原生宝宝／圣器：' + actor.name());
                }
                recipe.receipts[key] = equipped.id;
            }
        }
        // 前一版的四件手工测试宝宝仍在背包；确认替代装备穿戴后再清理。
        [8088, 8089, 8090, 8091].forEach(function(id) {
            var obsolete = $dataArmors[id];
            if (!obsolete || obsolete.baseItemId !== 4484 ||
                    !/12条满词条配置/.test(obsolete.description || '') ||
                    !$gameParty.numItems(obsolete)) return;
            $gameParty.loseItem(obsolete, $gameParty.numItems(obsolete));
            DataManager.removeIndependentItem(obsolete);
        });
        recipe.done = true;
    }
    // 旧版渡鸦备注写有 <pSkillPointsVarId:1167>，而 1167 是公共事件1405「召唤天虎令」的
    // 招募标记；渡鸦每次升级都会被 PKD 天赋点 +1。每个存档只修正一次：天虎令在队或曾获得
    // 经验视为已招募（1），否则为 0；同时清除渡鸦对象上缓存的变量号。
    function repairTianhuRecruitFlag() {
        if (!$gameSystem || $gameSystem._codexRavenVar1167Fixed || !$gameActors || !$gameParty) return;
        $gameSystem._codexRavenVar1167Fixed = true;
        var raven = $gameActors._data[R.ACTOR_ID], tianhu = $gameActors._data[104];
        if (raven) raven.pSkillPointsVarId = 0;
        var exp = tianhu && tianhu._exp || {};
        var recruited = $gameParty._actors.indexOf(104) >= 0 ||
            Object.keys(exp).some(function(k) { return Number(exp[k]) > 0; });
        var before = $gameVariables.value(1167), after = recruited ? 1 : 0;
        if (before !== after) $gameVariables.setValue(1167, after);
        $gameSystem._codexRavenVar1167Repair = { before: before, after: after };
    }
    var _DataManager_extractSaveContents = DataManager.extractSaveContents;
    DataManager.extractSaveContents = function(contents) {
        _DataManager_extractSaveContents.call(this, contents);
        R.refreshMasteryLimit();
        restoreRavenState();
        applySavedEquipmentRecipes();
        repairTianhuRecruitFlag();
    };
    var _DataManager_setupNewGame = DataManager.setupNewGame;
    DataManager.setupNewGame = function() {
        _DataManager_setupNewGame.call(this);
        R.refreshMasteryLimit();
        if ($gameSystem) $gameSystem._codexRavenVar1167Fixed = true;
    };
    var _Game_Variables_setValue_CodexRaven = Game_Variables.prototype.setValue;
    Game_Variables.prototype.setValue = function(variableId, value) {
        _Game_Variables_setValue_CodexRaven.call(this, variableId, value);
        if (variableId === 8) R.refreshMasteryLimit();
    };

    // 原版进阶窗口负责确认、消耗进阶印和更新 _AdvancedNum；渡鸦在此
    // 同步技能与专属形态，旧存档中两套计数由 setupRaven 自动对齐。
    if (typeof Scene_ActorAdvanced !== 'undefined') {
        var _Scene_ActorAdvanced_onConfirmOk_CodexRaven = Scene_ActorAdvanced.prototype.onConfirmOk;
        Scene_ActorAdvanced.prototype.onConfirmOk = function() {
            var actor = $gameParty.members()[this._windowIdx];
            var previous = raven(actor) ? stage(actor) : -1;
            _Scene_ActorAdvanced_onConfirmOk_CodexRaven.call(this);
            if (raven(actor) && Number(actor._AdvancedNum) === previous + 1) {
                actor._codexRavenStage = actor._AdvancedNum;
                // Only this successful native confirmation spends the soul stock.
                // Loading, canceling and previewing never clear existing souls.
                actor._codexRavenSoul = 0;
                setupRaven(actor);
                awardRavenAdvanceSeal(actor);
            }
        };
    }

    // 只在兑换大厅的不朽商店追加渡鸦货物，避免普通号角/武器店和
    // MoreCurrencies 的货币配置发生冲突。
    var _Scene_Shop_prepare = Scene_Shop.prototype.prepare;
    Scene_Shop.prototype.prepare = function(goods, purchaseOnly) {
        goods = goods || [];
        var has = function(type, id) { return goods.some(function(g) { return g[0] === type && g[1] === id; }); };
        var isHornShop = goods.some(function(g) {
            var item = g[0] === 0 && $dataItems[g[1]];
            return item && /^伙伴号角：/.test(item.name || '');
        });
        var mapId = $gameMap && $gameMap.mapId ? $gameMap.mapId() : 0;
        var isImmortalArtifactShop = goods.some(function(g) {
            var armor = g[0] === 2 && $dataArmors[g[1]];
            return armor && /<Magic Weapon>/i.test(armor.note || '');
        });
        if (mapId === 132 && isHornShop && !has(0, R.HORN_ITEM_ID)) {
            goods.push([0, R.HORN_ITEM_ID, 0, 0]);
        }
        if (mapId === 132 && isImmortalArtifactShop && !has(2, R.ARTIFACT_ID)) {
            goods.push([2, R.ARTIFACT_ID, 0, 0]);
        }
        _Scene_Shop_prepare.call(this, goods, purchaseOnly);
        // v1.8 首次加载时为此前已被错误标记为售罄的渡鸦号角补回 1 件。
        // 只执行一次；购买后仍按不朽商店规则永久限购 1 件。
        if (mapId === 132 && isHornShop && $gameSystem && !$gameSystem._codexRavenHornStockV18) {
            var inventories = $gameSystem._inventories || {};
            Object.keys(inventories).forEach(function(key) {
                var inventory = inventories[key];
                if (!inventory || !inventory.itemContainer) return;
                var stock = inventory.itemContainer($dataItems[R.HORN_ITEM_ID]);
                if (stock) stock[R.HORN_ITEM_ID] = 1;
            });
            $gameSystem._codexRavenHornStockV18 = true;
        }
    };

    // EliteEnemy.js 位于原版插件表后段，作者最新的基础掉率为：
    // (双倍掉落 ? 1 : 0.2) × 精英倍率。
    // 它以直接覆写的方式加载在 dsPassiveSkill、套装系统之后，导致
    // 原本的套装掉率和所有 passiveIRUP 被动完全没有参与实际掉落，
    // 而状态面板仍在显示它们，出现“面板很高、实际不变”的错位。
    // 本插件在最后统一恢复这些原版加成，但绝不改动作者的基础公式。
    var _Game_Enemy_dropItemRate_CodexRaven = Game_Enemy.prototype.dropItemRate;
    R.teamDropRateFactor = function() {
        var factor = 1;
        // 维持 GT_EquipSuitCore 的原作者规则：全队已加入队伍成员的
        // 套装掉率共同结算（不是只看当前前排）。
        if ($gameParty && $gameParty.equipSuitBonusBResultCal) {
            factor = $gameParty.equipSuitBonusBResultCal(factor, 2);
        }
        // 维持 dsPassiveSkill 的原作者规则：只有实际出战的角色，
        // 其 passiveIRUP 才会生效。渡鸦的亡魂汲取另按固定 +100%
        // 结算，避免把套装等已有加成再次翻倍。
        var members = $gameParty && $gameParty.battleMembers ? $gameParty.battleMembers() : [];
        members.forEach(function(actor) {
            if (!actor || !actor.iteratePassiveSkill) return;
            actor.iteratePassiveSkill('passiveIRUP', function(metaData) {
                var bonus = Number(metaData);
                if (isFinite(bonus)) factor += bonus * 0.01 * factor;
            });
        });
        // +100% 是基础掉宝倍率的一份增量，不乘算已经叠好的队伍加成。
        if (members.some(function(actor) { return hasRavenSkill(actor, 10129); })) {
            factor += 1;
        }
        return Math.max(0, factor);
    };
    Game_Enemy.prototype.dropItemRate = function() {
        return _Game_Enemy_dropItemRate_CodexRaven.call(this) * R.teamDropRateFactor();
    };

    // 人物状态页“全队掉率”改为直接调用与实际掉落完全相同的加成函数。
    // 地图详情页再以「物品基础概率 × 作者基础掉率 × 此倍率」显示最终
    // 概率，因此切换队伍、装备或渡鸦出战状态会立刻反映在两处界面。
    if (typeof JAH_Window_Status_Resistances !== 'undefined') {
        JAH_Window_Status_Resistances.prototype.calcDropBonus = function() {
            return Math.round(CodexRaven.teamDropRateFactor() * 100) + '%';
        };
    }

    // 地图详情页会缓存当前地图的掉落列表。队伍、套装或渡鸦出战位变化
    // 后，缓存原本不会重算，视觉上仍像“实际掉率没有变化”。只在倍率
    // 发生变化时重建当前已打开地图的掉落数据，不增加每帧重复计算负担。
    if (typeof Window_EnemyInfo !== 'undefined') {
        var _Window_EnemyInfo_update_CodexRavenDropRate = Window_EnemyInfo.prototype.update;
        Window_EnemyInfo.prototype.update = function() {
            _Window_EnemyInfo_update_CodexRavenDropRate.call(this);
            if (!this._mapId || !this._enemies || !this.parseEnemyDrops) return;
            var factor = R.teamDropRateFactor();
            if (this._codexRavenDropRateFactor === factor) return;
            this._codexRavenDropRateFactor = factor;
            this._drops = this._drops || {};
            for (var i = 0; i < this._enemies.length; i++) {
                var enemy = this._enemies[i];
                if (enemy) this._drops[enemy.id] = this.parseEnemyDrops(enemy);
            }
            this.refresh();
        };
    }

    function gainSoulFrom(enemy) {
        var actor = $gameActors && $gameActors.actor(R.ACTOR_ID);
        if (!actor || !active(actor) || enemy._codexRavenSoulCounted) return;
        enemy._codexRavenSoulCounted = true;
        var exp = Math.max(0, Number(enemy.exp ? enemy.exp() : 0) || 0);
        var baseSoul = Math.max(10, Math.min(50,
            Math.floor(12 + 5 * Math.log2(1 + exp / 100))));
        var gain = baseSoul;
        if (enemy.isElite && enemy.isElite()) gain *= 3;
        if (enemy.enemy && enemy.enemy().meta && (enemy.enemy().meta.boss || enemy.enemy().meta.Boss)) gain *= 10;
        gain = Math.min(50, gain);
        actor._codexRavenSoul += gain;
        actor.need_refresh = true;
        actor.refresh();
        awardRavenAdvanceSeal(actor);
        if (hasRavenSkill(actor, 10132)) {
            actor._codexRavenResidue = Math.min(3, actor._codexRavenResidue + 1);
            if (hasRavenSkill(actor, 10133) && actor._codexRavenResidue >= 3) actor._codexRavenHunter = true;
        }
        if (isMyth(actor) && actor._codexRavenMythTurns < 5) actor._codexRavenMythTurns++;
    }
    var _Game_Enemy_die = Game_Enemy.prototype.die;
    Game_Enemy.prototype.die = function() { var wasDead = this.isDead(); _Game_Enemy_die.call(this); if (!wasDead) { gainSoulFrom(this); BattleManager._codexRavenAnyDeath = true; } };

    function canForge(actor) {
        var next = stage(actor) + 1;
        return raven(actor) && next <= 5 && actor._codexRavenForgedStage !== stage(actor) &&
            soul(actor) >= R.REQUIRE[next];
    }
    function awardRavenAdvanceSeal(actor) {
        if (!canForge(actor) || !active(actor)) return false;
        actor._codexRavenForgedStage = stage(actor);
        // 旧存档或剧情已持有印章时不额外复制一枚。
        if (!$gameParty.hasItem($dataItems[R.ASCENSION_ITEM_ID])) {
            $gameParty.gainItem($dataItems[R.ASCENSION_ITEM_ID], 1);
        }
        return true;
    }

    var _Game_Action_apply = Game_Action.prototype.apply;
    Game_Action.prototype.apply = function(target) {
        _Game_Action_apply.call(this, target);
        var subject = this.subject(); var item = this.item();
        if (!raven(subject) || !item || !item.meta) return;
        if (item.meta.CodexRavenMyth && hasRavenSkill(subject, R.SKILL.MYTH) &&
                !isMyth(subject)) { subject._codexRavenMythTurns = 3; R.Fx.play(subject, target, 'ring'); }
        if (item.meta.CodexRavenDamage && target && target.result) {
            // Peck restores MP once per cast at every rank, after its first battle hit.
            if (item.id === R.SKILL.PECK &&
                    !this._codexRavenPeckRestored && $gameParty.inBattle() &&
                    target.result().isHit()) {
                this._codexRavenPeckRestored = true;
                subject.gainMp(Math.max(1, Math.floor(subject.mmp * 0.02)));
            }
            // Stage-two Feast uses the normal independent state roll. The
            // existing level-45 passive retains its original application.
            // Choosing one source prevents duplicate erosion on the same hit.
            if ((item.id === R.SKILL.FEAST || item.id === R.SKILL.SOULS) &&
                    target.result().isHit()) {
                if (hasRavenSkill(subject, 10134)) {
                    target.addState(1663);
                } else if (stage(subject) === 2 && item.id === R.SKILL.FEAST &&
                        hasRavenSkill(subject, R.SKILL.FEAST)) {
                    this.itemEffectAddNormalState(target,
                        { code: 21, dataId: 1663, value1: 1, value2: 0 });
                }
            }
            // 多段/群体技能会多次调用 apply。按目标累计本次行动的实际伤害，
            // 在行动结束时各触发一次影鸦复刻，而不是只记录最后一个目标。
            this._codexRavenTargets = this._codexRavenTargets || [];
            var hit = null;
            for (var h = 0; h < this._codexRavenTargets.length; h++) {
                if (this._codexRavenTargets[h].target === target) { hit = this._codexRavenTargets[h]; break; }
            }
            if (!hit) { hit = { target: target, damage: 0 }; this._codexRavenTargets.push(hit); }
            hit.damage += Math.max(0, target.result().hpDamage || 0);
            R.Fx.play(subject, target, 'slash');
        }
    };

    // Trait 34 normally benefits only Attack. Add it to Raven's double-hit
    // skill after dsPassiveSkill has already handled <atkk> and AgainUse.
    var _Game_Action_numRepeats_CodexRaven = Game_Action.prototype.numRepeats;
    Game_Action.prototype.numRepeats = function() {
        var repeats = _Game_Action_numRepeats_CodexRaven.call(this);
        var subject = this.subject(), item = this.item();
        if (raven(subject) && item && item.id === R.SKILL.FEATHER) {
            repeats += Math.max(0, Math.floor(subject.attackTimesAdd()));
        }
        return repeats;
    };

    var _Game_Action_makeDamageValue = Game_Action.prototype.makeDamageValue;
    Game_Action.prototype.makeDamageValue = function(target, critical) {
        var value = _Game_Action_makeDamageValue.call(this, target, critical);
        return Math.floor(value * R.damageMultiplier(this.subject(), this.item()));
    };

    function directDamage(target, value) {
        if (!target || target.isDead() || value <= 0) return;
        target.gainHp(-Math.floor(value)); target.startDamagePopup(); target.performDamage();
        if (target.isDead()) target.performCollapse();
    }
    var _BattleManager_endAction = BattleManager.endAction;
    BattleManager.endAction = function() {
        var action = this._action; var subject = this._subject;
        if (action && raven(subject) && action.item() && action.item().meta && action.item().meta.CodexRavenDamage && !action._codexRavenHandled) {
            action._codexRavenHandled = true;
            var hits = action._codexRavenTargets || [];
            var hunter = !!subject._codexRavenHunter && hasRavenSkill(subject, 10133);
            if (hunter) { subject._codexRavenHunter = false; subject._codexRavenResidue = 0; }
            for (var i = 0; i < hits.length; i++) {
                var target = hits[i].target; var base = hits[i].damage || 0;
                if (!target || target.isDead() || base <= 0) continue;
                if (hunter) { directDamage(target, base * (mythPower(subject) ? 1.50 : 1.00)); R.Fx.play(subject, target, 'harvest'); }
                if (mythPower(subject) && !target.isDead()) { directDamage(target, base * 0.85); R.Fx.play(subject, target, 'echo'); }
            }
        }
        _BattleManager_endAction.call(this);
    };
    var _BattleManager_startTurn = BattleManager.startTurn;
    BattleManager.startTurn = function() { this._codexRavenAnyDeath = false; _BattleManager_startTurn.call(this); };
    var _BattleManager_endTurn = BattleManager.endTurn;
    BattleManager.endTurn = function() {
        var actor = $gameActors && $gameActors.actor(R.ACTOR_ID);
        if (actor && active(actor)) {
            if (!this._codexRavenAnyDeath && hasRavenSkill(actor, 10132)) {
                actor._codexRavenResidue = Math.min(3, actor._codexRavenResidue + 1);
                if (hasRavenSkill(actor, 10133) && actor._codexRavenResidue >= 3) actor._codexRavenHunter = true;
            }
            if (isMyth(actor)) actor._codexRavenMythTurns--;
        }
        _BattleManager_endTurn.call(this);
    };
    // 神话形态只允许存在于当前战斗。胜利、逃跑或强制结束时都立即还原，
    // 避免战斗外菜单/图鉴继续显示神话战斗图，也避免下一场继承剩余回合。
    var _BattleManager_endBattle = BattleManager.endBattle;
    BattleManager.endBattle = function(result) {
        var actor = $gameActors && $gameActors.actor(R.ACTOR_ID);
        if (actor) actor._codexRavenMythTurns = 0;
        _BattleManager_endBattle.call(this, result);
    };

    // 低开销特效：仅创建4个Graphics对象，触发时重绘一次，逐帧只改透明度和缩放。
    R.Fx = { pool: [], ensure: function() {
        if (this.pool.length || !SceneManager._scene || !SceneManager._scene._spriteset) return;
        var field = SceneManager._scene._spriteset._battleField; if (!field) return;
        for (var i = 0; i < 4; i++) { var g = new PIXI.Graphics(); g.visible = false; g._ravenFrames = 0; field.addChild(g); this.pool.push(g); }
    }, pos: function(target) {
        var ss = SceneManager._scene && SceneManager._scene._spriteset; if (!ss) return { x: Graphics.boxWidth / 2, y: Graphics.boxHeight / 2 };
        var all = (ss._enemySprites || []).concat(ss._actorSprites || []); for (var i = 0; i < all.length; i++) if (all[i]._battler === target) return { x: all[i].x, y: all[i].y - 48 };
        return { x: Graphics.boxWidth / 2, y: Graphics.boxHeight / 2 };
    }, play: function(subject, target, type) {
        if (!SceneManager._scene || !(SceneManager._scene instanceof Scene_Battle)) return; this.ensure(); if (!this.pool.length) return;
        var g = this.pool.filter(function(x) { return !x.visible; })[0] || this.pool[0]; var p = this.pos(target); g.clear(); g.x = p.x; g.y = p.y; g.alpha = 1; g.scale.set(1, 1); g.visible = true; g._ravenFrames = type === 'ring' ? 28 : 16;
        if (type === 'ring') { g.lineStyle(5, 0x8c4dff, 0.9); g.drawCircle(0, 0, 72); g.lineStyle(2, 0x35a8ff, 0.8); g.drawCircle(0, 0, 92); }
        else { g.lineStyle(type === 'harvest' ? 10 : 6, type === 'echo' ? 0x356dff : 0xa84dff, 0.9); g.moveTo(-92, 55); g.quadraticCurveTo(0, -78, 92, 55); }
    }, update: function() { this.pool.forEach(function(g) { if (!g.visible) return; g._ravenFrames--; g.alpha *= 0.88; g.scale.x += 0.025; g.scale.y += 0.025; if (g._ravenFrames <= 0) g.visible = false; }); } };
    var _Scene_Battle_update = Scene_Battle.prototype.update;
    Scene_Battle.prototype.update = function() { _Scene_Battle_update.call(this); R.Fx.update(); };

    var _Game_Interpreter_pluginCommand = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function(command, args) { _Game_Interpreter_pluginCommand.call(this, command, args); if (command === 'RavenAdd' || command === '渡鸦加入') R.recruit(); };
    window.CodexDamageHooks.push({name:'raven',build:function(x,t,f){
 var a=x.subject(),item=x.item();if(!raven(a)||!item.meta.CodexRavenDamage)return;
 f.mode='magical';f.magicalDefenseRate*=R.defenseFactor(a);
 var p=progress(a),tempered=hasRavenSkill(a,10131),dark=item.damage.elementId===9;
 if(dark)f.elementAdd[9]=(f.elementAdd[9]||0)+(tempered?2+p:0)+(mythPower(a)?1:0);
 else f.normalAdd+=(tempered?1.5+p:0)+(mythPower(a)?1:0);
 f.finalAdd+=(tempered?1.5*Math.min(1,(stage(a)+p)/5):0)+(mythPower(a)?1.5:0);
 if(hasRavenSkill(a,10136))f.finalMultiplier*=1.1;
 f.skillMultiplier*=artifactEquipped(a)?1.6:1;f.settlementMultiplier*=R.crownRate(a)*R.growthRate(a);
 f.origins.push('raven');
}});

}());

  }


return installNativeRavenRuntime.apply(this, arguments);
});
