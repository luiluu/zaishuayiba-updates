// 【Claude·未经Codex检验】v0.44 按用户 2026-10-18 决定恢复专武随人物等级成长（v0.41 曾整体撤下）；模板与旧存档实例都恢复，规则同 v0.31。
// 【Claude·未经Codex检验】v0.31 专属武器随等级成长（照无极西瓜刀写法）。
// 用户 2026-10-16 决定：所有带专属角色限制（req_actors）的武器统一按档位成长——
// 普通档物攻、魔攻每级+10，极档+20，圣／绝／天外天等最高档+30；原有按等级的成长块全部替换，
// 强化变量（如千古啸、麒麟对剑在南贤处的强化）保留。数据库模板已在 Weapons.json 改好，
// 本模块只把存档里已有的独立实例（含「普通武器+专武词缀」的组合件）迁移到同一规则，可重复执行。
window.CodexRuntime.register('installExclusiveGrowthRuntime', function() {
  'use strict';
  if (window.KyoExclusiveGrowth) return window.KyoExclusiveGrowth;
  var W = window;
  // id: [每级加值, 名称]；由 scripts/exclusive_tiers.py 生成，和 Weapons.json 模板一致。
  var TABLE = {52:[10,"解放前的斩月"],53:[10,"斩月"],67:[20,"卍解-斩月"],68:[30,"斩月-虚与死神结合之力"],69:[30,"斩月-灭却师之力"],70:[30,"卍解-真正的天锁斩月"],71:[20,"斩月-II"],72:[20,"卍解-斩月-II"],73:[10,"麒麟对剑"],74:[20,"麒麟对剑*极"],75:[30,"麒麟对剑*星"],76:[10,"绣冬"],77:[10,"贽殿遮那"],78:[10,"戮仙剑"],79:[10,"护摩之杖"],80:[30,"天外天·电磁炮"],81:[30,"天外天·逐暗者"],82:[30,"天外天·爆裂魔杖"],83:[30,"天外天·贽殿遮那"],85:[30,"天外天·巴雷特"],86:[30,"天外天·月兔"],87:[30,"天外天·灼烂歼鬼"],88:[30,"天外天·护摩之杖"],89:[30,"天外天·诛仙剑"],90:[30,"天外天·一拳"],91:[30,"天外天·超赛·红"],92:[30,"天外天·轩辕剑"],93:[30,"天外天·永恒吞噬"],94:[30,"天外天·{绣冬·春雷}合一"],1526:[10,"定海神铁"],1527:[10,"银河钉锤"],1528:[10,"降妖宝斧"],1529:[10,"九锡拳套"],1530:[10,"白鳞短匕"],1543:[20,"极*定海神铁"],1544:[20,"极*银河钉锤"],1545:[20,"极*降妖宝斧"],1546:[20,"极*九锡拳套"],1547:[20,"极*白鳞短匕"],1548:[10,"紫青宝剑"],1619:[10,"毒吻"],1620:[10,"穿肠"],1621:[20,"毒吻*极"],1622:[20,"穿肠*极"],1687:[10,"绝世好剑（开封失败）"],1689:[30,"圣*毒吻"],1690:[30,"圣*穿肠"],1691:[30,"圣*定海神铁"],1692:[30,"圣*银河钉锤"],1693:[30,"圣*降妖宝斧"],1694:[30,"圣*九锡拳套"],1695:[30,"圣*白鳞短匕"],1696:[30,"紫青宝剑*绝"],1698:[10,"心澜"],1699:[20,"极*心澜"],1700:[30,"圣*心澜"],1702:[10,"夜愿"],1703:[20,"极*夜愿"],1704:[30,"圣*夜愿"],1925:[10,"千古啸"],1926:[20,"千古啸*极"],1927:[30,"千古啸*尘"],2005:[10,"鸾凤和鸣剑"],2006:[20,"鸾凤和鸣剑*极"],2007:[30,"鸾凤和鸣剑*绝"],2008:[10,"太极剑"],2009:[10,"混元霹雳"],2019:[10,"幽灵魔刀·狂龙"],2020:[10,"幽灵魔刀·武道"],2021:[10,"星鹫赤羽"],2022:[10,"阿莫斯之弓"],2023:[20,"星穹麒麟弩"],2222:[30,"真我之钥·无暇回归"],4003:[30,"极光剑一*剑道"]};
  var MARK = '// KYO专武成长';
  var LEVEL_LINE = /^\s*(?:maxhp|mhp|hp|maxmp|mmp|mp|maxsp|msp|sp|atk|str|def|mat|int|spi|mdf|res|agi|spd|luk|all)\s*=\s*user\.level\s*\*\s*[\d.]+\s*;?\s*$/i;
  var OLD_TEXT = /随等级提升增加|随自身等级成长|物攻、魔攻随人物等级提升/;
  var G = W.KyoExclusiveGrowth = { version: 'v0.44', table: TABLE, mark: MARK };

  // 南贤强化变量若尚未初始化会是 undefined，乘出来 NaN 会让整项属性失效；统一按0计。
  function guardVars(line) {
    return line.replace(/v\[(\d+)\]/g, function(m, n, off, str) {
      return str.charAt(off - 1) === '(' && str.substr(off + m.length, 4) === '||0)' ? m : '(v[' + n + ']||0)';
    });
  }
  G.guardVars = guardVars;
  function evalLine(per) { return 'atk += user.level * ' + per + '; mat += user.level * ' + per + '; ' + MARK; }
  function textLine(per) {
    return '<pos=APs text=\\c[1]特效:成长(物攻、魔攻随人物等级提升，每级+' + per + ') size=18 color=rgba(255,255,255,1) line=false align=0>';
  }
  G.evalLine = evalLine; G.textLine = textLine;

  // 备注：去掉成长块里的按等级赋值、旧成长说明和本规则旧行，再补一条说明和一个成长块。
  G.transformNote = function(note, per) {
    var lines = String(note || '').split(/\r?\n/), out = [], inBlock = false, block = [];
    lines.forEach(function(line) {
      if (/<(?:PARAMETER EVAL|custom parameter|custom parameters)>/i.test(line)) { inBlock = true; block = [line]; return; }
      if (inBlock && /<\/(?:PARAMETER EVAL|custom parameter|custom parameters)>/i.test(line)) {
        inBlock = false;
        var body = block.slice(1).filter(function(l) { return !LEVEL_LINE.test(l) && l.indexOf(MARK) < 0; }).map(guardVars);
        if (body.some(function(l) { return l.trim(); })) out.push.apply(out, [block[0]].concat(body, [line]));
        return;
      }
      if (inBlock) { block.push(line); return; }
      if (/<pos=APs/.test(line) && OLD_TEXT.test(line)) return;
      out.push(line);
    });
    if (inBlock) out.push.apply(out, block);
    while (out.length && !out[out.length - 1].trim()) out.pop();
    var lastPos = -1;
    out.forEach(function(l, i) { if (/<pos=APs/.test(l)) lastPos = i; });
    out.splice(lastPos >= 0 ? lastPos + 1 : out.length, 0, textLine(per));
    out.push('<Custom Parameters>', evalLine(per), '</Custom Parameters>');
    return out.join('\n');
  };
  G.transformEval = function(code, per) {
    var body = String(code || '').split(/\r?\n/).filter(function(l) { return !LEVEL_LINE.test(l) && l.indexOf(MARK) < 0 && l.trim(); }).map(guardVars);
    body.push(evalLine(per));
    return body.join('\n') + '\n';
  };

  function baseIdOf(i) { return Number(i.originalBaseItemId || i.baseItemId || i.id); }
  // 组合件按名字里最长的专武名判断（例：「卍解-真正的天锁斩月剃刀」→天锁斩月），只认带专属限制的。
  var names = Object.keys(TABLE).map(function(id) { return { id: Number(id), name: TABLE[id][1], per: TABLE[id][0] }; })
    .sort(function(a, b) { return b.name.length - a.name.length; });
  G.perLevelFor = function(i) {
    if (!i || !DataManager.isWeapon(i)) return 0;
    var own = TABLE[baseIdOf(i)] ? TABLE[baseIdOf(i)][0] : 0;
    if (!own && !(i.meta && i.meta.req_actors !== undefined) && !/<req_actors\s*:/i.test(i.note || '')) return 0;
    var name = String(i.name || ''), hit = 0;
    for (var k = 0; k < names.length; k++) if (name.indexOf(names[k].name) >= 0) { hit = names[k].per; break; }
    return Math.max(own, hit);
  };
  G.current = function(i) {
    var m = /atk \+= user\.level \* (\d+); mat \+= user\.level \* \1; \/\/ KYO专武成长/.exec(String(i && i.parameterEval || ''));
    return m ? Number(m[1]) : 0;
  };
  // 【Codex·未经Claude检验】v0.47：仅按原生本体ID同步两把李逍遥专武的等级与说明。
  G.normalizeLxyRequirement = function(i) {
    if (!i || !DataManager.isWeapon(i)) return false;
    var level = {78: 45, 92: 60}[baseIdOf(i)];
    if (!level) return false;
    var oldNote = String(i.note || ''), note = oldNote;
    if (/<req_level\s*:\s*\d+\s*>/i.test(note)) note = note.replace(/<req_level\s*:\s*\d+\s*>/i, '<req_level:' + level + '>');
    else note += '\n<req_level:' + level + '>';
    note = note.replace(/(<pos=APs\s+text=(?:\\c\[\d+\])?等级需求[:：])\s*\d+/, function(all, prefix) { return prefix + level; });
    if (note === oldNote && i.meta && String(i.meta.req_level) === String(level)) return false;
    i.note = note; i.meta = i.meta || {}; i.meta.req_level = String(level);
    delete i.descParams;
    if (W.RJO && RJO.HE) RJO.HE.getDescParams(i, 1);
    return true;
  };
  G.migrate = function(i) {
    var requirementChanged = G.normalizeLxyRequirement(i);
    var per = G.perLevelFor(i);
    if (!per) return requirementChanged;
    var ev = G.transformEval(i.parameterEval, per), note = G.transformNote(i.note, per);
    if (ev === i.parameterEval && note === i.note) return requirementChanged;
    i.note = note;
    i.parameterEval = ev;
    delete i._codexNoExclusiveGrowth41;
    if (W.CodexAbyssMerchant) CodexAbyssMerchant.touch();
    if (W.RJO && RJO.HE) { delete i.descParams; RJO.HE.getDescParams(i, 1); }
    return true;
  };
  G.sync = function() {
    var changed = 0;
    (DataManager._independentWeapons || []).forEach(function(i) { if (i && G.migrate(i)) changed++; });
    // Hidden legacy inventory may remain registered only in the native weapon database.
    ($dataWeapons || []).forEach(function(i) { if (i && G.normalizeLxyRequirement(i)) changed++; });
    if (changed && W.$gameActors) ($gameActors._data || []).forEach(function(a) { if (a) a.refresh(); });
    G.lastSync = changed;
    return changed;
  };
  var load = DataManager.extractSaveContents;
  DataManager.extractSaveContents = function() {
    var result = load.apply(this, arguments);
    G.sync();
    return result;
  };
  return G;
});
