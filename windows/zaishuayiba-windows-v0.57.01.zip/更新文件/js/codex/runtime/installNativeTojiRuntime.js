// 【Codex·未经Claude检验】v0.23 咒具切换兼容战技类别封印；未经claude检验。
// Extracted from the verified native runtime; installer order is maintained by main.js.
window.CodexRuntime.register("installNativeTojiRuntime", function() {
  function installNativeTojiRuntime() {
    'use strict';
    if (window.CodexToji && window.CodexToji._installed) return;
    var T = window.CodexToji = window.CodexToji || {};
    T._installed = true;
    var ACTOR = 171, ARMOR = 4580, STONE = 2935, HORN = 2936;
    T.armor = ARMOR; // 专属法宝「藏兵咒灵」，供战力模型等按名读取
    var PASSIVE = {noMp:10203, magicToAtk:10203, tyrant:10205,
      senses:10206, slayer:10207, blood:10208, power:10209,
      bloodGreat:10210, armory:10211};
    var SWITCH = [10212,10213,10214,10215];
    var MAIN = [10216,10217,10218,10219];
    // The random records are stored in document order. Runtime indices follow
    // the four shape states: Yun, Chain, Sword, Spear.
    var RANDOM = [10220,10223,10221,10222];
    var REFLECT = 10224, SHAPES = [2630,2631,2632,2633], SEAL = 2634;
    function toji(actor) { return !!(actor && actor.isActor && actor.isActor() && actor.actorId() === ACTOR); }
    function knows(actor,id) { return !!(toji(actor) && actor.isLearnedSkill && actor.isLearnedSkill(id)); }
    function level(actor) { return Number(actor.level || actor._level || 1); }
    T.balanceAt70 = 0.188208;
    function originalGrowth(lv) { return lv>=50 ? 1 : 0.10+0.90*Math.pow(lv/50,2); }
    function smoothTail(lv,anchor,base,slope,end) {
      var span=70-anchor,delta=end-base,lo=0.000001,hi=10;
      for(var i=0;i<64;i++){var k=(lo+hi)/2;if(delta*k/(1-Math.exp(-k*span))>slope)hi=k;else lo=k;}
      var rate=(lo+hi)/2;
      return base+delta*(1-Math.exp(-rate*(lv-anchor)))/(1-Math.exp(-rate*span));
    }
    T.outputGrowth=function(actor,main){
      var lv=Math.max(1,level(actor)),anchor=main?20:10;
      var p=originalGrowth(anchor),base=main?(1+0.1*anchor)*p:p;
      if(lv<=anchor)return (main?1+0.1*lv:1)*originalGrowth(lv);
      var slope=main?0.1*p+(1+0.1*anchor)*0.00072*anchor:0.00072*anchor;
      return smoothTail(lv,anchor,base,slope,T.balanceAt70*(main?8:1));
    };
    T.progressionRate=function(actor){return T.outputGrowth(actor,false);};
    function rank(actor) { return Number(actor._AdvancedNum || 0); }
    function weapon(actor) {
      return !!(actor.equips && actor.equips().some(function(item) {
        return item && (item.baseItemId || item.id) === ARMOR;
      }));
    }
    function isMain(id) { return MAIN.indexOf(id) >= 0; }
    function isRandom(id) { return RANDOM.indexOf(id) >= 0; }
    function eligibleShape(actor,index) {
      return index >= 0 && index < 4 && knows(actor,SWITCH[index]) && knows(actor,MAIN[index]);
    }
    function currentShape(actor) {
      for (var i=0;i<4;i++) if (actor.isStateAffected(SHAPES[i])) return i;
      return 0;
    }
    function setShape(actor,index) {
      if (!toji(actor) || !eligibleShape(actor,index)) return false;
      SHAPES.forEach(function(id) { if (actor.isStateAffected(id)) actor.removeState(id); });
      actor.addState(SHAPES[index]);
      actor._replaceAttackSkillId = undefined;
      actor.refresh();
      return actor.isStateAffected(SHAPES[index]);
    }
    T.setShape = setShape;
    T.currentShape = currentShape;
    var oldAttackId=Game_Actor.prototype.attackSkillId;
    Game_Actor.prototype.attackSkillId=function(){
      if(toji(this))return MAIN[currentShape(this)];
      return oldAttackId.apply(this,arguments);
    };
    var oldAttackCommand=Window_ActorCommand.prototype.addAttackCommand;
    Window_ActorCommand.prototype.addAttackCommand=function(){
      if(toji(this._actor)){
        var skill=$dataSkills[this._actor.attackSkillId()];
        this.addCommand(skill.name,'attack',this._actor.canAttack());
        return;
      }
      return oldAttackCommand.apply(this,arguments);
    };
    // The native status panel and native damage chain read these same fields.
    // Rebuild the native cache before parsing; its additive fields otherwise
    // retain old state contributions when refreshed more than once.
    var oldGrowthCache=Game_Actor.prototype.refreshPassiveCache;
    Game_Actor.prototype.refreshPassiveCache=function(){
      if(toji(this))this.initPassiveCache();
      var result=oldGrowthCache.apply(this,arguments);
      if(toji(this) && this._passiveCache){
        var c=this._passiveCache;
        var growth=knows(this,PASSIVE.tyrant)?0.40*level(this):0;
        c.globalHarmRi=(c.globalHarmRi||0)+growth;
        c.critHarmRi=(c.critHarmRi||0)+growth;
        c._codexTojiGrowth=growth;
      }
      return result;
    };

    // One final-stat layer preserves the unconverted MP/MAT sources and never
    // reads atk from the atk getter while calculating blood armor.
    var oldParam = Game_Actor.prototype.param;
    Game_Actor.prototype.param = function(paramId) {
      var original = oldParam.call(this,paramId);
      if (!toji(this)) return original;
      if (paramId === 1 && knows(this,PASSIVE.noMp)) return 0;
      if (paramId === 4 && knows(this,PASSIVE.magicToAtk)) return 0;
      if (paramId !== 0 && paramId !== 2 && paramId !== 6) return original;
      var growth = knows(this,PASSIVE.tyrant) ? level(this) : 0;
      if (paramId === 0) {
        var sourceMp = knows(this,PASSIVE.noMp) ? oldParam.call(this,1) : 0;
        return Math.max(1,Math.round((original+sourceMp)*(1+growth*0.10)));
      }
      if (paramId === 6) return Math.max(1,Math.round(original*(1+growth*0.05)));
      var sourceMat = knows(this,PASSIVE.magicToAtk) ? oldParam.call(this,4) : 0;
      var result = (original+sourceMat)*(1+growth*0.05);
      var fine = knows(this,PASSIVE.bloodGreat) && rank(this)>=1;
      if (fine || knows(this,PASSIVE.blood)) {
        var hp = this.param(0);
        var lost = Math.max(0,Math.min(1,1-Number(this._hp||0)/Math.max(1,hp)));
        result = (result+hp*(fine?0.05:0.025))*(1+lost*(fine?0.15:0.12));
      }
      if (knows(this,PASSIVE.power)) result *= 1.2;
      return Math.max(1,Math.round(result));
    };
    var oldXparam = Game_Actor.prototype.xparam;
    Game_Actor.prototype.xparam = function(id) {
      var value = oldXparam.call(this,id);
      return id===2 && knows(this,PASSIVE.tyrant) ? value+0.10*level(this) : value;
    };
    var oldSetMp = Game_Actor.prototype.setMp;
    Game_Actor.prototype.setMp = function(value) {
      return oldSetMp.call(this,knows(this,PASSIVE.noMp)?0:value);
    };
    var oldGainMp = Game_Actor.prototype.gainMp;
    Game_Actor.prototype.gainMp = function(value) {
      return oldGainMp.call(this,knows(this,PASSIVE.noMp)?0:value);
    };

    function negativeState(id) {
      if (window.CodexDifficulty && CodexDifficulty.isSystemState(id)) return false;
      if (id===1 || SHAPES.indexOf(id)>=0) return false;
      var state = $dataStates && $dataStates[id];
      if (!state) return false;
      if (state.restriction>0) return true;
      var match = /<BuffType:([^>]+)>/.exec(state.note||'');
      if (match) return ['祝福','变身','魔法','合剂','食物','愤怒','共鸣'].indexOf(match[1])<0;
      return /中毒|毒|灼|诅咒|封印|眩晕|麻痹|虚弱|减速|沉默|睡眠|冻结|流血|失效/.test(state.name||'');
    }
    var oldAddState = Game_Actor.prototype.addState;
    Game_Actor.prototype.addState = function(id) {
      if (knows(this,PASSIVE.tyrant) && negativeState(id)) return;
      return oldAddState.call(this,id);
    };
    var oldAddDebuff = Game_Actor.prototype.addDebuff;
    Game_Actor.prototype.addDebuff = function(id,turns) {
      if (knows(this,PASSIVE.tyrant)) return;
      return oldAddDebuff.call(this,id,turns);
    };
    T.clearDebuffs = function(actor) {
      if (!knows(actor,PASSIVE.tyrant)) return;
      (actor._states||[]).slice().forEach(function(id) {
        if (negativeState(id)) actor.removeState(id);
      });
      for(var p=0;p<8;p++) if (actor.isDebuffAffected(p)) actor.removeDebuff(p);
    };
    var oldLearnSkill = Game_Actor.prototype.learnSkill;
    Game_Actor.prototype.learnSkill = function(id) {
      var result=oldLearnSkill.call(this,id);
      if (id===PASSIVE.tyrant && toji(this)) T.clearDebuffs(this);
      return result;
    };

    function effectiveDef(actor,target,magical) {
      var value = Math.max(0,Number(target.param(magical?5:3)||0));
      return knows(actor,PASSIVE.senses) ? value*0.67 : value;
    }
    T.damage = function(actor,target,id,action) {
      if (!toji(actor) || !target) return 0;
      var atk = Math.max(0,Number(actor.atk||0));
      if (isMain(id)) {
        var base = Math.max(0,7777*atk+888*Math.max(0,Number(actor.mhp||0))-
          (window.CodexDamage&&CodexDamage.isCalculating()?0:effectiveDef(actor,target,false)));
        var n = action && action._tojiExtra || 0;
        if (id===MAIN[0]) return base;
        if (id===MAIN[2]) return base*(5+n)*0.95;
        return base*(action && action._tojiIndex>1 ? 0.8 : 4);
      }
      if (isRandom(id)) return Math.max(0,2666*atk-(window.CodexDamage&&CodexDamage.isCalculating()?0:effectiveDef(actor,target,false)));
      if (id===REFLECT) return Math.max(0,Number(action && action._tojiReflectBase||0)-
        (window.CodexDamage&&CodexDamage.isCalculating()?0:effectiveDef(actor,target,true)));
      return 0;
    };
    // Readonly battle affordances for the shared planner; no shape is changed
    // and no action/cost/black-flash draw is executed while evaluating options.
    T.aiProfile = function(actor,item,action) {
      if (!toji(actor) || !item) return null;
      var switchIndex=SWITCH.indexOf(item.id),index=MAIN.indexOf(item.id);
      if (switchIndex>=0) return eligibleShape(actor,switchIndex) && currentShape(actor)!==switchIndex ?
        {followupSkill:MAIN[switchIndex],setupActions:1} : null;
      if(index<0)return null;
      var extra=Math.max(0,Math.floor(Number(actor.attackTimesAdd()||0)));
      if(action)action._tojiExtra=extra;
      var awake=knows(actor,10226) && actor.isStateAffected(2635) &&
        actor._codexBlackFlashTemp && actor._codexBlackFlashTemp.expires>=CodexBlackFlash.round;
      var hits=index===0?5+extra+(awake?1:0):index===2?1:1+extra;
      // Chain extra hits are 0.8 rather than 4 times the raw damage.
      if(index===1||index===3)hits=1+extra*0.2;
      var multiplier=(knows(actor,PASSIVE.tyrant)?T.outputGrowth(actor,true)*3:T.outputGrowth(actor,false))*
        (weapon(actor)?1.11:1)*(awake?1.2:1);
      return {hits:hits,multiplier:multiplier,splash:index===1?(awake?0.50:0.33):0,
        pierce:index===2?(awake?0.80:0.66):0};
    };
    if(window.CodexSmartAI && CodexSmartAI.registerProfile)CodexSmartAI.registerProfile(T.aiProfile);
    var oldSparam = Game_Enemy.prototype.sparam;
    Game_Enemy.prototype.sparam = function(id) {
      var value = oldSparam.call(this,id), pierce = this._tojiPdrPierce;
      return id===6 && pierce && value<1 ? value+pierce*(1-value) : value;
    };
    var oldEva = Game_Action.prototype.itemEva;
    function shadowRate(faster,slower,cap) {
      return Math.min(cap,Math.max(0,Number(faster && faster.agi||0)/Math.max(1,Number(slower && slower.agi||0))-1)*0.15);
    }
    var oldShadowHit=Game_Action.prototype.itemHit;
    Game_Action.prototype.itemHit=function(target) {
      var value=oldShadowHit.call(this,target),actor=this.subject();
      return this.isPhysical() && knows(actor,PASSIVE.noMp) ? value+shadowRate(actor,target,0.30) : value;
    };
    function awakenedAction(action) {
      var cast=action && action._codexBlackFlashCast,actor=action && action.subject();
      return !!(cast && cast.awake && !cast.finished && !action._tojiInternal &&
        knows(actor,10226) && isMain(action.item().id));
    }
    Game_Action.prototype.itemEva = function(target) {
      var actor=this.subject(), item=this.item();
      if (knows(actor,PASSIVE.senses) && item && (isMain(item.id)||isRandom(item.id))) return 0;
      var value=oldEva.call(this,target);
      if (this.isPhysical() && knows(target,PASSIVE.noMp))
        value+=shadowRate(target,actor,0.30);
      return value;
    };
    var oldItemCri = Game_Action.prototype.itemCri;
    Game_Action.prototype.itemCri = function(target) {
      var actor=this.subject(), item=this.item();
      if (!target || !knows(actor,PASSIVE.senses) || !item ||
          !(isMain(item.id)||isRandom(item.id)||item.id===REFLECT))
        return oldItemCri.call(this,target);
      // The installed critical formula reads target.cev. Supply this hit's
      // reduced CEV without changing the enemy's permanent panel value.
      var own=Object.prototype.hasOwnProperty.call(target,'xparam');
      var prior=Object.getOwnPropertyDescriptor(target,'xparam');
      var original=target.xparam;
      target.xparam=function(id) {
        var value=original.apply(this,arguments);
        return id===3 ? value*0.34 : value;
      };
      try { return oldItemCri.call(this,target); }
      finally {
        if (own) Object.defineProperty(target,'xparam',prior);
        else delete target.xparam;
      }
    };
    var oldCri = Game_Action.prototype.applyCritical;
    Game_Action.prototype.applyCritical = function(damage) {
      var result = oldCri.call(this,damage), actor = this.subject(), item = this.item();
      return result;
    };
    var oldItem = Game_Action.prototype.item;
    Game_Action.prototype.item = function() {
      var item=oldItem.call(this);
      if (!item || item.id!==REFLECT || this._tojiReflectElement==null) return item;
      if (!this._tojiReflectItem ||
          this._tojiReflectItem.damage.elementId!==this._tojiReflectElement) {
        this._tojiReflectItem=Object.assign({},item,{
          damage:Object.assign({},item.damage,{elementId:this._tojiReflectElement})
        });
      }
      return this._tojiReflectItem;
    };
    var oldDamage = Game_Action.prototype.makeDamageValue;
    Game_Action.prototype.makeDamageValue = function(target,critical) {
      var actor = this.subject(), item = this.item(), id = item && item.id;
      var tojiHit = toji(actor) && (isMain(id)||isRandom(id)||id===REFLECT);
      var pierce = isMain(id) && id===MAIN[2] ? (awakenedAction(this)?0.80:0.66) :
        isRandom(id) && id===RANDOM[2] || isMain(id) && this._tojiBorrow===2 ? 0.33 : 0;
      if (tojiHit && pierce) target._tojiPdrPierce = pierce;
      var value;
      try { value = oldDamage.call(this,target,critical); }
      finally { if (tojiHit && pierce) delete target._tojiPdrPierce; }
      if (tojiHit) {
        if (isRandom(id) && actor.skillMasteryLevel)
          value *= 1+0.10*actor.skillMasteryLevel($dataSkills[PASSIVE.armory]);
        if (isMain(id) && knows(actor,PASSIVE.tyrant)) value *= T.outputGrowth(actor,true);
        if (id!==REFLECT && weapon(actor)) value *= 1.11;
        if (knows(actor,PASSIVE.tyrant)) value *= 3;
        if (this._tojiSpreadRate) value *= this._tojiSpreadRate;
        if (value>0 && !(isMain(id) && knows(actor,PASSIVE.tyrant))) value *= T.outputGrowth(actor,false);
      } else if (toji(target) && knows(target,PASSIVE.slayer) &&
                 this.isMagical() && item.damage && item.damage.type===1 && value>0 &&
                 actor && actor!==target && !this._tojiNoReflect) {
        this._tojiReflectTarget=target;
        this._tojiReflectSource=actor;
        this._tojiReflectBase=0.264*value;
        this._tojiReflectElement=item.damage.elementId;
        value *= 0.20;
      }
      return Math.round(value);
    };

    function spread(actor,sourceAction,id,sourceTarget,rate) {
      if (!rate || !$gameTroop || !$gameTroop.aliveMembers) return;
      $gameTroop.aliveMembers().forEach(function(target) {
        if (target===sourceTarget) return;
        var child=new Game_Action(actor);
        child.setSkill(id);
        child._tojiInternal=true;
        child._tojiSpreadRate=rate;
        child._tojiExtra=sourceAction._tojiExtra||0;
        child._tojiIndex=sourceAction._tojiIndex||1;
        child._tojiBorrow=sourceAction._tojiBorrow;
        child.apply(target);
      });
    }
    function reflect(action) {
      var target=action._tojiReflectTarget, source=action._tojiReflectSource;
      if (!target || !source || !source.isAlive || !source.isAlive()) return;
      var child=new Game_Action(target);
      child.setSkill(REFLECT);
      child._tojiInternal=true;
      child._tojiNoReflect=true;
      child._tojiReflectBase=action._tojiReflectBase;
      child._tojiReflectElement=action._tojiReflectElement;
      action._tojiReflectTarget=null;
      child.apply(source);
    }
    var oldApply = Game_Action.prototype.apply;
    Game_Action.prototype.apply = function(target) {
      if (this._tojiSuppressed) {
        if (target && target.clearResult) target.clearResult();
        return;
      }
      var actor=this.subject(), id=this.item() && this.item().id;
      if (toji(actor) && isMain(id) && !this._tojiInternal)
        this._tojiIndex=(this._tojiIndex||0)+1;
      oldApply.call(this,target);
      var hit=target && target.result && target.result().isHit();
      if (toji(actor) && hit && (isMain(id)||isRandom(id))) {
        var spear=isMain(id) && (id===MAIN[3] ||
          this._tojiBorrow===3 && this._tojiSpearRoll) ||
          isRandom(id) && id===RANDOM[3] && this._tojiSpearRoll;
        if (spear && target.addState) {
          target.addState(SEAL);
          if(target.isStateAffected(SEAL))target._tojiSealCharges=Math.max(target._tojiSealCharges||1,
            id===MAIN[3] && awakenedAction(this)?2:1);
        }
        if (!this._tojiSpreadRate && (id===MAIN[1] || this._tojiBorrow===1))
          spread(actor,this,id,target,id===MAIN[1]?(awakenedAction(this)?0.50:0.33):0.16);
        if (!this._tojiSpreadRate && isRandom(id) && id===RANDOM[1])
          spread(actor,this,id,target,0.16);
      }
      if (this._tojiReflectTarget===target) reflect(this);
    };

    // 【Codex·未经Claude检验】v0.23 咒具切换单独豁免战技类别封印；未经claude检验。
    // 只在四项切换技能的原生条件检查内豁免类别，其他技能、控制与单项封印照常。
    var checkingSwitchActor=null;
    var oldTypeSealed=Game_Actor.prototype.isSkillTypeSealed;
    Game_Actor.prototype.isSkillTypeSealed=function(stypeId){
      if(checkingSwitchActor===this && stypeId===1)return false;
      return oldTypeSealed.apply(this,arguments);
    };
    var oldMeets = Game_Actor.prototype.meetsSkillConditions;
    Game_Actor.prototype.meetsSkillConditions = function(skill) {
      if (toji(this) && skill && isMain(skill.id) && skill.id!==this.attackSkillId())return false;
      if (toji(this) && skill && SWITCH.indexOf(skill.id)>=0) {
        var index=SWITCH.indexOf(skill.id);
        if (!eligibleShape(this,index) || currentShape(this)===index) return false;
        var previous=checkingSwitchActor;checkingSwitchActor=this;
        try{return oldMeets.call(this,skill);}finally{checkingSwitchActor=previous;}
      }
      return oldMeets.call(this,skill);
    };
    var oldIncludes = Window_SkillList.prototype.includes;
    Window_SkillList.prototype.includes = function(item) {
      if(toji(this._actor) && item && isMain(item.id) && this._stypeId===1 && SceneManager._scene instanceof Scene_Skill)return true;
      if (toji(this._actor) && item && this._stypeId===1 && SWITCH.indexOf(item.id)<0)
        return false;
      if (toji(this._actor) && item && (isMain(item.id)||isRandom(item.id)||item.id===REFLECT))
        return false;
      return oldIncludes.call(this,item);
    };
    T.masteryInfo=function(actor,id) {
      if(!toji(actor) || !isMain(id) || !knows(actor,id))return null;
      return {id:id,level:actor.skillMasteryLevel(id),uses:actor.skillMasteryUses(id),
        needed:actor.skillMasteryUsageMax(id),active:actor.attackSkillId()===id};
    };
    if(typeof Sprite_ItemHelp!=='undefined') {
      var oldTojiHelp=Sprite_ItemHelp.prototype.setItem;
      Sprite_ItemHelp.prototype.setItem=function(item) {
        var scene=SceneManager._scene,actor=scene && (scene._actor || scene._skillWindow && scene._skillWindow._actor);
        var info=item && toji(actor) && isMain(item.id) && T.masteryInfo(actor,item.id);
        if(info && item.descParams && item.pos) {
          var copy=Object.assign({},item);copy.descParams=item.descParams.map(function(row){return row.slice();});copy.pos=item.pos.slice();
          copy.descParams.push(['咒具熟练：Lv'+info.level+'；本级进度：'+info.uses+'/'+info.needed,16,'#ffffff',false,0]);
          copy.descParams.push([info.active?'当前咒具；普通攻击使用此熟练度':'切换至此咒具后，普通攻击使用此熟练度',16,'#ffffff',false,0]);
          item=copy;
        }
        return oldTojiHelp.call(this,item);
      };
    }
    var oldEraseSeal=Game_BattlerBase.prototype.eraseState;
    Game_BattlerBase.prototype.eraseState=function(id){
      if(id===SEAL)delete this._tojiSealCharges;
      return oldEraseSeal.apply(this,arguments);
    };
    var oldClearSeal=Game_BattlerBase.prototype.clearStates;
    Game_BattlerBase.prototype.clearStates=function(){delete this._tojiSealCharges;return oldClearSeal.apply(this,arguments);};
    var oldGlobal = Game_Action.prototype.applyGlobal;
    Game_Action.prototype.applyGlobal = function() {
      var actor=this.subject(), item=this.item();
      if (item && item.stypeId!=null && !this._tojiInternal &&
          !this.isAttack() && !this.isGuard() &&
          actor && actor.isStateAffected && actor.isStateAffected(SEAL)) {
        this._tojiSuppressed=true;
        actor._tojiSealCharges=Math.max(0,Number(actor._tojiSealCharges||1)-1);
        if(!actor._tojiSealCharges)actor.removeState(SEAL);
        return;
      }
      return oldGlobal.call(this);
    };
    var oldSequence = BattleManager.processActionSequenceCheck;
    BattleManager.processActionSequenceCheck = function(name,args) {
      if (this._action && this._action._tojiSuppressed) return true;
      return oldSequence.call(this,name,args);
    };
    var oldStartAction = BattleManager.startAction;
    BattleManager.startAction = function() {
      oldStartAction.call(this);
      var actor=this._subject, action=this._action, item=action && action.item();
      if (!item || !action) return;
      if (action._tojiSuppressed) {
        this._targets=[]; this._allTargets=[]; this._individualTargets=[];
        return;
      }
      var switchIndex=toji(actor)?SWITCH.indexOf(item.id):-1;
      if (switchIndex>=0) {
        action._tojiSwitch=switchIndex;
        return;
      }
      if (!toji(actor) || !isMain(item.id) || !this._targets || !this._targets.length) return;
      var target=this._targets[0], index=MAIN.indexOf(item.id);
      var extra=Math.max(0,Math.floor(Number(actor.attackTimesAdd()||0)));
      action._tojiIndex=0;
      action._tojiExtra=extra;
      if (knows(actor,PASSIVE.armory) && rank(actor)>=1 && Math.random()<0.5) {
        var pool=[0,1,2,3].filter(function(n) { return n!==index && eligibleShape(actor,n); });
        if (pool.length) {
          var pick=pool[Math.floor(Math.random()*pool.length)];
          var randomTarget=target.isAlive && target.isAlive()?target:$gameTroop.aliveMembers()[0];
          if (randomTarget) {
            var child=new Game_Action(actor);
            child.setSkill(RANDOM[pick]);
            child._tojiInternal=true;
            child._tojiSpearRoll=pick===3 && Math.random()<0.5;
            child.apply(randomTarget);
            actor._actionMastery=actor._actionMastery||[];
            actor._actionMastery.push(PASSIVE.armory);
            action._tojiBorrow=pick;
            action._tojiSpearRoll=child._tojiSpearRoll;
            if (pick===0) extra++;
            if (!target.isAlive()) target=$gameTroop.aliveMembers()[0];
          }
        }
      }
      if (!target) {
        this._targets=[]; this._allTargets=[]; this._individualTargets=[];
        return;
      }
      action._tojiExtra=extra;
      var count=index===0?5+extra:index===2?1:1+extra;
      // YEP's named "target" selector deduplicates target arrays. Keep one
      // target and emit each real hit through its native action-effect stage.
      action._tojiHitCount=count;action._tojiEffectsDone=false;
      this._targets=[target];
      this._allTargets=[target];
      this._individualTargets=[target];
    };
    var oldEffect=BattleManager.actionActionEffect;
    BattleManager.actionActionEffect=function(args){
      var action=this._action,actor=this._subject,item=action && action.item();
      if(!toji(actor) || !item || !isMain(item.id) || action._tojiInternal)
        return oldEffect.apply(this,arguments);
      if(action._tojiEffectsDone)return true;
      action._tojiEffectsDone=true;
      var count=action._tojiHitCount||1;
      for(var i=0;i<count;i++){
        var targets=args && args[0]?this.makeActionTargets(args[0]):this._targets;
        if(!targets.some(function(t){return t && t.isAlive();}))break;
        oldEffect.call(this,args);
      }
      return true;
    };
    var oldEndAction = BattleManager.endAction;
    BattleManager.endAction = function() {
      var actor=this._subject, action=this._action;
      var shape=action && action._tojiSwitch;
      var result=oldEndAction.call(this);
      if (toji(actor) && shape!=null && !action._tojiSuppressed) setShape(actor,shape);
      return result;
    };
    var oldStartBattle = BattleManager.startBattle;
    BattleManager.startBattle = function() {
      var actor=$gameActors && $gameActors._data && $gameActors._data[ACTOR];
      if (actor && $gameParty._actors.indexOf(ACTOR)>=0) setShape(actor,0);
      return oldStartBattle.apply(this,arguments);
    };
    var oldEndBattle = BattleManager.endBattle;
    BattleManager.endBattle = function() {
      var actor=$gameActors && $gameActors._data && $gameActors._data[ACTOR];
      if (actor) {
        SHAPES.forEach(function(id) { if(actor.isStateAffected(id)) actor.removeState(id); });
        actor._replaceAttackSkillId=undefined;
      }
      return oldEndBattle.apply(this,arguments);
    };
    var oldRemoveDeath = Game_Actor.prototype.removeState;
    Game_Actor.prototype.removeState = function(stateId) {
      var wasDead = stateId === this.deathStateId() && this.isStateAffected(stateId);
      var result = oldRemoveDeath.apply(this,arguments);
      if (wasDead && toji(this) && $gameParty.inBattle() && this.isAlive() &&
          !SHAPES.some(function(id){return this.isStateAffected(id);},this)) {
        setShape(this,0);
      }
      return result;
    };

    function repair(actor) {
      if (!toji(actor)) return;
      if (actor.isLearnedSkill(10204)) actor.forgetSkill(10204);
      var unlock={10203:1,10205:1,10206:10,10207:20,
        10208:30,10209:35,10212:1,10213:15,10214:30,10215:40,
        10216:1,10217:15,10218:30,10219:40};
      Object.keys(unlock).forEach(function(key) {
        var id=Number(key);
        if (level(actor)>=unlock[key] && !(id===10208 && rank(actor)>=1)) {
          if (!actor.isLearnedSkill(id)) actor.learnSkill(id);
        } else if (actor.isLearnedSkill(id)) actor.forgetSkill(id);
      });
      [PASSIVE.bloodGreat,PASSIVE.armory].forEach(function(id) {
        if (rank(actor)>=1) { if (!actor.isLearnedSkill(id)) actor.learnSkill(id); }
        else if (actor.isLearnedSkill(id)) actor.forgetSkill(id);
      });
      actor._mp=0;
      actor._replaceAttackSkillId=undefined;
      T.clearDebuffs(actor);
    }
    var oldSetup = Game_Actor.prototype.setup;
    Game_Actor.prototype.setup = function(actorId) {
      oldSetup.call(this,actorId);
      if (actorId===ACTOR) repair(this);
    };
    var oldExtract = DataManager.extractSaveContents;
    DataManager.extractSaveContents = function(contents) {
      oldExtract.call(this,contents);
      var actor=$gameActors && $gameActors._data && $gameActors._data[ACTOR];
      if (actor) repair(actor);
    };
    if (typeof Scene_ActorAdvanced!=='undefined') {
      var oldAdvanced = Scene_ActorAdvanced.prototype.onConfirmOk;
      Scene_ActorAdvanced.prototype.onConfirmOk = function() {
        var result=oldAdvanced.call(this);
        var actor=$gameActors && $gameActors._data && $gameActors._data[ACTOR];
        if (actor && rank(actor)>=1) repair(actor);
        return result;
      };
    }

    T.rollAdvanceStone = function() {
      var actor=$gameActors && $gameActors._data && $gameActors._data[ACTOR];
      if (actor && rank(actor)>=1 || $gameParty.numItems($dataItems[STONE])>0) return false;
      if (Math.randomInt(50)!==0) return false;
      $gameParty.gainItem($dataItems[STONE],1);
      $.toaster({message:'获得了 甚尔进阶石！'});
      return true;
    };
    T.recruit = function() {
      if (!$dataActors[ACTOR] || !$dataArmors[ARMOR]) throw new Error('甚尔原生数据缺失');
      if ($gameParty._actors.indexOf(ACTOR)>=0) return false;
      var actor=$gameActors.actor(ACTOR), base=$dataArmors[ARMOR];
      var slot=actor.equipSlots().indexOf(base.etypeId);
      if (slot<0 || !actor.canEquip(base)) throw new Error('藏兵咒灵装备槽不可用');
      var worn=actor.equips()[slot];
      var generated=null;
      try {
        if (!worn || (worn.baseItemId||worn.id)!==ARMOR) {
          var artifact=$gameParty.getMatchingBaseItem && $gameParty.getMatchingBaseItem(base,false);
          if (!artifact) {
            if (!DataManager.isIndependent(base) || !$gameParty.gainIndependentItem)
              throw new Error('原生独立法宝功能不可用');
            generated=artifact=$gameParty.gainIndependentItem(base,1)[0];
          }
          if (!artifact) throw new Error('藏兵咒灵生成失败');
          actor.changeEquip(slot,artifact);
          if (actor.equips()[slot]!==artifact) throw new Error('藏兵咒灵装备失败');
        }
        $gameParty.addActor(ACTOR);
      } catch(error) {
        if ($gameParty._actors.indexOf(ACTOR)>=0) $gameParty.removeActor(ACTOR);
        if (actor.equips()[slot]!==worn) actor.changeEquip(slot,worn);
        if (generated) $gameParty.loseItem(generated,1,false);
        throw error;
      }
      $.toaster({message:'小伙伴 伏黑甚尔 加入队伍'});
      $.toaster({message:'获得并装备专属法宝：藏兵咒灵'});
      return true;
    };
    var oldShopPrepare=Scene_Shop.prototype.prepare;
    Scene_Shop.prototype.prepare=function(goods,purchaseOnly) {
      goods=goods||[];
      var mapId=$gameMap && $gameMap.mapId && $gameMap.mapId();
      if (mapId===132 && goods.some(function(g){return g[0]===0 && g[1]===2788;}) &&
          !goods.some(function(g){return g[0]===0 && g[1]===HORN;}))
        goods.push([0,HORN,0,0]);
      oldShopPrepare.call(this,goods,purchaseOnly);
      if (mapId===132 && $gameSystem && !$gameSystem._codexTojiHornStockInitialized) {
        var inventories=$gameSystem._inventories||{};
        Object.keys(inventories).forEach(function(key) {
          var inv=inventories[key], item=$dataItems[HORN];
          if (!inv || !inv.itemContainer || !item) return;
          var stock=inv.itemContainer(item);
          if (stock && stock[HORN]===undefined) stock[HORN]=1;
        });
        $gameSystem._codexTojiHornStockInitialized=true;
      }
    };
    var oldReady=DataManager.isDatabaseLoaded;
    DataManager.isDatabaseLoaded=function() {
      var ready=oldReady.call(this);
      if (ready && !T._checked) {
        if (!$dataActors[ACTOR] || !$dataClasses[169] || !$dataSkills[10224] ||
            !$dataStates[SEAL] || !$dataArmors[ARMOR] || !$dataItems[HORN] ||
            !$dataCommonEvents[9006]) throw new Error('甚尔原生数据未完整加载');
        T._checked=true;
      }
      return ready;
    };
    window.CodexDamageHooks.push({name:'toji',build:function(x,t,f){
 var a=x.subject(),id=x.item().id,own=toji(a)&&(isMain(id)||isRandom(id)||id===REFLECT);
 if(own){f.mode=id===REFLECT?'magical':'physical';
  if(knows(a,PASSIVE.senses)){f.physicalDefenseRate*=.67;f.magicalDefenseRate*=.67;}
  f.physicalIncomingPierce=id===MAIN[2]?(awakenedAction(x)?.80:.66):isRandom(id)&&id===RANDOM[2]||isMain(id)&&x._tojiBorrow===2?.33:0;
  if(isRandom(id)&&a.skillMasteryLevel)f.skillMultiplier*=1+.10*a.skillMasteryLevel($dataSkills[PASSIVE.armory]);
  if(isMain(id)&&knows(a,PASSIVE.tyrant))f.skillMultiplier*=T.outputGrowth(a,true);
  if(id!==REFLECT&&weapon(a))f.skillMultiplier*=1.11;
  if(knows(a,PASSIVE.tyrant))f.skillMultiplier*=3;
  if(x._tojiSpreadRate)f.skillMultiplier*=x._tojiSpreadRate;
  if(!(isMain(id)&&knows(a,PASSIVE.tyrant)))f.skillMultiplier*=T.outputGrowth(a,false);
 }else if(toji(t)&&knows(t,PASSIVE.slayer)&&x.isMagical()&&x.item().damage.type===1&&a!==t&&!x._tojiNoReflect){
  f.incomingMultiplier*=.2;
  f.after.push(function(r){if(r.value>0){x._tojiReflectTarget=t;x._tojiReflectSource=a;x._tojiReflectBase=.264*r.value/.2;x._tojiReflectElement=(r.breakdown.rows||[])[0]?.element||x.item().damage.elementId;}});
 }
}});

  }

  // Native difficulty events initialize the actors that existed at that time.
  // Reuse their actual learned profile when a later actor joins an older save.
  // Native difficulty events initialize the actors that existed at that time.
  // Reuse their actual learned profile when a later actor joins an older save.

return installNativeTojiRuntime.apply(this, arguments);
});
