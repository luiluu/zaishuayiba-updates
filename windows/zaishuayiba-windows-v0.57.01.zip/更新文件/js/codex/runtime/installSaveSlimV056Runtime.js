// v0.56 存档减载：独立装备的说明缓存（descParams／pos）是纯显示数据，
// 读档时由说明缓存自愈模块按备注重建。存档前临时摘掉，序列化后原样放回，
// 不改变装备对象、属性、备注、编号、数量或任何玩法数据。
(function () {
  'use strict';
  var W = window;
  var S = W.CodexSaveSlim56 = W.CodexSaveSlim56 || { version: 56, stripped: 0 };

  function install() {

  function eachItem(contents, fn) {
    ['items', 'weapons', 'armors'].forEach(function (key) {
      var list = contents && contents[key];
      if (!list || typeof list.length !== 'number') return;
      for (var i = 0; i < list.length; i++) {
        var item = list[i];
        if (item && typeof item === 'object') fn(item);
      }
    });
  }

  // 返回可用于恢复的记录；只摘掉确实存在的字段。
  S.strip = function (contents) {
    var saved = [];
    eachItem(contents, function (item) {
      var hasDesc = Object.prototype.hasOwnProperty.call(item, 'descParams');
      var hasPos = Object.prototype.hasOwnProperty.call(item, 'pos');
      if (!hasDesc && !hasPos) return;
      saved.push([item, hasDesc ? item.descParams : undefined, hasPos ? item.pos : undefined, hasDesc, hasPos]);
      if (hasDesc) delete item.descParams;
      if (hasPos) delete item.pos;
    });
    S.stripped = saved.length;
    return saved;
  };

  S.restore = function (saved) {
    (saved || []).forEach(function (row) {
      var item = row[0];
      if (row[3]) item.descParams = row[1];
      if (row[4]) item.pos = row[2];
    });
  };

  if (!W.DataManager || typeof W.DataManager.saveGameWithoutRescue !== 'function') return;
  if (W.DataManager._codexSaveSlim56) return;
  W.DataManager._codexSaveSlim56 = true;

  var save = W.DataManager.saveGameWithoutRescue;
  W.DataManager.saveGameWithoutRescue = function () {
    var make = W.DataManager.makeSaveContents;
    var pending = null;
    var used = false;
    W.DataManager.makeSaveContents = function () {
      var contents = make.apply(this, arguments);
      pending = S.strip(contents);
      used = true;
      return contents;
    };
    try {
      return save.apply(this, arguments);
    } finally {
      W.DataManager.makeSaveContents = make;
      if (used) S.restore(pending);
      pending = null;
    }
  };

  function itemKind(item) {
    if (!item || typeof item !== 'object') return -1;
    if (item.stypeId !== undefined) return 3;
    if (item.wtypeId !== undefined) return 1;
    if (item.atypeId !== undefined) return 2;
    if (item.itypeId !== undefined) return 0;
    return -1;
  }

  function ensureOne(item) {
    if (!item || Array.isArray(item.descParams) && Array.isArray(item.pos)) return;
    var type = itemKind(item);
    if (type < 0 || !W.RJO || !RJO.HE || typeof RJO.HE.getDescParams !== 'function') return;
    try { RJO.HE.getDescParams(item, type); } catch (e) { /* 保留原对象，交给缓存自愈模块记录 */ }
  }

  function ensureIndependent(contents) {
    ['items', 'weapons', 'armors'].forEach(function (key) {
      var list = contents && contents[key];
      if (!list || typeof list.length !== 'number') return;
      for (var i = 0; i < list.length; i++) ensureOne(list[i]);
    });
  }

  // 减载存档不含说明缓存；本模块装在最后，读档后最后再补一次缓存，
  // 避免其他更晚安装的模块拿到没有缓存的实例。
  if (typeof W.DataManager.extractSaveContents === 'function') {
    var extract = W.DataManager.extractSaveContents;
    W.DataManager.extractSaveContents = function () {
      var out = extract.apply(this, arguments);
      try {
        if (W.ClaudeRepair43 && typeof W.ClaudeRepair43.sweep === 'function') W.ClaudeRepair43.sweep();
        else ensureIndependent(out);
      } catch (e) {
        console.error('读档说明缓存补齐失败；装备数据未改动', e);
      }
      return out;
    };
  }

  // 供无界面测试直接测量；正式存档路径由上面的 saveGameWithoutRescue 包装调用。
  S.measureStrip = function (contents) {
    var saved = S.strip(contents);
    return saved;
  };
  return S;
  }

  if (W.CodexRuntime && typeof W.CodexRuntime.register === 'function') {
    W.CodexRuntime.register('installSaveSlimV056Runtime', install);
  } else {
    install();
  }
})();
