// 【Codex·未经Claude检验】v0.35：心之钢／利维坦第2回合可用，冷却2回合。
// 【Codex·未经Claude检验】v0.08 面板文本优化；未经claude检验。
// Extracted from the verified native runtime; installer order is maintained by main.js.
window.CodexRuntime.register("installNativeHeartsteelRuntime", function() {
  function installNativeHeartsteelRuntime() {
    var H=window.CodexHeartsteel={armorId:7900,leviathanId:7901,skillId:10227,leviathanSkillId:10228,recipeId:457,materialId:2867};
    H.baseId=function(item){return item?Number(item.originalBaseItemId||item.baseItemId||item.id):0;};
    H.isHeart=function(item){return H.baseId(item)===H.armorId;};
    H.isLeviathan=function(item){return H.baseId(item)===H.leviathanId;};
    H.isGear=function(item){return H.isHeart(item)||H.isLeviathan(item);};
    H.isSkill=function(skill){return skill && (skill.id===H.skillId || skill.id===H.leviathanSkillId);};
    H.skillFor=function(item){return H.isLeviathan(item)?H.leviathanSkillId:H.skillId;};
    H.gear=function(actor){return actor && actor.isActor && actor.isActor() ? actor.equips().filter(H.isGear)[0] : null;};
    H.growth=function(item){return Math.max(0,Math.floor(Number(item && item._codexHeartsteelHp)||0));};
    // v0.3 (2026-10-08): unbounded stacks; stage n needs 50*n*(n+1) stacks.
    // Legacy accumulated HP (_codexHeartsteelHp) stays as a flat bonus.
    H.stacks=function(item){return Math.max(0,Math.floor(Number(item && item._codexHeartsteelStacks)||0));};
    H.stageOf=function(k){k=Math.max(0,Number(k)||0);return Math.max(0,Math.floor((Math.sqrt(1+8*k/100)-1)/2+1e-9));};
    H.stageNeed=function(n){return 50*n*(n+1);};
    H.stage=function(item){return H.stageOf(H.stacks(item));};
    H.hpRate=function(item){return (H.isLeviathan(item)?1.1:1)+0.1*H.stage(item);};
    H.castScale=function(actor){var g=actor && H.gear(actor);return g?1+0.1*H.stage(g):1;};
    H.enemyWeight=function(enemy){
      if(!enemy || !enemy.isEnemy || !enemy.isEnemy() || !$gameParty.inBattle() || $gameTroop._troopId===1)return 0;
      var name=enemy.enemy().name;if(/分身|复制|召唤物|练习|训练|木桩/.test(name))return 0;
      return /【未知存在】/.test(name)?10:/【首领】|【被封印者】/.test(name)?5:1;
    };
    H._ledger=[];
    H.pending=function(item){var r=H._ledger.filter(function(e){return e.item===item;})[0];return r?r.gain:0;};
    H.addPending=function(item,gain){var r=H._ledger.filter(function(e){return e.item===item;})[0];if(!r){r={item:item,gain:0};H._ledger.push(r);}r.gain+=gain;};
    H.stageText=function(k){var n=H.stageOf(k);return k+'（第'+n+'阶，下一阶还差'+(H.stageNeed(n+1)-k)+'）';};
    H.quality=function(item){
      var q=12, match, regex=/<quality:\s*(\d+)>/gi;
      while((match=regex.exec(item.note||'')))if(Number(match[1])===14 || Number(match[1])===15)q=Math.max(q,Number(match[1]));
      return q;
    };
    H.normalize=function(item){
      if(!H.isGear(item))return;
      var q=H.quality(item);
      item.note=(item.note||'').replace(/<(quality|ici):\s*\d+>/gi,'')+'\n<quality:'+q+'>\n<ici:'+q+'>\n';
      item.meta=item.meta||{};item.meta.quality=String(q);item.meta.ici=String(q);
      item._codexHeartsteelQuality=q;
    };

    // 【Codex·未经Claude检验】v0.08：当前成长与待结算成长分开，保留随机词条。
    H.helpNumber=function(n){return String(Math.round(n*1000000)/1000000);};
    H.rewriteHelpRows=function(item,patterns,rows){
      item.note=String(item.note||'').replace(/<pos=APs text=([\s\S]*?) size=[^>]*>\s*/g,function(tag,text){
        var plain=text.replace(/\\c\[\d+\]/gi,'').replace(/:/g,'：');return patterns.some(function(p){return p.test(plain);})?'':tag;
      }).trim();
      rows.slice().reverse().forEach(function(text){if(/^(?:效果|战技|冷却|条件)：/.test(text))text='\\c[1]'+text;item.note+='\n<pos=APs text='+text+' size=18 color=rgba(255,255,255,1) line=false align=0>';});
    };

    // Same-color rows stay together, including native stats and preserved affix rows.
    H.groupHelpRows=function(view){
      if(!view||!view.descParams)return view;var order=[],groups={},probe=document.createElement('span');
      view.descParams.forEach(function(row){var match=/^\\[cC]\[(\d+)\]/.exec(String(row[0])),color=match?'palette:'+Number(match[1]):row[2];probe.style.color='';probe.style.color=String(color||'white');var key=probe.style.color||String(color);
        if(!groups[key]){groups[key]=[];order.push(key);}groups[key].push(row);
      });view.descParams=[].concat.apply([],order.map(function(key){return groups[key];}));return view;
    };
    H.helpPatterns=[/^(?:心之钢品质|已叠生命|物防结算|心钢层数|心钢|结算)：/,
      /^等级需求：无$/,/^基础属性：生命\+/,/^特效：全局回合结束回复/,/^战技：巨人吞噬/,
      /^伤害：(\(?[17]000?＋|\[(?:700|1000)＋)/,/^成长：(巨人吞噬|有效造成生命伤害|心钢层数)/,
      /^效果：(全局回合结束|每回合结束|巨人吞噬|敌方物防)/,/^冷却：巨人吞噬/,/^进度：心钢/,/^旧版生命：/,/^成长：额外最大生命/,/^本场成长：心钢/];
    H.damageText=function(item){var lev=H.isLeviathan(item);return '伤害：['+(lev?1000:700)+'＋常态最大生命×'+(lev?'8%':'6%')+']×'+H.helpNumber(1+0.1*H.stage(item));};

    H.helpRows=function(item){var k=H.stacks(item),n=H.stage(item);return [
      '成长：心钢层数'+k+'；最大生命×'+H.helpNumber(H.hpRate(item)),
      '进度：心钢升阶还需'+(H.stageNeed(n+1)-k)+'层',H.damageText(item),
      '效果：每回合结束回复'+(H.isLeviathan(item)?5:3)+'%最大生命',
      '战技：巨人吞噬；物理，单体，不可暴击',
      '冷却：巨人吞噬第2回合可用；冷却2回合',
      '效果：巨人吞噬命中积累心钢，胜利后保留'
    ];};
    H.describe=function(item){
      if(!H.isGear(item))return;
      item.description=String(item.description||'').replace(/^神武\n(?:13层[^\n]*|奥恩杰作。[^\n]*)/,$dataArmors[H.baseId(item)].description);
      var rows=H.helpRows(item);if(H.growth(item)>0)rows.splice(2,0,'成长：额外最大生命＋'+H.growth(item));
      H.rewriteHelpRows(item,H.helpPatterns,rows);
      if(window.RJO&&RJO.HE&&RJO.HE.getDescParams)RJO.HE.getDescParams(item,2);
    };
    H.helpView=function(item){var view=JsonEx.makeDeepCopy(item);H.describe(view);var pending=H.pending(item);if(pending){view.note+='\n<pos=APs text=本场成长：心钢＋'+pending+'层，胜利后保存 size=18 color=rgba(255,220,100,1) line=false align=0>';RJO.HE.getDescParams(view,2);}return H.groupHelpRows(view);};
    var heartHelp=Sprite_ItemHelp.prototype.setItem;
    Sprite_ItemHelp.prototype.setItem=function(item){return heartHelp.call(this,H.isGear(item)?H.helpView(item):item);};
    var heartDatabase=DataManager.isDatabaseLoaded;
    DataManager.isDatabaseLoaded=function(){var loaded=heartDatabase.apply(this,arguments);if(loaded&&!H._helpReady){H._helpReady=true;[H.armorId,H.leviathanId].forEach(function(id){H.describe($dataArmors[id]);});}return loaded;};
    var oldTags=DataManager.processYanflyTags;
    DataManager.processYanflyTags=function(item){H.normalize(item);return oldTags.apply(this,arguments);};
    var oldRegister=DataManager.addNewIndependentItem;
    DataManager.addNewIndependentItem=function(base,item){
      var out=oldRegister.apply(this,arguments);
      if(H.isGear(item)){
        // DreamX registers a temporary generated base before ItemCore gains
        // the owned instance; retain the actual original armor identity.
        var baseId=H.baseId(item);item.baseItemId=baseId;item.originalBaseItemId=baseId;
        item._codexHeartsteelHp=H.growth(item);item._codexHeartsteelStacks=H.stacks(item);H.normalize(item);H.describe(item);
      }
      return out;
    };
    // Roll only after the corresponding Unknown Existence battle is won.
    H.clearReward=function(result){
      // The entry route variable is not set by the laboratory/crystal shortcuts.
      // The actual immortal floor and native boss identity determine eligibility.
      var map=$gameMap.mapId(),troop=$gameTroop._troopId;
      if(result!==0 || map!==152 || H.unknownHeartOrigin()!==38 ||
          (troop!==454 && troop!==455) || BattleManager._codexHeartsteelRewardRolled)return false;
      BattleManager._codexHeartsteelRewardRolled=true;
      if(Math.random()>=0.10)return false;
      $gameParty.gainItem($dataArmors[H.armorId],1,false);
      if(window.$ && $.toaster)$.toaster({message:'获得神武：心之钢！'});
      return true;
    };
    H.round=function(){return Math.max(1,Number($gameTroop.turnCount())||1);};
    H.remaining=function(actor){
      var ready=Number(actor._codexHeartsteelReadyTurn);
      if(!Number.isFinite(ready))ready=2;
      return Math.max(0,ready-H.round());
    };
    H.effectiveHp=function(actor){
      // Evaluate a copy through the same parameter framework, retaining
      // learned passives and gear while clearing temporary battle effects.
      var copy=JsonEx.makeDeepCopy(actor);
      copy._states=copy._states.filter(function(id){return DataManager.isPermanent && DataManager.isPermanent($dataStates[id]);});
      copy._stateTurns={};copy._buffs=copy._buffs.slice();copy._buffs[0]=0;
      copy._cacheParamBuffRate={};
      copy._ParamCache2=[];copy._paramratecache=[];
      Object.keys(copy).forEach(function(key){if(/^need_refresh/.test(key))copy[key]=Array.isArray(copy[key])?copy[key].map(function(){return 1;}):true;});
      copy.need_refresh=true;
      copy.paramMax=function(id){return id===0?Infinity:Game_Actor.prototype.paramMax.call(this,id);};
      if(copy.initPassiveCache)copy.initPassiveCache();
      if(copy.refreshPassiveCache)copy.refreshPassiveCache();
      return Math.max(0,copy.param(0));
    };
    H.damage=function(actor,target,action){
      var cast=action && action._codexHeartsteelCast;
      if(!cast || !cast.valid)return 0;
      // HP-based strikes must remain usable against high-difficulty armor.
      // Keep linear defense below the cap; all native hit, resistance, flat
      // reduction and guard calculations still run after this base formula.
      return cast.baseDamage-Math.min(Math.max(0,Number(target.def)||0),cast.baseDamage*0.5);
    };
    var oldSkills=Game_Actor.prototype.skills;
    Game_Actor.prototype.skills=function(){
      var list=oldSkills.apply(this,arguments).filter(function(s){return !H.isSkill(s);}),gear=H.gear(this);
      if(gear)list.push($dataSkills[H.skillFor(gear)]);
      return list;
    };
    var oldConditions=Game_Actor.prototype.meetsSkillConditions;
    Game_Actor.prototype.meetsSkillConditions=function(skill){
      var gear=H.gear(this);
      if(H.isSkill(skill) && (!gear || skill.id!==H.skillFor(gear) || !$gameParty.inBattle() || H.remaining(this)>0))return false;
      return oldConditions.apply(this,arguments);
    };
    var oldParam=Game_Actor.prototype.paramPlus;
    Game_Actor.prototype.paramPlus=function(id){var value=oldParam.apply(this,arguments);return id===0?value+H.growth(H.gear(this)):value;};
    // Stage multiplier on max HP: applies to the actor's own total, no compounding.
    var oldFinalParam=Game_Actor.prototype.param;
    Game_Actor.prototype.param=function(id){
      var value=oldFinalParam.apply(this,arguments);if(id!==0)return value;
      var gear=H.gear(this),rate=gear?H.hpRate(gear):1;if(rate===1)return value;
      return Math.round(Math.min(this.paramMax(0),value*rate));
    };
    var oldSetup=BattleManager.setup;
    BattleManager.setup=function(){H._ledger=[];return oldSetup.apply(this,arguments);};
    var oldEndBattle=BattleManager.endBattle;
    BattleManager.endBattle=function(result){
      var rows=H._ledger;H._ledger=[];
      if(result===0)rows.forEach(function(r){r.item._codexHeartsteelStacks=H.stacks(r.item)+r.gain;H.describe(r.item);});
      var out=oldEndBattle.apply(this,arguments);
      if(result===0 && rows.length)$gameParty.allMembers().forEach(function(a){if(H.gear(a)){a.need_refresh=true;a.refresh();}});
      return out;
    };
    var oldBattle=BattleManager.startBattle;
    BattleManager.startBattle=function(){
      this._codexHeartsteelHealedTurn=null;
      $gameParty.allMembers().forEach(function(actor){actor._codexHeartsteelReadyTurn=2;delete actor._codexHeartsteelWait;actor._codexHeartsteelCasted=false;});
      return oldBattle.apply(this,arguments);
    };
    var oldStart=BattleManager.startAction;
    BattleManager.startAction=function(){
      var actor=this._subject,action=actor && actor.currentAction(),gear=H.gear(actor);
      if(action && gear && !action._codexHeartsteelStarted){
        action._codexHeartsteelStarted=true;action._codexHeartsteelGear=gear;
        if(H.isSkill(action.item())){
          var lev=H.isLeviathan(gear);
          action._codexHeartsteelCast={gear:gear,valid:action.item().id===H.skillFor(gear) && H.remaining(actor)===0,baseDamage:Math.floor(((lev?1000:700)+H.effectiveHp(actor)*(lev?0.08:0.06))*H.castScale(actor)),grown:false,applied:false};
        }
      }
      var out=oldStart.apply(this,arguments);
      var cast=action && action._codexHeartsteelCast;
      if(cast && cast.valid){actor._codexHeartsteelReadyTurn=H.round()+2;actor._codexHeartsteelCasted=true;}
      return out;
    };
    var oldRepeats=Game_Action.prototype.numRepeats;
    Game_Action.prototype.numRepeats=function(){return H.isSkill(this.item())?1:oldRepeats.apply(this,arguments);};
    var oldApply=Game_Action.prototype.apply;
    Game_Action.prototype.apply=function(target){
      var special=H.isSkill(this.item()),cast=this._codexHeartsteelCast;
      if(special && (!cast || !cast.valid || cast.applied || BattleManager._action!==this))return;
      var hp=target.hp;
      if(special)cast.applied=true;
      var out=oldApply.apply(this,arguments);
      // v0.3: a landed hit earns stacks even when flat reduction absorbs the damage.
      var weight=special && !cast.grown && hp>0 && target.result().isHit()?H.enemyWeight(target):0;
      if(weight){cast.grown=true;H.addPending(cast.gear,weight);}
      return out;
    };
    // OTB's actor turn-end callbacks can occur per action. Heal at global
    // round completion instead, once for each BattleManager.endTurn call.
    var oldRound=BattleManager.endTurn;
    BattleManager.endTurn=function(){
      var out=oldRound.apply(this,arguments);
      var turn=$gameTroop.turnCount();
      if(this._phase==='turnEnd' && this._codexHeartsteelHealedTurn!==turn){
        this._codexHeartsteelHealedTurn=turn;
        $gameParty.battleMembers().forEach(function(actor){var gear=H.gear(actor);if(gear && actor.isAlive())actor.gainHp(Math.floor(actor.mhp*(H.isLeviathan(gear)?0.05:0.03)));});
      }
      return out;
    };
    var oldLoad=DataManager.extractSaveContents;
    DataManager.extractSaveContents=function(){
      var out=oldLoad.apply(this,arguments);
      ($dataArmors||[]).forEach(function(item){if(H.isGear(item) && item.id!==H.armorId && item.id!==H.leviathanId){H.normalize(item);H.describe(item);}});
      H.unlockForge(false);
      return out;
    };

    H.skillHelpView=function(skill,actor){
      var view=JsonEx.makeDeepCopy(skill),gear=H.gear(actor),lev=skill.id===H.leviathanSkillId;
      if(!gear||H.skillFor(gear)!==skill.id)gear=$dataArmors[lev?H.leviathanId:H.armorId];

      var rows=['目标：敌方单体；伤害属性：物理','命中类型：物理；能否暴击：否；攻击次数：1','消耗：0MP／0TP',H.damageText(gear)];
      if(actor&&$gameParty.inBattle()){var n=H.remaining(actor);rows.push(n===0?'状态：巨人吞噬已就绪':actor._codexHeartsteelCasted?'状态：巨人吞噬冷却，还需'+n+'回合':'状态：巨人吞噬蓄力，还需'+n+'回合');}
      rows.push('效果：命中积累心钢，胜利后保留','条件：装备'+(lev?'杰作利维坦':'心之钢')+'；第2回合起可用','冷却：2回合');
      H.rewriteHelpRows(view,[/.*/],rows);RJO.HE.getDescParams(view,3);return view;
    };
    function wrapHelp(oldHelp){return function(){var out=oldHelp.apply(this,arguments),skill=this.item&&this.item();if(H.isSkill(skill)&&this._helpWindow)this._helpWindow.setItem(H.skillHelpView(skill,this._actor));return out;};}
    Window_BattleSkill.prototype.updateHelp=wrapHelp(Window_BattleSkill.prototype.updateHelp);
    Window_SkillList.prototype.updateHelp=wrapHelp(Window_SkillList.prototype.updateHelp);
    window.CodexRuntime.install("installNativeLeviathanForge", H);
  }


return installNativeHeartsteelRuntime.apply(this, arguments);
});
