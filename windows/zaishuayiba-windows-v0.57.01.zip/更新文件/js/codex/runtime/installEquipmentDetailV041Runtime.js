// 【Codex·未经Claude检验】v0.43：详情仅接收画布手势，保留虚拟按键；精简持武增伤说明及旧缓存。
// 【Codex·未经Claude检验】v0.42：Android15原生触摸命中UpperCanvas透明层，详情滑动同步接管该原生覆盖层。
// 【Codex·未经Claude检验】v0.41 persistent, paged equipment details and explicit held-weapon damage help.
window.CodexRuntime.register('installEquipmentDetailV041Runtime',function(){
 'use strict';var W=window,E=W.CodexEquipment41={version:41};
 function alias(o,k,f){var old=o[k];o[k]=function(){return f.call(this,old,arguments);};}
 // Sort only effect positions, keeping names, base attributes, requirements and prices anchored.
 var previousRows=CodexDisplay.equipmentRows;
 function plain41(t){return CodexDisplay.text(String(t||'')).replace(/(?:\\|\x1b)c\[\d+\]/gi,'').replace(/[\s:：]/g,'');}
 CodexDisplay.equipmentRows=function(i){
  previousRows(i);if(!i||!i.descParams||i.wtypeId===undefined&&i.atypeId===undefined)return;
  // Remove only v0.41 generated explanations, including persisted old-save rows.
  i.descParams=i.descParams.filter(function(r){return !/^效果：(?:持有.+时，造成的技能伤害[＋+]|持武增伤作用于)/.test(String(r[0]||''));});
  i.descParams.forEach(function(r){r[0]=CodexDisplay.text(r[0]);});
  var source={},q=0,re=/<quality:\s*(\d+)>|<pos=\S+\s+text=([\s\S]*?)\s+size=/gi,m;
  while((m=re.exec(i.note||''))){if(m[1]!==undefined)q=Number(m[1]);else source[plain41(m[2])]=CodexQuality.rank(q);}
  var db=i.wtypeId!==undefined?$dataWeapons:$dataArmors,b=db[Number(i.originalBaseItemId||i.baseItemId||i.id)],baseRank=b?CodexQuality.rank(b):0,indices=[],effects=[];
  i.descParams.forEach(function(r,n){var text=plain41(r[0]),kind=/^(?:混沌神话|混沌|神话|太古|mod)特效|^(?:特效|效果|成长)/i.test(text),blue=/(?:\\|\x1b)c\[[1-9]\d*\]/i.test(String(r[0]||''));
   if(!kind&&!blue)return;
   var rank=source[text]===undefined?baseRank:source[text];if(/^混沌(?:神话)?特效/.test(text))rank=111;else if(/^神话特效/.test(text))rank=110;else if(/^mod特效/i.test(text))rank=93;else if(/^太古特效/.test(text))rank=91;
   indices.push(n);effects.push({row:r,rank:rank,index:n});
  });effects.sort(function(a,b){return b.rank-a.rank||a.index-b.index;});indices.forEach(function(n,k){i.descParams[n]=effects[k].row;});
 };
 function row(text,color){return [text,20,color||'#ffffff',false,0];}
 // Apply at the common display boundary: native rows, forge previews and cached help.
 var previousText43=CodexDisplay.text;
 CodexDisplay.text=function(text){text=previousText43(text);return typeof text==='string'?text.replace(/(?:全)?武器伤(?:害)?(?=[＋+]\s*[\d.]+%)/g,'装备武器时，技能伤害'):text;};
 // The status weapon column shows the condition and whether it is currently satisfied.
 if(W.JAH_Window_Status_Resistances){alias(JAH_Window_Status_Resistances.prototype,'calcWeaponBonus',function(old,args){var text=old.apply(this,args);return text+(this._actor.isWtypeEquipped(Number(args[0]))?' 生效':' 未持有');});}
 function Detail(){this.initialize.apply(this,arguments);}
 Detail.prototype=Object.create(Window_Base.prototype);Detail.prototype.constructor=Detail;
 Detail.prototype.initialize=function(x,y,w,h){Window_Base.prototype.initialize.call(this,x,y,w,h);this._page41=0;this._pages41=1;this._item41=null;this._key41='';this._mode41=0;};
 Detail.prototype.setEquipment=function(i){var key=i?i.id+':'+i.note+':'+JSON.stringify(i.params)+':'+JSON.stringify(i.augmentSlotItems)+':'+JSON.stringify(i.slotsApplied):'';if(key===this._key41)return;this._key41=key;this._item41=i;this.render41();};
 Detail.prototype.setMode=function(n){this._mode41=n;this.render41();};
 Detail.prototype.rows41=function(){
  var i=this._item41;if(!i)return [row('选择左侧装备，查看完整信息。')];
  if(this._mode41===2){var rows=[row(CodexQuality.starName(i),'#ffe499')],slots=i.augmentSlots||[],gems=i.augmentSlotItems||[];
   rows.push(row('宝珠插槽：'+slots.length+'个'));
   slots.forEach(function(t,n){var gem=gems[n]&&gems[n]!=='none'?ItemManager.augmentInSlot(i,n):null;rows.push(row((n+1)+'．'+t+'：'+(gem?gem.name:'空槽')));});
   rows.push(row('符文镶嵌：剩余 '+Math.max(0,Number(i.upgradeSlots)||0)+' 孔'));
   (i.slotsApplied||[]).forEach(function(t,n){rows.push(row((n+1)+'．'+String(t)));});
   if(!(i.slotsApplied||[]).length)rows.push(row('尚无符文镶嵌记录。'));
   rows.push(row('镶嵌操作可在物品菜单选择这件装备。','#9cceff'));rows.push(row('说明较长时，在右侧上下滑动查看。','#9cceff'));return rows;
  }
  var v=Object.assign({},i);v.params=(i.params||[]).slice();RJO.HE.getDescParams(v,DataManager.isWeapon(i)?1:2);if(v.descParams&&v.descParams[0])v.descParams[0][0]=CodexQuality.starName(i);return CodexDisplay.readableView(v).descParams;
 };
 Detail.prototype.render41=function(){
  var rows=this.rows41(),width=this.contentsWidth(),height=0;this.createContents();RJO.SW.setContent(this.contents,0);
  rows.forEach(function(r){RJO.SW.changeTextSize(Math.min(22,Number(r[1])||20));RJO.SW.setupTextState(String(r[0]||''),0,height,width,r[4]);height+=RJO.SW.textHeight+8;});
  this._fullHeight41=Math.max(1,height);this.contents=new Bitmap(width,Math.max(this.contentsHeight(),height));RJO.SW.setContent(this.contents,0);height=0;
  rows.forEach(function(r){RJO.SW.changeTextSize(Math.min(22,Number(r[1])||20));RJO.SW.changeTextColor(r[2]||'#ffffff');RJO.SW.drawContentText(String(r[0]||''),0,height,width,r[4]);height+=RJO.SW.textHeight+8;});
  this._page41=0;this.origin.y=0;this._pages41=Math.max(1,1+Math.ceil(Math.max(0,this._fullHeight41-this.contentsHeight())/Math.max(1,this.contentsHeight()-40)));this.nav41();
 };
 Detail.prototype.nav41=function(){if(this._nav41)this._nav41.setText('上下滑动／滚轮／PgUp PgDn　'+(this._page41+1)+'／'+this._pages41);};
 Detail.prototype.scroll41=function(d){var max=Math.max(0,this._fullHeight41-this.contentsHeight());this.origin.y=Math.max(0,Math.min(max,this.origin.y+d));this._page41=this.origin.y>=max?this._pages41-1:Math.min(this._pages41-1,Math.floor(this.origin.y/Math.max(1,this.contentsHeight()-40)));this.nav41();};
 Detail.prototype.turn41=function(n){this._page41=Math.max(0,Math.min(this._pages41-1,this._page41+n));this.origin.y=Math.min(Math.max(0,this._fullHeight41-this.contentsHeight()),this._page41*Math.max(1,this.contentsHeight()-40));this.nav41();};
 E.Detail=Detail;
 alias(Sprite_ItemHelp.prototype,'setItem',function(old,args){var s=SceneManager._scene;if(s instanceof Scene_Equip&&!this._isExtra&&s._helpWindow===this){this.item=args[0];this.hide();if(s._detail41)s._detail41.setEquipment(args[0]);return;}return old.apply(this,args);});
 alias(Scene_Equip.prototype,'create',function(old,args){var out=old.apply(this,args),w=this._compareWindow,x=w.x,y=w.y,width=w.width,height=w.height,bar=58;
  this._tabs41=new Window_Help(1);this._tabs41.move(x,y,width,bar);this._tabs41.createContents();this.addWindow(this._tabs41);
  this._nav41=new Window_Help(1);this._nav41.move(x,y+height-bar,width,bar);this._nav41.createContents();this.addWindow(this._nav41);
  this._detail41=new Detail(x,y+bar,width,height-bar*2);this._detail41._nav41=this._nav41;this.addWindow(this._detail41);
  w.move(x,y+bar,width,height-bar*2);w.createContents();w.refresh();if(this._infoWindow)this._infoWindow.hide();this._lowerRightWindows=[this._detail41,w];this._equipMode41=0;this.chooseDetail41(0);this._helpWindow.hide();return out;
 });
 Scene_Equip.prototype.chooseDetail41=function(n){this._equipMode41=(n+3)%3;this._detail41.visible=this._equipMode41!==1;this._compareWindow.visible=this._equipMode41===1;if(this._infoWindow)this._infoWindow.hide();this._detail41.setMode(this._equipMode41);this._nav41.visible=this._equipMode41!==1;this._tabs41.setText(['装备详情','属性对比','插槽与镶嵌'].map(function(t,i){return (i===this._equipMode41?'【'+t+'】':t);},this).join('　'));};
 Scene_Equip.prototype.updateLowerRightWindows=function(){if(!this._detail41){(this._lowerRightWindows||[]).forEach(function(w,i){w.visible=i===0&&this._lowerRightVisibility;},this);return;}this.chooseDetail41(this._equipMode41);};
 Scene_Equip.prototype.updateLowerRightWindowTriggers=function(){if(!this._detail41)return;var t=this._tabs41,n=this._nav41;
  if(Input.isRepeated('right')||Input.isTriggered('tab'))this.chooseDetail41(this._equipMode41+1);else if(Input.isRepeated('left'))this.chooseDetail41(this._equipMode41-1);
  if(TouchInput.isTriggered()&&TouchInput.x>=t.x&&TouchInput.x<t.x+t.width&&TouchInput.y>=t.y&&TouchInput.y<t.y+t.height)this.chooseDetail41(Math.min(2,Math.floor((TouchInput.x-t.x)*3/t.width)));
  if(this._equipMode41!==1&&TouchInput.x>=n.x&&TouchInput.x<n.x+n.width){if(TouchInput.isTriggered()&&TouchInput.y>=n.y&&TouchInput.y<n.y+n.height)this._detail41.turn41(TouchInput.x<n.x+n.width/2?-1:1);else if(TouchInput.y>=this._detail41.y&&TouchInput.y<n.y){if(Math.abs(TouchInput.wheelY)>=1)this._detail41.scroll41(TouchInput.wheelY);}}
 };
 // Handle the detail surface before virtual game buttons consume its touch events.
 // Dragging changes only the visible offset, never the active equipment or selection.
 var drag41=null;
 function detailSurface43(target){return !target||target===window||target===document||target===document.body||target===Graphics._canvas||target===Graphics._upperCanvas;}
 function point41(e){return {x:Graphics.pageToCanvasX(e.pageX),y:Graphics.pageToCanvasY(e.pageY)};}
 function detailScene41(){var s=SceneManager._scene;return s instanceof Scene_Equip&&s._detail41&&s._detail41.visible&&[s._itemWindow,s._slotWindow,s._commandWindow].some(function(w){return w&&w.active;})?s:null;}
 E.dragDetail41=function(win,dy){win.scroll41(-dy);};
 function consume41(e){if(e.cancelable)e.preventDefault();e.stopImmediatePropagation();if(W.AndroidPort&&AndroidPort.releaseTouchKeys)AndroidPort.releaseTouchKeys();TouchInput.clear();}
 window.addEventListener('pointerdown',function(e){var s=detailScene41();if(!s||e.button>0)return;if(!detailSurface43(e.target))return;var p=point41(e),d=s._detail41;if(p.x<d.x||p.x>=d.x+d.width||p.y<d.y||p.y>=d.y+d.height)return;drag41={scene:s,id:e.pointerId,y:p.y};consume41(e);},true);
 window.addEventListener('pointermove',function(e){if(!drag41||drag41.id!==e.pointerId)return;var p=point41(e);if(detailScene41()===drag41.scene)E.dragDetail41(drag41.scene._detail41,p.y-drag41.y);drag41.y=p.y;consume41(e);},true);
 ['pointerup','pointercancel'].forEach(function(k){window.addEventListener(k,function(e){if(!drag41||drag41.id!==e.pointerId)return;drag41=null;consume41(e);},true);});
 // Older WebViews may expose touch events without PointerEvent.
 if(!W.PointerEvent){
  window.addEventListener('touchstart',function(e){var t=e.changedTouches[0],s=detailScene41();if(!t||!s||!detailSurface43(e.target))return;var p=point41(t),d=s._detail41;if(p.x<d.x||p.x>=d.x+d.width||p.y<d.y||p.y>=d.y+d.height)return;drag41={scene:s,id:t.identifier,y:p.y};consume41(e);},{capture:true,passive:false});
  window.addEventListener('touchmove',function(e){if(!drag41)return;var t=Array.prototype.find.call(e.changedTouches,function(t){return t.identifier===drag41.id;});if(!t)return;var p=point41(t);E.dragDetail41(drag41.scene._detail41,p.y-drag41.y);drag41.y=p.y;consume41(e);},{capture:true,passive:false});
  ['touchend','touchcancel'].forEach(function(k){window.addEventListener(k,function(e){if(drag41){drag41=null;consume41(e);}},{capture:true,passive:false});});
 }
 window.addEventListener('keydown',function(e){var s=detailScene41();if(!s||['PageDown','PageUp'].indexOf(e.code)<0)return;s._detail41.turn41(e.code==='PageDown'?1:-1);if(e.cancelable)e.preventDefault();e.stopImmediatePropagation();},true);
 alias(Scene_Equip.prototype,'update',function(old,args){var out=old.apply(this,args);if(this._detail41){this._helpWindow.hide();var list=this._itemWindow.visible?this._itemWindow:this._slotWindow;this._detail41.setEquipment(list.item());}return out;});
 return E;
});
