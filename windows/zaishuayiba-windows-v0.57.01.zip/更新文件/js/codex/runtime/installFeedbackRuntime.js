window.CodexRuntime.register('installFeedbackRuntime',function(){
 'use strict';
 var F=window.CodexFeedback={version:1},session=null,host=null,promptPending=false,clearRecord=null,retrying=false;
 var config=window.CodexFeedbackConfig||{},draftKey='codex.feedback.draft.v1';
 function endpoint(){var s=String(config.endpoint||'').replace(/\/$/,'');if(!s)return '';if(!/^https:\/\//.test(s)&&!(config.allowLocalDevelopment===true&&/^http:\/\/127\.0\.0\.1:\d+$/.test(s)))throw new Error('反馈服务需要安全连接。');return s;}
 function readDraft(){try{return localStorage.getItem(draftKey)||'';}catch(e){return '';}}
 function draft(text){try{localStorage.setItem(draftKey,String(text).slice(0,4000));}catch(e){}}
 function id(){var a=new Uint8Array(16);window.crypto.getRandomValues(a);return Array.from(a).map(function(n){return n.toString(16).padStart(2,'0');}).join('');}
 function outbox(){if(!Utils.isNwjs())return null;var fs=require('fs'),path=require('path'),dir=path.join(path.dirname(StorageManager.localFileDirectoryPath().replace(/[\\/]$/,'')),'feedback-outbox');fs.mkdirSync(dir,{recursive:true,mode:448});return {fs:fs,path:path,dir:dir};}
 function pending(){var box=outbox();if(!box)return [];return box.fs.readdirSync(box.dir).filter(function(n){return /^[a-f0-9]{32}\.json$/.test(n);}).map(function(n){var file=box.path.join(box.dir,n);try{return {file:file,payload:JSON.parse(box.fs.readFileSync(file,'utf8'))};}catch(e){return null;}}).filter(Boolean);}
 function queue(p){var box=outbox();if(!box)throw new Error('当前环境无法暂存附件，请联网后重试。');if(pending().length>=5)throw new Error('已有5份待提交反馈，请联网后再试。');var file=box.path.join(box.dir,p.requestId+'.json'),tmp=file+'.tmp';box.fs.writeFileSync(tmp,JSON.stringify(p),{mode:384});box.fs.renameSync(tmp,file);return file;}
 function remove(file){var box=outbox();if(box&&file){try{box.fs.unlinkSync(file);}catch(e){if(e.code!=='ENOENT')throw e;}}}
 // 【Codex·未经Claude检验】Network failures are not proof of an offline PC.
 function temporary(e){return e.retryable===true||!e.status||e.status>=500||e.status===429;}
 function failureText(e){
  if(e.code==='offline')return '当前设备报告未联网，请恢复网络后重试。';
  if(e.code==='timeout')return '连接反馈服务超时；有网络时也可能是线路或服务暂时不可达。';
  if(e.code==='network')return '无法连接反馈服务；请检查该网址能否打开，或稍后重试。';
  return e.message||'反馈服务暂时不可用，请稍后重试。';
 }
 async function request(route,p,token){
  var base=endpoint();if(!base)throw new Error(route.indexOf('/api/test/')===0?'测试验证服务暂未开放，请联系作者。':'反馈服务暂未开放，内容已保留在草稿中。');
  var controller=new AbortController(),timer=setTimeout(function(){controller.abort();},15000);
  try{
   var headers={Accept:'application/json'};if(p)headers['Content-Type']='application/json';if(token)headers.Authorization='Bearer '+token;
   var r=await fetch(base+route,{method:p?'POST':'GET',headers:headers,body:p?JSON.stringify(p):undefined,signal:controller.signal,credentials:'omit'});
   var d;try{d=await r.json();}catch(parseError){var invalid=new Error('反馈服务返回了无法识别的页面（HTTP '+r.status+'），可能遇到线路拦截或服务验证。');invalid.status=r.status;invalid.code='response';invalid.retryable=true;throw invalid;}
   if(!r.ok){var http=new Error(d&&d.error||'反馈服务暂时不可用（HTTP '+r.status+'）。');http.status=r.status;throw http;}
   if(!d||typeof d!=='object'){var invalid=new Error('反馈服务返回的数据无效，请稍后重试。');invalid.code='response';invalid.retryable=true;throw invalid;}
   return d;
  }catch(e){
   if(!e.status&&typeof e.code!=='string'){var network=new Error();network.code=e.name==='AbortError'?'timeout':navigator.onLine===false?'offline':'network';network.retryable=true;network.message=failureText(network);throw network;}
   throw e;
  }finally{clearTimeout(timer);}
 }
 var sending=new Map(),accepted=new Set();
 function send(file,p){
  if(sending.has(file))return sending.get(file);
  var promise=request('/api/feedback',p).then(function(d){if(d.received!==true)throw new Error('服务未确认收到，提交已保留，请稍后重试。');remove(file);accepted.add(file);return d;}).finally(function(){sending.delete(file);});
  sending.set(file,promise);return promise;
 }
 F.connectionStatus=async function(){try{var d=await request('/api/health');return d.ready===true?'反馈服务可连接；提交仍需服务确认。':'反馈服务尚未就绪，请稍后重试。';}catch(e){return failureText(e);}};
 F.retry=async function(){
  if(retrying||!endpoint())return {sent:0,remaining:pending().length};retrying=true;var sent=0,error='';
  try{var rows=pending();for(var i=0;i<rows.length;i++){try{await send(rows[i].file,rows[i].payload);sent++;}catch(e){error=failureText(e);if(!temporary(e)){remove(rows[i].file);continue;}break;}}}
  finally{retrying=false;}return {sent:sent,remaining:pending().length,error:error};
 };
 function close(){if(host){host.remove();host=null;}Input.clear();TouchInput.clear();}
 F.close=close;
 function pinActions(node){var actions=node.querySelector('.actions');if(actions)node.querySelector('.panel').insertBefore(actions,node.querySelector('output'));}
 function shell(title){if(host)return null;Input.clear();TouchInput.clear();var node=document.createElement('div');node.id='codex-feedback';node.innerHTML='<style>#codex-feedback{position:fixed;inset:0;z-index:100000;display:grid;place-items:center;background:rgba(7,12,20,.82);font:18px/1.65 system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;color:#e5eaf0}#codex-feedback *{box-sizing:border-box}#codex-feedback .panel{width:min(680px,92vw);max-height:91vh;overflow:hidden;display:flex;flex-direction:column;background:#17212d;border:1px solid #54606e;border-radius:16px;padding:24px 28px;box-shadow:0 24px 80px #0008}#codex-feedback .body{overflow:auto;min-height:0;padding-right:4px}#codex-feedback h1{flex-shrink:0;font-size:27px;color:#d8be7b;margin:0 0 7px}#codex-feedback p{margin:7px 0 17px;font-size:15px;color:#aebccd}#codex-feedback label{display:block;margin:12px 0 6px;font-size:15px}#codex-feedback input,#codex-feedback textarea,#codex-feedback select{width:100%;background:#101924;border:1px solid #536172;border-radius:7px;color:#eef0f4;padding:10px;font:inherit}#codex-feedback textarea{min-height:120px;resize:vertical}#codex-feedback input[type=checkbox]{width:auto;accent-color:#c6a86b}#codex-feedback input:focus,#codex-feedback textarea:focus{outline:2px solid #91b2c9}#codex-feedback .notice{border-left:3px solid #c7a76d;background:#202d3a;padding:10px 13px;font-size:14px;color:#d6e1ed}#codex-feedback .actions{display:flex;justify-content:flex-end;gap:10px;margin-top:15px;flex-shrink:0}#codex-feedback button{border:1px solid #718094;background:#263344;color:#e3e9f0;border-radius:7px;padding:10px 19px;font:inherit;cursor:pointer}#codex-feedback button.primary{background:#c6a86b;color:#14202b;border-color:#c6a86b}#codex-feedback button:disabled{opacity:.6;cursor:wait}#codex-feedback output:empty{display:none}#codex-feedback output{flex-shrink:0;display:block;margin-top:13px;font-size:14px;color:#a4d1dd;white-space:pre-wrap}</style><section class="panel"><h1></h1><div class="body"></div><output role="status" aria-live="polite"></output></section>';
  node.querySelector('h1').textContent=title;document.body.appendChild(node);host=node;
  ['keydown','keyup','mousedown','mouseup','click','wheel','touchstart','touchend'].forEach(function(k){node.addEventListener(k,function(e){e.stopPropagation();});});
  node.addEventListener('keydown',function(e){if(e.key==='Escape'){e.preventDefault();close();}});return node;
 }
 F.open=function(clear){var record=clear||null,node=shell(clear?'恭喜通关 · 留下你的反馈':'玩家反馈');if(!node)return;var body=node.querySelector('.body');body.innerHTML='<p>把遇到的问题或游玩感想告诉作者。可以暂存，联网后再提交。</p><div data-field="save-area" hidden><label><input type="checkbox" data-field="share" checked> 附上本次通关存档</label><div class="notice" data-field="notice"></div></div><label>反馈类型</label><select data-field="category"><option>问题</option><option>建议</option><option>平衡</option><option>其他</option></select><label>反馈内容</label><textarea data-field="text" maxlength="4000" placeholder="在哪一层、发生了什么、有什么建议…"></textarea><label>联系方式（选填）</label><input data-field="contact" maxlength="120" placeholder="方便作者进一步联系你"><p>反馈会发送给游戏作者保存和查看。关闭此窗口不会上传。</p><div class="actions"><button data-action="close">暂不提交</button><button data-action="submit" class="primary">提交反馈</button></div>';
  var text=node.querySelector('[data-field=text]'),share=node.querySelector('[data-field=share]'),button=node.querySelector('[data-action=submit]'),status=node.querySelector('output');text.value=readDraft();text.oninput=function(){draft(text.value);};
  if(record){var category=body.querySelector('[data-field=category]'),option=document.createElement('option');option.textContent='通关感想';category.appendChild(option);body.querySelector('p').textContent='可以写下通关感想，也可以只提交勾选的通关存档。';body.querySelector('[data-field=save-area]').hidden=false;body.querySelector('[data-field=notice]').textContent='通关难度：'+record.difficulty+'。存档包含队伍、装备、养成与进度，供作者下载。取消勾选只提交文字；点击提交后才会上传。';body.querySelector('[data-field=category]').value='通关感想';}
  var queuedFile=null,queuedPayload=null;pinActions(node);function label(){button.textContent=record&&share.checked?'提交反馈与存档':'提交反馈';}share.onchange=label;label();
  node.querySelector('[data-action=close]').onclick=function(){draft(text.value);close();};
  button.onclick=async function(){if(!text.value.trim()&&!(record&&share.checked)){status.textContent='请填写反馈内容。';text.focus();return;}button.disabled=true;
   var p={requestId:id(),category:body.querySelector('[data-field=category]').value,text:text.value.trim()||'通关记录',contact:body.querySelector('[data-field=contact]').value.trim(),version:config.version||'KYO',difficultyId:record?record.difficultyId:String($gameSystem.difficultyId()),difficulty:record?record.difficulty:difficultyName(),cleared:!!record,shareSave:!!(record&&share.checked)};
   if(p.shareSave)p.save=record.save;
   try{
    if(!endpoint())throw new Error('反馈服务暂未开放，内容已保留在草稿中。');
    if(!queuedFile){queuedPayload=p;queuedFile=queue(p);}
    // A background retry may already have sent this exact queued request.
    var box=outbox();if(box.fs.existsSync(queuedFile))await send(queuedFile,queuedPayload);else if(!accepted.has(queuedFile)){var cancelled=new Error('这份待提交反馈已取消，可编辑后重新提交。');cancelled.status=410;throw cancelled;}
    draft('');button.textContent='已收到';status.textContent='反馈已收到，谢谢你。';text.disabled=true;node.querySelector('[data-action=close]').textContent='返回游戏';
   }catch(e){
    if(!temporary(e)){if(queuedFile)remove(queuedFile);queuedFile=null;queuedPayload=null;text.disabled=false;body.querySelectorAll('input,select').forEach(function(x){x.disabled=false;});status.textContent=e.message;label();button.disabled=false;}
    else if(queuedFile){draft('');button.textContent='重试提交';status.textContent=failureText(e)+'\n这份提交已暂存，可立即重试；后台每分钟尝试一次。可在设置「待提交反馈」取消。';button.disabled=false;text.disabled=true;body.querySelectorAll('input,select').forEach(function(x){x.disabled=true;});}
    else{status.textContent=failureText(e);button.disabled=false;}
   }};text.focus();
 };
 F.openPending=function(){var node=shell('待提交反馈');if(!node)return;var rows=pending(),body=node.querySelector('.body');body.appendChild(document.createTextNode(rows.length?'这些反馈曾由你点击提交，联网后会继续发送。':'没有待提交的反馈。'));
  rows.forEach(function(r){var block=document.createElement('p'),button=document.createElement('button');block.textContent=r.payload.text.slice(0,100)+(r.payload.save?'（附存档）':'');button.textContent='取消这份提交';button.onclick=function(){remove(r.file);block.remove();button.remove();};body.append(block,button);});var retry=document.createElement('button');retry.textContent='立即重试';retry.disabled=!rows.length;retry.onclick=async function(){retry.disabled=true;var result=await F.retry();if(host!==node)return;close();F.openPending();if(host)host.querySelector('output').textContent='本次收到 '+result.sent+' 份，剩余 '+result.remaining+' 份。'+(result.error?' '+result.error:'');};body.appendChild(retry);
  var test=document.createElement('button');test.textContent='检查反馈服务连接';test.onclick=async function(){test.disabled=true;node.querySelector('output').textContent=await F.connectionStatus();test.disabled=false;};body.appendChild(test);
  var address=document.createElement('p');address.textContent='反馈网址：'+endpoint();body.appendChild(address);
  var b=document.createElement('button');b.textContent='返回游戏';b.onclick=close;body.appendChild(b);};
 function difficultyName(){return $gameSystem.difficultyName?$gameSystem.difficultyName().replace(/\\[Cc]\[\d+\]/g,''):'难度 '+$gameSystem.difficultyId();}
 F.captureClear=function(meta){meta=meta||{difficultyId:String($gameSystem.difficultyId()),difficulty:difficultyName()};var contents=DataManager.makeSaveContents();contents.system=JsonEx.makeDeepCopy(contents.system);contents.system.onBeforeSave();contents.system._codexClearRecord={difficultyId:meta.difficultyId,difficulty:meta.difficulty,completedAt:meta.completedAt||new Date().toISOString()};return {difficultyId:meta.difficultyId,difficulty:meta.difficulty,save:LZString.compressToBase64(JsonEx.stringify(contents))};};
 var victory=BattleManager.processVictory;BattleManager.processVictory=function(){var final=$gameMap.mapId()===157&&$gameTroop._troopId===469;var meta=final?{difficultyId:String($gameSystem.difficultyId()),difficulty:difficultyName(),completedAt:new Date().toISOString()}:null;var r=victory.apply(this,arguments);if(final){promptPending=meta;}return r;};
 var mapUpdate=Scene_Map.prototype.update;Scene_Map.prototype.update=function(){if(host)return;mapUpdate.apply(this,arguments);if(promptPending&&!$gameMessage.isBusy()&&!$gameParty.inBattle()&&!$gameMap.isEventRunning()){clearRecord=F.captureClear(promptPending);promptPending=false;F.open(clearRecord);}};
 var menuUpdate=Scene_MenuBase.prototype.update;Scene_MenuBase.prototype.update=function(){if(host)return;return menuUpdate.apply(this,arguments);};
 var menuList=Window_MenuCommand.prototype.makeCommandList;Window_MenuCommand.prototype.makeCommandList=function(){menuList.apply(this,arguments);var index=this._list.findIndex(function(c){return c.symbol==='options';});this._list.splice(index<0?this._list.length:index,0,{name:'反馈',symbol:'codexFeedback',enabled:true,ext:null});};
 var menuCreate=Scene_Menu.prototype.createCommandWindow;Scene_Menu.prototype.createCommandWindow=function(){menuCreate.apply(this,arguments);this._commandWindow.setHandler('codexFeedback',function(){F.open();this._commandWindow.activate();}.bind(this));};
 var optionList=Window_Options.prototype.makeCommandList;Window_Options.prototype.makeCommandList=function(){F.checkAuthorKey();optionList.apply(this,arguments);this.addCommand('待提交反馈','codexFeedbackPending');};
 var optionOK=Window_Options.prototype.processOk,optionStatus=Window_Options.prototype.statusText,optionChange=Window_Options.prototype.changeValue;
 Window_Options.prototype.processOk=function(){if(this.commandSymbol(this.index())==='codexFeedbackPending')return F.openPending();return optionOK.apply(this,arguments);};
 Window_Options.prototype.statusText=function(i){var s=this.commandSymbol(i);return s==='codexFeedbackPending'?String(pending().length)+' 份':s==='codexTestMode'?(F.hasAuthorKey()?(ConfigManager.codexTestMode?'开（作者）':'关（作者）'):F.testAuthorized()&&ConfigManager.codexTestMode?'已验证':'密码验证'):optionStatus.apply(this,arguments);};
 // 2026-10-10 作者钥匙：本机存档目录上一层的 codex_author_key.txt，其 SHA-256 与 AUTHOR_KEY_SHA256 一致即视为作者本机。
 // 客户端只有摘要，没有钥匙本身；发给玩家的包不含钥匙文件。读取结果缓存，打开设置时重新检查一次。
 F.AUTHOR_KEY_SHA256='72820bff6d5a9659d488549ca4b30da968e5aa75f9c075807f3013c8217c9f6a';
 F.authorKeyPath=function(){try{var path=require('path');return path.join(path.dirname(StorageManager.localFileDirectoryPath()),'codex_author_key.txt');}catch(e){return '';}};
 var authorKey=null;
 F.checkAuthorKey=function(){authorKey=false;try{var fs=require('fs'),crypto=require('crypto'),file=F.authorKeyPath();if(file&&fs.existsSync(file)){var key=String(fs.readFileSync(file,'utf8')).trim();authorKey=!!key&&crypto.createHash('sha256').update(key).digest('hex')===F.AUTHOR_KEY_SHA256;}}catch(e){authorKey=false;}return authorKey;};
 F.hasAuthorKey=function(){return authorKey===null?F.checkAuthorKey():authorKey;};
 F.testAuthorized=function(){return F.hasAuthorKey()||!!(session&&Date.now()<session.expiresAt);};
 CodexTestMode.enabled=function(){return ConfigManager.codexTestMode===true&&F.testAuthorized();};
 ConfigManager.codexTestMode=false;
 var applyConfig=ConfigManager.applyData,makeConfig=ConfigManager.makeData;
 // 作者本机记住开关；其他人每次启动都关闭（服务器验证的会话不跨启动）。
 ConfigManager.applyData=function(d){var r=applyConfig.apply(this,arguments);this.codexTestMode=!!(F.hasAuthorKey()&&d&&d.codexTestMode===true);return r;};
 ConfigManager.makeData=function(){var d=makeConfig.apply(this,arguments);d.codexTestMode=!!(F.hasAuthorKey()&&this.codexTestMode===true);return d;};
 F.authenticate=async function(password){var result=await request('/api/test/login',{password:password});if(!result.token||!Number.isFinite(result.expiresAt)||result.expiresAt<=Date.now())throw new Error('验证结果无效。');session={token:result.token,expiresAt:result.expiresAt};return true;};
 function passwordDialog(win){var node=shell('测试模式验证');if(!node)return;node.querySelector('.body').innerHTML='<p>输入作者提供的测试密码。验证通过后本次启动可使用30分钟；密码不会保存在游戏中。</p><label>测试密码</label><input type="password" autocomplete="off" data-field="password"><div class="actions"><button data-action="close">取消</button><button class="primary" data-action="verify">验证并开启</button></div>';
  pinActions(node);node.querySelector('[data-action=close]').onclick=close;var input=node.querySelector('input'),button=node.querySelector('[data-action=verify]');button.onclick=async function(){button.disabled=true;try{var secret=input.value;input.value='';await F.authenticate(secret);secret='';if(host!==node){session=null;return;}close();optionChange.call(win,'codexTestMode',true);win.refresh();win.activate();}catch(e){node.querySelector('output').textContent=e.message;button.disabled=false;}};input.addEventListener('keydown',function(e){if(e.key==='Enter')button.click();});input.focus();}
 Window_Options.prototype.changeValue=function(symbol,value){if(symbol==='codexFeedbackPending')return;if(symbol==='codexTestMode'&&value===true&&!F.testAuthorized())return passwordDialog(this);if(symbol==='codexTestMode'&&!value)session=null;return optionChange.apply(this,arguments);};
 // Expired or revoked sessions immediately stop experience/drop boosts and GM actions.
 var timer=setInterval(async function(){if(session){try{var r=await request('/api/test/session',null,session.token);if(!r.valid)session=null;}catch(e){session=null;}if(!F.testAuthorized()){ConfigManager.codexTestMode=false;}}F.retry().catch(function(){});},60000);
 var titleStart=Scene_Title.prototype.start;Scene_Title.prototype.start=function(){close();clearRecord=null;promptPending=false;return titleStart.apply(this,arguments);};
 var extract=DataManager.extractSaveContents;DataManager.extractSaveContents=function(){close();clearRecord=null;promptPending=false;return extract.apply(this,arguments);};
 return F;
});
