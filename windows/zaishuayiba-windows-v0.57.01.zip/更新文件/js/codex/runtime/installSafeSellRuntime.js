// v0.53.01 用户 2026-10-27：专属法宝按普通装备规则一键出售；专属武器仍保留。
// v0.46：普通法宝不再整类保留，专属（<req_actors>）仍保留；已升级的法宝算已培养（见 S.magicGrown）；比较词条前先统一模板的元素文字（见 baseNote46）。
// v0.45：带其他出售货币的 0 金币装备可以一键出售（见 S.sellable）。
// v0.44：只筛选装备；无词条随机生成标记不再触发整件保留。
// v0.41 九档词条门槛：神话★／神话特效★★／混沌神话★★★分开。
// v0.40 shared affix retention for挂机 and shop bulk sale.
window.CodexRuntime.register('installSafeSellRuntime',function(){
 'use strict';
 var W=window,Q=W.CodexQuality,S=W.CodexSafeSell={version:44};
 function real(i){return W.CodexAbyssMerchant?CodexAbyssMerchant.real(i):i;}
 S.isEquipment=function(item){var i=real(item);return !!i&&!DataManager.isItem(i)&&!DataManager.isSkill(i)&&(DataManager.isWeapon(i)||DataManager.isArmor(i));};
 function cfg(){return $gameParty._XdRsData_hangUp_SellWeapon||($gameParty._XdRsData_hangUp_SellWeapon={});}
 S.tiers41=[{label:'普通及以上',rank:0},{label:'优秀及以上',rank:18},{label:'精良及以上',rank:35},{label:'史诗及以上',rank:52},{label:'传说及以上',rank:69},{label:'不朽及以上',rank:88},{label:'神话★及以上',rank:108},{label:'神话特效★★及以上',rank:110},{label:'混沌神话★★★',rank:111}];
 S.threshold=function(){var n=cfg().keepAffixTier41;if(Number.isInteger(n)&&n>=-1&&n<9)return n;var old=cfg().keepAffixGrade40;return Number.isInteger(old)&&old>=-1&&old<=6?old:5;};
 S.label=function(){var n=S.threshold();return n<0?'关闭':S.tiers41[n].label;};
 S.cycle=function(dir){var n=S.threshold();cfg().keepAffixTier41=((n+1+(dir<0?9:1))%10)-1;return S.label();};
 function template(i){if(!S.isEquipment(i))return null;return (DataManager.isWeapon(i)?$dataWeapons:$dataArmors)[Number(i.originalBaseItemId||i.baseItemId||i.id)];}
 function qualities(note){var a=[],r=/<quality:\s*(\d+)>/gi,m;while((m=r.exec(note||'')))a.push(Number(m[1]));return a;}
 // A generated instance may contain no affix at all. Compare native note lines,
 // not the DXRPSItem marker; only unexplained added content stays conservative.
 // v0.46 独立装备的备注在生成和读档时会被元素文字统一（CodexElements：奥数→奥术、阴阳→虚空、所有属性展开），
 // 模板没有。按原样比较会把这些行当成「来历不明的内容」，整件判为词条待确认而保留（如紫晶拳爪）。比较前先对模板做同样的统一。
 function baseNote46(b){var n=b&&b.note||'',E=W.CodexElements;if(E&&E.normalizeEquipmentText&&E.normalizeNote){try{n=E.normalizeNote(E.normalizeEquipmentText(n));}catch(e){}}return n;}
 function addedNote44(i,b){
  function lines(note){return String(note||'').replace(/<prefix:[^>]*>|<suffix:[^>]*>/gi,'').split(/\r?\n/).map(function(t){return t.trim();}).filter(Boolean);}
  var counts=Object.create(null);lines(baseNote46(b)).forEach(function(t){counts[t]=(counts[t]||0)+1;});return lines(i.note).filter(function(t){if(counts[t]>0){counts[t]--;return false;}return true;}).join('\n');
 }
 S.affixInfo=function(item){var i=real(item),out=[],ranks=[],unknown=false;if(!S.isEquipment(i))return {ranks:[],maxRank:-1,grades:[],max:-1,unknown:false};
  function add(q){q=Number(q);if(!Number.isInteger(q)||q<0||q>15){unknown=true;return;}out.push(Q.grade(q));ranks.push(Q.rank(q));}
  (i._codexSaleAffixes40||[]).forEach(function(d){if(d)add(d.legacy);else unknown=true;});
  if(i._codexExtraAffix29){var d=i._codexExtraAffix29,t=W['$data'+d.db]&&W['$data'+d.db][d.id];if(t)add(Q.legacy(t));else unknown=true;}
  var b=template(i),tags=qualities(i.note),native=qualities(b&&b.note);
  native.forEach(function(q){var p=tags.indexOf(q);if(p>=0)tags.splice(p,1);});tags.forEach(add);
  var extra=addedNote44(i,b),markers=/(混沌神话|神话|太古|mod)特效\s*[:：]/gi,m;
  // Explicit legacy effect headers still identify their tier after a lost quality tag.
  while((m=markers.exec(extra)))add(m[1].toLowerCase()==='混沌神话'?15:m[1]==='神话'?14:m[1]==='太古'?11:13);
  if(!b||!out.length&&extra.trim())unknown=true;
  return {ranks:ranks,maxRank:ranks.length?Math.max.apply(Math,ranks):-1,grades:out,unknown:unknown,max:out.length?Math.max.apply(Math,out):-1};
 };
 // v0.45 售价为 0 但带其他出售货币（不朽碎片／灵魂／结晶、肝帝积分等，<Variable X Sell Price>）的装备，
 // 原版一键出售与挂机出售都会卖并换成这些货币；v0.40 把它们一律当成「不可出售」保留，导致整档卖不掉。
 // 现在只有标了 <Cannot Sell>、或既无金币售价也无其他货币的装备才算不可出售。
 S.sellable=function(item){var i=real(item);if(!i||i.cannotSell)return false;var gold=i.sellPrice!==undefined?Number(i.sellPrice)>0:Number(i.price)>0;
  return gold||['variableSellPrices','itemSellPrices','weaponSellPrices','armorSellPrices'].some(function(k){return (i[k]||[]).length>0;});};
 // v0.46 用户 2026-10-18：专属法宝一律保留，普通法宝按普通装备规则出售；
 // 升过级或有经验的法宝（CP_MagicWeapon 的 level／exp 高于模板初始值）算「已培养」，保留。
 S.magicGrown=function(i,b){return !!b&&/<Magic Weapon>/i.test(b.note||'')&&(Number(i.level)>Number(b.level)||Number(i.exp)>Number(b.exp));};
 S.equipped=function(item){var i=real(item);return ($gameActors._data||[]).some(function(a){return a&&(a._equips||[]).some(function(e){var o=real(e.object());return o===i;});});};
 S.reason=function(item){var i=real(item);if(!S.isEquipment(i))return '非装备';if(!$gameParty.hasItem(i,false))return '未持有';
  if(String(i.name).indexOf('[锁定]')>=0)return '锁定';if(S.equipped(i))return '已装备';
  var b=template(i),note=b&&b.note||'';if(!b)return '装备来源待确认';
  // v0.53.01：专属法宝（带 <Magic Weapon> 的护甲）按普通装备规则出售，仅专属武器继续保留。
  if(/<req_actors\s*:/i.test(note)&&!(DataManager.isArmor(b)&&/<Magic Weapon>/i.test(note)))return '专属';
  if(S.magicGrown(i,b)||i._codexAbsorbed29||i._alien||i._alienBound||i._codexHeartsteelHp>0||i._codexHeartsteelStacks>0||i._codexHubrisFame>0||Number(i.boostCount)>0||Number(i.Level)>0||Number(i._upgradeLevel)>0||(i.augmentSlotItems||[]).some(function(v){return v&&v!=='none';}))return '已培养或镶嵌';
  if(W.CodexAlienation&&CodexAlienation.reserved&&CodexAlienation.reserved(i))return '已被借用';
  if(!S.sellable(i))return '不可出售';
  var threshold=S.threshold(),a=S.affixInfo(i);if(threshold>=0&&(a.unknown||a.maxRank>=S.tiers41[threshold].rank))return a.unknown?'词条待确认':'词条保留';return '';
 };
 S.plan=function(grade){var selected=[],kept=[],qualities=grade===undefined?null:Q.members(grade);$gameParty.equipItems().slice().forEach(function(item){var i=real(item);if(!S.isEquipment(i))return;var raw=Q.legacy(i);if(qualities?qualities.indexOf(raw)<0:XdRsData.hangUp.SellWA.indexOf(raw)<0)return;var reason=S.reason(i);var count=DataManager.isIndependent(i)?1:$gameParty.numItems(i);for(var n=0;n<count;n++){if(reason)kept.push({item:i,reason:reason});else selected.push(i);}});return {sell:selected,keep:kept};};
 if(W.DreamX&&DreamX.RandomPrefixSuffix){var combine=DreamX.RandomPrefixSuffix.combineWithBaseItem;DreamX.RandomPrefixSuffix.combineWithBaseItem=function(affix,item){var out=combine.apply(this,arguments);if(affix&&S.isEquipment(item)){item._codexSaleAffixes40=item._codexSaleAffixes40||[];item._codexSaleAffixes40.push({db:DataManager.isWeapon(affix)?'Weapons':DataManager.isArmor(affix)?'Armors':'Items',id:affix.id,legacy:Q.legacy(affix)});}return out;};}
 // Use the existing transaction for prices, currencies and independent-item deletion; filter immediately before each sale.
 if(W.XdRsData&&XdRsData.hangUp){XdRsData.hangUp.OnekeyWPSell=function(){var p=S.plan();p.sell.forEach(function(i){if(!S.reason(i))XdRsData.hangUp.doSell(1,i);});return p;};}
 if(W.Star_Scene_AutomaticSellWeapon){var autoCreate=Star_Scene_AutomaticSellWeapon.prototype.create;Star_Scene_AutomaticSellWeapon.prototype.create=function(){var r=autoCreate.apply(this,arguments),h=new Window_Help(2);h.setText('词条达到保留品质，整件装备保留；关闭仅取消词条筛选。\n锁定、已装备、已培养或镶嵌（含已升级的法宝）装备始终保留；专属武器保留，专属法宝按普通装备出售。');this.addWindow(h);return r;};}
 if(W.Star_Window_SellWeapon){var P=Star_Window_SellWeapon.prototype,make=P.makeCommandList,status=P.booleanStatusText,ok=P.processOk,ref=P.RefmakeCommandList;
  P.windowWidth=function(){return 680;};P.makeCommandList=function(){make.apply(this,arguments);this.addCommand('保留词条品质','keepAffix40');};
  P.RefmakeCommandList=function(){if(this.currentSymbol()==='keepAffix40')return;return ref.apply(this,arguments);};
  P.booleanStatusText=function(symbol){return symbol==='keepAffix40'?S.label():status.apply(this,arguments);};
  P.statusWidth=function(){return 250;};P.processOk=function(){if(this.currentSymbol()!=='keepAffix40')return ok.apply(this,arguments);S.cycle(1);this.refresh();SoundManager.playOk();};
  var left=P.cursorLeft,right=P.cursorRight;P.cursorLeft=function(){if(this.currentSymbol()==='keepAffix40'){S.cycle(-1);this.refresh();SoundManager.playCursor();}else if(left)left.apply(this,arguments);};P.cursorRight=function(){if(this.currentSymbol()==='keepAffix40'){S.cycle(1);this.refresh();SoundManager.playCursor();}else if(right)right.apply(this,arguments);};
 }
 // Both menus share one saved threshold. Shop bulk sale previews counts and defaults to Cancel.
 if(W.Window_OnekeySellCommand&&W.Scene_Shop){var list=Window_OnekeySellCommand.prototype.makeCommandList,create=Scene_Shop.prototype.createShopOnekeySellWindow;
  Window_OnekeySellCommand.prototype.windowWidth=function(){return 680;};Window_OnekeySellCommand.prototype.makeCommandList=function(){this.addCommand('保留词条：'+S.label(),'keepAffix40');list.apply(this,arguments);this._list.forEach(function(c){if(/^codexGrade\d+$/.test(c.symbol))c.name=c.name.replace(/品质$/,'装备');});};
  function Confirm(){this.initialize.apply(this,arguments);}Confirm.prototype=Object.create(Window_Command.prototype);Confirm.prototype.constructor=Confirm;
  Confirm.prototype.windowWidth=function(){return 720;};Confirm.prototype.numVisibleRows=function(){return 4;};Confirm.prototype.makeCommandList=function(){var p=this._plan40||{sell:[],keep:[]};this.addCommand('待出售装备 '+p.sell.length+' 件；保留装备 '+p.keep.length+' 件','info40',false);this.addCommand('保留词条：'+S.label(),'info40',false);this.addCommand('确认出售','sell40',p.sell.length>0);this.addCommand('取消','cancel');};
  W.Window_SafeSellConfirm40=Confirm;
  Scene_Shop.prototype.createShopOnekeySellWindow=function(){var r=create.apply(this,arguments),scene=this;this._ShopOnekeySellWindow.setHandler('keepAffix40',function(){S.cycle(1);scene._ShopOnekeySellWindow.refresh();scene._ShopOnekeySellWindow.activate();});
   var c=this._safeSellConfirm40=new Confirm(0,0);c.x=(Graphics.boxWidth-c.width)/2;c.y=(Graphics.boxHeight-c.height)/2;c.hide();c.deactivate();this.addWindow(c);
   c.setHandler('cancel',function(){c.hide();c.deactivate();scene._ShopOnekeySellWindow.show();scene._ShopOnekeySellWindow.activate();});
   c.setHandler('sell40',function(){var now=S.plan(c._grade40),was=c._plan40;
    if(now.sell.length!==was.sell.length||now.sell.some(function(i,n){return i!==was.sell[n];})){c._plan40=now;c.refresh();c.select(3);c.activate();return;}
    now.sell.forEach(function(i){if(!S.reason(i)){scene._item=i;scene.doSell(1);}});scene._item=null;c.hide();c.deactivate();scene.OnekeySellDe();scene._goldWindow.refresh();scene._statusWindow.refresh();
   });return r;};
  Scene_Shop.prototype.sellUnifiedQuality=function(grade){var c=this._safeSellConfirm40;c._grade40=grade;c._plan40=S.plan(grade);c.refresh();this._ShopOnekeySellWindow.hide();this._ShopOnekeySellWindow.deactivate();c.show();c.activate();c.select(3);};
 }
 return S;
});
