// 【Claude·未经Codex检验】v0.44 强弱分类统一读角色备注 <KyoTier>（CodexTier），本文件不再写编号名单。
/* New-game weak actor passive and the native Chaos final-battle achievement. */
window.CodexRuntime.register('installWeakChallengeRuntime', function() {
    'use strict';
    if (window.CodexWeakChallenge) return window.CodexWeakChallenge;
    var W = window.CodexWeakChallenge = {version: 2, skillId: 10357, achievementId: 142, iconId: 240201};
    var freshGame = false, classified = null, registered = false, finalBattle = null;

    // 【Claude·未经Codex检验】v0.44 弱者＝角色备注没有 <KyoTier> 的有名字角色，与 Boss 名单、五乘区同一来源。
    W.isWeak = function(actor) {
        if (!actor || !actor.isActor || !actor.isActor()) return false;
        return CodexTier.isWeak(actor);
    };
    function enabled() { return !!(freshGame ? ConfigManager._codexWeakFiveClearV2 : $gameSystem && $gameSystem._codexWeakClearV2 === true); }
    function active(actor) { return enabled() && W.isWeak(actor) && actor.isLearnedSkill(W.skillId); }
    function sync(actor) {
        if (!actor) return false;
        var shouldHave = enabled() && W.isWeak(actor), has = actor.isLearnedSkill(W.skillId);
        if (shouldHave === has) return false;
        if (shouldHave) actor.learnSkill(W.skillId);
        else actor.forgetSkill(W.skillId);
        return true;
    }
    function syncActors() {
        if ($gameActors && $gameActors._data) $gameActors._data.forEach(sync);
    }
    var learn = Game_Actor.prototype.learnSkill;
    Game_Actor.prototype.learnSkill = function(id) {
        if (Number(id) === W.skillId && !(enabled() && W.isWeak(this))) return;
        return learn.apply(this, arguments);
    };
    var actorSetup = Game_Actor.prototype.setup;
    Game_Actor.prototype.setup = function() {
        var result = actorSetup.apply(this, arguments);
        // Only a freshly constructed actor is filled to its new maximum.
        if (sync(this) && enabled()) this.recoverAll();
        return result;
    };
    var newGame = DataManager.setupNewGame;
    DataManager.setupNewGame = function() {
        freshGame = true;
        finalBattle = null;
        try {
            var result = newGame.apply(this, arguments);
            $gameSystem._codexWeakNewGameBuff = 0;
            $gameSystem._codexWeakClearV2 = ConfigManager._codexWeakFiveClearV2 === true;
            syncActors();
            return result;
        } finally { freshGame = false; }
    };
    var extract = DataManager.extractSaveContents;
    DataManager.extractSaveContents = function() {
        var result = extract.apply(this, arguments);
        finalBattle = null;
        $gameSystem._codexWeakNewGameBuff = 0;
        syncActors();
        return result;
    };
    var sparam = Game_Actor.prototype.sparam;
    Game_Actor.prototype.sparam = function(id) {
        var value = sparam.apply(this, arguments);
        // Relative mitigation stacks with native equipment/passive mitigation.
        return (id === 6 || id === 7) && active(this) ? value * 0.5 : value;
    };
    // An independent multiplier keeps the bonus meaningful even with a large
    // existing final-damage pool. Healing follows its own native branch.
    window.CodexDamageHooks.push({id: 'weak-new-game', build: function(action, target, frame) {
        if (active(frame.subject)) frame.finalMultiplier *= 3;
    }});
    var describe = RJO.HE.getItemExtraDescParams2;
    RJO.HE.getItemExtraDescParams2 = function(item) {
        var result = describe.apply(this, arguments);
        if (item.id === W.skillId && /<CodexWeakNewGame>/i.test(item.note || ''))
            item.descParams.forEach(function(row) { if (/^品质[：:]/.test(row[0])) row[0] = '品质：神话'; });
        return result;
    };

    var databaseLoaded = DataManager.isDatabaseLoaded;
    DataManager.isDatabaseLoaded = function() {
        if (!databaseLoaded.apply(this, arguments)) return false;
        if (!registered) {
            var existing = Star.AchievementSystem.Achievement[W.achievementId];
            if (existing && existing.AcName !== '本质高手') throw new Error('弱者挑战：成就编号冲突');
            this.Star_AchievementSystemDatabaseAdd(W.achievementId, {
                AcName: '本质高手', AcType: '光辉事迹', AcIconId: String(W.iconId),
                AcTriggerT: '以五名弱者战胜混沌难度的最终守层者·鸿蒙老祖',
                AcShowText: '以最终战出战阵容判定；阵亡队员计入，替补不计。',
                AcItemReward: '[]', AcWeaponReward: '[]', AcArmorReward: '[]',
                AcEvalReward: '', AcEvalRewardText: ''
            }, null, null, null);
            badge();
            registered = true;
        }
        return true;
    };

    function badge() { return ImageManager.loadBitmap('img/codex_achievements/', 'EssenceMaster', 0, true); }
    var drawIcon = Window_Base.prototype.drawIcon;
    Window_Base.prototype.drawIcon = function(id, x, y, scale) {
        if (Number(id) !== W.iconId) return drawIcon.apply(this, arguments);
        var bitmap = badge(), contents = this.contents, size = Window_Base._iconWidth * (Number(scale) || 1);
        bitmap.addLoadListener(function() { contents.blt(bitmap, 0, 0, bitmap.width, bitmap.height, x, y, size, size); });
    };
    var bookIcon = Window_AchievementBookIndex.prototype.drawIcon;
    Window_AchievementBookIndex.prototype.drawIcon = function(id) {
        return Number(id) === W.iconId ? Window_Base.prototype.drawIcon.apply(this, arguments) : bookIcon.apply(this, arguments);
    };
    function paintName(win, x, y, popup) {
        win.resetFontSettings();
        var bitmap = win.contents, ctx = bitmap._context;
        if (popup) bitmap.fontSize = 20;
        var fontSize = bitmap.fontSize, height = popup ? 20 : win.lineHeight() / 3;
        var baseline = y + height / 2 + fontSize * 0.35;
        var gradient = ctx.createLinearGradient(0, baseline - fontSize, 0, baseline);
        gradient.addColorStop(0, '#fff8db');
        gradient.addColorStop(0.45, '#f7dda0');
        gradient.addColorStop(1, '#c69d55');
        ctx.save();
        ctx.font = bitmap._makeFontNameText(); ctx.textBaseline = 'alphabetic';
        ctx.lineJoin = 'round'; ctx.lineWidth = 3; ctx.strokeStyle = '#2d1749';
        ctx.shadowColor = '#9463d0'; ctx.shadowBlur = 4;
        ctx.strokeText('本质高手', x, baseline);
        ctx.fillStyle = gradient; ctx.fillText('本质高手', x, baseline);
        ctx.restore(); bitmap._setDirty();
        return win.textWidth('本质高手');
    }
    var achievementDraw = Window_AchievementBookIndex.prototype.drawItem;
    Window_AchievementBookIndex.prototype.drawItem = function(index) {
        if (!this._list[index] || this._list[index].id !== W.achievementId) return achievementDraw.apply(this, arguments);
        var owned = Object.prototype.hasOwnProperty.call(this, 'drawTextEx'), previous = this.drawTextEx;
        this.drawTextEx = function(text, x, y) {
            return text === '本质高手' ? paintName(this, x, y, false) : previous.apply(this, arguments);
        };
        try { return achievementDraw.apply(this, arguments); }
        finally { if (owned) this.drawTextEx = previous; else delete this.drawTextEx; }
    };
    var popup = Star.Achievement.Window_AchievementPopup.prototype, popupTitle = popup.drawTitle;
    popup.drawTitle = function() {
        if (Number(this.item.id) === W.achievementId) return paintName(this, 50, 5, true);
        return popupTitle.apply(this, arguments);
    };
    var popupRefresh = popup.refresh;
    popup.refresh = function() {
        var result = popupRefresh.apply(this, arguments);
        if (Number(this.item.id) === W.achievementId) {
            this.contents.fillRect(0, 0, this.contents.width, 1, '#b391d5');
            this.contents.fillRect(0, this.contents.height - 1, this.contents.width, 1, '#c7a261');
        }
        return result;
    };

    // CE714 repairs the original 1–8 switches. Keep explicitly selected native
    // Chaos (ID9), while intentional difficulty commands elsewhere still work.
    var command356 = Game_Interpreter.prototype.command356;
    Game_Interpreter.prototype.command356 = function() {
        var event = $dataCommonEvents && $dataCommonEvents[714];
        if (event && this._list === event.list && $gameSystem.difficultyId() === 9 &&
            /^Difficulty\s+SetID\s+\d+\s*$/i.test(this._params[0])) return true;
        return command356.apply(this, arguments);
    };
    function allWeak() {
        var members = $gameParty.battleMembers();
        return members.length === 5 && members.every(W.isWeak);
    }
    function checkFinalBattle() {
        if (finalBattle && ($gameSystem.difficultyId() !== 9 || !allWeak())) finalBattle.eligible = false;
    }
    var setupBattle = BattleManager.setup;
    BattleManager.setup = function(id) {
        syncActors();
        finalBattle = null;
        var result = setupBattle.apply(this, arguments);
        if ($gameMap.mapId() === 157 && Number(id) === 469 &&
            $gameSystem.difficultyId() === 9) finalBattle = {eligible: allWeak()};
        return result;
    };
    // Record intermediate roster/difficulty changes, including a strong actor
    // who leaves again before victory. Dead battle members remain in the check.
    ['addActor', 'removeActor', 'swapOrder', 'swapOrderBattleMembers', 'rearrangeActors', 'changeBattleMax'].forEach(function(name) {
        var original = Game_Party.prototype[name];
        if (typeof original !== 'function') return;
        Game_Party.prototype[name] = function() {
            var result = original.apply(this, arguments);
            checkFinalBattle();
            return result;
        };
    });
    var setDifficulty = Game_System.prototype.setDifficultyId;
    Game_System.prototype.setDifficultyId = function() {
        var result = setDifficulty.apply(this, arguments);
        checkFinalBattle();
        return result;
    };
    var startAction = BattleManager.startAction;
    BattleManager.startAction = function() {
        checkFinalBattle();
        if (finalBattle && this._subject && this._subject.isActor() && !W.isWeak(this._subject))
            finalBattle.eligible = false;
        return startAction.apply(this, arguments);
    };
    var endBattle = BattleManager.endBattle;
    BattleManager.endBattle = function(result) {
        checkFinalBattle();
        var award = result === 0 && finalBattle && finalBattle.eligible &&
            $gameMap.mapId() === 157 && $gameTroop._troopId === 469 &&
            $gameSystem.difficultyId() === 9 && allWeak() && $gameTroop.isAllDead();
        finalBattle = null;
        var value = endBattle.apply(this, arguments);
        if (award) {
            $gameSystem._codexWeakClearV2 = true;
            ConfigManager._codexWeakFiveClearV2 = true;
            syncActors();
            Star.AchievementSystem.GetAcReward(W.achievementId);
            ConfigManager.save();
        }
        return value;
    };
    var makeConfig = ConfigManager.makeData, applyConfig = ConfigManager.applyData;
    ConfigManager.makeData = function(){var d=makeConfig.apply(this,arguments);d.codexWeakFiveClearV2=this._codexWeakFiveClearV2===true;return d;};
    ConfigManager.applyData = function(d){var out=applyConfig.apply(this,arguments);this._codexWeakFiveClearV2=!!(d&&d.codexWeakFiveClearV2===true);return out;};
    // Saved interpreters can still carry an old dungeon page after a content update.
    var dungeon117=Game_Interpreter.prototype.command117;
    Game_Interpreter.prototype.command117=function(){
        var map=Number(this._mapId),event=Number(this._eventId),bad={48:1,49:6,54:15,85:1};
        if(Number(this._params[0])===1431&&bad[map]===event)return true;
        return dungeon117.apply(this,arguments);
    };
    W.syncActors=syncActors;
    return W;
});
