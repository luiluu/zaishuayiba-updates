// Visual indicators follow the native battle states and the final displayed body frame.
window.CodexRuntime.register('installNativeCharacterVisualRuntime', function() {
    'use strict';
(function(){
    'use strict';
    if(typeof Mx==='undefined'||!Imported.Mx_SuperSV||
       !window.CodexSV||!CodexSV.profiles)return;
    var base='CatSwordSaint_v3',sheet='CatSwordSaint_SV_v3';
    var profiles={"CatSwordSaint_v3":{"kind":"multi","width":192,"height":160,"bounds":[65,72,128,144],"targetHeight":72,"maxWidth":129},"CatSwordSaint_SV_v3":{"kind":"sheet","width":128,"height":128,"bounds":[43,64,85,113],"targetHeight":72,"maxWidth":129}};
    Object.keys(profiles).forEach(function(key){CodexSV.profiles[key]=profiles[key];});
    var cache=new WeakMap(),previousProvider=Mx.SuperSVMetaProvider;
    function own(actor){
        return actor&&actor.isActor&&actor.isActor()&&actor.battlerName&&actor.battlerName()===sheet&&
            !(window.CodexCostumes&&CodexCostumes.active(actor));
    }
    Mx.SuperSVMetaProvider=function(actor,meta){
        if(previousProvider)meta=previousProvider(actor,meta)||meta;
        if(!own(actor)||!meta||typeof meta!=='object'||(meta.sv&&meta.sv!==base))return meta;
        var result=cache.get(meta);
        if(!result){
            result=Object.assign({},meta);
            for(var i=0;i<18;i++){delete result['Cfdz'+i];result['SVzs'+i]=i===1?'1':'3';}
            result.sv=base;result.SVspeed='12';result.YCyy='false';cache.set(meta,result);
        }
        return result;
    };
    function activeProfile(sprite){
        if(!own(sprite._actor)||!sprite._mainSprite||!sprite._mainSprite.bitmap)return null;
        var url=decodeURIComponent(String(sprite._mainSprite.bitmap.url||''));
        if(sprite._mxSVActive&&url.indexOf('/'+base+'/')>=0)return profiles[base];
        if(!sprite._mxSVActive&&url.slice(-(sheet.length+4))===sheet+'.png')return profiles[sheet];
        return null;
    }
    function geometry(sprite){
        var p=activeProfile(sprite);if(!p||!sprite._mainSprite.bitmap.isReady())return;
        var b=p.bounds,s=Math.min(72/(b[3]-b[1]),129/(b[2]-b[0]));
        sprite._mainSprite.bitmap.smooth=false;
        sprite._mainSprite.scale.set(s,s);sprite._mainSprite.anchor.set(0.5,1);
        sprite._mainSprite.position.set((p.width/2-(b[0]+b[2])/2)*s,(p.height-b[3])*s);
        sprite._codexCatProfile=p;sprite._codexLegacyScale=false;
        if(sprite._mxSVActive)sprite._weaponSprite.visible=false;
    }
    var performAttack=Game_Actor.prototype.performAttack;
    Game_Actor.prototype.performAttack=function(){
        var result=performAttack.apply(this,arguments);if(own(this))this.requestMotion('swing');return result;
    };
    var installed=false;
    function install(){
        if(installed)return;installed=true;
        var update=Sprite_Actor.prototype.update;
        Sprite_Actor.prototype.update=function(){
            var result=update.apply(this,arguments);geometry(this);return result;
        };
        var startMotion=Sprite_Actor.prototype.startMotion;
        Sprite_Actor.prototype.startMotion=function(type){
            if(own(this._actor)&&type==='walk'&&!this.isMoving())type='wait';
            return startMotion.call(this,type);
        };
        // Native OTB can leave the walk motion running after a step finishes.
        // Resolve that transition before selecting a bitmap, and hold the planted frame.
        function planted(sprite){
            if(!own(sprite._actor)||sprite.isMoving())return false;
            if(sprite._motion===Sprite_Actor.MOTIONS.walk)sprite.startMotion('wait');
            if(sprite._motion!==Sprite_Actor.MOTIONS.wait)return false;
            sprite._pattern=0;sprite._motionCount=0;return true;
        }
        var frame=Sprite_Actor.prototype.updateFrame;
        Sprite_Actor.prototype.updateFrame=function(){
            planted(this);return frame.apply(this,arguments);
        };
        var count=Sprite_Actor.prototype.updateMotionCount;
        Sprite_Actor.prototype.updateMotionCount=function(){
            if(planted(this))return;
            return count.apply(this,arguments);
        };
        var width=Game_Actor.prototype.spriteWidth,height=Game_Actor.prototype.spriteHeight;
        Game_Actor.prototype.spriteWidth=function(){
            var sprite=this.battler&&this.battler(),p=sprite&&activeProfile(sprite);
            return p?(p.bounds[2]-p.bounds[0])*Math.min(72/(p.bounds[3]-p.bounds[1]),129/(p.bounds[2]-p.bounds[0])):width.apply(this,arguments);
        };
        Game_Actor.prototype.spriteHeight=function(){
            var sprite=this.battler&&this.battler(),p=sprite&&activeProfile(sprite);
            return p?(p.bounds[3]-p.bounds[1])*Math.min(72/(p.bounds[3]-p.bounds[1]),129/(p.bounds[2]-p.bounds[0])):height.apply(this,arguments);
        };
    }
    var boot=Scene_Boot.prototype.start;
    Scene_Boot.prototype.start=function(){
        var result=boot.apply(this,arguments);install();return result;
    };
})();

    var oldApply = Game_Action.prototype.apply;
    Game_Action.prototype.apply = function(target) {
        var out = oldApply.apply(this, arguments), actor = this.subject(), item = this.item();
        if (actor && actor.actorId && actor.actorId() === 171 && item && target &&
                target.result().isHit() && target.startAnimation) {
            if (this._tojiInternal && !this._tojiSpreadRate && item.id >= 10220 && item.id <= 10224)
                target.startAnimation(item.animationId, false, 0);
            else if (item.id === 10216 && !this._tojiInternal && this._tojiIndex > 1)
                target.startAnimation(1, false, Math.min(18, (this._tojiIndex - 1) * 3));
        }
        return out;
    };

    window.CodexBattleIndicators = {version: '1.0.0'};
    function domainCircle(owner) {
        var root = new Sprite(), drawing = new PIXI.Graphics(), red = 0xf32b40;
        root.addChild(drawing);
        root.scale.y = 0.34;
        root._codexDrawing = drawing;
        root._codexTick = 0;
        drawing.beginFill(red, 0.07);
        drawing.drawCircle(0, 0, 88);
        drawing.endFill();
        drawing.lineStyle(7, 0x24030b, 0.8);
        drawing.drawCircle(0, 0, 88);
        drawing.drawCircle(0, 0, 73);
        drawing.lineStyle(2.5, red, 0.95);
        drawing.drawCircle(0, 0, 88);
        drawing.lineStyle(1.5, red, 0.85);
        drawing.drawCircle(0, 0, 73);
        drawing.drawCircle(0, 0, 49);
        for (var triangle = 0; triangle < 2; triangle++) {
            for (var point = 0; point <= 3; point++) {
                var angle = -Math.PI / 2 + triangle * Math.PI + point * Math.PI * 2 / 3;
                var x = Math.cos(angle) * 59, y = Math.sin(angle) * 59;
                if (!point) drawing.moveTo(x, y); else drawing.lineTo(x, y);
            }
        }
        for (var glyph = 0; glyph < 12; glyph++) {
            var a = glyph * Math.PI / 6, cos = Math.cos(a), sin = Math.sin(a);
            drawing.moveTo(cos * 77 - sin * 3, sin * 77 + cos * 3);
            drawing.lineTo(cos * 84 - sin * 3, sin * 84 + cos * 3);
            drawing.lineTo(cos * 84 + sin * 3, sin * 84 - cos * 3);
            drawing.moveTo(cos * 80 - sin * 5, sin * 80 + cos * 5);
            drawing.lineTo(cos * 80 + sin * 5, sin * 80 - cos * 5);
        }
        owner.addChildAt(root, 0);
        owner._codexDomainCircle = root;
        return root;
    }

    function awakeningOutline(owner) {
        var root = new Sprite();
        // Offset silhouettes share the engine bitmap and work with both renderers.
        // The unchanged body covers their interior, leaving only a visible border.
        for (var layer = 0; layer < 2; layer++) for (var i = 0; i < 8; i++) {
            var clone = new Sprite(), angle = i * Math.PI / 4, distance = layer ? 2 : 3.5;
            clone._codexOffsetX = Math.cos(angle) * distance;
            clone._codexOffsetY = Math.sin(angle) * distance;
            clone._codexLayer = layer;
            root.addChild(clone);
        }
        owner.addChildAt(root, owner.getChildIndex(owner._mainSprite));
        owner._codexBlackFlashOutline = root;
        return root;
    }

    // 【Claude·未经Codex检验】v0.21 原来16个描边精灵各自带染色，身体每换一帧都要在画布上重新染色并上传贴图16次，
    // 手机上整个觉醒期间都卡，角色倒下隐藏描边才恢复。改为每个动作帧的两种剪影只生成一次并缓存，
    // 生成时仍走引擎原来的染色流程，所以描边像素与原来一致。
    var OUTLINE_COLORS = [[25, 5, 11, 255], [255, 41, 71, 255]], outlineCache = new WeakMap();
    function silhouette(bitmap, frame, layer) {
        var byFrame = outlineCache.get(bitmap);
        if (!byFrame) { byFrame = {}; outlineCache.set(bitmap, byFrame); }
        var key = frame.x + ',' + frame.y + ',' + frame.width + ',' + frame.height + ',' + layer;
        if (byFrame[key]) return byFrame[key];
        var probe = new Sprite(bitmap);
        probe.setBlendColor(OUTLINE_COLORS[layer]);
        probe.setFrame(frame.x, frame.y, frame.width, frame.height);
        var shape = new Bitmap(frame.width, frame.height);
        shape._context.globalCompositeOperation = 'copy';
        shape._context.drawImage(probe._canvas, 0, 0);
        shape._context.globalCompositeOperation = 'source-over';
        shape.smooth = bitmap.smooth; shape._setDirty();
        if (probe._tintTexture) probe._tintTexture.destroy();
        return (byFrame[key] = shape);
    }

    function syncOutline(root, body) {
        var frame = body._frame;
        root.children.forEach(function(clone) {
            var shape = silhouette(body.bitmap, frame, clone._codexLayer);
            if (clone.bitmap !== shape) { clone.bitmap = shape; clone.setFrame(0, 0, frame.width, frame.height); }
            clone.anchor.x = body.anchor.x; clone.anchor.y = body.anchor.y;
            clone.scale.x = body.scale.x; clone.scale.y = body.scale.y;
            clone.rotation = body.rotation;
            clone.skew.x = body.skew.x; clone.skew.y = body.skew.y;
            clone.x = body.x + clone._codexOffsetX;
            clone.y = body.y + clone._codexOffsetY;
            clone.alpha = body.alpha;
        });
    }

    function updateIndicators(owner) {
        var actor = owner._actor, body = owner._mainSprite;
        var visible = !!(actor && $gameParty && $gameParty.inBattle() && actor.isAlive() &&
            body && body.visible && body.alpha > 0 && body.bitmap && body.bitmap.isReady() &&
            body._frame.width > 0 && body._frame.height > 0);
        // Native status accessors initialize temporary combat data, so only call
        // them when that data already exists. Rendering never starts a mechanic.
        var domain = !!(visible && actor.actorId() === 172 && actor._codexSukuna &&
            window.CodexSukuna && CodexSukuna.activeDomain(actor));
        var awake = !!(visible && actor._codexBlackFlashTemp && window.CodexBlackFlash &&
            CodexBlackFlash.status(actor).awake);
        var circle = owner._codexDomainCircle, outline = owner._codexBlackFlashOutline;
        if (domain) {
            circle = circle || domainCircle(owner);
            var profile = owner._codexSVProfile, frame = body._frame;
            var bounds = profile && profile.width === frame.width && profile.height === frame.height ? profile.bounds : null;
            // Normalized frames compensate for transparent padding. Use their
            // visible feet rather than the bottom edge of the PNG canvas.
            circle.x = body.x + (bounds ? (bounds[0] + bounds[2]) / 2 - frame.width * body.anchor.x : 0) * body.scale.x;
            circle.y = body.y + ((bounds ? bounds[3] : frame.height) - frame.height * body.anchor.y) * body.scale.y;
            circle.alpha = 0.82 + Math.cos(++circle._codexTick * 0.04) * 0.08;
            circle._codexDrawing.rotation += 0.003;
        }
        if (circle) circle.visible = domain;
        if (awake) {
            outline = outline || awakeningOutline(owner);
            syncOutline(outline, body);
        }
        if (outline) outline.visible = awake;
    }

    // Install after all form, costume and multi-frame hooks, so the indicators
    // follow the actual displayed sprite, including Sukuna's full-form offset.
    var run = SceneManager.run, installed = false;
    function installActorHooks() {
        if (!installed) {
            installed = true;
            var update = Sprite_Actor.prototype.update;
            Sprite_Actor.prototype.update = function() {
                var result = update.apply(this, arguments);
                updateIndicators(this);
                return result;
            };
            var setBattler = Sprite_Actor.prototype.setBattler;
            Sprite_Actor.prototype.setBattler = function(actor) {
                if (this._actor !== actor) {
                    if (this._codexDomainCircle) this._codexDomainCircle.visible = false;
                    if (this._codexBlackFlashOutline) this._codexBlackFlashOutline.visible = false;
                }
                return setBattler.apply(this, arguments);
            };
        }
    }
    SceneManager.run = function() {
        var start = Scene_Boot.prototype.start;
        Scene_Boot.prototype.start = function() {
            var result = start.apply(this, arguments);
            // The shared normalization plugin installs its final hooks at boot.
            installActorHooks();
            return result;
        };
        return run.apply(this, arguments);
    };
});
