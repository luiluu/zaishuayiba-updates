// 【Claude·未经Codex检验】v0.44 角色强弱分类只保留一份名单（用户 2026-10-18 决定）。
// 名单就是角色备注里的 <KyoTier:超强者> / <KyoTier:强者>，没有这个标签的有名字角色都是弱者。
// 改一个角色的分类只改 Actors.json 里这一处。Boss 难度名单、弱者挑战、天道注视、五乘区、
// 难度补强（公共事件 1345、1443～1445）、新角色强者技能替换都从这里读，不再各自写编号。
// 须最后安装：数据库读完后把 CodexBossDifficulty 的两份数组按标签原地重建，覆盖其他模块的旧补丁。
window.CodexRuntime.register('installTierTagsV044Runtime', function() {
  'use strict';
  var W = window;
  if (W.CodexTier) return W.CodexTier;
  var TAG = /<KyoTier\s*:\s*(超强者|强者)\s*>/;
  var T = W.CodexTier = { version: 'v0.44', SUPER: '超强者', STRONG: '强者', WEAK: '弱者' };
  var source = null, cache = {};

  function idOf(x) { return typeof x === 'number' || typeof x === 'string' ? Number(x) : x && x.actorId ? x.actorId() : 0; }
  function rebuild() {
    if (!W.$dataActors || source === $dataActors) return;
    source = $dataActors; cache = {};
    $dataActors.forEach(function(a) {
      if (!a || !a.name) return;
      var m = TAG.exec(a.note || '');
      cache[a.id] = m ? m[1] : T.WEAK;
    });
    var D = W.CodexBossDifficulty;
    if (D && Array.isArray(D.superStrongIds) && Array.isArray(D.strongIds)) {
      // 原地替换：其他模块持有的是同一个数组。
      D.superStrongIds.splice.apply(D.superStrongIds, [0, D.superStrongIds.length].concat(T.ids(T.SUPER)));
      D.strongIds.splice.apply(D.strongIds, [0, D.strongIds.length].concat(T.ids(T.STRONG)));
    }
  }
  // 没有名字的空位不算任何一档。
  T.tierOf = function(x) { rebuild(); return cache[idOf(x)] || ''; };
  T.isSuper = function(x) { return T.tierOf(x) === T.SUPER; };
  T.isStrong = function(x) { return T.tierOf(x) === T.STRONG; };
  T.isWeak = function(x) { return T.tierOf(x) === T.WEAK; };
  T.isNonWeak = function(x) { var t = T.tierOf(x); return t === T.SUPER || t === T.STRONG; };
  T.ids = function(tier) {
    rebuild();
    return Object.keys(cache).map(Number).filter(function(id) { return cache[id] === tier; }).sort(function(a, b) { return a - b; });
  };
  // 公共事件 1345、1443～1445 的脚本读这个（原来各写一份编号）。
  T.nonWeakIds = function() { return T.ids(T.SUPER).concat(T.ids(T.STRONG)).sort(function(a, b) { return a - b; }); };

  var loaded = DataManager.isDatabaseLoaded;
  DataManager.isDatabaseLoaded = function() {
    var ok = loaded.apply(this, arguments);
    if (ok) rebuild();
    return ok;
  };
  return T;
});
