/* Install after the native plugins and all main.js character/item runtimes. */
window.CodexRuntime.register('installBulkPillsRuntime', function() {
    'use strict';
    if (window.CodexBulkPills) return window.CodexBulkPills;
    var supportedIds = [], expectedEvents = Object.create(null);
    var expEvents = {1188:100,1189:200,1192:500,1215:5000,1216:50000,1217:1000000};
    for (var id=1685; id<=1700; id++) supportedIds.push(id);
    for (id=1702; id<=1717; id++) supportedIds.push(id);
    supportedIds = supportedIds.concat([1726,1727,1728,1901,1902,1903,1906,1907,1908,1987,1997]);
    for (id=1685; id<=1692; id++) expectedEvents[id]=1226;
    for (id=1693; id<=1700; id++) expectedEvents[id]=1227;
    for (id=1702; id<=1709; id++) expectedEvents[id]=1228;
    for (id=1710; id<=1717; id++) expectedEvents[id]=1229;
    [1901,1902,1903,1906,1907,1908,1987,1997].forEach(function(itemId,i) {
        expectedEvents[itemId]=[1188,1189,1189,1192,1215,1216,1217,1192][i];
    });
    var api = window.CodexBulkPills = {
        version:1, supportedItemIds:supportedIds.slice(), lastResult:null,
        supports:function(item) { return supports(item); }
    };

    function same(a,b) { return JSON.stringify(a)===JSON.stringify(b); }
    function toastScript(command,variableId) {
        if (command.code!==355 || !command.parameters || command.parameters.length!==1) return false;
        var source=String(command.parameters[0]);
        // Only the audited, synchronous toaster statements are accepted as scripts.
        var match=/^\s*\$\.toaster\(\{\s*message\s*:\s*'[^'\\\r\n]*'(?:\+\$gameVariables\.value\((\d+)\))?\s*\}\);?\s*$/.exec(source);
        return !!(match && (match[1] ? Number(match[1])===variableId : true));
    }
    function approvedEvent(eventId) {
        var event=$dataCommonEvents[eventId];
        if (!event || !event.list) return false;
        var list=event.list, exp=expEvents[eventId];
        if (exp) return list.length===3 && list[0].code===356 &&
            same(list[0].parameters,['MagicWeaponAllGainExp '+exp]) &&
            toastScript(list[1],0) && list[2].code===0;
        if (eventId<1226 || eventId>1229) return false;
        var rank=eventId-1226, variableId=968+rank;
        var threshold=[240,200,120,80][rank], reward=1497+rank, unlock=2466+rank;
        var schema=[
            [122,0,[variableId,variableId,1,0,1]], [355,0,null],
            [111,0,[1,variableId,0,threshold,0]], [126,1,[reward,0,0,1]],
            [121,1,[unlock,unlock,0]], [355,1,null], [355,1,null],
            [0,1,[]], [411,0,[]], [0,1,[]], [412,0,[]], [0,0,[]]
        ];
        if (rank===3) {
            schema.pop();
            schema.forEach(function(row) { row[1]++; });
            schema.unshift([111,0,[1,variableId,0,80,4]]);
            schema.push([0,1,[]],[412,0,[]],[0,0,[]]);
        }
        return list.length===schema.length && list.every(function(command,i) {
            var row=schema[i];
            return command.code===row[0] && command.indent===row[1] &&
                (row[2]===null ? toastScript(command,variableId) : same(command.parameters,row[2]));
        });
    }
    function supports(item) {
        if (!item || supportedIds.indexOf(item.id)<0 || !item.consumable ||
                !DataManager.isItem(item) || (DataManager.isIndependent && DataManager.isIndependent(item))) return false;
        var events=(item.effects || []).filter(function(effect) { return effect.code===44; });
        var expected=expectedEvents[item.id];
        return expected ? events.length===1 && events[0].dataId===expected && approvedEvent(expected) : events.length===0;
    }
    function stock(item) {
        var number=Number($gameParty.numItems(item));
        return isFinite(number) ? Math.max(0,Math.floor(number)) : 0;
    }
    function notice(scene,message) {
        if (scene._helpWindow && scene._helpWindow.setText) scene._helpWindow.setText(message);
    }
    function fullyLearned(scene,item) {
        if (!item || item.id<1497 || item.id>1500) return false;
        var effects=(item.effects || []).filter(function(effect) { return effect.code===43; });
        var targets=scene.itemTargetActors();
        return effects.length>0 && targets.length>0 && targets.every(function(target) {
            return target && effects.every(function(effect) {
                return (target._skills && target._skills.indexOf(effect.dataId)>=0) ||
                    (target.isLearnedSkill && target.isLearnedSkill(effect.dataId));
            });
        });
    }

    // Reuse the engine's keyboard/touch quantity controls and window skin. Rendering
    // is local so YEP_ShopMenuCore never asks this item scene for shop currency data.
    function Window_BulkPillNumber() { this.initialize.apply(this,arguments); }
    Window_BulkPillNumber.prototype=Object.create(Window_ShopNumber.prototype);
    Window_BulkPillNumber.prototype.constructor=Window_BulkPillNumber;
    Window_BulkPillNumber.prototype.initialize=function() {
        Window_ShopNumber.prototype.initialize.apply(this,arguments);
        this.opacity=255;this.backOpacity=255;
    };
    Window_BulkPillNumber.prototype.update=function() {
        Window_ShopNumber.prototype.update.apply(this,arguments);
        // Native global window-opacity settings must not fade this modal dialog.
        this.opacity=255;this.backOpacity=255;
    };
    // 【Codex·未经Claude检验】v0.10 Keep the quantity dialog readable over the item scene.
    Window_BulkPillNumber.prototype.standardBackOpacity=function() { return 255; };
    Window_BulkPillNumber.prototype._refreshBack=function() {
        Window.prototype._refreshBack.call(this);
        var bitmap=this._windowBackSprite.bitmap;
        if (!bitmap || !bitmap.width || !bitmap.height) return;
        // Fill the transparent pixels in the native skin while keeping its texture.
        var ctx=bitmap._context;
        ctx.save();ctx.globalCompositeOperation='destination-over';ctx.globalAlpha=1;
        ctx.fillStyle='#111827';ctx.fillRect(0,0,bitmap.width,bitmap.height);ctx.restore();
        bitmap._setDirty();
    };
    Window_BulkPillNumber.prototype.windowWidth=function() { return Math.min(456,Graphics.boxWidth); };
    Window_BulkPillNumber.prototype.itemY=function() { return this.lineHeight()*2; };
    Window_BulkPillNumber.prototype.buttonY=function() { return this.lineHeight()*5+12; };
    Window_BulkPillNumber.prototype.maxDigits=function() { return String(this._max || 1).length; };
    Window_BulkPillNumber.prototype.cursorWidth=function() {
        return this.textWidth(String(this._max || 1))+this.textPadding()*2;
    };
    Window_BulkPillNumber.prototype.refresh=function() {
        this.contents.clear();
        this._index=0;
        this.resetFontSettings();
        var width=this.contentsWidth();
        this.changeTextColor(this.systemColor());
        this.drawText('服用数量',0,0,width,'center');
        this.resetTextColor();
        this.drawItemName(this._item,0,this.lineHeight(),width);
        this.drawMultiplicationSign();
        this.drawNumber();
        this.drawText('持有：'+(this._max || 0)+' 颗',0,this.lineHeight()*3,width,'right');
        this.drawText('← / → ±1    ↑ / ↓ ±10',0,this.lineHeight()*4,width,'center');
        this.updateCursor();
    };
    function quantityWindow(scene) {
        if (!scene._codexBulkNumberWindow) {
            var height=Math.min(Graphics.boxHeight,Window_Base.prototype.fittingHeight.call(scene._itemWindow,8));
            var win=new Window_BulkPillNumber(0,0,height);
            win.x=Math.floor((Graphics.boxWidth-win.width)/2);
            win.y=Math.floor((Graphics.boxHeight-win.height)/2);
            win.setHandler('ok',scene.onCodexBulkNumberOk.bind(scene));
            win.setHandler('cancel',scene.onCodexBulkNumberCancel.bind(scene));
            win.hide();
            win.deactivate();
            scene.addWindow(win);
            scene._codexBulkNumberWindow=win;
        }
        return scene._codexBulkNumberWindow;
    }
    function deactivateSelection(scene) {
        [scene._itemWindow,scene._actorWindow,scene._itemActionWindow].forEach(function(win) {
            if (win && win.deactivate) win.deactivate();
        });
    }
    function closeQuantity(scene) {
        var win=scene._codexBulkNumberWindow;
        if (win) { win.hide(); win.deactivate(); }
    }
    function restoreSelection(scene,context) {
        if (scene._actorWindow) scene._actorWindow.refresh();
        if (stock(context.item)>0 && context.forFriend) {
            if (scene._actorWindow) { scene._actorWindow.show(); scene._actorWindow.activate(); }
        } else {
            if (scene._actorWindow) { scene._actorWindow.hide(); scene._actorWindow.deactivate(); }
            scene.activateItemWindow();
            if (scene._itemWindow && scene._itemWindow.maxItems) {
                scene._itemWindow.select(Math.min(context.itemIndex,scene._itemWindow.maxItems()-1));
            }
        }
        if (scene._itemWindow && scene._itemWindow.redrawCurrentItem) scene._itemWindow.redrawCurrentItem();
        if (scene._statusWindow && scene._statusWindow.refresh) scene._statusWindow.refresh();
        if (scene._infoWindow && scene._infoWindow.refresh) scene._infoWindow.refresh();
    }

    // Capture reservations only during one pill's native action. Known events are
    // completed before another pill may reserve the engine's single event slot.
    // Unexpected reservations retain FIFO order for the ordinary map interpreter.
    function deferNativeEvents(events) {
        var temp=$gameTemp, queue=temp._codexBulkDeferredCommonEvents || [];
        events.forEach(function(eventId) {
            if (!temp.isCommonEventReserved()) temp.reserveCommonEvent(eventId);
            else queue.push(eventId);
        });
        temp._codexBulkDeferredCommonEvents=queue;
    }
    var oldReserved=Game_Interpreter.prototype.setupReservedCommonEvent;
    Game_Interpreter.prototype.setupReservedCommonEvent=function() {
        var result=oldReserved.apply(this,arguments);
        var queue=$gameTemp._codexBulkDeferredCommonEvents;
        if (result && queue && queue.length && !$gameTemp.isCommonEventReserved())
            $gameTemp.reserveCommonEvent(queue.shift());
        return result;
    };
    function finish(scene,reason) {
        var job=scene._codexBulkJob;
        scene._codexBulkJob=null;
        scene._codexBulkContext=null;
        closeQuantity(scene);
        api.lastResult={itemId:job.item.id,requested:job.requested,used:job.used,remaining:stock(job.item),reason:reason || 'complete'};
        restoreSelection(scene,job);
        notice(scene,'已服用 '+job.item.name+' × '+job.used+'；剩余 '+stock(job.item)+' 颗'+(reason && reason!=='complete' ? '（'+reason+'）' : ''));
        if ($gameTemp.isCommonEventReserved()) scene.checkCommonEvent();
        scene.checkGameover();
    }
    function finishInlineEvents(scene,job) {
        while (job.events.length || job.interpreter) {
            if (!job.interpreter) {
                var eventId=job.events.shift();
                if (!approvedEvent(eventId)) {
                    deferNativeEvents([eventId].concat(job.events));
                    job.events=[];
                    finish(scene,'后续事件交由地图执行');
                    return false;
                }
                job.interpreter=new Game_Interpreter();
                job.interpreter.setup($dataCommonEvents[eventId].list,0);
            }
            job.interpreter.update();
            if (job.interpreter.isRunning()) return false;
            job.interpreter=null;
        }
        return true;
    }
    function processBatch(scene) {
        var job=scene._codexBulkJob;
        if (!job || SceneManager.isSceneChanging()) return;
        if (!finishInlineEvents(scene,job)) return;
        // A frame budget keeps large legitimate inventory counts responsive.
        var started=Date.now();
        for (var count=0;count<20 && Date.now()-started<8;count++) {
            if (job.used>=job.requested) return finish(scene,'complete');
            if ($gameTemp.isCommonEventReserved()) return finish(scene,'等待已有事件');
            if (!supports(job.item) || stock(job.item)<1) return finish(scene,'库存不足或道具已改变');
            var user=scene.user();
            if (!user) return finish(scene,'当前没有可用角色');
            var action=new Game_Action(user);
            action.setItemObject(job.item);
            if (!user.canUse(job.item) || (job.forFriend && !job.targets.some(function(target) { return target && action.testApply(target); })))
                return finish(scene,'当前目标无法继续服用');
            var temp=$gameTemp, reserve=temp.reserveCommonEvent;
            var hadOwn=Object.prototype.hasOwnProperty.call(temp,'reserveCommonEvent');
            job.events=[];
            temp.reserveCommonEvent=function(eventId) { if (eventId>0) job.events.push(eventId); };
            try {
                user.useItem(job.item);
                job.targets.forEach(function(target) {
                    for (var repeat=0;repeat<action.numRepeats();repeat++) action.apply(target);
                });
                action.applyGlobal();
                job.used++;
            } finally {
                if (hadOwn) temp.reserveCommonEvent=reserve;
                else delete temp.reserveCommonEvent;
            }
            if (!finishInlineEvents(scene,job)) return;
            if (SceneManager.isSceneChanging()) return;
        }
        if (job.used>=job.requested) return finish(scene,'complete');
        notice(scene,'正在服用 '+job.item.name+'：'+job.used+' / '+job.requested);
    }

    var oldUse=Scene_Item.prototype.useItem;
    Scene_Item.prototype.useItem=function() {
        var item=this.item();
        if (fullyLearned(this,item)) {
            SoundManager.playBuzzer();
            notice(this,'目标已学会 '+item.name+' 的效果');
            return;
        }
        if (!supports(item)) return oldUse.apply(this,arguments);
        if (this._codexBulkContext || this._codexBulkJob) return;
        var available=stock(item);
        if (available<1 || $gameTemp.isCommonEventReserved()) {
            SoundManager.playBuzzer();
            notice(this,available<1 ? '丹药库存不足' : '请先完成当前道具事件');
            return;
        }
        var action=new Game_Action(this.user());
        action.setItemObject(item);
        this._codexBulkContext={item:item,available:available,forFriend:action.isForFriend(),
            targets:this.itemTargetActors().slice(),itemIndex:this._itemWindow.index()};
        deactivateSelection(this);
        var win=quantityWindow(this);
        win.setup(item,available,0);
        win.show();
        win.activate();
    };
    var oldActivate=Scene_Item.prototype.activateItemWindow;
    Scene_Item.prototype.activateItemWindow=function() {
        if (this._codexBulkContext || this._codexBulkJob) return;
        return oldActivate.apply(this,arguments);
    };
    Scene_Item.prototype.onCodexBulkNumberCancel=function() {
        var context=this._codexBulkContext;
        if (!context || this._codexBulkJob) return;
        this._codexBulkContext=null;
        closeQuantity(this);
        restoreSelection(this,context);
    };
    Scene_Item.prototype.onCodexBulkNumberOk=function() {
        var context=this._codexBulkContext;
        if (!context || this._codexBulkJob) return;
        var selected=Number(this._codexBulkNumberWindow.number());
        var requested=Math.min(Math.max(0,Math.floor(selected)),context.available,stock(context.item));
        if (!isFinite(requested) || requested<1) return this.onCodexBulkNumberCancel();
        context.requested=requested;
        context.used=0;
        context.events=[];
        context.interpreter=null;
        this._codexBulkJob=context;
        closeQuantity(this);
        this.playSeForItem();
        processBatch(this);
    };
    var oldUpdate=Scene_Item.prototype.update;
    Scene_Item.prototype.update=function() {
        oldUpdate.apply(this,arguments);
        processBatch(this);
    };
    return api;
});
