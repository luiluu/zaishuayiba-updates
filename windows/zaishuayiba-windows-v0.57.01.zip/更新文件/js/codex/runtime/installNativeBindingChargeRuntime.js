// 【Codex·未经Claude检验】v0.23 玩家反馈与平衡修复；未经claude检验。
// 本轮维护源：three-growth-install-20261009-114400；禁止用旧安装器覆盖。
// 形态绑定与行动充能（璇的附身、屠苏的武具共用）。
// - 开战按编队顺序自动绑定；绑定期间本体不可被敌方命中（目标选择与效果应用两层），友方支援照常。
// - 自然回合开始把本体当回合的行动次数转为充能（被控为 0）；充能由角色模块的自动支援花费，回合末交给角色模块释放，不跨回合。
// - 本体在 OTB 序列里保留位置，只作指令时点：形态状态用 <Replace Attack> 换「攻击」，原生「防御」作待命。
// - 宿主阵亡／离场（宿主是人形本体时，它离开人形也算离场）、本体阵亡／离场时解除；解除当回合本体按充能行动，0 充能只能防御；下一回合起按普通角色行动。
// - 战斗结束、逃跑、读档时清理。角色模块用 CodexBinding.register 登记自己的规则。
window.CodexRuntime.register("installNativeBindingChargeRuntime", function() {
  'use strict';
  var B = window.CodexBinding = {version: '1.0.0', kinds: {}};
  function alias(o, k, f) { var prev = o[k]; o[k] = function() { return f.call(this, prev, arguments); }; }
  function num(v) { v = Number(v); return isFinite(v) ? v : 0; }
  function round() { return Math.max(1, ($gameTroop && $gameTroop.turnCount()) || 1); }
  function inBattle() { return !!($gameParty && $gameParty.inBattle()); }
  function members() { return inBattle() ? $gameParty.battleMembers() : []; }
  function live(b) { return !!b && b.isAlive(); /* 【Codex·未经Claude检验】v0.48：零血未死亡仍为存活。 */ }
  function data(a) { return a && a._codexBind; }
  var acting = null, opening = false;
  B.data = data;
  B.round = round;
  B.register = function(kind, spec) { spec.kind = kind; B.kinds[kind] = spec; return spec; };
  function kindOf(a) {
    if (!a || !a.isActor || !a.isActor()) return null;
    for (var k in B.kinds) if (B.kinds[k].isOwner(a)) return B.kinds[k];
    return null;
  }
  B.kindOf = kindOf;
  B.isOwner = function(a) { return !!kindOf(a); };
  B.host = function(a) { var d = data(a); return d && d.hostId ? $gameActors.actor(d.hostId) : null; };
  B.isBound = function(a) { var d = data(a); return !!(d && d.hostId); };
  B.charges = function(a) { var d = data(a); return d ? d.charges : 0; };
  B.ownersOf = function(host) { return members().filter(function(a) { return B.host(a) === host; }); };
  // 敌方不可命中：只看「形态中的本体」。
  B.untargetable = function(b) { return !!(b && b.isActor && b.isActor() && inBattle() && B.isBound(b)); };
  function syncStates(a) {
    var k = kindOf(a), d = data(a); if (!k || !d) return;
    var bound = !!d.hostId, manual = k.manual && k.manual(a), empty = !manual && !bound && d.returnedRound === round() && d.charges <= 0;
    if (bound && !a.isStateAffected(k.formState)) a.addState(k.formState);
    if (!bound && a.isStateAffected(k.formState)) a.removeState(k.formState);
    if (k.emptyState) {
      if (empty && !a.isStateAffected(k.emptyState)) a.addState(k.emptyState);
      if (!empty && a.isStateAffected(k.emptyState)) a.removeState(k.emptyState);
    }
    if (k.chargeCounter) k.chargeCounter(a, d.charges);
    a.refresh();
  }
  B.sync = syncStates;
  B.canHost = function(owner, target) {
    var k = kindOf(owner);
    if (!k || !target || target === owner || !live(target) || members().indexOf(target) < 0) return false;
    // 璇与屠苏只在人形时可以互相绑定（v0.6）：已在形态中的本体不能作宿主／持武者；开战默认绑定不选本体。
    if (B.isOwner(target) && (B.isBound(target) || opening)) return false;
    return k.canHost ? k.canHost(owner, target) : true;
  };
  B.bind = function(owner, target, reason) {
    var k = kindOf(owner); if (!k || !B.canHost(owner, target) || !live(owner)) return false;
    var d = owner._codexBind = owner._codexBind || {charges: 0};
    var previous = B.host(owner);
    if (previous === target) return true;
    if (previous && k.onUnbind) k.onUnbind(owner, previous, 'transfer');
    d.hostId = target.actorId(); d.boundRound = round(); delete d.returnedRound;
    syncStates(owner);
    if (k.onBind) k.onBind(owner, target, reason || 'bind', previous);
    return true;
  };
  B.unbind = function(owner, reason) {
    var k = kindOf(owner), d = data(owner); if (!k || !d || !d.hostId) return false;
    var host = $gameActors.actor(d.hostId);
    d.hostId = 0;
    if (reason === 'leave-owner' || reason === 'death-owner') d.charges = 0;
    else if (!(k.manual && k.manual(owner))) d.returnedRound = round();
    if (k.onUnbind) k.onUnbind(owner, host, reason);
    syncStates(owner);
    return true;
  };
  B.spend = function(owner, n) {
    var d = data(owner); n = Math.max(1, Math.floor(num(n) || 1));
    if (!d || d.charges < n) return false;
    d.charges -= n; syncStates(owner); return true;
  };
  B.gain = function(owner, n) { var d = data(owner); if (!d) return; d.charges += Math.max(0, Math.floor(num(n))); syncStates(owner); };
  // 内部施放（先例：谷雨绽放）：照常检查并支付 MP／TP／冷却，不插入行动序列。返回实际作用的目标列表；失败返回 null。
  B.cast = function(owner, skillId, targets, options) {
    options = options || {};
    var skill = $dataSkills[skillId];
    if (!skill || !live(owner)) return null;
    if (!options.free) {
      if (owner.cooldown && owner.cooldown(skillId) > 0) return null;
      if (!owner.canPaySkillCost(skill)) return null;
    }
    targets = (targets || []).filter(function(t) { return t && (skill.scope === 9 || skill.scope === 10 ? t.isDead() : t.isAlive()); });
    if (!targets.length) return null;
    var action = new Game_Action(owner);
    action.setSkill(skillId);
    action._codexInternal = options.tag || 'binding';
    if (options.setup) options.setup(action);
    if (!options.free) owner.paySkillCost(skill);
    var log = BattleManager._logWindow, previous = BattleManager._action;
    try {
      BattleManager._action = action;
      targets.forEach(function(t) {
        if (options.animation !== false && skill.animationId > 0 && t.startAnimation) t.startAnimation(skill.animationId, owner.isActor() ? false : true, 0);
        action.apply(t);
        if (t.startDamagePopup) t.startDamagePopup();
        if (log && log.displayActionResults) log.displayActionResults(owner, t);
      });
    } finally { BattleManager._action = previous; }
    if (options.text && log && log.push) log.push('addText', options.text);
    if (B.onCast) try { B.onCast(owner, skill, targets, action); } catch (e) { console.error(e); }
    return targets;
  };
  // ---- 开战默认绑定：编队中排在本体之后的第一名合法队友，到末尾从队首找 ----
  B.defaultHost = function(owner) {
    var list = members(), i = list.indexOf(owner);
    if (i < 0) return null;
    for (var n = 1; n < list.length; n++) { var t = list[(i + n) % list.length]; if (B.canHost(owner, t)) return t; }
    return null;
  };
  // 【Claude·未经Codex检验】v0.44 超强者名单统一由角色备注 <KyoTier> 决定（CodexTier），这里不再追加。
  B.syncSuperStrong = function() {};
  alias(BattleManager, 'setup', function(old, args) { B.syncSuperStrong(); return old.apply(this, args); });
  alias(DataManager, 'extractSaveContents', function(old, args) { var out = old.apply(this, args); B.syncSuperStrong(); return out; });
  if (window.CodexBossDifficulty && CodexBossDifficulty.showRoster) alias(CodexBossDifficulty, 'showRoster', function(old, args) { B.syncSuperStrong(); return old.apply(this, args); });
  alias(BattleManager, 'startBattle', function(old, args) {
    var out = old.apply(this, args);
    opening = true;
    try {
      members().forEach(function(a) {
        var k = kindOf(a); if (!k) return;
        a._codexBind = {charges: 0};
        if (k.formState && a.isStateAffected(k.formState)) a.removeState(k.formState);
        var host = live(a) ? (k.defaultHost ? k.defaultHost(a) : B.defaultHost(a)) : null;
        // 本体开战；玩家输入或自动战斗再决定附身／化武。
      });
    } finally { opening = false; }
    return out;
  });
  // ---- 自然回合开始：行动次数转为充能；上回合回归的本体恢复普通 ----
  var startedRound = null;
  alias(BattleManager, 'startTurn', function(old, args) {
    var out = old.apply(this, args), r = round();
    if (startedRound !== r) {
      startedRound = r;
      members().forEach(function(a) {
        var k = kindOf(a), d = data(a); if (!k || !d) return;
        if (d.returnedRound && d.returnedRound < r) { delete d.returnedRound; d.charges = 0; }
        if (d.hostId) {
          var n = a.canMove() ? Math.max(1, a._actions ? a._actions.length : 1) : 0;
          d.charges = k.manual && k.manual(a) ? 0 : n;
          if (k.onRoundStart) k.onRoundStart(a, n);
        }
        syncStates(a);
      });
    }
    return out;
  });
  // ---- 回合末：交给角色模块释放剩余充能，然后清零 ----
  var endedRound = null;
  alias(BattleManager, 'endTurn', function(old, args) {
    var out = old.apply(this, args), r = round();
    if (this._enteredEndPhase && endedRound !== r) {
      endedRound = r;
      members().forEach(function(a) {
        var k = kindOf(a), d = data(a); if (!k || !d) return;
        if (d.charges > 0 && live(a) && d.hostId && k.onRoundEnd) { try { k.onRoundEnd(a); } catch (e) { console.error(e); } }
        if (k.onRoundClose) { try { k.onRoundClose(a); } catch (e) { console.error(e); } } // 每回合必定结算（默契、到期等）
        d.charges = 0; syncStates(a);
      });
    }
    return out;
  });
  // ---- 离场、阵亡：在行动结束时统一检查，不改变当前来源事件的目标集合 ----
  B.validate = function() {
    if (!inBattle()) return;
    var list = members();
    $gameParty.allMembers().forEach(function(a) {
      var k = kindOf(a), d = data(a); if (!k || !d) return;
      if (list.indexOf(a) < 0) { if (d.hostId) B.unbind(a, 'leave-owner'); d.charges = 0; syncStates(a); return; }
      if (!d.hostId) return;
      if (!live(a)) { B.unbind(a, 'death-owner'); return; }
      var host = B.host(a);
      if (!host || list.indexOf(host) < 0 || (B.isOwner(host) && B.isBound(host))) B.unbind(a, 'leave-host'); // 宿主本体离开人形按离场处理
      else if (!live(host)) B.unbind(a, 'death-host');
    });
  };
  alias(BattleManager, 'endAction', function(old, args) { var out; try { out = old.apply(this, args); } finally { acting = null; } B.validate(); return out; });
  alias(BattleManager, 'startAction', function(old, args) {
    B.validate();
    var subject = this._subject, d = data(subject);
    acting = subject || null;
    // 回归后本回合的时点：每次行动扣 1 点充能（0 时由充能耗尽状态只留防御）。
    if (d && !d.hostId && d.returnedRound === round() && d.charges > 0) { d.charges--; syncStates(subject); }
    return old.apply(this, args);
  });
  // ---- 敌方不可命中：目标选择与效果应用两层 ----
  // 敌方行动期间（startAction～endAction）才算敌方效果；回合末等阶段不受影响。
  function enemyActing() { return !!(acting && acting.isEnemy && acting.isEnemy()); }
  alias(Game_Action.prototype, 'makeTargets', function(old, args) {
    var out = old.apply(this, args), subject = this.subject();
    if (!subject || !subject.isEnemy || !subject.isEnemy() || !this.isForOpponent()) return out;
    var kept = out.filter(function(t) { return !B.untargetable(t); });
    if (kept.length === out.length) return out;
    if (!kept.length && out.length) {
      var pool = $gameParty.aliveMembers().filter(function(t) { return !B.untargetable(t); });
      if (pool.length && !this.isForAll()) for (var i = 0; i < out.length; i++) kept.push(pool[Math.floor(Math.random() * pool.length)]);
    }
    return kept;
  });
  ['randomTarget', 'smoothTarget'].forEach(function(name) {
    alias(Game_Party.prototype, name, function(old, args) {
      var t = old.apply(this, args);
      if (!enemyActing() || !B.untargetable(t)) return t;
      var pool = this.aliveMembers().filter(function(x) { return !B.untargetable(x); });
      return pool.length ? pool[Math.floor(Math.random() * pool.length)] : t;
    });
  });
  alias(Game_Action.prototype, 'apply', function(old, args) {
    var t = args[0], s = this.subject();
    if (s && s.isEnemy && s.isEnemy() && B.untargetable(t)) { t.clearResult(); t.result().used = false; return; }
    return old.apply(this, args);
  });
  // 璇附身期间也隔离回合持续伤害和直接扣血；屠苏仍沿用原规则。
  B.blocksHpLoss=function(a){var k=kindOf(a);return !!(k && k.kind==='xuan' && B.untargetable(a));};
  ['gainHp','setHp'].forEach(function(name){
    alias(Game_Actor.prototype,name,function(old,args){
      if(B.blocksHpLoss(this) && (name==='gainHp'?num(args[0])<0:Number(args[0])<this._hp))return;
      return old.apply(this,args);
    });
  });
  // 脚本直接扣血、加状态：敌方行动期间整份排除。
  alias(Game_Battler.prototype, 'gainHp', function(old, args) {
    if (num(args[0]) < 0 && enemyActing() && B.untargetable(this)) return;
    return old.apply(this, args);
  });
  alias(Game_Battler.prototype, 'addState', function(old, args) {
    if (enemyActing() && B.untargetable(this) && !(B.kindOf(this) && B.kindOf(this).formState === args[0])) return;
    return old.apply(this, args);
  });
  // ---- 指令窗：「攻击」位置显示替换后的技能名（先例：甚尔） ----
  alias(Window_ActorCommand.prototype, 'addAttackCommand', function(old, args) {
    var a = this._actor;
    if (a && B.isBound(a)) { var s = $dataSkills[a.attackSkillId()]; if (s) { this.addCommand(s.name, 'attack', a.canAttack()); return; } }
    return old.apply(this, args);
  });
  // 【Codex·未经Claude检验】v0.48：手动目标光标跳过附身／化武本体；群体效果结算沿用原规则。
  B.canSelectBattleActor = function(target) {
    if (!target || B.untargetable(target)) return false;
    var action = BattleManager.inputtingAction(), owner = action && action.subject(), item = action && action.item();
    if (action && action.isForUser() && target !== owner) return false;
    var X = window.CodexXuan, key = X && item && X.ids().key[item.id];
    if (X && X.isXuan(owner) && (key === 'jixing' || key === 'jixing.possess')) return B.canHost(owner, target) && target !== B.host(owner);
    var T = window.CodexTusu, tusuKey = T && item && T.ids().key[item.id];
    if (T && T.isTusu(owner) && tusuKey && tusuKey.indexOf('huawu.') === 0) return B.canHost(owner, target);
    return true;
  };
  alias(Window_BattleActor.prototype, 'select', function(old, args) {
    var index = Number(args[0]), list = $gameParty.battleMembers(), count = list.length;
    if (index >= 0 && !B.canSelectBattleActor(list[index])) {
      // 点击／悬停非法角色不跳到别的队友，也不确认旧光标。
      if (this._codexBindingPointer) return;
      var step = this._codexBindingCursorStep || 1, found = -1;
      for (var n = 1; n <= count; n++) {
        var next = (index + step * n + count * (n + 1)) % count;
        if (B.canSelectBattleActor(list[next])) { found = next; break; }
      }
      args[0] = found;
    }
    return old.apply(this, args);
  });
  ['cursorDown','cursorRight','cursorPagedown','cursorUp','cursorLeft','cursorPageup'].forEach(function(name) {
    alias(Window_BattleActor.prototype, name, function(old, args) {
      this._codexBindingCursorStep = /Up$|Left$|Pageup$/i.test(name) ? -1 : 1;
      try { return old.apply(this, args); } finally { delete this._codexBindingCursorStep; }
    });
  });
  alias(Window_BattleActor.prototype, 'processTouch', function(old, args) {
    this._codexBindingPointer = true;
    try { return old.apply(this, args); } finally { delete this._codexBindingPointer; }
  });
  ['isClickedActor','isMouseOverActor'].forEach(function(name) {
    if (typeof Window_BattleActor.prototype[name] === 'function') alias(Window_BattleActor.prototype, name, function(old, args) {
      return B.canSelectBattleActor(args[0]) && old.apply(this, args);
    });
  });
  ['isCurrentItemEnabled','isOkEnabled'].forEach(function(name) {
    alias(Window_BattleActor.prototype, name, function(old, args) {
      return B.canSelectBattleActor(this.actor()) && old.apply(this, args);
    });
  });
  // ---- 战斗外管理页（器谱、星谱）：独立菜单场景，选项窗沿用云裳天衣铺的原生选择窗 ----
  function Scene_CodexBindMenu() { this.initialize.apply(this, arguments); }
  Scene_CodexBindMenu.prototype = Object.create(Scene_MenuBase.prototype);
  Scene_CodexBindMenu.prototype.constructor = Scene_CodexBindMenu;
  Scene_CodexBindMenu.prototype.create = function() {
    Scene_MenuBase.prototype.create.call(this);
    var build = B._menuBuilder; B._menuBuilder = null;
    try { if (build) build(this); else this.popScene(); } catch (e) { console.error(e); this.popScene(); }
  };
  window.Scene_CodexBindMenu = Scene_CodexBindMenu;
  B.openMenu = function(builder) {
    if (!window.CodexYunshang || !CodexYunshang.choose) { if (window.$ && $.toaster) $.toaster({message: '缺少原生选择窗，无法打开'}); return false; }
    B._menuBuilder = builder; SceneManager.push(Scene_CodexBindMenu); return true;
  };
  // ---- 清理 ----
  function clearActor(a) {
    var k = kindOf(a); if (!a) return;
    delete a._codexBind;
    if (k) { [k.formState, k.emptyState].forEach(function(id) { if (id && a._states && a._states.indexOf(id) >= 0) a.eraseState(id); }); if (k.onClear) k.onClear(a); }
  }
  B.clearAll = function() {
    startedRound = null; endedRound = null; acting = null; opening = false;
    if ($gameActors && $gameActors._data) $gameActors._data.forEach(function(a) { if (a && (a._codexBind || kindOf(a))) clearActor(a); });
  };
  alias(BattleManager, 'endBattle', function(old, args) { try { return old.apply(this, args); } finally { B.clearAll(); } });
  alias(DataManager, 'extractSaveContents', function(old, args) { var out = old.apply(this, args); B.clearAll(); return out; });
  // ---- 伙伴号角上架（2026-10-08 美术接入）：同谷雨做法，在 Map132 出售伙伴号角的商店追加 <CodexTusu: horn>／<CodexXuan: horn> ----
  if (typeof Scene_Shop !== 'undefined') alias(Scene_Shop.prototype, 'prepare', function(old, args) {
    var goods = (args[0] || []).slice();
    if ($gameMap && $gameMap.mapId() === 132 && goods.some(function(g) { return g[0] === 0 && $dataItems[g[1]] && /^伙伴号角：/.test($dataItems[g[1]].name); })) {
      ($dataItems || []).forEach(function(i) {
        if (i && /<Codex(?:Tusu|Xuan):\s*horn\s*>/i.test(i.note || '') && !goods.some(function(g) { return g[0] === 0 && g[1] === i.id; })) goods.push([0, i.id, 0, 0]);
      });
    }
    return old.call(this, goods, args[1]);
  });
// 等级成长使用已有的元素、技能增伤和终伤乘区；不改攻防比例。
var nativeMpCost = Game_Actor.prototype.skillMpCost;
B.percentMpCost = function(a, skill, rate) {
  if (!a || !skill) return 0;
  var copy = Object.assign({}, skill, {mpCost: 0, mpCostPer: rate});
  return nativeMpCost.call(a, copy);
};
B.curve = function(a, values, levels) {
  levels = levels || [1,20,40,60];var lv=Math.max(1,Number(a&&a.level)||1);
  if(lv<=levels[0])return values[0];
  for(var i=1;i<levels.length;i++)if(lv<=levels[i])return values[i-1]+(values[i]-values[i-1])*(lv-levels[i-1])/(levels[i]-levels[i-1]);
  return values[values.length-1];
};
B.bindGrowth = function(M, cfg, getIds, isOwner, getOwner) {
  function ownerInstance(){return window.$gameActors&&$gameActors._data[getIds().actor];}
  M.coefficient=function(key,a){a=a||ownerInstance();return Math.floor(B.curve(a,cfg.growth.damage[key]||[0,0,0,0],cfg.growth.levels));};
  M.unlocked=function(a,key){var level=cfg.growth.unlock[key]||1;return !!a&&a.level>=level;};
  M.growth=function(a){return {element:1,skill:1,final:1,completion:1};};
  alias(Game_Actor.prototype,'meetsSkillConditions',function(old,args){
    var s=args[0],key=s&&getIds().key[s.id],a=isOwner(this)?this:ownerInstance();
    if(key==='return'&&isOwner(this))return !!($gameParty.inBattle()&&B.isBound(this)&&live(this)&&this.canMove());
    if(key&&!M.unlocked(a,key))return false;
    return old.apply(this,args);
  });
  alias(Game_Actor.prototype,'skills',function(old,args){
    var rows=old.apply(this,args),a=isOwner(this)?this:ownerInstance();
    return rows.filter(function(s){var key=getIds().key[s.id];return !key||M.unlocked(a,key);});
  });
  // 已有存档只补实际等级允许的技能，并清掉旧版一级授予的高阶技能。
  function sync(a){
    if(!a)return;var cl=a.currentClass();
    cl.learnings.forEach(function(l){if(!getIds().key[l.skillId])return;if(l.level<=a.level&&!a.isLearnedSkill(l.skillId))a.learnSkill(l.skillId);else if(l.level>a.level&&a.isLearnedSkill(l.skillId))a.forgetSkill(l.skillId);});
    if(M===window.CodexTusu&&/^(?:【最终兵器】|\[最终兵器\])屠苏$/.test(a._name))a._name='屠苏';
  }
  M.syncGrowth=sync;
  alias(DataManager,'extractSaveContents',function(old,args){var out=old.apply(this,args);sync($gameActors._data[getIds().actor]);return out;});
  alias(Game_Actor.prototype,'levelUp',function(old,args){var out=old.apply(this,args);if(isOwner(this))sync(this);return out;});
  alias(Game_Actor.prototype,'levelDown',function(old,args){var out=old.apply(this,args);if(isOwner(this))sync(this);return out;});
  alias(M,'recruit',function(old,args){var out=old.apply(this,args);sync($gameActors._data[getIds().actor]);return out;});
  // HelpExtend使用当前角色的当前系数；不泄露尚未解锁的成长。
  if(typeof Sprite_ItemHelp!=='undefined')alias(Sprite_ItemHelp.prototype,'setItem',function(old,args){
    var s=args[0],key=s&&getIds().key[s.id];
    if(!key||!s.descParams)return old.apply(this,args);
    var a=$gameActors&&$gameActors._data[getIds().actor];
    var rows=s.descParams.map(function(r){var v=r.slice(),text=v[0];
      var dk=key.replace(/^arm\./,'').replace(/^support\./,'').replace('body.phys','body_phys').replace('body.mag','body_mag');
      if(cfg.growth.damage[dk]&&/伤害[:：]/.test(text))text=text.replace(/×[\d.]+(?:亿)?(?:（随等级成长）)?/,'×'+M.coefficient(dk,a));
      v[0]=text;return v;});
    var copy=Object.assign({},s,{descParams:rows});args[0]=copy;return old.apply(this,args);
  });
};
  return B;
});
