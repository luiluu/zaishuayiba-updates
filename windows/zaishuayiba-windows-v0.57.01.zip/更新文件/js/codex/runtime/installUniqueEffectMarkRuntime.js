// 装备说明的唯一特效标识：按备注里的 <KyoUnique: 特效名> 在对应说明行前加「◆唯一 」。
// 只改说明缓存 descParams 的文字，不改备注以外的数值、属性或存档字段。
window.CodexRuntime.register('installUniqueEffectMarkRuntime', function() {
  'use strict';
  var W = window;
  var U = W.CodexUnique = { version: 1, marked: 0, items: 0 };
  var MARK = '◆唯一 ';
  var TAG = /<KyoUnique\s*:\s*([^>\r\n]+)>/gi;
  var COLOR = /^(?:(?:\\|\x1b)c\[\d+\])+/;
  var MARKED = /^(\s*(?:(?:\\|\x1b)c\[\d+\])*)◆唯一 /;
  var EFFECT = /^(?:混沌神话特效|神话特效|太古特效|mod特效|Mod特效|特效|效果|光环|连击|符石|被动|技能|套装(?:\(\d+\))?)(?:[:：]|[（(])/;

  U.text = function(value) {
    return typeof value === 'string' ? value : (value == null ? '' : String(value));
  };

  U.canon = function(value) {
    return U.text(value).replace(/全伤(?:害)?/g, '全属性伤害');
  };

  U.matches = function(text, key) {
    return U.canon(text).indexOf(U.canon(key)) >= 0;
  };

  U.hasMark = function(text) {
    return MARKED.test(U.text(text));
  };

  U.stripMark = function(text) {
    return U.text(text).replace(MARKED, '$1');
  };

  U.addMark = function(text) {
    var value = U.text(text);
    if (U.hasMark(value)) return value;
    var lead = (value.match(/^\s*/) || [''])[0];
    var rest = value.slice(lead.length);
    var match = COLOR.exec(rest);
    var head = match ? match[0] : '';
    // 标识挡住了行首，排版模块的「标签全角冒号」照顾不到，这里先统一。
    var body = rest.slice(head.length).replace(/^([^：:\s\\\x1b]{1,8}):/, '$1：');
    return lead + head + MARK + body;
  };

  U.isEffect = function(text) {
    var value = U.text(text).replace(/^\s+/, '').replace(COLOR, '').trim();
    return EFFECT.test(value);
  };

  U.tagsFromNote = function(note) {
    var out = [];
    var value = U.text(note);
    if (!value) return out;
    TAG.lastIndex = 0;
    var match;
    while ((match = TAG.exec(value))) {
      var key = U.text(match[1]).trim();
      if (key && out.indexOf(key) < 0) out.push(key);
    }
    return out;
  };

  U.globalKeys = function() {
    if (U._globalKeys) return U._globalKeys;
    var keys = [];
    var seen = {};
    function add(note) {
      U.tagsFromNote(note).forEach(function(key) {
        if (!seen[key]) { seen[key] = true; keys.push(key); }
      });
    }
    // 只取原型：独立实例的备注是生成时复制的，标签撤掉后旧实例里还留着。
    addEach([W.$dataWeapons, W.$dataArmors], function(item) {
      if (item && !(item.baseItemId && item.baseItemId !== item.id)) add(item.note);
    });
    keys.sort(function(a, b) { return b.length - a.length; });
    if (keys.length) U._globalKeys = keys;
    return keys;
  };

  function addEach(lists, callback) {
    (lists || []).forEach(function(list) {
      if (!list) return;
      for (var i = 0; i < list.length; i++) {
        if (list[i]) callback(list[i], i);
      }
    });
  }

  function databaseFor(item) {
    return item && item.wtypeId !== undefined ? W.$dataWeapons : W.$dataArmors;
  }

  U.keysOf = function(item) {
    if (!item) return [];
    var keys = [];
    var seen = {};
    function add(list) {
      (list || []).forEach(function(key) {
        if (key && !seen[key]) { seen[key] = true; keys.push(key); }
      });
    }
    add(U.tagsFromNote(item.note));
    var baseId = item.originalBaseItemId || item.baseItemId;
    if (baseId) {
      var db = databaseFor(item);
      var base = db && db[baseId];
      if (base && base !== item) add(U.tagsFromNote(base.note));
    }
    // 独立实例与随机词缀的旧备注可能还没有标签：只取当前备注里确实出现的标签键。
    if (item.originalBaseItemId || item.baseItemId) {
      var note = U.text(item.note);
      U.globalKeys().forEach(function(key) {
        if (U.matches(note, key)) add([key]);
      });
    }
    // 数据库里已撤掉的标签不再算数（旧实例备注里的残留）。
    var live = U.globalKeys();
    keys = keys.filter(function(key) { return live.indexOf(key) >= 0; });
    U.lastKeys = keys;
    return keys;
  };

  U.mark = function(item) {
    if (!item || !Array.isArray(item.descParams)) return 0;
    var keys = U.keysOf(item);
    // 说明缓存里旧版画上的标识，对不上现有标签的擦掉。
    item.descParams.forEach(function(row) {
      if (!Array.isArray(row) || !U.hasMark(row[0])) return;
      var plain = U.stripMark(row[0]);
      if (!keys.some(function(key) { return U.matches(plain, key); })) row[0] = plain;
    });
    if (!keys.length) return 0;
    var count = 0;
    item.descParams.forEach(function(row) {
      if (!Array.isArray(row)) return;
      var text = U.text(row[0]);
      if (!text || U.hasMark(text) || !U.isEffect(text)) return;
      if (text === U.text(item.name) || text === U.text(item.description)) return;
      for (var i = 0; i < keys.length; i++) {
        if (U.matches(text, keys[i])) {
          row[0] = U.addMark(text);
          count++;
          break;
        }
      }
    });
    if (count) {
      U.marked += count;
      U.items++;
    }
    return count;
  };

  U.sweep = function(root) {
    var seen = typeof WeakSet !== 'undefined' ? new WeakSet() : null;
    var list = [];
    var count = 0;
    function visited(node) {
      if (seen) {
        if (seen.has(node)) return true;
        seen.add(node);
        count++;
        return false;
      }
      if (list.indexOf(node) >= 0) return true;
      list.push(node);
      count++;
      return false;
    }
    function visit(node, depth) {
      if (!node || typeof node !== 'object' || depth > 12) return;
      if (visited(node)) return;
      if ((node.wtypeId !== undefined || node.atypeId !== undefined) && Array.isArray(node.descParams)) {
        U.mark(node);
      }
      if (Array.isArray(node)) {
        for (var i = 0; i < node.length; i++) visit(node[i], depth + 1);
        return;
      }
      for (var key in node) {
        if (!Object.prototype.hasOwnProperty.call(node, key)) continue;
        visit(node[key], depth + 1);
      }
    }
    visit(root, 0);
    return count;
  };

  U.sweepLive = function() {
    var party = W.$gameParty;
    if (party) {
      U.sweep(party._items);
      U.sweep(party._weapons);
      U.sweep(party._armors);
    }
    var actors = W.$gameActors;
    if (actors && actors._data) {
      actors._data.forEach(function(actor) {
        if (actor && actor._equips) U.sweep(actor._equips);
      });
    }
  };

  U.sweepDatabase = function() {
    U.sweep(W.$dataWeapons);
    U.sweep(W.$dataArmors);
  };

  if (W.CodexDisplay && typeof CodexDisplay.equipmentRows === 'function') {
    var nativeRows = CodexDisplay.equipmentRows;
    CodexDisplay.equipmentRows = function(item) {
      if (!item || !Array.isArray(item.descParams)) return nativeRows.apply(this, arguments);
      // 排序只看原文，标识不能改变品质顺序和行位置。
      item.descParams.forEach(function(row) {
        if (Array.isArray(row) && U.hasMark(row[0])) row[0] = U.stripMark(row[0]);
      });
      var out;
      try {
        out = nativeRows.apply(this, arguments);
      } finally {
        U.mark(item);
      }
      return out;
    };
  }

  if (W.RJO && RJO.HE && typeof RJO.HE.getDescParams === 'function') {
    var nativeDesc = RJO.HE.getDescParams;
    RJO.HE.getDescParams = function(item) {
      var out = nativeDesc.apply(this, arguments);
      U.mark(item);
      return out;
    };
  }

  if (W.DataManager) {
    if (typeof DataManager.extractSaveContents === 'function') {
      var nativeExtract = DataManager.extractSaveContents;
      DataManager.extractSaveContents = function(contents) {
        var out = nativeExtract.apply(this, arguments);
        U.sweep(contents);
        U.sweepLive();
        U.sweepDatabase();
        return out;
      };
    }
    if (typeof DataManager.createGameObjects === 'function') {
      var nativeCreate = DataManager.createGameObjects;
      DataManager.createGameObjects = function() {
        var out = nativeCreate.apply(this, arguments);
        U.sweepLive();
        U.sweepDatabase();
        return out;
      };
    }
  }

  return U;
});
