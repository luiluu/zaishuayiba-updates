// Extracted from the verified native runtime; installer order is maintained by main.js.
window.CodexRuntime.register("installNativeMiraRuntime", function() {
  function installNativeMiraRuntime() {
    // 静态角色／技能／法宝全部由原生 data 加载。只在现有 main.js 补
    // 无法用原生进阶、状态和公式标签表达的米拉专属结算。
    var M = window.CodexMira = window.CodexMira || {};
    M.actor = 168;
    M.armor = 4577;
    M.dragon = 2592;
    M.immortalBlood = 2597; // 旧版主动技能留下的限时状态，仅用于存档清理。
    // 与 game/tools/mira_database_spec.json、分级复算脚本相同的固定系数。
    M.multipliers = {
      human_foundation: 1.66, second_rank_scalar: 1.1,
      second_rank_power: 0.5, human_third: 2.88, dragon_third: 17.77,
      dragon_level_60: 1.5, dragon_level_70: 2,
      destruction_damage: 1.15, forbidden_damage: 1.15,
      forbidden_param_rate: 1.5, forbidden_resource_cost: 0.75,
      forbidden_hp_cost: 0.1, end_of_all_sun: 1.2
    };
    // 仅匹配游戏现有的放逐、封魔、沉默、封技和典型负面状态。
    // 编号清单由米拉数据源核对；避免免疫一切状态时误挡黑龙形态及增益。
    M.endOfAllImmuneStates = [4, 6, 10, 29, 30, 33, 35, 46, 100, 107, 126, 127, 128, 130, 131, 150, 178, 184, 234, 263, 264, 274, 320, 741, 742, 927, 995, 1082, 1101, 1102, 1114, 1119, 1264, 1544, 2016, 2042, 2043, 2503, 2507, 2513];
    M.skills = { strike: 10140, sweep: 10141, ember: 10142,
      rain: 10143, liberate: 10146, flame: 10147, claw: 10148,
      breath: 10149, wing: 10150, sun: 10151 };
    function isMira(actor) { return actor && actor.isActor && actor.isActor() && actor.actorId() === M.actor; }
    var oldMiraActorName = Game_Actor.prototype.name;
    Game_Actor.prototype.name = function() {
      return isMira(this) ? '米拉' : oldMiraActorName.call(this);
    };
    // 职业与装备可能各自追加同一种技能分类。只在米拉的显示列表
    // 合并相同类型ID，保留动态新增分类及原生技能/装备/封印判定。
    function uniqueMiraSkillTypes(actor, types) {
      if (!isMira(actor)) return types;
      return types.filter(function(id, index) { return types.indexOf(id) === index; });
    }
    var oldMiraSkillTypes = Game_Actor.prototype.addedSkillTypes;
    Game_Actor.prototype.addedSkillTypes = function() {
      return uniqueMiraSkillTypes(this, oldMiraSkillTypes.apply(this, arguments));
    };
    var oldMiraMenuSkillTypes = Game_Actor.prototype.addedSkillTypesForMenu;
    Game_Actor.prototype.addedSkillTypesForMenu = function() {
      var types = oldMiraMenuSkillTypes ? oldMiraMenuSkillTypes.apply(this, arguments) : this.addedSkillTypes();
      return uniqueMiraSkillTypes(this, types);
    };
    function rank(actor) { return isMira(actor) ? Number(actor._AdvancedNum || 0) : 0; }
    function has(actor, skill, needed) {
      return isMira(actor) && rank(actor) >= (needed || 0) && actor.isLearnedSkill(skill);
    }
    function dragon(actor) {
      return isMira(actor) && $gameParty && $gameParty.inBattle() &&
        rank(actor) >= 3 && has(actor, 10161, 3) && actor.isStateAffected(M.dragon);
    }
    function endOfAll(actor) { return dragon(actor) && has(actor,10167,3); }
    function endOfAllResists(actor,stateId) {
      return endOfAll(actor) && M.endOfAllImmuneStates.indexOf(stateId) !== -1;
    }
    var oldStateResist = Game_BattlerBase.prototype.isStateResist;
    Game_BattlerBase.prototype.isStateResist = function(stateId) {
      return endOfAllResists(this,stateId) || oldStateResist.call(this,stateId);
    };
    // 自定义技能效果可直接 addState；仍要通过相同的状态免疫名单。
    var oldAddState = Game_Battler.prototype.addState;
    Game_Battler.prototype.addState = function(stateId) {
      if (endOfAllResists(this,stateId)) return;
      oldAddState.call(this,stateId);
    };
    var oldAddDebuff = Game_Battler.prototype.addDebuff;
    Game_Battler.prototype.addDebuff = function(paramId,turns) {
      if (endOfAll(this)) return;
      oldAddDebuff.call(this,paramId,turns);
    };
    function heartEquipped(actor) {
      return actor.equips().some(function(item) {
        return item && (item.baseItemId || item.id) === M.armor;
      });
    }
    function refreshMiraArtifactPanel(record) {
      if (!record || Number(record.baseItemId) !== M.armor ||
          record._codexMiraArtifactTextRevision === 1) return;
      var base = $dataArmors && $dataArmors[M.armor];
      if (!base) return;
      record.description = base.description;
      var oldLines = String(record.note || '').split(/\r?\n/);
      var panelLines = String(base.note || '').split(/\r?\n/).filter(function(line) {
        return line.indexOf('<pos=APs text=') === 0;
      });
      var firstPanel = oldLines.findIndex(function(line) {
        return line.indexOf('<pos=APs text=') === 0;
      });
      var retained = oldLines.filter(function(line) {
        return line.indexOf('<pos=APs text=') !== 0 && !/^<HelpWidth:\s*\d+>/i.test(line);
      });
      var insertAt = firstPanel < 0 ? retained.length : oldLines.slice(0, firstPanel).filter(function(line) {
        return line.indexOf('<pos=APs text=') !== 0 && !/^<HelpWidth:\s*\d+>/i.test(line);
      }).length;
      retained.splice.apply(retained, [insertAt, 0].concat(panelLines));
      record.note = retained.join('\n');
      if (DataManager.extractMetadata) DataManager.extractMetadata(record);
      if (window.RJO && RJO.HE && RJO.HE.getDescParams) {
        RJO.HE.getDescParams(record, 2);
      }
      record._codexMiraArtifactTextRevision = 1;
    }
    function skillLevel(actor, id) {
      return actor.skillMasteryLevel ? Number(actor.skillMasteryLevel(id) || 0) : 0;
    }
    var dragonSkills = [10148, 10149, 10150, 10151, 10152];
    var humanSkills = [10140, 10141, 10142, 10143];
    var activeSkills = humanSkills.concat([M.skills.liberate]).concat(dragonSkills);
    // 原本需要消耗行动的护身/炽燃改为人形常驻被动。35/45级的进化
    // 在同一被动上追加倍率，不再施加三回合状态或重复占用技能栏。
    // G_StateParam 在 paramRate 之后才加状态固定属性；必须对最终面板乘算。
    var oldMiraFinalParam = Game_Actor.prototype.param;
    Game_Actor.prototype.param = function(paramId) {
      var value = oldMiraFinalParam.call(this,paramId);
      if (isMira(this) && !dragon(this)) {
        if ((paramId===3 || paramId===5) && this.level>=30 && has(this,10144)) {
          value *= 1.25 * (1+0.25*Math.min(1,Math.max(0,(this.level-30)/5)));
        }
        if ((paramId===2 || paramId===4 || paramId===6) &&
            this.level>=40 && has(this,10145)) {
          value *= 1.10 * (paramId===6 ? 1+0.25*Math.min(1,Math.max(0,(this.level-40)/5)) : 1);
        }
      }
      if (has(this,10166,2) && paramId >= 0 && paramId < 8) {
        value *= M.multipliers.forbidden_param_rate;
      }
      return isMira(this) && paramId >= 0 && paramId < 8 ?
        Math.round(Math.min(this.paramMax(paramId),value)) : value;
    };
    // 禁忌既减少战技也减少魔法的 MP／TP 消耗，保留其他插件原有的减耗。
    var oldSkillMpCost = Game_BattlerBase.prototype.skillMpCost;
    Game_BattlerBase.prototype.skillMpCost = function(skill) {
      var cost = oldSkillMpCost.call(this, skill);
      if (skill && activeSkills.indexOf(skill.id) !== -1 && has(this,10166,2)) {
        return Math.floor(cost * M.multipliers.forbidden_resource_cost);
      }
      return cost;
    };
    var oldSkillTpCost = Game_BattlerBase.prototype.skillTpCost;
    Game_BattlerBase.prototype.skillTpCost = function(skill) {
      var cost = oldSkillTpCost.call(this, skill);
      if (skill && activeSkills.indexOf(skill.id) !== -1 && has(this,10166,2)) {
        return Math.floor(cost * M.multipliers.forbidden_resource_cost);
      }
      return cost;
    };
    var oldPaySkillCost = Game_BattlerBase.prototype.paySkillCost;
    Game_BattlerBase.prototype.paySkillCost = function(skill) {
      oldPaySkillCost.call(this,skill);
      // 只登记本次施放的生命代价；伤害与状态结算结束后统一支付。
      this._codexMiraForbiddenHpDue = null;
      if (skill && activeSkills.indexOf(skill.id) !== -1 && has(this,10166,2)) {
        this._codexMiraForbiddenHpDue = {
          skillId: skill.id,
          cost: Math.max(1,Math.floor(this.mhp * M.multipliers.forbidden_hp_cost))
        };
      }
    };
    var oldMeets = Game_Actor.prototype.meetsSkillConditions ||
      Game_BattlerBase.prototype.meetsSkillConditions;
    Game_Actor.prototype.meetsSkillConditions = function(skill) {
      if (isMira(this) && skill) {
        if (dragonSkills.indexOf(skill.id) !== -1 && !dragon(this)) return false;
        if (humanSkills.indexOf(skill.id) !== -1 && dragon(this)) return false;
        if (skill.id === M.skills.liberate && (rank(this) < 3 ||
            this.level < 50 || !has(this, 10146, 3) || dragon(this))) return false;
        if (skill.id === M.skills.flame) return false; // 自动效果，不能单独施放。
      }
      return oldMeets.call(this, skill);
    };
    var oldBattlerName = Game_Actor.prototype.battlerName;
    Game_Actor.prototype.battlerName = function() {
      if (dragon(this)) return 'BlackDragon_Mira_SV';
      return oldBattlerName.call(this);
    };
    M.damage = function(a, b, id) {
      if (!isMira(a)) return 0;
      var lv = skillLevel(a, id);
      var isDragonAttack = [M.skills.claw,M.skills.breath,M.skills.wing,M.skills.sun].indexOf(id) !== -1;
      if (isDragonAttack && !dragon(a)) return 0;
      if (id === M.skills.liberate && (rank(a) < 3 || a.level < 50 || dragon(a))) return 0;
      var raw = 0, coeff = 0.15;
      switch (id) {
      case 10140: raw = 80000*a.atk+20000*a.def; break;
      case 10141:
        raw = (48000*a.atk+12000*a.def) *
          (1 + .75 * (1 - Math.max(0, Math.min(1, b.hpRate()))));
        break;
      case 10142: raw = 80000*a.mat+20000*a.mdf; break;
      case 10143:
        // Three hits together retain the former base output. 余烬术式 creates
        // a magic-defense opening that this rain spell can exploit.
        raw = (48000*a.mat+12000*a.mdf) / 3 *
          (b.isStateAffected(2594) ? 1.25 : 1);
        break;
      case 10146: case 10147: raw = 220*a.atk+220*a.mat+40*a.mhp; coeff = .1; break;
      case 10148: raw = 800*a.atk+240*a.def-(window.CodexDamage&&CodexDamage.isCalculating()?0:35*b.def); break;
      case 10149: raw = 600*a.mat+160*a.mdf+80*a.mmp-(window.CodexDamage&&CodexDamage.isCalculating()?0:35*b.mdf); break;
      case 10150: raw = 500*a.atk+180*a.def+300*a.agi-(window.CodexDamage&&CodexDamage.isCalculating()?0:30*b.def); coeff=.18; break;
      case 10151:
        raw = 500*a.mhp+140*a.mmp+1200*a.atk+680*a.def+
          1200*a.mat+680*a.mdf+900*a.agi+240*a.luk-(window.CodexDamage&&CodexDamage.isCalculating()?0:40*b.def+40*b.mdf);
        coeff = .20; break;
      default: return 0;
      }
      // 技能等级倍率；引擎本身的熟练度和目标元素抗性按原流程结算。
      var total = Math.max(0,raw)*(1+coeff*lv);
      if (!isDragonAttack && has(a,10156)) {
        // 赤鳞共鸣 interpolates continuously between its original growth anchors.
        var foundation=a.level>=60?2:a.level>=50?1.8+0.02*(a.level-50):
          a.level>=15?1.66+0.14*(a.level-15)/35:1.15+0.051*Math.max(0,a.level-5);
        total *= foundation;
      }
      if (rank(a) >= 2 && has(a,10158,2)) total *= 2.5;
      if (heartEquipped(a)) total *= 1.2;
      if (isDragonAttack) {
        total *= 2; // 黑龙火焰属性加成。
        if (has(a,10161,3)) total *= M.multipliers.dragon_third;
        if (a.level >= 60 && has(a,10163,3)) total *= M.multipliers.dragon_level_60;
        if (a.level >= 70 && has(a,10164,3)) total *= M.multipliers.dragon_level_70;
      } else if (rank(a) === 2 && has(a,10159,2)) {
        var attr = (id === M.skills.ember || id === M.skills.rain) ? a.mat : a.atk;
        total *= M.multipliers.second_rank_scalar *
          Math.pow(Math.max(1,attr)/40000,M.multipliers.second_rank_power);
      } else if (rank(a) >= 3 && has(a,10160,3)) {
        total *= M.multipliers.human_third;
      }
      if (id === M.skills.liberate || id === M.skills.flame) total *= 2;
      // 三阶被动以原进阶系统授技；仍检查进阶数，避免旧档提前拥有时生效。
      if (has(a,10165,1)) total *= M.multipliers.destruction_damage;
      if (has(a,10166,2)) total *= M.multipliers.forbidden_damage;
      if (id === M.skills.sun && dragon(a) && has(a,10167,3)) {
        total *= M.multipliers.end_of_all_sun;
      }
      return Math.floor(total);
    };

    // 当前行动命中的火伤按敌方目标分别累计；劫火只追加一次，且不会递归。
    var oldApply = Game_Action.prototype.apply;
    Game_Action.prototype.apply = function(target) {
      oldApply.call(this,target);
      var actor=this.subject(), item=this.item();
      if (!isMira(actor) || !item || !target || !target.isEnemy || !target.isEnemy()) return;
      var amount=target.result && target.result().isHit() ? Math.max(0,target.result().hpDamage || 0) : 0;
      if (!amount || item.damage.elementId!==2) return;
      if (actor.level>=55 && (dragon(actor) && has(actor,10162,3) ||
          item.id===M.skills.liberate && has(actor,10162,3))) {
        actor._codexMiraTurnFlame = actor._codexMiraTurnFlame || [];
        var entry=actor._codexMiraTurnFlame.filter(function(x){return x.target===target;})[0];
        if (!entry) { entry={target:target,amount:0}; actor._codexMiraTurnFlame.push(entry); }
        entry.amount+=amount;
      }
    };
    var oldEndAction = BattleManager.endAction;
    BattleManager.endAction = function() {
      var actor=this._subject, action=this._action;
      var transform=isMira(actor) && action && action.item() && action.item().id===M.skills.liberate;
      var due=actor && actor._codexMiraForbiddenHpDue;
      if (actor) actor._codexMiraForbiddenHpDue=null;
      if (due && action && action.item() && due.skillId===action.item().id) {
        // 行动效果结束后、每次施放仅扣一次；未命中照扣且最低保留 1 HP。
        var paid=Math.min(due.cost,Math.max(0,actor.hp-1));
        if (paid>0) actor.gainHp(-paid);
      }
      oldEndAction.call(this);
      if (transform && rank(actor)>=3 && has(actor,10146,3)) {
        actor.addState(M.dragon);
        if (endOfAll(actor)) {
          M.endOfAllImmuneStates.forEach(function(stateId) {
            if (actor.isStateAffected(stateId)) actor.removeState(stateId);
          });
          for (var paramId=0;paramId<8;paramId++) {
            if (actor.isDebuffAffected(paramId)) actor.removeDebuff(paramId);
          }
        }
        actor.clearActions(); // 解放代价：该角色本回合全部剩余行动结束。
        if (actor.refresh) actor.refresh();
      }
    };
    var oldStartTurn = BattleManager.startTurn;
    BattleManager.startTurn = function() {
      var actor=$gameActors && $gameActors.actor(M.actor);
      if (actor) actor._codexMiraTurnFlame=[];
      return oldStartTurn.call(this);
    };
    var oldEndTurn = BattleManager.endTurn;
    BattleManager.endTurn = function() {
      var actor=$gameActors && $gameActors.actor(M.actor);
      if (actor && actor.level>=55 && has(actor,10162,3) && $gameParty.inBattle()) {
        (actor._codexMiraTurnFlame || []).forEach(function(entry) {
          var target=entry.target;
          if (!target || target.isDead()) return;
          var extra=Math.floor(entry.amount*.30);
          if (extra>0) { target.gainHp(-extra); target.startDamagePopup(); }
        });
        actor._codexMiraTurnFlame=[];
      }
      return oldEndTurn.call(this);
    };
    var oldMakeDamageValue=Game_Action.prototype.makeDamageValue;
    Game_Action.prototype.makeDamageValue=function(target,critical) {
      var value=oldMakeDamageValue.call(this,target,critical);
      if (dragon(target) && has(target,10154,3) && value>0) value=Math.floor(value*.8);
      return value;
    };
    var oldTurnEnd=Game_Actor.prototype.onTurnEnd || Game_Battler.prototype.onTurnEnd;
    Game_Actor.prototype.onTurnEnd=function() {
      var heal=dragon(this) && has(this,10154,3) && this.isAlive();
      oldTurnEnd.call(this);
      if (heal && this.isAlive()) this.gainHp(Math.floor(this.mhp*.05));
    };
    var oldMiraEndBattle=BattleManager.endBattle;
    BattleManager.endBattle=function(result) {
      var outcome=oldMiraEndBattle.call(this,result);
      var actor=$gameActors && $gameActors._data[M.actor];
      if (actor) {
        actor._codexMiraForbiddenHpDue=null;
        actor._codexMiraTurnFlame=[];
        if (actor.isStateAffected(M.dragon)) actor.removeState(M.dragon);
        if (actor.isStateAffected(M.immortalBlood)) actor.removeState(M.immortalBlood);
        if (actor.isStateAffected(2598)) actor.removeState(2598);
        if (actor.isStateAffected(2599)) actor.removeState(2599);
      }
      return outcome;
    };
    function fixStrongClassification(actor) {
      if (!actor || !actor.actorId || actor.actorId()<141 || actor.actorId()>172 || !CodexTier.isNonWeak(actor)) return; // 【Claude·未经Codex检验】v0.44 只纠正分类为强者／超强者的角色
      var changed=false;
      if (actor.isLearnedSkill(6235)) { actor.forgetSkill(6235); changed=true; }
      if (!actor.isLearnedSkill(6216)) { actor.learnSkill(6216); changed=true; }
      if (actor.isLearnedSkill(5970)) {
        actor.forgetSkill(5970); actor.learnSkill(5971); changed=true;
      }
      if (actor.isStateAffected && actor.isStateAffected(1035)) {
        actor.removeState(1035); changed=true;
      }
      if (actor.isStateAffected && actor.isStateAffected(1276)) {
        actor.removeState(1276); changed=true;
      }
      if (actor.isStateAffected && actor.isStateAffected(1277)) {
        actor.removeState(1277); changed=true;
      }
      if (actor.actorId()===163 && actor._lastMenuSkill && actor._lastMenuSkill._itemId===5566) {
        actor._lastMenuSkill._itemId=0;
        actor._lastMenuSkill._dataClass='';
      }
      if (changed && actor.refreshPassiveSkillCache) actor.refreshPassiveSkillCache();
      if (changed && actor.initPassiveCache && actor.refreshPassiveCache) {
        actor.initPassiveCache(); actor.refreshPassiveCache();
      }
    }
    var oldStrongSetup=Game_Actor.prototype.setup;
    Game_Actor.prototype.setup=function(actorId) {
      oldStrongSetup.call(this,actorId);
      fixStrongClassification(this);
    };
    var oldExtract=DataManager.extractSaveContents;
    DataManager.extractSaveContents=function(contents) {
      oldExtract.call(this,contents);
      // 已有存档中的独立法宝保留等级、经验和词缀，只同步说明文字。
      if ($dataArmors) $dataArmors.forEach(refreshMiraArtifactPanel);
      if ($gameActors && $gameActors._data) for (var strongId=141;strongId<=170;strongId++) {
        fixStrongClassification($gameActors._data[strongId]);
      }
      var actor=$gameActors && $gameActors._data[M.actor];
      if (actor) {
        actor._codexMiraForbiddenHpDue=null;
        actor._codexMiraTurnFlame=[];
        if (actor.isStateAffected(M.dragon)) actor.removeState(M.dragon);
        if (actor.isStateAffected(M.immortalBlood)) actor.removeState(M.immortalBlood);
        if (actor.isStateAffected(2598)) actor.removeState(2598);
        if (actor.isStateAffected(2599)) actor.removeState(2599);
        // 既有存档可能在新增三条被动前已完成进阶；只补已达成的阶数。
        [[1,10165],[2,10166],[3,10154],[3,10167]].forEach(function(entry) {
          if (rank(actor)>=entry[0] && !actor.isLearnedSkill(entry[1])) actor.learnSkill(entry[1]);
        });
        // Former builds granted these two passives earlier.  Preserve every
        // other learned skill while moving only these to the new milestones.
        if (actor.isLearnedSkill(10153)) actor.forgetSkill(10153); // merged into 10152
        if (actor.level<5 && actor.isLearnedSkill(10156)) actor.forgetSkill(10156);
        if (actor.level<55 && actor.isLearnedSkill(10162)) actor.forgetSkill(10162);
        var learnings=$dataClasses[166] && $dataClasses[166].learnings || [];
        learnings.forEach(function(entry) {
          if (entry.level<=actor.level && !actor.isLearnedSkill(entry.skillId)) {
            actor.learnSkill(entry.skillId);
          }
        });
      }
    };
    // 深渊地图每场胜利只判定一次，概率 1/30；由原版奖励列表发放。
    var oldMakeRewards=BattleManager.makeRewards;
    BattleManager.makeRewards=function() {
      oldMakeRewards.call(this);
      var mapId=$gameMap && $gameMap.mapId && $gameMap.mapId();
      var map=$dataMapInfos && $dataMapInfos[mapId];
      if (map && /^深渊/.test(map.name || '') && Math.randomInt(30)===0 && $dataItems[2903]) {
        this._rewards.items.push($dataItems[2903]);
      }
    };
    M.recruit=function() {
      if (!$dataActors[M.actor] || !$dataArmors[M.armor]) throw new Error('米拉数据库缺失');
      if ($gameParty._actors.indexOf(M.actor)!==-1) return false;
      var actor=$gameActors.actor(M.actor), base=$dataArmors[M.armor];
      var slot=actor.equipSlots().indexOf(base.etypeId);
      if (slot<0 || !actor.canEquip(base)) throw new Error('米拉法宝装备槽不可用');
      var worn=actor.equips()[slot];
      var alreadyWearing=worn && (worn.baseItemId || worn.id)===M.armor;
      var artifact=null;
      if (!alreadyWearing) {
        artifact=$gameParty.getMatchingBaseItem && $gameParty.getMatchingBaseItem(base,false);
        if (!artifact) {
          if (!DataManager.isIndependent(base) || !$gameParty.gainIndependentItem)
            throw new Error('原版独立法宝系统不可用');
          artifact=$gameParty.gainIndependentItem(base,1)[0];
        }
        if (!artifact) throw new Error('黑龙心鳞生成失败');
        actor.changeEquip(slot,artifact);
        if (actor.equips()[slot]!==artifact) throw new Error('黑龙心鳞未能装备到米拉身上');
      }
      $gameParty.addActor(M.actor);
      return true;
    };
    // 只在兑换大厅 132 地图的原有号角商店出售限购号角；法宝仅随召唤装备。
    var oldShopPrepare=Scene_Shop.prototype.prepare;
    Scene_Shop.prototype.prepare=function(goods,purchaseOnly) {
      goods=goods || [];
      var mapId=$gameMap && $gameMap.mapId && $gameMap.mapId();
      var isHornShop=goods.some(function(g) {
        return g[0]===0 && $dataItems[g[1]] && /^伙伴号角：/.test($dataItems[g[1]].name || '');
      });
      var has=function(type,id) {return goods.some(function(g){return g[0]===type && g[1]===id;});};
      if (mapId===132 && isHornShop && !has(0,2904)) goods.push([0,2904,0,0]);
      // 清理之前版本动态加入的法宝商品，保留原版商店其余货物。
      if (mapId===132) for (var i=goods.length-1;i>=0;i--) {
        if (goods[i][0]===2 && goods[i][1]===M.armor) goods.splice(i,1);
      }
      oldShopPrepare.call(this,goods,purchaseOnly);
      var newHornStock=mapId===132 && isHornShop && $gameSystem && !$gameSystem._codexMiraHornStockInitialized;
      if (newHornStock) {
        var inventories=$gameSystem._inventories || {};
        Object.keys(inventories).forEach(function(key) {
          var inv=inventories[key];
          if (!inv || !inv.itemContainer) return;
          var item=$dataItems[2904];
          var stock=inv.itemContainer(item);
          if (stock && stock[item.id]===undefined) stock[item.id]=1;
        });
        $gameSystem._codexMiraHornStockInitialized=true;
      }
    };

    // The user's black-dragon art is an enemy-format static battler. The
    // actor retains Mira's SV name as a safe fallback; only the battle sprite
    // bitmap/frame changes during the transformed state.
    var oldDragonBitmap=Sprite_Actor.prototype.updateBitmap;
    Sprite_Actor.prototype.updateBitmap=function() {
      var isDragon=this._actor && dragon(this._actor) && !(window.CodexCostumes && CodexCostumes.active(this._actor));
      if (!isDragon && this._codexDragonVisual) this._battlerName='';
      oldDragonBitmap.call(this);
      if (isDragon && !this._codexDragonVisual) {
        this._mainSprite.bitmap=ImageManager.loadSvEnemy('BlackDragon_Mira_Enemy');
      }
      this._codexDragonVisual=!!isDragon;
      this._mainSprite.scale.set(isDragon ? 0.55 : 1);
      this._mainSprite.position.set(isDragon ? 20 : 0,isDragon ? 220 : 0);
      this._weaponSprite.visible=!isDragon;
    };
    var oldDragonFrame=Sprite_Actor.prototype.updateFrame;
    Sprite_Actor.prototype.updateFrame=function() {
      oldDragonFrame.call(this);
      if (this._codexDragonVisual && this._mainSprite.bitmap) {
        var bmp=this._mainSprite.bitmap;
        this._mainSprite.setFrame(0,0,bmp.width,bmp.height);
      }
    };
    var oldLoaded=DataManager.isDatabaseLoaded;
    DataManager.isDatabaseLoaded=function() {
      var ready=oldLoaded.call(this);
      if (ready && !M._checked) {
        if (!$dataActors[M.actor] || !$dataClasses[166] || !$dataSkills[M.skills.sun] ||
            !$dataStates[M.dragon] || !$dataItems[2903] || !$dataArmors[M.armor])
          throw new Error('米拉原生数据库文件未同步');
        M._checked=true;
      }
      return ready;
    };
    window.CodexDamageHooks.push({name:'mira',build:function(x,t,f){
 if(isMira(x.subject())&&x.item().id>=10140&&x.item().id<=10151){
  f.mode=[10142,10143,10149].indexOf(x.item().id)>=0?'magical':[10146,10147,10151].indexOf(x.item().id)>=0?'mixed':'physical';
 }
 if(dragon(t)&&has(t,10154,3))f.incomingMultiplier*=.8;
}});

  }

  // 米拉与渡鸦的新数值层只处理自己的直接攻击。插件已全部加载，
  // 因此在现有暴击和伤害包装链外侧各安装一次，追加伤害不会递归进入这里。

return installNativeMiraRuntime.apply(this, arguments);
});
