// 【Claude·未经Codex检验】v0.43 重做：说明缓存自愈、读档容错、一键出售对普通装备的“已装备”误判。
// 须最后安装：读档时在其他模块迁移完之后统一补齐缺失的说明缓存。
window.CodexRuntime.register('installCacheRepairV043Runtime', function() {
  'use strict';
  var W = window, R = W.ClaudeRepair43 = { version: 43, rebuilt: 0, failed: [] };

  // ---- 1. 说明缓存（descParams）----
  // 说明缓存是由备注生成的显示数据。v0.41 的专武／法宝迁移和数值修复只删除不重建，
  // 删除后的实例连同“没有缓存”一起写进存档，原生窗口读取 length 时报错（截图 YEP_ItemCore.js:1760，
  // 商店 YEP_ShopMenuCore.js:525 同理）。这里统一重建，不改属性、备注和实例身份。
  function kind(i) {
    if (!i || typeof i !== 'object') return -1;
    if (i.stypeId !== undefined) return 3;
    if (i.wtypeId !== undefined) return 1;
    if (i.atypeId !== undefined) return 2;
    if (i.itypeId !== undefined) return 0;
    return -1;
  }
  R.ensure = function(i) {
    if (!i || Array.isArray(i.descParams) && Array.isArray(i.pos)) return i;
    var type = kind(i);
    if (type < 0 || !W.RJO || !RJO.HE || typeof RJO.HE.getDescParams !== 'function') return i;
    try {
      RJO.HE.getDescParams(i, type);
      R.rebuilt++;
    } catch (e) {
      // 生成失败时保留名字行，窗口照常显示，并记录原因。
      console.error('说明缓存生成失败', i.id, i.name, e);
      R.failed.push({ id: i.id, name: i.name, error: String(e && e.message || e) });
      i.descParams = [[String(i.name || ''), RJO.HE.ItemDescNameSize || 20, '#ffffff', false, 1]];
      i.pos = [1, 1, 1, 1, 1];
    }
    return i;
  };
  R.sweep = function() {
    var n = 0;
    [W.$dataItems, W.$dataWeapons, W.$dataArmors, W.$dataSkills].forEach(function(list) {
      (list || []).forEach(function(o) { if (o && !(Array.isArray(o.descParams) && Array.isArray(o.pos))) { R.ensure(o); n++; } });
    });
    R.lastSweep = n;
    return n;
  };
  if (W.CodexBalance41) {
    ['normalizeSword', 'normalizeRelic'].forEach(function(k) {
      var old = CodexBalance41[k];
      if (typeof old === 'function') CodexBalance41[k] = function(i) { var out = old.apply(this, arguments); if (out) { delete i.pos; R.ensure(i); } return out; };
    });
  }
  function guardFirstArg(proto, k) {
    var old = proto && proto[k];
    if (typeof old === 'function') proto[k] = function(item) { R.ensure(item); return old.apply(this, arguments); };
  }
  if (W.Window_ItemStatus) guardFirstArg(Window_ItemStatus.prototype, 'drawEquipInfo');
  if (W.Window_ShopInfo) guardFirstArg(Window_ShopInfo.prototype, 'drawEquipInfo');
  if (W.Sprite_ItemHelp) guardFirstArg(Sprite_ItemHelp.prototype, 'setItem');

  // ---- 2. 读档容错 ----
  // v0.33 的独立装备编号整理遇到缺 baseItemId 或重复编号时直接抛错，整个存档无法读取。
  // 能从 originalBaseItemId 补回的先补；仍异常时本次跳过整理，按 v0.33 之前的方式读档并记录。
  if (typeof DataManager.reconcileIndependentSave === 'function') {
    var reconcile = DataManager.reconcileIndependentSave;
    R.independentAnomalies = function(contents) {
      var bad = [];
      [['weapon', 'weapons'], ['armor', 'armors']].forEach(function(g) {
        var seen = {};
        (contents && contents[g[1]] || []).forEach(function(item) {
          if (!item) return;
          var id = Number(item.id);
          if (!item.baseItemId && item.originalBaseItemId) item.baseItemId = item.originalBaseItemId;
          if (!item.baseItemId || !Number.isSafeInteger(id) || id < 1 || seen[id]) bad.push(g[0] + ' ' + item.id);
          seen[id] = true;
        });
      });
      return bad;
    };
    DataManager.reconcileIndependentSave = function(contents) {
      var bad = R.independentAnomalies(contents);
      if (bad.length) {
        console.warn('独立装备编号异常，本次读档跳过编号整理：', bad);
        R.reconcileSkipped = bad;
        this._lastIndependentReconcile = { version: 'v0.43', skipped: bad };
        return;
      }
      return reconcile.apply(this, arguments);
    };
  }

  // ---- 3. 一键出售 ----
  // 普通（非独立）装备在背包里的副本没有装备在任何人身上；旧判定按对象相同把它们全算“已装备”，一件都不卖。
  if (W.CodexSafeSell) {
    var S = CodexSafeSell, equipped = S.equipped, plan = S.plan, equippedSet = null;
    var real = function(i) { return W.CodexAbyssMerchant ? CodexAbyssMerchant.real(i) : i; };
    S.equipped = function(item) {
      var i = real(item);
      if (!i || !DataManager.isIndependent(i)) return false;
      if (equippedSet) return equippedSet.has(i);
      return equipped.apply(this, arguments);
    };
    S.plan = function() {
      equippedSet = new Set();
      ($gameActors._data || []).forEach(function(a) { if (a) (a._equips || []).forEach(function(e) { var o = e && e.object(); if (o) equippedSet.add(real(o)); }); });
      try { return plan.apply(this, arguments); } finally { equippedSet = null; }
    };
  }

  // 最外层：其他模块的读档迁移都跑完之后再补缓存。
  var extract = DataManager.extractSaveContents;
  DataManager.extractSaveContents = function() {
    var out = extract.apply(this, arguments);
    R.sweep();
    return out;
  };
  return R;
});
