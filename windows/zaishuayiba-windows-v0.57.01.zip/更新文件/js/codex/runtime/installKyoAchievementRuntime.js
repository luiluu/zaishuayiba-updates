/* 【Codex·未经Claude检验】 kyo专属 v1.1.0: icon-only achievement; native player nickname platinum cycle. */
window.CodexRuntime.register('installKyoAchievementRuntime', function() {
    'use strict';
    if (window.CodexKyoAchievement) return window.CodexKyoAchievement;
    var K = window.CodexKyoAchievement = {
        version: '1.2.0', designationId:31, achievementId: 143, iconId: 240202, name: 'kyo专属'
    };
    var registered = false;
    function enabled() { return !!(window.CodexTestMode && CodexTestMode.enabled()); }
    function ready() {
        return registered && !!($gameSystem && $gameSystem._codexGmReady && $gameParty) &&
            !$gameParty.inBattle() && !(SceneManager._scene instanceof Scene_Title);
    }
    K.owned = function() { return !!(ConfigManager.SAchievementS && ConfigManager.SAchievementS[K.achievementId]); };
    function isKyo(item) { return !!item && Number(item.id) === K.achievementId; }
    function badge() { return ImageManager.loadBitmap('img/codex_achievements/', 'KYO', 0, true); }
    var databaseLoaded = DataManager.isDatabaseLoaded;
    DataManager.isDatabaseLoaded = function() {
        if (!databaseLoaded.apply(this, arguments)) return false;
        if (!registered) {
            var existing = Star.AchievementSystem.Achievement[K.achievementId];
            if (existing && existing.AcName !== K.name) throw new Error('kyo专属：成就编号冲突');
            this.Star_AchievementSystemDatabaseAdd(K.achievementId, {
                AcName: K.name, AcType: '光辉事迹', AcIconId: String(K.iconId),
                AcTriggerT: '', AcShowText: '',
                AcItemReward: '[]', AcWeaponReward: '[]', AcArmorReward: '[]',
                AcEvalReward: '', AcEvalRewardText: ''
            }, null, null, null);
            registered = true;
            K.syncDesignation();
            badge();
        }
        return true;
    };
    // Native global ownership and cross-save synchronization stay intact;
    // only the first acquisition requires authorized, enabled test mode.
    var reward = Star.AchievementSystem.GetAcReward;
    Star.AchievementSystem.GetAcReward = function(id) {
        if (Number(id) === K.achievementId && (!ready() || (!K.owned() && !enabled()))) return;
        return reward.apply(this, arguments);
    };
    K.tryUnlock = function() {
        if (!ready() || !enabled() || K.owned()) return false;
        Star.AchievementSystem.GetAcReward(K.achievementId);
        if (!K.owned()) return false;
        K.syncDesignation();
        ConfigManager.save();
        return true;
    };
    // Achievement and native nameplate titles are separate databases.
    K.syncDesignation=function(){
        if(!registered||!window.$dataStarDesignationOpt)return false;
        var old=$dataStarDesignationOpt[K.designationId];
        if(old&&old.Name!==K.name)throw Error('kyo专属：称号编号冲突');
        if(!old)DataManager.Star_DesignationDatabaseAdd(K.designationId,{DesignationName:K.name,DesignationIcon:String(K.iconId),DesignationColor:'#f5f7fa'});
        ConfigManager.DesignationN=ConfigManager.DesignationN||{};
        ConfigManager.DesignationN[K.designationId]=K.owned();
        return K.owned();
    };
    var chooseTitle=Star.Designation.ChooseTitle;
    Star.Designation.ChooseTitle=function(){K.tryUnlock();K.syncDesignation();return chooseTitle.apply(this,arguments);};
    var titleExtract=DataManager.extractSaveContents;
    DataManager.extractSaveContents=function(){var out=titleExtract.apply(this,arguments);K.syncDesignation();return out;};
    // Native title/character drawing uses Bitmap.drawIcon rather than Window_Base.
    var bitmapIcon=Bitmap.prototype.drawIcon;
    Bitmap.prototype.drawIcon=function(id,x,y,scale){
        if(Number(id)!==K.iconId)return bitmapIcon.apply(this,arguments);
        var bitmap=this,source=badge(),size=32*(Number(scale)||1);
        source.addLoadListener(function(){bitmap.blt(source,0,0,source.width,source.height,x,y,size,size);});
    };
    var optionChange = Window_Options.prototype.changeValue;
    Window_Options.prototype.changeValue = function(symbol) {
        var result = optionChange.apply(this, arguments);
        if (symbol === 'codexTestMode') K.tryUnlock();
        return result;
    };
    ['Scene_Map', 'Scene_MenuBase'].forEach(function(name) {
        var prototype = window[name].prototype, update = prototype.update;
        prototype.update = function() { var result = update.apply(this, arguments); K.tryUnlock(); return result; };
    });

    K.drawBadge = function(win, x, y, size, opacity) {
        var source = badge(), contents = win.contents;
        source.addLoadListener(function() {
            if (!contents || !contents._context || win.contents !== contents) return;
            var previous = contents.paintOpacity;
            contents.paintOpacity = opacity === undefined ? previous : opacity;
            try { contents.blt(source, 0, 0, source.width, source.height, x, y, size, size); }
            finally { contents.paintOpacity = previous; }
        });
    };
    var drawIcon = Window_Base.prototype.drawIcon;
    Window_Base.prototype.drawIcon = function(id, x, y, scale) {
        if (Number(id) !== K.iconId) return drawIcon.apply(this, arguments);
        K.drawBadge(this, x, y, Window_Base._iconWidth * (Number(scale) || 1));
    };
    var bookIcon = Window_AchievementBookIndex.prototype.drawIcon;
    Window_AchievementBookIndex.prototype.drawIcon = function(id) {
        return Number(id) === K.iconId ? Window_Base.prototype.drawIcon.apply(this, arguments) : bookIcon.apply(this, arguments);
    };
    var bookDraw = Window_AchievementBookIndex.prototype.drawItem;
    Window_AchievementBookIndex.prototype.drawItem = function(index) {
        if (!this._list || !isKyo(this._list[index])) return bookDraw.apply(this, arguments);
        var rect = this.itemRectForText(index);
        K.drawBadge(this, rect.x + 8, rect.y + Math.max(0, (rect.height - 64) / 2), 64, K.owned() ? 255 : 80);
    };
    var popup = Star.Achievement.Window_AchievementPopup.prototype;
    var popupInitialize = popup.initialize, popupWidth = popup.windowWidth;
    popup.initialize = function(item) {
        if (isKyo(item)) this.item = item;
        var result = popupInitialize.apply(this, arguments);
        if (isKyo(item)) this.opacity = 0;
        return result;
    };
    popup.windowWidth = function() { return isKyo(this.item) ? 64 : popupWidth.apply(this, arguments); };
    var popupRefresh = popup.refresh, popupTitle = popup.drawTitle, popupMessage = popup.drawMessage;
    popup.refresh = function() {
        if (!isKyo(this.item)) return popupRefresh.apply(this, arguments);
        this.contents.clear();
        K.drawBadge(this, (this.contentsWidth() - 40) / 2, (this.contentsHeight() - 40) / 2, 40);
    };
    popup.drawTitle = function() { if (!isKyo(this.item)) return popupTitle.apply(this, arguments); };
    popup.drawMessage = function() { if (!isKyo(this.item)) return popupMessage.apply(this, arguments); };

    // Twelve seconds at the native 60 FPS: cool platinum to pale champagne.
    // Color is presentation only; the stored nickname and hero names are untouched.
    K.colors = function(frame) {
        var mix = (1 - Math.cos(Number(frame || 0) * Math.PI * 2 / 720)) / 2;
        function tint(a, b) {
            return 'rgb(' + a.map(function(v, i) { return Math.round(v + (b[i] - v) * mix); }).join(',') + ')';
        }
        return [tint([245,247,250], [247,239,220]), tint([164,182,207], [214,184,130])];
    };
    K.isPlayerSprite = function(sprite) {
        return !!($gamePlayer && sprite && (sprite._character === $gamePlayer ||
            ($gamePlayer.isInVehicle() && sprite._character === $gamePlayer.vehicle())));
    };
    K.updatePlayerName = function(sprite, force) {
        if (!K.isPlayerSprite(sprite) || !sprite._nameSpriteOL || !sprite._nameSpriteOL.bitmap) return false;
        var nameBitmap = sprite._nameSpriteOL.bitmap, name = String($gamePlayer.SaveActorName || '');
        var owned = K.owned(), step = Math.floor(Graphics.frameCount / 6);
        var signature = [owned, name, owned ? step : 0].join('|');
        if (!force && sprite._codexKyoNameSignature === signature) return false;
        var wasOwned = sprite._codexKyoNameOwned;
        sprite._codexKyoNameSignature = signature; sprite._codexKyoNameOwned = owned;
        if (!owned && !wasOwned) return false;
        // The native nameplate is 180×78: leave title and icon rows (0..53) intact.
        nameBitmap.clearRect(0, 54, 180, 22);
        if (!owned) {
            var previousColor = nameBitmap.textColor;
            nameBitmap.textColor = '#ffffff';
            try { nameBitmap.drawText(name, 0, 54, 180, 22, 'center'); }
            finally { nameBitmap.textColor = previousColor; }
            return true;
        }
        if (!name) return true;
        var ctx = nameBitmap._context, colors = K.colors(Graphics.frameCount);
        var baseline = 54 + 11 + nameBitmap.fontSize * 0.35;
        var gradient = ctx.createLinearGradient(0, baseline - nameBitmap.fontSize, 0, baseline);
        gradient.addColorStop(0, colors[0]); gradient.addColorStop(1, colors[1]);
        ctx.save();
        try {
            ctx.font = nameBitmap._makeFontNameText(); ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
            ctx.lineJoin = 'round'; ctx.lineWidth = nameBitmap.outlineWidth;
            ctx.strokeStyle = nameBitmap.outlineColor; ctx.shadowBlur = 0;
            ctx.strokeText(name, 90, baseline, 176);
            ctx.fillStyle = gradient; ctx.fillText(name, 90, baseline, 176);
        } finally { ctx.restore(); }
        nameBitmap._setDirty();
        return true;
    };
    var updateOther = Sprite_Character.prototype.updateOther;
    Sprite_Character.prototype.updateOther = function() {
        var result = updateOther.apply(this, arguments);
        K.updatePlayerName(this, false);
        return result;
    };
    var refreshDesignation = Star.Designation.RefUserDesignation;
    Star.Designation.RefUserDesignation = function() {
        var result = refreshDesignation.apply(this, arguments);
        var scene = SceneManager._scene, sprites = scene && scene._spriteset && scene._spriteset._characterSprites;
        if (sprites) sprites.forEach(function(sprite) { K.updatePlayerName(sprite, true); });
        return result;
    };
    return K;
});
