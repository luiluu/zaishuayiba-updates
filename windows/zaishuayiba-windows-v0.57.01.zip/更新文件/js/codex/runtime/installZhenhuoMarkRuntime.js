// v0.53.01：修复至尊宝「真火印记」（技能1089）追击不生效。
// 现状：印记（状态108）在目标受到火伤时只对「已经带有状态109」的我方成员重复 addState(109)，
// 而 YEP_BuffsStatesCore 对已存在的状态不会重跑 <Custom Apply Effect>，所以横扫千军（1090）从不触发；
// 另外旧 109 自动施法把 origin.index()（我方队位）当作敌方目标索引，多敌人时会打错目标。
// 本模块改为运行时直接实现该设计：印记目标受到火属性伤害时，由印记来源（持有1089的角色）追加一次
// 物理属性横扫千军1090，伤害为 60% + 每人物等级1%；独特技能（1083/1086）命中时附带/续期印记。
// 旧状态109的自动施法同时屏蔽，避免重复或错位出手。
// v0.53.03：追击目标按敌群完整队位（含已阵亡）传入，避免前面有敌人阵亡时打到别的敌人；追击本身不再触发追击。
window.CodexRuntime.register('installZhenhuoMarkRuntime', function () {
  'use strict';
  var W = window;
  if (W.__codexZhenhuoV05301) return W.__codexZhenhuoV05301;
  var MARK = 108, CHASE = 1090, PASSIVE = 1089, FIRE = 2, OLD_CHASE_STATE = 109;
  var UNIQUE = {1083: 1, 1086: 1};
  var Z = W.__codexZhenhuoV05301 = {version: 'v0.53.03', mark: MARK, chase: CHASE, runs: 0};
  function isOwner(u) {
    return !!(u && u.isActor && u.isActor() && (u._skills || []).indexOf(PASSIVE) >= 0);
  }
  function scaleOf(u) { return 0.6 + 0.01 * (Number(u && u.level) || 0); }
  Z.isOwner = isOwner;
  Z.scaleOf = scaleOf;
  Z.mark = function (target) {
    if (!target || !target.isAlive || !target.addState) return false;
    target.addState(MARK);
    if (target._stateTurns) target._stateTurns[MARK] = Math.max(Number(target._stateTurns[MARK]) || 0, 2);
    return target.isStateAffected(MARK);
  };
  // 旧“追击”状态：屏蔽自动施法，避免多敌人时按我方队位错打目标。
  var addState = Game_Battler.prototype.addState;
  Game_Battler.prototype.addState = function (stateId) {
    if (stateId === OLD_CHASE_STATE && this.isActor && this.isActor()) return;
    return addState.apply(this, arguments);
  };
  var apply = Game_Action.prototype.apply;
  Game_Action.prototype.apply = function (target) {
    var subject = this.subject(), item = this.item();
    var fire = !!(item && this.getItemElements && this.getItemElements().indexOf(FIRE) >= 0);
    var unique = !!(item && UNIQUE[item.id]);
    // 同一次行动按目标各记一次：本次行动开始前是否已有印记、本次行动是否已追击、是否已由本模块挂印记。
    var info = this._zhenhuoInfo = this._zhenhuoInfo || [];
    var slot = null;
    if (target) {
      for (var n = 0; n < info.length; n++) { if (info[n].target === target) { slot = info[n]; break; } }
      if (!slot) {
        slot = {target: target, markedBefore: !!(target.isStateAffected && target.isStateAffected(MARK)), chased: false, marked: false};
        info.push(slot);
      }
    }
    // 独特技能：本次行动第一次命中前先给目标挂印记（同一次多段不重复触发）。
    if (unique && fire && slot && !slot.marked && isOwner(subject)) {
      if (Z.mark(target)) slot.marked = true;
    }
    var out = apply.apply(this, arguments);
    try {
      if (!fire || !slot || !target || !target.isAlive || !subject || !subject.isActor || !subject.isActor()) return out;
      if (item && item.id === CHASE) return out;
      var result = target.result ? target.result() : null;
      var damage = result ? Number(result.hpDamage) || 0 : 0;
      if (damage <= 0 || !slot.markedBefore || slot.chased) return out;
      slot.chased = true;
      var owner = null, origin = target.stateOrigin ? target.stateOrigin(MARK) : null;
      if (origin && isOwner(origin)) owner = origin;
      if (!owner && isOwner(subject)) owner = subject;
      if (!owner || !W.$gameTroop) return out;
      // smoothTarget 按 members()（含已阵亡）取目标，所以要传完整队位。
      var index = W.$gameTroop.members().indexOf(target);
      if (index < 0 || !target.isAlive()) return out;
      BattleManager.queueForceAction(owner, CHASE, index);
      Z.runs++;
      Z.last = {owner: owner.actorId(), target: index, scale: scaleOf(owner)};
    } catch (e) {
      if (console && console.warn) console.warn('真火印记追击异常', e);
    }
    return out;
  };
  var makeDamageValue = Game_Action.prototype.makeDamageValue;
  Game_Action.prototype.makeDamageValue = function (target, critical) {
    var value = makeDamageValue.apply(this, arguments);
    var subject = this.subject(), item = this.item();
    if (item && item.id === CHASE && isOwner(subject) && !Z.noScale) {
      value = Math.max(1, Math.round(Number(value) * scaleOf(subject)));
    }
    return value;
  };
  return Z;
});
