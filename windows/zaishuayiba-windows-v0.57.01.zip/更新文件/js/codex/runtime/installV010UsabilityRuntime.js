// 【Codex·未经Claude检验】v0.24 移除主菜单一键存档入口，保留快存能力；未经claude检验。
// 【Codex·未经Claude检验】v0.10 操作与奖励修复；未经claude检验。
(function() {
 'use strict';
 CodexRuntime.register('installV010UsabilityRuntime', function() {
  if (window.CodexV010Fixes) return;
  var F=window.CodexV010Fixes={version:'v0.10'};
  function wrap(owner,key,fn) { var old=owner[key]; owner[key]=function(){return fn.call(this,old,arguments);}; }
  function newActor(actor) { return actor && actor.actorId()>=167 && actor.actorId()<=177; }
  // 【Codex·未经Claude检验】v0.26 check empty slots before character hooks spend resources.
  function actionHasItem(action){return !!(action&&action.item&&action.item());}
  wrap(BattleManager,'forceAction',function(old,args){
   var battler=args[0],action=battler&&battler.currentAction();
   if(!actionHasItem(action)){if(battler&&action)battler.removeCurrentAction();return;}
   var pending={battler:battler,times:battler._otbTimesActedThisTurn};
   var out=old.apply(this,args);this._codexPendingForcedEntry=pending;return out;
  });
  wrap(BattleManager,'processForcedAction',function(old,args){
   var forced=this._actionForcedBattler,pending=this._codexPendingForcedEntry;
   delete this._codexPendingForcedEntry;
   if(forced&&!actionHasItem(forced.currentAction())){
    if(forced.currentAction())forced.removeCurrentAction();
    if(pending&&pending.battler===forced)forced._otbTimesActedThisTurn=pending.times;
    this._actionForcedBattler=null;
    // Cancel before native processForcedAction can remove the restored actor's action.
    if(this.loadPreForceActionSettings)this.loadPreForceActionSettings();
    return;
   }
   return old.apply(this,args);
  });
  wrap(BattleManager,'startAction',function(old,args){
   var subject=this._subject,action=subject&&subject.currentAction();
   if(!actionHasItem(action)){
    // Native endAction advances OTB and restores a suspended forced-action context.
    this._action=null;
    return this.endAction();
   }
   return old.apply(this,args);
  });

  // 【Codex·未经Claude检验】v0.25 bind freeze follow-up to its actual caster.
  var freeze=window.CodexFreezeFollowup={};
  wrap(Game_Action.prototype,'applyGlobal',function(old,args){
   var item=this.item(),subject=this.subject();
   if(item&&item.id===6171&&DataManager.isSkill(item)&&subject&&subject.isActor&&subject.isActor())$gameTemp._codexFreezeCasterId=subject.actorId();
   return old.apply(this,args);
  });
  freeze.takeCaster=function(){
   var id=$gameTemp._codexFreezeCasterId;delete $gameTemp._codexFreezeCasterId;
   return id&&$gameActors?$gameActors.actor(id):null;
  };

  // Keep battle categories native. The menu tab must be visible even before
  // this actor learns their first cultivation skill.
  wrap(Window_SkillType.prototype,'makeCommandList',function(old,args) {
   old.apply(this,args);
   if (!newActor(this._actor)) return;
   this._list=this._list.filter(function(c){return !(c.symbol==='skill' && c.ext===6);});
   var index=this._list.findIndex(function(c){return c.symbol==='skill' && c.ext===4;});
   this._list.splice(index<0?Math.min(2,this._list.length):index,0,{name:$dataSystem.skillTypes[6],symbol:'skill',enabled:true,ext:6});
  });
  if (Game_Actor.prototype.addedSkillTypesForMenu) wrap(Game_Actor.prototype,'addedSkillTypesForMenu',function(old,args) {
   var list=old.apply(this,args).slice();
   if (newActor(this) && list.indexOf(6)<0) list.splice(Math.max(0,list.indexOf(4)),0,6);
   return list;
  });

  function hideHelp(scene) {
   if (scene._helpWindow && scene._helpWindow.hide) { scene._codexHelpSuppressed=true; scene._helpWindow.hide(); }
  }
  function targeting(scene) {
   return !!(scene._codexBulkContext || scene._codexBulkJob ||
    (scene._codexBulkNumberWindow && scene._codexBulkNumberWindow.visible) ||
    (scene._actorWindow && scene._actorWindow.visible));
  }
  function syncHelp(scene) {
   if (targeting(scene)) hideHelp(scene);
   else if (scene._codexHelpSuppressed && scene._itemWindow && scene._itemWindow.active) {
    scene._codexHelpSuppressed=false;
    if (scene._itemWindow.updateHelp) scene._itemWindow.updateHelp();
   }
  }
  wrap(Scene_ItemBase.prototype,'showSubWindow',function(old,args){hideHelp(this);return old.apply(this,args);});
  wrap(Scene_ItemBase.prototype,'hideSubWindow',function(old,args){var out=old.apply(this,args);syncHelp(this);return out;});
  [Scene_Item,Scene_Skill].forEach(function(Type) {
   wrap(Type.prototype,'update',function(old,args){var out=old.apply(this,args);syncHelp(this);return out;});
   wrap(Type.prototype,'activateItemWindow',function(old,args){var out=old.apply(this,args);syncHelp(this);return out;});
   wrap(Type.prototype,'useItem',function(old,args){var out=old.apply(this,args);syncHelp(this);return out;});
  });

  // Metadata stays outside the saved interpreter. Child common events share
  // the chest's receipt; ordinary rewards and battle drops retain their flow.
  var receipts=new WeakMap(),lastGains=new WeakMap();
  function chest(interpreter) {
   var event=$gameMap && $gameMap.event && $gameMap.event(interpreter._eventId);
   return event && event.characterName && event.characterName()==='BaoXiangGuai';
  }
  wrap(Game_Interpreter.prototype,'setup',function(old,args) {
   receipts.delete(this);lastGains.delete(this);
   var out=old.apply(this,args);
   if (this._eventId>0 && chest(this)) receipts.set(this,{owner:this,rows:new Map()});
   return out;
  });
  wrap(Game_Interpreter.prototype,'setupChild',function(old,args) {
   var out=old.apply(this,args),receipt=receipts.get(this);
   if (receipt && this._childInterpreter) receipts.set(this._childInterpreter,receipt);
   return out;
  });
  function escapeHTML(value) { return String(value).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
  function toast(message) { if (window.$ && $.toaster) $.toaster({message:message}); }
  F.awardQuantity=function(interpreter,kind,id,fallback) {
   var gain=lastGains.get(interpreter);
   return gain && gain.kind===kind && gain.id===id ? gain.amount : fallback;
  };
  F.rewardNotice=function(interpreter,message) { if (!receipts.has(interpreter)) toast(message); };
  [125,126,127,128].forEach(function(code) {
   var kind={125:'gold',126:'item',127:'weapon',128:'armor'}[code];
   wrap(Game_Interpreter.prototype,'command'+code,function(old,args) {
    var params=this._params || args[0],id=code===125?0:params[0];
    var data=code===125?null:({126:$dataItems,127:$dataWeapons,128:$dataArmors}[code])[id];
    var count=function(){return code===125?$gameParty.gold():(data?$gameParty.numItems(data):0);};
    var before=count(),out=old.apply(this,args),amount=Math.max(0,count()-before);
    lastGains.set(this,{kind:kind,id:id,amount:amount});
    var receipt=receipts.get(this);
    if (receipt && amount>0) {
     var key=kind+':'+id,row=receipt.rows.get(key);
     if (!row) {row={name:code===125?TextManager.currencyUnit:data.name,amount:0};receipt.rows.set(key,row);}
     row.amount+=amount;
    }
    return out;
   });
  });
  wrap(Game_Interpreter.prototype,'terminate',function(old,args) {
   var receipt=receipts.get(this),out=old.apply(this,args);
   receipts.delete(this);lastGains.delete(this);
   if (receipt && receipt.owner===this && receipt.rows.size) {
    var rows=[];receipt.rows.forEach(function(row){rows.push(escapeHTML(row.name)+' ×'+row.amount);});
    toast('宝箱收获：<br>'+rows.join('<br>'));
   }
   return out;
  });

  // Later save-protection plugins bypass YEP's WithoutRescue entry points.
  // Observe the final public entry points and only track successful operations.
  ['saveGame','loadGame'].forEach(function(key) {
   wrap(DataManager,key,function(old,args) {
    var slot=Number(args[0]),wasNew=$gameTemp && $gameTemp._autosaveNewGame;
    var previous=StorageManager.getCurrentAutosaveSlot && StorageManager.getCurrentAutosaveSlot();
    function restore() {
     if ($gameTemp) $gameTemp._autosaveNewGame=wasNew;
     if (StorageManager.setCurrentAutosaveSlot) StorageManager.setCurrentAutosaveSlot(previous);
    }
    function track(ok) {
     if (ok && Number.isInteger(slot) && slot>=1 && slot<=DataManager.maxSavefiles()) {
      $gameTemp._autosaveNewGame=false;
      if (StorageManager.setCurrentAutosaveSlot) StorageManager.setCurrentAutosaveSlot(slot);
     } else if (!ok) restore();
     return ok;
    }
    try {
     var result=old.apply(this,args);
     return result && typeof result.then==='function' ? result.then(track,function(error){restore();throw error;}) : track(result);
    } catch(error) {restore();throw error;}
   });
  });
  var Q=window.CodexQuickSave={version:'v0.10',busy:false};
  Q.canSave=function() {
   var scene=SceneManager._scene;
   return !Q.busy && !!(window.$gameSystem && $gameSystem.isSaveEnabled() && window.$gameParty &&
    !$gameParty.inBattle() && window.$gameMap && !$gameMap.isEventRunning() &&
    window.$gamePlayer && !$gamePlayer.isTransferring() && window.$gameMessage && !$gameMessage.isBusy() &&
    !SceneManager.isSceneChanging() && (scene instanceof Scene_Map || scene instanceof Scene_Menu) &&
    !document.getElementById('alien-workshop') && !document.getElementById('codex-feedback') &&
    !(window.CodexAndroidTouch && (CodexAndroidTouch.isOpen() || CodexAndroidTouch.isImportOpen())));
  };
  Q.run=function() {
   if (!Q.canSave()) return false;
   var scene=SceneManager._scene;
   var slot=StorageManager.getCurrentAutosaveSlot?Number(StorageManager.getCurrentAutosaveSlot()):Number(DataManager.lastAccessedSavefileId());
   if ($gameTemp._autosaveNewGame || !Number.isInteger(slot) || slot<1 || slot>DataManager.maxSavefiles()) {
    SceneManager.push(Scene_Save);return 'choose-slot';
   }
   Q.busy=true;
   var wasNew=$gameTemp._autosaveNewGame;
   function finish(ok) {
    Q.busy=false;
    if (ok) {SoundManager.playSave();toast('已保存到存档 '+slot+'。');}
    else {$gameTemp._autosaveNewGame=wasNew;SoundManager.playBuzzer();toast('存档失败，请通过存档菜单重试。');}
    if (SceneManager._scene===scene && scene._commandWindow) scene._commandWindow.activate();
    return !!ok;
   }
   try {
    $gameSystem.onBeforeSave();
    var result=DataManager.saveGame(slot);
    if (result && typeof result.then==='function') return result.then(finish,function(){return finish(false);});
    return finish(result);
   } catch(e) {console.error('Quick save failed',e);return finish(false);}
  };
  wrap(Scene_Base.prototype,'update',function(old,args) {
   var out=old.apply(this,args);
   if (Q.button) {var disabled=!Q.canSave();if(Q.button.disabled!==disabled)Q.button.disabled=disabled;}
   return out;
  });

  function bindWorkshop() {
   var root=document.getElementById('alien-workshop');
   if (!root || root._codexScrollBound) return;
   root._codexScrollBound=true;
   var drag=null,suppressClick=false;
   ['touchstart','touchmove','touchend','touchcancel'].forEach(function(type){root.addEventListener(type,function(e){e.stopPropagation();},{passive:true});});
   root.addEventListener('pointerdown',function(e) {
    suppressClick=false;
    if (e.pointerType!=='mouse' || e.button!==0 || e.target.closest('input,textarea,select')) return;
    var pane=e.target.closest('.alien-list') || e.target.closest('.alien-pane');
    if (pane) drag={id:e.pointerId,pane:pane,y:e.clientY,top:pane.scrollTop,moved:false};
   });
   root.addEventListener('pointermove',function(e) {
    if (!drag || e.pointerId!==drag.id) return;
    var distance=e.clientY-drag.y;
    if (!drag.moved && Math.abs(distance)<8) return;
    if (!drag.moved) {drag.moved=true;try{root.setPointerCapture(e.pointerId);}catch(e){/* Synthetic or released pointer. */}}
    drag.pane.scrollTop=drag.top-distance;suppressClick=true;e.preventDefault();
   });
   ['pointerup','pointercancel','lostpointercapture'].forEach(function(type){root.addEventListener(type,function(e){
    if (!drag || e.pointerId!==drag.id) return;
    var id=drag.id;drag=null;if(root.hasPointerCapture(id))root.releasePointerCapture(id);
   });});
   root.addEventListener('click',function(e){if(suppressClick){suppressClick=false;e.preventDefault();e.stopImmediatePropagation();}},true);
  }
  var workshop=window.CodexAlienation;
  if (workshop && workshop.openWorkshop) wrap(workshop,'openWorkshop',function(old,args){var out=old.apply(this,args);bindWorkshop();return out;});
  var style=document.createElement('style');
  style.textContent='#alien-workshop .alien-pane,#alien-workshop .alien-list{touch-action:pan-y;overscroll-behavior:contain;-webkit-overflow-scrolling:touch}#alien-workshop .alien-list{cursor:grab}#alien-workshop .alien-list:active{cursor:grabbing}#android-controls [data-quick]:disabled{opacity:.4}';
  document.head.appendChild(style);
 });
})();
