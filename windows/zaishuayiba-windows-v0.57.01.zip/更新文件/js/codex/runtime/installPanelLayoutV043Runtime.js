// 【Claude·未经Codex检验】v0.43 重做：装备／技能／物品说明统一排版，装备详情按整行翻页。
// 只整理显示副本：不改数据库、公式、数值、备注、存档和独立实例。须在 installDisplayPreferencesRuntime
// 与 installEquipmentDetailV041Runtime 之后安装。
window.CodexRuntime.register('installPanelLayoutV043Runtime', function() {
  'use strict';
  var W = window, D = W.CodexDisplay, P = W.ClaudePanel43 = { version: 43 };
  if (!D || !W.RJO || !RJO.SW || !RJO.HE) return P;

  // ---- 文字排版扩展：\col[N] 跳到本行 N% 处（两栏对齐），\rgb[N] 任意颜色（十进制 RRGGBB），
  // \lock[1] 之后本行忽略 \c[n]（属性名单独上色等），保证一行一种颜色 ----
  var esc = RJO.SW.processEscapeCharacter;
  RJO.SW.processEscapeCharacter = function(code, textState) {
    var m = /^(col|rgb|lock)\[(\d+)\]$/i.exec(String(code || ''));
    if (!m) {
      if (textState && textState.lock43 && /^c\[/i.test(String(code || ''))) return;
      return esc.apply(this, arguments);
    }
    if (m[1].toLowerCase() === 'lock') { if (textState.draw) textState.lock43 = true; return; }
    var n = Number(m[2]);
    if (m[1].toLowerCase() === 'col') {
      var x = textState.left + (textState.width - textState.left) * n / 100;
      textState.x = Math.max(x, textState.x + 12);
    } else if (textState.draw) {
      this.contents.textColor = '#' + ('00000' + n.toString(16)).slice(-6);
    }
  };

  var SIZE = { title: RJO.HE.ItemDescNameSize || 20, head: 17, body: 18, meta: 17, small: 15, gap: 4 };
  var COLOR = { meta: '#e3eaf3', tag: '#9fb3c8', flavor: '#a9b4c2', price: RJO.HE.ItemDescPriceColor || '#ffff00' };
  var ESC = /(?:\\|\x1b)c\[\d+\]/gi;
  function plain(t) { return String(t == null ? '' : t).replace(ESC, '').trim(); }
  function lead(t) { var m = String(t).match(/^(?:(?:\\|\x1b)c\[\d+\])+/i); return m ? m[0] : ''; }
  function rgb(c) {
    var s = String(c || '').replace(/\s/g, ''), m = /^rgba?\((\d+),(\d+),(\d+)/i.exec(s);
    if (m) return (Number(m[1]) << 16) + (Number(m[2]) << 8) + Number(m[3]);
    m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(s);
    if (!m) return 0xffffff;
    var h = m[1].length === 3 ? m[1].replace(/./g, '$&$&') : m[1];
    return parseInt(h, 16);
  }
  // 游戏内文字规则（AGENTS 第15条）：不显示通用的“防御按攻防比例结算”，标签统一用全角冒号。
  function tidy(t) {
    return String(t == null ? '' : t)
      .replace(/[；;，,]?\s*防御按攻防比例结算/g, '')
      .replace(/^((?:(?:\\|\x1b)c\[\d+\])*[^：:\s\\\x1b]{1,8}):/, '$1：');
  }
  function units(t) {
    var s = plain(t).replace(/(?:\\|\x1b)(?:col|rgb|lock)\[\d+\]/gi, ''), n = 0;
    for (var i = 0; i < s.length; i++) n += s.charCodeAt(i) > 0x2e80 ? 1 : 0.56;
    return n;
  }
  function row(text, size, color, align) { return [text, size, color || '#ffffff', false, align || 0]; }
  function spacer() { return [' ', SIZE.gap, '#000000', false, 0]; }

  var META = [
    /^(?:伤害属性|攻击属性)[：:]/, /^(?:目标|对象)[：:]/, /^(?:命中类型|命中)[：:]/, /^(?:能否暴击|暴击)[：:]/,
    /^(?:攻击次数|段数)[：:]/, /^(?:冷却时间|冷却|准备时间)[：:]/, /^(?:消耗|.{1,4}消耗)[：:]/, /^(?:武器限制)[：:]/,
    /^(?:纯粹伤害)[：:]/, /^分类[：:]/
  ];
  function metaRank(t) { for (var i = 0; i < META.length; i++) if (META[i].test(t)) return i; return -1; }
  var COND = /^(?:装备类型|武器类型|防具类型|装备位置|装备限制|等级需求|专属角色|使用角色|武器限制)[：:]/;
  var DROP = /^(?:纯粹伤害[：:]否|(?:武器|装备)限制[：:]无)$/;
  function bodyRank(t) {
    if (/^(?:基础)?伤害[：:]/.test(t)) return 0;
    if (/^(?:条件|限制|代价|时点)[：:]/.test(t)) return 2;
    if (/^成长[：:]/.test(t)) return 3;
    return 1;
  }
  function pairs(fields, size, color, width) {
    var max = Math.floor((width / 2 - 10) / size), out = [];
    for (var i = 0; i < fields.length; i++) {
      var a = fields[i], b = fields[i + 1];
      if (b !== undefined && units(a) <= max && units(b) <= max) { out.push(row(a + '\\col[50]' + b, size, color)); i++; }
      else out.push(row(a, size, color));
    }
    return out;
  }

  // item：已经过 characterHelpView（当前成长、费用、术语）的显示副本。width：绘制区域宽度。
  P.view = function(item, width) {
    if (!item || !Array.isArray(item.descParams) || item._claudePanel43) return item;
    var skill = item.stypeId !== undefined, gear = item.wtypeId !== undefined || item.atypeId !== undefined;
    if (!skill && !gear && item.itypeId === undefined) return item;
    width = Math.max(200, Number(width) || 392);
    var names = [0, 1, 2, 3, 4, 5, 6, 7].map(function(i) { return TextManager.param(i); });
    var title = null, quality = null, tags = [], params = [], meta = [], body = [], cond = [], flavor = [], price = [];
    item.descParams.forEach(function(src, index) {
      if (!Array.isArray(src)) return;
      var raw = tidy(src[0]), t = plain(raw);
      if (index === 0) { title = row(String(src[0] == null ? '' : src[0]), SIZE.title, src[2], 1); return; }
      if (!t) return;
      if (String(src[0]) === item.description || index === 1 && Number(src[1]) === RJO.HE.ItemDescSize) {
        var lines = String(src[0]).split(/\r?\n/).map(function(s) { return s.trim(); }).filter(Boolean);
        // 原作者的写法：说明第一行是类别（如“盔甲·轻甲”“被动”），其余是背景描述。
        if (lines.length > 1 && lines[0].length <= 8 && !/[。，！？,.!?：:]/.test(lines[0])) tags.push(lines.shift());
        if (lines.length) flavor.push(row(lines.join('\n'), SIZE.small, COLOR.flavor));
        return;
      }
      if (/^品质[：:]/.test(t)) { quality = src; return; }
      if (/^(?:购买价格|出售价格|无法出售)/.test(t)) { price.push(t); return; }
      if (t === '消耗品') { tags.push(t); return; }
      if (DROP.test(t)) return;
      if (gear) {
        var p = /^(.+?)[：:]\s*(-?\d+(?:\.\d+)?)$/.exec(t);
        if (p && !lead(src[0]) && names.indexOf(p[1]) >= 0 && Number(src[1]) <= RJO.HE.ItemDescOtherSize) { params.push({ name: p[1], value: p[2], color: src[2] }); return; }
        if (COND.test(t)) { cond.push(t); return; }
      }
      if (!gear) {
        var parts = t.split(/[；;](?=[^；;]{1,6}[：:])/), ranks = parts.map(metaRank);
        if (ranks.every(function(r) { return r >= 0; })) { parts.forEach(function(s, k) { meta.push({ text: s, rank: ranks[k], at: index * 10 + k }); }); return; }
      }
      // 每行一种颜色：保留行首颜色，去掉行中途插入的颜色（如属性名单独上色后变回白字）。
      var head = lead(raw), single = head + raw.slice(head.length).replace(ESC, '');
      body.push({ row: row(single, SIZE.body, src[2], Number(src[4]) || 0), rank: gear ? 1 : bodyRank(t), at: index, text: t });
    });
    // 已有“消耗：…”时去掉原生的“MP消耗：基础值”行；它不含减耗与按比例的部分。
    if (meta.some(function(m) { return /^消耗[：:]/.test(m.text); })) meta = meta.filter(function(m) { return !/^.{1,4}消耗[：:]\s*\d+$/.test(m.text) || /^消耗/.test(m.text); });
    // 装备：白字属性已在上方逐项列出时，去掉重复的“基础：…”汇总行。
    if (params.length) body = body.filter(function(b) { return !/^基础[：:]/.test(b.text); });
    meta.sort(function(a, b) { return a.rank - b.rank || a.at - b.at; });
    body.sort(function(a, b) { return a.rank - b.rank || a.at - b.at; });

    var blocks = [], head = [];
    if (title) head.push(title);
    if (quality || tags.length) {
      var label = (quality ? plain(quality[0]) : '') + (tags.length ? (quality ? '　' : '') + tags.join('·') : '');
      head.push(row(label, SIZE.head, quality ? quality[2] : COLOR.tag));
    }
    blocks.push(head);
    var grid = [];
    for (var i = 0; i < params.length; i += 2) {
      var cell = function(p) { return '\\rgb[' + rgb(p.color) + ']' + p.name + '：' + p.value; };
      grid.push(row(cell(params[i]) + (params[i + 1] ? '\\col[50]' + cell(params[i + 1]) : ''), SIZE.body, params[i].color));
    }
    blocks.push(grid);
    blocks.push(pairs(meta.map(function(m) { return m.text; }), SIZE.meta, COLOR.meta, width));
    blocks.push(body.map(function(b) { return b.row; }));
    blocks.push(pairs(cond, SIZE.meta, COLOR.meta, width));
    blocks.push(flavor);
    blocks.push(price.length ? pairs(price, SIZE.small, COLOR.price, width) : []);
    var rows = [];
    blocks.filter(function(b) { return b.length; }).forEach(function(b, n) { if (n) rows.push(spacer()); rows.push.apply(rows, b); });
    rows.forEach(function(r) { if (r[0] !== ' ' && !Number(r[4])) { var h = lead(r[0]); r[0] = h + '\\lock[1]' + String(r[0]).slice(h.length); } });
    var view = Object.assign({}, item);
    view.descParams = rows;
    view._claudePanel43 = true;
    return view;
  };

  // 说明浮窗与装备详情共用同一排版。宽度按当前绘制的窗口取。
  var width = 392;
  D.readableView = function(item) { return P.view(item, width); };
  if (W.Sprite_ItemHelp) ['getTextHeight', 'drawContents'].forEach(function(k) {
    var old = Sprite_ItemHelp.prototype[k];
    Sprite_ItemHelp.prototype[k] = function() {
      var saved = width; width = this.contentsWidth();
      try { return old.apply(this, arguments); } finally { width = saved; }
    };
  });

  // ---- 装备详情（装备界面右侧）----
  var E = W.CodexEquipment41, Detail = E && E.Detail;
  if (Detail) {
    var oldRows = Detail.prototype.rows41;
    Detail.prototype.rows41 = function() {
      var i = this._item41;
      if (!i || this._mode41 === 2) return oldRows.apply(this, arguments).filter(function(r) { return !/^说明较长时/.test(String(r[0])); });
      var v = Object.assign({}, i);
      v.params = (i.params || []).slice();
      RJO.HE.getDescParams(v, i.wtypeId !== undefined ? 1 : 2);
      if (v.descParams && v.descParams[0] && W.CodexQuality) v.descParams[0][0] = CodexQuality.starName(i);
      var shown = D.characterHelpView ? D.characterHelpView(v) : v;
      return P.view(shown, this.contentsWidth()).descParams;
    };
    // 先量每行高度再分页：放不下的行整行移到下一页顶部，翻页处不出现半行。
    Detail.prototype.render41 = function() {
      var rows = this.rows41(), w = this.contentsWidth(), viewH = this.contentsHeight(), tops = [], y = 0, page = 0;
      this.createContents();
      RJO.SW.setContent(this.contents, 0);
      rows.forEach(function(r, n) {
        RJO.SW.changeTextSize(Number(r[1]) || SIZE.body);
        RJO.SW.setupTextState(String(r[0] == null ? '' : r[0]), 0, 0, w, r[4]);
        var h = RJO.SW.textHeight;
        if (y > page && y + h > page + viewH) {
          page += viewH;
          y = page;
          if (r[0] === ' ') { tops.push(-1); return; }
        }
        tops.push(y);
        y += h;
      });
      var pages = page / viewH + 1, full = Math.max(1, y);
      this.contents = new Bitmap(w, Math.max(viewH, pages > 1 ? pages * viewH : full));
      RJO.SW.setContent(this.contents, 0);
      rows.forEach(function(r, n) {
        if (tops[n] < 0) return;
        RJO.SW.changeTextSize(Number(r[1]) || SIZE.body);
        RJO.SW.changeTextColor(r[2] || '#ffffff');
        RJO.SW.drawContentText(String(r[0] == null ? '' : r[0]), 0, tops[n], w, r[4]);
      });
      this._fullHeight41 = pages > 1 ? pages * viewH : full;
      this._pageTops43 = Array.from({ length: pages }, function(_, k) { return k * viewH; });
      this._pages41 = pages;
      this._page41 = 0;
      this.origin.y = 0;
      this.nav41();
    };
    Detail.prototype.maxScroll43 = function() { return Math.max(0, (this._fullHeight41 || 0) - this.contentsHeight()); };
    Detail.prototype.syncPage43 = function() {
      var tops = this._pageTops43 || [0], y = this.origin.y, p = 0;
      if (y >= this.maxScroll43() - 1) p = tops.length - 1;
      else for (var i = 0; i < tops.length; i++) if (tops[i] <= y + 2) p = i;
      this._page41 = p;
      this.nav41();
    };
    Detail.prototype.scroll41 = function(d) {
      this.origin.y = Math.max(0, Math.min(this.maxScroll43(), this.origin.y + d));
      this.syncPage43();
    };
    Detail.prototype.turn41 = function(n) {
      var tops = this._pageTops43 || [0], p = Math.max(0, Math.min(tops.length - 1, this._page41 + n));
      this.origin.y = Math.min(this.maxScroll43(), tops[p]);
      this._page41 = p;
      this.nav41();
    };
    // 底栏：只有一页时留空；多页时“▲ 上一页　页码　下一页 ▼”，点左半／右半翻页（原有触控逻辑）。
    Detail.prototype.nav41 = function() {
      var bar = this._nav41;
      if (!bar || !bar.contents) return;
      var c = bar.contents, w = bar.contentsWidth(), h = bar.contentsHeight(), p = this._page41 || 0, n = this._pages41 || 1;
      c.clear();
      if (n <= 1) return;
      c.fontSize = 20;
      bar.resetTextColor();
      bar.changePaintOpacity(p > 0);
      c.drawText('▲ 上一页', 0, 0, w / 3, h, 'left');
      bar.changePaintOpacity(true);
      c.drawText((p + 1) + '／' + n, w / 3, 0, w / 3, h, 'center');
      bar.changePaintOpacity(p < n - 1);
      c.drawText('下一页 ▼', w * 2 / 3, 0, w / 3, h, 'right');
      bar.changePaintOpacity(true);
    };

    // ---- 物品菜单：装备说明放进右侧固定区域，不再用浮窗盖住列表 ----
    var gear = function(i) { return !!i && (i.wtypeId !== undefined || i.atypeId !== undefined); };
    var itemDetail = function(s) { return s instanceof Scene_Item && s._detail43 && s._detail43.visible ? s._detail43 : null; };
    Scene_Item.prototype.gearShown43 = function() {
      var w = this._itemWindow;
      return !!(this._detail43 && w && w.visible && w.active && gear(w.item()));
    };
    Scene_Item.prototype.refreshGear43 = function() {
      if (!this._detail43) return;
      var on = this.gearShown43();
      this._tabs43.visible = this._nav43.visible = this._detail43.visible = on;
      if (this._infoWindow) this._infoWindow.visible = !on;
      if (!on) return;
      this._detail43.setEquipment(this._itemWindow.item());
      this._tabs43.setText(['装备详情', '插槽与镶嵌'].map(function(t, n) { return (n * 2 === this._mode43 ? '【' + t + '】' : t); }, this).join('　'));
    };
    Scene_Item.prototype.gearTab43 = function(mode) {
      this._mode43 = mode === 2 ? 2 : 0;
      this._detail43.setMode(this._mode43);
      this.refreshGear43();
    };
    var itemCreate = Scene_Item.prototype.create;
    Scene_Item.prototype.create = function() {
      var out = itemCreate.apply(this, arguments), w = this._infoWindow, bar = 58;
      if (!w) return out;
      this._mode43 = 0;
      this._tabs43 = new Window_Help(1); this._tabs43.move(w.x, w.y, w.width, bar); this._tabs43.createContents(); this.addWindow(this._tabs43);
      this._nav43 = new Window_Help(1); this._nav43.move(w.x, w.y + w.height - bar, w.width, bar); this._nav43.createContents(); this.addWindow(this._nav43);
      this._detail43 = new Detail(w.x, w.y + bar, w.width, Math.max(120, w.height - bar * 2)); this._detail43._nav41 = this._nav43; this.addWindow(this._detail43);
      this._tabs43.visible = this._nav43.visible = this._detail43.visible = false;
      return out;
    };
    var itemUpdate = Scene_Item.prototype.update;
    Scene_Item.prototype.update = function() {
      var out = itemUpdate.apply(this, arguments), d = this._detail43;
      if (!d) return out;
      this.refreshGear43();
      if (!d.visible) return out;
      var t = this._tabs43, n = this._nav43, x = TouchInput.x, y = TouchInput.y;
      if (Input.isTriggered('tab')) this.gearTab43(this._mode43 === 0 ? 2 : 0);
      if (TouchInput.isTriggered() && x >= t.x && x < t.x + t.width && y >= t.y && y < t.y + t.height) this.gearTab43(x < t.x + t.width / 2 ? 0 : 2);
      if (x >= d.x && x < d.x + d.width) {
        if (y >= d.y && y < d.y + d.height && Math.abs(TouchInput.wheelY) >= 1) d.scroll41(TouchInput.wheelY);
        if (TouchInput.isTriggered() && y >= n.y && y < n.y + n.height) d.turn41(x < n.x + n.width / 2 ? -1 : 1);
      }
      return out;
    };
    // 拖动详情区上下滚动；只在详情区内按下时接管，不影响列表和虚拟按键。
    var drag43 = null;
    var pt43 = function(e) { return { x: Graphics.pageToCanvasX(e.pageX), y: Graphics.pageToCanvasY(e.pageY) }; };
    var inside43 = function(d, p) { return p.x >= d.x && p.x < d.x + d.width && p.y >= d.y && p.y < d.y + d.height; };
    var eat43 = function(e) { if (e.cancelable) e.preventDefault(); e.stopImmediatePropagation(); TouchInput.clear(); };
    window.addEventListener('pointerdown', function(e) {
      var d = itemDetail(SceneManager._scene); if (!d || e.button > 0) return;
      var p = pt43(e); if (!inside43(d, p)) return;
      drag43 = { id: e.pointerId, y: p.y, moved: false };
    }, true);
    window.addEventListener('pointermove', function(e) {
      var d = itemDetail(SceneManager._scene); if (!drag43 || drag43.id !== e.pointerId || !d) return;
      var p = pt43(e), dy = p.y - drag43.y;
      if (!drag43.moved && Math.abs(dy) < 6) return;
      drag43.moved = true; d.scroll41(-dy); drag43.y = p.y; eat43(e);
    }, true);
    ['pointerup', 'pointercancel'].forEach(function(k) { window.addEventListener(k, function(e) { if (drag43 && drag43.id === e.pointerId) { if (drag43.moved) eat43(e); drag43 = null; } }, true); });
    // 物品菜单里的装备不再弹出浮窗。
    var helpSet = Sprite_ItemHelp.prototype.setItem;
    Sprite_ItemHelp.prototype.setItem = function(item) {
      var s = SceneManager._scene;
      if (!this._isExtra && s instanceof Scene_Item && s._helpWindow === this && s.gearShown43 && gear(item) && s._detail43) { this.item = item; this.hide(); return; }
      return helpSet.apply(this, arguments);
    };
  }
  return P;
});
