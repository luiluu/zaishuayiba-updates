// 【Codex·未经Claude检验】v0.12 奥恩材料统一更名为锻造锤；未经claude检验。
// 【Codex·未经Claude检验】v0.08 锻造预览显示当前层数；未经claude检验。
// Extracted from the verified native runtime; installer order is maintained by main.js.
window.CodexRuntime.register("installNativeLeviathanForge", function() {
  function installNativeLeviathanForge(H) {
    H.coreDropRate=0.20;
    var setup=BattleManager.setup;
    BattleManager.setup=function(){this._codexLeviathanCoreRolled=false;this._codexHeartsteelRewardRolled=false;return setup.apply(this,arguments);};
    // Both Unknown maps are shared by mortal and immortal routes.
    var mapSetup=Game_Map.prototype.setup;
    Game_Map.prototype.setup=function(mapId){
      var previous=this.mapId(),origin=this._codexLeviathanUnknownOrigin;
      var out=mapSetup.apply(this,arguments);
      if(mapId===152 || mapId===176)this._codexLeviathanUnknownOrigin=previous===mapId?origin:previous;
      else delete this._codexLeviathanUnknownOrigin;
      return out;
    };
    H.unknownHeartOrigin=function(){
      if($gameMap._codexLeviathanUnknownOrigin!=null)return Number($gameMap._codexLeviathanUnknownOrigin);
      // Native floor-13 portals send difficulty 107=1 to immortal map 38.
      return Number($gameVariables.value(107))===1?38:37;
    };
    H.unknownCoreOrigin=function(){
      if($gameMap._codexLeviathanUnknownOrigin!=null)return Number($gameMap._codexLeviathanUnknownOrigin);
      // Existing saves already inside map 176 predate the origin field.
      // Native entry events use difficulty variable 107=1 for map 164,
      // and 2/3 for map 165, which remains set on entry to the Unknown map.
      var difficulty=Number($gameVariables.value(107));
      return difficulty===1?164:(difficulty===2 || difficulty===3?165:0);
    };
    H.awardCore=function(result){
      var map=$gameMap.mapId(),troop=$gameTroop._troopId;
      if(result!==0 || map!==176 || [108,165].indexOf(H.unknownCoreOrigin())<0 ||
          [570,571,572,573,574,575].indexOf(troop)<0 || BattleManager._codexLeviathanCoreRolled)return false;
      BattleManager._codexLeviathanCoreRolled=true;
      if(Math.random()>=H.coreDropRate)return false;
      $gameParty.gainItem($dataItems[H.materialId],1,false);
      if(window.$ && $.toaster)$.toaster({message:'获得锻造材料：锻造锤！'});
      return true;
    };
    var endBattle=BattleManager.endBattle;
    BattleManager.endBattle=function(result){var out=endBattle.apply(this,arguments);H.clearReward(result);H.awardCore(result);return out;};
    H.ownedGear=function(){
      if(!$gameParty)return [];
      var items=$gameParty.armors().slice();
      $gameParty.allMembers().forEach(function(actor){items=items.concat(actor.equips().filter(H.isGear));});
      return items.filter(function(item,index){return H.isGear(item) && item.id>=DataManager._baseArmorsLength && items.indexOf(item)===index;});
    };
    H.forgeSources=function(){return H.ownedGear().filter(H.isHeart);};
    H.unlockForge=function(notify){
      if(!$gameParty)return;
      var was=!!$gameParty._codexLeviathanUnlocked;
      if(!was && !H.ownedGear().length)return;
      $gameParty._codexLeviathanUnlocked=true;
      $gameParty.learnRecipe(H.recipeId);
      if(!was && notify && window.$ && $.toaster)$.toaster({message:'已解锁打造配方：杰作利维坦'});
    };
    var oldGain=Game_Party.prototype.gainItem;
    Game_Party.prototype.gainItem=function(item,amount){
      var out=oldGain.apply(this,arguments);
      if(amount>0 && H.isGear(item) && this===$gameParty)H.unlockForge(true);
      return out;
    };
    var oldReset=Game_Party.prototype.resetKnownRecipes;
    Game_Party.prototype.resetKnownRecipes=function(){var out=oldReset.apply(this,arguments);if(this._codexLeviathanUnlocked)this.learnRecipe(H.recipeId);return out;};
    H.canForge=function(source){
      return !!($gameParty && !$gameParty.inBattle() && $gameParty._codexLeviathanUnlocked && H.isHeart(source) &&
        H.forgeSources().indexOf(source)>=0 && $gameParty.numItems($dataItems[2530])>=200 && $gameParty.numItems($dataItems[H.materialId])>=5);
    };
    H.previewForge=function(source){
      if(!H.isHeart(source))return null;
      var view=JsonEx.makeDeepCopy(source),base=$dataArmors[H.armorId],lev=$dataArmors[H.leviathanId];
      view.baseItemId=H.leviathanId;view.originalBaseItemId=H.leviathanId;
      for(var i=0;i<8;i++)view.params[i]+=lev.params[i]-base.params[i];
      view.name=view.name.replace('心之钢','杰作利维坦');
      if(view.baseItemName)view.baseItemName=view.baseItemName.replace('心之钢','杰作利维坦');
      view.iconIndex=lev.iconIndex;
      view.description=view.description.replace(base.description,lev.description);
      view.note=view.note.replace('<CodexHeartsteel>','<CodexLeviathan>');
      var rows=[['基础属性:生命+10000 物防+600 魔防+600','基础属性:生命+20000 物防+900 魔防+900'],
        ['特效:全局回合结束回复3%最大生命','特效:全局回合结束回复5%最大生命'],
        ['伤害:700＋6%有效最大生命；物理单体，不可暴击','伤害:1000＋8%有效最大生命；物理单体，不可暴击'],
        ['成长:有效造成生命伤害后，基础伤害的10%转为装备生命','成长:有效造成生命伤害后，基础伤害的12%转为装备生命']];
      rows.forEach(function(row){view.note=view.note.replace('text='+row[0]+' size=','text='+row[1]+' size=');});
      view.meta=JsonEx.makeDeepCopy(view.meta||{});delete view.meta.CodexHeartsteel;view.meta.CodexLeviathan=true;
      H.describe(view);
      return view;
    };
    function restoreItem(item,snapshot){Object.keys(item).forEach(function(k){delete item[k];});Object.keys(snapshot).forEach(function(k){item[k]=snapshot[k];});}
    H.forge=function(source){
      if(!H.canForge(source))return null;
      var preview=H.previewForge(source),snapshot=JsonEx.makeDeepCopy(source),fragments=$dataItems[2530],core=$dataItems[H.materialId];
      var f=$gameParty.numItems(fragments),n=$gameParty.numItems(core);
      try{
        // Transform the same ItemCore instance; no DreamX roll, new item,
        // equipment transfer, or second result can occur here.
        restoreItem(source,preview);
        $gameParty.loseItem(fragments,200,false);$gameParty.loseItem(core,5,false);
        if($gameParty.numItems(fragments)!==f-200 || $gameParty.numItems(core)!==n-5)throw new Error('Leviathan material transaction failed');
        $gameParty.allMembers().forEach(function(actor){if(actor.equips().indexOf(source)>=0){actor.need_refresh=true;actor.refresh();}});
      }catch(error){
        restoreItem(source,snapshot);
        $gameParty.gainItem(fragments,f-$gameParty.numItems(fragments),false);$gameParty.gainItem(core,n-$gameParty.numItems(core),false);
        throw error;
      }
      return source;
    };
    H.bindRecipe=function(){
      var recipe=window.$gameRecipes && $gameRecipes[H.recipeId];
      if(!recipe || recipe._codexLeviathanBound)return;
      recipe._codexLeviathanBound=true;
      var count=recipe.getMaterialCount;
      recipe.getMaterialCount=function(material){return material._type==='armor' && material._baseItemId===H.armorId?H.forgeSources().length:count.apply(this,arguments);};
      recipe.craftable=function(){return !!($gameParty && !$gameParty.inBattle() && $gameParty.recipeKnown(H.recipeId) && this.hasMaterials() && this.hasLevel());};
      recipe.amountCraftable=function(){return this.craftable()?1:0;};
      recipe.craft=function(){return H.forge(H._forgeSource);};
      H.unlockForge(false);
    };
    var oldRecipes=DataManager.createRecipes;
    DataManager.createRecipes=function(){var out=oldRecipes.apply(this,arguments);H.bindRecipe();return out;};
    H.bindRecipe();
    H.growthLabel='心钢层数';H.forgeGrowth=H.stacks;
    H.forgeDetailLines=function(source){return source?['品质、词条、心钢与强化进度完整保留','基础生命额外＋10000，双防各＋300','回合结束回复5%最大生命',H.damageText(H.previewForge(source)),'最大生命×'+H.helpNumber(1.1+0.1*H.stage(source))]:['选择一件心之钢，含已装备的实例','品质、词条与心钢层数完整继承'];};
    H.forgeHelpText=function(source,picking,shown){return source?'选择: '+source.name+'\n品质、词条、心钢层数及强化进度保留'+(picking?(shown?'；按 Shift 返回升级预览':'；按 Shift 查看词条'):''):'杰作利维坦：选择一件心之钢升级；消耗200人道意志碎片与5锻造锤';};
    function forgeAdapter(scene){var recipe=scene._listWindow && scene._listWindow.currentItem();return recipe && recipe._id===H.recipeId?H:recipe && window.CodexHubris && recipe._id===CodexHubris.recipeId?CodexHubris:null;}
    function isForgeScene(scene){return !!forgeAdapter(scene);} 
    H.patchCraftScene=function(sceneClass){
      var proto=sceneClass.prototype;
      while(proto && !Object.prototype.hasOwnProperty.call(proto,'craftSuccess'))proto=Object.getPrototypeOf(proto);
      if(!proto || proto._codexLeviathanScene)return;
      proto._codexLeviathanScene=true;
      var create=proto.create,update=proto.update,listSuccess=proto.listSuccess,cancel=proto.confirmCancel,craft=proto.craftSuccess;
      proto.create=function(){
        create.apply(this,arguments);var scene=this,list=this._listWindow;
        var picker=this._codexForgePicker=new Window_ItemList(list.x,list.y,list.width,list.height);
        var sourceHelp=this._codexForgeSourceHelp=new Sprite_ItemHelp(RJO.HE.ItemDescWidth);this.addChild(sourceHelp);
        this._codexShowSourceHelp=function(){
          var item=picker.item();if(!item)return;
          var view=JsonEx.makeDeepCopy(item);view.descParams=view.descParams.map(function(row){row[1]=Math.min(row[1],14);return row;});
          sourceHelp.x=scene._detailWindow.x;sourceHelp.y=scene._detailWindow.y;sourceHelp.setItem(view);
          scene._detailWindow.hide();
        };
        this._codexCloseSourceHelp=function(){sourceHelp.hide();scene._detailWindow.show();};
        picker.maxCols=function(){return 1;};picker.itemHeight=function(){return 72;};
        picker.makeItemList=function(){this._data=forgeAdapter(scene).forgeSources();};
        picker.isEnabled=function(item){return forgeAdapter(scene).canForge(item);};
        picker.drawItem=function(index){
          var item=this._data[index];if(!item)return;var rect=this.itemRect(index);
          this.contents.fontSize=22;this.changePaintOpacity(this.isEnabled(item));this.drawItemName(item,rect.x,rect.y,rect.width);
          this.contents.fontSize=18;this.resetTextColor();
          var equipped=$gameParty.allMembers().some(function(a){return a.equips().indexOf(item)>=0;});
          var quality=RJO.IQ.QualitiesName[Number(item.meta.quality)];
          this.drawText(quality+' · '+forgeAdapter(scene).growthLabel+':'+(forgeAdapter(scene).forgeGrowth||forgeAdapter(scene).growth)(item)+(equipped?' · 已装备':' · 背包'),rect.x,rect.y+32,rect.width);
          this.resetFontSettings();
        };
        picker.updateHelp=function(){scene._detailWindow.refresh();if(sourceHelp.visible)scene._codexShowSourceHelp();};
        picker.setHandler('ok',function(){
          var source=picker.item();if(!forgeAdapter(scene).canForge(source)){SoundManager.playBuzzer();picker.activate();return;}
          scene._codexCloseSourceHelp();
          forgeAdapter(scene)._forgeSource=source;scene._codexPicking=false;picker.deactivate();picker.hide();list.show();
          scene._confirmWindow.setRecipe(list.currentItem());scene._detailWindow.setRecipe(list.currentItem());listSuccess.call(scene);scene._detailWindow.refresh();
        });
        picker.setHandler('cancel',function(){
          if(sourceHelp.visible){scene._codexCloseSourceHelp();picker.activate();return;}
          forgeAdapter(scene)._forgeSource=null;scene._codexPicking=false;picker.deactivate();picker.hide();list.show();list.activate();scene._detailWindow.refresh();
        });
        picker.deactivate();picker.hide();this.addWindow(picker);
        var detail=this._detailWindow,refresh=detail.refresh;
        detail.refresh=function(){
          refresh.apply(this,arguments);
          if(!isForgeScene(scene))return;
          var source=scene._codexPicking?picker.item():forgeAdapter(scene)._forgeSource;
          this.contents.fontSize=18;this.resetTextColor();
          var y=224,lines=forgeAdapter(scene).forgeDetailLines(source);
          lines.forEach(function(text){detail.drawText(text,0,y,detail.contents.width);y+=25;});this.resetFontSettings();
        };
      };
      proto.listSuccess=function(){var scene=this;
        if(!isForgeScene(this))return listSuccess.apply(this,arguments);
        forgeAdapter(scene)._forgeSource=null;this._codexPicking=true;this._listWindow.deactivate();this._listWindow.hide();
        this._confirmWindow.deactivate();this.hideButtons();var picker=this._codexForgePicker;
        picker.refresh();picker.select(0);picker.show();picker.activate();this._detailWindow.refresh();
      };
      proto.update=function(){var scene=this;
        update.apply(this,arguments);
        if(isForgeScene(this)){
          var source=this._codexPicking?this._codexForgePicker.item():forgeAdapter(scene)._forgeSource;
          this._helpWindow.setText(forgeAdapter(scene).forgeHelpText(source,this._codexPicking,this._codexForgeSourceHelp.visible));
          if(this._codexPicking && this._codexForgePicker.active && Input.isTriggered('shift')){
            if(this._codexForgeSourceHelp.visible)this._codexCloseSourceHelp();else this._codexShowSourceHelp();
          }
        }
      };
      proto.confirmCancel=function(){var scene=this;if(forgeAdapter(scene))forgeAdapter(scene)._forgeSource=null;return cancel.apply(this,arguments);};
      proto.craftSuccess=function(){var scene=this;
        if(!isForgeScene(this))return craft.apply(this,arguments);
        var item=forgeAdapter(scene).forge(forgeAdapter(scene)._forgeSource);forgeAdapter(scene)._forgeSource=null;
        if(!item){SoundManager.playBuzzer();this.confirmCancel();return;}
        this.hideButtons();this._confirmWindow.deactivate();this._confirmWindow._amount=1;
        this._popupWindow.setText(item,1);this._listWindow.resetRecipes();this._detailWindow.refresh();
        if(this._goldWindow)this._goldWindow.refresh();this._popupWindow.activate();
      };
    };
    var push=SceneManager.push;
    SceneManager.push=function(sceneClass){
      if(sceneClass && /^Scene_Crafting/.test(sceneClass.name))H.patchCraftScene(sceneClass);
      return push.apply(this,arguments);
    };
  }


return installNativeLeviathanForge.apply(this, arguments);
});
