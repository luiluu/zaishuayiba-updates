// v0.52 一护／天剑特色化成长：读档时把 v0.52 之前就已打赢的剧情和剑道争锋补记到成长进度变量。
// 胜利分支都会打开事件独立开关A，所以独立开关A已开 = 已胜利；进度变量只补0→1，不会重复累加。
window.CodexRuntime.register('installStoryGrowthBackfillRuntime', function() {
  'use strict';
  var WINS = [[239, 1, 1579], [116, 11, 1580], [116, 12, 1581], [145, 9, 1582], [145, 10, 1583],
              [64, 11, 1584], [64, 12, 1585], [119, 19, 1586], [119, 20, 1587], [155, 25, 1588], [155, 26, 1589]];
  function backfill() {
    if (!window.$gameSelfSwitches || !window.$gameVariables) return 0;
    var n = 0;
    WINS.forEach(function(w) {
      if ($gameSelfSwitches.value([w[0], w[1], 'A']) && !Number($gameVariables.value(w[2]))) { $gameVariables.setValue(w[2], 1); n++; }
    });
    return n;
  }
  var extract = DataManager.extractSaveContents;
  DataManager.extractSaveContents = function(contents) {
    extract.call(this, contents);
    try { backfill(); } catch (e) { console.error('成长进度补记失败', e); }
  };
  return { version: 'v0.52', wins: WINS, backfill: backfill };
});
