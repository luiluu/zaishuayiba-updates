// 【Claude·未经Codex检验】v0.15 七档品质（2026-10-14）。核查状态：未经Codex检验。
// 【Claude·未经Codex检验】v0.16 用户要求旧档 13 Mod专属 移到不朽，神话只留 12 超·神器与 14／15 Mod。
// 【Claude·未经Codex检验】v0.17 用户要求神话用红色：神话红、不朽改金；边框神话用红色 Window10、不朽用金色 Window8。
// 【Claude·未经Codex检验】v0.18 列表名字颜色按七档：ItemColor 原按 <ici> 旧调色板画名字，与帮助卡的品质不一致。
// 【Claude·未经Codex检验】v0.19 存档里独立装备的旧帮助卡（旧品质名、旧颜色）在读档后与显示时刷新为七档。
// 【Claude·未经Codex检验】v0.17 神话档星级：超·神器★、神话特效★★（旧14）、混沌特效★★★（旧15）；名字后、帮助卡品质行与装备检索显示星级，排序先按七档再按旧档。
// 【Claude·未经Codex检验】v0.18 用户要求星级放到装备名字前面（列表与帮助卡名字行），帮助卡品质行与检索的品质文字不加星。
// 用户：神话保持稀有，在传说与神话之间加「不朽」过渡；人物品质不改数据。参考 Codex 未安装的六档候选（quality-six-v014）重做。
// 只改名称、颜色与帮助卡边框：旧 0～15 档的数值、装备实例、掉落、品阶倍率、排序先后与存档都不变。
// 旧档 → 七档：0粗糙/1普通→普通、2→优秀、3→精良、4→史诗、5神器/6传说/7传承→传说、8不朽/9传家宝/10远古/11太古/13 Mod专属→不朽、12超·神器/14神话Mod/15混沌Mod→神话。
window.CodexRuntime.register('installUnifiedQualityRuntime', function() {
  'use strict';
  var W = window;
  var Q = W.CodexQuality = {version: 4,
    names: ['普通', '优秀', '精良', '史诗', '传说', '不朽', '神话'],
    colors: ['rgba(235,240,247,1)', 'rgba(128,255,28,1)', 'rgba(57,185,255,1)', 'rgba(128,100,254,1)', 'rgba(255,160,64,1)', 'rgba(255,214,90,1)', 'rgba(255,72,60,1)'],
    // 帮助卡发光边框沿用原图：白、绿、蓝、紫、橙、金（不朽）、红（神话）
    windows: [1, 2, 3, 4, 7, 8, 10],
    itemGrades: [0, 0, 1, 2, 3, 4, 4, 4, 5, 5, 5, 5, 6, 5, 6, 6],
    // 人物原生品质名：1普通 2优秀 3精良 4史诗 5神圣 6不朽 7传说 10神话（12按10处理）
    actorGrades: {0: 0, 1: 0, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5, 7: 4, 8: 5, 9: 5, 10: 6, 12: 6},
    gearTags: {7: '传承', 9: '传家宝', 10: '远古', 11: '太古', 12: '超·神器', 13: 'Mod专属', 14: '神话特效', 15: '混沌特效'},
    // v0.17 神话档内的子分类（只用于装备）：旧14、15 来自随机词条「神话特效」「混沌神话特效」，强度差距大
    starMarks: {12: '★', 14: '★★', 15: '★★★'}};
  function num(v) { v = Number(v); return isFinite(v) ? v : 0; }
  Q.legacy = function(item) {
    if (!item) return 1;
    var m = item.meta || {}, q = m.quality;
    if (q === undefined) { var re = /<quality:\s*(\d+)>/gi, x; while ((x = re.exec(item.note || ''))) q = x[1]; }
    if (q === undefined) q = item.quality;
    q = Number(q);
    return isFinite(q) && q >= 0 ? Math.floor(q) : 1;
  };
  Q.grade = function(item) { var q = typeof item === 'number' ? item : Q.legacy(item); var g = Q.itemGrades[q]; return g === undefined ? (q >= 12 ? 6 : 0) : g; };
  Q.name = function(item) { return Q.names[Q.grade(item)]; };
  Q.color = function(item) { return Q.colors[Q.grade(item)]; };
  Q.members = function(grade) { var out = []; Q.itemGrades.forEach(function(g, q) { if (g === Number(grade)) out.push(q); }); return out; };
  Q.actorGrade = function(actor) { var raw = typeof actor === 'number' ? actor : num(actor && actor.meta && actor.meta.Actorquality); var g = Q.actorGrades[raw]; return g === undefined ? 0 : g; };
  Q.actorName = function(actor) { return Q.names[Q.actorGrade(actor)]; };
  Q.actorColor = function(actor) { return Q.colors[Q.actorGrade(actor)]; };
  Q.tags = function(item) {
    if (!item || !(DataManager.isWeapon(item) || DataManager.isArmor(item))) return [];
    var tags = [], t = Q.gearTags[Q.legacy(item)];
    if (t) tags.push(t);
    if (DataManager.isArmor(item) && Number(item.etypeId) === 17) tags.push('神武');
    return tags;
  };
  // 星级：传旧档数字时直接查表；传物品时只给武器、防具（技能、物品不加星）
  Q.stars = function(item) {
    if (typeof item === 'number') return Q.starMarks[item] || '';
    if (!item || !(DataManager.isWeapon(item) || DataManager.isArmor(item))) return '';
    return Q.starMarks[Q.legacy(item)] || '';
  };
  // 排序名次：先按七档，同档再按旧档细分（旧13 Mod专属属于不朽，排在神话★之后）
  Q.rank = function(item) { var q = typeof item === 'number' ? item : Q.legacy(item); return Q.grade(q) * 16 + q; };
  Q.subGrades = function() { return Object.keys(Q.starMarks).map(Number).sort(function(a, b) { return a - b; }).map(function(q) { return {legacy: q, label: Q.names[Q.grade(q)] + '：' + Q.starMarks[q] + Q.gearTags[q]}; }); };
  // 品质行只写档名与标签，不加星（v0.18）；星级在名字前面
  Q.label = function(item) { var t = Q.tags(item); return Q.name(item) + (t.length ? '（' + t.join('·') + '）' : ''); };
  Q.starName = function(item) { return item ? Q.stars(item) + item.name : ''; };

  // 原生 ItemQuality 与各模块都按旧档下标读名称／颜色：整张表换成七档对应值
  var names = Q.itemGrades.map(function(g) { return Q.names[g]; }), colors = Q.itemGrades.map(function(g) { return Q.colors[g]; });
  if (W.RJO && RJO.IQ) { RJO.IQ.QualitiesName = names; RJO.IQ.QualitiesColor = colors; }
  var params = PluginManager.parameters('ItemQuality');
  if (params) { params.QualitiesName = JSON.stringify(names); params.QualitiesColor = JSON.stringify(colors); }
  if (W.CodexQualityIcons) CodexQualityIcons.cache = {};

  // 帮助卡「品质」一行带上标签（装备）：品质：不朽（传家宝）
  function plain(v) { return String(v || '').replace(/\\c\[\d+\]/gi, ''); }
  Q.labelRows = function(item) {
    if (!item || !Array.isArray(item.descParams)) return item;
    var label = '品质：' + Q.label(item);
    item.descParams.forEach(function(row) { if (Array.isArray(row) && /^品质[：:]/.test(plain(row[0]))) row[0] = label; });
    return item;
  };
  if (W.RJO && RJO.HE && RJO.HE.getItemExtraDescParams2) {
    var extra = RJO.HE.getItemExtraDescParams2;
    RJO.HE.getItemExtraDescParams2 = function(item) { var out = extra.apply(this, arguments); Q.labelRows(item); return out; };
  }
  // 发光边框图按七档取代表图（只换 0～15 的品质图，其他窗口皮肤不动）
  if (W.Window_ItemHelp && Window_ItemHelp.prototype.loadWindowskin) {
    var skin = Window_ItemHelp.prototype.loadWindowskin;
    Window_ItemHelp.prototype.loadWindowskin = function(id) {
      var s = String(id);
      if (/^\d+$/.test(s) && num(s) <= 15) return skin.call(this, Q.windows[Q.grade(num(s))]);
      return skin.apply(this, arguments);
    };
  }

  // ---- 列表名字颜色 ----
  // ItemColor 排在 ItemQuality 之后，按 <ici> 旧调色板画名字；<ici> 与品质常不一致（斩月神话显示淡紫、梵风衣传说显示洋红）。
  // 在 ItemColor 的基础绘制入口按七档上色：所有经 YEP_ItemCore 的绘制链（含 Window_ItemList 已缓存的入口）都会走到这里。
  // 角色模块已临时指定颜色时（云裳天衣、传家宝法宝等）沿用其颜色；没有品质标记的照旧。战斗技能列表原版就是白字，不动。
  Q.hasQuality = function(item) { return !!item && ((item.meta && item.meta.quality !== undefined) || /<quality:\s*\d+>/i.test(item.note || '') || item.quality !== undefined); };
  // 神话装备在名字前加星（v0.17 加在后面，v0.18 改到前面）：只改这一次绘制里写名字的那一笔，item.name 本身不变
  function starScope(win, item, draw, args) {
    var s = Q.stars(item);
    if (!s) return draw.apply(win, args);
    var name = item.name, own = Object.prototype.hasOwnProperty.call(win, 'drawText'), text = win.drawText, done = false;
    win.drawText = function(t) {
      if (done || t !== name) return text.apply(this, arguments);
      done = true; var a = Array.prototype.slice.call(arguments); a[0] = s + t; return text.apply(this, a);
    };
    try { return draw.apply(win, args); } finally { if (own) win.drawText = text; else delete win.drawText; }
  }
  function gradeColorScope(win, item, draw, args) {
    if (!Q.hasQuality(item) || Object.prototype.hasOwnProperty.call(win, 'itemColor')) return starScope(win, item, draw, args);
    var color = Q.color(item);
    win.itemColor = function() { return color; };
    try { return starScope(win, item, draw, args); } finally { delete win.itemColor; }
  }
  if (W.Yanfly && Yanfly.Item && typeof Yanfly.Item.Window_Base_drawItemName === 'function') {
    var baseName = Yanfly.Item.Window_Base_drawItemName;
    Yanfly.Item.Window_Base_drawItemName = function(item) { return gradeColorScope(this, item, baseName, arguments); };
  }
  // 地图传送的掉落表同样按 <ici> 上色；其窗口类在插件闭包内，创建时给它的原型挂一次
  if (W.Scene_MapTransfer && Scene_MapTransfer.prototype.createEnemyInfoWindow) {
    var createInfo = Scene_MapTransfer.prototype.createEnemyInfoWindow;
    Scene_MapTransfer.prototype.createEnemyInfoWindow = function() {
      var out = createInfo.apply(this, arguments), P = this._enemyInfoWindow && Object.getPrototypeOf(this._enemyInfoWindow);
      if (P && typeof P.drawDropItem === 'function' && !P.drawDropItem.codexGradeColor) {
        var dropItem = P.drawDropItem;
        P.drawDropItem = function(drop) { return gradeColorScope(this, drop && drop.item, dropItem, arguments); };
        P.drawDropItem.codexGradeColor = true;
      }
      return out;
    };
  }

  // ---- 存档里的旧帮助卡 ----
  // 独立装备（随机词缀等生成的实例）的帮助卡文字与颜色在生成时写入存档，读档不重算：旧档会留着「品质：远古·不朽」和旧颜色。
  // 就地刷新：品质行换成七档名称与颜色；名字行（第1行、名字字号）换成现在的名字色；与旧名字同色的行（描述等按品质上色的行）换成现在的品质色。
  // 旧普通白色、旧传承黄色与帮助卡的效果白字、价格黄字同色，这两种只改描述行，效果行与价格行不动。其余行不动；不增删行。
  var FIXED = W.RJO && RJO.HE ? [RJO.HE.ItemDescNormalColor, RJO.HE.ItemDescPriceColor, RJO.HE.ItemDescConsumableColor, RJO.HE.SkillDescMPColor, RJO.HE.SkillDescTPColor] : [];
  Q.refreshRows = function(item) {
    if (!item || !Array.isArray(item.descParams) || !item.descParams.length || !Q.hasQuality(item) || !W.RJO || !RJO.HE) return item;
    var rows = item.descParams, head = rows[0], named = Array.isArray(head) && head[1] === RJO.HE.ItemDescNameSize;
    var oldColor = named ? head[2] : null, nameColor = RJO.HE.namecolor(item), lineColor = RJO.HE.normalcolor(item), label = '品质：' + Q.label(item);
    var recolor = oldColor !== null && oldColor !== lineColor, fixed = FIXED.indexOf(oldColor) >= 0;
    rows.forEach(function(row, i) {
      if (!Array.isArray(row)) return;
      if (/^品质[：:]/.test(plain(row[0]))) { row[0] = label; row[2] = lineColor; }
      else if (i === 0 && named) row[2] = nameColor;
      else if (recolor && row[2] === oldColor && (!fixed || row[0] === item.description)) row[2] = lineColor;
    });
    return item;
  };
  Q.refreshAllRows = function() { var n = 0; ['$dataWeapons', '$dataArmors', '$dataItems'].forEach(function(k) { (W[k] || []).forEach(function(o) { if (o && Array.isArray(o.descParams)) { Q.refreshRows(o); n++; } }); }); return n; };
  var extractSave = DataManager.extractSaveContents;
  DataManager.extractSaveContents = function() { var out = extractSave.apply(this, arguments); Q.refreshAllRows(); return out; };
  if (W.Sprite_ItemHelp && Sprite_ItemHelp.prototype.setItem) {
    var helpItem = Sprite_ItemHelp.prototype.setItem;
    Sprite_ItemHelp.prototype.setItem = function(item) { Q.refreshRows(item); return helpItem.apply(this, arguments); };
  }
  // v0.18 帮助卡名字行前加星：只在量高度与绘制时临时换上，结束即还原；存档里的行不改
  function starredHead(sprite, fn, args) {
    var item = sprite.item, s = Q.stars(item), rows = item && item.descParams, head = Array.isArray(rows) && rows[0];
    // 名字行按位置与字号认（改名加[锁定]后存储的名字行可能落后于 item.name）
    if (!s || !Array.isArray(head) || !W.RJO || !RJO.HE || head[1] !== RJO.HE.ItemDescNameSize || String(head[0]).indexOf(s) === 0) return fn.apply(sprite, args);
    var saved = head[0]; head[0] = s + saved;
    try { return fn.apply(sprite, args); } finally { head[0] = saved; }
  }
  if (W.Sprite_ItemHelp) ['getTextHeight', 'drawContents'].forEach(function(k) {
    var fn = Sprite_ItemHelp.prototype[k];
    if (typeof fn === 'function') Sprite_ItemHelp.prototype[k] = function() { return starredHead(this, fn, arguments); };
  });

  // ---- 按档批量操作：七档各自覆盖其旧档成员；原版没有提供的旧档不新增 ----
  function groupState(grade, allowed, read) { var ids = Q.members(grade).filter(allowed), n = ids.filter(read).length; return !ids.length ? null : n === 0 ? 'none' : n === ids.length ? 'all' : 'partial'; }
  Q.groupState = groupState;
  var ANY = function() { return true; };
  // 商店一键出售：原版提供旧档 0～14
  var ONEKEY = function(q) { return q <= 14; };
  if (W.Window_OnekeySellCommand && W.Scene_Shop) {
    Window_OnekeySellCommand.prototype.makeCommandList = function() { var that = this; Q.names.forEach(function(n, g) { if (Q.members(g).some(ONEKEY)) that.addCommand('出售' + n + '品质', 'codexGrade' + g); }); };
    var createSell = Scene_Shop.prototype.createShopOnekeySellWindow;
    if (createSell) Scene_Shop.prototype.createShopOnekeySellWindow = function() {
      var out = createSell.apply(this, arguments), scene = this;
      Q.names.forEach(function(_, g) { if (scene._ShopOnekeySellWindow) scene._ShopOnekeySellWindow.setHandler('codexGrade' + g, scene.sellUnifiedQuality.bind(scene, g)); });
      return out;
    };
    // 与原版相同：按装备备注里的品质匹配，跳过名字带「[锁定]」的装备
    Scene_Shop.prototype.sellUnifiedQuality = function(grade) {
      var scene = this, legacy = Q.members(grade).filter(ONEKEY);
      $gameParty.equipItems().slice().forEach(function(item) {
        if (item && item.meta && item.meta.quality !== undefined && legacy.indexOf(num(item.meta.quality)) >= 0 && String(item.name).indexOf('[锁定]') < 0) { scene._item = item; scene.doSell(1); }
      });
      this._item = null; this.OnekeySellDe(); this._goldWindow.refresh(); this._statusWindow.refresh();
    };
  }
  // 挂机自动出售：原版逐档 0～15；旧档开关原样保存，按七档显示「卖／不卖／部分」
  Q.autoConfig = function() { return ($gameParty && $gameParty._XdRsData_hangUp_SellWeapon) || {}; };
  Q.autoState = function(g) { var c = Q.autoConfig(); return groupState(g, ANY, function(q) { return !!c['quality' + q]; }); };
  Q.refreshAuto = function() { if (!W.XdRsData || !XdRsData.hangUp) return; var c = Q.autoConfig(); XdRsData.hangUp.SellWA = Q.itemGrades.map(function(_, q) { return c['quality' + q] ? q : null; }).filter(function(q) { return q !== null; }); };
  Q.autoSummary = function(ids) { ids = ids || []; return Q.names.map(function(n, g) { var s = groupState(g, ANY, function(q) { return ids.indexOf(q) >= 0; }); return s === 'none' || !s ? null : n + (s === 'partial' ? '（部分）' : ''); }).filter(Boolean); };
  if (W.Star_Window_SellWeapon) {
    var P = Star_Window_SellWeapon.prototype, refmake = P.RefmakeCommandList, status = P.booleanStatusText, ok = P.processOk;
    P.makeCommandList = function() { this.addCommand('卖出的回合(为0不卖出)', 'SellQuality'); var that = this; Q.names.forEach(function(n, g) { that.addCommand(n, 'qualityGrade' + g); }); };
    P.RefmakeCommandList = function() { if (/^qualityGrade/.test(this.currentSymbol() || '')) return; return refmake ? refmake.apply(this, arguments) : undefined; };
    if (status) P.booleanStatusText = function(symbol) { var m = /^qualityGrade(\d)$/.exec(symbol); if (!m) return status.apply(this, arguments); return {none: '不卖', all: '卖', partial: '部分'}[Q.autoState(num(m[1]))]; };
    if (ok) P.processOk = function() {
      var m = /^qualityGrade(\d)$/.exec(this.currentSymbol() || '');
      if (!m) return ok.apply(this, arguments);
      var g = num(m[1]), enable = Q.autoState(g) === 'none', c = $gameParty._XdRsData_hangUp_SellWeapon = $gameParty._XdRsData_hangUp_SellWeapon || {};
      Q.members(g).forEach(function(q) { c['quality' + q] = enable; });
      Q.refreshAuto(); this.refresh(); SoundManager.playOk();
    };
  }
  // 屏蔽装备：原版只提供旧档 0～7
  var PINGBI = function(q) { return q <= 7; };
  Q.blockState = function(g) { var a = ($gameSystem && $gameSystem._pingbiQuality) || []; return groupState(g, PINGBI, function(q) { return !!a[q]; }); };
  if (W.Window_PingbiCommands) {
    Window_PingbiCommands.prototype.makeCommandList = function() {
      var that = this;
      Q.names.forEach(function(n, g) { var s = Q.blockState(g); if (s) that.addCommand('屏蔽' + n + '装备 ' + {none: '关', all: '开', partial: '部分'}[s], 'quality' + g, true); });
    };
    Window_PingbiCommands.prototype.toggleQuality = function(g) {
      var a = $gameSystem._pingbiQuality = $gameSystem._pingbiQuality || [], enable = Q.blockState(g) === 'none';
      Q.members(g).filter(PINGBI).forEach(function(q) { a[q] = enable; });
      this.refresh();
    };
  }
  return Q;
});
