// v0.53.01：反击防护。部分敌人被替换/移除后仍可能作为反击发起者进入反击流程，
// 此时 Game_Action 无法解析其队伍索引，读取技能会报错并中断战斗。这里在进入反击前
// 判断发起者是否仍在敌方队伍中，不在则跳过本次反击，正常情况不受影响。
window.CodexRuntime.register('installCounterGuardRuntime', function () {
  'use strict';
  var W = window;
  if (W.__codexCounterGuardV05301) return W.__codexCounterGuardV05301;
  var G = W.__codexCounterGuardV05301 = {version: 'v0.53.01', skipped: 0};
  var manager = W.BattleManager;
  if (!manager || typeof manager.invokeCounterAttack !== 'function') return G;
  var original = manager.invokeCounterAttack;
  G.invokeCounterAttack = manager.invokeCounterAttack = function (subject, target) {
    if (!subject || !target) return;
    if (typeof target.isActor === 'function' && !target.isActor()) {
      var troop = W.$gameTroop;
      var members = troop && typeof troop.members === 'function' ? troop.members() : null;
      if (members && members.indexOf(target) < 0) {
        G.skipped++;
        return;
      }
    }
    return original.apply(this, arguments);
  };
  return G;
});
