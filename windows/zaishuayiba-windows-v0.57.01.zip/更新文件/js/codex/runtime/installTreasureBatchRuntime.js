// 【Codex·未经Claude检验】v0.29 藏宝图直接／批量使用与至臻装备闪光；未经claude检验。
window.CodexRuntime.register('installTreasureBatchRuntime',function(){
 'use strict';
 if(window.CodexTreasure)return window.CodexTreasure;
 var specs=[[212,117,1,10],[319,174,11,14],[320,175,15,18],[321,176,19,22],[322,177,23,25],[323,178,26,28],[324,179,29,32],[330,180,33,36],[331,181,37,40],[332,182,41,44],[336,183,45,48],[337,184,49,53],[338,185,54,57],[339,186,58,61],[340,187,62,65],[341,188,66,69],[342,189,1,10],[1679,1381,76,79],[1680,1382,80,83],[1681,1383,84,87],[1682,1384,88,91]],byId={},byEvent={},byRange={};
 specs.forEach(function(s){byId[s[0]]=s;byEvent[s[1]]=s;byRange[s[2]+':'+s[3]]=s;});
 var T=window.CodexTreasure={version:'v0.29',itemIds:specs.map(function(s){return s[0];}),current:null,lastResult:null,rareQueue:{},rareSerial:0,rareFrames:0};
 function stock(item){return Math.max(0,Math.floor(Number($gameParty.numItems(item))||0));}
 function supports(item){return !!(item&&DataManager.isItem(item)&&byId[item.id]&&(item.effects||[]).some(function(e){return e.code===44&&e.dataId===byId[item.id][1];}));}
 T.supports=supports;
 function nativeTable(s){var all=Star.RomGetItems.GameMapxy||[];return all.slice(s[2],s[3]+1).filter(function(row){return row&&row.item&&row.Armors&&row.Weapons&&row.Coms&&row.item.length&&row.Armors.length&&row.Weapons.length&&row.Coms.length;});}
 function initializeRolls(){
  var p=$gameParty,N=Star.RomGetItems;p.RomGet=p.RomGet||[];p.RomGetNum=p.RomGetNum||0;
  if(p.RomGet.length!==N.RomLength||p.RomGetNum>N.RomLengthRef){p.RomGet=[];for(var i=0;i<N.RomLength;i++)p.RomGet[i]=Math.floor(Math.random()*9999)+1;p.RomGetNum=0;}
 }
 // Keep the native reward roller, shared random stream, per-location rotation and
 // full independent-equipment generation. Only the coordinate gate is removed.
 var nativeRun=Star.RomGetItems.RunGetFun;
 Star.RomGetItems.RunGetFun=function(first,last){
  var key=first+':'+last,s=T.current&&byId[T.current.id];
  if(!s||s[2]!==first||s[3]!==last)s=byRange[key];
  if(!s)return nativeRun.apply(this,arguments);
  var item=$dataItems[s[0]],rows=nativeTable(s);if(!supports(item)||stock(item)<1||!rows.length)return false;
  var flags=$gameParty.GameMapxy=$gameParty.GameMapxy||{},row=rows.filter(function(r){return !flags[r.id];})[0];
  if(!row){rows.forEach(function(r){flags[r.id]=false;});row=rows[0];}
  initializeRolls();var copy=Object.assign({},row,{ItID:item.id});
  Star.RomGetItems.GetRomItem(copy);flags[row.id]=true;return true;
 };
 var setup=Game_Interpreter.prototype.setup;
 Game_Interpreter.prototype.setup=function(list){var out=setup.apply(this,arguments);this._codexTreasureSource=0;specs.some(function(s){if($dataCommonEvents[s[1]]&&list===$dataCommonEvents[s[1]].list){this._codexTreasureSource=s[0];return true;}return false;},this);return out;};
 var script=Game_Interpreter.prototype.command355;
 Game_Interpreter.prototype.command355=function(){var previous=T.current;if(this._codexTreasureSource)T.current=$dataItems[this._codexTreasureSource];try{return script.apply(this,arguments);}finally{T.current=previous;}};
 // The four native secondary outcomes are synchronous. Capture reservations per
 // map and complete them before the next map can use MV's single event slot.
 T.useOne=function(item){
  if(!supports(item)||stock(item)<1||$gameParty.inBattle()||$gameTemp.isCommonEventReserved())return false;
  var spec=byId[item.id],rows=nativeTable(spec);if(!rows.length)return false;
  var allowed={118:1,119:1,120:1,1377:1};if(rows.some(function(r){return r.Coms.some(function(id){return !allowed[id]||!$dataCommonEvents[id];});}))return false;
  var temp=$gameTemp,reserve=temp.reserveCommonEvent,own=Object.prototype.hasOwnProperty.call(temp,'reserveCommonEvent'),queue=[spec[1]],before=stock(item),previous=T.current;
  temp.reserveCommonEvent=function(id){queue.push(id);};T.current=item;
  try{
   for(var i=0;queue.length&&i<12;i++){
    var id=queue.shift();if(id!==spec[1]&&!allowed[id])throw new Error('藏宝图后续事件未完成：'+id);
    var runner=new Game_Interpreter();runner.setup($dataCommonEvents[id].list,0);runner.update();
    if(runner.isRunning())throw new Error('藏宝图事件尚未完成：'+id);
   }
   if(queue.length)throw new Error('藏宝图后续事件过多');
  }finally{T.current=previous;if(own)temp.reserveCommonEvent=reserve;else delete temp.reserveCommonEvent;}
  return stock(item)===before-1;
 };
 // Resolve the original series ID, not the shared quality tier or an affix name.
 var series=null;
 function seriesKey(item){
  if(!item)return '';
  var weapon=DataManager.isWeapon(item),armor=DataManager.isArmor(item);if(!weapon&&!armor)return '';
  if(!series){series={};[[$dataWeapons,'w'],[$dataArmors,'a']].forEach(function(group){group[0].forEach(function(base){if(base&&/^[“「"]?至臻/.test(base.name||''))series[group[1]+base.id]=true;});});}
  var key=(weapon?'w':'a')+Number(item.originalBaseItemId||item.baseItemId||item.id);return series[key]?key:'';
 }
 T.isPrestige=function(item){return !!seriesKey(item);};
 function rare(item,count){var key=seriesKey(item);if(!key||count<1)return;var r=T.rareQueue[key];if(!r)r=T.rareQueue[key]={name:item.name,iconIndex:item.iconIndex,count:0};r.count+=count;T.rareSerial+=count;}
 var independent=Game_Party.prototype.gainIndependentItem;
 Game_Party.prototype.gainIndependentItem=function(item,amount){
  var key=this===$gameParty&&amount>0&&DataManager.isNewItemValid(item)&&seriesKey(item),container=key&&this.itemContainer(item),before=container?Object.assign({},container):null;
  var out=independent.apply(this,arguments);
  if(key)(out||[]).forEach(function(created){var n=this.numItems(created)-(Number(before[created.id])||0);if(n>0)rare(created,n);},this);
  return out;
 };
 var gain=Game_Party.prototype.gainItem;
 Game_Party.prototype.gainItem=function(item,amount){var watch=this===$gameParty&&amount>0&&seriesKey(item)&&!DataManager.isIndependent(item),before=watch?this.numItems(item):0,out=gain.apply(this,arguments);if(watch)rare(item,Math.max(0,this.numItems(item)-before));return out;};
 function ensureNotice(scene){
  if(scene._codexPrestigeNotice)return scene._codexPrestigeNotice;
  var flash=new ScreenSprite();flash.setColor(255,219,130);flash.opacity=0;scene.addChild(flash);
  var width=Math.min(700,Graphics.boxWidth-24),win=new Window_Base(0,0,width,Window_Base.prototype.fittingHeight(4));win.x=(Graphics.boxWidth-width)/2;win.y=Math.max(12,Math.floor(Graphics.boxHeight*.12));win.visible=false;win.backOpacity=255;scene.addChild(win);
  return scene._codexPrestigeNotice={flash:flash,window:win,frames:0,flashFrames:0};
 }
 T.updateNotice=function(scene){
  if(!(scene instanceof Scene_Item||scene instanceof Scene_Map||scene instanceof Scene_Battle))return;
  var keys=Object.keys(T.rareQueue),ui=scene._codexPrestigeNotice;
  if(keys.length&&(!ui||ui.flashFrames<=0)){
   ui=ensureNotice(scene);var items=keys.map(function(k){return T.rareQueue[k];}),count=items.reduce(function(n,r){return n+r.count;},0);T.rareQueue={};ui.frames=150;ui.flashFrames=45;
   var win=ui.window;win.contents.clear();win.changeTextColor('#ffe28a');win.drawText('至臻现世 · 获得 '+count+' 件',0,0,win.contentsWidth(),'center');win.resetTextColor();
   items.slice(0,2).forEach(function(r,i){win.drawIcon(r.iconIndex,0,win.lineHeight()*(i+1));win.drawText(r.name+(r.count>1?' ×'+r.count:''),40,win.lineHeight()*(i+1),win.contentsWidth()-40);});
   if(items.length>2)win.drawText('另有 '+(items.length-2)+' 种至臻装备',0,win.lineHeight()*3,win.contentsWidth(),'center');win.visible=true;win.opacity=255;win.contentsOpacity=255;
  }
  if(!ui)return;ui.window.opacity=255;ui.window.backOpacity=255;
  if(ui.flashFrames>0){ui.flash.opacity=Math.floor(128*ui.flashFrames/45);ui.flashFrames--;}else ui.flash.opacity=0;
  if(ui.frames>0){ui.frames--;ui.window.contentsOpacity=Math.min(255,ui.frames*12);if(!ui.frames)ui.window.hide();}
 };
 [Scene_Map,Scene_Battle].forEach(function(type){var update=type.prototype.update;type.prototype.update=function(){var out=update.apply(this,arguments);T.updateNotice(this);return out;};});
 function notice(scene,text){if(scene._helpWindow&&scene._helpWindow.setText){scene._helpWindow.setText(text);scene._helpWindow.show();}}
 function Window_TreasureNumber(){this.initialize.apply(this,arguments);}
 Window_TreasureNumber.prototype=Object.create(Window_ShopNumber.prototype);Window_TreasureNumber.prototype.constructor=Window_TreasureNumber;
 Window_TreasureNumber.prototype.windowWidth=function(){return Math.min(500,Graphics.boxWidth-24);};
 Window_TreasureNumber.prototype.standardBackOpacity=function(){return 255;};
 Window_TreasureNumber.prototype.itemY=function(){return this.lineHeight()*2;};
 Window_TreasureNumber.prototype.buttonY=function(){return this.lineHeight()*5+this.standardPadding();};
 Window_TreasureNumber.prototype.maxDigits=function(){return String(this._max||1).length;};
 Window_TreasureNumber.prototype.cursorWidth=function(){return this.textWidth(String(this._max||1))+this.textPadding()*2;};
 Window_TreasureNumber.prototype.refresh=function(){this.contents.clear();this.resetFontSettings();var w=this.contentsWidth();this.changeTextColor(this.systemColor());this.drawText('使用藏宝图',0,0,w,'center');this.resetTextColor();this.drawItemName(this._item,0,this.lineHeight(),w);this.drawMultiplicationSign();this.drawNumber();this.drawText('持有 '+(this._max||0)+' 张',0,this.lineHeight()*3,w,'right');this.drawText('← / → ±1    ↑ / ↓ ±10',0,this.lineHeight()*4,w,'center');this.updateCursor();};
 Window_TreasureNumber.prototype.createButtons=function(){Window_ShopNumber.prototype.createButtons.call(this);var button=this._codexMaxButton=new Sprite_Button();button.bitmap=new Bitmap(88,40);button.bitmap.fillRect(0,0,88,40,'#293e53');button.bitmap.drawText('MAX',0,0,88,40,'center');button.setColdFrame(0,0,88,40);button.setHotFrame(0,0,88,40);button.x=(this.width-88)/2;button.y=this.buttonY()+64;button.setClickHandler(function(){this._number=this._max;this.refresh();}.bind(this));this.addChild(button);};
 Window_TreasureNumber.prototype.placeButtons=function(){var spacing=16,widths=this._buttons.map(function(b){return b._coldFrame.width;}),total=widths.reduce(function(n,w){return n+w;},0)+spacing*(widths.length-1),x=(this.width-total)/2;this._buttons.forEach(function(b,i){b.x=x;b.y=this.buttonY();x+=widths[i]+spacing;},this);};
 Window_TreasureNumber.prototype.update=function(){Window_ShopNumber.prototype.update.apply(this,arguments);this.showButtons();this.opacity=255;this.backOpacity=255;if(this.active&&Input.isTriggered('pagedown')){this._number=this._max;this.refresh();}};
 function quantity(scene){if(scene._codexTreasureNumber)return scene._codexTreasureNumber;var win=new Window_TreasureNumber(0,0,Window_Base.prototype.fittingHeight.call(scene._itemWindow,9));win.x=(Graphics.boxWidth-win.width)/2;win.y=(Graphics.boxHeight-win.height)/2;win.setHandler('ok',function(){begin(scene);});win.setHandler('cancel',function(){finish(scene,'取消');});win.hide();win.deactivate();scene.addWindow(win);return scene._codexTreasureNumber=win;}
 function closeQuantity(scene){var w=scene._codexTreasureNumber;if(w){w.hide();w.deactivate();}}
 function finish(scene,reason){
  var job=scene._codexTreasureJob;if(!job)return;scene._codexTreasureJob=null;closeQuantity(scene);
  T.lastResult={itemId:job.item.id,requested:job.requested||0,used:job.used,remaining:stock(job.item),prestige:T.rareSerial-job.initialRare,reason:reason};
  scene._itemWindow.refresh();scene._itemWindow.select(Math.min(job.index,Math.max(0,scene._itemWindow.maxItems()-1)));scene.activateItemWindow();
  if(scene._statusWindow&&scene._statusWindow.refresh)scene._statusWindow.refresh();
  notice(scene,job.used?'已使用 '+job.item.name+' ×'+job.used+'；剩余 '+stock(job.item)+' 张'+(T.lastResult.prestige?'；获得至臻装备 '+T.lastResult.prestige+' 件':'')+(reason==='完成'?'':'（'+reason+'）'):reason==='取消'?'已取消使用藏宝图':'藏宝图使用已停止：'+reason);
  Input.clear();TouchInput.clear();
 }
 function begin(scene){var job=scene._codexTreasureJob;if(!job||job.state!=='quantity')return;var n=Number(scene._codexTreasureNumber.number());if(!Number.isSafeInteger(n)||n<1||n>stock(job.item)){SoundManager.playBuzzer();return;}job.requested=n;job.state='using';closeQuantity(scene);scene.playSeForItem();Input.clear();TouchInput.clear();process(scene);}
 function process(scene){
  var job=scene._codexTreasureJob;if(!job||job.state!=='using'||SceneManager.isSceneChanging())return;
  if(Input.isTriggered('cancel')||TouchInput.isCancelled())return finish(scene,'已停止');
  var started=Date.now();
  for(var i=0;i<8&&Date.now()-started<8;i++){
   if(job.used>=job.requested)return finish(scene,'完成');
   if(stock(job.item)<1)return finish(scene,'库存不足');
   if($gameTemp.isCommonEventReserved()||$gameMessage.isBusy())return finish(scene,'请先完成当前事件');
   var toaster=window.$&&$.toaster;
   try{if(toaster)$.toaster=function(){};if(!T.useOne(job.item))return finish(scene,'当前无法继续使用');job.used++;}
   catch(e){console.error('藏宝图使用失败',e);return finish(scene,'本次使用中断');}
   finally{if(toaster)$.toaster=toaster;}
  }
  if(job.used>=job.requested)finish(scene,'完成');else notice(scene,'正在使用 '+job.item.name+'：'+job.used+' / '+job.requested+'；取消可停止');
 }
 var use=Scene_Item.prototype.useItem;Scene_Item.prototype.useItem=function(){var item=this.item();if(!supports(item))return use.apply(this,arguments);if(this._codexTreasureJob)return;if(stock(item)<1||$gameTemp.isCommonEventReserved()||$gameMessage.isBusy()){SoundManager.playBuzzer();return;}this._codexTreasureJob={item:item,index:this._itemWindow.index(),state:'quantity',used:0,initialRare:T.rareSerial};[this._itemWindow,this._categoryWindow,this._actorWindow,this._itemActionWindow].forEach(function(w){if(w)w.deactivate();});if(this._helpWindow)this._helpWindow.hide();var win=quantity(this);win.setup(item,stock(item),0);win.show();win.activate();};
 var activate=Scene_Item.prototype.activateItemWindow;Scene_Item.prototype.activateItemWindow=function(){if(this._codexTreasureJob)return;return activate.apply(this,arguments);};
 var update=Scene_Item.prototype.update;Scene_Item.prototype.update=function(){var out=update.apply(this,arguments);process(this);T.updateNotice(this);return out;};
 var stop=Scene_Item.prototype.stop;Scene_Item.prototype.stop=function(){if(this._codexTreasureJob)finish(this,'离开背包');return stop.apply(this,arguments);};
 var newGame=DataManager.setupNewGame;DataManager.setupNewGame=function(){var out=newGame.apply(this,arguments);T.rareQueue={};T.rareSerial=0;T.current=null;series=null;return out;};
 var extracted=DataManager.extractSaveContents;DataManager.extractSaveContents=function(){var out=extracted.apply(this,arguments);T.rareQueue={};series=null;return out;};
 T.numberClass=Window_TreasureNumber;return T;
});
