// 【Claude·未经Codex检验】v0.19 操作体验：物品说明框复用、消息提醒开关、手机按键避让与按钮显示；未经Codex检验。
(function() {
 'use strict';
 CodexRuntime.register('installV019UsabilityRuntime', function() {
  if (window.CodexV019) return;
  var U=window.CodexV019={version:'v0.19'};
  function wrap(owner,key,fn) { var old=owner[key]; owner[key]=function(){return fn.call(this,old,arguments);}; }

  // ---- 1. 物品说明框 ----
  // ItemQuality 每次换说明都新建4个发光窗口（每个约29张画布），技能书的附带说明框也每次新建。
  // 长时间上下翻背包会堆积大量画布和贴图。改为每个说明框固定4个发光窗口，换内容时重画同一批位图。
  var NativeGlow=window.Window_ItemHelp,NativeHelp=window.Sprite_ItemHelp;
  if (NativeGlow && NativeHelp && NativeHelp.prototype.drawBackground) {
   // 与 rpg_core 的 Window._refreshBack/_refreshFrame/_refreshCursor 相同，只是复用已有位图。
   function reuse(sprite,w,h) {
    var bitmap=sprite.bitmap;
    if (bitmap && bitmap._codexGlowOwned) { bitmap.resize(w,h); bitmap.clear(); return bitmap; }
    bitmap=new Bitmap(w,h); bitmap._codexGlowOwned=true; return bitmap;
   }
   NativeGlow.prototype._refreshBack=function() {
    var m=this._margin,w=this._width-m*2,h=this._height-m*2,bitmap=reuse(this._windowBackSprite,w,h);
    this._windowBackSprite.bitmap=bitmap;this._windowBackSprite.setFrame(0,0,w,h);this._windowBackSprite.move(m,m);
    if (w>0 && h>0 && this._windowskin) {
     var p=96;bitmap.blt(this._windowskin,0,0,p,p,0,0,w,h);
     for (var y=0;y<h;y+=p) for (var x=0;x<w;x+=p) bitmap.blt(this._windowskin,0,p,p,p,x,y,p,p);
     var tone=this._colorTone;bitmap.adjustTone(tone[0],tone[1],tone[2]);
    }
   };
   NativeGlow.prototype._refreshFrame=function() {
    var w=this._width,h=this._height,m=24,bitmap=reuse(this._windowFrameSprite,w,h);
    this._windowFrameSprite.bitmap=bitmap;this._windowFrameSprite.setFrame(0,0,w,h);
    if (w>0 && h>0 && this._windowskin) {
     var skin=this._windowskin,p=96,q=96;
     bitmap.blt(skin,p+m,0,p-m*2,m,m,0,w-m*2,m);bitmap.blt(skin,p+m,q-m,p-m*2,m,m,h-m,w-m*2,m);
     bitmap.blt(skin,p,m,m,p-m*2,0,m,m,h-m*2);bitmap.blt(skin,p+q-m,m,m,p-m*2,w-m,m,m,h-m*2);
     bitmap.blt(skin,p,0,m,m,0,0,m,m);bitmap.blt(skin,p+q-m,0,m,m,w-m,0,m,m);
     bitmap.blt(skin,p,q-m,m,m,0,h-m,m,m);bitmap.blt(skin,p+q-m,q-m,m,m,w-m,h-m,m,m);
    }
   };
   NativeGlow.prototype._refreshCursor=function() {
    var pad=this._padding,x=this._cursorRect.x+pad-this.origin.x,y=this._cursorRect.y+pad-this.origin.y;
    var w=this._cursorRect.width,h=this._cursorRect.height,m=4,x2=Math.max(x,pad),y2=Math.max(y,pad),ox=x-x2,oy=y-y2;
    var w2=Math.min(w,this._width-pad-x2),h2=Math.min(h,this._height-pad-y2),bitmap=reuse(this._windowCursorSprite,w2,h2);
    this._windowCursorSprite.bitmap=bitmap;this._windowCursorSprite.setFrame(0,0,w2,h2);this._windowCursorSprite.move(x2,y2);
    if (w>0 && h>0 && this._windowskin) {
     var skin=this._windowskin,p=96,q=48;
     bitmap.blt(skin,p+m,p+m,q-m*2,q-m*2,ox+m,oy+m,w-m*2,h-m*2);
     bitmap.blt(skin,p+m,p,q-m*2,m,ox+m,oy,w-m*2,m);bitmap.blt(skin,p+m,p+q-m,q-m*2,m,ox+m,oy+h-m,w-m*2,m);
     bitmap.blt(skin,p,p+m,m,q-m*2,ox,oy+m,m,h-m*2);bitmap.blt(skin,p+q-m,p+m,m,q-m*2,ox+w-m,oy+m,m,h-m*2);
     bitmap.blt(skin,p,p,m,m,ox,oy,m,m);bitmap.blt(skin,p+q-m,p,m,m,ox+w-m,oy,m,m);
     bitmap.blt(skin,p,p+q-m,m,m,ox,oy+h-m,m,m);bitmap.blt(skin,p+q-m,p+q-m,m,m,ox+w-m,oy+h-m,m,m);
    }
   };
   // 发光窗口：ItemQuality 在 drawBackground 里 new Window_ItemHelp(x,y,w,h,品质)。
   // 只在说明框画背景期间换成取池构造，其他时间仍是原构造。
   var glowOwner=null;
   function PooledGlow(x,y,width,height,quality) {
    var pool=glowOwner && glowOwner._codexGlowPool,win=pool && pool.pop();
    if (!win) { NativeGlow.apply(this,arguments); if (glowOwner) this._codexGlowOwner=glowOwner; return this; }
    win.loadWindowskin(quality);
    win.move(x,y,width,height);
    win.opacity=60;win.backOpacity=60;win.contentsOpacity=255;win.openness=255;win.visible=true;
    return win;
   }
   PooledGlow.prototype=NativeGlow.prototype;
   // 移除时放回本说明框的池（原来是丢弃）。
   NativeHelp.prototype.removeGlowWindows=function() {
    var list=this._glowWindows;
    if (!list) return;
    var pool=this._codexGlowPool||(this._codexGlowPool=[]);
    list.forEach(function(win) {
     if (win.parent) win.parent.removeChild(win);
     if (win._codexGlowOwner===this && pool.indexOf(win)<0) pool.push(win);
    },this);
    this._glowWindows=[];
   };
   wrap(NativeHelp.prototype,'drawBackground',function(old,args) {
    var previousOwner=glowOwner,previousCtor=window.Window_ItemHelp;
    glowOwner=this;window.Window_ItemHelp=PooledGlow;
    try { return old.apply(this,args); }
    finally { window.Window_ItemHelp=previousCtor;glowOwner=previousOwner; }
   });

   // 技能书的附带说明框：同一场景复用。
   var extraPool=null;
   function PooledHelp(width) {
    var help=extraPool && extraPool.pop();
    if (!help) { NativeHelp.apply(this,arguments); return this; }
    help.width=width;help.height=1;help.x=0;help.y=0;help.visible=false;help.item=null;help._isExtra=false;
    return help;
   }
   PooledHelp.prototype=NativeHelp.prototype;
   if (window.RJO && RJO.HE && RJO.HE.updateExtraHelpWindows) {
    var updateExtra=RJO.HE.updateExtraHelpWindows;
    RJO.HE.updateExtraHelpWindows=function(item,mainHelpWindow,scene) {
     if (!scene) return updateExtra.apply(this,arguments);
     var pool=scene._codexExtraHelpPool||(scene._codexExtraHelpPool=[]);
     (scene._extraHelpWindows||[]).forEach(function(win){if(pool.indexOf(win)<0)pool.push(win);});
     var previousPool=extraPool,previousCtor=window.Sprite_ItemHelp;
     extraPool=pool;window.Sprite_ItemHelp=PooledHelp;
     try { return updateExtra.apply(this,arguments); }
     finally { window.Sprite_ItemHelp=previousCtor;extraPool=previousPool; }
    };
   }
  }

  // ---- 1b. 回合顺序条：SV敌人头像每帧重建 ----
  // Olivia_BattleSysOTB 给SV敌人记下的是SV图名，却每帧拿普通图名比较，永远不相等，于是每帧重建头像；
  // 选敌时头像闪烁还要为每个新头像建染色画布，停在选敌越久越卡。改为用同一个名字比较；敌人变身换图仍会重建。
  if (window.Sprite_OTBTurnOrder) {
   Sprite_OTBTurnOrder.prototype.updateBattlerBitmap=function() {
    var b=this._battler;if(!b.isEnemy())return;
    var name=window.Imported && Imported.YEP_X_AnimatedSVEnemies && b.hasSVBattler()?b.svBattlerName():b.battlerName();
    if (this._battlerName!==name || this._battlerHue!==b.battlerHue()) {
     this._updateReady=false;this.removeChild(this._battlerSprite);this.createBattlerSprite();
    }
   };
  }

  // ---- 2. 消息提醒开关 ----
  // 只过滤自动弹出的提示；在菜单里操作得到的反馈、资源不足等提示照常显示。
  var NOTICE=U.notices=[
   {key:'race',name:'种族消息',hint:'种族祝福、猎物、血契、反攻等'},
   {key:'chest',name:'宝箱消息',hint:'开宝箱后的收获汇总'},
   {key:'zhenqi',name:'真气消息',hint:'真气精进、大圆满、降服灵根等'},
   {key:'points',name:'积分消息',hint:'肝帝积分、滑稽值、额外抽奖券'},
   {key:'drop',name:'掉落消息',hint:'副本Boss专属掉落、权能、锻造锤'},
   {key:'learn',name:'领悟消息',hint:'角色领悟新技能'},
   {key:'dungeon',name:'副本消息',hint:'副本完成、逃离、关闭挂机'},
   {key:'share',name:'共享消息',hint:'光环等技能共享、羁绊激活与失效'}
  ];
  ConfigManager.codexNotices={};
  var makeConfig=ConfigManager.makeData,applyConfig=ConfigManager.applyData;
  ConfigManager.makeData=function() {
   var data=makeConfig.apply(this,arguments),saved={};
   NOTICE.forEach(function(n){saved[n.key]=U.noticeOn(n.key);});
   data.codexNotices=saved;return data;
  };
  ConfigManager.applyData=function(data) {
   applyConfig.apply(this,arguments);
   var saved=data && data.codexNotices,next={};
   NOTICE.forEach(function(n){next[n.key]=!(saved && saved[n.key]===false);});
   this.codexNotices=next;
  };
  U.noticeOn=function(key){return !(ConfigManager.codexNotices && ConfigManager.codexNotices[key]===false);};
  U.classify=function(options) {
   var text=String(options && (options.message!=null?options.message:options.msg)||'');
   if (/^宝箱收获/.test(text)) return 'chest';
   if (/肝帝积分 *[+＋]|滑稽值 *[+＋]|抽奖券额外/.test(text)) return 'points';
   if (/专属掉落|权能掉落|获得锻造材料/.test(text)) return 'drop';
   if (/已领悟/.test(text)) return 'learn';
   if (/副本挑战完成|逃离副本|进入副本，关闭挂机/.test(text)) return 'dungeon';
   if (/^技能共享|^羁绊：/.test(text)) return 'share';
   var stack=String(new Error().stack||'');
   if (/installNativeRaceRuntime/.test(stack)) return 'race';
   if (/installNativeZhenqiRuntime/.test(stack)) return 'zhenqi';
   return null;
  };
  if (window.$ && $.toaster) {
   var toaster=$.toaster;
   $.toaster=function(options) {
    if (shareBuffer && options && /^技能共享：.+ 激活！$/.test(String(options.message||''))) return;
    var scene=SceneManager._scene,key=U.classify(options);
    if (key && !U.noticeOn(key) && !(scene instanceof Scene_MenuBase)) return;
    return toaster.apply(this,arguments);
   };
  }
  // 技能共享：原来每次刷新把全部共享技能逐条弹出（开战、换队、换装都会整串重播）。
  // 改为一次刷新只弹一条，只列这次新激活的技能；没有新增就不弹。
  var shareBuffer=null;
  if (window.Star && Star.SkillsShare && Star.SkillsShare.refreshAllSkills) {
   var refreshShare=Star.SkillsShare.refreshAllSkills;
   Star.SkillsShare.refreshAllSkills=function() {
    var outer=!shareBuffer,before=(Star.SkillsShare.lastSharedSkillIds||[]).slice();
    if (outer) shareBuffer=true;
    try { return refreshShare.apply(this,arguments); }
    finally {
     if (outer) {
      shareBuffer=null;
      var fresh=(Star.SkillsShare.lastSharedSkillIds||[]).filter(function(id){return before.indexOf(id)<0 && $dataSkills[id];});
      if (fresh.length && window.$ && $.toaster) $.toaster({message:'技能共享激活：'+fresh.map(function(id){return $dataSkills[id].name;}).join('、')});
     }
    }
   };
  }
  // 设置页：一个入口进入消息提醒；技能升级通告一并移进来。
  var skillNotice='codexSkillLevelNotice' in ConfigManager;
  wrap(Window_Options.prototype,'makeCommandList',function(old,args) {
   old.apply(this,args);
   var list=this._list.filter(function(c){return c.symbol!=='codexSkillLevelNotice';});
   var at=list.findIndex(function(c){return c.symbol==='codexFollow' || c.symbol==='codexCostumes';});
   list.splice(at<0?list.length:at,0,{name:'消息提醒',symbol:'codexNotices',enabled:true,ext:null});
   this._list=list;
  });
  wrap(Window_Options.prototype,'statusText',function(old,args) {
   if (this.commandSymbol(args[0])!=='codexNotices') return old.apply(this,args);
   var off=NOTICE.filter(function(n){return !U.noticeOn(n.key);}).length+(skillNotice && ConfigManager.codexSkillLevelNotice===false?1:0);
   return off?off+'项关闭':'全部显示';
  });
  wrap(Window_Options.prototype,'processOk',function(old,args) {
   if (this.commandSymbol(this.index())!=='codexNotices') return old.apply(this,args);
   SoundManager.playOk();SceneManager.push(Scene_CodexNotices);
  });
  ['cursorLeft','cursorRight'].forEach(function(key) {
   wrap(Window_Options.prototype,key,function(old,args){if(this.commandSymbol(this.index())!=='codexNotices')return old.apply(this,args);});
  });

  function Window_CodexNotices() { this.initialize.apply(this,arguments); }
  Window_CodexNotices.prototype=Object.create(Window_Command.prototype);
  Window_CodexNotices.prototype.constructor=Window_CodexNotices;
  Window_CodexNotices.prototype.initialize=function(y) {
   Window_Command.prototype.initialize.call(this,(Graphics.boxWidth-this.windowWidth())/2,y);
  };
  Window_CodexNotices.prototype.windowWidth=function(){return Math.min(760,Graphics.boxWidth-48);};
  Window_CodexNotices.prototype.numVisibleRows=function(){return this.maxItems();};
  Window_CodexNotices.prototype.makeCommandList=function() {
   NOTICE.forEach(function(n){this.addCommand(n.name,'toggle',true,n.key);},this);
   if (skillNotice) this.addCommand('技能升级通告','toggle',true,'skillLevel');
  };
  Window_CodexNotices.prototype.extOf=function(index){var c=this._list[index];return c?c.ext:null;};
  Window_CodexNotices.prototype.isOn=function(key){return key==='skillLevel'?ConfigManager.codexSkillLevelNotice!==false:U.noticeOn(key);};
  Window_CodexNotices.prototype.hintOf=function(key){
   if (key==='skillLevel') return '技能升级时右上角的通告';
   var n=NOTICE.find(function(x){return x.key===key;});return n?n.hint:'';
  };
  Window_CodexNotices.prototype.drawItem=function(index) {
   var rect=this.itemRectForText(index),key=this.extOf(index),on=this.isOn(key),status=90,name=170;
   this.resetFontSettings();this.resetTextColor();this.drawText(this.commandName(index),rect.x,rect.y,name);
   this.changeTextColor(this.systemColor());this.contents.fontSize=Math.max(16,this.standardFontSize()-6);
   this.drawText(this.hintOf(key),rect.x+name,rect.y,rect.width-name-status);
   this.resetFontSettings();this.changeTextColor(on?'#a9dfb7':this.textColor(8));
   this.drawText(on?'开':'关',rect.x+rect.width-status,rect.y,status,'right');this.resetTextColor();
  };
  Window_CodexNotices.prototype.toggleCurrent=function(value) {
   var key=this.extOf(this.index());if(!key)return;
   var next=value===undefined?!this.isOn(key):value;
   if (next===this.isOn(key)) return;
   if (key==='skillLevel') ConfigManager.codexSkillLevelNotice=next;
   else { if (!ConfigManager.codexNotices) ConfigManager.codexNotices={}; ConfigManager.codexNotices[key]=next; }
   SoundManager.playCursor();this.redrawItem(this.index());
  };
  Window_CodexNotices.prototype.cursorLeft=function(){this.toggleCurrent(false);};
  Window_CodexNotices.prototype.cursorRight=function(){this.toggleCurrent(true);};
  function Scene_CodexNotices() { this.initialize.apply(this,arguments); }
  Scene_CodexNotices.prototype=Object.create(Scene_MenuBase.prototype);
  Scene_CodexNotices.prototype.constructor=Scene_CodexNotices;
  window.Scene_CodexNotices=Scene_CodexNotices;
  Scene_CodexNotices.prototype.create=function() {
   Scene_MenuBase.prototype.create.call(this);
   var width=Math.min(760,Graphics.boxWidth-48);
   var top=Math.max(24,Math.round(U.visibleTop())+12);
   this._heading=new Window_Base((Graphics.boxWidth-width)/2,top,width,104);
   this._heading.contents.fontSize=24;this._heading.drawText('消息提醒',0,0,this._heading.contentsWidth());
   this._heading.contents.fontSize=18;this._heading.drawText('点选切换开／关。关闭后不再自动弹出；菜单里操作的结果和提示照常显示。',0,36,this._heading.contentsWidth());
   this.addWindow(this._heading);
   this._list=new Window_CodexNotices(top+116);
   this._list.setHandler('toggle',function(){this._list.toggleCurrent();this._list.activate();}.bind(this));
   this._list.setHandler('cancel',this.popScene.bind(this));
   this.addWindow(this._list);
  };
  Scene_CodexNotices.prototype.terminate=function(){Scene_MenuBase.prototype.terminate.call(this);ConfigManager.save();};

  // ---- 3. 手机：存档／更新按钮只在标题画面显示；伤害统计避开A/B键 ----
  function visibleRect(el) {
   if (!el || el.offsetParent===null) return null;
   var r=el.getBoundingClientRect();return r.width>0 && r.height>0?r:null;
  }
  // 屏幕上的虚拟按键 → 游戏坐标；没有手机按键时返回空。
  U.padRects=function() {
   var canvas=Graphics._canvas,controls=document.getElementById('android-controls');
   if (!canvas || !controls) return [];
   var c=canvas.getBoundingClientRect();if(!c.width||!c.height)return [];
   var sx=Graphics.width/c.width,sy=Graphics.height/c.height,out=[];
   document.querySelectorAll('#android-controls .actions button,#android-controls .original-actions button,.original-actions button').forEach(function(el) {
    var r=visibleRect(el);
    if (r) out.push({x:(r.left-c.left)*sx,y:(r.top-c.top)*sy,width:r.width*sx,height:r.height*sy});
   });
   return out;
  };
  U.visibleTop=function() {
   var canvas=Graphics._canvas;if(!canvas)return 0;
   var c=canvas.getBoundingClientRect();return c.height&&c.top<0?-c.top*Graphics.height/c.height:0;
  };
  function overlaps(a,b){return a.x<b.x+b.width && b.x<a.x+a.width && a.y<b.y+b.height && b.y<a.y+a.height;}
  if (window.Star_Record) {
   wrap(Star_Record.prototype,'initialize',function(old,args) {
    var out=old.apply(this,args);this._codexHome={x:this.x,y:this.y};this._codexPadTick=0;U.placeRecord(this);return out;
   });
   wrap(Star_Record.prototype,'update',function(old,args) {
    var out=old.apply(this,args);
    if (this._codexHome && --this._codexPadTick<=0) {this._codexPadTick=30;U.placeRecord(this);}
    return out;
   });
   // 与A/B键重叠时移到画面可见区域左上角；按键隐藏后回到原位。
   U.placeRecord=function(win) {
    var home=win._codexHome,rect={x:home.x,y:home.y,width:win.width,height:win.height};
    var blocked=U.padRects().some(function(r){return overlaps(rect,r);});
    var x=blocked?12:home.x,y=blocked?Math.round(U.visibleTop())+12:home.y;
    if (win.x!==x || win.y!==y) win.move(x,y,win.width,win.height);
   };
  }
  var titleOnly=window.AndroidPort?null:[];
  wrap(Scene_Base.prototype,'update',function(old,args) {
   var out=old.apply(this,args);
   if (titleOnly===null) {
    var list=[document.querySelector('#android-controls [data-tool]'),document.querySelector('#android-controls [data-content]')].filter(Boolean);
    if (list.length) titleOnly=list;else if (document.getElementById('android-controls')) titleOnly=[];
   }
   if (titleOnly && titleOnly.length) {
    var show=this instanceof Scene_Title;
    titleOnly.forEach(function(b){var want=show?'':'none';if(b.style.display!==want)b.style.display=want;});
   }
   return out;
  });
 });
})();
