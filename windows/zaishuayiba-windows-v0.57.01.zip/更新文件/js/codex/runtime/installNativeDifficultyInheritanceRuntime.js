// Extracted from the verified native runtime; installer order is maintained by main.js.
// 【Claude·未经Codex检验】v0.44 强弱分类统一读角色备注 <KyoTier>（CodexTier），强弱名单不再从公共事件里解析。
window.CodexRuntime.register("installNativeDifficultyInheritanceRuntime", function() {
  function installNativeDifficultyInheritanceRuntime() {
    // 【Codex·未经Claude检验】v0.25 fixed dungeon scaling has its own display name.
    var previousDifficultyName=Game_System.prototype.difficultyName;
    Game_System.prototype.difficultyName=function(){
      if(this.difficultyId()===1 && window.$gameMap && window.$dataMapInfos){
        var id=$gameMap.mapId(),seen={};
        while(id&&!seen[id]){seen[id]=true;var map=$dataMapInfos[id];if(!map)break;
          if(/深渊/.test(map.name||''))return '副本固定难度';
          id=map.parentId;
        }
      }
      return previousDifficultyName.apply(this,arguments);
    };

    var D=window.CodexDifficulty=window.CodexDifficulty||{};
    if (D._installed) return;
    D._installed=true;
    var roleSkills=[6216,6235,5968,5969,5970,5971,5972,5973];
    var tierPairs=[[5968,5969],[5970,5971],[5972,5973]];
    var roleEvents=[1443,1444,1445];
    var switches=[2496,2492,2491,2500,2494,2489,2487,2483];
    var baseSkills=[5561,5547,5548,5549,5562,5564,5564,5564];
    var managed=[],systemStates={},metadataSource=null;
    function learned(actor,id) { return !!(actor && actor.isLearnedSkill(id)); }
    function metadata() {
      if (!$dataSkills || metadataSource===$dataSkills) return;
      metadataSource=$dataSkills;managed=[];systemStates={};
      $dataSkills.forEach(function(skill) {
        if (!skill || !/^(?:轮回模式·|灭世挑战|(?:宝宝|简单|普通|困难|地狱|天灾)难度$|难度适应$|天道诅咒$)/.test(skill.name||'')) return;
        managed.push(skill.id);
      });
      // Honghuang's five selected curses are taught by event 1442. Preserve
      // the actual selected set from the save; never roll five new curses.
      var curseEvent=$dataCommonEvents && $dataCommonEvents[1442];
      if(curseEvent)curseEvent.list.forEach(function(command){
        if(command.code!==355 && command.code!==655)return;
        var match,re=/\.learnSkill\((\d+)\)/g;
        while((match=re.exec(command.parameters[0]))){
          var id=Number(match[1]);
          if($dataSkills[id] && managed.indexOf(id)<0)managed.push(id);
        }
      });
      managed.concat(roleSkills).forEach(function(id) {
        var skill=$dataSkills[id],match,re=/<Start(?:WT)?PushState(\d+):\s*100%>/gi;
        if (!skill) return;
        while ((match=re.exec(skill.note||''))) systemStates[Number(match[1])]=true;
      });
    }
    D.isSystemState=function(id) { metadata();return !!systemStates[id]; };
    function nativeIds(eventId,name) {
      var event=$dataCommonEvents && $dataCommonEvents[eventId];
      var text=event ? event.list.filter(function(c){return c.code===355||c.code===655;})
        .map(function(c){return c.parameters[0];}).join('\n') : '';
      var match=new RegExp('var\\s+'+name+'\\s*=\\s*(\\[[\\d,\\s]*\\])').exec(text);
      return match ? JSON.parse(match[1]) : [];
    }
    // 【Claude·未经Codex检验】v0.44 三档补强与强者压制都按同一份分类；公共事件里的名单也改为读这里。
    function strong(actor) { return CodexTier.isNonWeak(actor); }
    // 167 号以后的角色是在原生分类事件之后加入的，加入时直接按分类给强者／弱者压制。
    function lateActor(actor) { return actor.actorId()>=167 && !!CodexTier.tierOf(actor); }
    function profile() {
      metadata();
      var data=$gameActors && $gameActors._data;
      // Actor 1 is included by every native global difficulty/challenge event.
      // Read its existing object; do not instantiate or copy personal abilities.
      var source=data && data[1];
      if (!source && data) {
        source=data.filter(function(a){return a && a.actorId()<167 &&
          managed.some(function(id){return learned(a,id);});})[0];
      }
      var skills=source ? managed.filter(function(id){return learned(source,id);}) : [];
      var tiers=tierPairs.map(function(pair){return pair.some(function(id){return learned(source,id);});});
      var classification=learned(source,6216)||learned(source,6235);
      // Difficulty switches are persistent. _difficultyId can temporarily
      // change inside a dungeon and is not a substitute for challenge progress.
      if (!skills.length && $gameSwitches) {
        for (var i=switches.length-1;i>=0;i--) {
          if (!$gameSwitches.value(switches[i])) continue;
          skills.push(baseSkills[i]);
          if (i>=1 && i<=3) skills.push(5980);
          break;
        }
      }
      if ($gameSwitches) [2461,2462,2463].forEach(function(id,i){
        if ($gameSwitches.value(id)) tiers[i]=true;
      });
      if (!skills.length && !classification && !tiers.some(Boolean)) return null;
      return {skills:skills,tiers:tiers,classification:classification};
    }
    function dropState(actor,id) {
      if (!actor.isStateAffected(id)) return false;
      if (actor.removeStateCompletely) actor.removeStateCompletely(id);
      else actor.removeState(id);
      if (actor.isStateAffected(id)) actor.eraseState(id);
      return true;
    }
    D.syncActor=function(actor) {
      if (!actor || !actor.actorId || !$dataActors[actor.actorId()] ||
          !$dataActors[actor.actorId()].name) return false;
      var current=profile();
      if (!current || actor.actorId()===1) return false;
      var desired=current.skills.slice(),changed=false,id=actor.actorId();
      // Preserve native exceptions and the difference between each tier's
      // strong list, while the five explicitly classified new actors are strong.
      if (current.classification || lateActor(actor))
        desired.push(strong(actor)?6216:6235);
      tierPairs.forEach(function(pair,i) {
        if (!current.tiers[i] || nativeIds(roleEvents[i],'noSkillIds').indexOf(id)>=0) return;
        desired.push(strong(actor)?pair[1]:pair[0]);
      });
      managed.concat(roleSkills).forEach(function(skillId) {
        // Before the native strong/weak event has run, retain an explicitly
        // assigned classification without adding it to unrelated native actors.
        if ((skillId===6216||skillId===6235) && !current.classification && !lateActor(actor)) return;
        if (desired.indexOf(skillId)>=0) {
          if (!learned(actor,skillId)) {actor.learnSkill(skillId);changed=true;}
        } else if (learned(actor,skillId)) {actor.forgetSkill(skillId);changed=true;}
      });
      var kept={};
      managed.concat(roleSkills).forEach(function(skillId) {
        if (!learned(actor,skillId)) return;
        var match,re=/<Start(?:WT)?PushState(\d+):\s*100%>/gi;
        while ((match=re.exec($dataSkills[skillId].note||''))) kept[Number(match[1])]=true;
      });
      Object.keys(systemStates).forEach(function(key){
        var stateId=Number(key);
        if (!kept[stateId] && dropState(actor,stateId)) changed=true;
      });
      if (changed) {
        actor.need_refresh=true;
        if (actor.refreshPassiveSkillCache) actor.refreshPassiveSkillCache();
        if (actor.initPassiveCache) actor.initPassiveCache();
        if (actor.refreshPassiveCache) actor.refreshPassiveCache();
        actor.refresh();
      }
      return changed;
    };
    // 2026-10-07 补强名单统一（用户确认）：原版超强者与 141–166 在各档都拿强者补强。
    // 1443–1445 只在开启难度时发放一次，已有存档读档时按事件里的现行名单纠正原有角色。
    function syncNativeTier(actor) {
      var id=actor&&actor.actorId&&actor.actorId(),changed=false;
      if (!id || id>=167 || !$dataActors[id] || !$dataActors[id].name || !$gameSwitches) return false;
      // 2026-10-07 方案B：洪荒中的存档补上洪荒压制（新存档由 CE1445 发放）
      var hh=$dataSkills.filter(function(s){return s&&/<CodexHonghuangSuppress>/i.test(s.note||'');})[0];
      if (hh && $gameSwitches.value(2463) && !learned(actor,hh.id)) {actor.learnSkill(hh.id);changed=true;}
      tierPairs.forEach(function(pair,i) {
        if (!$gameSwitches.value([2461,2462,2463][i])) return;
        if (nativeIds(roleEvents[i],'noSkillIds').indexOf(id)>=0) return;
        var want=strong(actor)?pair[1]:pair[0];
        var other=want===pair[1]?pair[0]:pair[1];
        if (learned(actor,other)) {actor.forgetSkill(other);changed=true;}
        if (!learned(actor,want)) {actor.learnSkill(want);changed=true;}
      });
      if (changed) {
        actor.need_refresh=true;
        if (actor.refreshPassiveSkillCache) actor.refreshPassiveSkillCache();
        if (actor.initPassiveCache) actor.initPassiveCache();
        if (actor.refreshPassiveCache) actor.refreshPassiveCache();
        actor.refresh();
      }
      return changed;
    }
    D.syncNativeTier=syncNativeTier;
    var oldAdd=Game_Party.prototype.addActor;
    Game_Party.prototype.addActor=function(actorId) {
      if ($dataActors[actorId]) D.syncActor($gameActors.actor(actorId));
      return oldAdd.apply(this,arguments);
    };
    var oldExtract=DataManager.extractSaveContents;
    DataManager.extractSaveContents=function(contents) {
      oldExtract.call(this,contents);
      // Repair all existing later-added actors, including reserves. Characters
      // not yet instantiated will inherit when their normal recruitment runs.
      var data=$gameActors && $gameActors._data;
      if (data) data.forEach(function(actor,id){if (actor && id>=167) D.syncActor(actor);else if (actor) syncNativeTier(actor);});
    };
    var oldStart=BattleManager.startBattle;
    BattleManager.startBattle=function() {
      // A difficulty event may have changed the profile since recruitment.
      ($gameParty._actors||[]).forEach(function(id){
        if (id>=167 && $gameActors._data[id]) D.syncActor($gameActors._data[id]);
      });
      return oldStart.apply(this,arguments);
    };
  }


return installNativeDifficultyInheritanceRuntime.apply(this, arguments);
});
