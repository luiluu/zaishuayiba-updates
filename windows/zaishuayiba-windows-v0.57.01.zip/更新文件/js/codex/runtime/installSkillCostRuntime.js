// 【Claude·未经Codex检验】v0.15 技能减耗修复（2026-10-14）。核查状态：未经Codex检验。
// 玩家反馈「减技能消耗词条没生效」，分析见 09_玩家数据分析库/案例/C0004_减耗词条未生效。
// 1. 减耗缓存原来只在开战和打开状态页时重算：换装、学技能、状态变化后，技能页仍显示旧消耗，地图上施放也按旧值扣。
//    战斗外读消耗前按需重算（与状态页相同的 initPassiveCache＋refreshPassiveCache）；战斗内沿用原插件的开战重算与状态增量，不动。
// 2. 随机词缀合成按同名标签覆盖：底材自带的 ConsumeReduce 被词条值替换，帮助卡却两行都显示。改为相加；存档里已生成的实例读档时按备注修正。
// 3. 标签大小写：ConsumeReduceMF 这类写法按 Mf 识别（技能5909原来无效）。
// 4. 谷雨按最大MP比例收费的技能也吃通用减耗：谷雨模块调用 CodexSkillCost.applyConsumeReduce。
// 只修正结算与显示一致，不改任何装备、技能的减耗数值，叠加规则（相加、100%封顶）不变。
// 【Claude·未经Codex检验】v0.16（2026-10-14）5. 按最大MP比例收费的部分，合计减耗下限为−100%（挑战加耗最多×2）；见第5节。
window.CodexRuntime.register('installSkillCostRuntime', function() {
  'use strict';
  var W = window, C = W.CodexSkillCost = {version: 1};
  var CANON = {all: 'ConsumeReduceAll', mf: 'ConsumeReduceMf', zj: 'ConsumeReduceZj'};
  var TAG = /<\s*ConsumeReduce(All|Mf|Zj)\s*:\s*([^>]*)>/gi;
  function num(v) { var m = /([+-]?\d+(?:\.\d+)?)/.exec(String(v === undefined || v === null ? '' : v)); return m ? Number(m[1]) : 0; }
  function fmt(n) { return ' ' + (Math.round(n * 1000) / 1000) + '%'; }
  function canon(key) { var m = /^ConsumeReduce(All|Mf|Zj)$/i.exec(key || ''); return m ? CANON[m[1].toLowerCase()] : null; }

  // ---- 1. 战斗外按需重算减耗缓存 ----
  // 任何角色的装备、技能、状态或队伍成员变化都让全体失效：共享被动会进入队友的技能列表。
  var gen = 1, seen = typeof WeakMap === 'function' ? new WeakMap() : null;
  C.invalidate = function() { gen++; };
  function signature(a) {
    return gen + '|' + (a._skills || []).join(',') + '|' + (a._states || []).join(',') + '|' +
      (a._equips || []).map(function(e) { return e ? e._dataClass + ':' + e._itemId : ''; }).join(',');
  }
  C.ensure = function(a) {
    if (!seen || !a || !a.isActor || !a.isActor()) return;
    if (W.$gameParty && $gameParty.inBattle()) return;
    if (typeof a.initPassiveCache !== 'function' || typeof a.refreshPassiveCache !== 'function') return;
    var key = signature(a);
    if (seen.get(a) === key) return;
    seen.set(a, key);
    try { a.initPassiveCache(); a.refreshPassiveCache(); C.refreshCount = (C.refreshCount || 0) + 1; }
    catch (e) { seen.delete(a); console.error(e); }
  };
  function after(proto, name, fn) {
    var own = Object.prototype.hasOwnProperty.call(proto, name), old = proto[name];
    if (typeof old !== 'function') return;
    proto[name] = function() { var r = own ? old.apply(this, arguments) : Object.getPrototypeOf(proto)[name].apply(this, arguments); fn(this); return r; };
  }
  function before(proto, name, fn) {
    var own = Object.prototype.hasOwnProperty.call(proto, name), old = proto[name];
    if (typeof old !== 'function') return;
    proto[name] = function() { fn(this); return own ? old.apply(this, arguments) : Object.getPrototypeOf(proto)[name].apply(this, arguments); };
  }
  ['refresh', 'learnSkill', 'forgetSkill', 'eraseState', 'clearStates'].forEach(function(k) { after(Game_Actor.prototype, k, C.invalidate); });
  ['addActor', 'removeActor'].forEach(function(k) { after(Game_Party.prototype, k, C.invalidate); });
  ['skillMpCost', 'skillTpCost'].forEach(function(k) { before(Game_Actor.prototype, k, C.ensure); });

  // 与 dsPassiveSkill 的 skillMpCost／skillTpCost 同一算法：指定技能＋类型（1战技、2魔法）＋全体，相加后封顶100%。
  C.reduceRate = function(a, skill) {
    if (!a || !a.isActor || !a.isActor() || !skill) return 0;
    C.ensure(a);
    var c = a._passiveCache && a._passiveCache.consumeReduce;
    if (!c) return 0;
    var r = num(c.bySkill && c.bySkill[skill.id]) + num(c.all);
    if (skill.stypeId === 1) r += num(c.byType && c.byType.Zj);
    else if (skill.stypeId === 2) r += num(c.byType && c.byType.Mf);
    return Math.min(r, 100);
  };
  // 只给整笔按最大MP比例收费的运行时调用（目前是谷雨），所以下限同第5节。
  C.applyConsumeReduce = function(a, skill, cost) { return Math.floor(cost * (1 - Math.max(C.reduceRate(a, skill), C.PERCENT_FLOOR) / 100)); };

  // ---- 3. 标签大小写 ----
  function normalizeMeta(o) {
    if (!o || !o.meta) return 0;
    var n = 0;
    Object.keys(o.meta).forEach(function(k) {
      var c = canon(k);
      if (!c || c === k) return;
      o.meta[c] = o.meta[c] === undefined ? o.meta[k] : fmt(num(o.meta[c]) + num(o.meta[k]));
      delete o.meta[k]; n++;
    });
    return n;
  }
  C.normalizeDatabase = function() {
    var n = 0;
    ['$dataSkills', '$dataWeapons', '$dataArmors', '$dataStates'].forEach(function(k) { (W[k] || []).forEach(function(o) { n += normalizeMeta(o); }); });
    return n;
  };
  var onLoad = DataManager.onLoad;
  DataManager.onLoad = function(object) {
    var r = onLoad.apply(this, arguments);
    if (Array.isArray(object)) object.forEach(normalizeMeta);
    return r;
  };
  if (W.$dataSkills) C.normalizeDatabase();

  // ---- 2. 词缀合成相加 ----
  var D = W.DreamX && DreamX.RandomPrefixSuffix;
  if (D && typeof D.combineWithBaseItem === 'function') {
    var combine = D.combineWithBaseItem;
    D.combineWithBaseItem = function(affix, item) {
      var prior = {};
      if (affix && affix.meta && item && item.meta) {
        normalizeMeta(item);
        Object.keys(item.meta).forEach(function(k) { if (canon(k) === k) prior[k] = item.meta[k]; });
      }
      var r = combine.apply(this, arguments);
      if (affix && affix.meta && item && item.meta) {
        Object.keys(affix.meta).forEach(function(k) {
          var c = canon(k);
          if (c && prior[c] !== undefined) item.meta[c] = fmt(num(prior[c]) + num(affix.meta[k]));
        });
        normalizeMeta(item);
      }
      return r;
    };
  }
  // 存档里已生成的实例：备注里同一标签出现多次、元数据只等于最后一个，就是被覆盖的实例，改为各次相加。
  C.mergeInstance = function(o) {
    if (!o || !o.meta || typeof o.note !== 'string') return false;
    var seenKeys = {}, m, changed = false;
    TAG.lastIndex = 0;
    while ((m = TAG.exec(o.note))) {
      var c = CANON[m[1].toLowerCase()], s = seenKeys[c] || (seenKeys[c] = {count: 0, sum: 0, last: 0});
      s.count++; s.sum += num(m[2]); s.last = num(m[2]);
    }
    normalizeMeta(o);
    Object.keys(seenKeys).forEach(function(c) {
      var s = seenKeys[c];
      if (s.count < 2 || o.meta[c] === undefined || num(o.meta[c]) !== s.last || s.sum === s.last) return;
      o.meta[c] = fmt(s.sum); changed = true;
    });
    return changed;
  };
  C.mergeSavedInstances = function() {
    var n = 0;
    [['$dataWeapons', DataManager._baseWeaponsLength], ['$dataArmors', DataManager._baseArmorsLength]].forEach(function(p) {
      var list = W[p[0]] || [], start = Number(p[1]) || 0;
      for (var i = start; i < list.length; i++) if (list[i] && list[i].baseItemId && C.mergeInstance(list[i])) n++;
    });
    C.mergedOnLoad = n;
    return n;
  };
  var extractSave = DataManager.extractSaveContents;
  DataManager.extractSaveContents = function() {
    var r = extractSave.apply(this, arguments);
    C.mergeSavedInstances(); C.invalidate();
    return r;
  };

  // ---- 5. v0.16 按最大MP比例收费的部分：挑战加耗下限 ----
  // 【Claude·未经Codex检验】玩家反馈「米拉蓝耗过高」（09_玩家数据分析库 案例C0005）。
  // 挑战惩罚的「技能消耗+X%」是负减耗，和其他减耗相加后没有下限（灭世挑战【神罚】−600%，可叠到消耗×7）。
  // 固定消耗乘7影响很小；按最大MP比例收费的技能跟着最大MP一起放大，米拉、渡鸦部分技能超过最大MP，永远放不出。
  // 只对「最大MP×%」这部分把合计减耗的下限定为−100%（最多×2）；固定部分、TP、正向减耗与100%封顶都不变。
  // 做法：同一技能按原减耗、按下限各算一次（其余乘区如禁忌×0.75、鬼族减耗照常），再按最大MP部分所占比例合成。
  C.PERCENT_FLOOR = -100;
  C.percentShare = function(a, skill) {
    var per = Number(skill && skill.mpCostPer) || 0;
    if (per <= 0 || !a) return 0;
    var pct = Number(a.mmp) * per, flat = Math.max(0, Number(skill.mpCost) || 0);
    return pct > 0 ? pct / (pct + flat) : 0;
  };
  var flooring = [];
  (function() {
    var proto = Game_Actor.prototype, own = Object.prototype.hasOwnProperty.call(proto, 'skillMpCost'), old = proto.skillMpCost;
    var call = function(self, args) { return own ? old.apply(self, args) : Object.getPrototypeOf(proto).skillMpCost.apply(self, args); };
    proto.skillMpCost = function(skill) {
      if (!skill || flooring.indexOf(this) >= 0) return call(this, arguments);
      var share = C.percentShare(this, skill), r = share > 0 ? C.reduceRate(this, skill) : 0;
      var c = this._passiveCache && this._passiveCache.consumeReduce;
      if (share <= 0 || r >= C.PERCENT_FLOOR || !c) return call(this, arguments);
      flooring.push(this);
      try {
        var full = call(this, arguments), saved = c.all, floored;
        c.all = num(saved) + (C.PERCENT_FLOOR - r);
        try { floored = call(this, arguments); } finally { c.all = saved; }
        return Math.max(0, Math.floor(floored + (full - floored) * (1 - share)));
      } finally { flooring.splice(flooring.indexOf(this), 1); }
    };
  })();
  return C;
});
