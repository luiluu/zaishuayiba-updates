//=============================================================================
// main.js
//=============================================================================
// 启动稳定性修复：原版这里把同步的 PluginManager.setup 当作 Promise
// 等待，实际仅固定延时 600ms 便进入 Scene_Boot。项目启用了大量插件，
// 首次启动、机械硬盘或安全软件扫描时会导致插件未加载完就开始游戏，表现
// 为随机白屏、长时间无反馈或偶发启动报错。
(function() {
  'use strict';

  var expected = 0;
  var loaded = 0;
  var failed = [];
  var setupFinished = false;
  var started = false;
  var timeoutId = null;
  var overlay;
  var progress;

  function createLoadingOverlay() {
    document.body.style.background = '#10131c';
    overlay = document.createElement('div');
    overlay.id = 'codex-startup-loading';
    overlay.style.cssText = [
      'position:fixed', 'inset:0', 'z-index:2147483647',
      'display:flex', 'flex-direction:column', 'align-items:center',
      'justify-content:center', 'background:#10131c', 'color:#d9e5ff',
      'font:20px sans-serif', 'letter-spacing:1px'
    ].join(';');
    overlay.innerHTML = '<div style="font-size:30px;margin-bottom:16px">游戏正在加载</div>' +
      '<div id="codex-startup-progress" style="color:#8fb5ff">正在初始化插件…</div>' +
      '<div style="margin-top:18px;width:360px;height:4px;background:#293247">' +
      '<div id="codex-startup-bar" style="width:0;height:100%;background:#75a7ff;transition:width .12s"></div></div>';
    document.body.appendChild(overlay);
    progress = document.getElementById('codex-startup-progress');
  }

  function updateProgress() {
    if (!progress) return;
    var count = Math.min(loaded + failed.length, expected);
    progress.textContent = '正在加载插件 ' + count + ' / ' + expected;
    var bar = document.getElementById('codex-startup-bar');
    if (bar) bar.style.width = (expected ? (count / expected * 100) : 0) + '%';
  }

  function showFailure(message) {
    if (!overlay) return;
    var detail = failed.length ? ('\n失败文件：' + failed.join('、')) : '';
    overlay.innerHTML = '<div style="font-size:28px;color:#ffb4b4;margin-bottom:16px">启动未完成</div>' +
      '<div style="max-width:780px;white-space:pre-wrap;text-align:center;line-height:1.7">' +
      String(message).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') + detail +
      '\n请完全退出后重试；若仍出现，请截图此页面。</div>';
  }

  // 插件加载完到进标题之间出错时，引擎的报错画面在遮罩下面看不到，玩家只会看到停在「正在加载插件」。
  // 遮罩还在时：普通报错写到遮罩上；资源读取失败时撤掉遮罩，露出引擎自带的「重试」。
  function showBootErrors() {
    var printError = Graphics.printError, printLoadingError = Graphics.printLoadingError;
    Graphics.printError = function(name, message) {
      if (overlay && overlay.parentNode) showFailure('游戏启动时出错：' + name + ' ' + message);
      return printError.apply(this, arguments);
    };
    Graphics.printLoadingError = function() {
      if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
      return printLoadingError.apply(this, arguments);
    };
  }

  function removeOverlayWhenReady() {
    var originalStart = Scene_Boot.prototype.start;
    Scene_Boot.prototype.start = function() {
      originalStart.apply(this, arguments);
      window.setTimeout(function() {
        if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
      }, 0);
    };
  }

  function installNativeRavenRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNativeRavenRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installNativeMiraRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNativeMiraRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installMiraRavenNumberBoostRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installMiraRavenNumberBoostRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installNativeRavenMonsterVisual() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNativeRavenMonsterVisual"].concat(Array.prototype.slice.call(arguments))); }
  function installNanohaSharedKillRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNanohaSharedKillRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installQiyuDimensionRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installQiyuDimensionRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installStrongActorClassificationRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installStrongActorClassificationRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installItemBagContinuationRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installItemBagContinuationRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installNativeYomiJingliuRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNativeYomiJingliuRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installNativeTojiRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNativeTojiRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installNativeDifficultyInheritanceRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNativeDifficultyInheritanceRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installNativeBlackFlashRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNativeBlackFlashRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installNativeSkillProgressionRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNativeSkillProgressionRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installNativeCharacterVisualRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNativeCharacterVisualRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installNativeHeartsteelRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNativeHeartsteelRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installNativeLeviathanForge() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNativeLeviathanForge"].concat(Array.prototype.slice.call(arguments))); }
  function installNativeHubrisRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNativeHubrisRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installNativeSukunaRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNativeSukunaRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installNativeGarouRuntime() { return window.CodexRuntime.install.apply(window.CodexRuntime, ["installNativeGarouRuntime"].concat(Array.prototype.slice.call(arguments))); }
  function installImportedBalanceRuntime() { return window.CodexRuntime.install("installImportedBalanceRuntime"); }
  function installBulkPillsRuntime() { return window.CodexRuntime.install("installBulkPillsRuntime"); }

  function tryStart() {
    if (started || !setupFinished || loaded + failed.length !== expected) return;
    if (failed.length) {
      showFailure('有插件文件未能加载，游戏未启动以避免白屏或数据异常。');
      return;
    }
    if (!Utils.canReadGameFiles()) {
      showFailure('无法读取游戏文件。请勿从压缩包内直接运行，并确认游戏目录有读写权限。');
      return;
    }
    try {
      installNativeRavenRuntime();
      installNativeMiraRuntime();
      installMiraRavenNumberBoostRuntime();
      installNativeRavenMonsterVisual();
      installNativeYomiJingliuRuntime();
      installNativeTojiRuntime();
      installNanohaSharedKillRuntime();
      installQiyuDimensionRuntime();
      installStrongActorClassificationRuntime();
      installItemBagContinuationRuntime();
      installNativeDifficultyInheritanceRuntime();
      installNativeBlackFlashRuntime();
      installNativeSkillProgressionRuntime();
      installNativeCharacterVisualRuntime();
      installNativeHeartsteelRuntime();
      installNativeHubrisRuntime();
      installNativeSukunaRuntime();
      installNativeGarouRuntime();
      installImportedBalanceRuntime();
      installBulkPillsRuntime();
      window.CodexRuntime.install("installEquipmentStatusRuntime");
      window.CodexRuntime.install("installDisplayPreferencesRuntime");
      window.CodexRuntime.install("installRavenSkillEffectsRuntime");
      window.CodexRuntime.install("installCasinoBatchRuntime");
      window.CodexRuntime.install("installCombatPowerRuntime");
      window.CodexRuntime.install("installBossDifficultyRuntime");
      window.CodexRuntime.install("installTestModeRuntime");
      window.CodexRuntime.install("installTestGateRuntime"); // v0.53 测试模式门禁：方桌大厅 EV069「一键升级乌鸦」默认隐藏
      window.CodexRuntime.install("installCostumePreferencesRuntime");
      window.CodexRuntime.install("installVegettoFormRuntime"); // 贝吉特形态战斗图兜底
      window.CodexRuntime.install("installSkillLevelNoticeRuntime");
      window.CodexRuntime.install("installNativeYunshangRuntime");
      window.CodexRuntime.install("installDamageElementRuntime");
      window.CodexRuntime.install("installAlienationRuntime");
      window.CodexRuntime.install("installAlienationAffixes");
      window.CodexRuntime.install("installAlienationAdvanced");
      window.CodexRuntime.install("installAlienationWorkshop");
      window.CodexRuntime.install("installGamePanelTheme");
      window.CodexRuntime.install("installNativeGuyuRuntime"); // GUYU_START
      window.CodexRuntime.install("installSourceShieldLedgerRuntime"); // XUAN_TUSU
      window.CodexRuntime.install("installNativeBindingChargeRuntime"); // XUAN_TUSU
      window.CodexRuntime.install("installNativeXuanRuntime"); // XUAN_TUSU
      window.CodexRuntime.install("installNativeTusuRuntime"); // XUAN_TUSU
      window.CodexRuntime.install("installThreeGrowthRelicRuntime");
      window.CodexRuntime.install("installWeakChallengeRuntime");
      window.CodexRuntime.install("installNativeZhenqiRuntime"); // ZHENQI
      window.CodexRuntime.install("installNativeGuidanceRuntime"); // GUIDE
      window.CodexRuntime.install("installNativePowerZonesRuntime"); // ZONES
      window.CodexRuntime.install("installNativeEconomyRuntime"); // ECONOMY
      window.CodexRuntime.install("installNativeHonghuangRuntime"); // HONGHUANG
      window.CodexRuntime.install("installNativeOrbRuntime");
      window.CodexRuntime.install("installNativeMijingDrawRuntime"); // S5
      window.CodexRuntime.install("installNativeRunewordRuntime");
      window.CodexRuntime.install("installNativeRaceRuntime");
      window.CodexRuntime.install("installFeedbackRuntime");
      window.CodexRuntime.install("installKyoAchievementRuntime");
      window.CodexRuntime.install("installNativeDemonCrownRuntime");
      // v0.10 usability fixes after all native aliases.
      window.CodexRuntime.install("installV010UsabilityRuntime");
      // v0.14 超强者与强者路线压制，须在五乘区、谷雨、璇、屠苏之后。
      window.CodexRuntime.install("installSuperStrongRouteRuntime");
      // v0.15 七档品质：须在所有读取品质名称／颜色的模块之后。
      window.CodexRuntime.install("installUnifiedQualityRuntime");
      window.CodexRuntime.install("installV019UsabilityRuntime"); // v0.19 说明框复用、消息提醒、手机按键避让、回合条头像
      window.CodexRuntime.install("installReincarnationRandomRuntime"); // v0.27
      window.CodexRuntime.install("installTreasureBatchRuntime"); // v0.29
      window.CodexRuntime.install("installSkillCostRuntime"); // v0.15 技能减耗修复，须最后安装

      window.CodexRuntime.install("installIntegratedV029Runtime"); // v0.30

      window.CodexRuntime.install("installAbyssMerchantRuntime"); // v0.30
      window.CodexRuntime.install("installExclusiveGrowthRuntime"); // v0.31 专武随等级成长；须在v0.30一拳迁移之后
      window.CodexRuntime.install("installLxyUnlockRuntime"); // v0.53 李逍遥专武解禁与旧实例迁移

      window.CodexRuntime.install("installThreeBalanceV039Runtime"); // v0.39
      window.CodexRuntime.install("installSafeSellRuntime"); // v0.40
      window.CodexRuntime.install("installBalanceShopV041Runtime");
      window.CodexRuntime.install("installEquipmentDetailV041Runtime"); // v0.41
      window.CodexRuntime.install("installCacheRepairV043Runtime"); // v0.43 说明缓存自愈、读档容错；须最后安装
      window.CodexRuntime.install("installPanelLayoutV043Runtime"); // v0.43 装备／技能说明排版
      window.CodexRuntime.install("installUniqueEffectMarkRuntime"); // v0.56 唯一特效标识（只改显示）
      window.CodexRuntime.install("installTierTagsV044Runtime"); // v0.44 强弱分类只读角色备注 <KyoTier>；须最后安装
      window.CodexRuntime.install("installStoryGrowthBackfillRuntime"); // v0.52 一护／天剑成长进度补记
      window.CodexRuntime.install("installZhenhuoMarkRuntime"); // v0.53.01 至尊宝真火印记追击
      window.CodexRuntime.install("installCounterGuardRuntime"); // v0.53.01 反击防护
      window.CodexRuntime.install("installTransplantGapBackfillRuntime"); // v0.52 12.27 移植角色招募赠送与专武补发
      window.CodexRuntime.install("installSaveSlimV056Runtime");

    } catch (error) {
      console.error('内容模块初始化失败', error);
      showFailure('内容模块初始化失败：' + String(error && error.message || error));
      return;
    }
    started = true;
    if (timeoutId) window.clearTimeout(timeoutId);
    removeOverlayWhenReady();
    showBootErrors();
    try {
      SceneManager.run(Scene_Boot);
    } catch (error) {
      console.error('游戏启动失败', error);
      showFailure('游戏启动失败：' + String(error && error.message || error));
    }
  }

  createLoadingOverlay();

  // 保持 MV 的脚本顺序加载规则（async=false），只补上真实的完成通知。
  PluginManager.loadScript = function(name) {
    var url = this._path ? this._path + name : this.makeUrl(name);
    var script = document.createElement('script');
    expected++;
    script.type = 'text/javascript';
    script.src = url;
    script.async = false;
    script.onload = function() {
      loaded++;
      updateProgress();
      tryStart();
    };
    script.onerror = function(e) {
      PluginManager.onError(e);
      failed.push(url);
      updateProgress();
      tryStart();
    };
    script._url = url;
    document.body.appendChild(script);
  };

  PluginManager.setup($plugins);
  setupFinished = true;
  updateProgress();
  tryStart();

  // 不再在未完成时强行启动；以明确错误页取代白屏。
  timeoutId = window.setTimeout(function() {
    if (!started) showFailure('插件加载超过 45 秒，已停止继续启动以防止白屏。');
  }, 45000);
})();
