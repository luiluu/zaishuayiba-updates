// 【Codex·未经Claude检验】v0.29 共享提示合并且只提醒新激活项目。
// =============================================================================
// Star_SkillsShare.js
// Version: 1.37 (优化版)
var Imported = Imported || {};
Imported.Star_SkillsShare = true;
// -----------------------------------------------------------------------------
// [优化说明]: 添加缓存机制减少刷新频率
//      1. 添加战斗队伍成员缓存
//      2. 添加共享技能缓存
//      3. 仅在特定场景变化时刷新共享技能
// =============================================================================

/*:
 * @plugindesc 技能共享 [优化版]
 * @author Star
 
 @help
  当队伍角色有其中一个技能时全队拥有
  技能备注 <Share:ShareSkill>
  装备备注 <ShareSkill:技能id>
  装备备注 <ShareLearnSkill:技能id>  // 学习技能
  技能备注 <ShareSkill:技能id> // 通过技能1共享技能2
 */
var Star = Star || {};
Star.SkillsShare = Star.SkillsShare || {};

// 添加缓存变量
Star.SkillsShare.cachedBattleMembers = [];
Star.SkillsShare.lastSharedSkillIds = [];
Star.SkillsShare.lastEquipLearnSkills = {};

// 封装共享技能处理逻辑
Star.SkillsShare.refreshAllSkills = function() {
    const previousShared29 = (Star.SkillsShare.lastSharedSkillIds || []).slice();
    
    const battleMembers = $gameParty._battleMembers;
    let oldBattleMembers = [];
	if(Star.SkillsShare.cachedBattleMembers!='') oldBattleMembers = Star.SkillsShare.cachedBattleMembers.slice();
    Star.SkillsShare.cachedBattleMembers = battleMembers.slice();
    
    // 2. 收集新的装备学习技能
    const newEquipLearnSkills = this.collectEquipLearnSkills();
    
    // 遗忘之前的共享技能
    for (const skillId of Star.SkillsShare.lastSharedSkillIds) {
        for (const actorId of oldBattleMembers) {
            const actor = $gameActors.actor(actorId);
            if (actor) {
                actor.forgetSkill(skillId);
				//console.log('共享技能遗忘',actor._name,skillId)
            }
        }
    }
    
    // 遗忘之前的装备学习技能
    for (const actorId in Star.SkillsShare.lastEquipLearnSkills) {
        const actor = $gameActors.actor(Number(actorId));
        if (actor) {
            for (const skillId of Star.SkillsShare.lastEquipLearnSkills[actorId]) {
                actor.forgetSkill(skillId);
				//console.log('装备技能遗忘',actor._name,skillId)
            }
        }
    }
    //console.log('装备技能组',newEquipLearnSkills)
    // 添加新的装备学习技能（先学习）
    for (const actorId in newEquipLearnSkills) {
        const actor = $gameActors.actor(Number(actorId));
        if (actor) {
            const skills = newEquipLearnSkills[actorId];
            for (const skillId of skills) {
				if(!actor.hasSkill(skillId)) actor.learnSkill(skillId);
				//console.log('装备技能学习',actor._name,skillId)
            }
        }
    }
    Star.SkillsShare.lastEquipLearnSkills = newEquipLearnSkills;
    
    // 5. 现在角色已经学会了装备学习技能，可以正确收集共享技能
    const newSharedSkills = new Set();
    
    // 步骤1: 收集所有有Share标记的技能ID
    const shareMarkedSkills = new Set();
	const shareTaggedSkills = new Set();
    for (const actorId of battleMembers) {
        const actor = $gameActors.actor(actorId);
        if (actor) {
            for (const skill of actor.skills()) {
                if (skill && skill.meta && skill.meta.Share === "ShareSkill") {
                    shareMarkedSkills.add(skill.id);
					const skillRe = /<ShareSkill:(\d+)>/g;
					let skillMatch;
					while ((skillMatch = skillRe.exec(skill.note)) !== null) {
                    const skillId = Number(skillMatch[1]);
                    shareMarkedSkills.add(skillId);
                }
                }
            }
        }
    }
    //console.log('ShareSkill标识技能',shareMarkedSkills)
    // 步骤2: 收集所有<ShareSkill:技能id>标签的技能ID
    
    for (const actorId of battleMembers) {
        const actor = $gameActors.actor(actorId);
        if (actor) {
            // 收集角色技能中的ShareSkill标签
            for (const skill of actor.skills()) {
                if (!skill || !skill.note) continue;
                
                const skillRe = /<ShareSkill:(\d+)>/g;
                let skillMatch;
                while ((skillMatch = skillRe.exec(skill.note)) !== null) {
                    const skillId = Number(skillMatch[1]);
                    shareTaggedSkills.add(skillId);
                }
            }
            
            // 收集装备中的ShareSkill标签
            for (const equip of actor.equips()) {
                if (!equip) continue;
                
                const equipRe = /<ShareSkill:(\d+)>/g;
                let equipMatch;
                while ((equipMatch = equipRe.exec(equip.note)) !== null) {
                    const skillId = Number(equipMatch[1]);
                    shareTaggedSkills.add(skillId);
                }
            }
        }
    }
    //console.log('ShareSkill共享id',shareTaggedSkills)
    
    // 步骤3: 比对两个集合，找出匹配的技能ID
    for (const skillId of shareMarkedSkills) {
        if (shareTaggedSkills.has(skillId)) {
            newSharedSkills.add(skillId);
        }
    }
    //console.log('共享技能组',newSharedSkills)
    // 6. 添加新的共享技能
    const newSharedSkillIds = [];
    for (const skillId of newSharedSkills) {
        for (const actorId of battleMembers) {
            const actor = $gameActors.actor(actorId);
            if (actor && !actor.hasSkill(skillId)) {
                actor.learnSkill(skillId);
				//console.log('共享技能学习',actor._name,skillId)
            }
        }
        newSharedSkillIds.push(skillId);
    }
    const added29 = newSharedSkillIds.filter(function(id) { return previousShared29.indexOf(id) < 0; });
    if (added29.length && window.$ && $.toaster) {
      const names29 = added29.slice(0, 4).map(function(id) { return $dataSkills[id].name; });
      $.toaster({message: '光环生效：' + names29.join('、') + (added29.length > 4 ? ' 等' + added29.length + '项' : '')});
    }
    Star.SkillsShare.lastSharedSkillIds = newSharedSkillIds;
};

// 收集装备学习技能的函数
Star.SkillsShare.collectEquipLearnSkills = function() {
    const battleMembers = $gameParty._battleMembers;
    const newEquipLearnSkills = {};
    for (const actorId of battleMembers) {
        const actor = $gameActors.actor(actorId);
        if (actor) {
            const learnedSkills = [];
            for (const equip of actor.equips()) {
                if (!equip) continue;
                let re = /<ShareLearnSkill:(\d+)>/g;
                let match;
                while ((match = re.exec(equip.note)) !== null) {
                    const skillId = Number(match[1]);
                    learnedSkills.push(skillId);
                }
            }
            if (learnedSkills.length > 0) {
                newEquipLearnSkills[actorId] = learnedSkills;
            }
        }
    }
    return newEquipLearnSkills;
};

// 检查装备学习技能是否有变化
Star.SkillsShare.hasEquipLearnSkillsChanged = function() {
    const currentSkills = this.collectEquipLearnSkills();
    const lastSkills = Star.SkillsShare.lastEquipLearnSkills;
    // 检查键的数量是否相同
    const currentKeys = Object.keys(currentSkills);
    const lastKeys = Object.keys(lastSkills);
    if (currentKeys.length !== lastKeys.length) return true;
    
    // 检查每个角色的技能列表
    for (const actorId in currentSkills) {
        const current = currentSkills[actorId].slice().sort();
        const last = lastSkills[actorId] ? lastSkills[actorId].slice().sort() : [];
        
        // 检查数组长度
        if (current.length !== last.length) return true;
        
        // 检查每个技能ID
        for (let i = 0; i < current.length; i++) {
            if (current[i] !== last[i]) return true;
        }
    }
    
    return false;
};

// 战斗开始刷新技能
Star.SkillsShare.BattleManager_startBattle = BattleManager.startBattle;
BattleManager.startBattle = function() {
    if (Star.SkillsShare.hasEquipLearnSkillsChanged()) {
		Star.SkillsShare.refreshAllSkills();
	}
    Star.SkillsShare.BattleManager_startBattle.call(this);
};

//整队界面完成时刷新技能
if (Scene_Party) {
    Star.SkillsShare.Scene_Party_commandFinish = Scene_Party.prototype.commandFinish;
    Scene_Party.prototype.commandFinish = function() {
    // 检查队伍是否变化
    if (Imported.Star_JiBanSiklls && Star.ActorsRanksSkill_Jiban.hasBattleMembersChanged()) {
		Star.SkillsShare.refreshAllSkills();
	} else {
		Star.SkillsShare.refreshAllSkills();
	}
        Star.SkillsShare.Scene_Party_commandFinish.call(this);
    };
}

//仓库界面退出时刷新技能
if (typeof Star_Scene_ActorWarehouse !== 'undefined') {
    Star.SkillsShare.Star_Scene_ActorWarehouse_cancelNowScene = Star_Scene_ActorWarehouse.prototype.cancelNowScene;
    Star_Scene_ActorWarehouse.prototype.cancelNowScene = function() {
    if (Imported.Star_JiBanSiklls && Star.ActorsRanksSkill_Jiban.hasBattleMembersChanged()){
		Star.SkillsShare.refreshAllSkills();
	} else {
		Star.SkillsShare.refreshAllSkills();
	} 
        Star.SkillsShare.Star_Scene_ActorWarehouse_cancelNowScene.call(this);
    };
}

