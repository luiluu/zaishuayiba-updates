// 【Codex·未经Claude检验】v0.35：A键／触摸传送菜单，掉落详情中文属性与完整固定特效分页。
var Star_helpWindow = null;
/*:
 * @plugindesc 地图传送与敌群掉落查看插件 v2.0 (修改版)
 * @author YourName
 *
 * @param Map Settings
 * @type struct<MapSetting>[]
 * @desc 地图传送设置（每个地图单独配置）
 * @default []
 *
 * @help
 * 使用说明：
 * 1. 在插件参数中设置可传送的地图参数
 * 2. 通过插件指令"OpenMapTransfer"打开传送界面，地图场景右上角也有按钮
 * 3. 左侧选择地图，右侧查看该地图的敌人及掉落物
 * 4. 选中地图后按确认键可触发传送
 * 
 * 修改说明：
 * - 选择地图按确认键后，会选中怪物信息窗口的第一个掉落物
 * - 此时可使用方向键切换掉落物
 * - 按确认键弹出传送窗口
 * - 按取消键回到地图选择
 * 
 * 插件指令：
 *   UnlockMapTransfer [mapId] - 解锁指定地图
 *   LockMapTransfer [mapId]   - 锁定指定地图
 * 
 * 脚本调用：
 *   $gameSystem.unlockMap(mapId)   - 解锁地图
 *   $gameSystem.lockMap(mapId)     - 锁定地图
 *   $gameSystem.isMapUnlocked(mapId) - 检查地图是否解锁
 * 
 */

/*~struct~MapSetting:
 * @param id
 * @text 地图ID
 * @type number
 * @desc 地图ID
 * 
 * @param transmitid
 * @text 传送地图ID
 * @type number
 * @desc 传送地图id（可为空，为空时传送使用地图id）
 *
 * @param name
 * @text 地图名称
 * @type string
 * @desc 地图名称（可选，为空时使用数据库名称）
 * 
 * @param x
 * @text 传送X坐标
 * @type number
 * @desc 传送X坐标
 * 
 * @param y
 * @text 传送Y坐标
 * @type number
 * @desc 传送Y坐标
 * 
 * @param extraEnemies
 * @text 额外怪物ID
 * @type string
 * @desc 额外显示的怪物ID（多个用逗号分隔）
 * 
 * @param hidden
 * @text 初始是否隐藏
 * @type boolean
 * @desc 是否隐藏（true/false）
 * @default true
 *
 * @param canTransfer
 * @text 是否可传送
 * @type boolean
 * @desc 是否可以传送到此地图（true/false）
 * @default true
 *
 * @param transferItem
 * @text 传送消耗道具
 * @type item
 * @desc 传送到此地图需要消耗的道具（留空则不消耗）
 */

(function() {
	// F is deliberately reserved for map-transfer confirmation.  Shift and T
	// are already claimed by installed battle/common-event plugins.
	Input.keyMapper[70] = 'mapTransferConfirm';
    // 参数解析
    const parameters = PluginManager.parameters('MapTransferPlugin');
    const rawSettings = JSON.parse(parameters['Map Settings'] || '[]');
    // 解析每个字符串为对象
const mapSettings = [];
for (const str of rawSettings) {
    try {
        mapSettings.push(JSON.parse(str));
    } catch (e) {
        console.error("解析地图设置失败:", str, e);
    }
}
    // 解析地图列表
    const maps = [];
    const mapSettingsById = {};
    
    // 存储所有地图解锁状态
const _Game_System_initialize = Game_System.prototype.initialize;
Game_System.prototype.initialize = function() {
    _Game_System_initialize.call(this);
    // 确保 _unlockedMaps 总是对象
    if (!this._unlockedMaps || typeof this._unlockedMaps !== 'object') {
        this._unlockedMaps = {};
    }
};

// 解锁地图方法
Game_System.prototype.unlockMap = function(mapId) {
    // 确保 mapId 是数字
    mapId = parseInt(mapId);
    if (isNaN(mapId)) return;
    
    // 确保 _unlockedMaps 已初始化
    if (!this._unlockedMaps || typeof this._unlockedMaps !== 'object') {
        this._unlockedMaps = {};
    }
    
    this._unlockedMaps[mapId] = true;
};

// 锁定地图方法
Game_System.prototype.lockMap = function(mapId) {
    // 确保 mapId 是数字
    mapId = parseInt(mapId);
    if (isNaN(mapId)) return;
    
    // 确保 _unlockedMaps 已初始化
    if (!this._unlockedMaps || typeof this._unlockedMaps !== 'object') {
        this._unlockedMaps = {};
    }
    
    this._unlockedMaps[mapId] = false;
};

// 检查地图是否解锁
Game_System.prototype.isMapUnlocked = function(mapId) {
    // 确保 mapId 是数字
    mapId = parseInt(mapId);
    if (isNaN(mapId)) return false;
    
    // 确保 _unlockedMaps 已初始化
    if (!this._unlockedMaps || typeof this._unlockedMaps !== 'object') {
        this._unlockedMaps = {};
        return false;
    }
    
    // 检查解锁状态（默认为false）
    return this._unlockedMaps[mapId] === true;
};
    
    // 玩家进入地图时自动解锁
    const _Game_Player_performTransfer = Game_Player.prototype.performTransfer;
    Game_Player.prototype.performTransfer = function() {
        _Game_Player_performTransfer.call(this);
        const mapId = $gameMap.mapId();
        // 只解锁在配置中的地图
        if (mapSettingsById[mapId]) {
            $gameSystem.unlockMap(mapId);
        }
    };
    
    const parseMapSettings = function() {
    // 确保 $dataMapInfos 已加载
    if (!$dataMapInfos) {
        return;
    }
    
    // 清空之前的设置
    maps.length = 0;
    for (const key in mapSettingsById) delete mapSettingsById[key];
    
    // 解析地图设置
    for (const setting of mapSettings) {
        // 将字符串值转换为正确的类型
        const mapId = parseInt(setting.id);
		const transmitid = parseInt(setting.transmitid) || 0;
        const mapName = setting.name || ($dataMapInfos[mapId] ? $dataMapInfos[mapId].name : `地图${mapId}`);
        const x = parseInt(setting.x) || 0;
        const y = parseInt(setting.y) || 0;
        
        // 处理额外怪物ID - 确保空字符串不会产生[NaN]
        let extraEnemies = [];
        if (setting.extraEnemies && setting.extraEnemies.trim() !== "") {
            extraEnemies = setting.extraEnemies.split(',').map(id => parseInt(id)).filter(id => !isNaN(id));
        }
        
        // 处理布尔值 - 字符串'true'转换为true，其他为false
        const hidden = setting.hidden === "true";
		const canTransfer = setting.canTransfer !== "false";
        const transferItem = parseInt(setting.transferItem) || 0;
        
        // 创建地图配置对象
        const mapConfig = {
            id: mapId,
			tsid: transmitid,
            name: mapName,
            x: x,
            y: y,
            extraEnemies: extraEnemies,
            hidden: hidden,
            canTransfer: canTransfer,
            transferItem: transferItem
        };
        
        maps.push(mapConfig);
        mapSettingsById[mapId] = mapConfig;
    }
    
   // console.log("地图设置解析完成", maps);
};
	// 在数据库加载完成后解析地图设置
    const _DataManager_onLoad = DataManager.onLoad;
    DataManager.onLoad = function(object) {
        _DataManager_onLoad.call(this, object);
        
        // 当 MapInfos 加载完成时解析设置
        if (object === $dataMapInfos) {
            parseMapSettings();
        }
    };
    
    // 如果 MapInfos 已经加载，立即解析
    if ($dataMapInfos) {
        parseMapSettings();
    }

    // 创建传送场景
    function Scene_MapTransfer() {
        this.initialize.apply(this, arguments);
    }

    Scene_MapTransfer.prototype = Object.create(Scene_MenuBase.prototype);
    Scene_MapTransfer.prototype.constructor = Scene_MapTransfer;

    Scene_MapTransfer.prototype.initialize = function() {
        Scene_MenuBase.prototype.initialize.call(this);
        this._transferTarget = null;
        this._dropSelectMode = false; // 添加：掉落物选择模式标志
        this._ConfirmationMode = false;
    };

    Scene_MapTransfer.prototype.create = function() {
        Scene_MenuBase.prototype.create.call(this);
        this.createBackground();
        this.createWindowLayer();
        this.createMapListWindow();
        this.createEnemyInfoWindow();
        this.createDropDetailWindow();
        this.createMapActionWindow();
    };
	
	Scene_MapTransfer.prototype.isMapTransferScene = function() {
    return true;
	};
	
    // 添加：创建物品帮助窗口
    Scene_MapTransfer.prototype.createItemHelpWindow = function() {
        if (typeof Sprite_ItemHelp === 'function') {
            this._itemHelpWindow = new Sprite_ItemHelp(RJO.HE.ItemDescWidth);
            this.addChild(this._itemHelpWindow);
            this._itemHelpWindow.visible = false; // 初始隐藏
			// 设置全局变量
			Star_helpWindow = this._itemHelpWindow;
        }
    };
	
	// 添加 terminate 方法清理全局变量
	Scene_MapTransfer.prototype.terminate = function() {
    Scene_MenuBase.prototype.terminate.call(this);
    Star_helpWindow = null;
	};

    Scene_MapTransfer.prototype.createBackground = function() {
        this._backgroundSprite = new Sprite();
        this._backgroundSprite.bitmap = SceneManager.backgroundBitmap();
        this.addChild(this._backgroundSprite);
    };

    Scene_MapTransfer.prototype.createMapListWindow = function() {
        // 左侧宽度改为180
        const rect = new Rectangle(0, 0, 180, Graphics.boxHeight);
        this._mapListWindow = new Window_MapList(rect);
        this._mapListWindow.setHandler('ok', this.onMapConfirmed.bind(this));
        this._mapListWindow.setHandler('cancel', this.popScene.bind(this));
        // 添加change事件处理
        this._mapListWindow.setHandler('change', this.onMapSelected.bind(this));
        this.addWindow(this._mapListWindow);
        this._mapListWindow.activate();
    };

    Scene_MapTransfer.prototype.createEnemyInfoWindow = function() {
        const x = this._mapListWindow.width;
        const width = Graphics.boxWidth - x;
        const height = Graphics.boxHeight;
        const rect = new Rectangle(x, 0, width, height);
        this._enemyInfoWindow = new Window_EnemyInfo(rect);
        this.addWindow(this._enemyInfoWindow);
    };

    Scene_MapTransfer.prototype.createDropDetailWindow = function() {
        const width = Math.min(900, Graphics.boxWidth - 40);
        const height = Math.min(620, Graphics.boxHeight - 48);
        const rect = new Rectangle((Graphics.boxWidth - width) / 2, (Graphics.boxHeight - height) / 2, width, height);
        this._dropDetailWindow = new Window_DropDetail(rect);
        this.addWindow(this._dropDetailWindow);
        this._dropDetailWindow.close();
        this._dropDetailWindow.hide();
    };

    Scene_MapTransfer.prototype.openDropDetail = function() {
        const drop = this._enemyInfoWindow.selectedDrop();
        if (!drop || !drop.item) { SoundManager.playBuzzer(); return; }
        this._dropDetailWindow.setDrop(drop);
        this._dropDetailWindow.show();
        this._dropDetailWindow.open();
        this._dropDetailMode = true;
        SoundManager.playOk();
    };

    Scene_MapTransfer.prototype.closeDropDetail = function() {
        this._dropDetailWindow.close();
        this._dropDetailWindow.hide();
        this._dropDetailMode = false;
        SoundManager.playCancel();
    };

    Scene_MapTransfer.prototype.onMapSelected = function() {
        const map = this._mapListWindow.currentMap();
        if (map) {
            this._enemyInfoWindow.setMapId(map.id);
            // 重置掉落物选择模式
            this._dropSelectMode = false;
            this._enemyInfoWindow.deactivateDropSelect();
        }
    };

    // The same command window accepts desktop OK, Android A and direct touch.
    Scene_MapTransfer.prototype.createMapActionWindow = function() {
        this._mapActionWindow = new Window_MapAction();
        this._mapActionWindow.setHandler('transfer', this.requestMapTransfer.bind(this));
        this._mapActionWindow.setHandler('drops', this.beginDropSelect.bind(this));
        this._mapActionWindow.setHandler('cancel', this.closeMapActions.bind(this));
        this.addWindow(this._mapActionWindow);
        this._mapActionWindow.hide(); this._mapActionWindow.close(); this._mapActionWindow.deactivate();
    };
    Scene_MapTransfer.prototype.canTransferToTarget = function() {
        var map = this._transferTarget;
        return !!(map && map.canTransfer && Number(map.tsid || map.id) > 0 &&
            (!map.hidden || $gameSystem.isMapUnlocked(map.id)) &&
            (!map.transferItem || $gameParty.hasItem($dataItems[map.transferItem])));
    };
    Scene_MapTransfer.prototype.onMapConfirmed = function() {
        var map = this._mapListWindow.currentMap();
        if (!map) return;
        this._transferTarget = map;
        this._mapListWindow.deactivate();
        this._dropSelectMode = false;
        this._enemyInfoWindow.deactivateDropSelect();
        this._mapActionMode = true;
        this._mapActionWindow.refresh();
        this._mapActionWindow.select(this.canTransferToTarget() ? 0 : 1);
        this._mapActionWindow.show(); this._mapActionWindow.open(); this._mapActionWindow.activate();
    };
    Scene_MapTransfer.prototype.hideMapActions = function() {
        this._mapActionMode = false;
        this._mapActionWindow.hide(); this._mapActionWindow.close(); this._mapActionWindow.deactivate();
    };
    Scene_MapTransfer.prototype.closeMapActions = function() {
        this.hideMapActions();
        this._mapListWindow.activate();
    };
    Scene_MapTransfer.prototype.requestMapTransfer = function() {
        if (!this.canTransferToTarget()) { SoundManager.playBuzzer(); return; }
        this.hideMapActions();
        this.createConfirmationWindow();
    };
    Scene_MapTransfer.prototype.beginDropSelect = function() {
        this.hideMapActions();
        this._dropSelectMode = true;
        this._dropSelectEnteredFrame = Graphics.frameCount;
        this._mapListWindow.deactivate();
        this._enemyInfoWindow.activateDropSelect();
    };

    // 添加：处理掉落物选择模式下的输入
    Scene_MapTransfer.prototype.update = function() {
        Scene_MenuBase.prototype.update.call(this);
        this.updatePageTurn();
        
        // 在掉落物选择模式下处理输入
        if (this._dropDetailMode) {
            if (Input.isTriggered('left') || Input.isTriggered('pageup')) { this._dropDetailWindow.previousAffixPage(); return; }
            if (Input.isTriggered('right') || Input.isTriggered('pagedown')) { this._dropDetailWindow.nextAffixPage(); return; }
            if (TouchInput.isTriggered()) {
                var detail = this._dropDetailWindow, x = TouchInput.x - detail.x, y = TouchInput.y - detail.y;
                if (x >= 0 && x < detail.width && y >= detail.height - detail.standardPadding() - detail.lineHeight()) {
                    if (x < detail.width / 3) detail.previousAffixPage();
                    else if (x > detail.width * 2 / 3) detail.nextAffixPage();
                    else this.closeDropDetail();
                    return;
                }
            }
            if (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isCancelled()) this.closeDropDetail();
            return;
        }
        if (this._mapActionMode || this._ConfirmationMode) return;
        if (this._mapListWindow.active && Input.isTriggered('mapTransferConfirm')) {
            this._transferTarget = this._mapListWindow.currentMap();
            this.requestMapTransfer(); return;
        }
        if (this._dropSelectMode) {
			const map = this._mapListWindow.currentMap();
			// F is a dedicated physical key installed above and is not shared
			// with battle speed, enemy book, or common-event shortcuts.
            const transferTriggered = Input.isTriggered('mapTransferConfirm');
            const detailTriggered = Input.isTriggered('ok') &&
                Graphics.frameCount > (this._dropSelectEnteredFrame || 0);
            // The first confirm enters drop selection.  Every later confirm
            // opens information for the highlighted drop; it never transfers.
            if (detailTriggered) {
                this.openDropDetail();
                return;
            } else if (transferTriggered) {
                this.requestMapTransfer();
            } else if (Input.isTriggered('cancel') || TouchInput.isCancelled()) {
                // 退出掉落物选择模式
                this._dropSelectMode = false;
                this._enemyInfoWindow.deactivateDropSelect();
                this.onMapConfirmed();
            }
        }
        
        // Keep the contextual item help visible while browsing drops.  The
        // previous code hid it every frame, so confirming a map appeared to
        // do nothing even though a drop had been selected.
        this.updateItemHelpWindow();
    };
    
    // 添加：更新物品帮助窗口
    Scene_MapTransfer.prototype.updateItemHelpWindow = function() {
        if (this._itemHelpWindow && this._dropSelectMode) {
            const selectedDrop = this._enemyInfoWindow.selectedDrop();
            if (selectedDrop) {
                // 根据掉落物类型获取对应的物品/武器/防具
                let item = null;
                switch(selectedDrop.type) {
                    case 'Item':
                        item = $dataItems[selectedDrop.id];
                        break;
                    case 'Weapon':
                        item = $dataWeapons[selectedDrop.id];
                        break;
                    case 'Armor':
                        item = $dataArmors[selectedDrop.id];
                        break;
                }
                
                if (item) {
                if (this._codexHelpItem !== item) { this._codexHelpItem = item; this._itemHelpWindow.setItem(item); }
                this._itemHelpWindow.visible = true;
                
                // 设置物品帮助窗口位置（在掉落物旁边）
                const dropIndex = this._enemyInfoWindow.dropIndex();
                const dropPos = this._enemyInfoWindow.dropPosition(dropIndex);
				const rightWindowWidth = this._enemyInfoWindow.width;
                const dropWidth = dropPos ? dropPos.width : 180;
                if (dropPos) {
                    this._itemHelpWindow.x = dropPos.x + dropWidth + 10; // 向右偏移50像素
                    this._itemHelpWindow.y = dropPos.y;
                    
                    // 确保窗口不会超出屏幕
                    if (this._itemHelpWindow.x + this._itemHelpWindow.width > Graphics.width) {
                        this._itemHelpWindow.x = dropPos.x - this._itemHelpWindow.width - 10;
                    }
                    if (this._itemHelpWindow.y + this._itemHelpWindow.height > Graphics.height) {
                        this._itemHelpWindow.y = Graphics.height - this._itemHelpWindow.height - 10;
                    }
                }
            } else {
                this._itemHelpWindow.visible = false;
            }
        } else {
            this._itemHelpWindow.visible = false;
        }
    } else if (this._itemHelpWindow) {
        this._itemHelpWindow.visible = false;
    }
    };

    Scene_MapTransfer.prototype.createConfirmationWindow = function() {
        if (this._confirmationWindow) {
            this._confirmationWindow.close();
            this._windowLayer.removeChild(this._confirmationWindow);
        }
		this._ConfirmationMode = true;
        this._dropSelectMode = false;
        this._enemyInfoWindow.deactivateDropSelect();
        
        const rect = new Rectangle(0, 0, Math.min(380, Graphics.boxWidth - 40), 168);
        rect.x = (Graphics.boxWidth - rect.width) / 2;
        rect.y = (Graphics.boxHeight - rect.height) / 2;
        
        this._confirmationWindow = new Window_Confirmation(rect);
		const name = this._transferTarget ? this._transferTarget.name : '未知地图';
		this._confirmationWindow.setMessage(`是否传送至 ${name}?`);
        this._confirmationWindow.setHandler('ok', this.transferPlayer.bind(this));
        this._confirmationWindow.setHandler('cancel', this.closeConfirmationWindow.bind(this));
        this.addWindow(this._confirmationWindow);
        this._confirmationWindow.activate();
    };

    Scene_MapTransfer.prototype.closeConfirmationWindow = function() {
        if (this._confirmationWindow) {
            this._confirmationWindow.close();
			this._windowLayer.removeChild(this._confirmationWindow);
            this._confirmationWindow = null;
			this._ConfirmationMode = false;
            this.onMapConfirmed();
        }
    };

    Scene_MapTransfer.prototype.transferPlayer = function() {
        if (this._transferCommitted) return;
        if (!this.canTransferToTarget()) { SoundManager.playBuzzer(); return; }
        if (this._transferTarget) {
            this._transferCommitted = true;
			var map = Number(this._transferTarget.tsid || this._transferTarget.id);
			if (!map || map < 1) { SoundManager.playBuzzer(); return; }
			// 消耗传送道具（仅在目标地图有效时才扣除）
            if (this._transferTarget.transferItem > 0) {
                $gameParty.loseItem($dataItems[this._transferTarget.transferItem], 1);
            }
			var params = {
				name: "Laser1",
				pan: 0,
				pitch: 100,
				volume: 90
			}
			AudioManager.playSe(params)
			// SceneManager.goto(Scene_Map) bypasses the normal transfer fade-in
			// sequence.  Fading the shared Game_Screen out here therefore leaves
			// the destination map permanently black (or very dark) until another
			// scene happens to change the brightness.  Let the map change directly.
			$gameScreen._brightness = 255;
			$gameScreen._fadeOutDuration = 0;
			$gameScreen._fadeInDuration = 0;
            $gamePlayer.reserveTransfer(
                map,
				Number(this._transferTarget.x) || 0,
                Number(this._transferTarget.y) || 0,
				8,
				0
            );
            // 直接返回地图场景
            SceneManager.goto(Scene_Map);
        }
    };
// 在场景中添加翻页控制
Scene_MapTransfer.prototype.updatePageTurn = function() {
    // Enemy window handles paging once per frame.
};
Scene_MapTransfer.prototype.isConfirmationActive = function() {
    return this._mapActionMode || this._dropDetailMode || (this._confirmationWindow && this._confirmationWindow.active);
};
// =========================================================================
    // 新增：地图传送按钮
    // =========================================================================
    // 按钮精灵类
    function Sprite_MapTransferButton() {
        this.initialize.apply(this, arguments);
    }

    Sprite_MapTransferButton.prototype = Object.create(Sprite.prototype);
    Sprite_MapTransferButton.prototype.constructor = Sprite_MapTransferButton;

    Sprite_MapTransferButton.prototype.initialize = function() {
        Sprite.prototype.initialize.call(this);
        this._pressed = false;
        this._hover = false;
        this._blockInput = false; // 新增：输入阻断标志
        this.createButton();
    };

    // 创建按钮
    Sprite_MapTransferButton.prototype.createButton = function() {
        const width = 120;
        const height = 48;
        this.bitmap = new Bitmap(width, height);
        this.refresh();
        
        // 设置位置（右上角，与Save按钮间隔）
        this.x = Graphics.boxWidth - width - 140; // 在Save按钮左侧
        this.y = 10; // 顶部位置
        
        // 设置按钮区域
        this._buttonRect = new Rectangle(this.x, this.y, width, height);
    };

    // 刷新按钮状态
    Sprite_MapTransferButton.prototype.refresh = function() {
        const width = this.bitmap.width;
        const height = this.bitmap.height;
        const radius = 10; // 圆角半径
        this.bitmap.clear();
        
        // 获取背景颜色
        let bgColor = 'rgba(255, 255, 255, 0.2)'; // 半透明白色
        if (this._pressed) {
            bgColor = 'rgba(255, 255, 255, 0.8)';
        } else if (this._hover) {
            bgColor = 'rgba(255, 255, 255, 0.7)';
        }
        
        // 绘制圆角矩形
        const context = this.bitmap._context;
        context.save();
        context.beginPath();
        
        // 绘制圆角路径
        context.moveTo(radius, 0);
        context.lineTo(width - radius, 0);
        context.arcTo(width, 0, width, radius, radius);
        context.lineTo(width, height - radius);
        context.arcTo(width, height, width - radius, height, radius);
        context.lineTo(radius, height);
        context.arcTo(0, height, 0, height - radius, radius);
        context.lineTo(0, radius);
        context.arcTo(0, 0, radius, 0, radius);
        context.closePath();
        
        // 填充背景
        context.fillStyle = bgColor;
        context.fill();
        
        // 绘制边框
        context.strokeStyle = 'rgba(0, 0, 0, 0.3)';
        context.lineWidth = 1;
        context.stroke();
        
        context.restore();
        this.bitmap._setDirty();
        
        // 绘制文字 - 根据悬停状态调整透明度
        this.bitmap.fontSize = 24;
        const textOpacity = this._hover || this._pressed ? 0.7 : 0.4; // 悬停/按下时不透明，否则半透明
        this.bitmap.textColor = `rgba(0,255,127, ${textOpacity})`;
        this.bitmap.drawText('地图传送', 0, 0, width, height, 'center');
    };

    // 更新按钮状态
    Sprite_MapTransferButton.prototype.update = function() {
        Sprite.prototype.update.call(this);
        
        // 获取当前鼠标/触摸位置
        const x = TouchInput.x;
        const y = TouchInput.y;
        
        // 检测是否在按钮上
        const isTouched = this.isButtonTouched(x, y);
        
        // 更新悬停状态
        if (isTouched && !this._hover) {
            this._hover = true;
            this.refresh();
        } else if (!isTouched && this._hover) {
            this._hover = false;
            this.refresh();
        }
        
        // 处理按下事件
        if (isTouched && TouchInput.isPressed() && !this._pressed) {
            this._pressed = true;
            this._blockInput = true; // 激活输入阻断
            this.refresh();
        } 
        // 处理释放事件
        else if (this._pressed && TouchInput.isReleased()) {
            this._pressed = false;
            this.refresh();
            if (this.isButtonTouched(x, y)) {
                SoundManager.playOk();
                
                // 关键修复：清除触摸状态，防止角色移动
                TouchInput.clear();
                this._blockInput = false;
                
                SceneManager.push(Scene_MapTransfer);
            }
        }
    };

    // 检测位置是否在按钮上
    Sprite_MapTransferButton.prototype.isButtonTouched = function(x, y) {
        return this._buttonRect.contains(x, y);
    };

    // =========================================================================
    // 在地图场景添加按钮并修复输入处理
    // =========================================================================
    
    var _Scene_Map_create = Scene_Map.prototype.create;
    Scene_Map.prototype.create = function() {
        _Scene_Map_create.call(this);
		if($gameVariables.value(21)==0) this.createMapTransferButton();
    };

    Scene_Map.prototype.createMapTransferButton = function() {
        this._mapTransferButton = new Sprite_MapTransferButton();
        this.addChild(this._mapTransferButton);
    };

    // 确保按钮在窗口层上方
    var _Scene_Map_createDisplayObjects = Scene_Map.prototype.createDisplayObjects;
    Scene_Map.prototype.createDisplayObjects = function() {
        _Scene_Map_createDisplayObjects.call(this);
        if (this._mapTransferButton) {
            this.addChild(this._mapTransferButton);
        }
    };

    // 在场景更新时更新按钮
    var _Scene_Map_update = Scene_Map.prototype.update;
    Scene_Map.prototype.update = function() {
        _Scene_Map_update.call(this);
        if (this._mapTransferButton) {
            // Scene child update already updates the button once per frame.
        } else if($gameVariables.value(21)==0){
			this.createMapTransferButton();
		}
    };

    // 关键修复：在输入处理前阻断按钮区域的输入
    var _Scene_Map_processMapTouch = Scene_Map.prototype.processMapTouch;
    Scene_Map.prototype.processMapTouch = function() {
        if (this._mapTransferButton && 
            this._mapTransferButton._blockInput && 
            this._mapTransferButton.isButtonTouched(TouchInput.x, TouchInput.y)) {
            // 阻断输入，不处理地图触摸
            return;
        }
        _Scene_Map_processMapTouch.call(this);
    };

    // 覆盖此方法以完全阻止按钮区域的触摸
    var _Scene_Map_updateMapTouch = Scene_Map.prototype.updateMapTouch;
    Scene_Map.prototype.updateMapTouch = function() {
        if (this._mapTransferButton && 
            this._mapTransferButton.isButtonTouched(TouchInput.x, TouchInput.y)) {
            // 完全跳过地图触摸更新
            return;
        }
        _Scene_Map_updateMapTouch.call(this);
    };

    // 覆盖此方法防止按钮区域触发角色移动
    var _Scene_Map_isMapTouchOk = Scene_Map.prototype.isMapTouchOk;
    Scene_Map.prototype.isMapTouchOk = function() {
        if (this._mapTransferButton && 
            this._mapTransferButton.isButtonTouched(TouchInput.x, TouchInput.y)) {
            return false;
        }
        return _Scene_Map_isMapTouchOk.call(this);
    };

	
    // 确认窗口 - 修复布局
    function Window_Confirmation() {
    this.initialize.apply(this, arguments);
}

Window_Confirmation.prototype = Object.create(Window_Command.prototype);
Window_Confirmation.prototype.constructor = Window_Confirmation;

Window_Confirmation.prototype.initialize = function(rect) {
    this._dialogRect = rect;
    if (Utils.RPGMAKER_NAME === 'MV') Window_Command.prototype.initialize.call(this, rect.x, rect.y);
    else Window_Command.prototype.initialize.call(this, rect);
    this._message = '';
    this.openness = 0;
    this.open();
};

Window_Confirmation.prototype.setMessage = function(message) {
    this._message = message;
    this.refresh();
};

Window_Confirmation.prototype.makeCommandList = function() {
    this.addCommand('确认', 'ok');
    this.addCommand('取消', 'cancel');
};
Window_Confirmation.prototype.windowWidth = function() { return this._dialogRect.width; };
Window_Confirmation.prototype.windowHeight = function() { return this._dialogRect.height; };

Window_Confirmation.prototype.refresh = function() {
    Window_Command.prototype.refresh.call(this);
    if (this._message) {
        this.drawText(this._message, 0, 0, this.contentsWidth(), 'center');
    }
};

Window_Confirmation.prototype.itemRect = function(index) {
    var rect = Window_Selectable.prototype.itemRect.call(this, index);
    rect.y += this.lineHeight() + 12;
    return rect;
};

    function Window_MapAction() { this.initialize.apply(this, arguments); }
    Window_MapAction.prototype = Object.create(Window_Command.prototype);
    Window_MapAction.prototype.constructor = Window_MapAction;
    Window_MapAction.prototype.initialize = function() {
        var width = this.windowWidth();
        Window_Command.prototype.initialize.call(this, (Graphics.boxWidth - width) / 2, Math.max(0, (Graphics.boxHeight - this.fittingHeight(3)) / 2));
    };
    Window_MapAction.prototype.windowWidth = function() { return Math.min(360, Graphics.boxWidth - 40); };
    Window_MapAction.prototype.numVisibleRows = function() { return 3; };
    Window_MapAction.prototype.makeCommandList = function() {
        var scene = SceneManager._scene;
        this.addCommand('传送至此', 'transfer', !!(scene && scene.canTransferToTarget && scene.canTransferToTarget()));
        this.addCommand('查看掉落', 'drops');
        this.addCommand('返回地图列表', 'cancel');
    };

    // 地图选择窗口
    function Window_MapList() {
        this.initialize.apply(this, arguments);
    }

    Window_MapList.prototype = Object.create(Window_Selectable.prototype);
    Window_MapList.prototype.constructor = Window_MapList;

    Window_MapList.prototype.initialize = function(rect) {
        if (Utils.RPGMAKER_NAME === 'MV') Window_Selectable.prototype.initialize.call(this, rect.x, rect.y, rect.width, rect.height);
        else Window_Selectable.prototype.initialize.call(this, rect);
        this.refresh();
        this.select(0);
        this.activate();
    };

    Window_MapList.prototype.maxItems = function() {
        return maps.length;
    };

    Window_MapList.prototype.refresh = function() {
        this._list = maps;
        this.createContents();
        this.drawAllItems();
    };

    Window_MapList.prototype.drawItem = function(index) {
        if (index >= this._list.length) return;
        
        const rect = this.itemRectForText(index);
        const map = this._list[index];
        
        // 检查地图是否解锁
        const unlocked = $gameSystem.isMapUnlocked(map.id);
        
        // 隐藏地图显示为???
        if (map.hidden && !unlocked) {
            this.drawText("???", rect.x, rect.y, rect.width, 'center');
        } else {
            this.drawText(map.name, rect.x, rect.y, rect.width, 'center');
        }
    };

    Window_MapList.prototype.currentMap = function() {
        if (this.index() >= this._list.length) return null;
        return this._list[this.index()];
    };
    // Q/E page the left map list until a map is confirmed.
    Window_MapList.prototype.cursorPageup = function() {
        var step = Math.max(1, this.maxPageItems());
        this.select(Math.max(0, this.index() - step));
        SoundManager.playCursor();
    };
    Window_MapList.prototype.cursorPagedown = function() {
        var step = Math.max(1, this.maxPageItems());
        this.select(Math.min(this.maxItems() - 1, this.index() + step));
        SoundManager.playCursor();
    };

    Window_MapList.prototype.update = function() {
        Window_Selectable.prototype.update.call(this);
        if (this.active && this.index() >= 0) {
            // 当选择项改变时刷新右侧窗口
            if (this._index !== this._lastIndex) {
                this._lastIndex = this._index;
                this.callHandler('change');
            }
        }
    };

    // 敌群信息窗口（不再继承自Window_Selectable）
    function Window_EnemyInfo() {
        this.initialize.apply(this, arguments);
    }

    Window_EnemyInfo.prototype = Object.create(Window_Base.prototype);
    Window_EnemyInfo.prototype.constructor = Window_EnemyInfo;

    Window_EnemyInfo.prototype.initialize = function(rect) {
        if (Utils.RPGMAKER_NAME === 'MV') Window_Base.prototype.initialize.call(this, rect.x, rect.y, rect.width, rect.height);
        else Window_Base.prototype.initialize.call(this, rect);
        this._mapId = null;
        this._enemies = [];
        this._drops = {};
        this._mapData = null;
        this._bitmaps = {};
        this._lastMapId = 0;
		// 翻页相关属性
        this._currentPage = 0;
        this._pageItems = [];
	    this._inputCooldown = 0; // 新增输入冷却计时器
        
        // 添加：掉落物选择模式相关属性
        this._dropSelectMode = false; // 是否处于掉落物选择模式
        this._dropIndex = 0; // 当前选中的掉落物索引
        this._currentDrops = []; // 当前显示的掉落物列表
        this._dropPositions = []; // 掉落物位置信息
        
        this.refresh();
    };
    
    // 添加：激活掉落物选择模式
    Window_EnemyInfo.prototype.activateDropSelect = function() {
        this._dropSelectMode = true;
        this._dropIndex = 0; // 默认选中第一个掉落物
        this.refresh(); // 刷新以显示选择框
    };
    
    // 添加：取消掉落物选择模式
    Window_EnemyInfo.prototype.deactivateDropSelect = function() {
        this._dropSelectMode = false;
        this.refresh(); // 刷新以隐藏选择框
    };
    
    // 添加：获取当前选中的掉落物
    Window_EnemyInfo.prototype.selectedDrop = function() {
        if (this._currentDrops && this._currentDrops.length > 0 && 
            this._dropIndex >= 0 && this._dropIndex < this._currentDrops.length) {
            return this._currentDrops[this._dropIndex];
        }
        return null;
    };
    
    // 添加：获取当前掉落物索引
    Window_EnemyInfo.prototype.dropIndex = function() {
        return this._dropIndex;
    };
    
    // 添加：获取掉落物位置
    Window_EnemyInfo.prototype.dropPosition = function(index) {
        if (index >= 0 && index < this._dropPositions.length) {
            return this._dropPositions[index];
        }
        return null;
    };
    
    // 添加：处理掉落物选择模式下的输入
    Window_EnemyInfo.prototype.processDropSelect = function() {
    if (!this._dropSelectMode) return;
    if (this._inputCooldown > 0) {
        this._inputCooldown--;
        return;
    }
    const drops = this._currentDrops;
    if (drops.length <= 0) return;
    // 计算当前行列位置
    const dropsPerRow = this.dropColumns();
    const currentRow = Math.floor(this._dropIndex / dropsPerRow);
    const currentCol = this._dropIndex % dropsPerRow;
    
    // 计算总行数
    const totalRows = Math.ceil(drops.length / dropsPerRow);
    if (Input.isRepeated('down')) {
        // 向下移动到下一行的同一列
            const nextIndex = this._dropIndex + dropsPerRow;
            if (nextIndex < drops.length) {
				this._inputCooldown = 10;
                this._dropIndex = nextIndex;
                SoundManager.playCursor();
                this.refresh();
        }
    } else if (Input.isRepeated('up')) {
        // 向上移动到上一行的同一列
        let prevRow = this._dropIndex - dropsPerRow;
		if(prevRow < 0) prevRow = drops.length-1;
			this._inputCooldown = 10;
            this._dropIndex = prevRow;
            SoundManager.playCursor();
            this.refresh();
        
    } else if (Input.isRepeated('right')) {
        // 向右移动到同一行的下一列
        const nextCol = this._dropIndex + 1;
        if (nextCol < drops.length) {
			this._inputCooldown = 10;
                this._dropIndex = nextCol;
                SoundManager.playCursor();
                this.refresh();
        }
    } else if (Input.isRepeated('left')) {
        // 向左移动到同一行的上一列
        let prevCol = this._dropIndex - 1;
        if (prevCol < 0) prevCol = drops.length-1;
			this._inputCooldown = 10;
            this._dropIndex = prevCol;
            SoundManager.playCursor();
            this.refresh();
        
    }
};


Window_EnemyInfo.prototype.updatePageTurn = function() {
    if (this._pageItems.length <= 1) return; // 只有一页时不翻页
};
Window_EnemyInfo.prototype.nextPage = function() {
    if (this._pageItems.length <= 1) return;
    this._currentPage = (this._currentPage + 1) % this._pageItems.length;
    this.drawCurrentPage();
};

Window_EnemyInfo.prototype.prevPage = function() {
    if (this._pageItems.length <= 1) return;
    this._currentPage = (this._currentPage - 1 + this._pageItems.length) % this._pageItems.length;
    this.drawCurrentPage();
};
    Window_EnemyInfo.prototype.setMapId = function(mapId) {
        if (this._mapId !== mapId) {
            this._mapId = mapId;
			this._currentPage = 0;
			this._pageItems = [];
            this.loadMapData();
            this.refresh();
        }
    };

    // LRU of raw preview data only: never alter active $dataMap.
    const previewCache = new Map();
    // 直接读取地图JSON文件
    Window_EnemyInfo.prototype.loadMapData = function() {
    // 如果地图ID相同且已经加载过，则跳过
    if (this._lastMapId === this._mapId) return;
    this._lastMapId = this._mapId;
    
    this._enemies = [];
    this._drops = {};
    this._mapData = null;
    this._bitmaps = {};
    
    if (!this._mapId || this._mapId <= 0) return;
    
    try {
        // 获取地图设置
        const mapSetting = mapSettingsById[this._mapId];
        const unlocked = $gameSystem.isMapUnlocked(this._mapId);
        
        // 如果是隐藏地图且未解锁，则不加载数据
        if (mapSetting?.hidden && !unlocked) {
            return;
        }
        
        // 构建地图文件名
        const mapFilename = 'Map' + this._mapId.padZero(3) + '.json';
        const path = 'data/' + mapFilename;
        
        const requestedId = this._mapId;
        const generation = (this._previewGeneration || 0) + 1;
        this._previewGeneration = generation;
        const owner = SceneManager._scene;
        const applyPreview = (data) => {
            if (this._mapId !== requestedId || this._previewGeneration !== generation || SceneManager._scene !== owner) return;
            this._mapData = data;
            this.populatePreview(mapSetting);
            this._previewDirty = true;
        };
        if (previewCache.has(path)) {
            const data = previewCache.get(path);
            previewCache.delete(path); previewCache.set(path, data);
            applyPreview(data); return;
        }
        if (this._previewRequest) this._previewRequest.abort();
        const xhr = new XMLHttpRequest();
        this._previewRequest = xhr;
        xhr.open('GET', path, true);
        xhr.overrideMimeType('application/json');
        xhr.onload = () => {
            if (xhr.status !== 0 && xhr.status !== 200) { this._lastMapId = null; return; }
            try {
                const data = JSON.parse(xhr.responseText);
                previewCache.set(path, data);
                if (previewCache.size > 20) previewCache.delete(previewCache.keys().next().value);
                applyPreview(data);
            } catch (error) { console.warn('地图预览读取失败', error); this._lastMapId = null; }
        };
        xhr.onerror = () => { this._lastMapId = null; };
        xhr.send(null);
    } catch(error) { console.warn('地图预览失败', error); }
};

Window_EnemyInfo.prototype.populatePreview = function(mapSetting) {
    const requestedId = this._mapId;
    const generation = this._previewGeneration;
    const owner = SceneManager._scene;
    try {
        // 检查地图数据是否有效
        if (!this._mapData || !this._mapData.encounterList) {
            console.warn('地图数据格式无效，地图ID：', this._mapId);
            return;
        }
        
        // 准备所有需要处理的敌人ID
        const enemyIds = new Set();
        
        // 1. 添加地图敌群中的敌人
        for (const encounter of this._mapData.encounterList) {
            const troopId = encounter.troopId;
            if (troopId > 0 && $dataTroops[troopId]) {
                const troop = $dataTroops[troopId];
                if (troop && troop.members) {
                    for (const member of troop.members) {
                        if (member.enemyId > 0) {
                            enemyIds.add(member.enemyId);
                        }
                    }
                }
            }
        }
        
        // 2. 添加额外配置的敌人
        if (mapSetting && mapSetting.extraEnemies) {
            for (const enemyId of mapSetting.extraEnemies) {
                if (enemyId > 0) {
                    enemyIds.add(enemyId);
                }
            }
        }
        
        // 统一处理所有敌人
        for (const enemyId of enemyIds) {
            if ($dataEnemies[enemyId]) {
                const enemy = $dataEnemies[enemyId];
                if (enemy && !this._enemies.some(e => e.id === enemy.id)) {
                    this._enemies.push(enemy);
                    this._drops[enemy.id] = this.parseEnemyDrops(enemy);
                    
                    // 预加载敌人图片
                    const hue = enemy.battlerHue;
                    let bitmap;
                    
                    if ($gameSystem.isSideView()) {
                        if (Imported.YEP_X_AnimatedSVEnemies && enemy.sideviewBattler && enemy.sideviewBattler[0]) {
                            // 处理YEP动画SV敌人 - 需要特殊处理
                            const svName = Yanfly.Util.getRandomElement(enemy.sideviewBattler);
                            const sourceBitmap = ImageManager.loadSvActor(svName);
                            
                            // 添加加载监听器，等图片加载完成后再处理
                            const self = this;
                            sourceBitmap.addLoadListener(function() {
                                if (sourceBitmap.isReady()) {
                                    // 创建切割后的位图
                                    const cw = sourceBitmap.width / 9; // 假设9列
                                    const ch = sourceBitmap.height / 6; // 假设6行
                                    
                                    const frameBitmap = new Bitmap(cw, ch);
                                    frameBitmap.blt(
                                        sourceBitmap, 
                                        0, 0, cw, ch, // 源矩形(x,y,width,height)
                                        0, 0, cw, ch  // 目标矩形
                                    );
                                    
                                    if (self._mapId !== requestedId || self._previewGeneration !== generation || SceneManager._scene !== owner) return;
                                    self._bitmaps[enemy.id] = frameBitmap;
                                    if (self._mapId === requestedId && self._previewGeneration === generation && SceneManager._scene === owner) self._previewDirty = true;
                                }
                            });
                            
                            // 先设置为加载中的占位图
                            bitmap = ImageManager.loadSystem('IconSet');
                        } else {
                            // 标准SV敌人
                            bitmap = ImageManager.loadSvEnemy(enemy.battlerName, hue);
                        }
                    } else {
                        // 正面视图敌人
                        bitmap = ImageManager.loadEnemy(enemy.battlerName, hue);
                    }
                    
                    // 对于非YEP动画SV敌人，直接设置位图
                    if (bitmap && !(Imported.YEP_X_AnimatedSVEnemies && enemy.sideviewBattler && enemy.sideviewBattler[0])) {
                        this._bitmaps[enemy.id] = bitmap;
                        
                        // 添加图片加载监听器
                        const self = this;
                        bitmap.addLoadListener(function() {
                            if (self._mapId === requestedId && self._previewGeneration === generation && SceneManager._scene === owner) self._previewDirty = true;
                        });
                    }
                }
            }
        }
    } catch (e) {
        console.error("加载地图数据时出错:", e);
        this._enemies = [];
        this._drops = {};
        this._mapData = null;
        this._bitmaps = {};
    }
};

Window_EnemyInfo.prototype.parseEnemyDrops = function(enemy) {
    const drops = [];
    if (!enemy || !enemy.dropItems) return drops;
    // 计算基础掉落率
	var gameEnemy = new Game_Enemy(enemy.id,0,0);
    const baseRate = gameEnemy.dropItemRate()
    
    // 解析所有掉落物
    for (const dropItem of enemy.dropItems) {
        if (dropItem.kind === 0) continue; // 跳过无掉落物
        
        let type, item;
        switch (dropItem.kind) {
            case 1: // 道具
                type = 'Item';
                item = $dataItems[dropItem.dataId];
                break;
            case 2: // 武器
                type = 'Weapon';
                item = $dataWeapons[dropItem.dataId];
                break;
            case 3: // 防具
                type = 'Armor';
                item = $dataArmors[dropItem.dataId];
                break;
            default:
                continue;
        }
        
        if (!item || !item.name) continue;
        // 计算实际掉率
        const rate = Math.min(Math.round((1 / dropItem.denominator) * baseRate * 100000) / 1000, 100);
        
        drops.push({
            type: type,
            id: dropItem.dataId,
            rate: rate,
            item: item
        });
		drops.sort((a, b) => {
        const qualityA = parseInt(a.item.meta.quality || "1");
        const qualityB = parseInt(b.item.meta.quality || "1");
        return qualityB - qualityA; // 降序排列
    });
    }
    
    return drops;
};

Window_EnemyInfo.prototype.refresh = function() {
    this.contents.clear();
    
    if (this._mapId === null) {
        this.drawText("请从左侧选择地图", 0, 0, this.contentsWidth(), 'center');
        return;
    }
    // 获取地图设置
        const mapSetting = mapSettingsById[this._mapId];
        const unlocked = $gameSystem.isMapUnlocked(this._mapId);
        
        // 如果是隐藏地图且未解锁
        if (mapSetting?.hidden && !unlocked) {
            this.drawText("未解锁该地图", 0, 0, this.contentsWidth(), 'center');
            return;
        }
        
        if (!this._enemies || this._enemies.length === 0) {
            this.drawText("该地图没有敌人信息", 0, 0, this.contentsWidth(), 'center');
            return;
        }
    
    // 计算每个项目的高度
    this._itemHeights = [];
    for (let i = 0; i < this._enemies.length; i++) {
        this._itemHeights[i] = this.calcItemHeight(i);
    }
    
    // 分页逻辑
    this._pageItems = [];
    let currentPage = [];
    let currentHeight = 0;
    
    for (let i = 0; i < this._enemies.length; i++) {
        const itemHeight = this._itemHeights[i];
        
        // 如果添加当前项目会超过页面高度，则开始新页面
        if (currentHeight + itemHeight > this.contentsHeight() - this.lineHeight() * 2 && currentPage.length > 0) {
            this._pageItems.push(currentPage);
            currentPage = [];
            currentHeight = 0;
        }
        
        currentPage.push(i);
        currentHeight += itemHeight;
    }
    
    // 添加最后一页
    if (currentPage.length > 0) {
        this._pageItems.push(currentPage);
    }
    
    // 确保当前页码有效
    if (this._currentPage >= this._pageItems.length) {
        this._currentPage = 0;
    }
    // 重置翻页计时器
    this._pageTimer = 0;
    
    // 绘制当前页
    this.drawCurrentPage();
};
Window_EnemyInfo.prototype.drawCurrentPage = function() {
	this.contents.clear();
    this._currentDrops = []; // 重置当前掉落物列表
    this._dropPositions = []; // 重置掉落物位置
    
    if (this._pageItems.length === 0) return;
    
    const currentPage = this._pageItems[this._currentPage];
    let yPosition = 0;
    
    for (const index of currentPage) {
        this.drawItem(index, yPosition);
        yPosition += this._itemHeights[index];
    }
	// 在窗口底部添加传送提示文本
    const promptY = this.contentsHeight() - this.lineHeight();
    this.changeTextColor(this.systemColor());
	// 获取当前地图设置
    const mapSetting = mapSettingsById[this._mapId];
    // 根据地图设置显示不同的提示文本
	if(this._dropSelectMode || SceneManager._scene._ConfirmationMode){
    if (!mapSetting.canTransfer) {
        this.drawText("当前地图不可传送", 0, promptY, this.width, 'left');
    } else if (mapSetting.transferItem > 0) {
        const item = $dataItems[mapSetting.transferItem];
        
        if ($gameParty.hasItem(item)) {
            // 有传送道具时显示消耗提示
            this.drawText("A操作 / F传送，消耗 ", 0, promptY, this.width, 'left');
            const textWidth = this.textWidth("A操作 / F传送，消耗 ");
            this.drawItemName(item, textWidth, promptY, this.width - textWidth - 30, 'left');
            this.changeTextColor(this.systemColor());
			const nameWidth = this.textWidth(item.name);
            this.drawText("x1", textWidth+nameWidth+36, promptY, 30, 'left');
        } else {
            // 没有传送道具时显示错误提示
            this.drawText("A查看操作；传送需要 ", 0, promptY, this.width, 'left');
            const textWidth = this.textWidth("A查看操作；传送需要 ");
            this.drawItemName(item, textWidth, promptY, this.width - textWidth - 30, 'left');
            this.changeTextColor(this.systemColor());
			const nameWidth = this.textWidth(item.name);
            this.drawText("x1", textWidth+nameWidth+36, promptY, 30, 'left');
        }
    } else {
        // 没有传送消耗时显示普通提示
        this.drawText("A查看详情 / F传送", 0, promptY, this.width, 'left');
    }
	} else {
        this.drawText("A选择：传送至此／查看掉落", 0, promptY, this.width, 'left');
	}
    
    this.resetTextColor();
    // 绘制页码信息
    this.drawPageInfo();
};

Window_EnemyInfo.prototype.drawPageInfo = function() {
    if (this._pageItems.length <= 1) return; // 只有一页时不显示页码
	
	const text = `第 ${this._currentPage + 1}/${this._pageItems.length} 页（Q上一页 / E下一页）`;
    const width = this.textWidth(text);
    const x = (this.contentsWidth() - width);
    const y = this.contentsHeight() - this.lineHeight() * 2;
    this.drawText(text, x, y, width,'right');
    this.resetTextColor();
};

Window_EnemyInfo.prototype.processHandling = function() {
	const scene = SceneManager._scene;
    if (scene.isConfirmationActive && scene.isConfirmationActive()) return;
    if (this.isOpen() && this._dropSelectMode && this._pageItems.length > 1) {
        if (Input.isTriggered('pageup')) { this._dropIndex = 0; this.prevPage(); return; }
        if (Input.isTriggered('pagedown')) { this._dropIndex = 0; this.nextPage(); return; }
    }
	if (this._inputCooldown > 0) {
        this._inputCooldown--;
        return;
    }
    if (this.isOpen() && this.active && this._pageItems.length > 1 && !this._dropSelectMode) {
        if (Input.isTriggered('right')) {
            this.nextPage();
            this._inputCooldown = 10; // 设置10帧的冷却时间
        } else if (Input.isTriggered('left')) {
            this.prevPage();
            this._inputCooldown = 10;
        }
    }
    
    // 处理掉落物选择
    this.processDropSelect();
};

Window_EnemyInfo.prototype.update = function() {
    Window_Base.prototype.update.call(this);
    if (this._previewDirty) { this._previewDirty = false; this.refresh(); }
    this.updatePageTurn();
    this.processHandling(); // 处理手动翻页和掉落物选择
};

// 新增方法：计算单个项目的高度
Window_EnemyInfo.prototype.enemyColumnWidth = function() { return Math.min(230, Math.floor(this.contentsWidth() * 0.28)); };
Window_EnemyInfo.prototype.dropColumns = function() { return Math.max(1, Math.min(3, Math.floor((this.contentsWidth() - this.enemyColumnWidth() - 30) / 190))); };
Window_EnemyInfo.prototype.calcItemHeight = function(index) {
    if (!this._enemies || index >= this._enemies.length) {
        return 0;
    }
    
    const enemy = this._enemies[index];
    if (!enemy) return 0;
    
    const drops = this._drops[enemy.id] || [];
    const lineHeight = this.lineHeight();
    const padding = 10;
    
    // 计算左侧区域高度
    const hue = enemy.battlerHue;
    const bitmap = this._bitmaps[enemy.id] || ImageManager.loadSvEnemy(enemy.battlerName, hue);
    const imageHeight = bitmap && bitmap.isReady() ? bitmap.height * Math.min(0.5, this.enemyColumnWidth() / Math.max(1, bitmap.width), 120 / Math.max(1, bitmap.height)) : lineHeight * 2;
    const leftHeight = lineHeight + imageHeight + lineHeight + padding * 4;
    
    // 计算右侧区域高度
    const dropRows = Math.ceil(drops.length / this.dropColumns());
    const dropHeight = dropRows * (lineHeight + 10);
    const rightHeight = dropHeight + padding * 2;
    
    // 取左右区域中较高的值作为项目高度
    return Math.max(leftHeight, rightHeight);
};
	
	Window_EnemyInfo.prototype.formatHp = function(hp) {
    const units = ['', '万', '亿', '兆', '京'];
    let unitIndex = 0;
    
    while (hp >= 10000 && unitIndex < units.length - 1) {
        hp /= 10000;
        unitIndex++;
    }
    
    // 保留两位小数，但去掉多余的0
    let formatted = hp.toFixed(2);
    if (formatted.endsWith('.00')) {
        formatted = hp.toFixed(0);
    } else if (formatted.endsWith('0')) {
        formatted = hp.toFixed(1);
    }
    
    return formatted + units[unitIndex];
	};

    Window_EnemyInfo.prototype.drawItem = function(index, yPosition) {
    if (!this._enemies || index >= this._enemies.length) return;
    
    const enemy = this._enemies[index];
    if (!enemy) return;
    
    const height = this._itemHeights[index];
    const rect = new Rectangle(
        0,
        yPosition,
        this.contentsWidth(),
        height
    );
    
    // 其余绘制代码保持不变...
    const lineHeight = this.lineHeight();
    const padding = 10;
    const colWidth = this.enemyColumnWidth();
    
    // 左侧区域：怪物信息
    const leftRect = new Rectangle(
        rect.x + padding,
        rect.y + padding,
        colWidth,
        rect.height - padding * 2
    );
    
    // 右侧区域：掉落物信息
    const rightRect = new Rectangle(
        rect.x + colWidth + padding * 2,
        rect.y + padding,
        rect.width - colWidth - padding * 3,
        rect.height - padding * 2
    );
    
    // 绘制敌人名称
    this.drawText(enemy.name, leftRect.x, leftRect.y, leftRect.width);
    
    // 获取敌人图片
    const hue = enemy.battlerHue;
    const bitmap = this._bitmaps[enemy.id] || ImageManager.loadSvEnemy(enemy.battlerName, hue);
    
    // 图片位置
    const imageY = leftRect.y + lineHeight + 5;
    const scale = bitmap ? Math.min(0.5, colWidth / Math.max(1, bitmap.width), 120 / Math.max(1, bitmap.height)) : 1;
    if (bitmap && bitmap.isReady() && bitmap.width > 0 && bitmap.height > 0) {
        // 绘制敌人图片
        this.contents.blt(
            bitmap,
            0, 0, bitmap.width, bitmap.height,
            leftRect.x, imageY, 
            bitmap.width * scale, bitmap.height * scale
        );
    } else {
        // 图片未准备好时显示加载中文本
        this.drawText("(图片加载中...)", leftRect.x, imageY, 150);
    }
    
    // 绘制敌人血量 (使用格式化方法)
    const hp = enemy.params ? enemy.params[0] : enemy.hp;
    const hpY = imageY + (bitmap ? bitmap.height * scale : lineHeight) + 10;
    const hpText = `HP: ${this.formatHp(hp)}`;
    this.drawText(hpText, leftRect.x, hpY, leftRect.width);
    
    // 绘制掉落物信息 - 每行3个
    const drops = this._drops[enemy.id] || [];
    
    // 记录当前敌人掉落物（用于选择）
    const startIndex = this._currentDrops.length;
    this._currentDrops = this._currentDrops.concat(drops);
	
    const dropStartY = rightRect.y;
    const columns = this.dropColumns();
    const dropWidth = (rightRect.width - padding * (columns - 1)) / columns;
    const dropHeight = lineHeight + 10; // 每个掉落物高度
    if (drops.length > 0) {
        // 每行最多3个掉落物
        for (let i = 0; i < drops.length; i++) {
            const col = i % columns;
            const row = Math.floor(i / columns);
            
            const dropX = rightRect.x + col * (dropWidth + padding);
            const dropY = dropStartY + row * dropHeight;
            const globalIndex = startIndex + i;
            // 记录掉落物位置（全局坐标）
            this._dropPositions.push({
                x: this.x + this.padding + dropX + (this.parent ? this.parent.x : 0),
                y: this.y + this.padding + dropY + (this.parent ? this.parent.y : 0),
                width: dropWidth
            });
            
            // 确保在可见区域内
            if (dropY < rightRect.y + rightRect.height) {
                this.drawDropItem(drops[i], dropX, dropY, dropWidth);
                
                // 如果处于掉落物选择模式且是当前选中的掉落物，绘制选择框
                if (this._dropSelectMode && globalIndex === this._dropIndex) {
                    const dropRect = new Rectangle(dropX, dropY, dropWidth, lineHeight);
                    this.drawSelectionRect(dropRect);
                }
            }
        }
    } else {
        this.drawText("没有掉落物品", rightRect.x, dropStartY, rightRect.width);
    }
};

// 添加：绘制选择框
Window_EnemyInfo.prototype.drawSelectionRect = function(rect) {
    const padding = 2;
    const color = '#FFFF00'; // 黄色选择框
    const width = rect.width + padding * 2;
    const height = rect.height + padding * 2;
    
    // 绘制选择框
    this.contents.fillRect(rect.x - padding, rect.y - padding, width, 2, color); // 上边框
    this.contents.fillRect(rect.x - padding, rect.y + rect.height, width, 2, color); // 下边框
    this.contents.fillRect(rect.x - padding, rect.y - padding, 2, height, color); // 左边框
    this.contents.fillRect(rect.x + rect.width + padding, rect.y - padding, 2, height, color); // 右边框
};

    // 绘制单个掉落物 (一行显示)
Window_EnemyInfo.prototype.drawDropItem = function(drop, x, y, width) {
    const lineHeight = this.lineHeight();
    const iconSize = Window_Base._iconWidth;
    
    // 绘制物品图标
    this.drawIcon(drop.item.iconIndex, x, y);
    
    // 绘制物品名称
    const textX = x + iconSize;
    const textWidth = width - iconSize - 60; // 保留空间给掉落率
    
    // 名称过长时截断
    const name = drop.item.name.length > 12 ? 
        drop.item.name.substring(0, 11) + "..." : 
        drop.item.name;
			var ici;
        	if (drop.item.meta.ici != null) {
        		ici = Number(drop.item.meta.ici);
        	}else {
        		ici = 1;
        	};
			this.changeTextColor(this.itemColor(ici));
    this.drawText(name, textX, y, textWidth);
    
    // 绘制掉落率
    const rateX = x + width - 60;
    this.drawText(`${drop.rate.toFixed(2)}%`, rateX, y, 60, 'right'); // 保留两位小数
	this.resetTextColor();
};

// Dedicated detail page: does not rely on the floating item-help sprite,
// therefore it remains readable on both small and large map-transfer layouts.
function Window_DropDetail() { this.initialize.apply(this, arguments); }
Window_DropDetail.prototype = Object.create(Window_Base.prototype);
Window_DropDetail.prototype.constructor = Window_DropDetail;
Window_DropDetail.prototype.initialize = function(rect) {
    if (Utils.RPGMAKER_NAME === 'MV') Window_Base.prototype.initialize.call(this, rect.x, rect.y, rect.width, rect.height);
    else Window_Base.prototype.initialize.call(this, rect);
};
Window_DropDetail.prototype.setDrop = function(drop) {
    this._drop = drop;
	this._affixPage = 0;
    this.refresh();
};
// 地图掉落预览不能预知随机词条；显示它们容易让玩家误以为是必定属性。
// 这里仅从装备本体 note 中提取固定的专属、特效、套装/成长说明。
Window_DropDetail.prototype.standardFontSize = function() { return 22; };
Window_DropDetail.prototype.lineHeight = function() { return 30; };
Window_DropDetail.prototype.plainText = function(text) {
    return String(text || '').replace(/\\[cCiI]\[\d+\]/g, '').replace(/\\[{}]/g, '').replace(/[\r\n]+/g, ' ').replace(/[：:]/g, '：').trim();
};
Window_DropDetail.prototype.noteEffects = function(item) {
    var rows = [], re = /<pos=APs\s+text=([\s\S]*?)\s+(?:size|color|line|align)=/gi, match;
    while ((match = re.exec(String(item.note || '')))) {
        var text = this.plainText(match[1]);
        if (!text || /^(?:品质|类别|类型|等级需求|价格|售价|购买价格|出售价格|基础属性|进度)[：:]/.test(text)) continue;
        if (rows.indexOf(text) < 0) rows.push(text);
    }
    return rows;
};
Window_DropDetail.prototype.fixedTraitLines = function(item) {
    if (!item) return [];
    var rows = this.noteEffects(item), that = this, seenSkills = {};
    function add(text) { text = that.plainText(text); if (text && rows.indexOf(text) < 0) rows.push(text); }
    // Authored equipment help carries unique effects. Native granted skills and
    // permanent passives additionally expose their real descriptions, not scripts.
    (item.traits || []).forEach(function(trait) {
        if (trait.code !== 43 || seenSkills[trait.dataId]) return;
        var skill = $dataSkills[trait.dataId]; if (!skill || !skill.name) return;
        seenSkills[trait.dataId] = true;
        add('获得技能：' + skill.name);
        var help = that.noteEffects(skill);
        if (help.length) help.forEach(add);
        else add(skill.description);
    });
    (item.passiveStates || []).forEach(function(id) {
        var state = $dataStates[id]; if (!state || !state.name) return;
        add('常驻效果：' + state.name);
        that.noteEffects(state).forEach(add);
        var text = /<(?:StateNote|STATE_HELP|ステートヘルプ)>([\s\S]*?)<\/(?:StateNote|STATE_HELP|ステートヘルプ)>/i.exec(state.note || '');
        add(text ? text[1] : state.description);
    });
    (item.effects || []).forEach(function(effect) {
        var amount = [];
        if (effect.code === 11 || effect.code === 12) {
            if (effect.value1) amount.push(Math.round(effect.value1 * 10000) / 100 + '%最大' + (effect.code === 11 ? '生命' : '魔法'));
            if (effect.value2) amount.push(String(effect.value2));
            add((effect.code === 11 ? '恢复生命：' : '恢复魔法：') + amount.join('＋'));
        }
        if (effect.code === 13) add('恢复怒气：' + effect.value1);
        if (effect.code === 21 && $dataStates[effect.dataId]) add('附加状态：' + $dataStates[effect.dataId].name + '（' + Math.round(effect.value1 * 100) + '%）');
        if (effect.code === 22 && $dataStates[effect.dataId]) add('解除状态：' + $dataStates[effect.dataId].name);
        if (effect.code === 43 && $dataSkills[effect.dataId]) add('学会技能：' + $dataSkills[effect.dataId].name);
    });
    // Native traits also matter when an older item has no authored help rows.
    if (!rows.length) {
        var params = ['生命','魔法','物攻','物防','魔攻','魔防','敏捷','幸运'];
        var extra = ['命中率','闪避率','暴击率','暴击闪避','魔法闪避','魔法反射','反击率','生命再生','魔法再生','怒气再生'];
        (item.traits || []).forEach(function(t) {
            var percent = Math.round(t.value * 10000) / 100;
            if (t.code === 21 && t.value !== 1) add(params[t.dataId] + '×' + percent + '%');
            if (t.code === 22 && t.value) add(extra[t.dataId] + (t.value > 0 ? '＋' : '') + percent + '%');
            if (t.code === 14 && $dataStates[t.dataId]) add('免疫：' + $dataStates[t.dataId].name);
            if (t.code === 33 && t.value) add('攻击速度' + (t.value > 0 ? '＋' : '') + t.value);
            if (t.code === 34 && t.value) add('攻击次数' + (t.value > 0 ? '＋' : '') + t.value);
        });
    }
    if (/<(?:Prefixes|Suffixes)>/i.test(item.note || '')) add('随机词条以实际掉落为准。');
    return rows;
};
Window_DropDetail.prototype.typeName = function(drop) {
    var item = drop.item, subtype;
    if (drop.type === 'Weapon') { subtype = $dataSystem.weaponTypes[item.wtypeId]; return '武器' + (subtype ? '·' + subtype : ''); }
    if (drop.type === 'Armor') { subtype = $dataSystem.armorTypes[item.atypeId]; return (item.etypeId === 17 ? '神武' : '防具') + (subtype ? '·' + subtype : ''); }
    return item.itypeId === 2 ? '重要物品' : item.consumable ? '消耗品' : '道具';
};
Window_DropDetail.prototype.wrapLines = function(text, width) {
    var lines = [], line = '';
    Array.from(this.plainText(text)).forEach(function(char) {
        if (line && this.textWidth(line + char) > width) { lines.push(line); line = ''; }
        line += char;
    }, this);
    if (line) lines.push(line);
    return lines;
};
Window_DropDetail.prototype.nextAffixPage = function() {
    if (this._detailPages && this._affixPage < this._detailPages.length - 1) { this._affixPage++; this.refresh(); SoundManager.playCursor(); }
};
Window_DropDetail.prototype.previousAffixPage = function() {
    if (this._affixPage > 0) { this._affixPage--; this.refresh(); SoundManager.playCursor(); }
};
Window_DropDetail.prototype.refresh = function() {
    this.contents.clear();
    var drop = this._drop, item = drop && drop.item;
    if (!item) return;
    var width = this.contentsWidth(), lh = this.lineHeight(), y = lh + 8;
    this.contents.fontSize = 25;
    this.drawIcon(item.iconIndex || 0, 4, y);
    this.resetTextColor(); this.drawText(item.name || '未知物品', 44, y, width - 48);
    this.contents.fontSize = this.standardFontSize(); y += lh + 10;
    var columns = 3, column = Math.floor(width / columns), quality = window.CodexQuality ? CodexQuality.name(item) : '普通';
    this._detailMetadata = ['掉落率：' + (Math.round(Number(drop.rate || 0) * 1000) / 1000) + '%', '类型：' + this.typeName(drop), '品质：' + quality];
    this._detailMetadata.forEach(function(text, i) { this.changeTextColor(i === 2 && window.CodexQuality ? CodexQuality.color(item) : this.normalColor()); this.drawText(text, i * column + 4, y, column - 8); }, this);
    this.resetTextColor(); y += lh + 8;
    var stats = [];
    (item.params || []).forEach(function(value, i) { if (value) stats.push({label:['生命','魔法','物攻','物防','魔攻','魔防','敏捷','幸运'][i],value:(value > 0 ? '＋' : '') + value}); });
    this._detailStats = stats;
    if (stats.length) {
        this.changeTextColor(this.systemColor()); this.drawText('基础属性', 4, y, width - 8); y += lh;
        var count = width >= 740 ? 4 : 2, cell = Math.floor(width / count);
        stats.forEach(function(s, i) { var sx = i % count * cell + 8, sy = y + Math.floor(i / count) * lh; this.changeTextColor(this.systemColor()); this.drawText(s.label, sx, sy, 52); this.resetTextColor(); this.drawText(s.value, sx + 54, sy, cell - 70, 'right'); }, this);
        y += Math.ceil(stats.length / count) * lh + 8;
    }
    this.changeTextColor(this.systemColor()); this.drawText(item.params ? '固定特效' : '使用效果', 4, y, width - 8); this.resetTextColor(); y += lh;
    var effects = this.fixedTraitLines(item), lines = [];
    if (!effects.length) effects = [item.params ? '无额外固定特效' : '无额外使用效果'];
    effects.forEach(function(text) { Array.prototype.push.apply(lines, this.wrapLines('• ' + text, width - 16)); }, this);
    var room = Math.max(1, Math.floor((this.contentsHeight() - lh - 8 - y) / lh));
    this._detailPages = [];
    for (var i = 0; i < lines.length; i += room) this._detailPages.push(lines.slice(i, i + room));
    this._affixPage = Math.min(this._affixPage || 0, this._detailPages.length - 1);
    this._detailPages[this._affixPage].forEach(function(line, i) { this.drawText(line, 8, y + i * lh, width - 16); }, this);
    this.changeTextColor(this.systemColor()); this.drawText('掉落物详情  ' + (this._affixPage + 1) + '/' + this._detailPages.length, 0, 0, width, 'center');
    var footer = this.contentsHeight() - lh;
    this.changePaintOpacity(this._affixPage > 0); this.drawText('◀ 上一页', 0, footer, width / 3, 'center'); this.changePaintOpacity(true);
    this.drawText('A/B 返回', width / 3, footer, width / 3, 'center');
    this.changePaintOpacity(this._affixPage < this._detailPages.length - 1); this.drawText('下一页 ▶', width * 2 / 3, footer, width / 3, 'center'); this.changePaintOpacity(true); this.resetTextColor();
};

    // 添加插件指令
    const _Game_Interpreter_pluginCommand = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function(command, args) {
        _Game_Interpreter_pluginCommand.call(this, command, args);
        if (command === 'OpenMapTransfer') {
            SceneManager.push(Scene_MapTransfer);
        }
		else if (command === 'UnlockMapTransfer') {
            const mapId = parseInt(args[0]);
            if (mapId) $gameSystem.unlockMap(mapId);
        }
        else if (command === 'LockMapTransfer') {
            const mapId = parseInt(args[0]);
            if (mapId) $gameSystem.lockMap(mapId);
        }
    };
	window.Scene_MapTransfer = Scene_MapTransfer;
})();

// The normal plugin list does not reliably load newly added plugin files on an
// existing save.  MapTransferPlugin is already enabled in this build, so use it
// as a safe bootstrap for the Boss status HUD without replacing plugins.js.
(function() {
    if (window.CodexBossStatusSummaryLoaded || document.getElementById('codex-boss-status-summary')) return;
    var script = document.createElement('script');
    script.id = 'codex-boss-status-summary';
    script.src = 'js/plugins/Codex_BossStatusSummary.js?v=0.1.5';
    script.onerror = function() { console.warn('Codex BossStatusSummary file could not be loaded'); };
    document.body.appendChild(script);
})();
