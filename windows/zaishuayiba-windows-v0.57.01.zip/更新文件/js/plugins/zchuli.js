// 独立装备数组优化脚本
// 【Claude·未经Codex检验】v0.31 重写：
// 原写法只收集「队伍成员身上＋背包」的独立装备并深拷贝重新编号，仓库（PH_Warehouse）里存的装备、
// 不在队伍里的角色身上的装备和各模块按ID记的台账都没跟着改号——仓库记录指向空位或别的装备，
// 存进去的装备在清理后直接丢失。现改为：收集所有仍被引用的独立装备，保留原对象只改编号，
// 再把每一处按ID记录的地方同步改成新编号；没有任何引用的才视为垃圾丢弃。
(function() {
    'use strict';

    function isIndependentId(kind, id) {
        var base = kind === 'weapon' ? DataManager._baseWeaponsLength : DataManager._baseArmorsLength;
        return Number(id) >= base;
    }
    function database(kind) { return kind === 'weapon' ? $dataWeapons : $dataArmors; }

    function Collector() {
        this.order = { weapon: [], armor: [] };
        this.seen = { weapon: {}, armor: {} };
    }
    Collector.prototype.add = function(kind, id) {
        id = Number(id);
        if (!isIndependentId(kind, id) || this.seen[kind][id]) return;
        var item = database(kind)[id];
        if (!item || item.id !== id || !item.baseItemId) return;
        this.seen[kind][id] = true;
        this.order[kind].push(item);
    };

    function allActors() {
        return ($gameActors && $gameActors._data || []).filter(function(a) { return a && a._equips; });
    }
    function equipKind(ref) {
        if (!ref) return null;
        if (ref._dataClass === 'weapon') return 'weapon';
        if (ref._dataClass === 'armor') return 'armor';
        return null;
    }
    function warehouses() {
        var ph = window.PHPlugins && PHPlugins.PHWarehouse;
        var all = ph && ph._warehouses || {};
        return Object.keys(all).map(function(k) { return all[k]; }).filter(function(w) { return w && w.items; });
    }
    function alienLedger() { return $gameSystem && $gameSystem._alienLedger || null; }

    function collect() {
        var c = new Collector();
        // 1) 所有角色身上（含不在队伍、角色仓库、隐藏角色）
        allActors().forEach(function(actor) {
            actor._equips.forEach(function(ref) { var k = equipKind(ref); if (k) c.add(k, ref._itemId); });
        });
        // 2) 背包
        Object.keys($gameParty._weapons || {}).forEach(function(id) { c.add('weapon', id); });
        Object.keys($gameParty._armors || {}).forEach(function(id) { c.add('armor', id); });
        // 3) 仓库
        warehouses().forEach(function(w) {
            (w.items.weapon || []).forEach(function(id) { c.add('weapon', id); });
            (w.items.armor || []).forEach(function(id) { c.add('armor', id); });
        });
        // 4) v0.30 隐藏专武台账、异化待选
        Object.keys($gameParty._codexHiddenWeapons29 || {}).forEach(function(id) { c.add('weapon', id); });
        ($gameParty._codexHiddenWeaponSlots29 || []).forEach(function(r) { if (r) c.add('weapon', r.itemId); });
        var ledger = alienLedger();
        if (ledger && ledger.pending) c.add(ledger.pending.kind === 'w' ? 'weapon' : 'armor', ledger.pending.id);
        // 5) 星神仓库「传出」标记的对象
        var to = $gameParty.ToGEq;
        if (to && to.baseItemId) c.add(DataManager.isWeapon(to) ? 'weapon' : 'armor', to.id);
        return c;
    }

    function remapKeys(obj, map) {
        if (!obj) return obj;
        var out = {};
        Object.keys(obj).forEach(function(id) {
            var to = map[id] !== undefined ? map[id] : Number(id);
            out[to] = (out[to] || 0) + obj[id];
        });
        return out;
    }
    function remapId(map, id) { return map[id] !== undefined ? map[id] : id; }

    DataManager.cleanupIndependentItems = function() {
        //console.log('开始处理cleanupIndependentItems')
        var c = collect();
        var map = { weapon: {}, armor: {} };
        var start = { weapon: DataManager._baseWeaponsLength, armor: DataManager._baseArmorsLength };
        ['weapon', 'armor'].forEach(function(kind) {
            c.order[kind].forEach(function(item, i) {
                var newId = start[kind] + i;
                map[kind][item.id] = newId;
                item.id = newId;
            });
        });

        // 数据表：保留原对象，只按新顺序重排
        DataManager._independentWeapons = c.order.weapon.slice();
        DataManager._independentArmors = c.order.armor.slice();
        if (Yanfly.Param.ItemMaxWeapons > 0) {
            $dataWeapons.splice(start.weapon, $dataWeapons.length - start.weapon);
            DataManager.setIndependentLength($dataWeapons);
            $dataWeapons = $dataWeapons.concat(DataManager._independentWeapons);
        }
        if (Yanfly.Param.ItemMaxArmors > 0) {
            $dataArmors.splice(start.armor, $dataArmors.length - start.armor);
            DataManager.setIndependentLength($dataArmors);
            $dataArmors = $dataArmors.concat(DataManager._independentArmors);
        }

        // 背包：没有被收集的独立ID（数据已不存在）丢弃，其余改号
        ['weapon', 'armor'].forEach(function(kind) {
            var key = kind === 'weapon' ? '_weapons' : '_armors';
            var next = {};
            Object.keys($gameParty[key] || {}).forEach(function(id) {
                if (isIndependentId(kind, id)) {
                    if (map[kind][id] === undefined) return;
                    next[map[kind][id]] = $gameParty[key][id];
                } else {
                    next[id] = $gameParty[key][id];
                }
            });
            $gameParty[key] = next;
        });

        // 所有角色身上：直接改Game_Item里的ID，不走卸下再装（避免等级/条件导致装不回去）
        allActors().forEach(function(actor) {
            var touched = false;
            actor._equips.forEach(function(ref) {
                var k = equipKind(ref);
                if (!k || !isIndependentId(k, ref._itemId)) return;
                if (map[k][ref._itemId] !== undefined) ref._itemId = map[k][ref._itemId];
                else ref._itemId = 0;
                touched = true;
            });
            if (touched) actor.refresh();
        });

        // 仓库：items列表、数量与本体记录一起改号
        warehouses().forEach(function(w) {
            ['weapon', 'armor'].forEach(function(kind) {
                var ids = w.items[kind] || [], qtty = w.qtty && w.qtty[kind] || {};
                var bases = w.base && w.base[kind];
                var nextIds = [], nextQtty = {}, nextBases = bases ? {} : null, lost = 0;
                ids.forEach(function(id) {
                    var n = Number(qtty[id]) || 0;
                    if (isIndependentId(kind, id) && map[kind][id] === undefined) { lost += n; return; }
                    var to = remapId(map[kind], id);
                    if (nextIds.indexOf(to) < 0) nextIds.push(to);
                    nextQtty[to] = (nextQtty[to] || 0) + n;
                    if (nextBases && bases[id] !== undefined) nextBases[to] = bases[id];
                });
                w.items[kind] = nextIds;
                if (w.qtty) w.qtty[kind] = nextQtty;
                if (nextBases) w.base[kind] = nextBases;
                if (lost) w.currentCapacity = Math.max(0, (w.currentCapacity || 0) - lost);
            });
        });

        // 台账
        if ($gameParty._codexHiddenWeapons29) $gameParty._codexHiddenWeapons29 = remapKeys($gameParty._codexHiddenWeapons29, map.weapon);
        ($gameParty._codexHiddenWeaponSlots29 || []).forEach(function(r) { if (r) r.itemId = remapId(map.weapon, r.itemId); });
        var ledger = alienLedger();
        if (ledger && ledger.pending) ledger.pending.id = remapId(ledger.pending.kind === 'w' ? map.weapon : map.armor, ledger.pending.id);

        // 刷新队伍状态（保留原脚本的满血满蓝）
        $gameParty.members().forEach(function(actor) {
            if (!actor) return;
            actor.gainHp(actor.mhp);
            actor.gainMp(actor.mmp);
            actor.refresh();
        });
        DataManager._lastIndependentCleanup = { weapons: c.order.weapon.length, armors: c.order.armor.length };
        console.log('独立装备优化完成。武器:' + c.order.weapon.length + ' 防具:' + c.order.armor.length);
    };
})();
