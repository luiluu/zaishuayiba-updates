// 【Codex·未经Claude检验】v0.05 单次AI决策内重复伤害评估缓存；未经claude检验。
/*:
 * @plugindesc 智能挂机AI：按战局选择技能、目标、治疗与增减益；设置中开关。
 * @author Codex
 * @help 开启后仅接管自动战斗。按可用技能和实时战况判断职责，适用于不同角色与站位。
 * 同时比较单体、群体和随机目标技能；根据击杀机会、抗性、资源与敌方威胁评分。
 * 治疗、复活、解控和增减益只在目标能得到实际收益时使用。
 * 奈叶的小魔炮自动选择六档实际炮击，不弹出玩家选择框。
 * 玩家在挂机菜单指定的技能顺序优先于智能选择。
 * 比较有效伤害、治疗、资源和准备行动的后续收益；评分不执行未知脚本。
 */
(function() {
    'use strict';
    ConfigManager.codexSmartAI = true;
    var makeData = ConfigManager.makeData;
    ConfigManager.makeData = function() {
        var data = makeData.apply(this, arguments);
        data.codexSmartAI = this.codexSmartAI;
        return data;
    };
    var applyData = ConfigManager.applyData;
    ConfigManager.applyData = function(data) {
        applyData.apply(this, arguments);
        this.codexSmartAI = data.codexSmartAI === undefined ? true : !!data.codexSmartAI;
    };
    var options = Window_Options.prototype.addGeneralOptions;
    Window_Options.prototype.addGeneralOptions = function() {
        options.apply(this, arguments);
        this.addCommand('智能战斗AI（自动战斗）', 'codexSmartAI');
    };
    function actionFor(actor, item, isItem, target) {
        var action = new Game_Action(actor);
        if (isItem) action.setItem(item.id); else action.setSkill(item.id);
        if (target) action.setTarget(target.index());
        action._codexSmart = true;
        return action;
    }
    function canUse(actor, item) {
        // Custom MP Cost in this game mutates _costmp even during checks.
        var had = Object.prototype.hasOwnProperty.call(actor, '_costmp');
        var prior = actor._costmp;
        try { return actor.canUse(item); }
        finally { if (had) actor._costmp = prior; else delete actor._costmp; }
    }
    function previewCost(actor, item, method) {
        // Some installed cost plugins write _costmp while merely asking for
        // the price. Scoring must not change the next real action's cost.
        var had = Object.prototype.hasOwnProperty.call(actor, '_costmp');
        var prior = actor._costmp;
        try { return actor[method] ? Number(actor[method](item)) || 0 : 0; }
        catch (e) { return 0; }
        finally { if (had) actor._costmp = prior; else delete actor._costmp; }
    }
    function mastery(actor,item) { var id=typeof item==='number'?item:item.id;return Math.max(0,Number(actor._skillMasteryLevels && actor._skillMasteryLevels[id])||0); }
    function level(actor) { return Number(actor && (actor.level || actor._level) || 0); }
    function learned(actor, id) { return !!(actor && actor.isLearnedSkill && actor.isLearnedSkill(id)); }
    // 小魔炮(5692) only opens a six-choice common event. Auto battle must
    // select the actual attack instead of opening that player-only menu.
    var cannonPower = {5703:.3, 5704:.6, 5705:.9, 5706:.3, 5708:.6, 5709:.9};
    function cannonOptions(actor) {
        if (!actor.actorId || actor.actorId() !== 108 || !learned(actor, 5692) ||
                !$dataSkills[5692] || !canUse(actor, $dataSkills[5692])) return [];
        return Object.keys(cannonPower).map(function(id) { return $dataSkills[Number(id)]; })
            .filter(function(skill) { return skill && canUse(actor, skill); })
            .map(function(skill) { return {item:skill, isItem:false}; });
    }
    function boosts(actor, item) {
        if (!actor || !actor.actorId || !item) return 1;
        var id = actor.actorId(), multiplier = 1;
        if (id === 168 && item.id >= 10140 && item.id <= 10151) {
            if (level(actor) >= 30 && learned(actor, 10144)) multiplier *= 7.66;
            if (level(actor) >= 70 && Number(actor._AdvancedNum || 0) >= 3 &&
                    learned(actor, 10164)) multiplier *= 2;
        } else if (id === 167 && item.id >= 10122 && item.id <= 10126) {
            if (window.CodexRaven && window.CodexRaven.damageMultiplier) {
                multiplier *= window.CodexRaven.damageMultiplier(actor, item);
            }
            if (level(actor) >= 25 && learned(actor, 10132)) multiplier *= 1.15;
            if (level(actor) >= 60 && Number(actor._codexRavenStage || 0) >= 5 &&
                    learned(actor, 10136)) multiplier *= 4.25;
        }
        return multiplier;
    }
    function safeDamage(actor, target, item, action) {
        var nativeProfile=profile(actor,item,action);
        var formula = String(item.damage && item.damage.formula || '0');
        var power = actor.actorId && actor.actorId() === 108 && cannonPower[item.id];
        var cannonHits = 1;
        if (power) {
            // YEP pays the percentage cost before evaluating damage. The
            // post-damage effect repeats once per full 2000 MP committed.
            var beforeMp = Math.max(0, Number(actor.mp) || 0);
            var paidMp = previewCost(actor, item, 'skillMpCost');
            cannonHits = Math.max(1, Math.floor(beforeMp * power / 2000));
            actor = Object.create(actor);
            Object.defineProperty(actor, 'mp', {value:Math.max(0, beforeMp - paidMp)});
        }
        var value;
        // Both actors use controlled runtime damage functions. Treat those as
        // known estimators instead of rejecting their formulas as unknown JS.
        if (item.id >= 10140 && item.id <= 10151 &&
                /^CodexMira\.damage\(a,b,\d+\)$/.test(formula) &&
                window.CodexMira && window.CodexMira.damage) {
            // 实战由统一伤害按攻防比例处理防御（米拉公式此时不扣固定防御）；预估保持同一口径。
            var unified = window.CodexDamage && CodexDamage.defenseRate ? CodexDamage : null, calculating = unified && unified.isCalculating;
            try {
                if (unified) unified.isCalculating = function() { return true; };
                try { value = window.CodexMira.damage(actor, target, item.id); }
                finally { if (unified) unified.isCalculating = calculating; }
                if (unified) {
                    var physicalRate = unified.defenseRate(actor.atk, target.def), magicalRate = unified.defenseRate(actor.mat, target.mdf);
                    value *= [10142, 10143, 10149].indexOf(item.id) >= 0 ? magicalRate :
                        [10146, 10147, 10151].indexOf(item.id) >= 0 ? (physicalRate + magicalRate) / 2 : physicalRate;
                }
            } catch (e) { value = 0; }
        } else if (item.id >= 10122 && item.id <= 10126 &&
                window.CodexRaven && window.CodexRaven.legionStrikeRate &&
                window.CodexRaven.defenseFactor) {
            var known = formula.replace(/CodexRaven\.legionStrikeRate\(a\)/g, '1')
                .replace(/CodexRaven\.skillCoefficient\(a,\s*1012[2-6]\)/g, '1')
                .replace(/CodexRaven\.(?:defenseFactor|defenseDeduction)\(a\)/g, '1')
                .replace(/b\.hpRate\(\)/g, '1')
                .replace(/(?:a|b)\.(?:atk|def|mhp|mat|mdf|mmp)\b/g, '1');
            if (/^[\d\s.+*/()%\-]+$/.test(known)) {
                try {
                    value = Function('a', 'b', 'CodexRaven', 'return (' + formula + ');')
                        (actor, target, window.CodexRaven);
                } catch (e) { value = 0; }
            }
        } else if (item.id >= 10171 && item.id <= 10174 &&
                /^CodexYomi\.damage\(a,b,1017[1-4]\)$/.test(formula) &&
                window.CodexYomi && window.CodexYomi.damage) {
            try { value = window.CodexYomi.damage(actor, target, item.id); }
            catch (e) { value = 0; }
        } else if (item.id >= 10187 && item.id <= 10193 &&
                /^CodexJingliu\.damage\(a,b,101(?:8[7-9]|9[0-3])\)$/.test(formula) &&
                window.CodexJingliu && window.CodexJingliu.damage) {
            var previous = BattleManager._action;
            try {
                BattleManager._action = action || null;
                value = window.CodexJingliu.damage(actor, target, item.id);
            } catch (e) { value = 0; }
            finally { BattleManager._action = previous; }
        } else if (item.id >= 10216 && item.id <= 10219 &&
                /^CodexToji\.damage\(a,b,1021[6-9],this\)$/.test(formula) &&
                window.CodexToji && window.CodexToji.damage) {
            try { value = window.CodexToji.damage(actor, target, item.id, action); }
            catch (e) { value = 0; }
        } else if ((item.id === 10227 || item.id === 10228) &&
                /^CodexHeartsteel\.damage\(a,b,this\)$/.test(formula) &&
                window.CodexHeartsteel) {
            var hsBase = ((item.id === 10228 ? 1000 : 700) +
                Math.max(0, Number(actor.mhp) || 0) * (item.id === 10228 ? 0.08 : 0.06)) *
                (window.CodexHeartsteel.castScale ? window.CodexHeartsteel.castScale(actor) : 1);
            value = Math.max(0, hsBase - Math.min(Math.max(0, Number(target.def) || 0), hsBase * 0.5));
        } else if (item.id >= 10229 && item.id <= 10233 &&
                /^CodexSukuna\.damage\(a,b,102(?:29|30|31|32|33),this\)$/.test(formula) &&
                window.CodexSukuna && window.CodexSukuna.damage) {
            if (item.id === 10232 && !(target._codexSukunaTarget && target._codexSukunaTarget.charged)) return 0;
            if (item.id === 10233 && !(actor._codexSukuna && actor._codexSukuna.prep > 0)) return 0;
            try { value = window.CodexSukuna.damage(Object.create(actor), Object.create(target), item.id, action); }
            catch (e) { value = 0; }
        } else if (item.id >= 10250 && item.id <= 10263 &&
                /^CodexGarou\.base\(a,b,102(?:5[0-9]|6[0-3])\)$/.test(formula) &&
                window.CodexGarou && window.CodexGarou.base) {
            var garou = window.CodexGarou, active = garou._action;
            try {
                garou._action = null;
                value = garou.base(actor, target, item.id);
                var form = garou.form(actor), layers = Math.max(0, Number(actor._garouEvolution) || 0);
                var extra = garou.gear(actor) ? form.relic.evolution_bonus_per_stack_percent : 0;
                value *= 1 + layers * (form.passives.evolution_base_per_stack_percent + extra) / 100;
            } catch (e) { value = 0; }
            finally { garou._action = active; }
        }
        // 新角色模块登记的估算器（CodexTusu、CodexXuan 等）：返回原始公式值；未登记的技能照旧。 // CODEX_AI_ESTIMATORS
        if (value === undefined && window.CodexAIEstimators) {
            for (var ei = 0; ei < CodexAIEstimators.length && value === undefined; ei++) {
                try { var ev = CodexAIEstimators[ei](actor, target, item, action, formula); if (ev !== undefined) value = Number(ev) || 0; } catch (e) { value = 0; }
            }
        }
        // Restrict estimates to arithmetic and known readonly references.
        if (value === undefined) {
            formula = formula.replace(/Math\.random\(\)/g, '0.5');
            var stripped = formula.replace(/user\.skillMasteryLevel\(item\.id\)/g, '1')
                .replace(/(?:a|b|user|target)\.isStateAffected\(\d+\)/g, '1')
                .replace(/(?:a|b|user|target)\.hpRate\(\)/g, '1')
                .replace(/(?:a|b|user|target)\.(?:mhp|mmp|hp|mp|tp|atk|def|mat|mdf|agi|luk|level|hit|cri)\b/g, '1')
                .replace(/v\[\d+\]/g, '1')
                .replace(/Math\.(?:floor|ceil|round|max|min|abs|pow|sqrt)\b/g, '1');
            if (!/^[\d\s.+*/()%\-,?:<>=!&|]+$/.test(stripped) || /(?:^|[^=!<>])=(?!=)|\+\+|--/.test(stripped)) return 0;
            try {
                var view=Object.create(actor);view.skillMasteryLevel=function(s){return mastery(actor,s);};
                value = Function('a', 'b', 'user', 'target', 'item', 'v', 'return (' + formula + ');')
                    (view, target, view, target, item, $gameVariables._data);
            } catch (e) { return 0; }
        }
        try {
            var rate = item.damage.elementId > 0 ? target.elementRate(item.damage.elementId) : 1;
            var defense = item.damage.type===3 || item.damage.type===4 ? 1 : item.hitType === 1 ? target.pdr : item.hitType === 2 ? target.mdr : 1;
            if(nativeProfile.pierce && defense<1)defense+=nativeProfile.pierce*(1-defense);
            var repeats = action && action.numRepeats ? Number(action.numRepeats()) : Number(item.repeats);
            repeats=(repeats||1)*(nativeProfile.hits||sequenceHits(actor,item));
            var masteryLevel=mastery(actor,item);
            var masteryNote=/<Custom Damage Mastery Formula:\s*value\s*\*\s*\(1\s*\+\s*level\s*\*\s*([\d.]+)\)\s*>/i.exec(item.note||'');
            var masteryRate=masteryNote?1+masteryLevel*Number(masteryNote[1]):1+masteryLevel*0.10;
            // Native skill/element modifiers are readonly summaries. No action
            // application, random draw, cost payment or common event runs here.
            var extraRate=nativeProfile.multiplier||1;
            if(item.damage.type===1 && actor._passiveCache)extraRate*=Math.max(0,1+number(actor._passiveCache.globalHarmRi,0));
            return Math.max(0, Number(value) || 0) * rate * defense *
                Math.max(1, Math.min(32, repeats || 1)) * cannonHits * boosts(actor, item) * extraRate * masteryRate *
                (window.CodexImportedBalance && [1,2,5,6].indexOf(item.damage.type)>=0 ? window.CodexImportedBalance.outgoingRate(actor) : 1);
        } catch (e) { return 0; }
    }
    var decisionDamage=null;
    function expectedDamage(actor,target,item,action){
        if(!decisionDamage)return expectedDamageRaw(actor,target,item,action);
        var byActor=decisionDamage.get(actor);if(!byActor){byActor=new WeakMap();decisionDamage.set(actor,byActor);}var byTarget=byActor.get(target);if(!byTarget){byTarget=new Map();byActor.set(target,byTarget);}
        var key=[item.id,actor.hp,actor.mp,actor.tp,target.hp,target.mp,target.tp,action._targetIndex,action.isAttack()].join('|');
        if(byTarget.has(key))return byTarget.get(key);var value=expectedDamageRaw(actor,target,item,action);byTarget.set(key,value);return value;
    }
    function expectedDamageRaw(actor, target, item, action) {
        var damage = safeDamage(actor, target, item, action);
        if (damage <= 0) return 0;
        try {
            var hit = Math.max(0, Math.min(1, action.itemHit(target))) *
                (1 - Math.max(0, Math.min(1, action.itemEva(target))));
            var crit = item.damage.critical ? Math.max(0, Math.min(1, action.itemCri(target))) : 0;
            var bonus = 0;
            if (actor.actorId() === 168 && level(actor) >= 40 && learned(actor, 10145)) bonus = 9.99;
            if (actor.actorId() === 167 && item.id >= 10122 && item.id <= 10126 &&
                    level(actor) >= 45 && learned(actor, 10134)) bonus = 9.99;
            // 原游戏的暴击倍率可因装备变化；这里只估算共同的基础增量。
            // 渡鸦神话期间的伤害倍率（与战力模型相同）。
            if (actor.actorId() === 167 && item.meta && item.meta.CodexRavenDamage && actor._codexRavenMythTurns > 0 && learned(actor, 10136)) damage *= 1.85;
            return damage * hit * (1 + crit * (0.5 + bonus));
        } catch (e) { return damage; }
    }
    function hardFight(actor, skills, foes) {
        return foes.some(function(target) {
            var best = 0;
            skills.forEach(function(skill) {
                if (!skill.damage || skill.damage.type !== 1 || skill.id === 10146 || skill.id === 10127) return;
                var action = actionFor(actor, skill, false);
                if (action.isForOpponent()) best = Math.max(best, expectedDamage(actor, target, skill, action));
            });
            return target.hp > Math.max(1, best) * 1.5;
        });
    }
    function outputActors() {
        return $gameParty.battleMembers().filter(function(actor) {
            return actor.skills().some(function(s) {
                return s.scope > 0 && s.damage && [1,5].indexOf(s.damage.type) >= 0;
            });
        });
    }
    function scheduledSkill(actor) {
        var table = $gameParty && $gameParty._XdRsData_hangUp_ActSkill;
        if (!table || !$gameTroop || !window.Star || !Star.NumToThreeNum) return false;
        var key = actor.name() + Star.NumToThreeNum($gameTroop._turnCount);
        var id = Number(table[key]);
        var skill = id && $dataSkills[id];
        return skill && canUse(actor, skill) &&
            (id <= 2 || actor.skills().some(function(entry) { return entry.id === id; })) ? skill : null;
    }
    function nanohaFallback(actor) {
        if (!actor.actorId || actor.actorId() !== 108 || !learned(actor, 5692)) return null;
        var attack = $dataSkills[actor.attackSkillId()], guard = $dataSkills[actor.guardSkillId()];
        if (attack && canUse(actor, attack)) return actionFor(actor, attack, false);
        if (guard && canUse(actor, guard)) return actionFor(actor, guard, false);
        return null;
    }
    function harmfulState(state) {
        if (!state) return false;
        var tag = /<BuffType\s*:\s*([^>]+)>/i.exec(state.note || '');
        if (tag && /(减益|异常|削弱|debuff|诅咒|毒|破甲|封印|眩晕)/i.test(tag[1])) return true;
        if (tag && /(增益|强化|buff)/i.test(tag[1])) return false;
        if (Number(state.restriction) > 0) return true;
        if ((state.traits || []).some(function(t) {
            return t.code === 21 && Number(t.value) < 1 ||
                t.code === 22 && Number(t.value) < 0;
        })) return true;
        return /(中毒|诅咒|流血|灼伤|眩晕|沉默|封印|虚弱|破甲|麻痹|失明)/.test(state.name || '');
    }
    function threat(target, foes) {
        function power(t) { return Math.max(1, Number(t.atk || 0) + Number(t.mat || 0) + Number(t.agi || 0) * 0.3); }
        var highest = foes.reduce(function(n, foe) { return Math.max(n, power(foe)); }, 1);
        var boss = target._bosshp_meter || target.enemy && target.enemy() &&
            target.enemy().meta && (target.enemy().meta.boss || target.enemy().meta.Boss);
        return Math.min(1.4, 0.8 + 0.35 * power(target) / highest + (boss ? 0.15 : 0));
    }
    function damageUtility(target, damage, foes, context) {
        var hp = Math.max(1, (Number(target.hp)||0)+shieldPoints(target));
        var effective = Math.min(hp, Math.max(0, damage));
        if (!effective) return 0;
        // 目标血量远大于单次伤害时，按血量比例的分数趋近 0；再按本回合自己最强的伤害折算，
        // 让伤害技能之间、伤害与增益之间仍能正常比较（当前回合的最强伤害为 4000，低于施加增益的 5000；准备后的未来伤害可超过 4000，用于判断是否值得先变身/强化）。
        var relative = context && context.damageScale > 0 ? 4000 * effective / context.damageScale : 0;
        return threat(target, foes) * (11000 * effective / hp +
            (damage >= hp ? 7000 : 0) + relative);
    }
    var profileAdapters = [];
    function registerProfile(fn) { if (profileAdapters.indexOf(fn) < 0) profileAdapters.push(fn); }
    function profile(actor, item, action) {
        for (var n=0;n<profileAdapters.length;n++) {
            var result=profileAdapters[n](actor,item,action);
            if (result) return result;
        }
        return {};
    }
    function number(value, fallback) { return Number.isFinite(Number(value)) ? Number(value) : fallback; }
    function shieldPoints(target) { return Math.max(0,number(target._shield,0))+Math.max(0,number(target._permBarrier,0))+(target._turnBarrier||[]).reduce(function(n,v){return n+Math.max(0,number(v,0));},0); }
    function shieldEstimate(actor,target,item) {
        var formula=String(item.damage&&item.damage.formula||''), match=/^(?:b|target)\.addShield\((.+)\)\s*;\s*0\s*$/.exec(formula);
        if(!match && actor===target)match=/^(?:a|user)\.addShield\((.+)\)\s*;\s*0\s*$/.exec(formula);
        var total=(item.targetBarrier||[]).reduce(function(n,v){return n+Math.max(0,number(v,0));},0);
        if(match) {
            var expr=match[1], stripped=expr.replace(/(?:a|b|user|target)\.(?:mhp|mmp|hp|mp|atk|def|mat|mdf|agi|luk|level)\b/g,'1').replace(/Math\.(?:floor|ceil|round|max|min|abs|pow|sqrt)\b/g,'1');
            if(/^[\d\s.+*/()%\-,]+$/.test(stripped))try { total+=Math.max(0,Number(Function('a','b','user','target','return ('+expr+');')(actor,target,actor,target))||0)*(1+(target.shieldEffectBonus?target.shieldEffectBonus():0)); }catch(e){}
        }
        return total;
    }
    function unitRate(target, key) { return Math.max(0,number(target[key],1)); }
    function sequenceHits(actor,item) {
        var steps=(item.wholeActions||[]).concat(item.targetActions||[]), stack=[], active=true, count=0;
        steps.forEach(function(step) {
            var name=String(step[0]).toUpperCase(), condition=(step[1]||[]).join(',');
            if (name==='IF') {
                var matched=/^(?:user|a)\._skills\.includes\((\d+)\)$/.exec(condition);
                var state=/^(?:user|a)\.isStateAffected\((\d+)\)$/.exec(condition);
                stack.push({parent:active,truth:matched?learned(actor,Number(matched[1])):state?actor.isStateAffected(Number(state[1])):false});
                active=active && stack[stack.length-1].truth;
            } else if (name==='ELSE' && stack.length) {
                active=stack[stack.length-1].parent && !stack[stack.length-1].truth;
            } else if ((name==='END' || name==='END IF') && stack.length) active=stack.pop().parent;
            else if (name==='ACTION EFFECT' && active) count++;
        });
        return Math.max(1,count);
    }
    function usefulCommonEvent(id) {
        // Only plain parameter growth attached to a normal attack is known safe.
        // Do not evaluate events, scripts, choices, shops or transfers while planning.
        var ev=typeof $dataCommonEvents!=='undefined' && $dataCommonEvents[id];
        return ev && ev.list && ev.list.every(function(c){return c.code===0 || c.code===108 || c.code===408 || c.code===317;});
    }
    function legalCandidate(actor,item,isItem) {
        if (!item || !item.scope || /<Hide in Battle>/i.test(item.note||'') || !canUse(actor,item)) return false;
        return !(item.effects||[]).some(function(e){return e.code===44 &&
            (isItem || !item.damage || ![1,2,5,6].includes(item.damage.type) || !usefulCommonEvent(e.dataId));});
    }
    function healingAmount(actor,target,item,isItem,action,mp) {
        var type=mp?4:3, code=mp?12:11, max=mp?target.mmp:target.mhp;
        var amount=item.damage && item.damage.type===type ? safeDamage(actor,target,item,action) * unitRate(target,'rec') : 0;
        (item.effects||[]).forEach(function(e) {
            if (e.code===code) amount+=(max*number(e.value1,0)+number(e.value2,0))*unitRate(target,'rec')*(isItem?unitRate(actor,'pha'):1);
        });
        return Math.max(0,amount);
    }
    function recoveryUtility(actor,target,item,isItem,action) {
        if (action.isForDeadFriend() && target.isDead()) {
            var revives=(item.effects||[]).some(function(e){return e.code===22 && e.dataId===1;});
            return revives || item.damage && item.damage.type===3 ? 60000 : 0;
        }
        if (!target.isAlive()) return 0;
        var max=Math.max(1,target.mhp),missing=Math.max(0,max-target.hp),rate=Math.min(1,(target.hp+shieldPoints(target))/max),score=0;
        var heal=healingAmount(actor,target,item,isItem,action,false),effective=Math.min(missing,heal);
        // Tiny scratches do not warrant a whole action. Emergency healing is
        // evaluated independently of formation, identity and damage capability.
        if (missing/max>=0.18 || rate<0.4) {
            var urgency=rate<0.25?6:rate<0.4?3.5:rate<0.6?2.2:rate<0.82?1:0.2;
            score+=28000*effective/max*urgency;
            if (rate<0.25 && effective/max>=0.10) score+=22000;
        }
        var missingMp=Math.max(0,target.mmp-target.mp),mp=healingAmount(actor,target,item,isItem,action,true);
        if (target.mp/Math.max(1,target.mmp)<0.45 && missingMp>0)
            score+=6500*Math.min(missingMp,mp)/Math.max(1,target.mmp);
        var tp=(item.effects||[]).filter(function(e){return e.code===13;}).reduce(function(v,e){return v+number(e.value1,0);},0);
        var maxTp=target.maxTp?target.maxTp():100;
        if (target.tp<maxTp*0.4 && target.skills().some(function(s){return s.tpCost>0;}))
            score+=3000*Math.min(maxTp-target.tp,tp)/Math.max(1,maxTp);
        return score;
    }
    function benefit(actor,target,item,action,context) {
        var score=0;
        (item.effects||[]).forEach(function(e) {
            var state=$dataStates[e.dataId],harmful=harmfulState(state);
            if (e.code===21 && e.dataId>1 && harmful===action.isForOpponent() &&
                    !target.isStateAffected(e.dataId) && !target.isStateResist(e.dataId) &&
                    !(window.CodexBossDifficulty && CodexBossDifficulty.hasHyperArmor(target) && CodexBossDifficulty.isControlState(e.dataId))) {
                var probability=Math.min(1,Math.max(0,number(e.value1,0))*target.stateRate(e.dataId));
                var control=state && state.restriction>0;
                var value=action.isForOpponent()?(control?11000:4200):5000;
                score+=value*probability*(context.longFight?1:0.18);
            }
            if (e.code===22 && e.dataId>1 && target.isStateAffected(e.dataId) && !(window.CodexBossDifficulty && e.dataId===CodexBossDifficulty.armorStateId && CodexBossDifficulty.hasHyperArmor(target))) {
                if (action.isForFriend() && harmful) score+=state && state.restriction>0?40000:16000;
                if (action.isForOpponent() && !harmful) score+=7000;
            }
            var paramWeight=[0.1,0.1,1,1,1,1,0.25,0.25][e.dataId];if(paramWeight===undefined)paramWeight=1;
            if (e.code===31 && action.isForFriend() && (target._buffs[e.dataId]||0)<2)
                score+=2200*paramWeight*(2-(target._buffs[e.dataId]||0))*(context.longFight?1:0.1);
            if (e.code===32 && action.isForOpponent() && (target._buffs[e.dataId]||0)>-2)
                score+=3000*paramWeight*(2+(target._buffs[e.dataId]||0))*(context.longFight?1:0.2);
            if (e.code===33 && action.isForOpponent() && (target._buffs[e.dataId]||0)>0) score+=6500;
            if (e.code===34 && action.isForFriend() && (target._buffs[e.dataId]||0)<0) score+=16000;
        });
        return score;
    }
    function costMultiplier(actor,item,isItem) {
        if (isItem) return 0.65;
        var mp=previewCost(actor,item,'skillMpCost'),tp=previewCost(actor,item,'skillTpCost'),hp=previewCost(actor,item,'skillHpCost');
        var after=(actor.hp-hp)/Math.max(1,actor.mhp);
        var danger=hp>0 && after<0.25?4:hp>0 && after<0.5?1.6:0;
        return 1/(1+0.25*mp/Math.max(1,actor.mmp)+0.6*mp/Math.max(1,actor.mp)+
            0.25*tp/Math.max(1,actor.maxTp())+0.35*tp/Math.max(1,actor.tp)+
            1.5*hp/Math.max(1,actor.hp)+danger);
    }
    function scoreCandidate(actor,candidate,context) {
        var item=candidate.item,action=actionFor(actor,item,candidate.isItem),p=profile(actor,item,action);
        var targets=action.isForOpponent()?context.foes:action.isForUser()?[actor]:context.friends.filter(function(t){return action.isForDeadFriend()?t.isDead():t.isAlive();});
        if(p.targetAllowed)targets=targets.filter(function(t){return p.targetAllowed(t,context);});
        if (!targets.length) return {score:0,action:action};
        var rows=targets.map(function(target) {
            var score=action.isForFriend()?recoveryUtility(actor,target,item,candidate.isItem,action):0,hitDamage=0,hitScore=0;
            if(action.isForFriend()) { var shields=shieldEstimate(actor,target,item),gap=Math.max(0,target.mhp*0.8-shieldPoints(target));score+=16000*Math.min(gap,shields)/Math.max(1,target.mhp)*(context.longFight?1:0.12); }
            score+=benefit(actor,target,item,action,context);
            if(p.targetUtility)score+=number(p.targetUtility(target,context),0);
            if (action.isForOpponent() && item.damage && [1,5].includes(item.damage.type)) {
                hitDamage=expectedDamage(actor,target,item,action);hitScore=damageUtility(target,hitDamage,context.foes,context);score+=hitScore;
                if (p.splash && !action.isForAll()) context.foes.forEach(function(other) {
                    if(other!==target)score+=damageUtility(other,expectedDamage(actor,other,item,action)*p.splash,context.foes,context);
                });
            } else if(action.isForOpponent() && item.damage && [2,6].includes(item.damage.type))
                score+=4000*Math.min(target.mp,expectedDamage(actor,target,item,action))/Math.max(1,target.mmp);
            return {target:target,score:score,hitDamage:hitDamage,hitScore:hitScore};
        });
        var best=rows.reduce(function(a,b){return b.score>a.score?b:a;},rows[0]),total=rows.reduce(function(a,b){return a+b.score;},0);
        var random=action.isForRandom && action.isForRandom();
        var score=action.isForAll()?total:random?0:best.score;
        if(random) {
            var totalWeight=targets.reduce(function(n,t){return n+Math.max(0,number(t.tgr,1));},0)||targets.length;
            var n=Math.max(1,action.numTargets()),weighted=0;
            // 每段独立选目标：伤害按期望段数 n×w 计（目标少于段数时多段落在同一目标上），附加效果按至少命中一次计。
            targets.forEach(function(t,i){var w=Math.max(0,number(t.tgr,1))/totalWeight,r=rows[i];weighted+=(r.score-r.hitScore)*(1-Math.pow(1-w,n))+(r.hitDamage>0?damageUtility(t,r.hitDamage*n*w,context.foes,context):0);});
            score=weighted*0.9; // repeated random hits must not count the same kill twice
        }
        if(p.ongoingSkill && $dataSkills[p.ongoingSkill] && !context.noSetup){var ongoing=$dataSkills[p.ongoingSkill],oa=actionFor(actor,ongoing,false);
            context.foes.forEach(function(t){try{score+=damageUtility(t,expectedDamage(actor,t,ongoing,oa)*number(p.ongoingRounds,1)*0.8,context.foes,context);}catch(e){}});}
        score*=costMultiplier(actor,item,candidate.isItem);
        if(p.holdInLongFight&&context.longFight&&!context.urgent)score=0;
        if (!candidate.isItem && !context.longFight && item.cooldown && item.cooldown[item.id]>0)score*=0.94;
        if (!context.noSetup && (p.followupSkill || p.futureActor)) {
            var future=Object.create(p.futureActor||actor);future._mp=Math.max(0,actor.mp-previewCost(actor,item,'skillMpCost'));future._tp=Math.max(0,actor.tp-previewCost(actor,item,'skillTpCost'));future._hp=Math.max(1,actor.hp-previewCost(actor,item,'skillHpCost'));future._cooldownTurns=Object.assign({},actor._cooldownTurns);future._warmupTurns=Object.assign({},actor._warmupTurns);var followups=p.followupSkill?[$dataSkills[p.followupSkill]]:future.skills();
            var futureBest=0;
            followups.forEach(function(s) {
                if(!s || !s.damage || ![1,2,5,6].includes(s.damage.type) || (!p.followupSkill && !legalCandidate(future,s,false)))return;
                var next=scoreCandidate(future,{item:s,isItem:false},Object.assign({},context,{noSetup:true}));
                futureBest=Math.max(futureBest,next.score);
            });
            if(!context.noSetup) {
                var steps=Math.max(1,number(p.setupActions,1)+1);
                // Set-up must pay for the action it consumes and exceed the
                // immediate option; the same rule serves weapons and forms.
                // 铺垫后的强化持续 duration 次行动：按铺垫与受益行动的平均收益比较（duration 缺省为1，即原公式）。
                var span=Math.max(1,number(p.duration,1));
                score=Math.max(score,(score+futureBest*span)/(steps-1+span)*0.92*(context.urgent?0.6:1));
            }
        }
        action.setTarget(best.target.index());
        if(p.prepareTarget)p.prepareTarget(best.target,context);
        if(action.isForAll()||random)action._targetIndex=-1;
        return {score:score,action:action,target:best.target};
    }
    function choose(actor,cannonOnly) {
        var nativeRandom=Math.random,blackRandom=window.CodexBlackFlash&&CodexBlackFlash.random,fixed=function(){return .5;};
        Math.random=fixed;if(window.CodexBlackFlash)CodexBlackFlash.random=fixed;
        var previousDamage=decisionDamage;decisionDamage=new WeakMap();try{return chooseScored(actor,cannonOnly);}finally{decisionDamage=previousDamage;Math.random=nativeRandom;if(window.CodexBlackFlash)CodexBlackFlash.random=blackRandom;}
    }
    function chooseScored(actor,cannonOnly) {
        var friends=actor.friendsUnit().members(),foes=actor.opponentsUnit().aliveMembers();
        var skills=actor.skills().filter(function(s){return legalCandidate(actor,s,false) && s.id!==5692;});
        var attack=$dataSkills[actor.attackSkillId()];
        if(!cannonOnly && legalCandidate(actor,attack,false) && !skills.some(function(s){return s.id===attack.id;}))skills.push(attack);
        var candidates=skills.map(function(s){return {item:s,isItem:false};}),cannons=cannonOptions(actor);
        if(cannonOnly)candidates=cannons;
        else if(cannons.length)candidates=candidates.filter(function(c){return !cannonPower[c.item.id];}).concat(cannons);
        var urgent=friends.some(function(t){return t.isDead()||t.isAlive()&&(t.hp+shieldPoints(t))/Math.max(1,t.mhp)<0.25;}),context={friends:friends,foes:foes,urgent:urgent,longFight:false};
        // 本回合可用伤害技能对任一敌人的最大期望伤害，作为伤害分的相对基准。
        var damageScale=0;candidates.forEach(function(c){var it=c.item;if(c.isItem||!it.damage||[1,5].indexOf(it.damage.type)<0)return;var act=actionFor(actor,it,false);if(!act.isForOpponent())return;var reps=act.isForRandom&&act.isForRandom()?Math.max(1,act.numTargets()/Math.max(1,foes.length)):1;foes.forEach(function(t){try{damageScale=Math.max(damageScale,expectedDamage(actor,t,it,act)*reps);}catch(e){}});});context.damageScale=damageScale;
        var bestAttack=0;
        candidates.forEach(function(c){if(c.item.damage && [1,5].includes(c.item.damage.type))bestAttack=Math.max(bestAttack,scoreCandidate(actor,c,Object.assign({},context,{noSetup:true})).score);});
        // A whole encounter that one available action can finish is short.
        context.longFight=foes.length>0 && bestAttack<foes.reduce(function(n,t){return n+damageUtility(t,t.hp+shieldPoints(t),foes);},0)*0.92;
        if(!cannonOnly)$gameParty.items().forEach(function(item) {
            if(item.consumable && legalCandidate(actor,item,true) && (item.effects||[]).some(function(e){return [11,12,22,34].includes(e.code);}))candidates.push({item:item,isItem:true});
        });
        var best=null,bestScore=0,ranking=[];
        candidates.forEach(function(c){var result=scoreCandidate(actor,c,context);ranking.push({id:c.item.id,item:c.isItem,score:Math.round(result.score),target:result.action._targetIndex});if(result.score>bestScore){bestScore=result.score;best=result.action;}});
        if(!best && !cannonOnly && foes.length && legalCandidate(actor,attack,false))best=actionFor(actor,attack,false,foes.reduce(function(a,b){return b.hp<a.hp?b:a;},foes[0]));
        if(!best && !cannonOnly){var guard=$dataSkills[actor.guardSkillId()];if(guard && canUse(actor,guard))best=actionFor(actor,guard,false,actor);}
        if(best && cannonOnly)best._codexSmartScheduledCannon=true;
        if(best)actor._codexLastAIDecision={skill:best.item().name,id:best.item().id,target:best._targetIndex,score:bestScore,candidates:ranking.sort(function(a,b){return b.score-a.score;}).slice(0,6)};
        return best;
    }
    // Existing script mechanics describe their affordances here. They do not
    // choose actions: every profile uses the same benefit/cost comparison.
    registerProfile(function(actor,item) {
        if(actor.actorId()===169) return {splash:({10172:0.33,10173:0.5,10174:0.66})[item.id]||0};
        // 神灶：开会立即结束领域；领域到期时原生会以满准备层数自动施放，长战斗中不提前手动收尾。
        if(actor.actorId()===172 && item.id===10233 && actor._codexSukuna && actor._codexSukuna.domain>0) return {holdInLongFight:true};
        if(actor.actorId()===167 && item.id===10127 && !actor._codexRavenMythTurns) {
            var view=Object.create(actor);view._codexRavenMythTurns=3;
            return {futureActor:view,setupActions:1,duration:3};
        }
        if(actor.actorId()===172 && item.id===10231 && !actor.isStateAffected(2636)) {
            var domain=Object.create(actor);domain._states=actor._states.concat([2636]);
            return {futureActor:domain,setupActions:0,ongoingSkill:10237,ongoingRounds:4};
        }
        if(actor.actorId()===168 && item.id===10146) {
            var dragon=Object.create(actor);dragon._states=actor._states.concat([2592]);
            return {futureActor:dragon,setupActions:0,followupSkill:10151};
        }
        return null;
    });
    var oldMakeAction = Game_Actor.prototype.makeAction;
    Game_Actor.prototype.makeAction = function() {
        if (ConfigManager.codexSmartAI) {
            try {
                var scheduled = scheduledSkill(this);
                if (scheduled) {
                    if (scheduled.id === 5692) {
                        var cannon = choose(this, true) || choose(this);
                        if (cannon) return cannon;
                        var fallback = nanohaFallback(this);
                        if (fallback) return fallback;
                    }
                    return oldMakeAction.apply(this, arguments);
                }
                var action = choose(this);
                if (action) return action;
                var fallback = nanohaFallback(this);
                if (fallback) return fallback;
            }
            catch (e) { console.warn('智能AI已回退到原挂机逻辑', e); }
        }
        return oldMakeAction.apply(this, arguments);
    };
    // Native character runtimes wrap startAction and inspect currentAction
    // before calling our original wrapper. Refresh on the first read so all
    // those runtimes see the same final action and attach their casts to it.
    var currentAction = Game_Actor.prototype.currentAction;
    Game_Actor.prototype.currentAction = function() {
        var current = currentAction.apply(this, arguments);
        if (!ConfigManager.codexSmartAI || BattleManager._subject !== this ||
                !current || !current._codexSmart || current._codexSmartReviewed || current._forcing) return current;
        current._codexSmartReviewed = true;
        try {
            var action = current._codexSmartScheduledCannon ?
                (choose(this, true) || choose(this)) : choose(this);
            if (action) {
                action._codexSmartReviewed = true;
                var slot = this._actions ? this._actions.indexOf(current) : -1;
                this.setAction(slot >= 0 ? slot : 0, action);
                return action;
            }
        } catch (e) { console.warn('智能AI重新评估失败，保留原动作', e); }
        return current;
    };
    window.CodexSmartAI = { choose: choose, safeDamage: safeDamage, outputActors: outputActors, registerProfile: registerProfile, profile: profile, sequenceHits: sequenceHits, score: scoreCandidate, version: 2 };
})();
