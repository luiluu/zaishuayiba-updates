/*:
 * @plugindesc v0.4.0 Boss状态面板（异常/增益分区、回合与层数、分页说明）
 * @author Codex
 * @help
 * 仅显示当前敌群中仍存活且已现身的原生 Boss。
 * 点击状态栏展开，点击异常/增益标签筛选，点击条目查看完整效果。
 * 状态说明、原生叠层及计数只读；不参与战斗结算。
 * 【Claude·未经Codex检验】选项菜单「Boss状态面板」可关闭本面板（默认开启，Boss 血条不受影响）。
 */
(function() {
    'use strict';
    var Root = window;
    if (Root.CodexBossStatusSummaryLoaded) return;
    Root.CodexBossStatusSummaryLoaded = true;
    var BAR_HEIGHT = 96, CARD_HEIGHT = 68, BODY_Y = 82, FOOTER_HEIGHT = 34;
    var COLOR = { ink:'#ffffff', muted:'#c9ced8', edge:'rgba(255,255,255,0.28)', blue:'#84aaff', bad:'#ff8f86', good:'#98e598' }; // 与原生窗口文字/系统色一致
    var LABELS = ['生命','魔法','物攻','物防','魔攻','魔防','敏捷','幸运'];
    var XPARAM = ['命中率','闪避率','暴击率','暴击闪避','魔法闪避','魔法反射','反击率','生命再生','魔法再生','怒气再生'];
    var SPARAM = ['被锁定率','防御效果','恢复效果','药理知识','魔法消耗','怒气充能','物理承伤','魔法承伤','地形承伤','经验获取'];
    var pointer = null;
    // Options toggle; undefined in old config files means on.
    ConfigManager.codexBossStatusPanel = true;
    function enabled() { return ConfigManager.codexBossStatusPanel !== false; }
    var makeConfig = ConfigManager.makeData, applyConfig = ConfigManager.applyData;
    ConfigManager.makeData = function() { var data = makeConfig.apply(this, arguments); data.codexBossStatusPanel = enabled(); return data; };
    ConfigManager.applyData = function(data) { applyConfig.apply(this, arguments); this.codexBossStatusPanel = !data || data.codexBossStatusPanel !== false; };
    var makeOptions = Window_Options.prototype.makeCommandList, changeOption = Window_Options.prototype.changeValue;
    Window_Options.prototype.makeCommandList = function() { makeOptions.apply(this, arguments); this.addCommand('Boss状态面板', 'codexBossStatusPanel'); };
    Window_Options.prototype.changeValue = function(symbol, value) { var before = ConfigManager[symbol], result = changeOption.apply(this, arguments); if (symbol === 'codexBossStatusPanel' && before !== ConfigManager[symbol]) ConfigManager.save(); return result; };
    function alive(enemy) {
        return !!(enemy && enemy.isEnemy && enemy.isEnemy() && !enemy.isDead() && !enemy.isHidden());
    }
    function isBoss(enemy) {
        if (!alive(enemy)) return false;
        if (typeof enemy._codexBossDifficultyBoss==='boolean') return enemy._codexBossDifficultyBoss;
        var id = enemy.enemyId(), data = $dataEnemies[id];
        // Use the same database roster/note identity as the native HP HUD and
        // difficulty system. Do not infer a boss from HP, sprite or its name.
        if (typeof Moghunter !== 'undefined' && Moghunter.boss_list) {
            for (var i=1;i<=Moghunter.boss_list_length;i++) {
                if (Number(Moghunter.boss_list[i]) === id) return true;
            }
        }
        return !!(data && /<boss(?:\s*:[^>]*)?\s*>|BOSS级怪物/i.test(data.note || ''));
    }
    function locateBoss(scene) {
        var members = $gameTroop && $gameTroop.members ? $gameTroop.members() : [];
        var bosses = members.filter(isBoss);
        if (!bosses.length) return null;
        var targetWindow = scene && scene._enemyWindow;
        var target = targetWindow && targetWindow.active && targetWindow.enemy ? targetWindow.enemy() : null;
        var hud = scene && scene._bosshp_sprites;
        var temp = $gameTemp && $gameTemp._battler_bhp_temp && $gameTemp._battler_bhp_temp[0];
        var previous = scene && scene._codexBossStatusOverlay && scene._codexBossStatusOverlay._battler;
        var preferred = [target, temp, hud && hud._battler, previous];
        for (var i=0;i<preferred.length;i++) if (bosses.indexOf(preferred[i])>=0) return preferred[i];
        return bosses[0];
    }
    function clean(text) {
        return String(text || '').replace(/(?:\\|\x1b)[A-Za-z]+\[[^\]]*\]/g,'').replace(/<[^>]+>/g,'').trim();
    }
    function noteBlock(note, tag) {
        var found = new RegExp('<'+tag+'\\s*>([\\s\\S]*?)<\\/'+tag+'\\s*>','i').exec(String(note || ''));
        return found ? clean(found[1]).replace(/[ \t]+/g,' ').replace(/\n\s*\n/g,'\n') : '';
    }
    function percent(n) { var value=Math.round(Number(n)*1000)/10; return (value>0?'+':'')+value+'%'; }
    function traitText(state) {
        var result=[];
        (state.traits || []).forEach(function(t) {
            var n=Number(t.value);
            if (t.code===21 && LABELS[t.dataId] && n!==1) result.push(LABELS[t.dataId]+percent(n-1));
            else if (t.code===22 && XPARAM[t.dataId] && n) result.push(XPARAM[t.dataId]+percent(n));
            else if (t.code===23 && SPARAM[t.dataId] && n!==1) result.push(SPARAM[t.dataId]+percent(n-1));
            else if (t.code===42) result.push('封印技能类型');
            else if (t.code===44) result.push('封印技能');
        });
        var tag=/<g_shuxing>([\s\S]*?)<\/g_shuxing>/i.exec(state.note || '');
        if (tag) {
            var ids={mhp:0,mmp:1,atk:2,def:3,mat:4,mdf:5,agi:6,luk:7}, re=/\b(mhp|mmp|atk|def|mat|mdf|agi|luk)\s*=\s*([+-])\s*(\d+(?:\.\d+)?)\s*(%?)/ig,m;
            while ((m=re.exec(tag[1]))) result.push(LABELS[ids[m[1].toLowerCase()]]+m[2]+m[3]+m[4]);
        }
        return result.join('，');
    }
    function kindOf(state) {
        var type=/<BuffType:\s*([^>]+)>/i.exec(state.note || ''), name=type && type[1].trim();
        if (name && /^(?:减益|异常|削弱|持续伤害|debuff|毒|损伤|疾病|诅咒|暗黑|黑暗|沉默|封印|禁咒|睡眠|眩晕|麻痹|混乱|魅惑|愤怒|破甲|灼伤|冰冷|冰封撕裂)$/i.test(name)) return 'Debuff';
        if (name && /^(?:增益|强化|加成|buff|祝福|食物|合剂)$/i.test(name)) return 'Buff';
        if (Number(state.restriction)>0) return 'Debuff';
        if ((state.traits || []).some(function(t) { return (t.code===21 && Number(t.value)<1) || (t.code===22 && Number(t.value)<0) || t.code===42 || t.code===44; })) return 'Debuff';
        var values=/<g_shuxing>([\s\S]*?)<\/g_shuxing>/i.exec(state.note || '');
        if (values && /=\s*-\s*\d/.test(values[1])) return 'Debuff';
        return /(诅咒|中毒|剧毒|疾病|睡眠|失明|封印|沉默|眩晕|麻痹|破甲|碎甲|冰冷|致残|灼伤|流血|气伤|虚弱|减益)/.test(state.name || '') ? 'Debuff' : 'Buff';
    }
    function duration(turns,state) {
        if (Root.CodexAlienation && state.id===CodexAlienation.config.ids.corrosion) return Math.max(1,Math.ceil(Number(turns)||0))+'回合';
        if (Number(state.autoRemovalTiming)>0) {
            var value=Number(turns);
            if (isFinite(value) && value>0) return Math.ceil(value)+'回合';
            if (isFinite(value) && value===0) return Number(state.autoRemovalTiming)===1?'行动后结束':'回合末结束';
        }
        if (/<Permanent>/i.test(state.note || '')) return '常驻';
        return state.removeAtBattleEnd ? '本场战斗' : '持续';
    }
    function entries(battler) {
        if (!battler) return [];
        var rows=[],seen={};
        (Array.isArray(battler._states)?battler._states:[]).forEach(function(id) {
            if (seen[id]) return; seen[id]=true;
            var state=$dataStates[id]; if (!state || !state.name || id===1) return;
            var floor=(battler._statesFloor || []).find(function(f) {return f.state===id;}), stack=floor && Number(floor.floor);
            var counter=battler._stateCounter && battler._stateCounter[id];
            var metadata=[];
            if (stack>0) metadata.push(stack+'层');
            // Some YEP counters represent charges/damage, rather than stacks.
            if (typeof counter==='number' && isFinite(counter)) metadata.push('计数 '+counter);
            var turns=battler._stateTurns && battler._stateTurns[id];
            rows.push({id:id,kind:kindOf(state),name:clean(state.name),icon:Number(state.iconIndex)||0,
                stack:metadata.join(' · '),turns:duration(turns,state),remaining:(Number(state.autoRemovalTiming)>0 || Root.CodexAlienation && state.id===CodexAlienation.config.ids.corrosion) && isFinite(Number(turns))?Number(turns):Infinity,
                description:noteBlock(state.note,'StateNote') || noteBlock(state.note,'STATE_HELP') || noteBlock(state.note,'ステートヘルプ') || traitText(state) || '此状态没有文字说明。'});
        });
        (battler._buffs || []).forEach(function(level,id) {
            if (!level || !LABELS[id]) return;
            var turns=battler._buffTurns && battler._buffTurns[id];
            rows.push({id:'buff'+id,kind:level>0?'Buff':'Debuff',name:LABELS[id]+(level>0?'强化':'弱化'),
                icon:battler.buffIconIndex?Number(battler.buffIconIndex(level,id))||0:0,stack:Math.abs(level)+'层',
                turns:duration(turns,{autoRemovalTiming:2}),remaining:isFinite(Number(turns))?Number(turns):Infinity,
                description:LABELS[id]+percent(battler.paramBuffRate?battler.paramBuffRate(id)-1:level*.25)});
        });
        return rows.sort(function(a,b) {return a.kind!==b.kind?(a.kind==='Debuff'?-1:1):(a.remaining-b.remaining || String(a.id).localeCompare(String(b.id),undefined,{numeric:true}));});
    }
    function inRect(point,rect) {return point && point.x>=rect.x && point.x<rect.x+rect.width && point.y>=rect.y && point.y<rect.y+rect.height;}
    function overlaps(a,b) {return a.x<b.x+b.width && a.x+a.width>b.x && a.y<b.y+b.height && a.y+a.height>b.y;}
    function rect(sprite) {return sprite.getBounds();}
    function fit(bitmap,text,width) {
        text=String(text || ''); if (bitmap.measureTextWidth(text)<=width) return text;
        while (text && bitmap.measureTextWidth(text+'…')>width) text=text.slice(0,-1);
        return text+'…';
    }
    function wrap(bitmap,text,width) {
        var lines=[],line='';
        Array.from(String(text || '')).forEach(function(char) {
            if (char==='\n') {lines.push(line);line='';return;}
            if (line && bitmap.measureTextWidth(line+char)>width) {lines.push(line);line='';}
            line+=char;
        });
        if (line) lines.push(line);return lines;
    }
    function round(bitmap,x,y,w,h,color,border,radius) {
        var c=bitmap._context,r=radius || 8;c.save();c.beginPath();c.moveTo(x+r,y);c.lineTo(x+w-r,y);c.quadraticCurveTo(x+w,y,x+w,y+r);c.lineTo(x+w,y+h-r);c.quadraticCurveTo(x+w,y+h,x+w-r,y+h);c.lineTo(x+r,y+h);c.quadraticCurveTo(x,y+h,x,y+h-r);c.lineTo(x,y+r);c.quadraticCurveTo(x,y,x+r,y);c.closePath();c.fillStyle=color;c.fill();if(border){c.strokeStyle=border;c.lineWidth=1;c.stroke();}c.restore();bitmap._setDirty();
    }
    function BossStatusOverlay() {this.initialize.apply(this,arguments);}
    BossStatusOverlay.prototype=Object.create(Sprite.prototype);
    BossStatusOverlay.prototype.constructor=BossStatusOverlay;
    BossStatusOverlay.prototype.initialize=function() {
        Sprite.prototype.initialize.call(this);
        this._bar=new Sprite();this._detail=new Sprite();this.addChild(this._bar);this.addChild(this._detail);
        this._battler=null;this._open=false;this._page=0;this._selected=null;this._filter='Debuff';this._descriptionPage=0;this._stamp=null;
        this._detail.visible=false;this._iconSet=ImageManager.loadSystem('IconSet');this.dimensions();
        var self=this;this._iconSet.addLoadListener(function(){self.refresh(true);});if(Root.CodexGamePanels)CodexGamePanels.skin.addLoadListener(function(){self.refresh(true);});
    };
    BossStatusOverlay.prototype.dimensions=function() {
        var w=Math.max(220,Math.min(440,Graphics.boxWidth-24)),dw=Math.max(220,Math.min(480,Graphics.boxWidth-24)),dh=Math.max(220,Math.min(400,Graphics.boxHeight-180));
        if (this._width===w && this._detailWidth===dw && this._detailHeight===dh) return;
        this._width=w;this._detailWidth=dw;this._detailHeight=dh;
        [this._bar.bitmap,this._detail.bitmap].forEach(function(bitmap){if(!bitmap)return;if(typeof bitmap.destroy==='function')bitmap.destroy();else if(bitmap._baseTexture)bitmap._baseTexture.destroy();});
        this._bar.bitmap=new Bitmap(w,BAR_HEIGHT);this._detail.bitmap=new Bitmap(dw,dh);this._stamp=null;
    };
    BossStatusOverlay.prototype.pageSize=function() {return Math.max(1,Math.floor((this._detailHeight-BODY_Y-FOOTER_HEIGHT)/CARD_HEIGHT));};
    BossStatusOverlay.prototype.list=function() {var filter=this._filter;return entries(this._battler).filter(function(row){return filter==='All' || row.kind===filter;});};
    BossStatusOverlay.prototype.drawIcon=function(bitmap,icon,x,y,size) {
        if (icon && this._iconSet.isReady()) bitmap.blt(this._iconSet,(icon%16)*32,Math.floor(icon/16)*32,32,32,x,y,size || 24,size || 24);
    };
    BossStatusOverlay.prototype.preview=function(bitmap,rows,kind,y) {
        var color=kind==='Debuff'?COLOR.bad:COLOR.good,label=kind==='Debuff'?'异常':'增益';
        bitmap.fontSize=14;bitmap.textColor=color;bitmap.drawText(label+' '+rows.length,12,y+3,58,26);
        if (!rows.length) {bitmap.textColor=COLOR.muted;bitmap.drawText('无',78,y+3,this._width-90,26);return;}
        var count=Math.min(rows.length,2),more=rows.length-count,area=this._width-82-(more?34:0),cw=Math.floor(area/count);
        for(var i=0;i<count;i++) {
            var x=76+i*cw,row=rows[i],nameX=x+(row.icon?28:7),textW=cw-(row.icon?36:15);
            round(bitmap,x,y,cw-5,29,'rgba(255,255,255,0.07)',null,5);this.drawIcon(bitmap,row.icon,x+4,y+3,23);
            bitmap.fontSize=13;bitmap.textColor=COLOR.ink;bitmap.drawText(fit(bitmap,row.name,textW),nameX,y-2,textW,19);
            bitmap.fontSize=11;bitmap.textColor=color;bitmap.drawText(fit(bitmap,[row.stack,row.turns].filter(Boolean).join(' · '),textW),nameX,y+13,textW,16);
        }
        if(more){bitmap.fontSize=13;bitmap.textColor=color;bitmap.drawText('+'+more,this._width-37,y+3,28,24,'right');}
    };
    BossStatusOverlay.prototype.drawSelected=function(bitmap,row) {
        var w=this._detailWidth,h=this._detailHeight,color=row.kind==='Debuff'?COLOR.bad:COLOR.good;
        round(bitmap,12,BODY_Y,w-24,58,'rgba(255,255,255,0.07)',null,7);this.drawIcon(bitmap,row.icon,22,BODY_Y+12,30);
        var x=row.icon?63:23;bitmap.fontSize=18;bitmap.textColor=COLOR.ink;
        // Full names wrap in the detail view, while preview names remain compact.
        var names=wrap(bitmap,row.name,w-x-20),top=BODY_Y;
        names.slice(0,2).forEach(function(line,i){bitmap.drawText(line,x,top+3+i*22,w-x-20,23);});
        bitmap.fontSize=13;bitmap.textColor=color;bitmap.drawText([row.stack,row.turns].filter(Boolean).join(' · '),23,BODY_Y+62,w-46,22);
        bitmap.fontSize=16;bitmap.textColor=COLOR.ink;
        var lines=wrap(bitmap,row.description,w-44),start=BODY_Y+94,per=Math.max(1,Math.floor((h-FOOTER_HEIGHT-start-8)/24));
        var pages=Math.max(1,Math.ceil(lines.length/per));this._descriptionPage=Math.max(0,Math.min(this._descriptionPage,pages-1));this._descriptionPages=pages;
        for(var i=0;i<per && i+this._descriptionPage*per<lines.length;i++) bitmap.drawText(lines[this._descriptionPage*per+i],22,start+i*24,w-44,24);
        this.footer(bitmap,this._descriptionPage,pages,'返回列表');
    };
    BossStatusOverlay.prototype.footer=function(bitmap,page,pages,middle) {
        var w=this._detailWidth,y=this._detailHeight-FOOTER_HEIGHT;
        bitmap.fillRect(13,y,w-26,1,COLOR.edge);bitmap.fontSize=13;
        bitmap.textColor=page>0?COLOR.blue:'rgba(255,255,255,0.3)';bitmap.drawText('‹ 上一页',15,y+3,82,28);
        bitmap.textColor=COLOR.muted;bitmap.drawText((middle?middle+'  ':'')+(page+1)+' / '+pages,98,y+3,w-196,28,'center');
        bitmap.textColor=page<pages-1?COLOR.blue:'rgba(255,255,255,0.3)';bitmap.drawText('下一页 ›',w-97,y+3,82,28,'right');
    };
    // 【Codex·未经Claude检验】 折叠栏只读缓存，玩家展开详情后才计算敌人战力。
    BossStatusOverlay.prototype.refresh=function(force) {
        var all=entries(this._battler),list=this.list(),pages=Math.max(1,Math.ceil(list.length/this.pageSize()));
        this._page=Math.max(0,Math.min(this._page,pages-1));
        var selected=list.find(function(row){return String(row.id)===String(this._selected);},this);
        if(!selected)this._selected=null;
        var name=this._battler?clean(this._battler.name()):'',power=this._battler&&Root.CodexCombatPower?(this._open?CodexCombatPower.enemy(this._battler):CodexCombatPower.cachedEnemy&&CodexCombatPower.cachedEnemy(this._battler)):null,stamp=JSON.stringify([name,power&&power.total,all,this._page,this._filter,this._open,this._selected,this._descriptionPage,this._width,this._detailHeight]);
        if(!force && stamp===this._stamp)return;this._stamp=stamp;
        var bad=all.filter(function(r){return r.kind==='Debuff';}),good=all.filter(function(r){return r.kind==='Buff';}),bar=this._bar.bitmap;
        bar.clear();if(Root.CodexGamePanels)CodexGamePanels.drawFrame(bar,this._width,BAR_HEIGHT,true);else round(bar,1,1,this._width-2,BAR_HEIGHT-2,'rgba(15,24,38,0.94)',COLOR.edge,10);
        bar.fontSize=14;bar.textColor=COLOR.blue;bar.drawText('BOSS',12,3,44,24);
        var pw=power?118:0;bar.textColor=COLOR.ink;bar.drawText(fit(bar,name,this._width-148-pw),63,3,this._width-148-pw,24);if(power){bar.textColor='rgb(255,211,115)';bar.drawText('战力 '+CodexCombatPower.format(power.total),this._width-80-pw,3,pw,24,'right');}
        bar.fontSize=13;bar.textColor=COLOR.blue;bar.drawText(this._open?'收起 ▴':'详情 ▾',this._width-76,3,62,24,'right');
        bar.fillRect(12,28,this._width-24,1,COLOR.edge);this.preview(bar,bad,'Debuff',32);this.preview(bar,good,'Buff',64);
        var detail=this._detail.bitmap,w=this._detailWidth,h=this._detailHeight;
        detail.clear();if(Root.CodexGamePanels)CodexGamePanels.drawFrame(detail,w,h,false);else round(detail,1,1,w-2,h-2,'rgba(15,24,38,0.98)',COLOR.edge,10);
        detail.fontSize=18;detail.textColor=COLOR.ink;detail.drawText(fit(detail,name,Math.max(80,w-256)),16,7,Math.max(80,w-256),28);if(Root.CodexElements){var headerSize=detail.fontSize;detail.fontSize=14;CodexElements.drawAttributes(detail,this._battler,w-231,7,178,28,'敌人属性');detail.fontSize=headerSize;}
        detail.fontSize=17;detail.textColor=COLOR.blue;detail.drawText('×',w-42,7,27,28,'center');
        var tabs=[['Debuff','异常 '+bad.length,COLOR.bad],['Buff','增益 '+good.length,COLOR.good],['All','全部 '+all.length,COLOR.blue]],tw=(w-24)/3;
        tabs.forEach(function(tab,i) {var x=12+i*tw;if(this._filter===tab[0])round(detail,x,43,tw-4,28,'rgba(160,230,235,0.25)',null,5);detail.fontSize=14;detail.textColor=this._filter===tab[0]?tab[2]:COLOR.muted;detail.drawText(tab[1],x,43,tw-4,28,'center');},this);
        if(selected){this.drawSelected(detail,selected);return;}
        if(!list.length){detail.fontSize=16;detail.textColor=COLOR.muted;detail.drawText(this._filter==='Debuff'?'当前没有异常状态':this._filter==='Buff'?'当前没有增益状态':'当前没有状态',16,BODY_Y+28,w-32,28,'center');}
        for(var i=0,start=this._page*this.pageSize();i<this.pageSize() && start+i<list.length;i++) {
            var row=list[start+i],y=BODY_Y+i*CARD_HEIGHT,color=row.kind==='Debuff'?COLOR.bad:COLOR.good;
            round(detail,12,y,w-24,CARD_HEIGHT-6,'rgba(255,255,255,0.05)',null,7);detail.fillRect(12,y+8,2,CARD_HEIGHT-22,color);this.drawIcon(detail,row.icon,22,y+9,27);
            var x=row.icon?58:24;detail.fontSize=16;detail.textColor=COLOR.ink;detail.drawText(fit(detail,row.name,w-x-122),x,y+2,w-x-122,26);
            detail.fontSize=12;detail.textColor=color;detail.drawText(fit(detail,[row.stack,row.turns].filter(Boolean).join(' · '),110),w-125,y+2,109,26,'right');
            detail.fontSize=14;detail.textColor=COLOR.muted;detail.drawText(fit(detail,row.description.replace(/\n/g,' '),w-48),24,y+29,w-48,25);
        }
        this.footer(detail,this._page,pages);
    };
    BossStatusOverlay.prototype.click=function() {
        var point=pointer;pointer=null;if(!point && TouchInput.isTriggered())point={x:TouchInput.x,y:TouchInput.y};if(!point)return;
        if(inRect(point,rect(this._bar))){this._open=!this._open;this.refresh(true);return;}
        if(!this._detail.visible || !inRect(point,rect(this._detail)))return;
        var bounds=rect(this._detail),x=point.x-bounds.x,y=point.y-bounds.y,w=this._detailWidth;
        if(y<37 && x>w-48){this._open=false;return;}
        if(y>=43 && y<73){this._filter=['Debuff','Buff','All'][Math.max(0,Math.min(2,Math.floor((x-12)/((w-24)/3))))];this._selected=null;this._page=0;this.refresh(true);return;}
        if(y>=this._detailHeight-FOOTER_HEIGHT){
            if(this._selected!==null){if(x>=w*.3 && x<=w*.7)this._selected=null;else this._descriptionPage+=x<w*.3?-1:1;}
            else this._page+=x<w*.3?-1:x>w*.7?1:0;
            this.refresh(true);return;
        }
        var item=Math.floor((y-BODY_Y)/CARD_HEIGHT),list=this.list();
        if(this._selected===null && y>=BODY_Y && item>=0 && item<this.pageSize() && list[this._page*this.pageSize()+item]){this._selected=list[this._page*this.pageSize()+item].id;this._descriptionPage=0;this.refresh(true);}
    };
    BossStatusOverlay.prototype.update=function() {
        Sprite.prototype.update.call(this);
        var scene=SceneManager._scene,battler=enabled() && scene instanceof Scene_Battle?locateBoss(scene):null,changed=this._battler!==battler;
        this._battler=battler;this.visible=!!battler;
        if(!battler){this._open=false;this._selected=null;this._detail.visible=false;pointer=null;return;}
        if(changed){this._page=0;this._open=false;this._filter='Debuff';this._selected=null;this._descriptionPage=0;}
        this.click();this._detail.visible=this._open;
        if(changed || Graphics.frameCount%8===0)this.refresh(changed);
    };
    function visibleHelp(scene) {
        var lists=[scene._skillWindow,scene._itemWindow];
        for(var i=0;i<lists.length;i++){var list=lists[i],help=list && list._helpWindow;if(list && list.visible && help && help.visible && help.item && help.bitmap && help.bitmap.height)return rect(help);}
        return null;
    }
    function ensure(scene) {
        var overlay=scene._codexBossStatusOverlay;
        if(!overlay){overlay=new BossStatusOverlay();scene._codexBossStatusOverlay=overlay;scene._codexBossOverlay=overlay;scene.addChild(overlay);}
        overlay.dimensions();
        if(scene.children[scene.children.length-1]!==overlay)scene.setChildIndex(overlay,scene.children.length-1);
        var hud=scene._bosshp_sprites,layout=hud && hud._layout && hud._layout.bitmap;
        // Keep the small card alongside the native HP HUD, on the left edge of
        // the battlefield. It leaves the party HUD and bottom-right damage free.
        var x=hud?Number(hud.x || 0):Math.round(Graphics.boxWidth*.08),y=hud?Number(hud.y || 0)+Math.max(66,layout && layout.height || 0)+8:84;
        overlay.x=Math.max(12,Math.min(x,Graphics.boxWidth-overlay._width-12));
        overlay.y=Math.max(12,Math.min(y,Graphics.boxHeight-BAR_HEIGHT-12));
        var help=visibleHelp(scene),bar={x:overlay.x,y:overlay.y,width:overlay._width,height:BAR_HEIGHT};
        if(help && overlaps(bar,help))overlay.y=Math.max(12,Math.min(overlay.y,help.y-BAR_HEIGHT-8));
        var dx=Math.max(12,Math.min(overlay.x,Graphics.boxWidth-overlay._detailWidth-12));
        var dy=Math.max(12,Math.min(overlay.y+BAR_HEIGHT+6,Graphics.boxHeight-overlay._detailHeight-12));
        overlay._detail.x=dx-overlay.x;overlay._detail.y=dy-overlay.y;
        overlay._detail.visible=overlay.visible && overlay._open && !(help && overlaps({x:dx,y:dy,width:overlay._detailWidth,height:overlay._detailHeight},help));
    }
    document.addEventListener('pointerdown',function(event) {
        if(event.button!==0)return;
        var scene=SceneManager._scene,overlay=scene && scene._codexBossStatusOverlay;if(!overlay || !overlay.visible)return;
        var point={x:Graphics.pageToCanvasX(event.pageX),y:Graphics.pageToCanvasY(event.pageY)};
        if(!inRect(point,rect(overlay._bar)) && !(overlay._detail.visible && inRect(point,rect(overlay._detail))))return;
        pointer=point;TouchInput.clear();event.preventDefault();event.stopImmediatePropagation();
    },true);
    document.addEventListener('keydown',function(event) {
        var scene=SceneManager._scene,overlay=scene && scene._codexBossStatusOverlay;
        if(event.key==='Escape' && overlay && overlay.visible && overlay._open){overlay._open=false;overlay._detail.visible=false;overlay.refresh(true);Input.clear();event.preventDefault();event.stopImmediatePropagation();}
    },true);
    if(typeof Sprite_BossHP!=='undefined'){
        var oldBossUpdate=Sprite_BossHP.prototype.update;
        Sprite_BossHP.prototype.update=function(){var out=oldBossUpdate.apply(this,arguments);if(this._codexBossStatusPanel)this._codexBossStatusPanel.visible=false;return out;};
    }
    var update=Scene_Battle.prototype.update;
    Scene_Battle.prototype.update=function(){var out=update.apply(this,arguments);ensure(this);return out;};
    Root.CodexBossStatusSummary={version:'0.4.0-game-theme-candidate',create:function(){return new BossStatusOverlay();},isBoss:isBoss,statusEntries:entries,locateBoss:locateBoss};
})();
