/*:

 PH - Warehouse/Storage
 @plugindesc PH - 仓库/存储
 @author PrimeHover【八云翻译】
 @version 1.2.1
 @date 05/30/2016

 ---------------------------------------------------------------------------------------
 This work is licensed under the Creative Commons Attribution 4.0 International License.
 To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/
 ---------------------------------------------------------------------------------------

 @param ---Options---
 @text ---选项---
 @desc 使用下面的空格来自定义插件的选项
 @default

 @param All Together
 @text 全部显示
 @desc 类别分别显示，或者全部在一起
（0：假，1：真）
 @default 0

 @param Stack Item Quantity
 @text 堆叠物品数量
 @desc 定义是否要将堆叠项目视为容量中的单个空间
（0：假，1：真）
 @default 0

 @param ---Vocabulary---
 @text ---词汇---
 @desc 使用下面的空格来个性化插件的词汇
 @default

 @param Withdraw Text
 @text 提款
 @desc 选项“提款”中显示的文本
 @default 箱子物品

 @param Deposit Text
 @text 存款
 @desc 选项“存款”中显示的文本
 @default 随身物品

 @param All Text
 @text 所有文字
 @desc 如果参数“All Together”设置为true，则选项“All”中显示的文本。
 @default 全部

 @param Available Space Text
 @text 可用空间文本
 @desc 信息窗口中显示的文本
 @default 剩余空间:

 @help

 仓库/存储插件，由 PrimeHover 创建！

查看完整文档：
https://github.com/PrimeHover/Warehouse

查看使用命令和规则的说明性示例：
http://forums.rpgmakerweb.com/index.php?/topic/50503-ph-warehousestorage/

查看葡萄牙语示例：
http://www.mundorpgmaker.com.br/topic/114053-ph-warehousestorage/

 ------------------------------------------------------------------------------

 插件命令:
 - 下面用★代表仓库名称，因为中文存储空间太多！
 - 有些在右边要用拉动的，当然你也可以用★当仓库标题

 - PHWarehouse create <★>		# 创建仓库
 - PHWarehouse create <★:50>		# 创建仓库,容量50
 - PHWarehouse create <★:50:rule>		# 创建仓库,容量50,设置规则

 - PHWarehouse show <★>			# 显示仓库
 - PHWarehouse remove <★>		# 移除仓库


 - loot item只能在仓库第一次打开之前添加，之后命令没用
 - add item强制添加

 - PHWarehouse loot item <★:id:数量>	# 添加物品
 - PHWarehouse loot weapon <★:id:数量>	# 添加武器
 - PHWarehouse loot armor <★:id:数量>	# 添加护甲
 - PHWarehouse loot keyItem <★:id:数量>	# 添加重要物品

 - PHWarehouse add item <★:id:数量>	# 添加物品
 - PHWarehouse add weapon <★:id:数量>	# 添加武器
 - PHWarehouse add armor <★:id:数量>	# 仓库添加护甲
 - PHWarehouse add keyItem <★:id:数量>	# 添加重要物品

 - PHWarehouse capacity set <★:数量>	# 设置仓库最大容量
 - PHWarehouse capacity increase <★:数量>	# 增加仓库最大容量
 - PHWarehouse capacity decrease <★:数量>	# 减少仓库最大容量

 ------------------------------------------------------------------------------

 脚本命令:

# 获取仓库的最大容量（返回一个数字）
 - PHPlugins.PHWarehouse.prototype.exist("★");	

# 获取仓库的当前容量（返回一个数字）
 - PHPlugins.PHWarehouse.prototype.getMaxCapacity("★");

# 检查仓库是否存在（返回真或假）	
 - PHPlugins.PHWarehouse.prototype.getCurrentCapacity("★");
	
# 验证仓库是否有特定项目并返回仓库内该项目的数量。
 - PHPlugins.PHWarehouse.prototype.hasItem("★", id);

# 验证仓库是否有特定武器并返回仓库内该物品的数量。	
 - PHPlugins.PHWarehouse.prototype.hasWeapon("★", id);

# 验证仓库是否有特定的盔甲并返回仓库内该物品的数量。	
 - PHPlugins.PHWarehouse.prototype.hasArmor("★", id);

# 验证仓库是否有特定的关键项目并返回仓库内该项目的数量。	
 - PHPlugins.PHWarehouse.prototype.hasKeyItem("★", id);	

 ------------------------------------------------------------------------------

 规则配置:

    规则是一种管理可以存储在特定仓库中的项目的简单方法。为了为您的仓库
    创建规则，您必须在数据库中创建一个名为“PHWarehouse”的公共事件。
    在该公共事件中，您将创建一些注释以填充仓库规则。
    这些注释必须具有以下格式：
     {规则标题}
     [commands]

    您可以指定的 [commands] 如下：

    item: 1 （只允许存储 id 为 1 的项目）
    item: 1, 2, 3, 4 （允许存储 id 为 1、2、3 和 4 的项目）
    item: no （不允许存放物品）
    item-n: 1（允许存储除 id 为 1 的项目之外的任何项目）
（如果您在规则中未指定命令“item”，则将允许存储所有项目）

    weapon: 1 （只允许存放 id 为 1 的武器）
    weapon: 1, 2, 3, 4 （允许存放 id 为 1、2、3 和 4 的武器）
    weapon: no （不允许存放武器）
    weapon-n: 1(允许存放任何武器，除了id为1的武器)
    (如果规则中没有指定命令“weapon”，则允许存放所有武器)

    armor: 1 （只允许存放 id 为 1 的盔甲）
    armor: 1, 2, 3, 4 （允许存储 ID 为 1、2、3 和 4 的盔甲）
    armor: no （不允许存放盔甲）
    armor-n 1(允许存放任何盔甲，除了id为1的盔甲)
    (如果你没有在规则中指定命令“armor”，所有盔甲都将被允许存放)

    keyItem: 1 （只允许存储 id 为 1 的关键项）
    keyItem: 1, 2, 3, 4 （允许存储 id 为 1、2、3 和 4 的关键项）
    keyItem: no （不允许存放关键物品）
    keyItem-n 1（允许存储除 id 为 1 之外的任何关键项）
    （如果您在规则中未指定命令“keyItem”，则将允许存储所有关键项）

 */

/* Global variable for PH Plugins */
var PHPlugins = PHPlugins || {};
PHPlugins.Parameters = PluginManager.parameters('PH_Warehouse');
PHPlugins.Params = PHPlugins.Params || {};

/* Global variable for the list of quests */
PHPlugins.PHWarehouse = null;

/* Getting the parameters */
PHPlugins.Params.PHWarehouseWithdrawText = String(PHPlugins.Parameters['Withdraw Text']);
PHPlugins.Params.PHWarehouseDepositText = String(PHPlugins.Parameters['Deposit Text']);
PHPlugins.Params.PHWarehouseAvailableSpaceText = String(PHPlugins.Parameters['Available Space Text']);
PHPlugins.Params.PHWarehouseAllText = String(PHPlugins.Parameters['All Text']);
PHPlugins.Params.PHWarehouseAllTogether = Number(PHPlugins.Parameters['All Together']) || 0;
PHPlugins.Params.PHWarehouseStackItemQuantity = Number(PHPlugins.Parameters['Stack Item Quantity']) || 0;
PHPlugins.Params.PHWarehouseAllTogether = Boolean(PHPlugins.Params.PHWarehouseAllTogether);
PHPlugins.Params.PHWarehouseStackItemQuantity = Boolean(PHPlugins.Params.PHWarehouseStackItemQuantity);

(function() {

    /* ---------------------------------------------------------- *
     *                      WAREHOUSE MANAGER                     *
     * ---------------------------------------------------------- */

    function PHWarehouseManager() {
        this._rules = {};
        this._warehouses = {};
        this._lastActive = "";
        this._lastOption = 0; // 0 = Withdraw, 1 = Deposit
        this._lastCategory = "item";
    }

    /* ---- BASIC OPERATIONS ---- */

    /* Creates a warehouse if it does not exist */
    PHWarehouseManager.prototype.createWarehouse = function(_sentence) {

        var matches = this.checkSentence(_sentence);
        var results;
        var title;
        var rule = null;
        var capacity = 50;

        if (matches != null) {
            results = matches.split(":");
            title = results[0];

            if (!this._warehouses.hasOwnProperty(title)) {

                if (results.length >= 2) {
                    capacity = parseInt(results[1]);
                    if (isNaN(capacity) || capacity <= 0) {
                        capacity = 50;
                    }
                    if (typeof results[2] !== "undefined" && this._rules.hasOwnProperty(results[2])) {
                        rule = results[2];
                    }
                }

                this._warehouses[title] = {
                    title: title,
                    maxCapacity: capacity,
                    currentCapacity: 0,
                    rule: rule,
                    lootBonus: true,
                    items: {
                        item: [],
                        weapon: [],
                        armor: [],
                        keyItem: []
                    },
                    qtty: {
                        item: {},
                        weapon: {},
                        armor: {},
                        keyItem: {}
                    }
                };
            }

            this._lastActive = title;
        }

    };

    /* Opens a warehouse */
    PHWarehouseManager.prototype.openWarehouse = function(_sentence) {
        var matches = this.checkSentence(_sentence);
        if (matches != null) {
            this._lastActive = matches;
            this._warehouses[this._lastActive].lootBonus = false;
            var removed = this.repairIndependentEntries(matches);
            if (removed > 0 && window.$ && $.toaster) $.toaster({ message: '仓库里有' + removed + '条失效的装备记录（物品已不存在），已清除并归还容量。' });
        }
    };

    /* Remove a warehouse */
    PHWarehouseManager.prototype.removeWarehouse = function(_sentence) {

        var matches = this.checkSentence(_sentence);

        if (matches != null) {
            if (this._warehouses.hasOwnProperty(matches)) {
                delete this._warehouses[matches];
            }
        }

    };

    /* Add a loot bonus */
    PHWarehouseManager.prototype.addLoot = function(_sentence, category) {

        var matches = this.checkSentence(_sentence);
        var results;

        if (matches != null) {
            results = matches.split(":");
            if (this._warehouses.hasOwnProperty(results[0]) && this._warehouses[results[0]].lootBonus && typeof results[1] !== "undefined" && typeof results[2] !== "undefined") {
                results[1] = parseInt(results[1]);
                results[2] = parseInt(results[2]);
                if (results[2] > this._warehouses[results[0]].maxCapacity - this._warehouses[results[0]].currentCapacity) {
                    results[2] = this._warehouses[results[0]].maxCapacity - this._warehouses[results[0]].currentCapacity;
                }

                if (this._warehouses[results[0]].items[category].indexOf(results[1]) > -1) {
                    this._warehouses[results[0]].qtty[category][results[1]] += results[2];
                } else {
                    this._warehouses[results[0]].items[category].push(results[1]);
                    this._warehouses[results[0]].qtty[category][results[1]] = results[2];
                }
                this._warehouses[results[0]].currentCapacity += results[2];
            }
        }

    };

    /* Add item to a warehouse */
    PHWarehouseManager.prototype.addItems = function(_sentence, category) {

        var matches = this.checkSentence(_sentence);
        var results;

        if (matches != null) {
            results = matches.split(":");
            if (this._warehouses.hasOwnProperty(results[0]) && typeof results[1] !== "undefined" && typeof results[2] !== "undefined") {
                results[1] = parseInt(results[1]);
                results[2] = parseInt(results[2]);

                if (results[2] > this._warehouses[results[0]].maxCapacity - this._warehouses[results[0]].currentCapacity) {
                    results[2] = this._warehouses[results[0]].maxCapacity - this._warehouses[results[0]].currentCapacity;
                }

                if (this._warehouses[results[0]].items[category].indexOf(results[1]) > -1) {
                    this._warehouses[results[0]].qtty[category][results[1]] += results[2];
                } else {
                    this._warehouses[results[0]].items[category].push(results[1]);
                    this._warehouses[results[0]].qtty[category][results[1]] = results[2];
                }
                this._warehouses[results[0]].currentCapacity += results[2];
            }
        }

    };



    /* ---- RULE METHODS ---- */

    /* Load rules */
    PHWarehouseManager.prototype.loadRules = function() {
        var warehouseVar = null;

        if ($dataCommonEvents) {
            for (var i = 0; i < $dataCommonEvents.length; i++) {
                if ($dataCommonEvents[i] instanceof Object && $dataCommonEvents[i].name == "PHWarehouse") {
                    warehouseVar = $dataCommonEvents[i].list;
                    i = $dataCommonEvents.length;
                }
            }
        }

        if (warehouseVar != null) {
            this.populateRules(warehouseVar);
        }
    };

    /* Populate rules */
    PHWarehouseManager.prototype.populateRules = function(warehouseVar) {
        var str = '';
        var index = -1;
        var rule;

        for (var i = 0; i < warehouseVar.length; i++) {
            if (warehouseVar[i].parameters[0]) {
                str = warehouseVar[i].parameters[0].trim();
                if (this.checkTitle(str)) {
                    str = str.slice(1, str.length-1);
                    this._rules[str] = {
                        enabledItems: {
                            item: [],
                            weapon: [],
                            armor: [],
                            keyItem: []
                        },
                        disabledItems: {
                            item: [],
                            weapon: [],
                            armor: [],
                            keyItem: []
                        }
                    };
                    index = str;
                } else if (this._rules[index]) {
                    rule = str.split(":");
                    rule[0] = rule[0].trim();
                    rule[1] = rule[1].trim();

                    if (rule[0].indexOf('-n') > -1) {
                        rule[0] = rule[0].replace("-n", "");
                        if (this._rules[index].disabledItems.hasOwnProperty(rule[0])) {
                            this._rules[index].disabledItems[rule[0]] = this.getItemsId(rule[1]);
                        }
                    } else {
                        if (this._rules[index].enabledItems.hasOwnProperty(rule[0])) {
                            if (rule[1].indexOf("no") > -1) {
                                this._rules[index].enabledItems[rule[0]] = false;
                            } else {
                                this._rules[index].enabledItems[rule[0]] = this.getItemsId(rule[1]);
                            }
                        }
                    }
                }
            }
        }
    };

    /* Checks if the string is a title or a description */
    PHWarehouseManager.prototype.checkTitle = function(str) {
        if (str.charAt(0) == "{" && str.charAt(str.length - 1) == "}") {
            return true;
        }
        return false;
    };

    /* Separate ids and make it an array */
    PHWarehouseManager.prototype.getItemsId = function(str) {
        var arr = str.split(",");
        for (var i = 0; i < arr; i++) {
            arr[i] = parseInt(arr[i], 10);
        }
        return arr;
    };

    /* Checks if items are enabled */
    PHWarehouseManager.prototype.isItemEnabled = function() {
        if (this._warehouses[this._lastActive].rule == null || (this._rules.hasOwnProperty(this._warehouses[this._lastActive].rule) && Array.isArray(this._rules[this._warehouses[this._lastActive].rule].enabledItems.item))) {
            return true;
        }
        return false;
    };

    /* Checks if weapons are enabled */
    PHWarehouseManager.prototype.isWeaponEnabled = function() {
        if (this._warehouses[this._lastActive].rule == null || (this._rules.hasOwnProperty(this._warehouses[this._lastActive].rule) && Array.isArray(this._rules[this._warehouses[this._lastActive].rule].enabledItems.weapon))) {
            return true;
        }
        return false;
    };

    /* Checks if armors are enabled */
    PHWarehouseManager.prototype.isArmorEnabled = function() {
        if (this._warehouses[this._lastActive].rule == null || (this._rules.hasOwnProperty(this._warehouses[this._lastActive].rule) && Array.isArray(this._rules[this._warehouses[this._lastActive].rule].enabledItems.armor))) {
            return true;
        }
        return false;
    };

    /* Checks if key items are enabled */
    PHWarehouseManager.prototype.isKeyItemEnabled = function() {
        if (this._warehouses[this._lastActive].rule == null || (this._rules.hasOwnProperty(this._warehouses[this._lastActive].rule) && Array.isArray(this._rules[this._warehouses[this._lastActive].rule].enabledItems.keyItem))) {
            return true;
        }
        return false;
    };

    /* Verifies if an item is allowed to be withdrawn or deposited */
    PHWarehouseManager.prototype.verifyItem = function(item) {
        if (item == undefined) return false;
        this.verifyAllTogether(item);
        if (this._warehouses[this._lastActive].rule == null ||
                (this._rules.hasOwnProperty(this._warehouses[this._lastActive].rule) &&
                Array.isArray(this._rules[this._warehouses[this._lastActive].rule].enabledItems[this._lastCategory]) &&
                    (this._rules[this._warehouses[this._lastActive].rule].enabledItems[this._lastCategory].indexOf(item.id) > -1) ||
                    this._rules[this._warehouses[this._lastActive].rule].enabledItems[this._lastCategory].length == 0)) {

            /* Makes a second checking to see if this item is disabled */
            if (this._warehouses[this._lastActive].rule !== null &&
                Array.isArray(this._rules[this._warehouses[this._lastActive].rule].disabledItems[this._lastCategory]) &&
                this._rules[this._warehouses[this._lastActive].rule].disabledItems[this._lastCategory].indexOf(item.id) > -1) {
                return false;
            }
            return true;
        }
        return false;
    };

    /* Changes the last category if "all together" are set as true */
    PHWarehouseManager.prototype.verifyAllTogether = function(item) {
        if (PHPlugins.Params.PHWarehouseAllTogether == true) {
            if (DataManager.isItem(item) && item.itypeId === 1) {
                this._lastCategory = 'item';
            } else if (DataManager.isArmor(item)) {
                this._lastCategory = 'armor';
            } else if (DataManager.isWeapon(item)) {
                this._lastCategory = 'weapon';
            } else if (DataManager.isItem(item) && item.itypeId === 2) {
                this._lastCategory = 'keyItem';
            }
        }
    };

    /* Undo what the previous function has done */
    PHWarehouseManager.prototype.undoAllTogetherVerification = function() {
        if (PHPlugins.Params.PHWarehouseAllTogether == true) {
            this._lastCategory = 'all';
        }
    };

    /* Changes the maximum capacity of the warehouse for the given title */
    PHWarehouseManager.prototype.setMaxCapacity = function(_sentence) {
        var matches = this.checkSentence(_sentence);
        if (matches != null) {
            var results = matches.split(":");
            if (results.length == 2) {
                var title = results[0];
                var capacity = parseInt(results[1]);
                if (this._warehouses.hasOwnProperty(title) && !isNaN(capacity) && capacity >= this.getCurrentCapacity(title)) {
                    this._warehouses[title].maxCapacity = capacity;
                    if (this._warehouses[title].maxCapacity < 0) {
                        this._warehouses[title].maxCapacity = 0;
                    }
                }
            }
        }
    };

    /* Increases the maximum capacity of the warehouse for the given title */
    PHWarehouseManager.prototype.increaseMaxCapacity = function(_sentence) {
        var matches = this.checkSentence(_sentence);
        if (matches != null) {
            var results = matches.split(":");
            if (results.length == 2) {
                var title = results[0];
                var capacity = parseInt(results[1]);
                if (this._warehouses.hasOwnProperty(title) && !isNaN(capacity) && (this._warehouses[title].maxCapacity + capacity) >= this.getCurrentCapacity(title)) {
                    this._warehouses[title].maxCapacity += capacity;
                    if (this._warehouses[title].maxCapacity < 0) {
                        this._warehouses[title].maxCapacity = 0;
                    }
                }
            }
        }
    };

    /* Decreases the maximum capacity of the warehouse for the given title */
    PHWarehouseManager.prototype.decreaseMaxCapacity = function(_sentence) {
        var matches = this.checkSentence(_sentence);
        if (matches != null) {
            var results = matches.split(":");
            if (results.length == 2) {
                var title = results[0];
                var capacity = parseInt(results[1]);
                if (this._warehouses.hasOwnProperty(title) && !isNaN(capacity) && (this._warehouses[title].maxCapacity - capacity) >= this.getCurrentCapacity(title)) {
                    this._warehouses[title].maxCapacity -= capacity;
                    if (this._warehouses[title].maxCapacity < 0) {
                        this._warehouses[title].maxCapacity = 0;
                    }
                }
            }
        }
    };



    /* ---- MANAGEMENT METHODS ---- */

    /* Get all the items from the current warehouse */
    PHWarehouseManager.prototype.getItems = function() {
        var totalItems = this.getCommonItems();
        totalItems = totalItems.concat(this.getArmors());
        totalItems = totalItems.concat(this.getKeyItems());
        totalItems = totalItems.concat(this.getWeapons());
        return totalItems;
    };

    // 【Claude·未经Codex检验】v0.31：仓库存的就是数据库下标，直接按ID取；原写法每个记录都扫一遍整张独立装备表。
    PHWarehouseManager.prototype.lookupStored = function(category, database) {
        var totalItems = [];
        var ids = this._warehouses[this._lastActive].items[category];
        for (var i = 0; i < ids.length; i++) {
            var item = database[ids[i]];
            if (item != null && item.id == ids[i]) {
                totalItems.push(item);
            }
        }
        return totalItems;
    };

    /* Get weapon items */
    PHWarehouseManager.prototype.getWeapons = function() {
        return this.lookupStored('weapon', $dataWeapons);
    };

    /* Get common items */
    PHWarehouseManager.prototype.getCommonItems = function() {
        return this.lookupStored('item', $dataItems);
    };

    /* Get armor items */
    PHWarehouseManager.prototype.getArmors = function() {
        return this.lookupStored('armor', $dataArmors);
    };

    /* Get key items */
    PHWarehouseManager.prototype.getKeyItems = function() {
        return this.lookupStored('keyItem', $dataItems);
    };

    // 【Claude·未经Codex检验】v0.31：独立装备另记本体ID。记录找不到实物、本体对不上、或同一件已在背包／身上时视为失效：移除并归还容量。
    // 按底层装备ID比较：v0.30起 equips() 可能返回吸取特效的显示副本，按对象比较会漏判。
    PHWarehouseManager.prototype.independentOwnedElsewhere = function(item) {
        if ($gameParty.numItems(item) > 0) return true;
        var kind = DataManager.isWeapon(item) ? 'weapon' : 'armor';
        var actors = $gameActors._data || [];
        for (var i = 0; i < actors.length; i++) {
            var actor = actors[i];
            if (!actor || !actor._equips) continue;
            for (var j = 0; j < actor._equips.length; j++) {
                var ref = actor._equips[j];
                if (ref && ref._dataClass === kind && ref._itemId === item.id) return true;
            }
        }
        return false;
    };

    PHWarehouseManager.prototype.repairIndependentEntries = function(title) {
        var warehouse = this._warehouses[title];
        if (!warehouse || !warehouse.items) return 0;
        var removed = 0;
        warehouse.base = warehouse.base || { weapon: {}, armor: {} };
        [['weapon', $dataWeapons, DataManager._baseWeaponsLength], ['armor', $dataArmors, DataManager._baseArmorsLength]].forEach(function(row) {
            var category = row[0], database = row[1], baseLength = row[2] || Infinity;
            var ids = warehouse.items[category] || [], qtty = warehouse.qtty[category] || {};
            var bases = warehouse.base[category] = warehouse.base[category] || {};
            for (var i = ids.length - 1; i >= 0; i--) {
                var id = ids[i];
                if (id < baseLength) continue;
                var item = database[id];
                var stale = !item || item.id != id || !item.baseItemId ||
                    (bases[id] !== undefined && Number(bases[id]) !== Number(item.baseItemId)) ||
                    this.independentOwnedElsewhere(item);
                if (stale) {
                    removed += Math.max(1, Number(qtty[id]) || 1);
                    ids.splice(i, 1);
                    delete qtty[id];
                    delete bases[id];
                } else if (bases[id] === undefined) {
                    bases[id] = item.baseItemId;
                }
            }
        }, this);
        if (removed > 0) warehouse.currentCapacity = Math.max(0, (warehouse.currentCapacity || 0) - removed);
        return removed;
    };

    /* Get the quantity for the corresponding item */
    PHWarehouseManager.prototype.getQuantity = function(item) {
        this.verifyAllTogether(item);
        var qtty = this._warehouses[this._lastActive].qtty[this._lastCategory][item.id];
        this.undoAllTogetherVerification();
        return qtty;
    };

    /* Checks whether or not the warehouse is already full */
    PHWarehouseManager.prototype.checkCapacity = function() {
        var capacity = this.getCurrentCapacity(this._lastActive);
        if (capacity < this._warehouses[this._lastActive].maxCapacity) {
            return true;
        }
        return false;
    };



    /* ---- OPERATION METHODS ---- */

    /* Deposit on warehouse */
    PHWarehouseManager.prototype.deposit = function(item) {
        if (this.checkCapacity()) {

            this.verifyAllTogether(item);
            if (this._lastCategory != 'all') {
                var hasItem = false;
                if (this._warehouses[this._lastActive].items[this._lastCategory].indexOf(item.id) > -1) {
                    hasItem = true;
                }

                if (hasItem) {
                    this._warehouses[this._lastActive].qtty[this._lastCategory][item.id]++;
                } else {
                    this._warehouses[this._lastActive].items[this._lastCategory].push(item.id);
                    this._warehouses[this._lastActive].qtty[this._lastCategory][item.id] = 1;
                }
                if (item.baseItemId && (this._lastCategory === 'weapon' || this._lastCategory === 'armor')) {
                    var bases = this._warehouses[this._lastActive].base = this._warehouses[this._lastActive].base || { weapon: {}, armor: {} };
                    bases[this._lastCategory] = bases[this._lastCategory] || {};
                    bases[this._lastCategory][item.id] = item.baseItemId;
                }
                this._warehouses[this._lastActive].currentCapacity++;
            }
            this.undoAllTogetherVerification();

        }

    };

    /* Withdraw from a warehouse */
    PHWarehouseManager.prototype.withdraw = function(item) {

        this.verifyAllTogether(item);

        if (this._lastCategory != 'all') {
            var hasItem = false;
            var index = this._warehouses[this._lastActive].items[this._lastCategory].indexOf(item.id);
            if (index > -1) {
                hasItem = true;
            }

            if (hasItem) {
                this._warehouses[this._lastActive].qtty[this._lastCategory][item.id]--;
                if (this._warehouses[this._lastActive].qtty[this._lastCategory][item.id] == 0) {
                    this._warehouses[this._lastActive].items[this._lastCategory].splice(index, 1);
                    delete this._warehouses[this._lastActive].qtty[this._lastCategory][item.id];
                    if (this._warehouses[this._lastActive].base && this._warehouses[this._lastActive].base[this._lastCategory]) {
                        delete this._warehouses[this._lastActive].base[this._lastCategory][item.id];
                    }
                }
                this._warehouses[this._lastActive].currentCapacity--;
            }
        }

        this.undoAllTogetherVerification();

    };



    /* ---- INTERNAL METHODS ---- */

    /* Check sentences coming from the arguments */
    PHWarehouseManager.prototype.checkSentence = function(_sentence) {
        var regExp = /\<([^)]+)\>/;
        var matches = regExp.exec(_sentence);
        if (matches != null) {
            return matches[1];
        } else {
            return null;
        }
    };

    /* Main method for checking items inside warehouses */
    PHWarehouseManager.prototype.hasItems = function(title, id, category) {
        if (this._warehouses.hasOwnProperty(title) && this._warehouses[title].items[category].indexOf(id) > -1) {
            return this._warehouses[title].qtty[category][id];
        }
        return 0;
    };



    /* ---- ACCESSOR METHODS ---- */

    /* Return the value of the maximum capacity of the warehouse for the given title */
    PHWarehouseManager.prototype.getMaxCapacity = function(title) {
        if (this._warehouses.hasOwnProperty(title)) {
            return this._warehouses[title].maxCapacity;
        }
        return 0;
    };

    /* Return the value of the quantity of items in the warehouse for the given title */
    PHWarehouseManager.prototype.getCurrentCapacity = function(title) {
        if (this._warehouses.hasOwnProperty(title)) {
            if (PHPlugins.Params.PHWarehouseStackItemQuantity == true) {
                return (this._warehouses[title].items.item.length + this._warehouses[title].items.weapon.length + this._warehouses[title].items.keyItem.length + this._warehouses[title].items.armor.length);
            } else {
                return this._warehouses[title].currentCapacity;
            }
        }
        return 0;
    };

    /* Return whether or not the warehouse for the given title exists */
    PHWarehouseManager.prototype.exist = function(title) {
        if (this._warehouses.hasOwnProperty(title) && this._warehouses[title] !== undefined) {
            return true;
        }
        return false;
    };

    /* Checks if the given warehouse has an item */
    PHWarehouseManager.prototype.hasItem = function(title, id) {
        return this.hasItems(title, id, 'item');
    };

    /* Checks if the given warehouse has a weapon */
    PHWarehouseManager.prototype.hasWeapon = function(title, id) {
        return this.hasItems(title, id, 'weapon');
    };

    /* Checks if the given warehouse has an armor */
    PHWarehouseManager.prototype.hasArmor = function(title, id) {
        return this.hasItems(title, id, 'armor');
    };

    /* Checks if the given warehouse has a key item */
    PHWarehouseManager.prototype.hasKeyItem = function(title, id) {
        return this.hasItems(title, id, 'keyItem');
    };



    /* ---------------------------------------------------------- *
     *                      LOADING PROCESS                       *
     * ---------------------------------------------------------- */

    /* Creating PHWarehouse variable after loading the whole database */
    var _DataManager_createGameObjects_ = DataManager.createGameObjects;
    DataManager.createGameObjects = function() {
        _DataManager_createGameObjects_.call(this);
        PHPlugins.PHWarehouse = new PHWarehouseManager();
        PHPlugins.PHWarehouse.loadRules();
    };

    /* Saves the warehouses when the player saves the game */
    var _DataManager_makeSaveContents_ = DataManager.makeSaveContents;
    DataManager.makeSaveContents = function() {
        var contents = _DataManager_makeSaveContents_.call(this);
        contents.phwarehouse = PHPlugins.PHWarehouse._warehouses;
        return contents;
    };

    /* Retrieve the warehouses from the save content */
    var _DataManager_extractSaveContents_ = DataManager.extractSaveContents;
    DataManager.extractSaveContents = function(contents) {
        _DataManager_extractSaveContents_.call(this, contents);
        PHPlugins.PHWarehouse = new PHWarehouseManager();
        PHPlugins.PHWarehouse._warehouses = contents.phwarehouse;
        PHPlugins.PHWarehouse.loadRules();
    };

    var getAllArguments = function(args, startIndex) {
        var str = args[startIndex].toString();
        for (var i = (startIndex+1); i < args.length; i++) {
            str += ' ' + args[i].toString();
        }
        return str;
    };

    var _Game_Interpreter_pluginCommand = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function(command, args) {
        _Game_Interpreter_pluginCommand.call(this, command, args);
        if (command === 'PHWarehouse') {
            switch (args[0]) {
                case 'create':
                    PHPlugins.PHWarehouse.createWarehouse(getAllArguments(args, 1));
                    break;
                case 'show':
                    PHPlugins.PHWarehouse.openWarehouse(getAllArguments(args, 1));
                    SceneManager.push(Scene_Warehouse);
                    break;
                case 'remove':
                    PHPlugins.PHWarehouse.removeWarehouse(getAllArguments(args, 1));
                    break;
                case 'add':
                    switch (args[1]) {
                        case 'item':
                            PHPlugins.PHWarehouse.addItems(getAllArguments(args, 2), 'item');
                            break;
                        case 'weapon':
                            PHPlugins.PHWarehouse.addItems(getAllArguments(args, 2), 'weapon');
                            break;
                        case 'armor':
                            PHPlugins.PHWarehouse.addItems(getAllArguments(args, 2), 'armor');
                            break;
                        case 'keyItem':
                            PHPlugins.PHWarehouse.addItems(getAllArguments(args, 2), 'keyItem');
                            break;
                    }
                    break;
                case 'capacity':
                    switch (args[1]) {
                        case 'increase':
                            PHPlugins.PHWarehouse.increaseMaxCapacity(getAllArguments(args, 2));
                            break;
                        case 'decrease':
                            PHPlugins.PHWarehouse.decreaseMaxCapacity(getAllArguments(args, 2));
                            break;
                        case 'set':
                            PHPlugins.PHWarehouse.setMaxCapacity(getAllArguments(args, 2));
                            break;
                    }
                    break;
                case 'loot':
                    switch (args[1]) {
                        case 'item':
                            PHPlugins.PHWarehouse.addLoot(getAllArguments(args, 2), 'item');
                            break;
                        case 'weapon':
                            PHPlugins.PHWarehouse.addLoot(getAllArguments(args, 2), 'weapon');
                            break;
                        case 'armor':
                            PHPlugins.PHWarehouse.addLoot(getAllArguments(args, 2), 'armor');
                            break;
                        case 'keyItem':
                            PHPlugins.PHWarehouse.addLoot(getAllArguments(args, 2), 'keyItem');
                            break;
                    }
                    break;
            }
        }
    };



    /* ---------------------------------------------------------- *
     *                       WINDOW PROCESS                       *
     * ---------------------------------------------------------- */

    function Window_WarehouseTitle() {
        this.initialize.apply(this, arguments);
    }
    Window_WarehouseTitle.prototype = Object.create(Window_Base.prototype);
    Window_WarehouseTitle.prototype.constructor = Window_WarehouseTitle;

    Window_WarehouseTitle.prototype.initialize = function() {
        Window_Base.prototype.initialize.call(this, 0, 0, Graphics.boxWidth, this.fittingHeight(1));
        this.refresh();
    };

    Window_WarehouseTitle.prototype.refresh = function() {
        this.contents.clear();
        this.changeTextColor(this.crisisColor());
        this.drawText(PHPlugins.PHWarehouse._lastActive, 0, 0, Graphics.boxWidth, "center");
    };



    function Window_WarehouseOption() {
        this.initialize.apply(this, arguments);
    }
    Window_WarehouseOption.prototype = Object.create(Window_Selectable.prototype);
    Window_WarehouseOption.prototype.constructor = Window_WarehouseOption;

    Window_WarehouseOption.prototype.initialize = function() {
        Window_Selectable.prototype.initialize.call(this, 0, this.fittingHeight(1), Graphics.boxWidth, this.fittingHeight(1));
        this.withdrawText = PHPlugins.Params.PHWarehouseWithdrawText;
        this.depositText = PHPlugins.Params.PHWarehouseDepositText;
        this.refresh();
        this.select(0);
        this.activate();
    };

    Window_WarehouseOption.prototype.maxItems = function() {
        return 2;
    };

    Window_WarehouseOption.prototype.maxCols = function() {
        return 2;
    };

    Window_WarehouseOption.prototype.changeOption = function() {
        PHPlugins.PHWarehouse._lastOption = this._index;
    };

    Window_WarehouseOption.prototype.refresh = function() {
        var rectWithdraw = this.itemRectForText(0);
        var rectDeposit = this.itemRectForText(1);
        this.drawText(this.withdrawText, rectWithdraw.x, rectWithdraw.y, rectWithdraw.width, "center");
        this.drawText(this.depositText, rectDeposit.x, rectDeposit.y, rectDeposit.width, "center");
    };



    function Window_WarehouseCategory() {
        this.initialize.apply(this, arguments);
    }
    Window_WarehouseCategory.prototype = Object.create(Window_ItemCategory.prototype);
    Window_WarehouseCategory.prototype.constructor = Window_WarehouseCategory;

    Window_WarehouseCategory.prototype.initialize = function() {
        Window_ItemCategory.prototype.initialize.call(this);
        this.y = this.fittingHeight(3);
        this.deselect();
        this.deactivate();
    };

    Window_WarehouseCategory.prototype.changeCategory = function() {
        PHPlugins.PHWarehouse._lastCategory = this.currentSymbol() || "item";
    };

    Window_WarehouseCategory.prototype.maxCols = function() {
        if (PHPlugins.Params.PHWarehouseAllTogether == true) {
            return 1;
        }
        var cols = 0;
        if (PHPlugins.PHWarehouse.isItemEnabled()) {
            cols++;
        }
        if (PHPlugins.PHWarehouse.isWeaponEnabled()) {
            cols++;
        }
        if (PHPlugins.PHWarehouse.isArmorEnabled()) {
            cols++;
        }
        if (PHPlugins.PHWarehouse.isKeyItemEnabled()) {
            cols++;
        }
        return cols;
    };

    Window_WarehouseCategory.prototype.makeCommandList = function() {
        if (PHPlugins.Params.PHWarehouseAllTogether == true) {
            this.addCommand(PHPlugins.Params.PHWarehouseAllText, 'all');
        } else {
            if (PHPlugins.PHWarehouse.isItemEnabled()) {
                this.addCommand(TextManager.item, 'item');
            }
            if (PHPlugins.PHWarehouse.isWeaponEnabled()) {
                this.addCommand(TextManager.weapon, 'weapon');
            }
            if (PHPlugins.PHWarehouse.isArmorEnabled()) {
                this.addCommand(TextManager.armor, 'armor');
            }
            if (PHPlugins.PHWarehouse.isKeyItemEnabled()) {
                this.addCommand(TextManager.keyItem, 'keyItem');
            }
        }
    };

    Window_WarehouseCategory.prototype.setItemWindow = function(itemWindow) {
        this._itemWindow = itemWindow;
        this.update();
    };

    // 【Claude·未经Codex检验】v0.31：原写法每帧重建并重画整张列表（新数组永远不等于旧数组），仓库因此一直很卡。改为切换页签或存取后才刷新。
    Window_WarehouseCategory.prototype.update = function() {
        Window_ItemCategory.prototype.update.call(this);
        this.changeCategory();
        var key = PHPlugins.PHWarehouse._lastOption + ':' + PHPlugins.PHWarehouse._lastCategory;
        if (this._itemWindow && (this._itemWindow._phListKey !== key || this._itemWindow._phDirty)) {
            this._itemWindow._phListKey = key;
            this._itemWindow._phDirty = false;
            this._itemWindow.refresh();
        }
    };


    function Window_WarehouseItemList() {
        this.initialize.apply(this, arguments);
    }
    Window_WarehouseItemList.prototype = Object.create(Window_ItemList.prototype);
    Window_WarehouseItemList.prototype.constructor = Window_WarehouseItemList;

    Window_WarehouseItemList.prototype.initialize = function() {
        Window_ItemList.prototype.initialize.call(this, 0, this.fittingHeight(5), Graphics.boxWidth, Graphics.boxHeight - this.fittingHeight(7));
    };

    Window_WarehouseItemList.prototype.isCurrentItemEnabled = function() {
        if (this._data.length > 0) {
            if (PHPlugins.PHWarehouse._lastOption == 1 && PHPlugins.PHWarehouse.checkCapacity()) {
                return true;
            } else if (PHPlugins.PHWarehouse._lastOption == 0) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    };

    Window_WarehouseItemList.prototype.makeWarehouseItemList = function() {
        var data = PHPlugins.PHWarehouse.getItems();
        this._data = data.filter(function(item) {
            if (PHPlugins.Params.PHWarehouseAllTogether == true) {
                return this.includesWarehouseAll(item);
            } else {
                return this.includes(item);
            }
        }, this);
        if (this.includes(null)) {
            this._data.push(null);
        }
    };

    Window_WarehouseItemList.prototype.includesWarehouseAll = function(item) {
        return ( (DataManager.isItem(item) && item.itypeId === 1) || (DataManager.isWeapon(item)) || (DataManager.isArmor(item)) || (DataManager.isItem(item) && item.itypeId === 2) );
    };

    Window_WarehouseItemList.prototype.makeDepositAllItemList = function() {
        this._data = $gameParty.allItems();
    };

    Window_WarehouseItemList.prototype.loadItems = function() {

        // Deposit
        if (PHPlugins.PHWarehouse._lastOption == 1) {
            if (PHPlugins.Params.PHWarehouseAllTogether == true) {
                this.makeDepositAllItemList();
            } else {
                this.makeItemList();
            }
        }

        // Withdraw
        else if (PHPlugins.PHWarehouse._lastOption == 0) {
            this.makeWarehouseItemList();
        }

    };

    Window_WarehouseItemList.prototype.drawItem = function(index) {
        var item = this._data[index];
        if (item) {
            var numberWidth = this.numberWidth();
            var rect = this.itemRect(index);
            rect.width -= this.textPadding();

            this.changePaintOpacity(PHPlugins.PHWarehouse.verifyItem(item));
            this.drawItemName(item, rect.x, rect.y, rect.width - numberWidth);

            if (PHPlugins.PHWarehouse._lastOption == 1) {
                this.drawItemNumber(item, rect.x, rect.y, rect.width);
            } else if (PHPlugins.PHWarehouse._lastOption == 0) {
                this.drawWarehouseItemNumber(item, rect.x, rect.y, rect.width);
            }

            this.changePaintOpacity(1);
        }
    };

    Window_WarehouseItemList.prototype.drawWarehouseItemNumber = function(item, x, y, width) {
        var qtty = PHPlugins.PHWarehouse.getQuantity(item);
        if (typeof Yanfly !== "undefined") {
            this.contents.fontSize = Yanfly.Param.ItemQuantitySize;
            this.drawText('\u00d7' + qtty, x, y, width, 'right');
            this.resetFontSettings();
        } else {
            this.drawText(':', x, y, width - this.textWidth('00'), 'right');
            this.drawText(qtty, x, y, width, 'right');
        }
    };

    Window_WarehouseItemList.prototype.refresh = function() {
        this.contents.clear();
        this.loadItems();
        this.drawAllItems();
    };

    Window_WarehouseItemList.prototype.moveItem = function() {

        var item = this.item();
        this._phDirty = true;

        // Deposit
        if (PHPlugins.PHWarehouse._lastOption == 1) {
            if (PHPlugins.PHWarehouse.checkCapacity() && PHPlugins.PHWarehouse.verifyItem(item)) {
                SoundManager.playEquip();
                PHPlugins.PHWarehouse.deposit(item);
                $gameParty.loseItem(item, 1);
            } else {
                SoundManager.playBuzzer();
            }
        }

        // Withdraw
        else if (PHPlugins.PHWarehouse._lastOption == 0) {
            if (PHPlugins.PHWarehouse.verifyItem(item)) {
                var numItems = $gameParty.numItems(item);
                $gameParty.gainItem(item, 1);
                if (numItems < $gameParty.numItems(item)) {
                    SoundManager.playEquip();
                    PHPlugins.PHWarehouse.withdraw(item);
                } else {
                    SoundManager.playBuzzer();
                }
            } else {
                SoundManager.playBuzzer();
            }
        }

    };

    Window_WarehouseItemList.prototype.playOkSound = function() { };



    function Window_WarehouseInfo() {
        this.initialize.apply(this, arguments);
    }
    Window_WarehouseInfo.prototype = Object.create(Window_Base.prototype);
    Window_WarehouseInfo.prototype.constructor = Window_WarehouseInfo;

    Window_WarehouseInfo.prototype.initialize = function() {
        Window_Base.prototype.initialize.call(this, 0, Graphics.boxHeight - this.fittingHeight(1), Graphics.boxWidth, this.fittingHeight(1));
        this.availableSpaceText = PHPlugins.Params.PHWarehouseAvailableSpaceText + " ";
        this.refresh();
    };

    Window_WarehouseInfo.prototype.refresh = function() {
        this.contents.clear();
        this.availableSpaceValue = (PHPlugins.PHWarehouse._warehouses[PHPlugins.PHWarehouse._lastActive].maxCapacity - PHPlugins.PHWarehouse.getCurrentCapacity(PHPlugins.PHWarehouse._lastActive)) + " / " + PHPlugins.PHWarehouse._warehouses[PHPlugins.PHWarehouse._lastActive].maxCapacity;
        this.changeTextColor(this.normalColor());
        this.drawText(this.availableSpaceText + this.availableSpaceValue, 0, 0, this.x);
    };



    /* ---------------------------------------------------------- *
     *                        SCENE PROCESS                       *
     * ---------------------------------------------------------- */

    function Scene_Warehouse() {
        this.initialize.apply(this, arguments);
    }

    Scene_Warehouse.prototype = Object.create(Scene_MenuBase.prototype);
    Scene_Warehouse.prototype.constructor = Scene_Warehouse;

    Scene_Warehouse.prototype.initialize = function() {
        Scene_MenuBase.prototype.initialize.call(this);
    };

    Scene_Warehouse.prototype.create = function() {
        Scene_MenuBase.prototype.create.call(this);

        this.createTitle();
        this.createOptions();
        this.createCategory();
        this.createItemList();
        this.createInfoLocation();

    };

    Scene_Warehouse.prototype.createTitle = function() {
        this._titleWindow = new Window_WarehouseTitle();
        this.addWindow(this._titleWindow);
    };

    Scene_Warehouse.prototype.createOptions = function() {
        this._optionWindow = new Window_WarehouseOption();
        this._optionWindow.setHandler('cancel', this.popScene.bind(this));
        this._optionWindow.setHandler('ok', this.onOptionOk.bind(this));
        this.addWindow(this._optionWindow);
    };

    Scene_Warehouse.prototype.createCategory = function() {
        this._categoryWindow = new Window_WarehouseCategory();
        this._categoryWindow.setHandler('cancel', this.onCategoryCancel.bind(this));
        this._categoryWindow.setHandler('ok', this.onCategoryOk.bind(this));
        this.addWindow(this._categoryWindow);
    };

    Scene_Warehouse.prototype.createItemList = function() {
        this._itemWindow = new Window_WarehouseItemList();
        this._itemWindow.setHandler('ok', this.onItemOk.bind(this));
        this._itemWindow.setHandler('cancel', this.onItemCancel.bind(this));
        this.addWindow(this._itemWindow);
        this._categoryWindow.setItemWindow(this._itemWindow);
    };

    Scene_Warehouse.prototype.createInfoLocation = function() {
        this._infoLocationWindow = new Window_WarehouseInfo();
        this.addWindow(this._infoLocationWindow);
    };

    Scene_Warehouse.prototype.onOptionOk = function() {
        this._optionWindow.changeOption();
        this._categoryWindow.activate();
        this._categoryWindow.select(0);
        this._optionWindow.deactivate();
    };

    Scene_Warehouse.prototype.onCategoryOk = function() {
        this._itemWindow.activate();
        if (this._itemWindow._data.length > 0) {
            this._itemWindow.select(0);
        }
        this._categoryWindow.deactivate();
    };

    Scene_Warehouse.prototype.onCategoryCancel = function() {
        this._categoryWindow.deselect();
        this._optionWindow.activate();
    };

    Scene_Warehouse.prototype.onItemCancel = function() {
        this._itemWindow.deselect();
        this._categoryWindow.activate();
    };

    Scene_Warehouse.prototype.onItemOk = function() {
        this._itemWindow.moveItem();
        this._infoLocationWindow.refresh();
        this._itemWindow.activate();
    };

})();