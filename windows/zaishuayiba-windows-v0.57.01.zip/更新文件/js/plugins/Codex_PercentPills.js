// 【Codex·未经Claude检验】v0.13 每颗2%，20颗上限保留；原始实现作者Claude，未经claude检验。
/*:
 * @plugindesc v1.00 后期百分比丹药：<CodexPill: mhp|atk|def|mat|mdf|agi>，每颗该属性永久+2%，每名角色每种最多20颗
 * @author Claude
 * @help
 * 2026-10-08 用户接受「丹药做后期百分比版」。原生道具（菜单中对一名队友使用、消耗品），
 * 不改原有固定值丹药及其一品/二品计数。计数存在角色 _codexPills，随存档保存。
 * 在出售二品丹药（养血丹 1693）的原生商店追加本丹药（方桌大厅、蜜雪冰城），不改地图数据。
 */
var Imported = Imported || {}; Imported.Codex_PercentPills = true;
(function() {
    'use strict';
    var KEYS = {mhp: 0, mmp: 1, atk: 2, def: 3, mat: 4, mdf: 5, agi: 6, luk: 7}, STEP = 0.02, CAP = 20, SHOP_ANCHOR = 1693;
    function pillOf(item) { var k = item && item.meta && item.meta.CodexPill; k = k && String(k).trim(); return KEYS.hasOwnProperty(k) ? KEYS[k] : -1; }
    var P = window.CodexPills = {step: STEP, cap: CAP, paramOf: pillOf};
    P.count = function(actor, id) { return (actor && actor._codexPills && actor._codexPills[id]) || 0; };
    P.rate = function(actor, id) { return 1 + STEP * P.count(actor, id); };
    var hasValid = Game_Action.prototype.hasItemAnyValidEffects;
    Game_Action.prototype.hasItemAnyValidEffects = function(target) {
        var id = pillOf(this.item());
        if (id >= 0) return !!(target && target.isActor && target.isActor() && P.count(target, id) < CAP);
        return hasValid.apply(this, arguments);
    };
    var userEffect = Game_Action.prototype.applyItemUserEffect;
    Game_Action.prototype.applyItemUserEffect = function(target) {
        var id = pillOf(this.item());
        if (id >= 0 && target && target.isActor && target.isActor() && P.count(target, id) < CAP) {
            target._codexPills = target._codexPills || {};
            target._codexPills[id] = P.count(target, id) + 1;
            target.refresh(); this.makeSuccess(target);
            if (window.$ && $.toaster) $.toaster({message: target.name() + ' ' + TextManager.param(id) + ' +' + Math.round(STEP * 100 * P.count(target, id)) + '%（' + P.count(target, id) + '/' + CAP + '）'});
        }
        return userEffect.apply(this, arguments);
    };
    var param = Game_Actor.prototype.param;
    Game_Actor.prototype.param = function(id) {
        var value = param.apply(this, arguments), n = P.count(this, id);
        return n ? Math.round(Math.min(this.paramMax(id), value * (1 + STEP * n))) : value;
    };
    if (typeof Scene_Shop !== 'undefined') {
        var prepare = Scene_Shop.prototype.prepare;
        Scene_Shop.prototype.prepare = function(goods, purchaseOnly) {
            goods = (goods || []).slice();
            if (goods.some(function(g) { return g[0] === 0 && g[1] === SHOP_ANCHOR; })) {
                ($dataItems || []).forEach(function(i) { if (pillOf(i) >= 0 && !goods.some(function(g) { return g[0] === 0 && g[1] === i.id; })) goods.push([0, i.id, 0, 0]); });
            }
            return prepare.call(this, goods, purchaseOnly);
        };
    }
})();
