// 【Claude·未经Codex检验】v0.15 服装目录分类按七档（含神话），典藏分类保留。
// =============================================================================
// Star_ChangeClothes.js
// Version: 1.00
//================================================================================
/*:
 * @plugindesc 换装系统
 * @author Star
 *
 * @param ChangeClothes List 1-25
 * @text ----换装列表1-25----
 * @default
 *
 * @param ChangeClothes 1
 * @text 换装1
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 2
 * @text 换装2
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 3
 * @text 换装3
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 4
 * @text 换装4
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 5
 * @text 换装5
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 6
 * @text 换装6
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 7
 * @text 换装7
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 8
 * @text 换装8
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 9
 * @text 换装9
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 10
 * @text 换装10
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 11
 * @text 换装11
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 12
 * @text 换装12
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 13
 * @text 换装13
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 14
 * @text 换装14
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 15
 * @text 换装15
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 16
 * @text 换装16
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 17
 * @text 换装17
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 18
 * @text 换装18
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 19
 * @text 换装19
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 20
 * @text 换装20
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 21
 * @text 换装21
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 22
 * @text 换装22
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 23
 * @text 换装23
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 24
 * @text 换装24
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 25
 * @text 换装25
 * @parent ChangeClothes List 1-25
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes List 26-50
 * @text ----换装列表26-50----
 * @default
 *
 * @param ChangeClothes 26
 * @text 换装26
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 27
 * @text 换装27
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 28
 * @text 换装28
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 29
 * @text 换装29
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 30
 * @text 换装30
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 31
 * @text 换装31
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 32
 * @text 换装32
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 33
 * @text 换装33
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 34
 * @text 换装34
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 35
 * @text 换装35
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 36
 * @text 换装36
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 37
 * @text 换装37
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 38
 * @text 换装38
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 39
 * @text 换装39
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 40
 * @text 换装40
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 41
 * @text 换装41
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 42
 * @text 换装42
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 43
 * @text 换装43
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 44
 * @text 换装44
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 45
 * @text 换装45
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 46
 * @text 换装46
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 47
 * @text 换装47
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 48
 * @text 换装48
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 49
 * @text 换装49
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 50
 * @text 换装50
 * @parent ChangeClothes List 26-50
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes List 51-75
 * @text ----换装列表51-75----
 * @default
 *
 * @param ChangeClothes 51
 * @text 换装51
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 52
 * @text 换装52
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 53
 * @text 换装53
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 54
 * @text 换装54
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 55
 * @text 换装55
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 56
 * @text 换装56
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 57
 * @text 换装57
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 58
 * @text 换装58
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 59
 * @text 换装59
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 60
 * @text 换装60
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 61
 * @text 换装61
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 62
 * @text 换装62
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 63
 * @text 换装63
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 64
 * @text 换装64
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 65
 * @text 换装65
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 66
 * @text 换装66
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 67
 * @text 换装67
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 68
 * @text 换装68
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 69
 * @text 换装69
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 70
 * @text 换装70
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 71
 * @text 换装71
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 72
 * @text 换装72
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 73
 * @text 换装73
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 74
 * @text 换装74
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 75
 * @text 换装75
 * @parent ChangeClothes List 51-75
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes List 76-100
 * @text ----换装列表76-100----
 * @default
 *
 * @param ChangeClothes 76
 * @text 换装76
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 77
 * @text 换装77
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 78
 * @text 换装78
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 79
 * @text 换装79
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 80
 * @text 换装80
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 81
 * @text 换装81
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 82
 * @text 换装82
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 83
 * @text 换装83
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 84
 * @text 换装84
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 85
 * @text 换装85
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 86
 * @text 换装86
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 87
 * @text 换装87
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 88
 * @text 换装88
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 89
 * @text 换装89
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 90
 * @text 换装90
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 91
 * @text 换装91
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 92
 * @text 换装92
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 93
 * @text 换装93
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 94
 * @text 换装94
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 95
 * @text 换装95
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 96
 * @text 换装96
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 97
 * @text 换装97
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 98
 * @text 换装98
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 99
 * @text 换装99
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 * @param ChangeClothes 100
 * @text 换装100
 * @parent ChangeClothes List 76-100
 * @type struct<ChangeClothes>
 * @default 
 *
 *
 * @param ChangeClothes List 101-150
 * @text ----换装列表101-150----
 * @default
 *
 * @param ChangeClothes 101
 * @text 换装101
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 *
 * @param ChangeClothes 102
 * @text 换装102
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 103
 * @text 换装103
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 104
 * @text 换装104
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 105
 * @text 换装105
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 106
 * @text 换装106
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 107
 * @text 换装107
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 108
 * @text 换装108
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 109
 * @text 换装109
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 110
 * @text 换装110
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 111
 * @text 换装111
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 112
 * @text 换装112
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 113
 * @text 换装113
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 114
 * @text 换装114
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 115
 * @text 换装115
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 116
 * @text 换装116
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 *
 * @param ChangeClothes 117
 * @text 换装117
 * @parent ChangeClothes List 101-150
 * @type struct<ChangeClothes>
 * @default
 @help
 // 获得额外
 if(ConfigManager.ChangeClothesLite.indexOf(-4) == -1){
	ConfigManager.ChangeClothesLite.push(-4);
  }
  // 打开界面
  SceneManager.push(Scene_ChangeClothes)

 */
/* ---------------------------------------------------------------------------
 * struct<ChangeClothes>
 * ---------------------------------------------------------------------------
 */
/*~struct~ChangeClothes:
 *
 * @param name
 * @text 名称
 * @desc 名称
 * @default 
 *
 * @param characterName
 * @text 文件名称
 * @desc 文件名称
 * @default 
 *
 * @param characterIndex
 * @text 图片序号
 * @desc 图片序号
 * @type number
 * @default 
 *
 * @param GetFs
 * @text 获取途经
 * @desc 获取途经
 * @default 
 *
 */
var Star = Star;
Star.ChangeClothes = Star.ChangeClothes || {};
Star.ChangeClothes.parameters = PluginManager.parameters("Star_ChangeClothes");
// Star.ChangeClothes.NewNum = [{name:"测试1",characterName:"Damage1",characterIndex:3,id:-1},{name:"测试2",characterName:"Damage1",characterIndex:2,id:-2}];

Star.ChangeClothes.DataManager_isDatabaseLoaded = DataManager.isDatabaseLoaded;
DataManager.isDatabaseLoaded = function() {
    if (!Star.ChangeClothes.DataManager_isDatabaseLoaded.call(this))
		return false;
    if (!Star._loaded_Star_ChangeClothes) {
		this.Star_GetChangeClothesOpt();
        Star._loaded_Star_ChangeClothes = true;
    }
    return true;
};

DataManager.Star_GetChangeClothesOpt = function() {
    Star.ChangeClothes.NewNum = [null];
    for (var i = 1; i <= 150; ++i) {
        var ChangeClothesOptData = JSON.parse(Star.ChangeClothes.parameters['ChangeClothes ' + i] || 'null');
        if (ChangeClothesOptData) {
			this.Star_ChangeClothesDatabaseAdd(i, ChangeClothesOptData);
		}
    }
	Star.ChangeClothes.parameters = {};
};

DataManager.Star_ChangeClothesDatabaseAdd = function(id, data) {
    if (!data) return Star.ChangeClothes.NewNum.push(null);
    var ChangeClothes = {
        id: -id,
        name: data['name'], // 名称
        characterName: data['characterName'], // 图片
        characterIndex: Number(data['characterIndex']), // 序号
		GetFs: data['GetFs'] // 获得方式
    };
    Star.ChangeClothes.NewNum.push(ChangeClothes);
};

Star.ChangeClothes.ConfigManager_makeData = ConfigManager.makeData;
ConfigManager.makeData = function() {
    var config = Star.ChangeClothes.ConfigManager_makeData.call(this);
    config.ChangeClothesLite = this.ChangeClothesLite || [];
    return config;
};

Star.ChangeClothes.ConfigManager_applyData = ConfigManager.applyData;
ConfigManager.applyData = function(config) {
	Star.ChangeClothes.ConfigManager_applyData.call(this, config)
    this.ChangeClothesLite = config["ChangeClothesLite"] || [];
};

// SceneManager.push(Scene_ChangeClothes)
//=============================================================================
// Scene_ChangeClothes
//=============================================================================

Scene_ChangeClothes = function() {
    this.initialize.apply(this, arguments);
}
Scene_ChangeClothes.prototype = Object.create(Scene_MenuBase.prototype);
Scene_ChangeClothes.prototype.constructor = Scene_ChangeClothes;

Scene_ChangeClothes.prototype.initialize = function() {
	// ConfigManager.ChangeClothesLite = ConfigManager.ChangeClothesLite || [];
    for (var i = 0; i < $gameParty.members().length; i++) {
		if(ConfigManager.ChangeClothesLite.indexOf($gameParty.members()[i]._actorId) == -1){
			ConfigManager.ChangeClothesLite.push($gameParty.members()[i]._actorId);
		}
	}
	if($gameParty._saveactors){
      for (var i = 0; i < $gameParty._saveactors.length; i++) {
		if(ConfigManager.ChangeClothesLite.indexOf($gameParty._saveactors[i]) == -1){
			ConfigManager.ChangeClothesLite.push($gameParty._saveactors[i]);
		}
	  }
	}
    Scene_MenuBase.prototype.initialize.call(this);
};

Scene_ChangeClothes.prototype.create = function() {
    Scene_MenuBase.prototype.create.call(this);
    this._windowIdx = -1;
    this._indexWindow = new Window_ChangeClothesC(0, 0);
    this._indexWindow.setHandler('ok', this.onRangeOk.bind(this));
    this._indexWindow.setHandler('cancel', this.RancancelA.bind(this));
    var wx = this._indexWindow.width;
    var ww = Graphics.boxWidth - wx;
    // 高度拉满
    var wh = Graphics.boxHeight;
    this._AListWindow = new Window_ChangeClothesIndex(wx, 0);
    var wwx = wx + this._AListWindow.width;
    var www = Graphics.boxWidth - wwx;
    this._AListWindow.setHandler('ok', this.onRefSzOk.bind(this));
    this._AListWindow.setHandler('cancel', this.Rancancel.bind(this));
    this._statusWindow = new Window_ChangeClothesStatus(wwx, 0, www, wh);
    this.addWindow(this._indexWindow);
    this.addWindow(this._AListWindow);
    this.addWindow(this._statusWindow);
	this._indexWindow.refresh();
    this._indexWindow.select(-1);
    this._indexWindow.show();
	this._AListWindow.refresh(1);
    this._AListWindow.select(-1);
    this._AListWindow.show();
    this._AListWindow.setStatusWindow(this._AListWindow);
    this.createBottomConfirmWindow();
};
Scene_ChangeClothes.prototype.createBottomConfirmWindow = function() {
        this._BottomconfirmWindow = new Window_ChangeClothesConfirm(0, Graphics.boxHeight);
        this._BottomconfirmWindow.setHandler('TiHuan', this.onGHOk.bind(this));
        this._BottomconfirmWindow.setHandler('HuanYuan',  this.onHYOk.bind(this));
        this._BottomconfirmWindow.setHandler('cancel', this.popScene.bind(this));
        this.addWindow(this._BottomconfirmWindow);
    	this._BottomconfirmWindow.open();
    	this._BottomconfirmWindow.activate();
    	this._BottomconfirmWindow.select(0);
};

Scene_ChangeClothes.prototype.onGHOk = function() {
    SoundManager.playOk();
    this._BottomconfirmWindow.select(-1);
    this._BottomconfirmWindow.deactivate();
    this._indexWindow.select(0);
    this._indexWindow.activate();
};
Scene_ChangeClothes.prototype.onHYOk = function() {
    $gamePlayer.Set_OcharacterName = null;
    	$gamePlayer.Set_OcharacterIndex = null;
		if($ && $.toaster) $.toaster({ message : '还原完成'});
    this._BottomconfirmWindow.activate();
};
Scene_ChangeClothes.prototype.RancancelA = function() {
    SoundManager.playOk();
    this._indexWindow.select(-1);
    this._indexWindow.deactivate();
    this._BottomconfirmWindow.activate();
    this._BottomconfirmWindow.select(0);
};
Scene_ChangeClothes.prototype.onRangeOk = function() {
    SoundManager.playOk();
	if(this._indexWindow.index() == 6){
	    this._AListWindow.refresh(0);
        this._AListWindow.select(0);
		this._statusWindow.setupWhenCheck();
		this._AListWindow.activate();
	}else{
	    this._AListWindow.refresh(this._indexWindow.index() + 1);
        this._AListWindow.select(0);
		this._statusWindow.setupWhenCheck();
		this._AListWindow.activate();
	}
};
Scene_ChangeClothes.prototype.onRefSzOk = function() {
    SoundManager.playOk();
	if(ConfigManager.ChangeClothesLite.indexOf(this._AListWindow._list[this._AListWindow.index()].id) != -1){
		$gamePlayer.Set_OcharacterName = this._AListWindow._list[this._AListWindow.index()].characterName;
		$gamePlayer.Set_OcharacterIndex = this._AListWindow._list[this._AListWindow.index()].characterIndex;
		if($ && $.toaster) $.toaster({ message : '替换完成'});
	}else{
		if($ && $.toaster) $.toaster({ message : '未解锁'});
	}
	this._AListWindow.activate();
};
Scene_ChangeClothes.prototype.Rancancel = function() {
    SoundManager.playOk();
    this._AListWindow.select(-1);
    this._AListWindow.deactivate();
    this._indexWindow.activate();
};
Star.ChangeClothes.SAAupdate = Scene_ChangeClothes.prototype.update;
Scene_ChangeClothes.prototype.update = function() {
    Star.ChangeClothes.SAAupdate.call(this);
    if (this._AListWindow.index() !== this._AIdx && this._AListWindow.index() >= 0) {
        this._AIdx = this._AListWindow.index();
		this._statusWindow.setupWhenCheck();
    };
	if (this._indexWindow.index() !== this._WIdx && this._indexWindow.index() >= 0) {
        this._WIdx = this._indexWindow.index();
		if(this._WIdx == 6){
			this._AListWindow.refresh(0);
		}else{
			this._AListWindow.refresh(this._indexWindow.index() + 1);
		}
    }
};
Scene_ChangeClothes.prototype.calcStatusWindowHeight = function() {
    var lineHeight = Window_Base.prototype.lineHeight();
    var textPadding = Window_Base.prototype.textPadding();
    var standardPadding = Window_Base.prototype.standardPadding();
    var paramHeight = Scene_ChangeClothes.prototype.calcParameterHeight();
    var height = paramHeight + standardPadding * 2;
    return height;
};

Scene_ChangeClothes.prototype.calcParameterHeight = function() {
    var lineHeight = Window_Base.prototype.lineHeight();
    var textPadding = Window_Base.prototype.textPadding();
    var standardPadding = Window_Base.prototype.standardPadding();
    var height = 0;
    height = lineHeight * 6 + textPadding * 2;

    return height;
};


function Window_ChangeClothesConfirm() {
    this.initialize.apply(this, arguments);
}

Window_ChangeClothesConfirm.prototype = Object.create(Window_Command.prototype);
Window_ChangeClothesConfirm.prototype.constructor = Window_ChangeClothesConfirm;

Window_ChangeClothesConfirm.prototype.initialize = function(x, y) {
    Window_Command.prototype.initialize.call(this, x, y - this.windowHeight());
};

Window_ChangeClothesConfirm.prototype.makeCommandList = function() {
    this.addCommand("更换", 'TiHuan');
    this.addCommand("还原当前形象", 'HuanYuan');
};

Window_ChangeClothesConfirm.prototype.windowWidth = function() {
    return Graphics.boxWidth / 3;
};
Window_ChangeClothesConfirm.prototype.windowHeight = function() {
    return this.fittingHeight(2);
};

//=============================================================================
// Window_ChangeClothesC
//=============================================================================
Window_ChangeClothesC = function() {
    this.initialize.apply(this, arguments);
}
Window_ChangeClothesC.prototype = Object.create(Window_Selectable.prototype);
Window_ChangeClothesC.prototype.constructor = Window_ChangeClothesC;

Window_ChangeClothesC.lastIndex = 0;

Window_ChangeClothesC.prototype.initialize = function(x, y) {
    var width = Math.floor(Graphics.boxWidth / 3);
    var height = Graphics.boxHeight;
    Window_Selectable.prototype.initialize.call(this, x, y, width, height - this.fittingHeight(2));
}

Window_ChangeClothesC.prototype.setup = function() {
    this.refresh();
    this.select(0);
    this.show();
    this.activate();
    this.open();
};

Window_ChangeClothesC.prototype.setupWhenCheck = function() {
    this.refresh();
    this.select(0);
    this.openness = 255;
    this.hide();
    this.activate();
};

Window_ChangeClothesC.prototype.maxCols = function() {
    return 1;
};

Window_ChangeClothesC.prototype.maxItems = function() {
    return this._list ? this._list.length : 0;
};

Window_ChangeClothesC.prototype.setPercentWindow = function(percentWindow) {
    this._percentWindow = percentWindow;
    this.updatePercent();
};

Window_ChangeClothesC.prototype.setStatusWindow = function(statusWindow) {
    this._statusWindow = statusWindow;
};

Window_ChangeClothesC.prototype.updatePercent = function() {
    if (this._percentWindow && this._list) {
        var a = $gameSystem.getRegisterNumber();
        this._percentWindow.setAchievement(this._list.length, a);
    }
}

Window_ChangeClothesC.prototype.refresh = function() {
    this._list = ["普通","优秀","精良","史诗","传说","不朽","神话","典藏"];
    this.createContents();
    this.drawAllItems();
};

  // SceneManager.push(Scene_ChangeClothes)
Window_ChangeClothesC.prototype.drawItem = function(index) {
    var Name = this._list[index];
    var rect = this.itemRectForText(index);
    this.drawText(Name, rect.x, rect.y, rect.width);
};

//=============================================================================
// Window_ChangeClothesIndex
//=============================================================================
Window_ChangeClothesIndex = function() {
    this.initialize.apply(this, arguments);
}
Window_ChangeClothesIndex.prototype = Object.create(Window_Selectable.prototype);
Window_ChangeClothesIndex.prototype.constructor = Window_ChangeClothesIndex;

Window_ChangeClothesIndex.lastIndex = 0;

Window_ChangeClothesIndex.prototype.initialize = function(x, y) {
    var width = Math.floor(Graphics.boxWidth / 3);
    var height = Graphics.boxHeight;
    Window_Selectable.prototype.initialize.call(this, x, y, width, height);
}

Window_ChangeClothesIndex.prototype.setup = function() {
    this.refresh(1);
    this.select(0);
    this.show();
    this.activate();
    this.open();
};

Window_ChangeClothesIndex.prototype.setupWhenCheck = function() {
    this.refresh(1);
    this.select(0);
    this.openness = 255;
    this.hide();
    this.activate();
};

Window_ChangeClothesIndex.prototype.maxCols = function() {
    return 1;
};

Window_ChangeClothesIndex.prototype.maxItems = function() {
    return this._list ? this._list.length : 0;
};

Window_ChangeClothesIndex.prototype.setPercentWindow = function(percentWindow) {
    this._percentWindow = percentWindow;
    this.updatePercent();
};

Window_ChangeClothesIndex.prototype.setStatusWindow = function(statusWindow) {
    this._statusWindow = statusWindow;
};


Window_ChangeClothesIndex.prototype.updatePercent = function() {
    if (this._percentWindow && this._list) {
        var a = $gameSystem.getRegisterNumber();
        this._percentWindow.setAchievement(this._list.length, a);
    }
}

Window_ChangeClothesIndex.prototype.refresh = function(id) {
    this._list = [];
	if(typeof id == "number") this.Lid = id;
	else id = this.Lid;
	for (var i = 1; i < $dataActors.length; i++) {
		if($dataActors[i].name != "" && (window.CodexQuality?CodexQuality.actorGrade($dataActors[i])===id-1:Number($dataActors[i].meta.Actorquality)==id)) this._list.push($dataActors[i]);// 目录添加
    }
	for (var i = 0; i < Star.ChangeClothes.NewNum.length; i++) {
		if(Star.ChangeClothes.NewNum[i] && !id) this._list.push(Star.ChangeClothes.NewNum[i]);// 目录添加
    }
	
    this.createContents();
    this.drawAllItems();
};

// SceneManager.push(Scene_ChangeClothes)
Window_ChangeClothesIndex.prototype.drawItem = function(index) {
  if(this._list[index]){
	// if(this._list[index].meta && this._list[index].meta.Actorquality) {
	  var bitmap = ImageManager.loadCharacter(this._list[index].characterName);
      if (bitmap.width <= 0) {
        return setTimeout(this.drawItem.bind(this, index), 5);
      }
      this.clearItem(index);
	  if(ConfigManager.ChangeClothesLite.indexOf(this._list[index].id) != -1){
		var rect = this.itemRect(index);
		this.drawBasic(this._list[index], rect);
	  }else{
        var rect = this.itemRectForText(index);
		this.drawText("？？？", rect.x, rect.y, rect.width);
	  }
      
	// }else{
        // var Name = this._list[index].name;
        // var rect = this.itemRectForText(index);
		// this.drawText(Name, rect.x, rect.y, rect.width);
	// }
  }
};

Window_ChangeClothesIndex.prototype.drawBasic = function(actor, rect) {
    var wx = Window_Base._iconWidth / 2 + this.textPadding() / 2;
    var wy = rect.y + rect.height + Yanfly.Param.PartySpriteBufferY
    if (Yanfly.Param.PartyShowListSprite) {
      this.drawCharacter(actor.characterName, actor.characterIndex, wx, wy);
    }
    var ibw = Window_Base._iconWidth + 4;
    if (!Yanfly.Param.PartyShowListSprite) ibw = this.textPadding();
    this.drawText(actor.name, rect.x + ibw, rect.y, rect.width - ibw);
    this.resetFontSettings();
};
//=============================================================================
// Window_ChangeClothesStatus
//=============================================================================

Window_ChangeClothesStatus = function() {
    this.initialize.apply(this, arguments);
};

Window_ChangeClothesStatus.prototype = Object.create(Window_Base.prototype);
Window_ChangeClothesStatus.prototype.constructor = Window_ChangeClothesStatus;

Window_ChangeClothesStatus.prototype.initialize = function(x, y, width, height) {
    Window_Base.prototype.initialize.call(this, x, y, width, height);
    this._defaultX = x;
    this._windowWidth = width;
    this._Sprite = new Sprite();
    this._Sprite.anchor.x = 0.5;
    this._Sprite.anchor.y = 0.5;
    this._Sprite.x = width / 4;
    this._Sprite.y = width / 4 + this.lineHeight();
    this._spriteFrameCount = this._spriteFrameCount || 0;
    this._spriteFRef = this._spriteFRef || 0;
    this.addChildToBack(this._Sprite);
};

Window_ChangeClothesStatus.prototype.setup = function() {
    this.x = this._defaultX;
    this.setupbacksprite();
    this.show();
    this.open();
};

Window_ChangeClothesStatus.prototype.setupWhenCheck = function() {
    this.x = Math.floor((Graphics.boxWidth - this.width) / 2);
    this.width = this._windowWidth;
    this.setupbacksprite();
    this.show();
    this.open();
};
Window_ChangeClothesStatus.prototype.setupbacksprite = function() {
    this.x = this._defaultX;
    this.width = this._windowWidth;
    // this.height = Scene_ChangeClothes.prototype.calcStatusWindowHeight();
    this.createContents();
    this.refresh();
};


Window_ChangeClothesStatus.prototype.update = function() {
    Window_Base.prototype.update.call(this);
    if (this._Sprite.bitmap) {
        var bitmap = this._Sprite.bitmap;
        if (this._spriteFrameCount % 20 === 0) {
		  if(SceneManager._scene._AListWindow._list[SceneManager._scene._AListWindow.index()] && ConfigManager.ChangeClothesLite.indexOf(SceneManager._scene._AListWindow._list[SceneManager._scene._AListWindow.index()].id) != -1){
        	var motionIndex = SceneManager._scene._AListWindow._list[SceneManager._scene._AListWindow.index()].characterIndex;
        	var cw = bitmap.width / 12;
        	var ch = bitmap.height / 8;
        	if(motionIndex > 3){
        		var cx = Math.floor(motionIndex) * 3 - 12 + this._spriteFRef;
        		var cy = 4;
        	}else{
        		var cx = motionIndex * 3 + this._spriteFRef;
        		var cy = 0;
        	}
            this._Sprite.setFrame(cx * cw, cy * ch, cw, ch);
		  }else{
			this._Sprite.bitmap = null;
			this.contents.clear();
		  }
		  this._spriteFRef += 1;
		  if(this._spriteFRef == 3) this._spriteFRef = 0;
        }
        var bitmapWidth = bitmap.width / 9;
        var contentsWidth = this.contents.width;
        var scale = 2;
        this._Sprite.scale.x = scale;
        this._Sprite.scale.y = scale;
        this._spriteFrameCount++;
    }
};


Window_ChangeClothesStatus.prototype.refresh = function() {
    var x = 0,
        y = 0,
        width = this.contentsWidth();
    height = this.height;
    //	x = Graphics.boxWidth/2 - this._windowWidth / 2;
    //	width = this._windowWidth;
    this._Sprite.x = x + width / 10;
    this._Sprite.y = width / 13;
    this.drawAllContents(x, y, width, height);
    // this.drawAllContents(x, y, width, height);
};
/*
	Window_ChangeClothesStatus.prototype.refresh = function(Actor) {
		var x = 0, y = 0, width = this.contentsWidth(); height = this.height;
			x = Graphics.boxWidth/2 - this._windowWidth / 2;
			width = this._windowWidth;
		this._Sprite.x = x+ width / 4;
		this._Sprite.y = width / 4 + this.lineHeight();
		this.drawAllContents(x,y,width,height,Actor);
	};
	*/

Window_ChangeClothesStatus.prototype.drawAllContents = function(x, y, width, height) {
	Actor = SceneManager._scene._AListWindow._list[SceneManager._scene._AListWindow.index()];
	if(!Actor){
		this._Sprite.bitmap = null;
		this.contents.clear();
		return;
	};
    // 窗口绘制
    var column1x = x;
    var column2x = width ? x + width / 2 + this.standardPadding() / 2 : this.contentsWidth() / 2 + this.standardPadding() / 2;
    var columnWidth = width ? width / 2 - this.standardPadding() : this.contentsWidth() / 2 - this.standardPadding();
    var x = x || 0;
    var y = y || 0;
    var w = columnWidth / 2 - this.standardPadding();
    //var mY = 0;
    var lineHeight = this.lineHeight();
    this.contents.clear();
	// 未解锁不显示图像
	if(ConfigManager.ChangeClothesLite.indexOf(Actor.id) != -1){
      var bitmap;
      bitmap = ImageManager.loadCharacter(Actor.characterName);
      var motionIndex = Actor.characterIndex;
      var cw = bitmap.width / 12;
      var ch = bitmap.height / 8;
      if(motionIndex > 3){
    	var cx = Math.floor(motionIndex) * 3 - 11;
    	var cy = 4;
      }else{
    	var cx = motionIndex * 3 + 1;
    	var cy = 0;
      }
      this._Sprite.bitmap = bitmap;
      this._Sprite.scale.x = 2;
      this._Sprite.scale.y = 2;
      this._Sprite.x = Graphics.boxWidth / 6;
      this._Sprite.y = Graphics.boxHeight / 2;
      this._Sprite.setFrame(cx * cw, cy * ch, cw, ch);
	}else{
		this._Sprite.bitmap = null;
	};
    this.resetTextColor();
    if(ConfigManager.ChangeClothesLite.indexOf(Actor.id) != -1) this.drawText("形象展示", column2x - this.textWidth("形象0"), y, width);
    y += lineHeight * 12;
	if(Actor.GetFs) this.drawText("获得途径:" + Actor.GetFs, x, y, width);
    else this.drawText("获得途径:获得伙伴" + Actor.name, x, y, width);
    y += lineHeight;
	if(ConfigManager.ChangeClothesLite.indexOf(Actor.id) != -1){
        this.drawText("状态:已解锁", x, y, width);
	}else{
        this.drawText("状态:未解锁", x, y, width);
	}
};

Game_CharacterBase.prototype.characterName = function() {
if(this.constructor == Game_Player) return this.Set_OcharacterName || this._characterName;
    return this._characterName;
};
Game_CharacterBase.prototype.characterIndex = function() {
if(this.constructor == Game_Player && typeof this.Set_OcharacterIndex == "number") return this.Set_OcharacterIndex;
    return this._characterIndex;
};

// 上传同屏数据时
/* Star.ChangeClothes.HosExtralData = HWGOE.override.sameScreen.extralData;
HWGOE.override.sameScreen.extralData = function (data) {
  Star.ChangeClothes.HosExtralData.call(this, data);
  data.characterName = $gamePlayer.Set_OcharacterName || data.characterName;
  if(typeof $gamePlayer.Set_OcharacterIndex == "number") data.characterIndex = $gamePlayer.Set_OcharacterIndex || data.characterIndex;
}; */
// Star.ChangeClothes.HosHandlerData = HWGOE.override.sameScreen.handlerData;
// HWGOE.override.sameScreen.handlerData = function (character, data, characterSprite) {
  // Star.ChangeClothes.HosHandlerData.call(this, character, data, characterSprite);
  // data.characterName = $gamePlayer.Set_OcharacterName || data.characterName;
  // if(typeof $gamePlayer.Set_OcharacterIndex == "number") data.characterIndex = $gamePlayer.Set_OcharacterIndex || data.characterIndex;
// };