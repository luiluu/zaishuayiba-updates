// 【Codex·未经Claude检验】核查状态：未经claude检验。
// Retired author-only, one-off inventory grant. This file intentionally has no
// load hooks, awards or automatic saves, even if an old plugin list enables it.
// Existing inventory (including legitimately earned Pudding) is preserved.
