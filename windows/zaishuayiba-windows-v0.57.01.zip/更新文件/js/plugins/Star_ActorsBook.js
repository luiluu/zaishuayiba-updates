// 【Codex·未经Claude检验】v0.35：人物图鉴依所选实例匹配详情，兼容隐藏角色过滤。
// 【Claude·未经Codex检验】v0.15 人物图鉴品质名称／颜色按七档显示，人物数据不变。
// =============================================================================
// Star_ActorBook.js
// Version: 1.00
// =============================================================================
/*:
 * @plugindesc 角色图鉴
 * @author Star

 @help
    角色图鉴
 */
var Star = Star;
Star.ActorBook = Star.ActorBook || {};
// SceneManager.push(Scene_ActorBook)
//=============================================================================
// Scene_ActorBook
//=============================================================================

Scene_ActorBook = function() {
    this.initialize.apply(this, arguments);
}
Scene_ActorBook.prototype = Object.create(Scene_MenuBase.prototype);
Scene_ActorBook.prototype.constructor = Scene_ActorBook;

Scene_ActorBook.prototype.initialize = function() {
	$gameParty.ActorBookLite = $gameParty.ActorBookLite || [];
    for (var i = 0; i < $gameParty.members().length; i++) {
		if($gameParty.ActorBookLite.indexOf($gameParty.members()[i]._actorId) == -1){
			$gameParty.ActorBookLite.push($gameParty.members()[i]._actorId);
		}
	}
	if($gameParty._saveactors){
      for (var i = 0; i < $gameParty._saveactors.length; i++) {
		if($gameParty.ActorBookLite.indexOf($gameParty._saveactors[i]) == -1){
			$gameParty.ActorBookLite.push($gameParty._saveactors[i]);
		}
	  }
	}
    Scene_MenuBase.prototype.initialize.call(this);
};

Scene_ActorBook.prototype.create = function() {
    Scene_MenuBase.prototype.create.call(this);
    this._windowIdx = -1;
    this._indexWindow = new Window_ActorBookIndex(0, 0);
    // this._indexWindow.setHandler('ok', this.onRangeOk.bind(this));
    this._indexWindow.setHandler('cancel', this.popScene.bind(this));
    // this._indexWindow.setHandler('cancel', this.popScene.bind(this));
    var wx = this._indexWindow.width;
    var ww = Graphics.boxWidth - wx;
    // 高度拉满
    var wh = Graphics.boxHeight;
    // var wh = this.calcStatusWindowHeight();
    this._statusWindow = new Window_ActorBookStatus(wx, 0, ww, wh);
    this.addWindow(this._indexWindow);
    this.addWindow(this._statusWindow);
    this._indexWindow.setup();
    this._indexWindow.setStatusWindow(this._statusWindow);
};
// SceneManager._scene._indexWindow.setupWhenCheck();
// SceneManager._scene._statusWindow.setupWhenCheck();
Scene_ActorBook.prototype.onRangeOk = function() {
    SoundManager.playOk();
    // this._indexWindow.activate();
};

Star.ActorBook.SAAupdate = Scene_ActorBook.prototype.update;
Scene_ActorBook.prototype.update = function() {
    Star.ActorBook.SAAupdate.call(this);
    var actor = this._indexWindow.actor();
    var actorId = actor ? actor.actorId() : 0;
    if (this._indexWindow.index() !== this._windowIdx || actorId !== this._windowActorId) {
        this._windowIdx = this._indexWindow.index();
        this._windowActorId = actorId;
        this._statusWindow.setupWhenCheck(actor && $gameParty.ActorBookLite.indexOf(actorId) !== -1 ? actor : false);
    }
};
Scene_ActorBook.prototype.calcStatusWindowHeight = function() {
    var lineHeight = Window_Base.prototype.lineHeight();
    var textPadding = Window_Base.prototype.textPadding();
    var standardPadding = Window_Base.prototype.standardPadding();
    var paramHeight = Scene_ActorBook.prototype.calcParameterHeight();
    var height = paramHeight + standardPadding * 2;
    return height;
};

Scene_ActorBook.prototype.calcParameterHeight = function() {
    var lineHeight = Window_Base.prototype.lineHeight();
    var textPadding = Window_Base.prototype.textPadding();
    var standardPadding = Window_Base.prototype.standardPadding();
    var height = 0;
    height = lineHeight * 6 + textPadding * 2;

    return height;
};
//=============================================================================
// Window_ActorBookIndex
//=============================================================================
Window_ActorBookIndex = function() {
    this.initialize.apply(this, arguments);
}
Window_ActorBookIndex.prototype = Object.create(Window_Selectable.prototype);
Window_ActorBookIndex.prototype.constructor = Window_ActorBookIndex;

Window_ActorBookIndex.lastIndex = 0;

Window_ActorBookIndex.prototype.initialize = function(x, y) {
    var width = Math.floor(Graphics.boxWidth / 4);
    var height = Graphics.boxHeight;
    Window_Selectable.prototype.initialize.call(this, x, y, width, height);
}

Window_ActorBookIndex.prototype.setup = function() {
    this.refresh();
    this.select(0);
    this.show();
    this.activate();
    this.open();
};

Window_ActorBookIndex.prototype.setupWhenCheck = function() {
    this.refresh();
    this.select(0);
    this.openness = 255;
    this.hide();
    this.activate();
};

Window_ActorBookIndex.prototype.actor = function() {
    var actor = this._list && this._list[this.index()];
    return actor && typeof actor.actorId === 'function' && actor.actor() && actor.actor().name ? actor : null;
};

Window_ActorBookIndex.prototype.maxCols = function() {
    return 1;
};

Window_ActorBookIndex.prototype.maxItems = function() {
    return this._list ? this._list.length : 0;
};

Window_ActorBookIndex.prototype.setPercentWindow = function(percentWindow) {
    this._percentWindow = percentWindow;
    this.updatePercent();
};

Window_ActorBookIndex.prototype.setStatusWindow = function(statusWindow) {
    this._statusWindow = statusWindow;
};


Window_ActorBookIndex.prototype.updatePercent = function() {
    if (this._percentWindow && this._list) {
        var a = $gameSystem.getRegisterNumber();
        this._percentWindow.setAchievement(this._list.length, a);
    }
}

Window_ActorBookIndex.prototype.refresh = function() {
    /// $dataStarAddLittleOpt
    this._list = [];
    // for (var i = 0; i < $gameParty.ActorBookLite.length; i++) {
        // this._list.push($gameActors.actor($gameParty.ActorBookLite[i]));// 目录添加
    // }
	for (var i = 0; i < $dataActors.length; i++) {
        if($gameParty.ActorBookLite.indexOf(i) !== -1){
			this._list.push($gameActors.actor(i));// 目录添加
		}else{
			this._list.push({_name: "？？？"});// 目录添加
		}
    }
    this.createContents();
    this.drawAllItems();
};

  // SceneManager.push(Scene_ActorBook)
Window_ActorBookIndex.prototype.drawItem = function(index) {
    var Name = this._list[index]._name;
    var rect = this.itemRectForText(index);
    this.drawText(Name, rect.x, rect.y, rect.width);
};

//=============================================================================
// Window_ActorBookStatus
//=============================================================================

Window_ActorBookStatus = function() {
    this.initialize.apply(this, arguments);
};

Window_ActorBookStatus.prototype = Object.create(Window_Base.prototype);
Window_ActorBookStatus.prototype.constructor = Window_ActorBookStatus;

Window_ActorBookStatus.prototype.initialize = function(x, y, width, height) {
    Window_Base.prototype.initialize.call(this, x, y, width, height);
    this._defaultX = x;
    this._windowWidth = width;
    this._Sprite = new Sprite();
    this._Sprite.anchor.x = 0.5;
    this._Sprite.anchor.y = 0.5;
    this._Sprite.x = width / 4;
    this._Sprite.y = width / 4 + this.lineHeight();
    this._spriteFrameCount = this._spriteFrameCount || 0;
    this.addChildToBack(this._Sprite);
};

Window_ActorBookStatus.prototype.setup = function() {
    this.x = this._defaultX;
    this.setupbacksprite();
    this.show();
    this.open();
};

Window_ActorBookStatus.prototype.setupWhenCheck = function(Actor) {
    this.x = Math.floor((Graphics.boxWidth - this.width) / 2);
    this.width = this._windowWidth;
    this.setupbacksprite(Actor);
    this.show();
    this.open();
};
Window_ActorBookStatus.prototype.setupbacksprite = function(Actor) {
    this.x = this._defaultX;
    this.width = this._windowWidth;
    // this.height = Scene_ActorBook.prototype.calcStatusWindowHeight();
    this.createContents();
    this.refresh(Actor);
};


Window_ActorBookStatus.prototype.update = function() {
    Window_Base.prototype.update.call(this);
    if (this._Sprite.bitmap) {
        var bitmap = this._Sprite.bitmap;
        if (this._spriteFrameCount % 12 === 0) {
            var ary = [0, 1, 2, 1];
            var motionIndex = 0;
            var pattern = ary[Math.floor(this._spriteFrameCount / 12) % 4];
            var cw = bitmap.width / 9;
            var ch = bitmap.height / 6;
            var cx = Math.floor(motionIndex / 6) * 3 + pattern;
            var cy = motionIndex % 6;
            this._Sprite.setFrame(cx * cw, cy * ch, cw, ch);
        }
        var bitmapWidth = bitmap.width / 9;
        var contentsWidth = this.contents.width;
        var scale = 1;
        if (bitmapWidth > contentsWidth / 2) {
            scale = contentsWidth / bitmapWidth / 2;
        }
        this._Sprite.scale.x = scale;
        this._Sprite.scale.y = scale;
        this._spriteFrameCount++;
    }
};

Window_ActorBookStatus.prototype.refresh = function(Actor) {
    var x = 0,
        y = 0,
        width = this.contentsWidth();
    height = this.height;
    //	x = Graphics.boxWidth/2 - this._windowWidth / 2;
    //	width = this._windowWidth;
    this._Sprite.x = x + width / 10;
    this._Sprite.y = width / 13;
    this.drawAllContents(x, y, width, height, Actor);
};
/*
	Window_ActorBookStatus.prototype.refresh = function(Actor) {
		var x = 0, y = 0, width = this.contentsWidth(); height = this.height;
			x = Graphics.boxWidth/2 - this._windowWidth / 2;
			width = this._windowWidth;
		this._Sprite.x = x+ width / 4;
		this._Sprite.y = width / 4 + this.lineHeight();
		this.drawAllContents(x,y,width,height,Actor);
	};
	*/

Window_ActorBookStatus.prototype.drawAllContents = function(x, y, width, height, Actor) {
	if(!Actor){
		this._Sprite.bitmap = null;
		this.contents.clear();
		return;
	}
    Actor.pushattribute = Actor.pushattribute || [];
    for (var i = 0; i < 8; i++) {
        Actor.pushattribute[i] = Actor.pushattribute[i] || [0, 0];
    };
    var attribute = ["生命", "魔法", "物理攻击", "物理防御", "魔法攻击", "魔法防御", "敏捷", "幸运"];
    Actor._AdvancedNum = Actor._AdvancedNum || 0;
	var GetUpData = $dataStarAdvancedOpt.filter(function (obj) {
		// 人物ID相同 && 次数相同
		return obj && Actor._actorId == obj.AdvancedActId && Actor._AdvancedNum == obj.AdvancedActNum;
	})[0];
    // 窗口绘制
    var column1x = x;
    var column2x = width ? x + width / 2 + this.standardPadding() / 2 : this.contentsWidth() / 2 + this.standardPadding() / 2;
    var columnWidth = width ? width / 2 - this.standardPadding() : this.contentsWidth() / 2 - this.standardPadding();
    var x = x || 0;
    var y = y || 0;
    var w = columnWidth / 2 - this.standardPadding();
    //var mY = 0;
    var lineHeight = this.lineHeight();
    this.contents.clear();
    var bitmap;
    bitmap = ImageManager.loadSvActor(Actor.battlerName());
    var motionIndex = 0;
    var pattern = 1;
    var cw = bitmap.width / 9;
    var ch = bitmap.height / 6;
    var cx = Math.floor(motionIndex / 6) * 3 + pattern;
    var cy = motionIndex % 6;
    this._Sprite.bitmap = bitmap;
    this._Sprite.scale.x = 1;
    this._Sprite.scale.y = 1;
    this._Sprite.setFrame(cx * cw, cy * ch, cw, ch);
    this.resetTextColor();
    this.drawText(Actor._name, column2x / 3, y, columnWidth);
    this.changeTextColor(this.systemColor());
    this.drawText(attribute[0], column2x / 3 * 2 + this.textWidth("       "), y, columnWidth);
    this.drawText(attribute[1], column2x / 10 * 11 + this.textWidth("       "), y, columnWidth);
    this.drawText(attribute[2], column2x / 3 * 2 + this.textWidth("       "), y + lineHeight, columnWidth);
    this.drawText(attribute[3], column2x / 10 * 11 + this.textWidth("       "), y + lineHeight, columnWidth);
    this.drawText(attribute[6], column2x / 10 * 15 + this.textWidth("       "), y + lineHeight, columnWidth);
    this.drawText(attribute[4], column2x / 3 * 2 + this.textWidth("       "), y + lineHeight * 2, columnWidth);
    this.drawText(attribute[5], column2x / 10 * 11 + this.textWidth("       "), y + lineHeight * 2, columnWidth);
    this.drawText(attribute[7], column2x / 10 * 15 + this.textWidth("       "), y + lineHeight * 2, columnWidth);
    this.resetTextColor();
    this.drawText($dataClasses[Actor._classId].params[0][1], column2x / 3 * 2 + this.textWidth(attribute[0] + "        "), y, columnWidth);
    this.drawText($dataClasses[Actor._classId].params[1][1], column2x / 10 * 11 + this.textWidth(attribute[1] + "        "), y, columnWidth);
    this.drawText("初始值", column2x / 10 * 15 + this.textWidth("       "), y, columnWidth);
    this.drawText($dataClasses[Actor._classId].params[2][1], column2x / 3 * 2 + this.textWidth(attribute[2] + "        "), y + lineHeight, columnWidth);
    this.drawText($dataClasses[Actor._classId].params[3][1], column2x / 10 * 11 + this.textWidth(attribute[3] + "        "), y + lineHeight, columnWidth);
    this.drawText($dataClasses[Actor._classId].params[6][1], column2x / 10 * 15 + this.textWidth(attribute[6] + "        "), y + lineHeight, columnWidth);
    this.drawText($dataClasses[Actor._classId].params[4][1], column2x / 3 * 2 + this.textWidth(attribute[4] + "        "), y + lineHeight * 2, columnWidth);
    this.drawText($dataClasses[Actor._classId].params[5][1], column2x / 10 * 11 + this.textWidth(attribute[5] + "        "), y + lineHeight * 2, columnWidth);
    this.drawText($dataClasses[Actor._classId].params[7][1], column2x / 10 * 15 + this.textWidth(attribute[7] + "        "), y + lineHeight * 2, columnWidth);
    y += lineHeight;
    this.changeTextColor(this.systemColor());
    this.drawText("品质 ", column2x / 3, y, columnWidth);
    this.resetTextColor();
    var quality=Number($dataActors[Actor._actorId].meta.Actorquality)||0;
    // Actor quality is independent of the combat classification roster.
    if(quality===12)quality=10;
    var qualityNames={1:'普通',2:'优秀',3:'精良',4:'史诗',5:'神圣',6:'不朽',7:'传说',8:'品质8',9:'品质9',10:'神话'};
    var qualityColors={2:'#80FF1C',3:'#39B9FF',4:'#8064FE',5:'#FF28FF',6:'#FFAF00',10:'#f30b0b'};
    if(window.CodexQuality)this.changeTextColor(CodexQuality.actorColor(quality));else if(qualityColors[quality])this.changeTextColor(qualityColors[quality]);
    var qualityLabel=window.CodexQuality&&quality?CodexQuality.actorName(quality):qualityNames[quality]||(quality?'品质'+quality:'无');
    this.drawText(qualityLabel,column2x/3+this.textWidth('品质:'),y,columnWidth);
    this._codexActorBookQuality={actorId:Actor._actorId,value:quality,label:qualityLabel};
    y += lineHeight;this.resetTextColor();var bodyFont=this.contents.fontSize;this.contents.fontSize=18;CodexElements.drawAttributes(this.contents,Actor,column2x/3,y,columnWidth,lineHeight,'人物属性');this.contents.fontSize=bodyFont;this._codexActorBookElements=CodexElements.affinity(Actor);
    this.resetTextColor();
    y += lineHeight;
    this.changeTextColor(this.systemColor());
    this.drawText("最大进阶次数 ", column2x / 3, y, columnWidth);
    this.resetTextColor();
    if(GetUpData){
	  this.drawText(GetUpData.AdvancedActNumMaX, column2x / 3 + this.textWidth("最大进阶次数:"), y, columnWidth);
	}else{
	  this.drawText((Actor._AdvancedNum || 0), column2x / 3 + this.textWidth("最大进阶次数:"), y, columnWidth);
	}
    y += lineHeight;
    var codexRavenBook = Actor._actorId === 167 || Actor._actorId === 173;
    var skillLineHeight = codexRavenBook ? Math.min(32, lineHeight) : lineHeight;
    ActNotey = y + lineHeight * 10;
    var initialy = y + lineHeight;
    var ravenColumnWidth = Math.floor((width || this.contentsWidth()) / 3) - 12;
    var drawBookSkill = function(skill, sx, sy) {
        if (!codexRavenBook) {
            this.drawItemName(skill, sx, sy, Graphics.boxWidth);
            return;
        }
        var context = this.contents.context;
        var oldFontSize = this.contents.fontSize;
        context.save();
        context.beginPath();
        context.rect(sx, sy, ravenColumnWidth, skillLineHeight);
        context.clip();
        this.contents.fontSize = 20;
        this.drawItemName(skill, sx, sy, ravenColumnWidth);
        this.contents.fontSize = oldFontSize;
        context.restore();
    }.bind(this);
    // 【Codex·未经Claude检验】v0.29 光环独立栏；长列表由确认后的详情完整展示。
    var bookSkills=window.CodexActorBookSkills?window.CodexActorBookSkills(Actor,true):[];
    var auraBook29=bookSkills.some(function(s){return /<CodexAura>/.test(s.note||'');});
    //人物技能等
    this.changeTextColor(this.systemColor());
    if(auraBook29){
        var cw29=Math.floor((width||this.contentsWidth())/4);
        ['主动','被动','光环','其他'].forEach(function(label,index){this.drawText(label,x+index*cw29,y,cw29-8);},this);
        this.resetTextColor();
        var maxRows29=Math.max(1,Math.floor((this.contentsHeight()-initialy-lineHeight*6)/Math.min(30,lineHeight)));
        var groups29=[[],[],[],[]];
        bookSkills.forEach(function(skill){var index=/<CodexAura>/.test(skill.note||'')?2:skill.stypeId===4?1:skill.stypeId===5?3:0;groups29[index].push(skill);});
        this._codexActorBookGroups29=groups29.map(function(list){return list.map(function(s){return s.id;});});
        var oldSize29=this.contents.fontSize;this.contents.fontSize=22;
        groups29.forEach(function(list,index){list.slice(0,maxRows29).forEach(function(skill,row){this.drawItemName(skill,x+index*cw29,initialy+row*30,cw29-8);},this);if(list.length>maxRows29)this.drawText('确认查看全部',x+index*cw29,initialy+maxRows29*30,cw29-8);},this);
        this.contents.fontSize=oldSize29;
        ActNotey=initialy+(Math.min(maxRows29,Math.max.apply(null,groups29.map(function(list){return list.length;})))+1)*30;
    }else{
    this.drawText("主动", x, y, Graphics.boxWidth);
    this.drawText("被动", column2x * 2 / 3, y, Graphics.boxWidth);
    this.drawText("其他", column2x * 4 / 3, y, Graphics.boxWidth);
    this.resetTextColor();
   	y += lineHeight;
    // The summary and detail page use the same intrinsic sources, excluding external skills.

    this._codexActorBookSkills=bookSkills.map(function(skill){return skill.id;});
    var offsets=[x,column2x*2/3,column2x*4/3-this.textWidth(' ')];
    [1,4,5].forEach(function(type,index){
        var rowY=initialy;
        bookSkills.forEach(function(skill){
            var matches=type===1?skill.stypeId>=1&&skill.stypeId<=3:skill.stypeId===type;
            if(matches){drawBookSkill(skill,offsets[index],rowY);rowY+=skillLineHeight;}
        });
    });

    }

    // Raven uses the unused native "其他" column for mastery.  Its eleven
    // passive rows can then occupy the full height without colliding below.
    y = codexRavenBook && !auraBook29 ? initialy : ActNotey;
    var masteryX = codexRavenBook && !auraBook29 ? column2x * 4 / 3 - this.textWidth(" ") : x;
    var masteryWidth = codexRavenBook ? this.contentsWidth() - masteryX - 4 : Graphics.boxWidth;
    this.changeTextColor(this.systemColor());
    this.drawText("武器掌握", masteryX, y, masteryWidth);
    this.resetTextColor();
    y += lineHeight;
    var Weapons = [];
    for(var a = 0;a < $dataClasses[Actor._classId].traits.length;a++){
        if($dataClasses[Actor._classId].traits[a].code == 51){
            Weapons.push([$dataSystem.weaponTypes[$dataClasses[Actor._classId].traits[a].dataId], $dataClasses[Actor._classId].traits[a].dataId]);
        }
    };
    Weapons.sort((a,b) => a[1] - b[1]);
    if (codexRavenBook || Actor.actorId()===173) {
        var oldMasteryFont = this.contents.fontSize;
        this.contents.fontSize = 18;
        for (var weaponRow = 0; weaponRow < Weapons.length; weaponRow += 4) {
            this.drawText(Weapons.slice(weaponRow, weaponRow + 4).map(function(entry) {
                return entry[0];
            }).join('、'), masteryX, y, masteryWidth);
            if (weaponRow + 4 < Weapons.length) y += skillLineHeight;
        }
        this.contents.fontSize = oldMasteryFont;
    } else {
        for(var c = 0;c < Weapons.length;c++){
            this.drawText(Weapons[c][0], x + this.textWidth("         ") * c, y, Graphics.boxWidth);
        }
    }
    y += lineHeight;
    this.changeTextColor(this.systemColor());
    this.drawText("防具掌握", masteryX, y, masteryWidth);
    this.resetTextColor();
    y += lineHeight;
    var Armors = [];
    for(var a = 0;a < $dataClasses[Actor._classId].traits.length;a++){
        if($dataClasses[Actor._classId].traits[a].code == 52){
            Armors.push([$dataSystem.armorTypes[$dataClasses[Actor._classId].traits[a].dataId], $dataClasses[Actor._classId].traits[a].dataId]);
        }
    };
    Armors.sort((a,b) => a[1] - b[1]);
    if (codexRavenBook || Actor.actorId()===173) {
        var oldArmorFont = this.contents.fontSize;
        this.contents.fontSize = 18;
        for (var armorRow = 0; armorRow < Armors.length; armorRow += 4) {
            this.drawText(Armors.slice(armorRow, armorRow + 4).map(function(entry) {
                return entry[0];
            }).join('、'), masteryX, y, masteryWidth);
            if (armorRow + 4 < Armors.length) y += skillLineHeight;
        }
        this.contents.fontSize = oldArmorFont;
    } else {
        for(var c = 0;c < Armors.length;c++){
            this.drawText(Armors[c][0], x + this.textWidth("         ") * c, y, Graphics.boxWidth);
        }
    }
    y += lineHeight;
    // 人物备注
    var ShowEnemyNote = false;
  	for(var i = 0;i < Actor.notetags().length;i++){
  	    if(Actor.notetags()[i] == "<ActorNote>" || ShowEnemyNote){
  	        ShowEnemyNote = true;
  	        if(Actor.notetags()[i] == "</ActorNote>"){
  	            ShowEnemyNote = false;
  	        }else if(Actor.notetags()[i] != "<ActorNote>"){
  	            for(var a = 0;a <= Math.ceil(Actor.notetags()[i].length/32);a++){
  	                this.drawText(Actor.notetags()[i].slice(a*32, (a+1)*32), x, y, Graphics.boxWidth);
  	                y += lineHeight;
  	            }
		    }
		}
	}
};
