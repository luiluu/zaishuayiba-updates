/*:
 * @plugindesc v1.05 新增角色SV：统一缩放、站位与原生变身联动
 * @author Codex
 * @param MiraHumanScale
 * @text 米拉人形大小
 * @type number
 * @decimals 2
 * @min 0.30
 * @max 1.20
 * @default 0.60
 * @param MiraDragonScale
 * @text 黑龙形态大小
 * @type number
 * @decimals 2
 * @min 0.30
 * @max 1.20
 * @default 0.60
 * @param RavenMythicScale
 * @text 渡鸦神话大小
 * @type number
 * @decimals 2
 * @min 0.30
 * @max 1.20
 * @default 0.60
 * @param NewStandardScale
 * @text 其他新增普通SV大小
 * @type number
 * @decimals 2
 * @min 0.30
 * @max 1.20
 * @default 0.60
 * @param SukunaFullScale
 * @text 宿傩完全体大小
 * @type number
 * @decimals 2
 * @min 0.30
 * @max 1.20
 * @default 0.60
 * @param CrispScaling
 * @text 像素锐利缩放
 * @type boolean
 * @default true
 * @help
 * 放在 Mx_SuperSV v1.07 后面。无需数据库备注或修改存档。
 * 米拉168：普通人形；原生黑龙条件成立时换黑龙。
 * 渡鸦167：战斗内神话剩余回合>0时换图，结束后恢复原图。
 * 素材位于 img/sv_actors/sv/UserSV_MiraHuman、UserSV_MiraDragon、
 * UserSV_RavenMythic。每组20张透明PNG，对应18种MV动作。
 * 本插件仅处理图像与播放，不修改技能、伤害、进阶或变身持续时间。
 * 新增SV按站姿可见高度72逻辑像素归一，不按透明画布缩放。其他新增普通SV
 * 包括黄泉、镜流、伏黑甚尔、宿傩、渡鸦普通形态，以及饿狼多帧形态。
 * 宿傩完全体多帧SV默认0.60。每类可独立调整，1.00为原图大小。
 * 脚底、悬浮、状态图标和选择范围随大小同步，读取旧存档即可生效。
 * 默认使用最近邻缩放，避免双线性插值造成模糊。5人队自动按角色
 * 显示尺寸排列为四角加中心，3/4人竖向一列，保留动作移动。
 */
var Imported = Imported || {};
Imported.Codex_MiraRavenMultiFrame = true;
(function() {
    'use strict';
    var configs = {}, merged = new WeakMap();
    var parameters=PluginManager.parameters('Codex_MiraRavenMultiFrame');
    var crispScaling=String(parameters.CrispScaling||'true')==='true';
    var formationCache=null;
    var normProfiles={"Raven_Normal_SV":{"kind":"sheet","width":64,"height":64,"bounds":[9,4,60,64],"targetHeight":72,"maxWidth":129,"source":"idle motion0/frame1"},"BlackDragon_Mira_SV":{"kind":"sheet","width":64,"height":64,"bounds":[10,2,55,64],"targetHeight":72,"maxWidth":129,"source":"idle motion0/frame1"},"Codex_Yomi_SV":{"kind":"sheet","width":64,"height":64,"bounds":[0,4,63,64],"targetHeight":72,"maxWidth":129,"source":"idle motion0/frame1"},"Codex_Jingliu_SV":{"kind":"sheet","width":64,"height":64,"bounds":[11,2,54,64],"targetHeight":72,"maxWidth":129,"source":"idle motion0/frame1"},"Codex_Toji_SV":{"kind":"sheet","width":64,"height":64,"bounds":[9,3,51,64],"targetHeight":72,"maxWidth":129,"source":"idle motion0/frame1"},"Codex_Sukuna_SV":{"kind":"sheet","width":64,"height":64,"bounds":[14,5,48,63],"targetHeight":72,"maxWidth":129,"source":"idle motion0/frame1"},"Garou_Human":{"kind":"sheet","width":64,"height":64,"bounds":[12,10,51,59],"targetHeight":72,"maxWidth":129,"source":"idle motion0/frame1"},"Raven_Mythic_SV":{"kind":"sheet","width":64,"height":64,"bounds":[11,4,58,63],"targetHeight":72,"maxWidth":129,"source":"idle motion0/frame1"},"Garou_Cosmic":{"kind":"sheet","width":64,"height":64,"bounds":[16,4,48,60],"targetHeight":72,"maxWidth":129,"source":"idle motion0/frame1"},"UserSV_MiraHuman":{"kind":"multi","width":260,"height":240,"bounds":[43,48,196,178],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/sv/UserSV_MiraHuman/UserSV_MiraHuman1_0.png"},"UserSV_MiraDragon":{"kind":"multi","width":340,"height":280,"bounds":[61,58,260,217],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/sv/UserSV_MiraDragon/UserSV_MiraDragon1_0.png"},"UserSV_RavenMythic":{"kind":"multi","width":380,"height":280,"bounds":[84,55,268,211],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/sv/UserSV_RavenMythic/UserSV_RavenMythic0_0.png"},"Codex_Sukuna_Full":{"kind":"multi","width":270,"height":260,"bounds":[79,42,190,222],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/sv/Codex_Sukuna_Full/Codex_Sukuna_Full1_0.png"},"garou_human_v2":{"kind":"multi","width":192,"height":176,"bounds":[50,37,146,172],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/sv/garou_human_v2/garou_human_v21_0.png"},"garou_cosmic":{"kind":"multi","width":128,"height":128,"bounds":[28,8,99,120],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/sv/garou_cosmic/garou_cosmic1_0.png"}};
    Object.assign(normProfiles,{"yunshang":{"kind":"multi","width":192,"height":192,"bounds":[40,52,152,184],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/sv/yunshang/yunshang1_0.png"},"Yunshang":{"kind":"sheet","width":192,"height":192,"bounds":[41,52,150,184],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/Yunshang.png"}});
    normProfiles.Codex_Sukuna_QFull={"kind":"multi","width":64,"height":64,"bounds":[8,6,47,62],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/sv/Codex_Sukuna_QFull/Codex_Sukuna_QFull1_0.png","bodyReference":"stationary wait, chibi four-arm master v18"};
    Object.assign(normProfiles,{"Codex_Garou_QHuman":{"kind":"multi","width":112,"height":112,"bounds":[33,24,76,96],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/sv/Codex_Garou_QHuman/Codex_Garou_QHuman1_0.png","bodyReference":"chibi standing feet baseline 96, fixed scale across all motions"},"Codex_Garou_QCosmic":{"kind":"multi","width":112,"height":112,"bounds":[35,24,81,96],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/sv/Codex_Garou_QCosmic/Codex_Garou_QCosmic1_0.png","bodyReference":"chibi standing feet baseline 96, fixed scale across all motions"}});
    // 2026-10-08 face-angle revision; fixed body scale and foot anchors.
    Object.assign(normProfiles,{"Codex_Garou_QHuman":{"kind":"multi","width":64,"height":64,"bounds":[7,0,51,64],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/sv/Codex_Garou_QHuman/Codex_Garou_QHuman1_0.png","bodyReference":"v0.19 user sheet 9x6 64px, feet at 64"},"Garou_Human":{"kind":"sheet","width":64,"height":64,"bounds":[7,0,51,64],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/Garou_Human.png","bodyReference":"v0.19 user sheet 9x6 64px"},"Codex_Garou_QCosmic":{"kind":"multi","width":112,"height":112,"bounds":[32,24,80,96],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/sv/Codex_Garou_QCosmic/Codex_Garou_QCosmic1_0.png","bodyReference":"near frontal face slight left, shared-scale all motions, fixed feet 96"},"Garou_Cosmic":{"kind":"sheet","width":64,"height":64,"bounds":[18,14,46,55],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/Garou_Cosmic.png","bodyReference":"same new multi-frame artwork fallback 9x6"},"yunshang":{"kind":"multi","width":192,"height":192,"bounds":[34,52,158,184],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/sv/yunshang/yunshang1_0.png","bodyReference":"near frontal face slight left, shared-scale all motions, fixed feet 184"},"Yunshang":{"kind":"sheet","width":192,"height":192,"bounds":[34,52,158,184],"targetHeight":72,"maxWidth":129,"source":"img/sv_actors/Yunshang.png","bodyReference":"same new multi-frame artwork fallback 9x6"}});
    var inferredProfiles={};
    var display={
        MiraHuman:{width:180,height:144},
        MiraDragon:{width:245,height:195},
        RavenMythic:{width:285,height:174},
        NewStandard:{padding:0},
        NewMultiFrame:{padding:0},
        SukunaFull:{padding:40}
    };
    function scaleParameter(value, fallback) {
        var n=Number(value);
        return isFinite(n) && n>=0.30 && n<=1.20 ? n : fallback;
    }
    Object.keys(display).forEach(function(name) {
        display[name].scale=scaleParameter(parameters[name+'Scale'],0.60);
    });
    display.NewMultiFrame.scale=display.NewStandard.scale;
    var spriteMotionBeforeLegacy = Sprite_Actor.prototype.startMotion;
    ['MiraHuman','MiraDragon','RavenMythic'].forEach(function(name) {
        configs[name] = {sv:'UserSV_' + name, SVspeed:'10', SVzs0:'4',
            SVzs7:'4', SVzs10:'4', Cfdz0:'[1,2,12]', Cfdz7:'[6,8]',
            Cfdz10:'[9,11]', YCyy:name==='RavenMythic' ? 'true' : 'false'};
        [3,4,5,13,14,15,16,17].forEach(function(i) {configs[name]['SVzs'+i]='1';});
    });
    ['MiraHuman','MiraDragon'].forEach(function(name) {
        configs[name].SVzs1='1';
        configs[name].Cfdz0='[2,12]';
    });
    function quietIdle(sprite) {
        var a=sprite && sprite._actor;
        return a && (a.actorId()===173 || a.actorId()===168 || a.actorId()===174 || a.actorId()===172);
    }
    function breathe(sprite) {
        if (!quietIdle(sprite) || !sprite._mxSVActive) return;
        if(sprite._actor.actorId()===173) sprite._weaponSprite.visible=false;
        // Anchor remains at the feet: a small vertical body expansion, no lateral sway.
        if(sprite._motion===Sprite_Actor.MOTIONS.wait && !sprite.isMoving() && !sprite._actor.isDead()) {
            var scale=sprite._mainSprite.scale.x;
            sprite._mainSprite.scale.y=scale*(1+0.009*(1+Math.sin((Graphics.frameCount+sprite._actor.actorId()*11)/23))/2);
            var p=sprite._codexSVProfile;if(p)sprite._mainSprite.y=(p.height-p.bounds[3])*sprite._mainSprite.scale.y+(sprite._codexSVFloat||0);
        }
    }
    function form(actor) {
        if (!actor || !actor.isActor || !actor.isActor()) return '';
        if (window.CodexCostumes && CodexCostumes.active(actor)) return '';
        var battle = $gameParty && $gameParty.inBattle();
        if (actor.actorId() === 168) {
            return battle && Number(actor._AdvancedNum || 0)>=3 &&
                actor.isLearnedSkill(10161) && actor.isStateAffected(2592) ? 'MiraDragon' : 'MiraHuman';
        }
        return actor.actorId() === 167 && battle && actor._codexRavenMythTurns>0 ? 'RavenMythic' : '';
    }
    var previousProvider = Mx.SuperSVMetaProvider;
    Mx.SuperSVMetaProvider = function(actor, base) {
        if (previousProvider) base = previousProvider(actor,base) || base;
        var name = form(actor);
        if (!name) return base;
        var record = merged.get(base);
        if (!record) {record={}; merged.set(base,record);}
        if (!record[name]) {
            record[name] = Object.assign({},base);
            // The pack supplies all motion aliases; retain unrelated database tags.
            for (var i=0;i<18;i++) delete record[name]['Cfdz'+i];
            Object.assign(record[name],configs[name]);
        }
        return record[name];
    };
    function assetKey(sprite) {
        var url=String(sprite && sprite._mainSprite && sprite._mainSprite.bitmap && sprite._mainSprite.bitmap.url || '');
        var multi=url.match(/\/sv\/([^/]+)\//);
        if(multi)return decodeURIComponent(multi[1]);
        var sheet=url.match(/\/([^/]+)\.png(?:$|\?)/);return sheet?decodeURIComponent(sheet[1]):'';
    }
    function inferProfile(sprite,key) {
        if(inferredProfiles[key])return inferredProfiles[key];
        var bm=sprite._mainSprite.bitmap;if(!bm||!bm.isReady())return null;
        var multi=sprite._mxSVActive,w=multi?bm.width:bm.width/9,h=multi?bm.height:bm.height/6;
        if(multi && sprite._motion && sprite._motion.index>1)return null;
        try {
            var px=bm._context.getImageData(multi?0:w,0,w,h).data;
            var l=w,t=h,r=0,b=0;
            for(var y=0;y<h;y++)for(var x=0;x<w;x++)if(px[(y*w+x)*4+3]>=12){l=Math.min(l,x);t=Math.min(t,y);r=Math.max(r,x+1);b=Math.max(b,y+1);}
            if(r<=l||b<=t)return null;
            return inferredProfiles[key]={kind:multi?'multi':'sheet',width:w,height:h,bounds:[l,t,r,b],targetHeight:72,maxWidth:129};
        }catch(e){return null;}
    }
    function profile(sprite) {
        if(!sprite||!sprite._actor||sprite._actor.actorId()<167)return null;
        var key=assetKey(sprite);return normProfiles[key]||inferProfile(sprite,key);
    }
    function scaleFor(p) {return Math.min(p.targetHeight/(p.bounds[3]-p.bounds[1]),p.maxWidth/(p.bounds[2]-p.bounds[0]));}
    function applyVisual(sprite) {
        var p=profile(sprite);if(!p)return;
        var scale=scaleFor(p),b=p.bounds;
        var raven=form(sprite._actor)==='RavenMythic';
        var float=raven&&!sprite._actor.isDead()?-14+Math.sin((Graphics.frameCount+sprite._actor.actorId())/22)*1.5:0;
        sprite._mainSprite.bitmap.smooth=false;
        sprite._mainSprite.scale.set(scale,scale);
        sprite._mainSprite.anchor.set(0.5,1);
        sprite._mainSprite.position.set((p.width/2-(b[0]+b[2])/2)*scale,(p.height-b[3])*scale+float);
        sprite._codexSVProfile=p;sprite._codexSVFloat=float;
        if(sprite._mxSVActive)sprite._weaponSprite.visible=false;
        if(raven)sprite._shadowSprite.visible=false;
    }
    window.CodexSV={targetHeight:72,maxWidth:129,profiles:normProfiles,
        profile:profile,assetKey:assetKey,scaleFor:scaleFor,
        geometry:function(sprite){var p=profile(sprite);if(!p)return null;var s=scaleFor(p),b=p.bounds;return {key:assetKey(sprite),height:(b[3]-b[1])*s,width:(b[2]-b[0])*s,scale:s};}};
    function usingPack(sprite) {
        var name= sprite && form(sprite._actor), b=sprite && sprite._mainSprite && sprite._mainSprite.bitmap;
        return name && sprite._mxSVActive && b && String(b.url).indexOf('/UserSV_'+name+'/')>=0 ? name : '';
    }
    function visualForm(sprite) {
        var own=usingPack(sprite);
        if(own)return own;
        if(!sprite || !sprite._actor || !sprite._mainSprite || !sprite._mainSprite.bitmap)return '';
        var url=String(sprite._mainSprite.bitmap.url);
        if(sprite._mxSVActive && url.indexOf('/Codex_Sukuna_Full/')>=0)return 'SukunaFull';
        if(sprite._mxSVActive && /\/garou_(human(?:_v2)?|cosmic)\//.test(url))return 'NewMultiFrame';
        return !sprite._mxSVActive && /\/(Codex_(Yomi|Jingliu|Toji|Sukuna)_SV|Raven_Normal_SV)\.png$/.test(url) ? 'NewStandard' : '';
    }
    function effectiveScale(sprite,name) {
        var passive=sprite._actor && sprite._actor._passiveCache;
        var base=(name==='NewStandard'||name==='NewMultiFrame'||name==='SukunaFull') && passive && Number(passive.SvPngFd) || 1;
        return display[name].scale*base;
    }
    // 【Claude·未经Codex检验】v0.07：阵型在同一画面帧内只计算一次；下一帧照常重新核对成员与尺寸。
    var layoutFrame=-1,layoutFrameParty=null,layoutFrameValue=null;
    function partyLayout() {
        if(layoutFrame===Graphics.frameCount&&layoutFrameParty===$gameParty)return layoutFrameValue;
        layoutFrameValue=computePartyLayout();layoutFrame=Graphics.frameCount;layoutFrameParty=$gameParty;
        return layoutFrameValue;
    }
    function computePartyLayout() {
        if(!$gameParty || !$gameParty.inBattle())return null;
        // Bound support forms (Xuan/Tusu) live on their host and take no formation slot.
        var members=$gameParty.battleMembers().filter(function(a){return !(window.CodexBinding&&CodexBinding.isBound&&CodexBinding.isBound(a));}),n=members.length;
        if(n<1||n>5)return null;
        var width=72,height=72,key=Graphics.boxWidth+':'+Graphics.boxHeight+':'+n;
        for(var i=0;i<n;i++){width=Math.max(width,members[i].spriteWidth());height=Math.max(height,members[i].spriteHeight());key+=':'+members[i].actorId()+','+Math.round(members[i].spriteWidth())+','+Math.round(members[i].spriteHeight());}
        if(formationCache && formationCache.key===key)return formationCache;
        var points=[],W=Graphics.boxWidth,H=Graphics.boxHeight,cx=Math.round(W*0.64);
        if(n===5){
            // 2026-10-08 HOLD-011: keep the native party order top-to-bottom so
            // the field matches the side status list; alternate front/back
            // columns (enemies are on the left) to keep five figures apart.
            var dx=Math.round(Math.max(100,Math.min(W*0.105,width+24))/2);
            var top5=Math.max(height+36,H*0.30),bottom5=H*0.75,step5=(bottom5-top5)/4;
            for(var k=0;k<5;k++)points.push([cx+(k%2?dx:-dx),Math.round(top5+k*step5)]);
        }else{
            var top=Math.max(height+36,H*0.32),bottom=H*0.73;
            var step=n>1?(bottom-top)/(n-1):0;
            for(var j=0;j<n;j++)points.push([cx,n===1?Math.round(H*0.525):Math.round(top+j*step)]);
        }
        formationCache={key:key,members:members,points:points};return formationCache;
    }
    CodexSV.layout=partyLayout;
    var installed = false;
    function installVisualHooks() {
        if (installed) return;
        installed=true;
        // main.js installs the legacy transformation hooks after plugins load.
        // Wrap them at boot, preserving gameplay and applying geometry last.
        var previousUpdate = Sprite_Actor.prototype.update;
        Sprite_Actor.prototype.update = function() {
            if(this._codexLegacyScale){this._mainSprite.scale.x/=0.75;this._mainSprite.scale.y/=0.75;this._codexLegacyScale=false;}
            previousUpdate.apply(this,arguments);this.updatePosition();applyVisual(this);
            if(!profile(this)&&this._actor&&$gameParty.inBattle()){this._mainSprite.scale.x*=0.75;this._mainSprite.scale.y*=0.75;this._mainSprite.bitmap.smooth=false;this._codexLegacyScale=true;}
            breathe(this);
        };
        var previousPosition = Sprite_Actor.prototype.updatePosition;
        var previousHome = Sprite_Actor.prototype.setActorHome;
        Sprite_Actor.prototype.updatePosition = function() {
            // MV setHome calls updatePosition synchronously. Keep that nested
            // update on the original path, then apply this wrapper once outside.
            if(this._smallSVSettingHome)return previousPosition.apply(this,arguments);
            var layout=partyLayout(),index=layout&&layout.members.indexOf(this._actor);
            if(layout && index>=0){
                this._smallSVFormation=true;
                var homeX=layout.points[index][0],homeY=layout.points[index][1];
                if(this._homeX!==homeX || this._homeY!==homeY){
                    this._smallSVSettingHome=true;
                    try{this.setHome(homeX,homeY);}finally{this._smallSVSettingHome=false;}
                }
            } else if(this._smallSVFormation && this._actor){
                this._smallSVFormation=false;
                this._smallSVSettingHome=true;
                try{previousHome.call(this,this._actor.index());}finally{this._smallSVSettingHome=false;}
            }
            previousPosition.apply(this,arguments);
            if(this._smallSVFormation){this.x=this._homeX+this._offsetX;this.y=this._homeY+this._offsetY;}
            var name=visualForm(this);
            if (!this._smallSVFormation && name && name!=='NewStandard' && name!=='NewMultiFrame') this.x += name==='RavenMythic' ?
                Math.min(65*display[name].scale,Graphics.boxWidth*0.74-100*display[name].scale-this._homeX) : -160*effectiveScale(this,name);
            if(crispScaling && name && !this._movementDuration){this.x=Math.round(this.x);this.y=Math.round(this.y);}
            // Bound Xuan/Tusu follow their host; applied after every geometry pass.
            if(window.CodexXuanTusuArt && CodexXuanTusuArt.attachPosition)CodexXuanTusuArt.attachPosition(this);
        };
        // Selection and state icons should follow the visible figure, not the
        // transparent atlas extraction padding. Movement/attack offsets still run.
        var previousWidth=Game_Actor.prototype.spriteWidth;
        var previousHeight=Game_Actor.prototype.spriteHeight;
        Game_Actor.prototype.spriteWidth=function() {
            var sprite=this.battler(),p=profile(sprite);
            return p?(p.bounds[2]-p.bounds[0])*scaleFor(p):previousWidth.apply(this,arguments);
        };
        Game_Actor.prototype.spriteHeight=function() {
            var sprite=this.battler(),p=profile(sprite);
            return p?(p.bounds[3]-p.bounds[1])*scaleFor(p)+Math.max(0,-(sprite._codexSVFloat||0)):previousHeight.apply(this,arguments);
        };
        // The actor book uses the same visual size; multi-frame art is displayed
        // without treating each frame as an old 9x6 sheet.
        var bookDraw=Window_ActorBookStatus.prototype.drawAllContents;
        Window_ActorBookStatus.prototype.drawAllContents=function(x,y,w,h,a){
            this._codexBookActor=a && a.actorId()>=167?a:null;
            // 切换角色时清掉上一人的锚点与缩放，未知素材也沿用原生图鉴位置。
            this._Sprite.anchor.set(0.5,0.5);this._Sprite.scale.set(1,1);
            var out=bookDraw.apply(this,arguments);
            if(a && a.actorId()===168){var name='UserSV_MiraHuman';this._Sprite.bitmap=ImageManager.loadBigSvActor(name,name+'1_0',0);this._codexBookMulti=name;}
            else if(a && a.actorId()===174){this._Sprite.bitmap=ImageManager.loadBigSvActor('yunshang','yunshang1_0',0);this._codexBookMulti='yunshang';}
            else {
                var assets={175:{name:'Guyu',asset:'Codex_Guyu'},176:{name:'Codex_Tusu_SV_v1',asset:'Codex_Tusu_v1'},177:{name:'Codex_Xuan_SV_v1',asset:'Codex_Xuan_v1'}},entry=a&&assets[a.actorId()];
                if(entry&&a.battlerName()===entry.name){
                    this._Sprite.bitmap=ImageManager.loadBigSvActor(entry.asset,entry.asset+'1_0',0);
                    this._codexBookMulti=entry.asset;
                } else this._codexBookMulti=a && a.actorId()===173?(Number(a._AdvancedNum)>=6?'Codex_Garou_QCosmic':'Codex_Garou_QHuman'):null;
            }
            updateBookVisual(this);return out;
        };
        function updateBookVisual(w){
            var a=w._codexBookActor,bm=w._Sprite.bitmap;if(!a||!bm||!bm.isReady())return;
            var key=w._codexBookMulti||decodeURIComponent(String(bm.url).split('/').pop().replace(/\.png$/,''));
            var p=normProfiles[key];if(!p)return;
            var s=scaleFor(p),b=p.bounds;
            if(w._codexBookMulti)w._Sprite.setFrame(0,0,p.width,p.height);
            w._Sprite.scale.set(s,s);w._Sprite.anchor.set(0.5,1);bm.smooth=false;
            w._Sprite.x=w.contentsWidth()/10+(p.width/2-(b[0]+b[2])/2)*s;
            w._Sprite.y=w.contentsWidth()/13+(b[3]-b[1])*s/2+(p.height-b[3])*s;
        }
        var bookUpdate=Window_ActorBookStatus.prototype.update;
        Window_ActorBookStatus.prototype.update=function(){
            if(this._codexBookMulti && this._codexBookActor)Window_Base.prototype.update.call(this);
            else bookUpdate.apply(this,arguments);
            updateBookVisual(this);
        };
        var previousFrame = Sprite_Actor.prototype.updateFrame;
        Sprite_Actor.prototype.updateFrame = function() {
            if(quietIdle(this) && this._motion===Sprite_Actor.MOTIONS.walk && !this.isMoving()) this.startMotion('wait');
            previousFrame.apply(this,arguments);applyVisual(this);breathe(this);
        };
        var previousMotion = Sprite_Actor.prototype.startMotion;
        Sprite_Actor.prototype.startMotion = function(type) {
            // MV calls walk for command input and undecided actors. These custom
            // sheets contain actual steps there; use the stationary wait stance.
            if(quietIdle(this) && type==='walk' && !this.isMoving()) type='wait';
            // The original Raven sheet remapped these two poses to evade/wait.
            // The supplied mythic sheet has dedicated damage and dying frames.
            var method=form(this._actor)==='RavenMythic' && (type==='damage'||type==='dying') ?
                spriteMotionBeforeLegacy : previousMotion;
            return method.call(this,type);
        };
        Object.keys(configs).forEach(function(name) {
            var c=configs[name];
            for(var m=0;m<18;m++) for(var f=0;f<Number(c['SVzs'+m]||0);f++)
                ImageManager.loadBigSvActor(c.sv,c.sv+m+'_'+f,0);
        });
    }
    var start = Scene_Boot.prototype.start;
    Scene_Boot.prototype.start = function() {installVisualHooks();return start.apply(this,arguments);};
})();
