@echo off
call "%~dp0InstallUpdate.cmd" %*
exit /b %ERRORLEVEL%
