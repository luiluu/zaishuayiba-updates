// 【Codex·未经Claude检验】v0.10；未经claude检验。
/* 【Codex·未经Claude检验】 Touch controls and Android lifecycle. 核查状态：未经claude检验。 */
(function(){
 'use strict';
 var run=SceneManager.run;
 function controls(){
  var css=document.createElement('style');css.textContent=`
   #android-controls{position:fixed;inset:0;pointer-events:none;z-index:90000;user-select:none;-webkit-user-select:none;font:15px system-ui}
   #android-controls button{pointer-events:auto;touch-action:none;min-width:44px;min-height:44px;padding:8px;border:1px solid #adc4ed77;border-radius:12px;background:#13253db8;color:#e6f1ff;font:inherit;-webkit-tap-highlight-color:transparent}
   #android-controls button:active{background:#31557c}
   #android-controls .movement{position:absolute;left:max(12px,env(safe-area-inset-left));bottom:max(12px,env(safe-area-inset-bottom));width:184px;height:160px}
   #android-controls .joystick{position:absolute;left:0;bottom:0;width:144px;height:144px;border:1px solid #adc4ed77;border-radius:50%;background:radial-gradient(circle,#203b5570 0 29%,#13253d65 30% 64%,#203b556b 65%);box-sizing:border-box;pointer-events:auto;touch-action:none;overflow:hidden;-webkit-tap-highlight-color:transparent}
   #android-controls .joystick.active{border-color:#cce6ffbb;background-color:#31557c44}
   #android-controls .joystick .knob{position:absolute;left:50%;top:50%;width:52px;height:52px;box-sizing:border-box;border-radius:50%;border:1px solid #cce6ffb0;background:radial-gradient(circle at 35% 30%,#739fc3c9,#325976c9);box-shadow:0 2px 7px #0005;transform:translate(-50%,-50%);pointer-events:none}
   #android-controls .joystick .direction{position:absolute;color:#cbe1f59c;font-size:16px;line-height:18px;pointer-events:none}
   #android-controls .joystick .up{left:calc(50% - 8px);top:8px}#android-controls .joystick .down{left:calc(50% - 8px);bottom:8px}
   #android-controls .joystick .left{left:8px;top:calc(50% - 9px)}#android-controls .joystick .right{right:8px;top:calc(50% - 9px)}
   #android-controls .run{position:absolute;right:0;top:0}
   #android-controls .actions{position:absolute;right:max(9px,env(safe-area-inset-right));bottom:max(9px,env(safe-area-inset-bottom));display:grid;grid-template:44px 44px 48px/60px 60px;gap:5px}
   #android-controls .top{position:absolute;top:max(6px,env(safe-area-inset-top));right:max(8px,env(safe-area-inset-right));display:flex;gap:5px}
   #android-controls .top button{min-height:32px;font-size:13px;padding:5px 9px}
   #android-controls.compact .movement,#android-controls.compact .actions{display:none}
   body:has(#codex-feedback) #android-controls{display:none}
   @media(max-height:360px){#android-controls .movement{width:164px;height:140px}#android-controls .joystick{width:124px;height:124px}#android-controls .joystick .knob{width:46px;height:46px}}
   #codex-feedback .panel{max-height:94dvh!important;padding:12px 18px!important}#codex-feedback h1{font-size:22px!important}#codex-feedback textarea{min-height:65px!important}
  `;document.head.appendChild(css);
  var node=document.createElement('div');node.id='android-controls';node.innerHTML='<div class="movement"><div class="joystick" role="group" aria-label="移动摇杆"><span class="direction up">▲</span><span class="direction left">◀</span><span class="direction right">▶</span><span class="direction down">▼</span><span class="knob"></span></div><div class="direction-pad" role="group" aria-label="方向键"><i></i><button data-key="up" aria-label="向上">▲</button><i></i><button data-key="left" aria-label="向左">◀</button><i class="direction-center" aria-hidden="true"></i><button data-key="right" aria-label="向右">▶</button><i></i><button data-key="down" aria-label="向下">▼</button><i></i></div><button class="run" data-key="shift" aria-label="跑步">跑</button></div><div class="actions"><button data-key="shift" aria-label="Shift">Shift</button><button data-key="control" aria-label="Ctrl">Ctrl</button><button data-key="pageup" aria-label="上一页">前页</button><button data-key="pagedown" aria-label="下一页">后页</button><button data-key="escape">返回</button><button data-key="ok">确认</button></div><div class="top"><button data-quick disabled>快存</button><button data-tool>存档</button><button data-content>更新</button><button data-toggle>按键</button></div>';
  document.body.appendChild(node);
  ['pointerdown','pointermove','pointerup','touchstart','touchmove','touchend','mousedown','mouseup','click'].forEach(function(type){node.addEventListener(type,function(e){e.stopPropagation();});});
  // The run button and explicit Shift button share a key without releasing one another.
  var keyStates=[];
  function syncKey(key){Input._currentState[key]=keyStates.some(function(state){return state.key===key&&state.active;});}
  var wheel=node.querySelector('.joystick'),knob=wheel.querySelector('.knob'),stickPointer=null;
  var stickStates=['up','down','left','right'].map(function(key){var state={key:key,active:false};keyStates.push(state);return state;});
  function clearStick(){
   var previous=stickPointer;stickPointer=null;
   stickStates.forEach(function(state){state.active=false;state.pending=false;state.originalPending=false;state.originalReleased=false;syncKey(state.key);});
   knob.style.transform='translate(-50%,-50%)';wheel.classList.remove('active');
   if(previous!==null&&wheel.hasPointerCapture(previous))wheel.releasePointerCapture(previous);
  }
  function moveStick(e){
   var rect=wheel.getBoundingClientRect(),radius=rect.width/2;
   var x=e.clientX-(rect.left+radius),y=e.clientY-(rect.top+rect.height/2),distance=Math.hypot(x,y);
   var travel=Math.max(1,radius-knob.offsetWidth/2-8),scale=distance>travel?travel/distance:1;
   knob.style.transform='translate(calc(-50% + '+(x*scale)+'px),calc(-50% + '+(y*scale)+'px))';
   // A neutral center prevents accidental movement. Adjacent directions can
   // be held together; the game's existing movement rules choose the result.
   var active={up:false,down:false,left:false,right:false};
   if(distance>radius*.16&&SceneManager._scene instanceof Scene_Battle){
    // A menu gesture chooses one axis; diagonal map movement stays native.
    if(Math.abs(x)>Math.abs(y))active[x<0?'left':'right']=true;else active[y<0?'up':'down']=true;
   }else if(distance>radius*.16){
    if(Math.abs(x)>Math.abs(y)*.41421356237)active[x<0?'left':'right']=true;
    if(Math.abs(y)>Math.abs(x)*.41421356237)active[y<0?'up':'down']=true;
   }
   stickStates.forEach(function(state){state.active=active[state.key];syncKey(state.key);});
  }
  wheel.addEventListener('pointerdown',function(e){
   e.preventDefault();e.stopPropagation();if(stickPointer!==null||!window.Input)return;
   stickPointer=e.pointerId;wheel.setPointerCapture(stickPointer);wheel.classList.add('active');moveStick(e);
  });
  wheel.addEventListener('pointermove',function(e){if(e.pointerId!==stickPointer)return;e.preventDefault();e.stopPropagation();moveStick(e);});
  ['pointerup','pointercancel','lostpointercapture'].forEach(function(type){wheel.addEventListener(type,function(e){if(e.pointerId!==stickPointer)return;e.preventDefault();e.stopPropagation();clearStick();});});
  function bindVirtualButton(b){
   if(b._codexVirtualBinding)return b._codexVirtualBinding;
   var state={key:b.dataset.key,active:false,pressedAt:0,timer:null,single:b.dataset.single==='true'||b.dataset.key==='ok'||b.dataset.key==='escape'};keyStates.push(state);
   function clear(){clearTimeout(state.timer);state.active=false;state.pending=false;syncKey(state.key);}
   function release(e){e.preventDefault();e.stopPropagation();if(state.single)return;if(!state.active)return;clearTimeout(state.timer);state.timer=setTimeout(clear,Math.max(0,70-(Date.now()-state.pressedAt)));}
   b.addEventListener('pointerdown',function(e){e.preventDefault();e.stopPropagation();if(!window.Input)return;clearTimeout(state.timer);state.pressedAt=Date.now();state.active=true;state.pending=state.single;b.setPointerCapture(e.pointerId);syncKey(state.key);});
   ['pointerup','lostpointercapture'].forEach(function(type){b.addEventListener(type,release);});
   b.addEventListener('pointercancel',function(e){e.preventDefault();e.stopPropagation();clear();});
   state.clear=clear;b._codexVirtualBinding=state;return state;
  }
  node.querySelectorAll('[data-key]').forEach(bindVirtualButton);
  AndroidPort.bindVirtualButton=bindVirtualButton;
  AndroidPort.setVirtualDirections=function(values){var any=stickStates.some(function(s){return !!values[s.key];});stickStates.forEach(function(state){if(values[state.key]){if(!state.active)state.originalPending=true;state.active=true;state.originalReleased=false;}else if(!any&&state.originalPending){state.originalReleased=true;}else{state.active=false;state.originalPending=false;state.originalReleased=false;}syncKey(state.key);});Input._currentState.shift=!!values.shift;};
  AndroidPort.unbindVirtualButton=function(b){var state=b._codexVirtualBinding;if(!state)return;state.clear();var i=keyStates.indexOf(state);if(i>=0)keyStates.splice(i,1);delete b._codexVirtualBinding;};
  AndroidPort.queueVirtualKey=function(key){var state=keyStates.find(function(s){return s.queued&&s.key===key;});if(!state){state={key:key,queued:true,single:true,clear:function(){state.active=false;state.pending=false;syncKey(key);}};keyStates.push(state);}state.active=true;state.pending=true;syncKey(key);};
  // Confirm/cancel remain queued until one actual game input update reads them.
  // A fixed millisecond pulse can be missed on a slow equipment screen.
  var inputUpdate=Input.update;Input.update=function(){inputUpdate.apply(this,arguments);stickStates.forEach(function(state){if(state.originalPending){state.originalPending=false;if(state.originalReleased){state.originalReleased=false;state.active=false;syncKey(state.key);}}});keyStates.forEach(function(state){if(state.single&&state.pending){state.pending=false;state.active=false;syncKey(state.key);}});};
  AndroidPort.releaseTouchKeys=function(){clearStick();keyStates.forEach(function(state){if(state.clear)state.clear();});if(window.CodexAndroidTouch)CodexAndroidTouch.releaseOriginalControls();};
  window.addEventListener('blur',AndroidPort.releaseTouchKeys);
  window.addEventListener('resize',AndroidPort.releaseTouchKeys);
  document.addEventListener('visibilitychange',function(){if(document.hidden)AndroidPort.releaseTouchKeys();});
  new MutationObserver(function(){if(document.getElementById('codex-feedback'))AndroidPort.releaseTouchKeys();}).observe(document.body,{childList:true});
  node.querySelector('[data-toggle]').onclick=function(){AndroidPort.releaseTouchKeys();node.classList.toggle('compact');localStorage.setItem('kyo.android.controlsHidden',node.classList.contains('compact')?'1':'0');};
  if(localStorage.getItem('kyo.android.controlsHidden')==='1')node.classList.add('compact');
  node.querySelector('[data-content]').onclick=function(){AndroidPort.releaseTouchKeys();if(window.AndroidInterface&&typeof AndroidInterface.onlineupdate==='function')AndroidInterface.onlineupdate();else AndroidInterface.contenttools();};
  node.querySelector('[data-tool]').onclick=function(){if(SceneManager._scene instanceof Scene_Title)AndroidInterface.savetools();else AndroidInterface.message('请先保存游戏并返回标题，再导入或导出存档。');};
  var quick=node.querySelector('[data-quick]');
  CodexQuickSave.button=quick;
  quick.onclick=function(){AndroidPort.releaseTouchKeys();CodexQuickSave.run();};
  if(window.CodexAndroidTouch)CodexAndroidTouch.mount(node);
 }
 SceneManager.run=function(){
  Utils.isNwjs=function(){return false;};
  var active=SceneManager.isGameActive;SceneManager.isGameActive=function(){return AndroidPort.background||active.apply(this,arguments);};
  var update=SceneManager.update;SceneManager.update=function(){if(AndroidPort.paused)return;return update.apply(this,arguments);};
  if(window.Yanfly)Yanfly.updateResolution=function(){};
  // One touch controller across new games and imported desktop settings.
  var originalCreate=Scene_Base.prototype.createGhostButtons;
  if(originalCreate)Scene_Base.prototype.createGhostButtons=function(){var on=window.CodexAndroidTouch&&CodexAndroidTouch.useOriginalControls();ConfigManager.ghostButtons=!!on;if(on){var result=originalCreate.apply(this,arguments);CodexAndroidTouch.attachOriginalControls(this);return result;}};
  var optionsList=Window_Options.prototype.makeCommandList;Window_Options.prototype.makeCommandList=function(){optionsList.apply(this,arguments);this._list=this._list.filter(function(c){return c.symbol!=='ghostButtons';});};
  var caught=SceneManager.catchException;SceneManager.catchException=function(e){AndroidInterface.log('scene-error',String(e&&e.stack||e));return caught.apply(this,arguments);};
  SceneManager.exit=function(){AndroidInterface.closeapp();};
  var ready=Scene_Boot.prototype.start;Scene_Boot.prototype.start=function(){ready.apply(this,arguments);document.title='再刷一把：西游（mod_KYO）';controls();};
  if(AndroidInterface.isqa()){var s=document.createElement('script');s.src='js/android-qa.js';document.body.appendChild(s);}
  return run.apply(this,arguments);
 };
})();
