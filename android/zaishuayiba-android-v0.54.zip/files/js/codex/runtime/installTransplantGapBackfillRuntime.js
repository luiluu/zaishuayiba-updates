// v0.52 12.27 移植角色补齐：读档时给已招募（在队或在仓库）的角色补上招募赠送的超越极限 I～IV，
// 并给本版之前就招募了亚斯娜／夏娜／五河琴里、或已在小爱莉处领过奖的存档补发一次新增的专属装备。
window.CodexRuntime.register('installTransplantGapBackfillRuntime', function() {
  'use strict';
  var GIFT_ACTORS = [150, 151, 153, 154, 155, 156, 158, 159, 162, 163, 164, 165], GIFT_SKILLS = [1240, 1241, 1242, 1244];
  var GEAR = [[151, "Weapons", 4000], [154, "Weapons", 83], [159, "Armors", 128]];
  var ELI_ARMORS = [135, 134], REVISION = 1;
  function recruited(id) {
    var p = $gameParty;
    return (p._actors || []).indexOf(id) >= 0 || (p._saveactors || []).indexOf(id) >= 0;
  }
  // 武器、防具是独立实例（新号，baseItemId 指回原型；带随机词缀的还会隔一层新原型），顺着 baseItemId 追到最初的原型，
  // 背包和已招募角色身上任一件是这个原型就算已有
  function root(x) {
    var db = DataManager.isWeapon(x) ? $dataWeapons : $dataArmors, y = x, k = 0;
    while (y && y.baseItemId && y.baseItemId !== y.id && k++ < 8) y = db[y.baseItemId];
    return y ? y.id : 0;
  }
  function owns(kind, id) {
    var isKind = kind === 'Weapons' ? DataManager.isWeapon : DataManager.isArmor;
    var same = function(x) { return x && isKind.call(DataManager, x) && root(x) === id; };
    if ((kind === 'Weapons' ? $gameParty.weapons() : $gameParty.armors()).some(same)) return true;
    return (($gameParty._actors || []).concat($gameParty._saveactors || [])).some(function(aid) {
      var a = $gameActors.actor(aid);
      return a && a.equips().some(same);
    });
  }
  function give(kind, id) {
    var item = window['$data' + kind][id];
    if (item && !owns(kind, id)) { $gameParty.gainItem(item, 1, false); return 1; }
    return 0;
  }
  function backfill() {
    if (!window.$gameParty || !window.$gameActors || !window.$gameSystem) return 0;
    var n = 0;
    GIFT_ACTORS.forEach(function(id) {
      if (!recruited(id)) return;
      var a = $gameActors.actor(id);
      GIFT_SKILLS.forEach(function(s) { if (a && !a.isLearnedSkill(s)) { a.learnSkill(s); n++; } });
    });
    if ((Number($gameSystem._transplantGapBackfill) || 0) < REVISION) {
      GEAR.forEach(function(g) { if (recruited(g[0])) n += give(g[1], g[2]); });
      if (window.$gameSelfSwitches && $gameSelfSwitches.value([4, 11, 'A'])) ELI_ARMORS.forEach(function(id) { n += give('Armors', id); });
      $gameSystem._transplantGapBackfill = REVISION;
    }
    return n;
  }
  var extract = DataManager.extractSaveContents;
  DataManager.extractSaveContents = function(contents) {
    extract.call(this, contents);
    try { backfill(); } catch (e) { console.error('移植角色补发失败', e); }
  };
  // 新开档的招募事件本身就会给专武，不再补发
  var setup = DataManager.setupNewGame;
  DataManager.setupNewGame = function() {
    setup.apply(this, arguments);
    $gameSystem._transplantGapBackfill = REVISION;
  };
  return { version: 'v0.52', giftActors: GIFT_ACTORS, gear: GEAR, backfill: backfill };
});
