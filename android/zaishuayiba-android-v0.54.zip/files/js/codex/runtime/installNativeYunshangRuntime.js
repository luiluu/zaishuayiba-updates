// 【Codex·未经Claude检验】v0.26 无技能内容的行动不执行准备或结束效果；未经claude检验。
// 【DeepSeek·未经Codex/Claude检验】v0.49 天衣订单：胜利结算时补记最后未完成的战斗回合，避免一击结束的战斗整场不计回合。
// 【Codex·未经Claude检验】 安卓订单持久化及相同SHA指纹；核查状态：未经claude检验。
// Yunshang v4 adapted to the current Mac content registry.
window.CodexRuntime.register("installNativeYunshangRuntime", function(){
'use strict';
 var Y=window.CodexYunshang={config:{"version":"2.8.1-mac","actor":174,"class":172,"skills":{"pin":10270,"cut":10271,"wind":10272,"wake":10273,"gather":10274,"random":10275,"spread":10276,"double":10277,"silver":10278,"formation":10279,"silk":10280,"seamless":10281,"mountain":10282,"exchange":10283,"gift":10284,"store":10285,"needle":10286,"shop":10287},"robes":[{"id":7920,"key":0,"name":"山河作骨","level":35,"stage":0},{"id":7921,"key":1,"name":"百厄成锦","level":35,"stage":0},{"id":7922,"key":2,"name":"赊月偿星","level":35,"stage":0},{"id":7923,"key":3,"name":"不渡黄泉","level":40,"stage":1},{"id":7924,"key":4,"name":"逆命换锦","level":40,"stage":1},{"id":7925,"key":5,"name":"千军入袖","level":40,"stage":1},{"id":7926,"key":6,"name":"空袖藏星","level":45,"stage":1},{"id":7927,"key":7,"name":"九曲回针","level":45,"stage":1},{"id":7928,"key":8,"name":"六衡裁身","level":45,"stage":1},{"id":7929,"key":9,"name":"寸光留仙","level":50,"stage":2},{"id":7930,"key":10,"name":"孤灯照众","level":50,"stage":2},{"id":7931,"key":11,"name":"同袍换日","level":50,"stage":2},{"id":7932,"key":12,"name":"一身两世","level":55,"stage":2},{"id":7933,"key":13,"name":"万法同裳","level":55,"stage":2},{"id":7934,"key":14,"name":"七曜流霞","level":55,"stage":2}],"relic":7935,"silk":2942,"horn":2941,"hornEvent":9010,"shard":2530,"iconStart":210000,"armorBaseLength":8001,"ordinaryClothModel":4282,"advance":[{"level":35,"robes":3,"shards":50},{"level":50,"robes":9,"shards":188}],"visual":{"counts":{"2":6,"8":6,"12":6,"13":6,"14":6,"17":1},"speeds":{"2":10,"8":6,"12":6,"13":10,"14":12},"anchorY":0.96},"damageCoefficients":{"pin":66.66,"cut":111.88,"gather":246.21,"needle":33.33},"damageGrowth":"25级起每级爆伤+188%、终伤+18.88%；原生技能等级伤害倍率1+9.99L","robeDamageCoefficients":{"mountain":888.88,"bank":188.88,"debt":188.88},"unknownBattles":{"152":{"troops":[454,455],"origins":[37,38],"immortalOrigins":[38],"legacyDifficulty":[1]},"160":{"troops":[470,471,472,473,474],"origins":[50,51],"immortalOrigins":[51],"legacyDifficulty":[2,3]},"161":{"troops":[544,545,546,547,548],"origins":[52,53],"immortalOrigins":[53],"legacyDifficulty":[2,3]},"162":{"troops":[539,540,541,542],"origins":[56,57,58,59],"immortalOrigins":[57,59],"legacyDifficulty":[2,3]},"176":{"troops":[570,571,572,573,574,575],"origins":[164,165,108],"immortalOrigins":[165,108],"legacyDifficulty":[2,3]},"141":{"troops":[577,578,579,580,581,582],"origins":[167,168],"immortalOrigins":[168],"legacyDifficulty":[2,3]},"177":{"troops":[584,585,586,587,588,589],"origins":[174,175],"immortalOrigins":[174,175],"unpaired":true},"210":{"troops":[724,725,726,727,728,729],"origins":[211,216],"immortalOrigins":[211,216],"unpaired":true},"223":{"troops":[647,648,649,650,651,652,653,654,655,656,657,658,659],"origins":[184],"immortalOrigins":[184],"unpaired":true}},"transferDebuffs":[5,6,7,8,9,10,17,18,19,20,21,29,30,33,37,77,87,93,100,107,118,124,126,127,131,151,178,184,185,192,234,263,268,296,318,320,333,412,474,487,491,511,513,522,552,600,636,701,722,723,724,725,726,727,728,729,730,742,778,797,799,817,918,919,920,921,922,923,924,925,926,941,1011,1014,1015,1016,1019,1055,1095,1101,1102,1119,1129,1131,1135,1319,1646,1650,1654,1755,2503,2504,2505,2506,2507,2508,2509,2510,2511,2512,2513,2580],"shareBuffs":[43,55,64,65,72,78,82,92,113,117,119,123,130,158,162,166,168,174,193,194,205,207,209,211,215,222,230,232,237,248,267,271,273,276,287,327,380,472,519,525,531,557,565,576,592,593,619,624,626,628,635,645,688,689,803,805,806,807,808,828,829,834,933,953,1013,1017,1027,1046,1303,1304,1321,1598,1606,1619,1620,1655,2517,2628,2629],"gates":{"10270":[1,0],"10271":[10,0],"10272":[20,0],"10273":[35,1],"10274":[50,2],"10275":[35,1],"10276":[25,0],"10277":[30,0],"10278":[35,1],"10279":[40,1],"10280":[45,1],"10281":[55,2],"10282":[1,0],"10283":[1,0],"10284":[1,0],"10285":[1,0],"10286":[1,0],"10287":[20,0]},"shopEvent":9011},version:'2.8.1-mac'};
 var C=Y.config,S=C.skills,round=0,battle='',mutating=false,calculating=0,transferring=0;
 function alias(o,k,f){var prev=o[k];o[k]=function(){return f.call(this,prev,arguments);};}
 function copy(o){return JSON.parse(JSON.stringify(o));}
 function is(a){return a&&a.actorId&&a.actorId()===C.actor;}
 // Per-motion pacing is limited to Yunshang's independent SuperSV frames.
 alias(Sprite_Actor.prototype,'motionSpeed',function(old,args){
  var speed=C.visual&&C.visual.speeds[this._motion&&this._motion.index];
  return is(this._actor)&&this._mxSVActive&&speed||old.apply(this,args);
 });
 // The drawn shuttle and needle replace the native weapon overlay.
 alias(Game_Actor.prototype,'startWeaponAnimation',function(old,args){
  if(is(this)){this._weaponImageId=0;return;}
  return old.apply(this,args);
 });
 alias(Game_Actor.prototype,'performEscape',function(old,args){
  if(is(this))this.spriteFaceForward();
  return old.apply(this,args);
 });
 function members(){return $gameParty.battleMembers();}
 function base(i){return i&&Number(i.originalBaseItemId||i.baseItemId||i.id);}
 function robe(a){if(!a||!a.equips)return;var items=a.equips();for(var i=0;i<items.length;i++)if(items[i]&&base(items[i])>=7920&&base(items[i])<7935)return items[i];}
 function key(a){var r=robe(a);return r?base(r)-7920:-1;}
 function relic(a){return is(a)&&a.equips().some(function(i){return base(i)===C.relic;});}
 function normalizeRobe(i){
  var id=base(i);if(!i||id<7920||id>=7935)return i;
  var note=(i.note||'').replace(/<(?:quality|ici):\s*\d+>/gi,'').trim()+'\n<quality:12>\n<ici:12>';
  if(((i.note||'').match(/<quality:\s*\d+>/gi)||[]).length!==1||((i.note||'').match(/<ici:\s*\d+>/gi)||[]).length!==1||!i.meta||Number(i.meta.quality)!==12||Number(i.meta.ici)!==12){i.note=note;DataManager.extractMetadata(i);}refreshYunshangText(i);return i;
 }
 function data(a){
  var r=robe(a);if(!r)return null;
  var uid=r._yunUid||('native:'+r.id),d=a._yunBattle;
  if(!d||d.uid!==uid||d.battle!==battle){
   if(d&&d.debts&&d.debts.length)settleDebt(a,d);
   d=a._yunBattle={uid:uid,battle:battle,key:key(a),wakeUntil:0,bank:0,debts:[],captured:[],stored:0,ghost:0,ghostDone:0,ghostUsed:false,revived:false,freeGiftRound:-1,gifts:0,cloneRound:-1,needleUsed:false,needleOther:[],needleBypassRound:-1,lampRound:-1,cutRound:-1,releaseRound:-1};
  }return d;
 }
 function awake(a){var d=data(a);return !!d&&d.wakeUntil>=round&&d.wakeUntil>0;}
 function live(a){return a&&a.isAlive();}
 function stage(a){return Number(a&&a._AdvancedNum||0);}
 function unlocked(a,id){var g=C.gates[id];return !g||a.level>=g[0]&&stage(a)>=g[1];}
 function ownSkill(a,id){return (a._skills||[]).indexOf(id)>=0;}
 function damageAction(a){return a&&a.item()&&[1,2,5,6].indexOf(a.item().damage.type)>=0&&!a._yunDerived;}
 function sourceOriginal(a){return a._yunActionSource!=='gift'&&a._yunActionSource!=='stored';}
 function notify(t){if(window.$&&$.toaster)$.toaster({message:t});else if($gameMessage)$gameMessage.add(t);}
 Y.is=is;Y.robe=robe;Y.key=key;Y.data=data;Y.awake=awake;Y.stage=stage;Y.round=function(){return round;};
 Y.sync=function(a){
  if(!is(a)||a._yunSync)return;a._yunSync=true;
  try{Object.keys(C.gates).forEach(function(id){id=Number(id);if(id>=S.mountain&&id!==S.shop)return;if(unlocked(a,id))a.learnSkill(id);else a.forgetSkill(id);});a.need_refresh=true;if(a.initPassiveCache&&a.refreshPassiveCache){a.initPassiveCache();a.refreshPassiveCache();}a.refresh();}finally{delete a._yunSync;}
 };
 alias(Game_Actor.prototype,'setup',function(old,args){var v=old.apply(this,args);if(is(this)){this._AdvancedNum=0;Y.sync(this);}return v;});
 ['levelUp','changeLevel'].forEach(function(k){alias(Game_Actor.prototype,k,function(old,args){var v=old.apply(this,args);Y.sync(this);return v;});});
 var oldParam=Game_Actor.prototype.param;
 Game_Actor.prototype.param=function(id){
  var v=oldParam.call(this,id);
  if(is(this)&&[0,4,6].indexOf(id)>=0){var m=1;if(this.level>=25)m=1.5;if(this.level>=30)m=2;if(this.level>=35&&stage(this)>=1)m=2.5;if(this.level>=40&&stage(this)>=1)m=3;if(this.level>=50&&stage(this)>=2)m=4;v*=m;}
  var d=$gameParty&&$gameParty.inBattle()&&data(this);
  if(d&&d裁身(d)&&id>=2&&id<=7){if(d.cutAwake!==awake(this))Y.cut(this,d.cutChoices);v=d.cutValues[id];}
  if(d&&d.key===13&&[2,4].indexOf(id)>=0&&!this._yunParamPair){this._yunParamPair=true;try{v=Math.max(v,this.param(id===2?4:2));}finally{delete this._yunParamPair;}}
  if(this._yunBorrowStats&&[2,4].indexOf(id)>=0)v=Math.max(v,this._yunBorrowStats[id]||0);
  if(id===6&&this._yunWindUntil>=round&&$gameParty&&$gameParty.inBattle())v*=1.33;
  return Math.round(Math.max(id===0?1:0,Math.min(this.paramMax(id),v)));
 };
 function d裁身(d){return d.cutRound===round&&d.cutValues;}
 // Atomic independent journal. Ordinary saves retain a replay cursor only.
 var ledger=null,ledgerStore=null,legacyIdentity=null;
 function optionalJournal(fn){
  if(Y._storageError)return;
  try{return fn();}catch(e){Y._storageError=e.message;console.error('云裳订单记录不可用；普通游戏继续，订单与天丝奖励暂停',e);notify('云裳订单记录不可用，制作/进阶及天丝奖励暂停');}
 }
 function fingerprint(value){
  value=String(value);
  if(window.AndroidPort)return AndroidPort.fingerprint(value);
  if(Utils.isNwjs())return require('crypto').createHash('sha256').update(value).digest('hex');
  var h=2166136261;for(var n=0;n<value.length;n++){h^=value.charCodeAt(n);h=Math.imul(h,16777619);}return (h>>>0).toString(16)+':'+value.length;
 }
 function store(){
  if(ledgerStore)return ledgerStore;
  if(window.AndroidPort){ledgerStore=AndroidPort.ledgerStore();return ledgerStore;}
  if(Utils.isNwjs()){
   var fs=require('fs'),path=require('path'),dir=StorageManager.localFileDirectoryPath(),file=path.join(dir,'yunshang_orders_v1.json');
   ledgerStore={read:function(){return fs.existsSync(file)?fs.readFileSync(file,'utf8'):null;},write:function(s){
    fs.mkdirSync(dir,{recursive:true});var tmp=file+'.'+uuid()+'.tmp',fd;
    try{fd=fs.openSync(tmp,'wx');fs.writeFileSync(fd,s);fs.fsyncSync(fd);fs.closeSync(fd);fd=null;fs.renameSync(tmp,file);}
    finally{if(fd!=null)fs.closeSync(fd);if(fs.existsSync(tmp))fs.unlinkSync(tmp);}
   }};
  }else ledgerStore={read:function(){return localStorage.getItem('yunshang_orders_v1');},write:function(s){localStorage.setItem('yunshang_orders_v1',s);}};
  return ledgerStore;
 }
 function loadLedger(){
  if(!ledger){
   var t=store().read(),next=t?JSON.parse(t):{version:2,profiles:{},legacyProfiles:{}};
   if(next.version!==1&&next.version!==2)throw Error('云裳订单记录版本不兼容');
   if(!next.profiles||typeof next.profiles!=='object')throw Error('云裳订单记录损坏');
   next.version=2;next.legacyProfiles=next.legacyProfiles||{};delete next.active;ledger=next;
  }return ledger;
 }
 function saveLedger(next){store().write(JSON.stringify(next));ledger=next;}
 function uuid(){return Date.now().toString(36)+'-'+Math.random().toString(36).slice(2)+'-'+Math.random().toString(36).slice(2);}
 function profile(){
  var l=loadLedger(),id=$gameSystem._yunProfile;
  if(id&&!l.profiles[id])throw Error('此存档的云裳订单记录缺失；请恢复对应订单文件，暂不可制作或进阶');
  if(!id){
   id=legacyIdentity&&l.legacyProfiles[legacyIdentity];
   if(!id){
    id=uuid();var n=copy(l);n.profiles[id]={journal:[],order:null,clears:0,stage:0,recruited:false};
    if(legacyIdentity)n.legacyProfiles[legacyIdentity]=id;saveLedger(n);
   }
   if(!ledger.profiles[id])throw Error('云裳旧档绑定记录损坏');
   $gameSystem._yunProfile=id;
  }
  var p=ledger.profiles[id];if(p.order)normalizeRobe(p.order.spec);return p;
 }
 function findUid(uid){return ($dataArmors||[]).filter(function(i){return i&&i._yunUid===uid;})[0];}
 function removeUid(uid,nativeId,baseId){
  var i=findUid(uid);if(!i&&nativeId&&$dataArmors[nativeId]&&base($dataArmors[nativeId])===baseId){i=$dataArmors[nativeId];i._yunUid=uid;}if(!i)return;
  $gameParty.allMembers().forEach(function(a){a.equips().forEach(function(e,slot){if(e&&e._yunUid===uid)a.changeEquip(slot,null);});});
  $gameParty.loseItem(i,1,false);
 }
 function grantSpec(spec){
  if(findUid(spec._yunUid))return;
  var n=normalizeRobe(copy(spec));n.id=$dataArmors.length;n.baseItemId=base(spec);n.originalBaseItemId=base(spec);n.nonIndependent=false;n.DXRPSNewItem=false;
  if(n.overlayIcons&&!Y.isRobeItem(n)){$gameSystem.overlayIcons=$gameSystem.overlayIcons||[];n.iconIndex=6400+$gameSystem.overlayIcons.length;$gameSystem.overlayIcons.push(copy(n.overlayIcons));}
  $dataArmors.push(n);DataManager._independentArmors.push(n);$gameParty._armors[n.id]=1;
 }
 function replay(){
  var p=profile(),seq=Number($gameSystem._yunSeq||0);
  mutating=true;try{
   for(var j=seq;j<p.journal.length;j++){
    var op=p.journal[j];
    if(op.delta)$gameParty.gainItem($dataItems[op.item],op.delta,false);
    if(op.grant)grantSpec(op.grant);
    if(op.remove)removeUid(op.remove,op.nativeId,op.baseId);
    $gameSystem._yunSeq=j+1;
   }
   (DataManager._independentArmors||[]).forEach(normalizeRobe);
   var a=$gameActors._data[C.actor];if(a){a._AdvancedNum=p.stage;Y.sync(a);}
  }finally{mutating=false;}
 }
 function transaction(fn){
  profile();var n=copy(ledger),p=n.profiles[$gameSystem._yunProfile];fn(p);saveLedger(n);replay();return p;
 }
 Y.ledger=function(){return copy(profile());};Y.replay=replay;
 function owned(){return $gameParty.armors().filter(function(i){return i&&base(i)>=7920&&base(i)<7935&&i.id>=8001;});}
 Y.advance=function(selected){
  replay();var a=$gameActors.actor(C.actor),s=stage(a),req=C.advance[s];
  if(!req||a.level<req.level)throw Error('等级不足或已完成两次进阶');
  var allowed=owned(),seen={};if(selected.length!==req.robes)throw Error('天衣数量不符');
  selected.forEach(function(i){if(allowed.indexOf(i)<0||seen[i.id])throw Error('请选择背包中的不同天衣，已装备天衣须先卸下');seen[i.id]=true;});
  if($gameParty.numItems($dataItems[C.shard])<req.shards)throw Error('人道意志碎片不足');
  // Give old generated robes a stable identity before the durable transaction.
  selected.forEach(function(i){if(!i._yunUid)i._yunUid=uuid();});
  transaction(function(p){p.journal.push({item:C.shard,delta:-req.shards});selected.forEach(function(i){p.journal.push({remove:i._yunUid,nativeId:i.id,baseId:base(i)});});p.stage=s+1;});
  notify('云裳完成第'+(s+1)+'次进阶');return true;
 };
 Y.pool=function(){var a=$gameActors.actor(C.actor);return C.robes.filter(function(r){return a.level>=r.level&&stage(a)>=r.stage;});};
 // Use the native maximum cloth template unlocked by the world's equipment cap.
 Y.equipmentCap=function(){return $dataArmors.slice(0,8001).reduce(function(cap,i){var m=i&&i.etypeId===4&&i.atypeId===1&&/<Prefixes>/i.test(i.note||'')&&/<req_level:\s*(\d+)>/i.exec(i.note||'');return m?Math.max(cap,Number(m[1])):cap;},1);};
 function model(){
  var cap=Y.equipmentCap(),list=$dataArmors.slice(0,8001).filter(function(i){var m=i&&/<req_level:\s*(\d+)>/i.exec(i.note||'');return i&&i.etypeId===4&&i.atypeId===1&&m&&Number(m[1])<=cap&&/<Prefixes>/i.test(i.note||'')&&base(i)<7920;});
  list.sort(function(a,b){return Number(/<req_level:\s*(\d+)>/i.exec(b.note)[1])-Number(/<req_level:\s*(\d+)>/i.exec(a.note)[1]);});
  return list[0]||$dataArmors[C.ordinaryClothModel];
 }
 Y.submit=function(){
  if($gameParty.inBattle())throw Error('战斗外才能开工');replay();var p=profile(),pool=Y.pool();
  if(p.order)throw Error('请先完成并领取当前订单');
  if(!pool.length)throw Error('35级才能解锁首批制作池');
  if($gameParty.numItems($dataItems[C.silk])<15)throw Error('需要15份不朽天丝');
  var r=pool[Math.randomInt(pool.length)],template=copy(model()),locked=copy($dataArmors[r.id]);
  // Retain native base stats/affix distributions, strip template-specific fixed mechanics.
  var notes=template.note||'',prefix=notes.match(/<Prefixes>[\s\S]*?<\/Prefixes>/i),variance=notes.match(/<Random Variance:\s*\d+>/i);
  locked.params=template.params.slice();locked.traits=[];
  locked.note+=(prefix?'\n'+prefix[0]:'')+'\n'+(variance?variance[0]:'<Random Variance: 0>');
  locked.note=locked.note.replace(/<Random Variance: 0>/,'');DataManager.extractMetadata(locked);
  var temporaryId=$dataArmors.length,independentLength=DataManager._independentArmors.length;locked.id=temporaryId;$dataArmors.push(locked);
  var generated;
  try{DataManager.processYanflyTags(locked);generated=DreamX.RandomPrefixSuffix.makeItem(locked);}finally{$dataArmors.length=temporaryId;DataManager._independentArmors.length=independentLength;}
  // Native rolls are complete now; no randomness is invoked on claim/replay.
  generated._yunUid=uuid();generated.baseItemId=r.id;generated.originalBaseItemId=r.id;generated._yunRobeKey=r.key;generated._yunEquipmentCap=Y.equipmentCap();generated.name=r.name;generated.priorityName=r.name;generated.description=$dataArmors[r.id].description;generated.DXRPSNewItem=false;
  // Ordinary affix quality never replaces a robe's fixed super-artifact tier.
  normalizeRobe(generated);
  transaction(function(n){n.journal.push({item:C.silk,delta:-15});n.order={id:uuid(),spec:generated,progress:0,roundTokens:[]};});return copy(profile().order);
 };
 Y.claim=function(){replay();var p=profile();if(!p.order||p.order.progress<10)throw Error('订单尚未完成');var result=copy(p.order.spec);transaction(function(n){n.journal.push({grant:result,order:n.order.id});n.order=null;});return result;};
 Y.progress=function(token){var p=profile();if(!p.order||p.order.progress>=10||p.order.roundTokens.indexOf(token)>=0)return false;transaction(function(n){n.order.roundTokens.push(token);n.order.progress=Math.min(10,n.order.progress+1);});return true;};
 alias(DataManager,'setupNewGame',function(old,args){var v=old.apply(this,args),id=uuid();legacyIdentity=null;$gameSystem._yunProfile=id;$gameSystem._yunSeq=0;Y._storageError=null;optionalJournal(function(){var n=copy(loadLedger());n.profiles[id]={journal:[],order:null,clears:0,stage:0,recruited:false};saveLedger(n);});return v;});
 alias(DataManager,'extractSaveContents',function(old,args){
  var identity=DataManager._yunLoadIdentity||('legacy-direct:'+fingerprint(JsonEx.stringify(args[0])));
  var v=old.apply(this,args);legacyIdentity=identity;
  try{replay();Y._storageError=null;}catch(e){Y._storageError=e.message;console.error('云裳订单功能暂不可用，普通存档已保留',e);}
  Y.sync($gameActors._data[C.actor]);return v;
 });
 alias(DataManager,'loadGame',function(old,args){
  var previous=this._yunLoadIdentity;
  try{try{var raw=StorageManager.load(args[0]);this._yunLoadIdentity='legacy-slot:'+args[0]+':'+fingerprint(raw);}catch(e){delete this._yunLoadIdentity;}return old.apply(this,args);}
  finally{if(previous===undefined)delete this._yunLoadIdentity;else this._yunLoadIdentity=previous;}
 });
 alias(Game_Party.prototype,'gainItem',function(old,args){
  var item=args[0],amount=args[1];
  if(!mutating&&amount<0&&item&&item._yunUid&&$gameParty===this&&!this._yunEquipTrade&&(this.numItems(item)>0||args[2]&&this.checkItemIsEquipped(item))){transaction(function(p){p.journal.push({remove:item._yunUid,nativeId:item.id,baseId:base(item)});});return;}
  return old.apply(this,args);
 });
 alias(Game_Actor.prototype,'tradeItemWithParty',function(old,args){$gameParty._yunEquipTrade=true;try{return old.apply(this,args);}finally{delete $gameParty._yunEquipTrade;}});
 Y.recruit=function(){replay();var a=$gameActors.actor(C.actor);$gameParty.addActor(C.actor);a._AdvancedNum=profile().stage;Y.sync(a);if(!profile().recruited){$gameParty.gainItem($dataArmors[C.relic],1,false);var gear=$gameParty.armors().filter(function(i){return base(i)===C.relic;}).slice(-1)[0];gear._yunUid=uuid();transaction(function(p){p.recruited=true;p.journal.push({grant:copy(gear)});});}notify('云裳已加入队伍');};
 alias(Scene_Shop.prototype,'prepare',function(old,args){var goods=args[0]||[];if($gameMap.mapId()===132&&goods.some(function(g){return g[0]===0&&$dataItems[g[1]]&&/^伙伴号角：/.test($dataItems[g[1]].name);})&&!goods.some(function(g){return g[0]===0&&g[1]===C.horn;}))goods.push([0,C.horn,0,0]);return old.apply(this,[goods,args[1]]);});
 // Stable custom icons, including large DreamX previews.
 function icon(index){return index>=C.iconStart&&index<C.iconStart+14;}
 function drawIcon(w,index,x,y,size){var bitmap=ImageManager.loadSystem('Yunshang_Icons'),contents=w.contents;function draw(){if(w.contents===contents)contents.blt(bitmap,(index-C.iconStart)*32,0,32,32,x,y,size,size);}if(bitmap.isReady&&!bitmap.isReady()){bitmap.addLoadListener(draw);return;}draw();}
 alias(Window_Base.prototype,'drawIcon',function(old,args){if(!icon(args[0]))return old.apply(this,args);drawIcon(this,args[0],args[1],args[2],32);});
 if(Window_Base.prototype.DXDrawLargeIcon)alias(Window_Base.prototype,'DXDrawLargeIcon',function(old,args){var i=this._item||args[0];if(i&&icon(i.iconIndex)){var s=Number(Yanfly.Param.ItemIconSize)||64;drawIcon(this,i.iconIndex,(144-s)/2,(144-s)/2,s);return;}return old.apply(this,args);});
 if(typeof Window_ItemStatus!=='undefined')alias(Window_ItemStatus.prototype,'drawLargeIcon',function(old,args){if(this._item&&icon(this._item.iconIndex)){this.contents.blt(ImageManager.loadSystem('Yunshang_Icons'),(this._item.iconIndex-C.iconStart)*32,0,32,32,0,0,128,128);return;}return old.apply(this,args);});
 Y.wake=function(a){
  var d=data(a);if(!d||!live(a))return false;var fresh=!awake(a);d.wakeUntil=Math.max(d.wakeUntil,round+1);
  if(fresh){d.debtConversion=true;d.exchangeCharge=true;if(d.key===7){var eye=setting(a).eye;if(eye)a.setCooldown(eye,0);}if(d.key===8&&d.cutRound===round)Y.cut(a,d.cutChoices);}
  var cloud=$gameActors._data[C.actor];if(cloud&&members().indexOf(cloud)>=0&&relic(cloud))cloud._yunAfterglow=true;
  return true;
 };
 function setting(a){a._yunSettings=a._yunSettings||{};var i=robe(a),id=i&&(i._yunUid||'native:'+i.id);return a._yunSettings[id]||(a._yunSettings[id]={borrow:[],eye:0,elements:[2,3,4],element:2});}
 Y.setting=setting;
 function ordinary(id,bad){return (bad?C.transferDebuffs:C.shareBuffs).indexOf(Number(id))>=0;}
 function stateCopy(from,to,id,turns){if(window.CodexAlienation&&!CodexAlienation._yunTransferFrame){CodexAlienation._yunTransferFrame=true;try{return CodexAlienation.withFrame(null,to,'support',function(){return stateCopy(from,to,id,turns);},from);}finally{CodexAlienation._yunTransferFrame=false;}}if(!to.isStateAddable(id)||to.stateRate(id)<=0)return false;transferring++;try{to.addState(id);if(to.isStateAffected(id)){to._stateTurns[id]=turns==null?from._stateTurns[id]:turns;if(window.CodexAlienation&&id===CodexAlienation.config.ids.corrosion)CodexAlienation.syncCorrosion(to,to._stateTurns[id]);}return to.isStateAffected(id);}finally{transferring--;}}
 function settleDebt(a,d){var total=d.debts.reduce(function(s,x){return s+x.amount;},0);d.debts=[];if(total>0){a.gainHp(-total);a.refresh();}}
 ['changeEquip','forceChangeEquip'].forEach(function(name){alias(Game_Actor.prototype,name,function(old,args){var previous=robe(this),d=this._yunBattle;if(previous&&previous!==args[1]&&this.equipSlots()[args[0]]===4&&d){settleDebt(this,d);if(d.ghost)endGhost(this,d);delete this._yunBattle;}return old.apply(this,args);});});
 function repay(d,n){for(var i=0;i<d.debts.length&&n>0;i++){var x=d.debts[i],pay=Math.min(n,x.amount);x.amount-=pay;n-=pay;}d.debts=d.debts.filter(function(x){return x.amount>0;});}
 function resetRound(){
  round=$gameTroop.turnCount();if(round<1)round=1;
  members().forEach(function(a){a._yunGiftReceived=0;var d=data(a);if(!d)return;d.gifts=0;d.needleOther=[];d.lampRound=-1;if(d.key===9&&awake(a))d.stored=Math.min(3,d.stored+1);});
  Y._lampShared=[];Y._acted=[];Y._giftSources={};
  var cloud=$gameActors._data[C.actor];if(cloud&&members().indexOf(cloud)>=0&&live(cloud)&&ownSkill(cloud,S.random)){
   var sleeping=members().filter(function(a){return live(a)&&robe(a)&&!awake(a);});if(sleeping.length)Y.wake(sleeping[Math.randomInt(sleeping.length)]);
  }
 }
 alias(BattleManager,'startBattle',function(old,args){var v=old.apply(this,args);battle=uuid();round=1;Y._roundStart=null;Y._roundEnd=null;Y._rewarded=false;Y._lampShared=[];Y._acted=[];Y._giftSources={};members().forEach(function(a){delete a._yunBattle;delete a._yunWindUntil;delete a._yunAfterglow;data(a);});var cloud=$gameActors._data[C.actor];Y.sync(cloud);if(cloud&&live(cloud)&&members().indexOf(cloud)>=0&&ownSkill(cloud,S.seamless))members().forEach(function(a){if(robe(a))Y.wake(a);});return v;});
 alias(BattleManager,'startTurn',function(old,args){var v=old.apply(this,args),turn=$gameTroop.turnCount();if(Y._roundStart!==turn){Y._roundStart=turn;resetRound();}return v;});
 alias(BattleManager,'endTurn',function(old,args){var v=old.apply(this,args),turn=$gameTroop.turnCount();if(this._phase!=='turnEnd'||!this._enteredEndPhase||Y._roundEnd===turn)return v;Y._roundEnd=turn;members().forEach(function(a){var d=data(a);if(!d)return;var due=d.debts.filter(function(x){return x.due<=round;});d.debts=d.debts.filter(function(x){return x.due>round;});if(due.length)a.gainHp(-due.reduce(function(s,x){return s+x.amount;},0));if(d.ghost&&round>=d.ghostExpires)endGhost(a,d);d.cutValues=null;});var cloud=$gameActors._data[C.actor];if(cloud&&members().indexOf(cloud)>=0)optionalJournal(function(){Y.progress(battle+':'+turn);});return v;});
 alias(Game_Map.prototype,'setup',function(old,args){var from=this.mapId(),to=Number(args[0]),route=C.unknownBattles[to],origin=this._yunUnknownOrigin;if(!route)origin=null;else if(from!==to)origin=Number(from);var v=old.apply(this,args);this._yunUnknownOrigin=origin;return v;});
 Y.isImmortalClear=function(){var mid=$gameMap.mapId(),route=C.unknownBattles[mid];if(!route||route.troops.indexOf($gameTroop._troopId)<0)return false;var origin=$gameMap._yunUnknownOrigin;if(origin==null&&(mid===152||mid===176))origin=$gameMap._codexLeviathanUnknownOrigin;if(origin!=null)return route.immortalOrigins.indexOf(Number(origin))>=0;return !!route.unpaired||(route.legacyDifficulty||[]).indexOf(Number($gameVariables.value(107)))>=0;};
 alias(BattleManager,'endBattle',function(old,args){
  if(args[0]===0&&battle){var yc=$gameActors._data[C.actor],yturn=$gameTroop.turnCount();if(yturn>0&&yc&&members().indexOf(yc)>=0)optionalJournal(function(){Y.progress(battle+':'+yturn);});}
  if(args[0]===0&&!Y._rewarded&&Y.isImmortalClear()){
   Y._rewarded=true;var cloud=$gameActors._data[C.actor],bonus=cloud&&members().indexOf(cloud)>=0&&ownSkill(cloud,S.silk);
   optionalJournal(function(){transaction(function(p){p.clears++;if(bonus)p.bonusClears=(p.bonusClears||0)+1;p.journal.push({item:C.silk,delta:1+(bonus&&p.bonusClears%2===0?1:0)});});});
  }
  $gameActors._data.forEach(function(a){if(!a)return;var d=a._yunBattle;if(d&&d.battle===battle){settleDebt(a,d);if(d.ghost)endGhost(a,d);delete a._yunBattle;}delete a._yunWindUntil;delete a._yunBorrowStats;delete a._yunAfterglow;});battle='';round=0;return old.apply(this,args);
 });
 // Native skills and cooldowns; extra actions never bypass costs.
 alias(Game_Actor.prototype,'skills',function(old,args){var a=this,list=old.apply(a,args).filter(function(s){return !is(a)||unlocked(a,s.id);}),k=key(a);if(k===0)list.push($dataSkills[S.mountain]);if(k===4)list.push($dataSkills[S.exchange]);if(k===11)list.push($dataSkills[S.gift]);if(k===9)list.push($dataSkills[S.store]);if(k===6){var set=setting(a),limit=awake(a)?3:1;set.borrow.slice(0,limit).forEach(function(r){var owner=$gameActors._data[r.owner],s=$dataSkills[r.skill];if(owner&&members().indexOf(owner)>=0&&ownSkill(owner,r.skill)&&Y.borrowable(s))list.push(s);});}return list.filter(function(s,i){return s&&list.indexOf(s)===i;});});
 Y.borrowable=function(s){return !!s&&s.id<S.pin&&s.occasion!==3&&s.stypeId!==4&&!/<(?:Custom|Passive|SkillKill|SkillFrUse|Switch|Variable|Actor|req_|MagicWeapon)/i.test(s.note||'')&&!/Codex|\$game|\ba\._|\bb\._|\ba\.[A-Za-z]+\s*\(/.test(s.damage.formula||'')&&!/形态|领域|觉醒|进阶|制作|唤醒|召唤|复活|变身|解放|无限|天与/.test(s.name)&&!s.effects.some(function(e){return e.code===44||e.code===43||(e.code===21||e.code===22)&&!ordinary(e.dataId,true)&&!ordinary(e.dataId,false);});};
 alias(Game_Actor.prototype,'meetsSkillConditions',function(old,args){
  var s=args[0],d=data(this);if(!s)return false;if(is(this)&&!unlocked(this,s.id))return false;
  if(s.id===S.wake&&!members().some(function(a){return live(a)&&robe(a);}))return false;
  if(s.id===S.gather&&!members().some(awake))return false;
  if(s.id===S.gift&&(key(this)!==11||d.gifts>=3||!sourceOriginal(this)||d.ghost))return false;
  if(s.id===S.store&&(key(this)!==9||!sourceOriginal(this)||d.ghost))return false;
  if(d&&d.key===6&&!ownSkill(this,s.id)){var choices=setting(this).borrow,index=choices.findIndex(function(x){return x.skill===s.id;});if(index>=0){var owner=$gameActors._data[choices[index].owner];if(index>=(awake(this)?3:1)||!owner||members().indexOf(owner)<0||!ownSkill(owner,s.id)||!Y.borrowable(s))return false;}}
  if(d&&d.key===7&&awake(this)&&setting(this).eye===s.id&&d.needleBypassRound!==round){var cd=this.cooldown(s.id);this.setCooldown(s.id,0);try{return old.apply(this,args);}finally{this.setCooldown(s.id,cd);}}
  return old.apply(this,args);
 });
 alias(Game_Action.prototype,'testApply',function(old,args){var target=args[0],id=this.item().id;if(id===S.wake)return live(target)&&!!robe(target);if(id===S.gift)return target!==this.subject()&&live(target);if(this.isForDeadFriend()&&target._yunBattle&&target._yunBattle.ghost)return true;return old.apply(this,args);});
 alias(Game_Action.prototype,'itemHit',function(old,args){return is(this.subject())&&this.isSkill()&&this.item().damage.type>0?1:old.apply(this,args);});
 alias(Game_Action.prototype,'itemEva',function(old,args){return is(this.subject())&&this.isSkill()&&this.item().damage.type>0?0:old.apply(this,args);});
 alias(Game_Action.prototype,'itemCri',function(old,args){var n=old.apply(this,args);return relic(this.subject())&&this.item().damage.critical?Math.max(0,Math.min(1,n+3)):n;});
 alias(Game_Action.prototype,'numRepeats',function(old,args){var n=old.apply(this,args);return !this._yunDerived&&is(this.subject())&&ownSkill(this.subject(),S.double)&&damageAction(this)?n*2:n;});
 alias(Game_Action.prototype,'makeTargets',function(old,args){var targets=old.apply(this,args);if(!this._yunDerived&&is(this.subject())&&ownSkill(this.subject(),S.spread)&&this.isForOpponent()&&damageAction(this)&&this.isForOne()){var a=this.opponentsUnit().aliveMembers(),p=targets[0];targets=p?[p].concat(a.filter(function(x){return x!==p;})):a;targets=this.repeatTargets(targets);}if(this._yunSleeve&&this.isForOpponent()&&this.isForAll()||this._yunSleeve&&is(this.subject())&&ownSkill(this.subject(),S.spread)&&damageAction(this)){this._yunSleeveTargets=this.opponentsUnit().aliveMembers().slice();var t=this.opponentsUnit().smoothTarget(this._targetIndex);targets=this.repeatTargets([t]);}return targets;});
 Y.offensiveGrowth=function(a){var n=Math.max(0,Math.min(99,a.level||1)-24);return {crit:n*1.88,final:n*.1888};};
 alias(Game_Actor.prototype,'refreshPassiveCache',function(old,args){
  var v=old.apply(this,args),cache=this._passiveCache;if(!cache||!is(this))return v;
  var previous=cache._yunGrowth||{crit:0,final:0},g=ownSkill(this,S.spread)?Y.offensiveGrowth(this):{crit:0,final:0};
  var finalBonus=g.final+(this._equips&&this._equips.length&&relic(this)?3:0);
  cache.critHarmRi=(cache.critHarmRi||0)-previous.crit+g.crit;cache.globalHarmRi=(cache.globalHarmRi||0)-previous.final+finalBonus;
  cache._yunGrowth={crit:g.crit,final:finalBonus};return v;
 });
 Y.formula=function(action,a,b){
  var id=action.item().id,v=0,defense=window.CodexDamage&&CodexDamage.isCalculating()?0:action._yunPhysicalRoute?b.def:b.mdf,k=C.damageCoefficients;
  if(id===S.pin)v=k.pin*Math.max(0,a.mat-defense*.1);
  if(id===S.cut)v=k.cut*Math.max(0,a.mat-defense*.1);
  if(id===S.gather)v=k.gather*Math.max(0,a.mat-defense*.05)*(action._yunGatherRounds||0);
  if(id===S.mountain)v=C.robeDamageCoefficients.mountain*Math.max(0,a.def+a.mdf-defense*.1);
  if(id===S.needle)v=k.needle*Math.max(0,(action._yunNeedleMat||a.mat)-defense*.1);
  if(action._yunRaw!=null)v=action._yunRaw;
  return Math.max(0,v);
 };
 Y.storedDamage=function(a,value,kind){return Math.max(0,value)*C.robeDamageCoefficients[kind];};
 var oldDamage=Game_Action.prototype.makeDamageValue;
 function nativeDamage(action,target,critical,options){
  var item=action.item(),original=item.damage.elementId,hit=item.hitType,formula=item.damage.formula,note=item.note,cache=action.subject()._passiveCache,saved,phy=options&&options.physical,categoryRatio=1;
  var subject=action.subject(),mastery=subject.skillMasteryLevel,ownMastery=Object.prototype.hasOwnProperty.call(subject,'skillMasteryLevel');
  if(!action.subject()._passiveCache&&action.subject().refreshPassiveCache){action.subject().initPassiveCache();action.subject().refreshPassiveCache();}
  if(!target._passiveCache&&target.refreshPassiveCache){target.initPassiveCache();target.refreshPassiveCache();}
  cache=subject._passiveCache;
  var suppress=options&&options.suppress;if(suppress)calculating++;
  try{
   if(item.id===S.mountain||action._yunStoredKind){
    var rune=Y.offensiveGrowth(subject);saved=copy(subject._passiveCache);subject._passiveCache=copy(saved);cache=subject._passiveCache;
    cache.critHarmRi=Math.max(cache.critHarmRi||0,rune.crit);cache.globalHarmRi=Math.max(cache.globalHarmRi||0,rune.final);
   }
   // Derived damage uses the trigger's native mastery once; no extra multiplier.
   if(action._yunMasteryLevel!=null&&mastery)subject.skillMasteryLevel=function(skill){var id=typeof skill==='object'?skill.id:skill;return id===item.id?action._yunMasteryLevel:mastery.call(this,skill);};
   if(options&&options.element!=null)item.damage.elementId=options.element;
   if(options&&options.raw!=null){action._yunRaw=options.raw;item.damage.formula='CodexYunshang.formula(this,a,b)';}
   if(options&&options.route){item.hitType=phy?1:2;action._yunPhysicalRoute=phy;item.damage.formula=formula.replace(phy?/b\.mdf\b/g:/b\.def\b/g,phy?'b.def':'b.mdf');}
   // Native SelfPhysRate/SelfElemRate are category multipliers; element
   // amplification remains on the original element, without sharing sums.
   if(key(action.subject())===13){
    var physicalRate=1,magicRate=1;action.subject().traitObjects().forEach(function(o){var p=/<SelfPhysRate:(\d+\.?\d+)>/i.exec(o.note||''),m=/<SelfElemRate:(\d+\.?\d+)>/i.exec(o.note||'');if(p)physicalRate*=Number(p[1]);if(m)magicRate*=Number(m[1]);});
    var selected=item.damage.elementId===1?physicalRate:(item.damage.elementId>=2&&item.damage.elementId<=9?magicRate:1);if(selected>0)categoryRatio=Math.max(physicalRate,magicRate)/selected;
    if(cache){if(!saved)saved=copy(cache);var pen=cache.penetrateHarmRe,eid=item.damage.elementId;if(pen&&eid>0){pen.fixed[eid]=Math.max(pen.fixed[eid]||0,pen.fixed[1]||0);pen.percent[eid]=Math.min(100,Math.max(pen.percent[eid]||0,pen.percent[1]||0));}}
   }
   if(window.CodexDamage)return CodexDamage.calculate(action,target,{critical:critical,raw:options&&options.raw,mode:options&&options.route?(phy?'physical':'magical'):undefined,preview:!!action._codexPowerPreview,isolated:!!action._codexPowerPreview,commit:!action._codexPowerPreview}).value;
   return Math.max(0,oldDamage.call(action,target,critical)*categoryRatio);
  }finally{if(action._yunMasteryLevel!=null&&mastery){if(ownMastery)subject.skillMasteryLevel=mastery;else delete subject.skillMasteryLevel;}if(suppress)calculating--;item.damage.elementId=original;item.damage.formula=formula;item.hitType=hit;item.note=note;delete action._yunRaw;delete action._yunPhysicalRoute;if(saved)action.subject()._passiveCache=saved;}
 }
 Game_Action.prototype.makeDamageValue=function(target,critical){
  var a=this.subject(),d=data(a),item=this.item(),elements=[null],routes=[null],total=0;
  if([1,2,5,6].indexOf(item.damage.type)<0||!is(a)&&!d&&!this._yunPinWeaken&&!this._yunNeedleRate)return oldDamage.call(this,target,critical);
  if(!this._yunDerived&&damageAction(this)&&d&&d.key===14){var set=setting(a);elements=awake(a)?set.elements.slice():[set.element];}
  if(!this._yunDerived&&damageAction(this)&&d&&d.key===13&&awake(a))routes=[false,true];
  var sleeve=this._yunSleeveTargets,targets=sleeve||[target];
  for(var i=0;i<targets.length;i++)for(var e=0;e<elements.length;e++)for(var r=0;r<routes.length;r++){
   var n=nativeDamage(this,targets[i],critical,{element:elements[e],route:routes[r]!==null,physical:routes[r]===true,suppress:!!this._yunDerived||i>0||e>0||r>0});
   if(is(a)&&!this._yunDerived&&ownSkill(a,S.double)&&damageAction(this))n*=.555;
   if(is(a)&&ownSkill(a,S.spread)&&this.isForOne()&&damageAction(this)&&targets[i]!==this._yunPrimary)n*=ownSkill(a,S.silver)?.77:ownSkill(a,S.double)?.66:.5;
   total+=n;
  }
  if(relic(a)&&this.isSkill()&&item.damage.type>0)total*=1.99*(this._yunGlow||1);
  if(this._yunNeedleRate)total*=this._yunNeedleRate;
  if(this._yunNeedleGlow)total*=this._yunNeedleGlow;
  if(this._yunPinWeaken)total*=.67;
  return Number.isFinite(total)?Math.round(Math.max(0,total)):0;
 };
 function derived(source,target,skill,options){
  if(!target||!live(target))return 0;var action=new Game_Action(source),o=options||{};action.setSkill(skill);action._yunDerived=true;action._yunNeedleMat=o.mat;action._yunNeedleRate=o.rate||1;action._yunNeedleGlow=o.glow||1;action._yunMasteryLevel=o.masteryLevel;action._yunStoredKind=o.kind;
  var crit=Math.random()<action.itemCri(target),n=o.damage==null?(o.raw==null?action.makeDamageValue(target,crit):nativeDamage(action,target,crit,{raw:o.raw,suppress:true})*(relic(source)?1.99:1)):o.damage;
  if(o.rate&&o.raw!=null)n*=o.rate;n=Math.round(n);var before=target.hp;
  action.executeDamage(target,n);if(target.startDamagePopup)target.startDamagePopup();if(target.startAnimation)target.startAnimation($dataSkills[skill].animationId,false,0);
  return Math.min(before,Math.max(0,n));
 }
 Y.derived=derived;
 function burst(target,all){
  var list=target._yunNeedles||[],take=all?list.length:Math.min(1,list.length);
  for(var i=0;i<take;i++){var n=list.shift(),source=$gameActors.actor(n.owner);for(var p=0;p<n.parts&&live(target);p++)derived(source,target,S.needle,{mat:n.mat,rate:n.rate,glow:n.glow,masteryLevel:n.mastery==null?source.skillMasteryLevel(S.pin):n.mastery});}
 }
 function endGhost(a,d){d.ghost=0;d.ghostEnding=true;try{a.setHp(0);a.addState(a.deathStateId());}finally{delete d.ghostEnding;}}
 function ghostDie(old,args){var d=data(this);if($gameParty.inBattle()&&d&&d.key===3&&!d.ghostUsed&&!d.ghostEnding){d.ghostUsed=true;d.ghost=2;d.ghostDone=0;d.ghostExpires=round+1;this._hp=1;this.removeState(this.deathStateId());return;}return old.apply(this,args);}
 alias(Game_Battler.prototype,'die',ghostDie);alias(Game_Actor.prototype,'die',ghostDie);
 alias(Game_BattlerBase.prototype,'revive',function(old,args){var d=this._yunBattle;if(d&&d.ghost){d.ghost=0;d.ghostDone=0;}return old.apply(this,args);});
 alias(Game_Unit.prototype,'deadMembers',function(old,args){var list=old.apply(this,args);if(this===$gameParty&&$gameParty.inBattle())members().forEach(function(a){if(a._yunBattle&&a._yunBattle.ghost&&list.indexOf(a)<0)list.push(a);});return list;});
 alias(Game_Unit.prototype,'smoothDeadTarget',function(old,args){var a=this.members()[args[0]];if(a&&a._yunBattle&&a._yunBattle.ghost)return a;return old.apply(this,args);});
 alias(Game_Action.prototype,'itemEffectRemoveState',function(old,args){var target=args[0],effect=args[1];if(effect.dataId===target.deathStateId()&&target._yunBattle&&target._yunBattle.ghost&&Math.random()<effect.value1){target._yunBattle.ghost=0;target._yunBattle.ghostDone=0;target.setHp(Math.max(1,target.hp));return;}return old.apply(this,args);});
 function stateAdded(old,args){
  if(calculating)return;var id=args[0],d=data(this),had=this.isStateAffected(id),v;
  if(id===this.deathStateId()&&d&&d.key===3&&(!d.ghostUsed||d.ghost)){if(!d.ghost)this.die();if(d.ghost)return;}
  v=old.apply(this,args);if(!this.isStateAffected(id)||had||transferring||!$gameParty.inBattle())return v;
  if(d&&d.key===1&&ordinary(id,true)){
   var cap=awake(this)?6:3;if(d.captured.length<cap&&!d.captured.some(function(x){return x.id===id;})){d.captured.push({id:id,turns:this._stateTurns[id],cleaned:awake(this)});if(awake(this))this.removeState(id);}
  }
  if(ordinary(id,false)&&!Y._teamBuffApplying){
   var lamps=members().filter(function(a){return key(a)===10&&awake(a);});
   var use=lamps.length&&Y._lampShared.indexOf(id)<0&&Y._lampShared.length<3;
   if(!use&&d&&d.key===10&&!awake(this)&&d.lampRound!==round){d.lampRound=round;use=true;}
   if(use){if(lamps.length)Y._lampShared.push(id);members().forEach(function(a){if(a!==this)stateCopy(this,a,id);},this);}
  }return v;
 }
 // Existing character modules keep a separate Actor.addState alias chain.
 alias(Game_Battler.prototype,'addState',stateAdded);
 alias(Game_Actor.prototype,'addState',stateAdded);
 alias(Game_Action.prototype,'executeHpDamage',function(old,args){
  var target=args[0],value=args[1],d=data(target),source=this.subject();
  if(value>0&&target.isActor()&&members().indexOf(target)>=0&&$gameParty.inBattle()&&!this._yunNoTransfer){
   var guards=members().filter(function(a){return a!==target&&live(a)&&key(a)===0&&awake(a);});
   if(guards.length){var total=Math.floor(value*.33),each=Math.floor(total/guards.length),remainder=total-each*guards.length;value-=total;guards.forEach(function(a,i){var take=each+(i===0?remainder:0),before=a.hp;a.gainHp(-take);data(a).bank=Math.min(a.mhp*3,data(a).bank+Math.min(before,take));});}
  }
  if(d&&d.key===2&&value>0&&!this._yunDebtSettlement){var debt=d.debts.reduce(function(s,x){return s+x.amount;},0),delay=Math.min(Math.floor(value*.5),Math.max(0,target.mhp*2-debt));if(delay>0){d.debts.push({amount:delay,due:round+1});value-=delay;}}
  var before=target.hp,v=old.call(this,target,value);
  if(!this._yunDerived&&damageAction(this)){this._yunTotal=(this._yunTotal||0)+Math.min(before,Math.max(0,value));(this._yunHits||(this._yunHits=[])).push({target:target,value:value,critical:target.result().critical});}
  if(d&&d.key===0&&d.guardUntil>=round&&d.guardUntil>0&&!this._yunDerived&&source.isEnemy()&&value>0){var token=this._yunToken||(this._yunToken=uuid());if(d.counterToken!==token){d.counterToken=token;d.guardUntil=0;derived(target,source,S.mountain,{rate:.5});}}
  return v;
 });
 function prepareAction(a,action){
  if(!a||!action||action._yunPrepared)return;var item=action.item();if(!item)return;action._yunPrepared=true;action._yunToken=uuid();var d=data(a),id=item.id;
  if(a.isEnemy()){burst(a,true);if(a._yunPinUntil>=round&&damageAction(action)){action._yunPinWeaken=true;delete a._yunPinUntil;}}
  if(!live(a))return;
  if(a.refreshPassiveCache){a.initPassiveCache();a.refreshPassiveCache();}
  if(is(a)&&damageAction(action)&&a._yunAfterglow){action._yunGlow=1.33;a._yunAfterglow=false;}
  if(id===S.gather){var target=$gameActors._data[action._yunWakeTarget],wd=target&&data(target);if(target&&awake(target)){action._yunGatherRounds=wd.wakeUntil-round+1;wd.wakeUntil=0;}else action._yunGatherRounds=0;}
  if(d&&d.key===6&&awake(a)){var b=setting(a).borrow.filter(function(x){return x.skill===id;})[0],owner=b&&$gameActors._data[b.owner];if(owner&&members().indexOf(owner)>=0)a._yunBorrowStats={2:owner.atk,4:owner.mat};}
  if(d&&d.key===7&&id===setting(a).eye&&awake(a)&&d.needleBypassRound!==round){d.needleBypassRound=round;a.setCooldown(id,0);}
  if(d&&d.key===0&&id===S.mountain){action._yunMountainBank=d.bank;d.bank=0;d.guardUntil=round+1;}
  if(d&&d.key===2&&awake(a)&&d.debtConversion&&damageAction(action)){action._yunDebtConvert=d.debts.reduce(function(s,x){return s+x.amount;},0);action._yunDebtMastery=a.skillMasteryLevel(id);}
  if(Y._acted.indexOf(a)<0)Y._acted.push(a);
 }
 Y.prepareAction=prepareAction;
 alias(BattleManager,'startAction',function(old,args){var a=this._subject,action=a&&a.currentAction();prepareAction(a,action);if(a&&!live(a)){this._subject=null;this._phase='turn';return;}var v=old.apply(this,args);if(action&&action.item()){action._yunPrimary=this._targets&&this._targets[0];if(action.isForFriend()&&action.isForAll())Y._teamBuffApplying=true;}return v;});
 function applyCommand(action,target){
  var a=action.subject(),id=action.item().id,d=data(a);if(action._yunCommand)return;action._yunCommand=true;
  if(id===S.wind){members().forEach(function(x){x._yunWindUntil=round+1;});var q=BattleManager._actionBattlers,allies=q.filter(function(x){return x.isActor()&&Y._acted.indexOf(x)<0;}).sort(function(x,y){return y.agi-x.agi;});BattleManager._actionBattlers=allies.concat(q.filter(function(x){return allies.indexOf(x)<0;}));}
  if(id===S.wake)Y.wake(target);
  if(id===S.gift){d.gifts++;Y.addActions(target,1,'gift');}
  if(id===S.store)Y.storeActions(a);
  if(id===S.exchange){
   if(awake(a)&&d.exchangeCharge){d.exchangeCharge=false;var bad={},good={};members().forEach(function(x){x._states.forEach(function(i){if(ordinary(i,true)&&!bad[i])bad[i]=x;});});$gameTroop.aliveMembers().forEach(function(x){x._states.forEach(function(i){if(ordinary(i,false)&&!good[i]&&Object.keys(good).length<3)good[i]=x;});});Object.keys(bad).forEach(function(i){var ok=false;$gameTroop.aliveMembers().forEach(function(x){ok=stateCopy(bad[i],x,Number(i))||ok;});if(ok)members().forEach(function(x){x.removeState(Number(i));});});Object.keys(good).forEach(function(i){var ok=false;members().forEach(function(x){ok=stateCopy(good[i],x,Number(i))||ok;});if(ok)$gameTroop.aliveMembers().forEach(function(x){x.removeState(Number(i));});});
   }else{var mine=action._yunExchangeSelf,theirs=action._yunExchangeEnemy;if(mine&&a.isStateAffected(mine)&&stateCopy(a,target,mine))a.removeState(mine);if(theirs&&target.isStateAffected(theirs)&&stateCopy(target,a,theirs))target.removeState(theirs);}
  }
 }
 alias(Game_Action.prototype,'apply',function(old,args){
  if(!$gameParty.inBattle())return old.apply(this,args);
  var target=args[0],a=this.subject();if(!this._yunPrepared)prepareAction(a,this);if(!this._yunPrimary)this._yunPrimary=target;
  var v=old.apply(this,args);if(this._yunDerived||!target.result().isHit())return v;applyCommand(this,target);
  var id=this.item().id,d=data(a);
  if(is(a)&&id===S.pin){
   this._yunPlanted=this._yunPlanted||[];if(this._yunPlanted.indexOf(target)<0){this._yunPlanted.push(target);var count=ownSkill(a,S.formation)?3:ownSkill(a,S.silver)?2:1,rate=count===3?.4:count===2?.555:1,parts=ownSkill(a,S.double)?2:1;target._yunNeedles=target._yunNeedles||[];for(var i=0;i<count;i++)target._yunNeedles.push({owner:C.actor,mat:a.mat,mastery:a.skillMasteryLevel(S.pin),parts:parts,rate:rate*(parts===2?.555:1)*(target===this._yunPrimary?1:ownSkill(a,S.silver)?.77:ownSkill(a,S.double)?.66:.5),glow:this._yunGlow||1});target._yunPinUntil=round+1;}
  }
  if(is(a)&&id===S.cut&&!this._yunDispelled){this._yunDispelled=true;var allowed=target._states.filter(function(i){return ordinary(i,false);});if(allowed.length){target.removeState(allowed[0]);var team=members().slice().sort(function(x,y){return Number(awake(y))-Number(awake(x));});for(var c=0;c<team.length;c++){var bad=team[c]._states.filter(function(i){return ordinary(i,true);});if(bad.length){team[c].removeState(bad[0]);break;}}}}
  if(damageAction(this)&&awake(a)&&this._yunTotal>0&&!this._yunBurst){this._yunBurst=true;burst(target,false);}
  if(d&&damageAction(this)&&!this._yunRobeHit&&this._yunTotal>0){
   this._yunRobeHit=true;
   if(d.key===1&&d.captured.length){var enemies=awake(a)?$gameTroop.aliveMembers():[this._yunPrimary];var pending=[];d.captured.forEach(function(s){var ok=false;enemies.forEach(function(t){ok=stateCopy(a,t,s.id,s.turns)||ok;});if(awake(a)||ok){a.removeState(s.id);}else pending.push(s);});d.captured=pending;}
   if(d.key===2&&this._yunDebtConvert){var n=this._yunDebtConvert;d.debtConversion=false;repay(d,n);derived(a,this._yunPrimary,S.needle,{raw:Y.storedDamage(a,n,'debt'),kind:'debt',masteryLevel:this._yunDebtMastery});this._yunDebtConvert=0;}
   if(d.key===0&&this._yunMountainBank){derived(a,this._yunPrimary,S.mountain,{raw:Y.storedDamage(a,this._yunMountainBank,'bank'),kind:'bank'});this._yunMountainBank=0;}
  }
  if(this._yunSleeveTargets&&d&&awake(a)&&!live(target)&&target.result().hpDamage>0){var overflow=Math.max(0,target.result().hpDamage-this._yunHpBefore);$gameTroop.aliveMembers().forEach(function(t){if(overflow>0){var before=t.hp;derived(a,t,this.item().id,{damage:overflow});overflow=Math.max(0,overflow-before);}},this);}
  return v;
 });
 alias(Game_Action.prototype,'executeDamage',function(old,args){this._yunHpBefore=args[0].hp;return old.apply(this,args);});
 function finishAction(a,action){
  if(!a||!action||action._yunFinished||action._yunDerived)return;var item=action.item();if(!item)return;action._yunFinished=true;var d=data(a),id=item.id;
  if(d&&d.key===2&&damageAction(action))repay(d,(action._yunTotal||0)*.33);
  if(d&&d.key===7){var eye=setting(a).eye;if(id===eye)d.needleUsed=true;else if(d.needleUsed&&d.needleOther.length<3&&d.needleOther.indexOf(id)<0&&action.isSkill()){d.needleOther.push(id);a.setCooldown(eye,Math.max(0,a.cooldown(eye)-1));}}
  if(d&&d.key===12&&damageAction(action)&&(awake(a)||d.cloneRound!==round)){var clones=awake(a)?2:1;d.cloneRound=round;for(var n=0;n<clones;n++)(action._yunHits||[]).forEach(function(h){var t=live(h.target)?h.target:action.opponentsUnit().aliveMembers()[0];if(t){derived(a,t,id,{damage:h.value});action.item().effects.filter(function(e){return e.code===21&&ordinary(e.dataId,true)||e.code===21&&ordinary(e.dataId,false);}).forEach(function(e){if(Math.random()<e.value1)stateCopy(a,t,e.dataId);});}});}
  if(d&&d.ghost&&[S.gift,S.store].indexOf(id)<0){d.ghost--;d.ghostDone++;if(awake(a)&&d.ghostDone>=2&&!d.revived){d.revived=true;d.ghost=0;a.setHp(Math.floor(a.mhp*.5));a.setMp(Math.floor(a.mmp*.5));}else if(d.ghost<=0)endGhost(a,d);}
  delete a._yunBorrowStats;Y._teamBuffApplying=false;
 }
 Y.finishAction=finishAction;
 alias(BattleManager,'endAction',function(old,args){finishAction(this._subject,this._action);return old.apply(this,args);});
 // OTB queues contain battlers, so provenance is tracked in parallel per actor.
 Y.addActions=function(a,count,source){
  if(!live(a)||members().indexOf(a)<0)return false;
  var q=BattleManager._actionBattlers||[],pending=q.filter(function(x){return x===a;}).length,tags=Y._giftSources[a.actorId()]||(Y._giftSources[a.actorId()]=[]);
  while(tags.length<pending)tags.push('original');for(var i=0;i<count;i++){q.push(a);tags.push(source);}
  BattleManager._actionBattlers=q;if(SceneManager._scene&&BattleManager.otbDisplayWindow){var w=BattleManager.otbDisplayWindow();if(w&&w.createNewSprites)w.createNewSprites();}return true;
 };
 alias(BattleManager,'getNextSubject',function(old,args){var a=old.apply(this,args);if(a&&a.isActor()){var tags=Y._giftSources&&Y._giftSources[a.actorId()];a._yunActionSource=tags&&tags.length?tags.shift():'original';}return a;});
 Y.freeGift=function(a,target){var d=data(a);if(!d||d.key!==11||!awake(a)||d.freeGiftRound===round||d.ghost||a===target||!live(target)||members().indexOf(target)<0||(target._yunGiftReceived||0)>=2)return false;d.freeGiftRound=round;target._yunGiftReceived=2;return Y.addActions(target,2,'gift');};
 Y.storeActions=function(a){var d=data(a);if(!d||d.key!==9||d.ghost||!sourceOriginal(a))return false;var q=BattleManager._actionBattlers||[],tags=Y._giftSources[a.actorId()]||[],used=0,remaining=[],keptTags=[],idx=0;for(var i=0;i<q.length;i++){if(q[i]!==a){remaining.push(q[i]);continue;}var tag=tags[idx++]||'original';if(tag==='original'&&d.stored<3){d.stored++;used++;}else{remaining.push(a);keptTags.push(tag);}}if(d.stored<3){d.stored++;used++;}Y._giftSources[a.actorId()]=keptTags;BattleManager._actionBattlers=remaining;return used>0;};
 Y.release=function(a){var d=data(a);if(!d||d.key!==9||d.releaseRound===round||!d.stored||d.ghost)return false;var count=d.stored*(awake(a)?2:1);d.stored=0;d.releaseRound=round;return Y.addActions(a,count,'stored');};
 Y.cut=function(a,choices){var d=data(a);if(!d||d.key!==8||!choices.length)return false;var pair=awake(a),selected=choices.slice(0,pair?2:1);if(pair&&selected.length<2)selected.push([2,3,4,5,6,7].filter(function(i){return i!==selected[0];})[0]);var snap=d.cutRound===round&&d.cutSnapshot?d.cutSnapshot:{};if(d.cutRound!==round){d.cutValues=null;for(var i=2;i<8;i++)snap[i]=a.param(i);}var sum=0;for(var j=2;j<8;j++)if(selected.indexOf(j)<0)sum+=snap[j]*.33;var values={};for(var k=2;k<8;k++)values[k]=selected.indexOf(k)>=0?snap[k]+sum:pair?snap[k]:snap[k]*.67;d.cutSnapshot=snap;d.cutChoices=selected;d.cutValues=values;d.cutRound=round;d.cutAwake=pair;return true;};
 alias(Game_Action.prototype,'evaluate',function(old,args){var a=this.subject(),id=this.item().id,d=data(a),team=members();
  if(id===S.wake){var sleepers=team.filter(function(t){return live(t)&&robe(t)&&!awake(t);});if(!sleepers.length)return 0;this._targetIndex=sleepers[0].index();return 1;}
  if(id===S.wind)return a._yunWindUntil>=round?0:1.1;
  if(id===S.gather){var holders=team.filter(awake);if(!holders.length)return 0;this._yunWakeTarget=holders[0].actorId();this._yunGatherRounds=data(holders[0]).wakeUntil-round+1;}
  if(id===S.exchange){var bad=a._states.filter(function(i){return ordinary(i,true);}),enemies=$gameTroop.aliveMembers(),chosen=enemies.filter(function(t){return t._states.some(function(i){return ordinary(i,false);});})[0]||enemies[0];if(!chosen)return 0;this._targetIndex=chosen.index();this._yunExchangeSelf=bad[0]||0;this._yunExchangeEnemy=chosen._states.filter(function(i){return ordinary(i,false);})[0]||0;return (this._yunExchangeSelf||this._yunExchangeEnemy)?1:0;}
  if(id===S.gift){var allies=team.filter(function(t){return t!==a&&live(t);}).sort(function(x,y){return y.atk+y.mat-x.atk-x.mat;});if(!allies.length||allies[0].atk+allies[0].mat<=a.atk+a.mat)return 0;this._targetIndex=allies[0].index();return .8;}
  return old.apply(this,args);
 });
 // Smart AI uses native affordances without applying actions while planning.
 // The vanilla evaluate alias above remains the fallback when smart AI is off.
 function aiBattle(a){var r=robe(a),d=a&&a._yunBattle;return r&&d&&d.uid===(r._yunUid||'native:'+r.id)&&d.battle===battle?d:null;}
 function aiAwake(a){var d=aiBattle(a);return !!d&&d.wakeUntil>0&&d.wakeUntil>=round;}
 function aiGather(action){
  if(action._yunPrepared)return $gameActors._data[action._yunWakeTarget]||null;
  var holders=members().filter(function(t){return live(t)&&aiAwake(t);});
  holders.sort(function(x,y){var dx=aiBattle(x),dy=aiBattle(y);return dy.wakeUntil-dx.wakeUntil||Number(x===action.subject())-Number(y===action.subject())||x.index()-y.index();});
  var t=holders[0],d=t&&aiBattle(t);action._yunWakeTarget=t?t.actorId():0;action._yunGatherRounds=d?Math.max(0,d.wakeUntil-round+1):0;return t;
 }
 function aiAccept(from,to,id){return ordinary(id,true)||ordinary(id,false)?!!to&&to.isStateAddable(id)&&to.stateRate(id)>0:false;}
 function aiExchange(a,t){return {mine:(a._states||[]).filter(function(id){return ordinary(id,true)&&!t.isStateAffected(id)&&aiAccept(a,t,id);})[0]||0,theirs:(t._states||[]).filter(function(id){return ordinary(id,false)&&!a.isStateAffected(id)&&aiAccept(t,a,id);})[0]||0};}
 function aiOutput(a,foes){var best=0,had=Object.prototype.hasOwnProperty.call(a,'_costmp'),prior=a._costmp;try{(a.skills()||[]).concat([$dataSkills[a.attackSkillId()]]).forEach(function(s){if(!s||!s.damage||[1,5].indexOf(s.damage.type)<0||!a.canUse(s))return;var x=new Game_Action(a);x.setSkill(s.id);foes.forEach(function(t){best=Math.max(best,CodexSmartAI.safeDamage(a,t,s,x));});});return best;}finally{if(had)a._costmp=prior;else delete a._costmp;}}
 window.CodexAIEstimators=window.CodexAIEstimators||[];
 CodexAIEstimators.push(function(a,b,item,action,formula){
  if(formula!=='CodexYunshang.formula(this,a,b)'||[S.pin,S.cut,S.gather,S.mountain,S.needle].indexOf(item.id)<0)return;
  var x=action||new Game_Action(a);if(!action)x.setSkill(item.id);if(item.id===S.gather)aiGather(x);
  // Unified damage handles defense separately; the authored raw formula sees 0.
  return Y.formula(x,a,{def:0,mdf:0});
 });
 if(window.CodexSmartAI&&CodexSmartAI.registerProfile)CodexSmartAI.registerProfile(function(a,item,action){
  var id=item.id,d=aiBattle(a),cloud=is(a),offense=[1,2,5,6].indexOf(item.damage.type)>=0;
  if(!cloud&&[S.mountain,S.exchange,S.gift,S.store].indexOf(id)<0)return null;
  var p={},gather=id===S.gather?aiGather(action):null,active=aiAwake(a)&&!(gather===a),mult=1;
  if(cloud&&offense){
   if(ownSkill(a,S.double))mult*=.555;
   if(relic(a))mult*=1.99*(a._yunAfterglow?1.33:1);
   if(ownSkill(a,S.spread))p.splash=ownSkill(a,S.silver)?.77:ownSkill(a,S.double)?.66:.5;
  }
  if(offense&&d){if(d.key===12)mult*=active?3:d.cloneRound===round?1:2;if(d.key===13&&active)mult*=2;}
  p.multiplier=mult;
  if(id===S.wake){
   p.targetAllowed=function(t){return live(t)&&!!robe(t)&&!aiAwake(t);};
   p.targetUtility=function(t,c){var td=aiBattle(t);return !c.longFight?0:(c.urgent&&td&&[0,3].indexOf(td.key)>=0?12500:6500);};
  }else if(id===S.wind){
   p.targetUtility=function(t,c){if(!c.longFight||a._yunWindUntil>=round)return 0;var q=BattleManager._actionBattlers||[],firstEnemy=q.findIndex(function(x){return x.isEnemy&&x.isEnemy();});var waiting=q.some(function(x,i){return firstEnemy>=0&&i>firstEnemy&&x.isActor&&x.isActor()&&x!==a&&(Y._acted||[]).indexOf(x)<0;});return waiting?5500/Math.max(1,c.friends.filter(live).length):0;};
  }else if(id===S.exchange){
   p.targetUtility=function(t,c){var pair=aiExchange(a,t),count=Number(!!pair.mine)+Number(!!pair.theirs);if(d&&active&&d.exchangeCharge){var bad={},good={};c.friends.filter(live).forEach(function(f){(f._states||[]).forEach(function(id){if(ordinary(id,true)&&c.foes.some(function(e){return !e.isStateAffected(id)&&aiAccept(f,e,id);}))bad[id]=true;});});c.foes.forEach(function(e){(e._states||[]).forEach(function(id){if(ordinary(id,false)&&c.friends.some(function(f){return !f.isStateAffected(id)&&aiAccept(e,f,id);}))good[id]=true;});});count=Object.keys(bad).length+Math.min(3,Object.keys(good).length);}
    return count*8500*(c.longFight?1:.15);};
   p.prepareTarget=function(t){var pair=aiExchange(a,t);action._yunExchangeSelf=pair.mine;action._yunExchangeEnemy=pair.theirs;};
  }else if(id===S.gift){
   p.targetAllowed=function(t){return live(t)&&t!==a;};
   p.targetUtility=function(t,c){var mine=aiOutput(a,c.foes),theirs=aiOutput(t,c.foes);return theirs>mine?Math.min(18000,5500*theirs/Math.max(1,mine))*(c.longFight?1:.1):0;};
  }else if(id===S.store){
   // Stockpiling sacrifices the current action. Don't loop on a full reserve,
   // or defer a useful attack while a live opponent can already be hit.
   p.targetUtility=function(t,c){return d&&d.stored<3&&c.longFight&&aiOutput(a,c.foes)===0?4500:0;};
  }
  return p;
 });

 // A small native Window_Command UI provides explicit choices and cancel paths.
 function Window_YunChoices(){this.initialize.apply(this,arguments);}
 Window_YunChoices.prototype=Object.create(Window_Command.prototype);Window_YunChoices.prototype.constructor=Window_YunChoices;
 Window_YunChoices.prototype.initialize=function(){this.rows=[];this.info=[];this.titleText='';Window_Command.prototype.initialize.call(this,0,0);this.hide();this.deactivate();};
 Window_YunChoices.prototype.windowWidth=function(){return Math.min(760,Graphics.boxWidth);};
 Window_YunChoices.prototype.numVisibleRows=function(){return Math.min(12,Math.max(3,this.rows.length));};
 Window_YunChoices.prototype.infoHeight=function(){var n=(this.info||[]).length;return n?n*this.lineHeight()+12:0;};
 Window_YunChoices.prototype.windowHeight=function(){return this.fittingHeight(this.numVisibleRows())+this.infoHeight();};
 Window_YunChoices.prototype.maxPageRows=function(){return Math.max(1,Math.floor((this.height-this.padding*2-this.infoHeight())/this.itemHeight()));};
 Window_YunChoices.prototype.itemRect=function(index){var rect=Window_Command.prototype.itemRect.call(this,index);rect.y+=this.infoHeight();return rect;};
 Window_YunChoices.prototype.refresh=function(){Window_Command.prototype.refresh.call(this);var info=this.info||[],w=this.contentsWidth(),lh=this.lineHeight();if(!info.length)return;info.forEach(function(t,i){this.changeTextColor(i===0?this.systemColor():this.normalColor());this.changePaintOpacity(i<2);this.drawText(t,0,i*lh,w);},this);this.resetTextColor();this.contents.paintOpacity=72;this.contents.fillRect(0,info.length*lh+5,w,2,this.normalColor());this.changePaintOpacity(true);};
 Window_YunChoices.prototype.makeCommandList=function(){this.rows.forEach(function(r){this.addCommand(r.label,'choose',r.enabled!==false,r);},this);};
 Window_YunChoices.prototype.openRows=function(rows,ok,cancel,info){this.rows=rows;this.info=info||[];this.height=Math.min(Graphics.boxHeight,this.windowHeight());this.createContents();this.refresh();this.x=(Graphics.boxWidth-this.width)/2;this.y=(Graphics.boxHeight-this.height)/2;this.setHandler('choose',function(){var r=this.currentExt();if(r&&r.enabled!==false)ok(r);}.bind(this));this.setHandler('cancel',cancel);this.show();this.open();this.select(0);this.activate();};
 function choose(scene,rows,ok,cancel,info){if(!scene._yunChoices){scene._yunChoices=new Window_YunChoices();scene.addWindow(scene._yunChoices);}scene._yunChoices.openRows(rows,function(r){scene._yunChoices.hide();scene._yunChoices.deactivate();ok(r);},function(){scene._yunChoices.hide();scene._yunChoices.deactivate();if(cancel)cancel();},info);}
 function Scene_Yunshang(){this.initialize.apply(this,arguments);}
 Scene_Yunshang.prototype=Object.create(Scene_MenuBase.prototype);Scene_Yunshang.prototype.constructor=Scene_Yunshang;
 Scene_Yunshang.prototype.create=function(){Scene_MenuBase.prototype.create.call(this);this.home();};
 Scene_Yunshang.prototype.home=function(){
  var self=this,p=profile(),a=$gameActors.actor(C.actor),order=p.order,info=['天衣铺　云裳 '+a.level+'级　进阶'+stage(a)+'/2　不朽天丝 '+$gameParty.numItems($dataItems[C.silk]),order?'制作中：'+order.spec.name+'　'+order.progress+'/10回合':'当前没有制作订单','制作池按等级与进阶开放（35级起可制作）','属性与词条开工时确定，领取或读档不重抽'],rows=[{label:'制作天衣　不朽天丝×15',run:function(){Y.submit();self.home();},enabled:a.level>=35&&!order},{label:'领取已完成的天衣',run:function(){Y.claim();self.home();},enabled:!!order&&order.progress>=10},{label:'角色进阶',run:function(){SceneManager.push(Scene_ActorAdvanced);},enabled:stage(a)<2&&a.level>=C.advance[stage(a)].level},{label:'配置天衣神纹',run:function(){self.configActor();}},{label:'返回',run:function(){self.popScene();}}];
  choose(self,rows,function(r){try{r.run();}catch(e){notify(e.message);self.home();}},function(){self.popScene();},info);
 };
 Scene_Yunshang.prototype.configActor=function(){var self=this;choose(self,$gameParty.allMembers().filter(robe).map(function(a){return {label:a.name()+'｜'+robe(a).name,actor:a};}),function(r){self.configure(r.actor);},function(){self.home();});};
 Scene_Yunshang.prototype.configure=function(a){var self=this,k=key(a),set=setting(a);if(k===6){var pool=[];$gameParty.allMembers().forEach(function(owner){owner.skills().filter(Y.borrowable).forEach(function(s){pool.push({label:owner.name()+'：'+s.name,owner:owner.actorId(),skill:s.id});});});var chosen=[];function pick(){choose(self,pool.filter(function(r){return !chosen.some(function(c){return c.skill===r.skill;});}),function(r){chosen.push({owner:r.owner,skill:r.skill});if(chosen.length===3){set.borrow=chosen;self.home();}else pick();},function(){self.home();},['选择借用技能 '+chosen.length+'/3（首个为常驻）']);}pick();return;}
  if(k===7){choose(self,a.skills().filter(function(s){return s.id<S.mountain&&s.cooldown&&s.occasion!==3&&!/唤醒|复活|制作|进阶/.test(s.name);}).map(function(s){return {label:s.name,skill:s.id};}),function(r){set.eye=r.skill;self.home();},function(){self.home();});return;}
  if(k===14){var chosen=[];function pickElement(){choose(self,$dataSystem.elements.map(function(n,i){return {label:n,id:i};}).filter(function(r){return r.id>=2&&r.id!==10&&r.label&&chosen.indexOf(r.id)<0;}),function(r){chosen.push(r.id);if(chosen.length===3){set.elements=chosen;set.element=chosen[0];self.home();}else pickElement();},function(){self.home();});}pickElement();return;}
  notify('这件天衣无需战前配置');self.home();
 };
 alias(Window_ActorCommand.prototype,'makeCommandList',function(old,args){var v=old.apply(this,args),a=this._actor,d=data(a);if(d){if(d.key===11&&awake(a))this.addCommand('神纹赠行（免费）','yunGift',d.freeGiftRound!==round&&!d.ghost);if(d.key===9)this.addCommand('释放余光','yunRelease',d.stored>0&&d.releaseRound!==round&&!d.ghost);if(d.key===8)this.addCommand('六衡裁身','yunCut',d.cutRound!==round);if(d.key===5)this.addCommand(a._yunSleeve?'收袖：开启':'收袖：关闭','yunSleeve',true);if(d.key===14)this.addCommand('选择七曜元素','yunElement',a._yunElementChosenRound!==round);}return v;});
 alias(Scene_Battle.prototype,'createActorCommandWindow',function(old,args){var v=old.apply(this,args),self=this,w=this._actorCommandWindow;w.setHandler('yunSleeve',function(){var a=BattleManager.actor();a._yunSleeve=!a._yunSleeve;w.setup(a);});w.setHandler('yunRelease',function(){Y.release(BattleManager.actor());w.setup(BattleManager.actor());});w.setHandler('yunGift',function(){var a=BattleManager.actor();choose(self,members().filter(function(t){return t!==a&&live(t);}).map(function(t){return {label:t.name(),target:t,enabled:(t._yunGiftReceived||0)<2};}),function(r){Y.freeGift(a,r.target);w.setup(a);},function(){w.activate();});});w.setHandler('yunCut',function(){var a=BattleManager.actor(),chosen=[];function next(){choose(self,[2,4,3,5,6,7].filter(function(i){return chosen.indexOf(i)<0;}).map(function(i){return {label:TextManager.param(i),id:i};}),function(r){chosen.push(r.id);if(awake(a)&&chosen.length<2)next();else{Y.cut(a,chosen);w.setup(a);}},function(){w.activate();});}next();});w.setHandler('yunElement',function(){var a=BattleManager.actor();choose(self,setting(a).elements.map(function(e){return {label:$dataSystem.elements[e],element:e};}),function(r){setting(a).element=r.element;a._yunElementChosenRound=round;w.setup(a);},function(){w.activate();});});return v;});
 alias(Scene_Battle.prototype,'onSkillOk',function(old,args){var self=this,skill=this._skillWindow.item(),a=BattleManager.actor(),action=BattleManager.inputtingAction();action._yunSleeve=!!a._yunSleeve;function proceed(){old.apply(self,args);}if(skill.id===S.gather){this._skillWindow.deactivate();choose(self,members().filter(awake).map(function(t){return {label:t.name(),target:t};}),function(r){action._yunWakeTarget=r.target.actorId();proceed();},function(){self._skillWindow.activate();});return;}
  if(skill.id===S.exchange&&!awake(a)){this._skillWindow.deactivate();var rows=[{label:'不选自身状态',id:0}].concat(a._states.filter(function(i){return ordinary(i,true)||ordinary(i,false);}).map(function(i){return {label:$dataStates[i].name,id:i};}));choose(self,rows,function(r){action._yunExchangeSelf=r.id;proceed();},function(){self._skillWindow.activate();});return;}return proceed();});
 alias(Scene_Battle.prototype,'onEnemyOk',function(old,args){var self=this,action=BattleManager.inputtingAction(),target=$gameTroop.members()[this._enemyWindow.enemyIndex()];if(action.item().id===S.exchange&&!awake(action.subject())&&!action._yunExchangePicked){action._yunExchangePicked=true;this._enemyWindow.deactivate();choose(self,[{label:'不选敌方状态',id:0}].concat(target._states.filter(function(i){return ordinary(i,true)||ordinary(i,false);}).map(function(i){return {label:$dataStates[i].name,id:i};})),function(r){action._yunExchangeEnemy=r.id;old.apply(self,args);},function(){delete action._yunExchangePicked;self._enemyWindow.activate();});return;}return old.apply(this,args);});
 alias(Scene_Battle.prototype,'onActorOk',function(old,args){var action=BattleManager.inputtingAction(),target=members()[this._actorWindow.index()],id=action.item().id;if(id===S.wake&&(!target||!robe(target))||id===S.gift&&target===action.subject()){SoundManager.playBuzzer();this._actorWindow.activate();return;}return old.apply(this,args);});
 // Automatic combat: select useful deterministic options, no free-action recursion.
 alias(Game_Actor.prototype,'makeAutoBattleActions',function(old,args){var v=old.apply(this,args),a=this,d=data(a);if(!d)return v;if(d.key===11&&awake(a)){var targets=members().filter(function(t){return t!==a&&live(t)&&(t._yunGiftReceived||0)<2;}).sort(function(x,y){return y.atk+y.mat-x.atk-x.mat;});if(targets.length)Y.freeGift(a,targets[0]);}if(d.key===9)Y.release(a);if(d.key===8&&d.cutRound!==round)Y.cut(a,a.mat>=a.atk?[4,6]:[2,6]);if(d.key===5)a._yunSleeve=true;(a._actions||[]).forEach(function(action){if(action.item().id===S.gather)aiGather(action);action._yunSleeve=!!a._yunSleeve;});return v;});
 // Keep the native learned-skill list authoritative; previewing the book never awards future skills.
 alias(Game_Actor.prototype,'learnSkill',function(old,args){if(is(this)&&C.gates[args[0]]&&!unlocked(this,args[0]))return;return old.apply(this,args);});
 alias(Game_Actor.prototype,'levelDown',function(old,args){var v=old.apply(this,args);Y.sync(this);return v;});
 alias(Game_Actor.prototype,'addedSkillTypes',function(old,args){return is(this)?[2,1,5,4]:old.apply(this,args);});
 alias(Game_Actor.prototype,'addedSkillTypesForMenu',function(old,args){return is(this)?[2,1,5,4]:old?old.apply(this,args):this.addedSkillTypes();});
 alias(Window_ActorCommand.prototype,'addSkillCommands',function(old,args){if(!is(this._actor))return old.apply(this,args);var w=this;[2,1,5].forEach(function(id){w.addCommand($dataSystem.skillTypes[id],'skill',true,id);});});
 // Existing quality renderer receives the authored atlas, avoiding DreamX's dynamic overlay range.
 if(window.CodexQualityIcons){
  var lookup=CodexQualityIcons.lookup;
 }
 Y.availableRobes=owned;
 Y.choose=choose;
 Y.openCrafting=function(){var a=$gameActors._data[C.actor];if($gameParty.inBattle()||!a||$gameParty._actors.indexOf(C.actor)<0||a.level<20){notify('云裳达到20级后，可在战斗外使用天衣铺');return;}SceneManager.push(Scene_Yunshang);};
 Y.profileIdentity=function(){profile();return $gameSystem._yunProfile;};
 Y.reloadJournal=function(){ledger=null;return loadLedger();};
 // 【Codex·未经Claude检验】v0.27: recruit rollback restores only this save's profile; other profiles are preserved.
 Y.recruitCheckpoint=function(){var p=profile();return {id:$gameSystem._yunProfile,profile:copy(p),legacyIdentity:legacyIdentity};};
 Y.restoreRecruitCheckpoint=function(checkpoint){if(!checkpoint||!checkpoint.id)throw Error('云裳招募检查点缺失');var next=copy(loadLedger());next.profiles[checkpoint.id]=copy(checkpoint.profile);saveLedger(next);legacyIdentity=checkpoint.legacyIdentity;};
 Y.advanceRequirements=function(a){var req=C.advance[stage(a)];if(!req)return '已完成两次进阶';if(a.level<req.level)return '等级不足：需要'+req.level+'级';if($gameParty.numItems($dataItems[C.shard])<req.shards)return '人道意志碎片不足：需要'+req.shards+'份';if(owned().length<req.robes)return '背包天衣不足：需要'+req.robes+'件（已装备天衣须先卸下）';return '';};
 if(typeof Scene_ActorAdvanced!=='undefined'){
  alias(Scene_ActorAdvanced.prototype,'onBottomConfirmOk',function(old,args){
   var scene=this,a=$gameParty.members()[this._indexWindow.index()];
   if(!is(a))return old.apply(this,args);
   var reason=Y.advanceRequirements(a);this._BottomconfirmWindow.deactivate();this._BottomconfirmWindow.close();
   if(reason){SoundManager.playBuzzer();notify(reason);this._indexWindow.activate();return;}
   var required=C.advance[stage(a)].robes,selected=[];this._indexWindow.deactivate();
   function pick(){
    if(selected.length===required){scene._yunAdvanceSelection={actor:a,stage:stage(a),items:selected.slice()};scene._windowIdx=scene._indexWindow.index();scene.startConfirmWindow('消耗'+required+'件天衣，确认进阶');return;}
    choose(scene,[{label:'选择进阶所需天衣 '+selected.length+'/'+required,enabled:false}].concat(owned().filter(function(i){return selected.indexOf(i)<0;}).map(function(i){return{label:Y.robeLabel(i),item:i};})),function(r){selected.push(r.item);pick();},function(){delete scene._yunAdvanceSelection;scene._indexWindow.activate();});
   }pick();
  });
  alias(Scene_ActorAdvanced.prototype,'onConfirmOk',function(old,args){
   var a=$gameParty.members()[this._windowIdx];if(!is(a))return old.apply(this,args);
   var selection=this._yunAdvanceSelection;delete this._yunAdvanceSelection;
   try{if(!selection||selection.actor!==a||selection.stage!==stage(a))throw Error('进阶选择已失效，请重新选择');Y.advance(selection.items);}
   catch(e){SoundManager.playBuzzer();notify(e.message);}
   this._confirmWindow.deactivate();this._confirmWindow.close();this._indexWindow.activate();this._goldWindow.setupWhenCheck();this._statusWindow.setupWhenCheck(a);
  });
  ['onConfirmCancel','onBottomConfirmCancel'].forEach(function(name){alias(Scene_ActorAdvanced.prototype,name,function(old,args){delete this._yunAdvanceSelection;return old.apply(this,args);});});
  alias(Window_ActorAdvancedStatus.prototype,'drawAllContents',function(old,args){var v=old.apply(this,args),a=args[4];this._yunPreviewActor=a;if(is(a)&&C.advance[stage(a)]){this.contents.fontSize=18;var y=(args[1]||0)+this.lineHeight()*12,w=this.contentsWidth()/2;this.drawText('背包天衣×'+C.advance[stage(a)].robes+'（确认时选择）',args[0]||0,y,w);this.drawText('已装备的天衣须先卸下',args[0]||0,y+this.lineHeight(),w);this.resetFontSettings();}return v;});
  alias(Window_ActorAdvancedStatus.prototype,'update',function(old,args){var v=old.apply(this,args);if(is(this._yunPreviewActor)&&this._Sprite&&window.CodexSV){var p=CodexSV.profiles.Yunshang;if(p)this._Sprite.scale.set(CodexSV.scaleFor(p));}return v;});
 }
 // An optional journal failure blocks only crafting/reward actions, never the player's ordinary load.
 var craftingHome=Scene_Yunshang.prototype.home;
 Scene_Yunshang.prototype.home=function(){try{return craftingHome.apply(this,arguments);}catch(e){var self=this;choose(this,[{label:'制作记录暂不可用，请恢复配套记录后重试',enabled:false},{label:'返回',run:true}],function(){self.popScene();},function(){self.popScene();});}};
 var database=DataManager.isDatabaseLoaded;
 DataManager.isDatabaseLoaded=function(){var ready=database.apply(this,arguments);if(ready&&!Y._checked){if(!$dataActors[C.actor]||$dataActors[C.actor].name!=='云裳'||!$dataClasses[C.class]||!$dataSkills[S.pin]||DataManager._baseArmorsLength!==8001)throw Error('云裳数据与测试模块不匹配');Y._checked=true;}return ready;};


 var legacyYunshangAps={"7920":["<pos=APs text=等级需求：35 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：山河击MP99，以888.88×双防系数攻击；守势反击一 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=次，基础伤害50% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：全队合计分担队友伤害33%；蓄势最多最大生命300%；下 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=次山河击附加蓄势×188.88 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳35级，无进阶要求 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：全队合计分担队友伤害33%；蓄势最多最大生命300%；下次山河击附加蓄势×188.88 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：山河击MP99，以888.88×有效双防攻击；守势反击一次，基础伤害50% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7921":["<pos=APs text=等级需求：35 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：收录最多3种普通减益；下一次主动伤害命中后尝试转给主目标 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=，保留持续时间 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：获得减益时立即净化并收录，最多6种；下一次命中尝试施加全 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=体敌人 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳35级，无进阶要求 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：获得减益时立即净化并收录，最多6种；下一次命中尝试施加全体敌人 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：收录最多3种普通减益；下一次主动伤害命中后尝试转给主目标，保留持续时间 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7922":["<pos=APs text=等级需求：35 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：50%承伤记为伤债，上限最大生命200%；主动伤害的33 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=%还债，到期扣未还部分 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：下一次主动命中将当前伤债×188.88转为附加魔法伤害； size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=每次唤醒限一次；战后仍结清伤债 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳35级，无进阶要求 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：下一次主动命中将当前伤债×188.88转为附加魔法伤害；每次唤醒限一次；战后仍结清伤债 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：50%承伤记为伤债，上限最大生命200%；主动伤害的33%还债，到期扣未还部分 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7923":["<pos=APs text=等级需求：40 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：每场首次倒下暂留衣魂，最多完成2次真实行动，费用与技能条 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=件保留 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：每场一次，衣魂完成2次有效行动后恢复50%生命及MP；赠 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=行、存行和等待不计 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳40级，完成第1次进阶 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：每场一次，衣魂完成2次有效行动后恢复50%生命及MP；赠行、存行和等待不计 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：每场首次倒下暂留衣魂，最多完成2次真实行动，费用与技能条件保留 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7924":["<pos=APs text=等级需求：40 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：换锦MP99、冷却3；交换自身与一敌的各一个普通状态，保 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=留剩余时间 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：每次唤醒限一次，全队减益向全敌转移，夺取最多3种普通增益 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=给全队，仍需原费用 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳40级，完成第1次进阶 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：每次唤醒限一次，全队减益向全敌转移，夺取最多3种普通增益给全队，仍需原费用 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：换锦MP99、冷却3；交换自身与一敌的各一个普通状态，保留剩余时间 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7925":["<pos=APs text=等级需求：40 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：收袖将群攻对各目标分别计算的伤害集中到主目标，保留原段数 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：击杀后的溢出伤害依次传递给其他存活敌人，不重复状态和派生 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=机制 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳40级，完成第1次进阶 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：击杀后的溢出伤害依次传递给其他存活敌人，不重复状态和派生机制 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7926":["<pos=APs text=等级需求：45 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：战前预选3个普通技能，首个可用；原拥有者须出场；保留原费 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=用、条件与冷却 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：开放全部3个；每次施放双攻分别与原拥有者取高，不复制其其 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=他属性、装备或被动 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳45级，完成第1次进阶 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：开放全部3个；每次施放双攻分别与原拥有者取高，不复制其其他属性、装备或被动 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：战前预选3个普通技能，首个可用；原拥有者须出场；保留原费用、条件与冷却 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7927":["<pos=APs text=等级需求：45 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：战前选有冷却的针眼技能；施放后用不同主动技能缩短冷却，每 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=回合最多3次 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：首次唤醒清零针眼冷却；每回合首次主动针眼可越过冷却，正常 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=产生新冷却与费用 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳45级，完成第1次进阶 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：首次唤醒清零针眼冷却；每回合首次主动针眼可越过冷却，正常产生新冷却与费用 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：战前选有冷却的针眼技能；施放后用不同主动技能缩短冷却，每回合最多3次 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7928":["<pos=APs text=等级需求：45 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：每回合行动前选一项六维属性，裁入其余五项各33%，其余相 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=应降低 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：改选两项，各获得其余四项之和33%；其余保持；按原快照计 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=算，回合末清除 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳45级，完成第1次进阶 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：改选两项，各获得其余四项之和33%；其余保持；按原快照计算，回合末清除 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：每回合行动前选一项六维属性，裁入其余五项各33%，其余相应降低 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7929":["<pos=APs text=等级需求：50 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：结束并收存本回合未用的原有行动，最多3次；每回合可释放一 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=次 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：每份储存释放为2次行动，每回合开始额外存1份；受赠和储存 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=行动不能再存或再赠 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳50级，完成第2次进阶 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：每份储存释放为2次行动，每回合开始额外存1份；受赠和储存行动不能再存或再赠 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：结束并收存本回合未用的原有行动，最多3次；每回合可释放一次 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7930":["<pos=APs text=等级需求：50 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：每回合一次，把自身获得的普通个人增益共享给出场队友，保留 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=持续时间 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：全队共同最多传播3种原始个人增益事件；禁止传播链和专属机 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制共享 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳50级，完成第2次进阶 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：全队共同最多传播3种原始个人增益事件；禁止传播链和专属机制共享 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：每回合一次，把自身获得的普通个人增益共享给出场队友，保留持续时间 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7931":["<pos=APs text=等级需求：50 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：消耗一次原有行动，赠队友一次行动，每回合最多3次；受赠与 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=储存行动不能转赠 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：每回合免费赠队友2次行动；全队同一接收者最多2次；仍需其 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=原资源与技能条件 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳50级，完成第2次进阶 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：每回合免费赠队友2次行动；全队同一接收者最多2次；仍需其原资源与技能条件 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：消耗一次原有行动，赠队友一次行动，每回合最多3次；受赠与储存行动不能转赠 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7932":["<pos=APs text=等级需求：55 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：每回合首次主动伤害复演一次，各100%伤害；只复制允许的 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=普通状态 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：每次主动伤害复演两次，各100%；不再叠加常驻幻身，不重 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=建符针或角色专属机制 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳55级，完成第2次进阶 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：每次主动伤害复演两次，各100%；不再叠加常驻幻身，不重建符针或角色专属机制 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：每回合首次主动伤害复演一次，各100%伤害；只复制允许的普通状态 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7933":["<pos=APs text=等级需求：55 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：双攻、物魔加伤与穿透各取较高值，不相加 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：主动伤害分物理/魔法两路，各依对应防御抗性结算；状态、资 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=源和符针仍只执行一次 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳55级，完成第2次进阶 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：主动伤害分物理/魔法两路，各依对应防御抗性结算；状态、资源和符针仍只执行一次 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7934":["<pos=APs text=等级需求：55 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=品质：超·神器 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性与原生词条在开工时锁定；领取和读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：战前选3种合法非物理元素，战斗中每回合选其一，替换原伤害 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=元素组 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：3元素各按100%基础伤害独立结算；状态与资源一次；不重 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=复展开派生伤害 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=随机属性在开工时确定，领取或读档不重抽 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=制作条件：云裳55级，完成第2次进阶 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=唤醒：3元素各按100%基础伤害独立结算；状态与资源一次；不重复展开派生伤害 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=常驻：战前选3种合法非物理元素，战斗中每回合选其一，替换原伤害元素组 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=类别：天衣 size=18 color=rgba(255,255,255,1) line=false align=0>"],"7935":["<pos=APs text=专属：云裳 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=等级需求：1 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=基础固定属性：无；属性由原生法宝等级成长提供 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=每级成长：生命/MP/物攻/物防/魔防/幸运+18，魔攻/速度 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=+51 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=生命、魔攻、速度×1.33；技能伤害+99%；暴击率+300% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=；终伤+300% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=成功唤醒后，下次主动伤害技能+33%；等级上限888 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=重复刷新唤醒不重复获得余辉 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=成功唤醒后，下一次主动伤害技能提高33% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=终伤增加300% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=技能伤害提高99%；暴击率增加300% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=生命、魔攻、敏捷提高33% size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=基础固定属性：无；属性成长随法宝等级提高 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=每级成长：魔攻、敏捷+51 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=每级成长：生命、MP、物攻、物防、魔防、幸运+18 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=等级需求：1；法宝等级上限：888 size=18 color=rgba(255,255,255,1) line=false align=0>","<pos=APs text=专属角色：云裳 size=18 color=rgba(255,255,255,1) line=false align=0>"]};
 // A menu-only native passive opens the shop through a native common event.
 var iconSources=[0,1,2,3,4,5,6,7,8,9,10,11,11,1,10,6,0,3];
 if(window.CodexQualityIcons){
  var yunIconLookup=CodexQualityIcons.lookup;
  CodexQualityIcons.lookup=function(index,w){
   var id=index-120000,item=$dataSkills&&$dataSkills[id];
   if(item&&id>=10270&&id<=10287)return{item:item,image:'Yunshang_Icons',source:iconSources[id-10270],skill:false};
   if(index===210012)return{item:$dataItems[C.horn],image:'Yunshang_Icons',source:12,skill:false};
   if(index===210013)return{item:$dataArmors[C.relic],image:'Yunshang_Icons',source:13,skill:false};
   if(index===210014)return{item:$dataItems[C.silk],image:'Yunshang_Icons',source:10,skill:false};
   return yunIconLookup.apply(this,arguments);
  };
  alias(Window_Base.prototype,'drawIcon',function(old,args){if(args[0]>=210012&&args[0]<=210014&&CodexQualityIcons.draw(this,args[0],args[1],args[2],32))return;return old.apply(this,args);});
 }
 // Reuse native property colors, equipment windows and HelpExtend ordering.
 function yunRelicItem(item){return !!item&&DataManager.isArmor(item)&&base(item)===C.relic;}
 Y.relicDisplayParams=function(item){
  var level=Number(item.level)||1,growth=item.paramPlusPerLevel;
  if(!Array.isArray(growth))return item.params.slice();
  return item.params.map(function(value,index){return Number(value||0)+level*Number(growth[index]||0);});
 };
 function yunRelicView(item){var view=Object.create(item);view.params=Y.relicDisplayParams(item);return view;}
 Y.relicNextLevelExp=function(item){
  // The native experience helper can cache its formula; keep that write on a view.
  var view=Object.create(item),equip=new Game_Item();equip.setObject(item);equip.object=function(){return view;};
  return equip.nextLevelExp();
 };
 alias(RJO.HE,'getEquipBaseDescParams',function(old,args){
  if(!yunRelicItem(args[0]))return old.apply(this,args);
  return old.call(this,yunRelicView(args[0]),args[1]);
 });
 if(typeof Window_ItemStatus!=='undefined')alias(Window_ItemStatus.prototype,'drawEquipInfo',function(old,args){
  return old.call(this,yunRelicItem(args[0])?yunRelicView(args[0]):args[0]);
 });
 if(typeof Window_ShopInfo!=='undefined')alias(Window_ShopInfo.prototype,'drawEquipInfo',function(old,args){
  return old.call(this,yunRelicItem(args[0])?yunRelicView(args[0]):args[0]);
 });
 var nativeYunEquipDesc=RJO.HE.getDescParams;
 RJO.HE.getDescParams=function(item,type){
  var result=nativeYunEquipDesc.apply(this,arguments);
  if(yunRelicItem(item)&&type===2&&Array.isArray(item.paramPlusPerLevel)){
   var level=Number(item.level)||1,max=Number(item.maxLevel)||888,exp=Number(item.exp)||0;
   var rows=['当前等级：'+level+' / '+max,'法宝经验：'+exp+(level>=max?'（已满级）':' / '+Y.relicNextLevelExp(item))];
   var at=item.descParams.findIndex(function(row){return row[0]==='等级需求：1';});
   item.descParams.splice.apply(item.descParams,[at<0?item.pos[3]:at+1,0].concat(rows.map(function(text){return [text,RJO.HE.ItemDescOtherSize,RJO.HE.ItemDescNormalColor,false,0];})));
  }
  return result;
 };

 legacyYunshangAps[C.relic]=legacyYunshangAps[C.relic].concat(["<pos=APs text=重复刷新唤醒不重复获得余辉 size=18 color=rgba(255,255,255,1) line=false align=0>", "<pos=APs text=成功唤醒后，下一次主动伤害技能提高33% size=18 color=rgba(255,255,255,1) line=false align=0>", "<pos=APs text=终伤增加300% size=18 color=rgba(255,255,255,1) line=false align=0>", "<pos=APs text=技能伤害提高99%；暴击率增加300% size=18 color=rgba(255,255,255,1) line=false align=0>", "<pos=APs text=生命、魔攻、敏捷提高33% size=18 color=rgba(255,255,255,1) line=false align=0>", "<pos=APs text=每级成长：魔攻、敏捷+51 size=18 color=rgba(255,255,255,1) line=false align=0>", "<pos=APs text=每级成长：生命、MP、物攻、物防、魔防、幸运+18 size=18 color=rgba(255,255,255,1) line=false align=0>", "<pos=APs text=等级需求：1；法宝等级上限：888 size=18 color=rgba(255,255,255,1) line=false align=0>", "<pos=APs text=专属角色：云裳 size=18 color=rgba(255,255,255,1) line=false align=0>"]);
 var yunTextCache=new WeakMap();
 function refreshYunshangText(item){
  var id=base(item);if(!item||id<7920||id>7935||yunTextCache.has(item))return item;
  var template=$dataArmors[id];if(!template)return item;
  var old=legacyYunshangAps[id]||[],lines=String(item.note||'').replace(/<YunshangGrowthHelp>[\s\S]*?<\/YunshangGrowthHelp>\s*/g,'').trimEnd().split(/\r?\n/);
  var wanted=String(template.note||'').split(/\r?\n/).filter(function(s){return s.indexOf('<pos=APs ')===0;});
  lines=lines.filter(function(s){return old.indexOf(s)<0&&wanted.indexOf(s)<0;});
  item.note=lines.concat(wanted).join('\n');item.description=template.description;item.iconIndex=template.iconIndex;
  item.note=item.note.replace(/<ici:\s*\d+>/gi,'<ici:'+(id===7935?9:12)+'>');
  DataManager.extractMetadata(item);if(RJO.HE)RJO.HE.getDescParams(item,2);
  yunTextCache.set(item,true);return item;
 }
 Y.refreshItemText=refreshYunshangText;
 Y.robeLabel=function(item){var list=owned(),number=list.indexOf(item)+1;return item.name+'　编号'+number;};
 alias(DataManager,'extractSaveContents',function(old,args){
  var v=old.apply(this,args);(DataManager._independentArmors||[]).forEach(refreshYunshangText);Y.sync($gameActors._data[C.actor]);return v;
 });
 alias(Sprite_ItemHelp.prototype,'setItem',function(old,args){
  var i=args[0];if(i&&DataManager.isArmor(i)){refreshYunshangText(i);if(base(i)===C.relic)RJO.HE.getDescParams(i,2);}
  return old.apply(this,args);
 });

 // Fifteen robes share a unique visual palette while retaining quality 12.
 Y.robeColor='rgba(255,169,202,1)';
 Y.isRobeItem=function(item){var id=base(item);return !!item&&id>=7920&&id<7935;};
 ['normalcolor','namecolor'].forEach(function(name){
  var nativeColor=RJO.HE[name];RJO.HE[name]=function(item){return Y.isRobeItem(item)?Y.robeColor:nativeColor.apply(this,arguments);};
 });
 [Window_Base,Window_ItemList].forEach(function(Type){
 if(Type!==Window_Base&&!Object.prototype.hasOwnProperty.call(Type.prototype,'drawItemName'))return;
 alias(Type.prototype,'drawItemName',function(old,args){
  var item=args[0];if(!Y.isRobeItem(item))return old.apply(this,args);
  var previous=this._codexQualityItem,hadColor=Object.prototype.hasOwnProperty.call(this,'itemColor'),nativeColor=this.itemColor;
  this._codexQualityItem=item;this.itemColor=function(){return Y.robeColor;};
  try{var result=old.apply(this,args);if(RJO.IQ.DrawOutline>=0)this.drawOutline(args[1]+2,args[2]+2,32,32,Y.robeColor,RJO.IQ.DrawOutline);return result;}
  finally{this._codexQualityItem=previous;if(hadColor)this.itemColor=nativeColor;else delete this.itemColor;}
 });
 });
 alias(Sprite_ItemHelp.prototype,'standardLineColor',function(old,args){return Y.isRobeItem(this.item)?Y.robeColor:old.apply(this,args);});
 var robeSkin=null;
 function coloredRobeSkin(){
  if(robeSkin)return robeSkin;
  var source=ImageManager.loadSystem('Window12');if(!source.isReady())return null;
  var skin=new Bitmap(source.width,source.height),pixels=source._context.getImageData(0,0,source.width,source.height),d=pixels.data;
  for(var p=0;p<d.length;p+=4){if(!d[p+3])continue;var light=(d[p]*.2126+d[p+1]*.7152+d[p+2]*.0722)/255,shade=.18+.82*light;d[p]=Math.round(255*shade);d[p+1]=Math.round(169*shade);d[p+2]=Math.round(202*shade);}
  skin._context.putImageData(pixels,0,0);skin._setDirty();robeSkin=skin;return skin;
 }
 alias(Sprite_ItemHelp.prototype,'drawBackground',function(old,args){
  var result=old.apply(this,args);if(!Y.isRobeItem(this.item))return result;
  var windows=(this._glowWindows||[]).slice();
  function applySkin(){var skin=coloredRobeSkin();if(skin)windows.forEach(function(w){w.windowskin=skin;});}
  var source=ImageManager.loadSystem('Window12');if(source.isReady())applySkin();else source.addLoadListener(applySkin);
  return result;
 });
 if(window.CodexQualityIcons){
  var robeIconLookup=CodexQualityIcons.lookup,robeIconBitmap=CodexQualityIcons.bitmap,robeIconCache={};
  CodexQualityIcons.lookup=function(index,w){
   var item=w&&(w._codexQualityItem||w._item);
   if(Y.isRobeItem(item)&&item.iconIndex===index)return{item:item,image:'IconSet',source:index,robeColor:Y.robeColor};
   return robeIconLookup.apply(this,arguments);
  };
  CodexQualityIcons.bitmap=function(info,again){
   if(!info.robeColor)return robeIconBitmap.apply(this,arguments);
   var key=info.source+':'+info.robeColor;if(robeIconCache[key])return robeIconCache[key];
   var source=ImageManager.loadSystem('IconSet');if(!source.isReady()){source.addLoadListener(again);return null;}
   var bitmap=new Bitmap(32,32),pixels=source._context.getImageData(info.source%16*32,Math.floor(info.source/16)*32,32,32),d=pixels.data,rgb=[255,169,202];
   for(var p=0;p<d.length;p+=4){if(!d[p+3])continue;var light=(d[p]*.2126+d[p+1]*.7152+d[p+2]*.0722)/255,shade=.18+.82*light,white=Math.max(0,(light-.76)/.24)*.75;for(var n=0;n<3;n++)d[p+n]=Math.round(rgb[n]*shade*(1-white)+255*white);}
   bitmap._context.putImageData(pixels,0,0);bitmap._setDirty();robeIconCache[key]=bitmap;return bitmap;
  };
 }

 // New native-resolution artwork: preserve original color and silhouette.
 Y.iconAtlas='Yunshang_Icons_HD_v1';
 var hdLookup=CodexQualityIcons.lookup,hdBitmap=CodexQualityIcons.bitmap,hdDraw=CodexQualityIcons.draw,hdCache={};
 Y.iconInfo=function(index,w){
  var skill=index-120000,slot,item,current=w&&(w._codexQualityItem||w._item);
  if(skill>=10270&&skill<=10287){slot=skill-10270;item=$dataSkills[skill];}
  else if(index>=210118&&index<=210135){slot=index-210100;item=current&&current.iconIndex===index?current:slot<=33?$dataArmors[7920+slot-18]:$dataItems[2941+slot-34];}
  else return null;
   return{item:item,image:Y.iconAtlas,source:slot,skill:skill>=10270&&skill<=10287,yunHD:true,color:Y.isRobeItem(item)?Y.robeColor:RJO.IQ.QualitiesColor[Number(item.meta.quality)||0]};
 };
 CodexQualityIcons.lookup=function(index,w){return Y.iconInfo(index,w)||hdLookup.apply(this,arguments);};
 CodexQualityIcons.bitmap=function(info,again){
  if(!info.yunHD)return hdBitmap.apply(this,arguments);
  var key=info.source+':'+info.color;if(hdCache[key])return hdCache[key];
  var source=ImageManager.loadSystem(Y.iconAtlas);if(!source.isReady()){source.addLoadListener(again||function(){});return null;}
  var cell=source.width/6,bitmap=new Bitmap(128,128),ctx=bitmap._context;
  ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';
  bitmap.blt(source,info.source%6*cell,Math.floor(info.source/6)*cell,cell,cell,8,8,112,112);
  bitmap._setDirty();hdCache[key]=bitmap;return bitmap;
 };
 CodexQualityIcons.draw=function(w,index,x,y,size,again){
  var info=Y.iconInfo(index,w);if(!info)return hdDraw.apply(this,arguments);
  var contents=w.contents,bitmap=CodexQualityIcons.bitmap(info,again||function(){if(w.contents===contents)w.drawIcon(index,x,y);});
  if(bitmap){var ctx=contents._context,smooth=ctx.imageSmoothingEnabled,quality=ctx.imageSmoothingQuality;ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';try{contents.blt(bitmap,0,0,bitmap.width,bitmap.height,x,y,size,size);}finally{ctx.imageSmoothingEnabled=smooth;ctx.imageSmoothingQuality=quality;}}
  return true;
 };
 // Side-view status icons also retain full artwork rather than cropping 32px.
 alias(Sprite_StateIcon.prototype,'updateFrame',function(old,args){
  if(this._codexYunHDBase){this.bitmap=this._codexYunHDBase.bitmap;this.scale.set(this._codexYunHDBase.x,this._codexYunHDBase.y);delete this._codexYunHDBase;}
  var result=old.apply(this,args),info=Y.iconInfo(this._iconIndex);
  if(!info)return result;
  var sprite=this,bitmap=CodexQualityIcons.bitmap(info,function(){sprite.updateFrame();});
  if(bitmap){this._codexYunHDBase={bitmap:this.bitmap,x:this.scale.x,y:this.scale.y};this.bitmap=bitmap;this.setFrame(0,0,bitmap.width,bitmap.height);this.scale.set(this.scale.x*32/bitmap.width,this.scale.y*32/bitmap.height);}
  return result;
 });

 window.CodexDamageHooks.push({name:'yunshang',split:function(x,t,o){
  var a=x.subject(),d=data(a);if(!d||x._yunDerived||!damageAction(x))return null;
  var es=d.key===14?(awake(a)?setting(a).elements.slice():[setting(a).element]):null;
  var routes=d.key===13&&awake(a)?['magical','physical']:[null],targets=x._yunSleeveTargets||[t];
  if(!es&&routes.length===1&&targets.length===1)return null;
  var parts=[];targets.forEach(function(target){routes.forEach(function(mode){parts.push({target:target,options:{elements:es||undefined,mode:mode||undefined}});});});return parts;
 },enter:function(x,t,f){
  var a=x.subject(),prior=x._yunPhysicalRoute;x._yunPhysicalRoute=f.options.mode==='physical';
  return function(){if(prior===undefined)delete x._yunPhysicalRoute;else x._yunPhysicalRoute=prior;};
 },build:function(x,t,f){
  var a=x.subject(),d=data(a),item=x.item();if(is(a)&&damageAction(x)){
   f.mode=f.options.mode||'magical';
   if(!x._yunDerived&&ownSkill(a,S.double))f.skillMultiplier*=.555;
   if(ownSkill(a,S.spread)&&x.isForOne()&&t!==x._yunPrimary)f.skillMultiplier*=ownSkill(a,S.silver)?.77:ownSkill(a,S.double)?.66:.5;
  }
  if(relic(a)&&x.isSkill()&&item.damage.type>0)f.settlementMultiplier*=1.99*(x._yunGlow||1);
  if(x._yunNeedleRate)f.skillMultiplier*=x._yunNeedleRate;
  if(x._yunNeedleGlow)f.skillMultiplier*=x._yunNeedleGlow;
  if(x._yunPinWeaken)f.incomingMultiplier*=.67;
  if(d&&d.key===13)f.categoryMax=true;
 }});

return {version:Y.version,actor:C.actor};
});
