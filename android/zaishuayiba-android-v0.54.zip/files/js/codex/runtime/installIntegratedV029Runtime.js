// 【Codex·未经Claude检验】v0.42：按用户要求追加隐藏戮仙剑78；旧独立实例原位归档，禁止装备、获取、随机词缀、商店及吸取。
// 【Codex·未经Claude检验】v0.36：一拳终伤旧实例迁移，禁用隐藏专武随机词缀来源。
// 【Codex·未经Claude检验】v0.30 拳一、隐藏禁用、光环分类及旧实例兼容。
window.CodexRuntime.register('installIntegratedV029Runtime',function(){
 'use strict';
 var W=window,U=W.CodexV029={version:'v0.30',limitless:10454,absorb:10455,auraType:11,hiddenActors:[141,146,152,157,160,161,166]};

 var Z=W.CodexZhuxianRestore={ids:{"5945": 10456, "5946": 10458, "5947": 10459, "5948": 10460, "5949": 10461, "5950": 10462, "5951": 10463, "5952": 10464, "5953": 10465, "5954": 10466, "5955": 10457, "5956": 10467, "5957": 10468, "5958": 10469, "5959": 10470, "5960": 10471},revision:29};
 Z.sync=function(){var a=W.$gameActors&&$gameActors._data[162];if(!a||a._codexZhuxian29)return;
  a._skills=(a._skills||[]).filter(function(id){return !(id>=5945&&id<=5960);});
  a._skillsCache=undefined;a._codexZhuxian29=true;if(W.CodexV029)CodexV029.refresh(a);
 };
 function alias(o,k,fn){var old=o[k];if(typeof old==='function')o[k]=function(){return fn.call(this,old,arguments);};}
 function clone(x){return JSON.parse(JSON.stringify(x));}
 function base(i){return Number(i&&(i.originalBaseItemId||i.baseItemId||i.id));}
 function hiddenActor(a){return U.hiddenActors.indexOf(Number(a&&a.actorId?a.actorId():a))>=0;}
 // v0.53 用户要求解禁李逍遥专武 78／92：隐藏名单清空，恢复获取/装备/商店/吸取/词缀来源。
 function hiddenGear(i){return false;}
 U.hiddenActor=hiddenActor;U.hiddenGear=hiddenGear;
 function refresh(a){if(W.CodexQiyuBalance&&CodexQiyuBalance.refreshActor)CodexQiyuBalance.refreshActor(a);else a.refresh();}
 U.refresh=refresh;
 U.normalizeWeapon=function(i){
  if(!i||i.wtypeId===undefined||base(i)!==90||i._codexQiyuWeapon29)return false;
  if(/<CodexQiyuWeapon29>/.test(i.note||'')){i._codexQiyuWeapon29=true;return false;}
  // Remove only the authored hidden growth block. Independent params, augments and ID remain owned by the instance.
  var authored=U.weaponBefore&&U.weaponBefore.note.match(/<Custom Parameters>[\s\S]*?<\/Custom Parameters>/i);
  i.note=String(i.note||'');if(authored)i.note=i.note.replace(authored[0],'');
  if(i.parameterEval){var ev=String(i.parameterEval);[['atk',15000],['mat',1500],['luk',2000],['agi',2000],['def',2000],['mdf',2000],['mhp',20000],['mmp',5000]].forEach(function(pair){ev=ev.replace(new RegExp('\\b'+pair[0]+'\\s*=\\s*user\\.level\\s*\\*\\s*'+pair[1]+'\\s*;?'),'');});i.parameterEval=ev;}
  i.note=i.note.replace(/只有桐人能够装备/g,'只有拳一能够装备').replace(/琦玉/g,'拳一');
  var target=$dataWeapons[90],before=U.weaponBefore;
  if(before){
   // Replace the authored line once; keep independently appended affix lines.
   before.note.split(/\r?\n/).forEach(function(line){
    if(!/<(?:Element Amplify 1:|SkillPass(?:9934|9938|9939|5574):)/.test(line))return;
    var key=line.match(/^<([^:]+):/),replacement=key&&target.note.split(/\r?\n/).find(function(t){return t.indexOf('<'+key[1]+':')===0;});
    if(replacement)i.note=i.note.replace(line,replacement);
   });
   var t=(i.traits||[]).find(function(t){return t.code===22&&t.dataId===2&&Math.abs(t.value-.3)<1e-9;});if(t)t.value=1.88;
   if(i.elementAmplify&&i.elementAmplify[1]!==undefined)i.elementAmplify[1]+=(100-150)/100;
   if(i.meta){[9934,9938,9939,5574].forEach(function(id){var k='SkillPass'+id;if(i.meta[k]!==undefined)i.meta[k]=String(parseFloat(i.meta[k])-101)+'%';});}
  }
  i.note=i.note.replace('物理伤害+150%','物理伤害+100%').replace('专属技能伤害+200%','专属技能伤害+99%').replace('暴击率+30%','暴击率+188%');
  i._codexQiyuWeapon29=true;
  if(W.RJO&&RJO.HE){delete i.descParams;RJO.HE.getDescParams(i,1);}
  return true;
 };
 // 【Codex·未经Claude检验】v0.36：先完成旧版迁移，再精确替换专武本体终伤。
 var normalizeBefore36=U.normalizeWeapon;
 U.normalizeWeapon=function(i){
  var changed=normalizeBefore36(i);
  if(!i||i.wtypeId===undefined||base(i)!==90||i._codexQiyuWeapon36===36)return changed;
  var note=String(i.note||'');
  note=note.replace('神武(最终伤害+1000%)','神武(最终伤害+300%)').replace('<passiveHarmRi:1000>','<passiveHarmRi:300>');
  i.note=note;i._codexQiyuWeapon36=36;
  var re=/<passiveHarmRi:([^>]+)>/gi,m,last;while((m=re.exec(note)))last=m[1];
  if(last!==undefined){i.meta=i.meta||{};i.meta.passiveHarmRi=last;}
  if(W.CodexAbyssMerchant)CodexAbyssMerchant.touch();
  if(W.RJO&&RJO.HE){delete i.descParams;RJO.HE.getDescParams(i,1);}
  return true;
 };
 // A generated current template is already updated; only legacy copies need deltas.
 U.weaponBefore={"note": "<Custom Parameters>\natk = user.level * 15000;\nmat = user.level * 1500;\nluk = user.level * 2000;\nagi = user.level * 2000;\ndef = user.level * 2000;\nmdf = user.level * 2000;\nmhp = user.level * 20000;\nmmp = user.level * 5000;\n</Custom Parameters>\n  <Disassemble Pool: 3>\n   item 236\n  </Disassemble Pool: 3>\n<req_level:1>\n<req_actors:163>\n<ici:11>\n<quality:9>\n<dh:531>\n<Random Variance: 150>\n<pos=APs text=等级需求:1 size=18 color=rgba(255,255,255,1) line=false align=0>\n<pos=APs text=\\c[2]特效:秃头英雄(只有桐人能够装备) size=18 color=rgba(255,255,255,1) line=false align=0>\n<pos=APs text=\\c[1]特效:神武(最终伤害+100%) size=18 color=rgba(255,255,255,1) line=false align=0>\n<pos=APs text=\\c[1]特效:普通一击(物理伤害+150%，攻击属性：物理) size=18 color=rgba(255,255,255,1) line=false align=0>\n<pos=APs text=\\c[1]特效:认真一拳(专属技能伤害+200%) size=18 color=rgba(255,255,255,1) line=false align=0>\n<pos=APs text=暴击率+30% size=18 color=rgba(255,255,255,1) line=false align=0>\n  <Disassemble Pool: 4>\n   item 640\n  </Disassemble Pool: 4> \n<Element Amplify 1: +150%>\n<DepassiveHarmRe01:10%>\n<passiveHarmRi:100>\n<SkillPass9934:200%>\n<SkillPass9938:200%>\n<SkillPass9939:200%>\n<SkillPass5574:200%>\n<item 2882 Buy Price: 2>\n<item 2898 sell Price: 2>"};
 U.sync=function(){
  if(!W.$gameParty||!W.$gameActors)return;
  var party=$gameParty,hidden=party._codexHiddenActors29=party._codexHiddenActors29||[];
  var origins=party._codexHiddenActorLocations29=party._codexHiddenActorLocations29||{};
  U.hiddenActors.forEach(function(id){if(!origins[id]&&((party._actors||[]).indexOf(id)>=0||(party._saveactors||[]).indexOf(id)>=0))origins[id]={partyIndex:(party._actors||[]).indexOf(id),warehouseIndex:(party._saveactors||[]).indexOf(id),battleSlots:(party._battleMembers||[]).map(function(v,i){return v===id?i:-1;}).filter(function(i){return i>=0;})};});
  ['_actors','_saveactors'].forEach(function(k){party[k]=(party[k]||[]).filter(function(id){if(hiddenActor(id)){if(hidden.indexOf(id)<0)hidden.push(id);return false;}return true;});});
  (party._battleMembers||[]).forEach(function(id,j){if(hiddenActor(id))party._battleMembers[j]=0;});
  var archived=party._codexHiddenWeapons29=party._codexHiddenWeapons29||{};
  ($gameActors._data||[]).forEach(function(a){if(!a)return;
   var dirty=false;
   (a._equips||[]).forEach(function(ref,slot){var i=ref&&ref.object();if(hiddenGear(i)){var slots=party._codexHiddenWeaponSlots29=party._codexHiddenWeaponSlots29||[];slots.push({actorId:a.actorId(),slot:slot,itemId:i.id});archived[i.id]=(archived[i.id]||0)+1;ref.setObject(null);dirty=true;}else if(U.normalizeWeapon(i))dirty=true;});
   if(a.actorId()>=141&&a.actorId()<=166){
    var old=a._skills||[];a._skills=old.filter(function(id){return id!==10264;});
    if(a.actorId()!==163){a._states=(a._states||[]).filter(function(id){return id!==2626;});}
    else{a._name='拳一';if(a._skills.indexOf(U.limitless)<0){a._skills.push(U.limitless);dirty=true;}if(a._skills.indexOf(U.absorb)<0){a._skills.push(U.absorb);dirty=true;}}
    if(old.length!==a._skills.length)dirty=true;
   }
   if(W.CodexAbyssMerchant&&CodexAbyssMerchant.isAbsorbActor(a.actorId())&&!a.isLearnedSkill(U.absorb)){a.learnSkill(U.absorb);dirty=true;}
   if(dirty)refresh(a);
  });
  Object.keys(party._weapons||{}).forEach(function(id){var i=$dataWeapons[id];if(hiddenGear(i)){archived[id]=(archived[id]||0)+party._weapons[id];delete party._weapons[id];}else U.normalizeWeapon(i);});
  (DataManager._independentWeapons||[]).forEach(U.normalizeWeapon);
  if(W.CodexZhuxianRestore)CodexZhuxianRestore.sync();
 };
 alias(DataManager,'extractSaveContents',function(old,args){var result=old.apply(this,args);U.sync();return result;});
 alias(DataManager,'setupNewGame',function(old,args){var result=old.apply(this,args);U.sync();return result;});
 alias(Game_Actor.prototype,'setup',function(old,args){var result=old.apply(this,args);if(Number(args[0])===163)this.learnSkill(U.limitless);if(W.CodexAbyssMerchant&&CodexAbyssMerchant.isAbsorbActor(args[0]))this.learnSkill(U.absorb);return result;});
 alias(Game_Actor.prototype,'addState',function(old,args){if(this.actorId()>=141&&this.actorId()<=166&&Number(args[0])===2626)return;return old.apply(this,args);});
 alias(Game_Actor.prototype,'canEquip',function(old,args){return !hiddenGear(args[0])&&old.apply(this,args);});
 ['changeEquip','forceChangeEquip'].forEach(function(k){alias(Game_Actor.prototype,k,function(old,args){if(hiddenGear(args[1]))return;return old.apply(this,args);});});
 alias(Game_Party.prototype,'gainItem',function(old,args){if(Number(args[1])>0&&hiddenGear(args[0]))return;return old.apply(this,args);});
 if(W.DreamX&&DreamX.RandomPrefixSuffix)alias(DreamX.RandomPrefixSuffix,'isValidItem',function(old,args){return !hiddenGear(args[0])&&!exclusiveAffix(args[0])&&old.apply(this,args);});
 // 【Claude·未经Codex检验】v0.37：天外天专武（武器名以「天外天·」开头）是角色专属，不再被随机前后缀抽成别的装备的词条。
 function exclusiveAffix(i){return !!(i&&i.wtypeId!==undefined&&/^天外天·/.test(i.name||''));}
 U.exclusiveAffix=exclusiveAffix;
 alias(Game_Party.prototype,'weapons',function(old,args){return old.apply(this,args).filter(function(i){return !hiddenGear(i);});});
 if(W.Star_Window_PartyList)alias(Star_Window_PartyList.prototype,'createActorOrder',function(old,args){var result=old.apply(this,args);this._data=(this._data||[]).filter(function(id){return !hiddenActor(id);});return result;});
 if(W.Window_ActorBookIndex)alias(Window_ActorBookIndex.prototype,'refresh',function(old,args){var result=old.apply(this,args);this._list=(this._list||[]).filter(function(a){return !hiddenActor(a);});this.createContents();this.drawAllItems();return result;});
 // v0.53 专武已解禁，商店不再过滤 78／92。
 alias(Scene_Shop.prototype,'prepare',function(old,args){return old.apply(this,args);});

 // Natural complete rounds, additive +10% per round, no extra-turn double count.
 function reset(){if(W.$gameActors)($gameActors._data||[]).forEach(function(a){if(a&&a.actorId()===163){a._qiyuRounds29=0;a._qiyuRoundToken29=null;refresh(a);}});}
 alias(BattleManager,'startBattle',function(old,args){reset();return old.apply(this,args);});
 U.completeRound=function(token){var a=$gameActors._data[163];if(!$gameParty.inBattle()||!a||!a.isBattleMember()||!a.isAlive()||!a.isLearnedSkill(U.limitless)||a._qiyuRoundToken29===token)return false;a._qiyuRoundToken29=token;a._qiyuRounds29=(a._qiyuRounds29||0)+1;refresh(a);return true;};
 alias(BattleManager,'endTurn',function(old,args){var was=this._enteredEndPhase,out=old.apply(this,args);if((!was&&this._enteredEndPhase)||(!this.isOTB()&&this._phase==='turnEnd'))U.completeRound($gameTroop.turnCount());return out;});
 alias(BattleManager,'endBattle',function(old,args){try{return old.apply(this,args);}finally{reset();}});
 alias(Game_Actor.prototype,'param',function(old,args){var v=old.apply(this,args);if(this.actorId()!==163||!$gameParty.inBattle()||!this.isLearnedSkill(U.limitless))return v;return Math.max(this.paramMin(args[0]),Math.min(this.paramMax(args[0]),Math.round(v*(1+.1*(this._qiyuRounds29||0)))));});

 // Type 11 is a menu-only aura view. Keep native passive type 4 for effect readers.
 function aura(s){return !!(s&&s.stypeId===4&&/<CodexAura>/.test(s.note||''));}
 U.isAura=aura;
 ['addedSkillTypes','addedSkillTypesForMenu'].forEach(function(k){alias(Game_Actor.prototype,k,function(old,args){var list=old.apply(this,args).map(function(id){return Number(id);}).filter(function(id,index,all){return Number.isInteger(id)&&id>0&&all.indexOf(id)===index;});if(k==='addedSkillTypesForMenu'&&this.skills().some(aura)&&list.indexOf(U.auraType)<0)list.push(U.auraType);return list;});});
 alias(Window_SkillList.prototype,'includes',function(old,args){var s=args[0];if(s&&this._stypeId===U.auraType)return aura(s);if(aura(s)&&this._stypeId===4)return false;return old.apply(this,args);});
 if(W.Window_SkillType)alias(Window_SkillType.prototype,'makeCommandList',function(old,args){var result=old.apply(this,args),seen={};if(this._actor&&this._actor.skills().some(aura)&&!this._list.some(function(c){return c.ext===U.auraType;}))this.addCommand('光环','skill',true,U.auraType);this._list=this._list.filter(function(c){var k=c.symbol+':'+c.ext;if(seen[k])return false;seen[k]=true;return true;});return result;});
 // Absorption is implemented by the shared affix service, invoked from the native skill menu.
 alias(Scene_Skill.prototype,'useItem',function(old,args){var i=this.item();if(i&&i.id===U.absorb){if(W.CodexAbyssMerchant)CodexAbyssMerchant.openAbsorb();return;}return old.apply(this,args);});
 return U;
});
