// v0.53 李逍遥专武解禁：78 戮仙剑、92 天外天·轩辕剑。
// 用户 2026-10-27 决定：完成三档平衡后一并解禁两把专武（获取、装备、商店、吸取与词缀来源）。
// 本模块只做两件事：
//  1) 把旧存档里被 v0.30/v0.42 隐藏归档的两把武器按原角色槽位/背包数量恢复（不删除随机词条、吸取、镶嵌与培养）；
//  2) 把旧独立实例的备注与解析字段迁移到本轮新数值（保留实例 ID、培养、随机词条等；v0.53.03 起只改模板原有行）。
// 不改变狂刀与其他角色，不改存档结构；可重复执行。
window.CodexRuntime.register('installLxyUnlockRuntime', function() {
  'use strict';
  var W = window, IDS = [78, 92];
  function base(i) { return Number(i && (i.originalBaseItemId || i.baseItemId || i.id)); }
  function isTarget(i) { return !!(i && i.wtypeId !== undefined && IDS.indexOf(base(i)) >= 0); }
  // 独立实例在 YEP_ItemCore 读档后追加进 $dataWeapons，因此按 id 即可解析。
  function resolve(id) {
    id = Number(id);
    var t = W.$dataWeapons && W.$dataWeapons[id];
    if (t && Number(t.id) === id) return t;
    var arr = (W.DataManager && DataManager._independentWeapons) || [];
    for (var k = 0; k < arr.length; k++) if (arr[k] && Number(arr[k].id) === id) return arr[k];
    return null;
  }
  // v0.53.03：只改「模板原有行」——按改前模板原文精确匹配、每行只换第一次出现；
  // 随机词条追加进实例备注的同名标签（终伤、物理增伤等）原样保留。每个实例只迁移一次（_codexLxy5303）。
  // 旧档读档时 ImportedBalance 已先把更早世代换成 v0.52 数值，所以这里只需认 v0.52 原文。
  var POS = function(t) { return '<pos=APs text=' + t + ' size=18 color=rgba(255,255,255,1) line=false align=0>'; };
  var RULES = {
    78: [['<Replace Attack: 5564> ', '<Replace Attack: 9926>'], ['<Replace Attack: 5564>', '<Replace Attack: 9926>'],
         ['<Weapon Unleash 100%: 5564>', null],
         [POS('\\c[1]特效:仙剑(最终伤害+500%)'), null],
         [POS('\\c[1]特效:剑道(物理伤害+1200%，攻击属性：物理)'), POS('\\c[1]特效:剑道(物理伤害+110%，攻击属性：物理)')],
         [POS('\\c[1]特效:万剑归宗(普通攻击变为释放万剑归宗·戮仙)'), POS('\\c[1]特效:万剑归宗(普通攻击变为释放万剑归宗)')],
         ['<Element Amplify 1: +1200%>', '<Element Amplify 1: +110%>', -10.9],
         ['<passiveHarmRi:500>', null], ['<CodexHiddenEquipment>', null]],
    92: [[POS('\\c[3]特效:真·神兵(最终伤害+5000%)'), POS('\\c[3]特效:真·神兵(最终伤害+100%)')],
         [POS('\\c[4]特效:真·极道(物理伤害+10000%，攻击属性：物理)'), null],
         [POS('\\c[5]特效:真·剑舞(普通攻击变为释放万剑归宗 万剑归宗专属伤害+3000%)'), POS('\\c[5]特效:真·剑舞(普通攻击变为释放万剑归宗)')],
         [POS('\\c[6]特效:真·双生(再动/在释放+1)'), POS('\\c[6]特效:真·双生(再动+1)')],
         ['<Element Amplify 1: +10000%>', null, -100],
         ['<passiveHarmRi:5000>', '<passiveHarmRi:100>'],
         ['<SkillPass9926: 3000%>', null], ['<AgainUseAll: 100%>', null], ['<CodexHiddenEquipment>', null]]
  };
  var REPLACE = '<Replace Attack: 9926>', DONE = '_codexLxy5303';
  // meta 取备注中最后一次出现的值（与 DataManager.extractMetadata 一致），没有就删除。
  function syncMeta(item, key) {
    var re = new RegExp('<' + key + ':([^>]*)>', 'gi'), m, last;
    while ((m = re.exec(item.note))) last = m[1];
    if (last === undefined) delete item.meta[key]; else item.meta[key] = last;
  }
  function migrate(item) {
    if (!isTarget(item) || item[DONE]) return false;
    var id = base(item), lines = String(item.note || '').split(/\r?\n/), changed = false;
    (RULES[id] || []).forEach(function(rule) {
      var k = lines.indexOf(rule[0]);
      if (k < 0) return;
      if (rule[1] === null) lines.splice(k, 1); else lines[k] = rule[1];
      if (rule[2] && item.elementAmplify) item.elementAmplify[1] = Math.max(0, (Number(item.elementAmplify[1]) || 0) + rule[2]);
      changed = true;
    });
    if (!lines.some(function(l) { return /<(?:ATTACK REPLACE|REPLACE ATTACK):/i.test(l); })) {
      var at = lines.indexOf('<Random Variance: 150>');
      lines.splice(at >= 0 ? at + 1 : lines.length, 0, REPLACE);
      changed = true;
    }
    item.attackReplace = 9926;
    var traits = item.traits || [], filtered = traits.filter(function(t) { return !(t && Number(t.code) === 43 && Number(t.dataId) === 5564); });
    if (filtered.length !== traits.length) { item.traits = filtered; changed = true; }
    if (changed) {
      item.note = lines.join('\n');
      item.meta = item.meta || {};
      ['passiveHarmRi', 'SkillPass9926', 'AgainUseAll', 'CodexHiddenEquipment', 'Element Amplify 1'].forEach(function(k) { syncMeta(item, k); });
      if (W.RJO && RJO.HE) { delete item.descParams; RJO.HE.getDescParams(item, 1); }
    }
    // 模板本身不打标记（新实例从模板复制，标记会被带走）。
    if (Number(item.id) !== id) item[DONE] = true;
    return changed;
  }
  function actorById(id) {
    var arr = (W.$gameActors && $gameActors._data) || [];
    for (var k = 0; k < arr.length; k++) if (arr[k] && Number(arr[k].actorId && arr[k].actorId()) === Number(id)) return arr[k];
    return null;
  }
  function restore() {
    var p = W.$gameParty, stat = { slots: 0, items: 0, unresolved: 0 };
    if (!p) return stat;
    // 原生 changeEquip 要求物品在背包里（tradeItemWithParty）；装备实例在 gainItem 时创建。
    function give(id) {
      var item = resolve(id);
      if (!item) return null;
      try { p.gainItem(item, 1); } catch (e) {}
      var list = p.weapons();
      for (var k = list.length - 1; k >= 0; k--) {
        var x = list[k];
        if (x && Number(x.originalBaseItemId || x.baseItemId || x.id) === Number(item.id)) return x;
      }
      return null;
    }
    var slots = p._codexHiddenWeaponSlots29 || [], keep = [], restored = {};
    slots.forEach(function(rec) {
      if (!rec) { keep.push(rec); return; }
      var id = Number(rec.itemId), item = resolve(id);
      if (!item || !isTarget(item)) { keep.push(rec); stat.unresolved += 1; return; }
      var got = give(id);
      if (!got) { keep.push(rec); stat.unresolved += 1; return; }
      var a = actorById(rec.actorId), slot = Number(rec.slot);
      if (a && a._equips && a._equips[slot] && !a._equips[slot].object()) {
        var etype = a.equipSlots()[slot];
        if (etype === got.etypeId && a.canEquip(got)) {
          try { a.changeEquip(slot, got); } catch (e) {}
        }
      }
      restored[id] = (restored[id] || 0) + 1;
      stat.slots += 1;
    });
    p._codexHiddenWeaponSlots29 = keep;
    var arch = p._codexHiddenWeapons29 || {};
    Object.keys(arch).forEach(function(key) {
      var item = resolve(key);
      if (!item || !isTarget(item)) return;
      var n = Number(arch[key] || 0) - (restored[Number(key)] || 0);
      if (n > 0) { try { p.gainItem(item, n); stat.items += n; } catch (e) {} }
      delete arch[key];
    });
    p._codexHiddenWeapons29 = arch;
    // 迁移覆盖：独立实例、所有角色身上、背包、未解析归档。
    ((W.DataManager && DataManager._independentWeapons) || []).forEach(function(i) { if (i) migrate(i); });
    ((W.$gameActors && $gameActors._data) || []).forEach(function(a) {
      if (a && a._equips) a._equips.forEach(function(r) { var i = r && r.object && r.object(); if (i) migrate(i); });
    });
    Object.keys(p._weapons || {}).forEach(function(id) { var i = W.$dataWeapons && W.$dataWeapons[id]; if (i) migrate(i); });
    (p._codexHiddenWeaponSlots29 || []).forEach(function(r) { var i = r && resolve(r.itemId); if (i) migrate(i); });
    return stat;
  }
  // v0.53.03：78/92 的普攻替换为万剑归宗 9926。原生规则里「攻击次数」只加在普攻上（李逍遥战斗中 +3），
  // 不处理的话普攻形态的万剑归宗会多打 3 轮，等于直接放技能的 4 倍。这里让普攻形态与直接施放同段数，
  // 保持 v0.53 已定的 0.5／1／1.5 刀标定。
  var numRepeats = Game_Action.prototype.numRepeats;
  Game_Action.prototype.numRepeats = function() {
    var n = numRepeats.apply(this, arguments), it = this.item(), s = this.subject();
    if (it && it.id === 9926 && s && s.isActor && s.isActor() && this.isAttack()) {
      n = Math.max(it.repeats || 1, n - (Number(s.attackTimesAdd()) || 0));
    }
    return n;
  };
  var U = { version: 'v0.53.03', ids: IDS.slice(), migrate: migrate, restore: restore };
  W.CodexLxyUnlock = U;
  var extract = DataManager.extractSaveContents;
  DataManager.extractSaveContents = function() {
    var out = extract.apply(this, arguments);
    try { U.lastRestore = restore(); } catch (e) { U.lastError = String(e && e.message || e); }
    return out;
  };
  var setupNewGame = DataManager.setupNewGame;
  DataManager.setupNewGame = function() {
    var out = setupNewGame.apply(this, arguments);
    try { U.lastRestore = restore(); } catch (e) {}
    return out;
  };
  return U;
});
