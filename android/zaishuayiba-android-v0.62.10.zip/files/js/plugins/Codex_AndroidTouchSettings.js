// 【Claude·未经Codex检验】v0.62.13 设置弹窗在矮屏和旧版 WebView 上可完整滑动；未经Codex检验。
// 【Codex·未经Claude检验】v0.08 原版按钮显示恢复；未经claude检验。
// 【Codex·未经Claude检验】v0.07 原版虚拟按钮可选／战斗点击设置／实时菜单输入／手机UI位置／移动／A-B布局／后台设置；未经claude检验。
/*:
 * @plugindesc Android按键大小设置与标题存档导入入口。【Codex·未经Claude检验】
 * @author Codex
 * @help
 * 核查状态：未经claude检验。
 * 游戏设置或右上「按键」选择轮盘／方向键，分别调大小，自动保存。
 * 标题右上「导入存档」直接选择JSON存档，检查格式后选择档位。
 * 仅在带AndroidInterface的手机版生效，不改变角色、装备或战斗规则。
 */
(function(){
 'use strict';
 if(!window.AndroidInterface||!window.AndroidPort)return;
 var KEY='kyo.android.touchSettings.v1',node=null,panel=null,savePanel=null,focusBefore=null,saveFocus=null,effective={},layoutEditing=false,layoutBar=null,layoutDrag=null,insetProbe=null;
 var defaults={controllerStyle:'modern',mode:'joystick',stick:100,pad:100,buttons:100,tools:100,hidden:false,mapTouch:true,battleTouch:false,actionLayout:'ab',showRun:false,transparency:0};
 var limits={stick:[70,170],pad:[70,170],buttons:[70,160],tools:[80,140],transparency:[0,80]};
 function normalized(value){
  var out={};value=value||{};
  Object.keys(limits).forEach(function(k){var n=Number(value[k]);out[k]=Number.isFinite(n)?Math.max(limits[k][0],Math.min(limits[k][1],n)):defaults[k];});
  out.mode=value.mode==='buttons'?'buttons':'joystick';out.mapTouch=value.mapTouch!==false;out.actionLayout=value.actionLayout==='full'?'full':'ab';
  out.positions={};['movement','actions','top'].forEach(function(k){var p=value.positions&&value.positions[k];out.positions[k]=p&&Number.isFinite(p.x)&&Number.isFinite(p.y)?{x:Math.max(0,Math.min(1,p.x)),y:Math.max(0,Math.min(1,p.y))}:null;});
  out.controllerStyle=value.controllerStyle==='original'?'original':'modern';out.originalPositions={};['movement','actions'].forEach(function(k){var p=value.originalPositions&&value.originalPositions[k];out.originalPositions[k]=p&&Number.isFinite(p.x)&&Number.isFinite(p.y)?{x:Math.max(0,Math.min(1,p.x)),y:Math.max(0,Math.min(1,p.y))}:null;});
  out.showRun=value.showRun===true;out.hidden=typeof value.hidden==='boolean'?value.hidden:localStorage.getItem('kyo.android.controlsHidden')==='1';
  out.battleTouch=typeof value.battleTouch==='boolean'?value.battleTouch:out.hidden;return out;
 }
 var settings;
 try{settings=normalized(JSON.parse(localStorage.getItem(KEY)||'null'));}catch(e){settings=normalized(defaults);}
 function save(){
  try{localStorage.setItem(KEY,JSON.stringify(settings));localStorage.setItem('kyo.android.controlsHidden',settings.hidden?'1':'0');}
  catch(e){AndroidInterface.message('按键设置暂时无法保存，请重新打开应用后重试。');}
 }
 function release(){
  if(AndroidPort.releaseTouchKeys)AndroidPort.releaseTouchKeys();
  if(window.Input)Input.clear();if(window.TouchInput)TouchInput.clear();
 }
 function apply(){
  if(!node)return;release();
  var w=innerWidth,h=innerHeight,small=h<=360,stick=settings.stick/100,pad=settings.pad/100,buttons=settings.buttons/100,tools=settings.tools/100,isPad=settings.mode==='buttons';
  node.classList.toggle('direction-buttons',isPad);node.classList.toggle('layout-ab',settings.actionLayout==='ab');
  if(!settings.mapTouch&&window.$gameTemp)$gameTemp.clearDestination();
  node.querySelector('.run').hidden=!settings.showRun;node.style.opacity=String(layoutEditing?1:1-settings.transparency/100);
  var top=node.querySelector('.top'),v=node.style;
  function topSize(scale){v.setProperty('--touch-top-font',Math.max(11,13*scale)+'px');v.setProperty('--touch-top-height',(32*scale)+'px');v.setProperty('--touch-top-x',(9*scale)+'px');v.setProperty('--touch-top-y',(5*scale)+'px');}
  topSize(tools);
  var available=Math.max(100,w-24),width=top.getBoundingClientRect().width;
  if(width>available){tools*=available/width;topSize(tools);}
  var s=(small?124:144)*stick,p=(small?124:144)*pad,knob=(small?46:52)*stick,run=44*(isPad?pad:stick),gap=5*buttons;
  var moveWidth=(isPad?p:s)+(settings.showRun?run+8:0),moveHeight=Math.max(isPad?p:s,run),ab=settings.actionLayout==='ab',actionWidth=(ab?164:120)*buttons,actionHeight=(ab?144:136)*buttons;
  var required=moveWidth+actionWidth+gap,usable=Math.max(100,w-48);
  var vertical=Math.max(70,h-top.getBoundingClientRect().height-42);
  var fit=Math.min(1,usable/required,vertical/Math.max(moveHeight,actionHeight+2*gap));
  s*=fit;p*=fit;knob*=fit;run*=fit;buttons*=fit;gap*=fit;
  var padGap=3*pad*fit,cell=(p-2*padGap)/3;
  var vars={'--touch-stick':s,'--touch-pad':p,'--touch-pad-cell':cell,'--touch-pad-gap':padGap,'--touch-pad-center':cell+padGap,'--touch-pad-font':Math.max(10,16*pad*fit),'--touch-knob':knob,'--touch-run-font':15*(isPad?pad:stick)*fit,'--touch-run':run,'--touch-move-width':moveWidth*fit,'--touch-move-height':moveHeight*fit,'--touch-ab-width':164*buttons,'--touch-ab-height':144*buttons,'--touch-ab-size':72*buttons,'--touch-ab-font':30*buttons,'--touch-action-width':60*buttons,'--touch-action-height':44*buttons,'--touch-confirm-height':48*buttons,'--touch-gap':gap,'--touch-font':Math.max(10,15*buttons)};
  Object.keys(vars).forEach(function(k){v.setProperty(k,vars[k]+'px');});
  node.classList.toggle('compact',settings.hidden&&!layoutEditing);node.classList.toggle('original-controls',originalSelected());applyPositions();syncOriginalControls();applyOriginalGeometry();
  effective={controllerStyle:settings.controllerStyle,battleTouch:settings.battleTouch,showRun:settings.showRun,transparency:settings.transparency,mapTouch:settings.mapTouch,actionLayout:settings.actionLayout,mode:settings.mode,stick:Math.round(settings.stick*fit),pad:Math.round(settings.pad*fit),buttons:Math.round(buttons*100),tools:Math.round(tools*100),limited:fit<.995||tools<settings.tools/100-.005};
  if(panel){var hint=panel.querySelector('[data-fit]');hint.textContent=effective.limited?'当前屏幕较小，已自动缩放，避免按键重叠。':'拖动滑杆可预览大小，设置会自动保存。';}
 }
 // 【Codex·未经Claude检验】 Reuse the APK's actual native sprite renderer.
 // The modern pointer bridge prevents canvas leaks and queues A/B once.
 var originalOverlay=null,originalScene=null,originalStick=null,originalButtons=null,originalPointers={},originalDrag=null;
 function originalSelected(){return settings.controllerStyle==='original';}
 function originalAvailable(scene){return originalSelected()&&(!settings.hidden||layoutEditing)&&!panel&&!savePanel&&scene&&!(scene instanceof Scene_Title)&&!(scene instanceof Scene_Boot)&&!document.getElementById('codex-feedback');}
 function originalCanvasTouchAllowed(){return !(SceneManager._scene instanceof Scene_Battle)||settings.battleTouch;}
 function releaseOriginalControls(){
  originalPointers={};originalDrag=null;
  if(AndroidPort.setVirtualDirections)AndroidPort.setVirtualDirections({});
  if(originalStick){originalStick._codexHeld=false;if(originalStick._D_Pad)originalStick._D_Pad.move(0,0);}
  if(originalOverlay)originalOverlay.querySelectorAll('button').forEach(function(b){if(b._codexVirtualBinding)b._codexVirtualBinding.clear();});
 }
 function removeOriginalOverlay(){releaseOriginalControls();if(originalOverlay){originalOverlay.querySelectorAll('button').forEach(function(el){if(AndroidPort.unbindVirtualButton)AndroidPort.unbindVirtualButton(el);});originalOverlay.remove();}originalOverlay=null;originalScene=null;originalStick=null;originalButtons=null;}
 function screenRect(sprite,radius,height){
  var a=sprite.toGlobal(new PIXI.Point(-radius,-(height===undefined?radius:height/2))),z=sprite.toGlobal(new PIXI.Point(radius,height===undefined?radius:height/2)),c=Graphics._canvas.getBoundingClientRect();
  return {left:c.left+a.x*c.width/Graphics.width,top:c.top+a.y*c.height/Graphics.height,width:(z.x-a.x)*c.width/Graphics.width,height:(z.y-a.y)*c.height/Graphics.height};
 }
 function placeHit(el,rect,relative){
  var left=rect.left-(relative?relative.left:0),top=rect.top-(relative?relative.top:0);
  el.style.left=left+'px';el.style.top=top+'px';el.style.width=rect.width+'px';el.style.height=rect.height+'px';
 }
 function moveOriginalSprite(sprite,key,base){
  var p=settings.originalPositions[key];if(!p)return;
  var rect=base(),canvas=Graphics._canvas.getBoundingClientRect(),left=canvas.left+12,top=canvas.top+6;
  var width=Math.max(0,canvas.width-24-rect.width),height=Math.max(0,canvas.height-18-rect.height);
  sprite.x+=(left+p.x*width-rect.left)*Graphics.width/canvas.width;
  sprite.y+=(top+p.y*height-rect.top)*Graphics.height/canvas.height;
 }
 function originalGroupBounds(){
  var a=originalButtons.getChildByName('keyboardAction'),b=originalButtons.getChildByName('keyboardCancel'),x=screenRect(a,a._radius),y=screenRect(b,b._radius);
  var left=Math.min(x.left,y.left),top=Math.min(x.top,y.top);
  return {left:left,top:top,width:Math.max(x.left+x.width,y.left+y.width)-left,height:Math.max(x.top+x.height,y.top+y.height)-top};
 }
 function applyOriginalGeometry(){
  if(!originalOverlay||!originalStick||!originalButtons)return;
  originalStick.scale.set(settings.stick/100);originalButtons.scale.set(settings.buttons/100);
  originalStick.x=originalStick._codexBase.x;originalStick.y=originalStick._codexBase.y;
  originalButtons.x=originalButtons._codexBase.x;originalButtons.y=originalButtons._codexBase.y;
  moveOriginalSprite(originalStick,'movement',function(){return screenRect(originalStick,originalStick._radius);});
  moveOriginalSprite(originalButtons,'actions',originalGroupBounds);
  var sr=screenRect(originalStick,originalStick._radius),ar=originalGroupBounds();
  placeHit(originalOverlay.querySelector('.original-movement'),sr);placeHit(originalOverlay.querySelector('.original-actions'),ar);
  originalButtons.children.forEach(function(s){
   var el=originalOverlay.querySelector('[data-original-key="'+s._keyName+'"]');if(!el)return;
   if(s._keyName==='tilde'){
    // Source Save remains in the upper right when A/B is repositioned.
    var canvas=Graphics._canvas.getBoundingClientRect(),toolbar=node.querySelector('.top').getBoundingClientRect();
    var saveY=Math.max(40,(toolbar.bottom+6-canvas.top)*Graphics.height/canvas.height+40);
    s.x=(Graphics.width-40-originalButtons.x)/originalButtons.scale.x;s.y=(saveY-originalButtons.y)/originalButtons.scale.y;
    placeHit(el,screenRect(s,s._radius,60));
   }else placeHit(el,screenRect(s,s._radius),ar);
  });
  var alpha=1-settings.transparency/100;
  originalStick.opacity=(originalStick._codexHeld?255:150)*alpha;
  originalButtons.children.forEach(function(s){var el=originalOverlay.querySelector('[data-original-key="'+s._keyName+'"]');s.opacity=(el&&el._codexVirtualBinding&&el._codexVirtualBinding.active?255:80)*alpha;});
  originalOverlay.classList.toggle('layout-editing',layoutEditing);
 }
 function originalDragStart(e,el,key,sprite){
  e.preventDefault();e.stopImmediatePropagation();releaseOriginalControls();
  var canvas=Graphics._canvas.getBoundingClientRect();originalDrag={id:e.pointerId,key:key,sprite:sprite,x:e.clientX,y:e.clientY,baseX:sprite.x,baseY:sprite.y,canvas:canvas,el:el};el.setPointerCapture(e.pointerId);
 }
 function originalDragMove(e){
  var d=originalDrag;if(!d||d.id!==e.pointerId)return;e.preventDefault();e.stopImmediatePropagation();
  d.sprite.x=d.baseX+(e.clientX-d.x)*Graphics.width/d.canvas.width;d.sprite.y=d.baseY+(e.clientY-d.y)*Graphics.height/d.canvas.height;
  var r=d.key==='movement'?screenRect(originalStick,originalStick._radius):originalGroupBounds(),left=d.canvas.left+12,top=d.canvas.top+6;
  var width=Math.max(0,d.canvas.width-24-r.width),height=Math.max(0,d.canvas.height-18-r.height);
  settings.originalPositions[d.key]={x:width?Math.max(0,Math.min(1,(r.left-left)/width)):0,y:height?Math.max(0,Math.min(1,(r.top-top)/height)):0};applyOriginalGeometry();
 }
 function installOriginalPointerHandlers(){
  var movement=originalOverlay.querySelector('.original-movement'),actions=originalOverlay.querySelector('.original-actions');
  [movement,actions].forEach(function(el){
   el.addEventListener('pointerdown',function(e){if(layoutEditing)originalDragStart(e,el,el===movement?'movement':'actions',el===movement?originalStick:originalButtons);},true);
   el.addEventListener('pointermove',originalDragMove,true);
   ['pointerup','pointercancel','lostpointercapture'].forEach(function(type){el.addEventListener(type,function(e){if(originalDrag&&originalDrag.id===e.pointerId){e.preventDefault();e.stopImmediatePropagation();originalDrag=null;save();releaseOriginalControls();}},true);});
  });
  movement.addEventListener('pointerdown',function(e){
   e.preventDefault();e.stopPropagation();if(layoutEditing||originalPointers.stick)return;
   originalPointers.stick={id:e.pointerId,started:performance.now(),pageAt:0};movement.setPointerCapture(e.pointerId);originalStick._codexHeld=true;move(e);
  });
  function move(e){
   var state=originalPointers.stick;if(!state||state.id!==e.pointerId)return;
   var r=movement.getBoundingClientRect(),x=(e.clientX-r.left-r.width/2)*280/r.width,y=(e.clientY-r.top-r.height/2)*280/r.height,distance=Math.hypot(x,y),scale=distance>140?140/distance:1;
   originalStick._D_Pad.move(x*scale,y*scale);var keys={};
   if(distance>42){var key=Math.abs(x)>Math.abs(y)?(x<0?'left':'right'):(y<0?'up':'down');keys[key]=true;
    keys.shift=SceneManager._scene instanceof Scene_Map&&!ConfigManager.alwaysDash&&distance>=77;
    // Keep the source's deliberate sideways long-drag page gesture on real time.
    var now=performance.now();if(e.type==='pointermove'&&(key==='left'||key==='right')&&distance>=91&&now-state.started>=600&&now-state.pageAt>=400){AndroidPort.queueVirtualKey(key==='left'?'pageup':'pagedown');state.pageAt=now;}
   }
   AndroidPort.setVirtualDirections(keys);applyOriginalGeometry();
  }
  movement.addEventListener('pointermove',function(e){e.preventDefault();e.stopPropagation();move(e);});
  ['pointerup','pointercancel','lostpointercapture'].forEach(function(type){movement.addEventListener(type,function(e){if(originalPointers.stick&&originalPointers.stick.id===e.pointerId){e.preventDefault();e.stopPropagation();originalPointers.stick=null;originalStick._codexHeld=false;originalStick._D_Pad.move(0,0);AndroidPort.setVirtualDirections({});applyOriginalGeometry();}});});
  originalOverlay.querySelectorAll('[data-original-key]').forEach(function(el){el.dataset.key=el.dataset.originalKey;el.dataset.single='true';AndroidPort.bindVirtualButton(el);});
  ['pointerdown','pointermove','pointerup','touchstart','touchmove','touchend','touchcancel','mousedown','mouseup','click'].forEach(function(type){originalOverlay.addEventListener(type,function(e){e.stopPropagation();});});
 }
 function attachOriginalControls(scene){
  var stick=scene.getChildByName('JoyStick'),buttons=scene.getChildByName('ghostButtons');if(!stick||!buttons)return;
  if(originalScene===scene&&originalStick===stick&&originalButtons===buttons&&originalOverlay)return;
  removeOriginalOverlay();originalScene=scene;originalStick=stick;originalButtons=buttons;
  stick._codexBase={x:stick.x,y:stick.y};buttons._codexBase={x:buttons.x,y:buttons.y};
  if($gamePlayer&&$gamePlayer._characterName){
   ImageManager.loadCharacter($gamePlayer._characterName).addLoadListener(function(){
    if(scene.getChildByName('JoyStick')!==stick||!stick._D_Pad)return;
    var bitmap=stick._D_Pad.bitmap,r=stick._D_Pad._radius;
    bitmap.clear();bitmap.drawJoyStickInside(r,r,r,'rgba(255, 255, 255, 0.8)',true,true);stick._codexPortraitReady=true;
   });
  }
  // Rendering is the original APK implementation; Android input is routed once.
  stick.updateDirection=function(){};stick.processTouch=function(){};
  buttons.children.forEach(function(s){s.processTouch=function(){};});
  originalOverlay=document.createElement('div');originalOverlay.id='android-original-controls';
  originalOverlay.innerHTML='<div class="original-movement" role="group" aria-label="原版头像摇杆"></div><div class="original-actions"><button data-original-key="ok" aria-label="原版 A 确认"></button><button data-original-key="escape" aria-label="原版 B 返回"></button></div>';
  if(buttons.getChildByName('keyboardSave')){var el=document.createElement('button');el.dataset.originalKey='tilde';el.setAttribute('aria-label','原版 Save 存档');originalOverlay.appendChild(el);}
  document.body.appendChild(originalOverlay);installOriginalPointerHandlers();applyOriginalGeometry();
 }
 function syncOriginalControls(){
  var scene=SceneManager._scene;if(!scene)return;
  ConfigManager.ghostButtons=!!originalAvailable(scene);
  if(originalAvailable(scene)){
   // 【Codex·未经Claude检验】v0.08：战斗后新增覆盖层不遮挡原版按钮，残缺实例重建。
   if((!scene.getChildByName('JoyStick')||!scene.getChildByName('ghostButtons'))&&scene.createGhostButtons){
    if(scene.clearGhostButtons)scene.clearGhostButtons();scene.createGhostButtons();
   }
   attachOriginalControls(scene);
   if(originalScene===scene&&originalStick&&originalButtons){
    [originalStick,originalButtons].forEach(function(sprite){sprite.visible=true;sprite.renderable=true;if(sprite._hiding&&sprite.show)sprite.show();});
    var last=scene.children.length-1;
    if(scene.getChildIndex(originalButtons)!==last||scene.getChildIndex(originalStick)!==last-1){
     scene.setChildIndex(originalStick,last);scene.setChildIndex(originalButtons,last);
    }
   }
  }else{
   if(scene.getChildByName('JoyStick')&&scene.clearGhostButtons)scene.clearGhostButtons();
   if(originalOverlay)removeOriginalOverlay();
  }
 }

 function close(){
  if(layoutEditing)finishLayout();
  if(!panel)return;save();panel.remove();panel=null;release();syncOriginalControls();
  if(focusBefore&&focusBefore.isConnected)focusBefore.focus();focusBefore=null;
 }
 function open(){
  if(layoutEditing)finishLayout();
  if(panel)return;closeImport();release();focusBefore=document.activeElement;
  panel=document.createElement('div');panel.id='android-touch-settings';panel.className='android-port-dialog';
  panel.innerHTML='<section role="dialog" aria-modal="true" aria-labelledby="touch-settings-heading"><header><h2 id="touch-settings-heading">按键设置</h2><button data-close aria-label="关闭按键设置">关闭</button></header><fieldset class="stack"><legend>操作布局</legend><label><input type="radio" name="controller-style" value="modern">改版按键</label><label><input type="radio" name="controller-style" value="original">原版虚拟按钮</label></fieldset><p data-original-hint>原版使用头像摇杆和A/B按钮；可调大小、透明度和位置。</p><fieldset data-modern-mode><legend>移动方式</legend><label><input type="radio" name="touch-mode" value="joystick">轮盘</label><label><input type="radio" name="touch-mode" value="buttons">方向键</label></fieldset><fieldset class="stack"><legend>地图移动</legend><label><input type="radio" name="map-touch" value="tap">可点击屏幕移动</label><label><input type="radio" name="map-touch" value="controls">仅方向键／轮盘移动</label></fieldset><fieldset class="stack"><legend>战斗点击操作</legend><label><input type="radio" name="battle-touch" value="controls">仅屏幕按键</label><label><input type="radio" name="battle-touch" value="tap">按键＋屏幕点击</label></fieldset><p>仅影响战斗选项与目标选择，地图和商店保持原设置。</p><fieldset data-modern-actions><legend>右侧布局</legend><label><input type="radio" name="action-layout" value="ab">A／B 两键</label><label><input type="radio" name="action-layout" value="full">原多键</label></fieldset><label class="visible"><input type="checkbox" data-background>后台挂机</label><p data-background-hint>先在游戏中开启挂机，再打开此项。切到其他应用或锁屏仍继续游戏，并显示运行通知。强制关闭应用会停止挂机。</p><label class="visible"><input type="checkbox" data-visible>显示屏幕按键</label><label class="visible"><input type="checkbox" data-run>显示跑步键</label><label class="visible"><input type="checkbox" data-power>战力显示与估算</label>'+Object.keys(limits).map(function(k){var label={stick:'轮盘大小',pad:'方向键大小',buttons:'右侧按键大小',tools:'顶部按钮大小',transparency:'按键透明度'}[k];return '<label class="size-row" data-size-row="'+k+'">'+label+'<output data-value="'+k+'"></output><input type="range" data-size="'+k+'" aria-label="'+label+'" min="'+limits[k][0]+'" max="'+limits[k][1]+'" step="5"></label>';}).join('')+'<button class=position-button data-position>调整UI位置</button><p data-fit></p><footer><button data-reset>恢复默认</button><button data-done>完成</button></footer></section>';
  document.body.appendChild(panel);
  ['pointerdown','pointermove','pointerup','touchstart','touchmove','touchend','mousedown','mouseup','click','keydown','keyup'].forEach(function(type){panel.addEventListener(type,function(e){e.stopPropagation();});});
  // A game confirmation touch can finish after this dialog appears. Only
  // dismiss a backdrop gesture that actually began on the backdrop itself.
  var backdropDown=false;
  panel.addEventListener('pointerdown',function(e){backdropDown=e.target===panel;});
  panel.addEventListener('click',function(e){if(e.target===panel&&backdropDown)close();backdropDown=false;});
  panel.addEventListener('keydown',function(e){if(e.key==='Escape'){e.preventDefault();close();}});
  var visible=panel.querySelector('[data-visible]');visible.checked=!settings.hidden;
  visible.onchange=function(){settings.hidden=!visible.checked;apply();save();};
  var run=panel.querySelector('[data-run]');run.onchange=function(){settings.showRun=run.checked;apply();save();};
  var power=panel.querySelector('[data-power]');power.checked=CodexCombatPower.enabled();power.onchange=function(){CodexCombatPower.setEnabled(power.checked);ConfigManager.save();};
  function refresh(){run.checked=settings.showRun;panel.querySelectorAll('[name=controller-style]').forEach(function(input){input.checked=input.value===settings.controllerStyle;});panel.querySelector('[data-modern-mode]').hidden=originalSelected();panel.querySelector('[data-original-hint]').hidden=!originalSelected();panel.querySelector('[data-modern-actions]').hidden=originalSelected();panel.querySelector('[data-run]').closest('label').hidden=originalSelected();panel.querySelectorAll('[data-size]').forEach(function(input){var k=input.dataset.size;input.value=settings[k];panel.querySelector('[data-value="'+k+'"]').textContent=settings[k]+'%';});panel.querySelectorAll('[name=touch-mode]').forEach(function(input){input.checked=input.value===settings.mode;});panel.querySelectorAll('[name=map-touch]').forEach(function(input){input.checked=(input.value==='tap')===settings.mapTouch;});panel.querySelectorAll('[name=action-layout]').forEach(function(input){input.checked=input.value===settings.actionLayout;});panel.querySelectorAll('[name=battle-touch]').forEach(function(input){input.checked=(input.value==='tap')===settings.battleTouch;});panel.querySelector('[data-size-row=stick]').hidden=!originalSelected()&&settings.mode!=='joystick';panel.querySelector('[data-size-row=pad]').hidden=originalSelected()||settings.mode!=='buttons';}
  panel.querySelectorAll('[name=controller-style]').forEach(function(input){input.onchange=function(){release();removeOriginalOverlay();settings.controllerStyle=input.value;refresh();apply();save();};});
  panel.querySelectorAll('[name=touch-mode]').forEach(function(input){input.onchange=function(){settings.mode=input.value;refresh();apply();save();};});
  panel.querySelectorAll('[name=map-touch]').forEach(function(input){input.onchange=function(){settings.mapTouch=input.value==='tap';refresh();apply();save();};});
  panel.querySelectorAll('[name=action-layout]').forEach(function(input){input.onchange=function(){settings.actionLayout=input.value;refresh();apply();save();};});
  panel.querySelectorAll('[name=battle-touch]').forEach(function(input){input.onchange=function(){settings.battleTouch=input.value==='tap';if(!settings.battleTouch){settings.hidden=false;visible.checked=true;}refresh();apply();save();};});
  var background=panel.querySelector('[data-background]');background.checked=typeof AndroidInterface.backgroundenabled==='function'&&AndroidInterface.backgroundenabled();background.disabled=typeof AndroidInterface.setbackground!=='function';
  if(background.disabled)panel.querySelector('[data-background-hint]').textContent='请覆盖安装v0.03新版APK以启用后台挂机。';
  background.onchange=function(){AndroidInterface.setbackground(background.checked);};
  panel.querySelectorAll('[data-size]').forEach(function(input){input.oninput=function(){settings[input.dataset.size]=Number(input.value);refresh();apply();};input.onchange=save;});
  panel.querySelector('[data-reset]').onclick=function(){settings=normalized(defaults);visible.checked=true;background.checked=false;if(typeof AndroidInterface.setbackground==='function')AndroidInterface.setbackground(false);refresh();apply();save();};
  panel.querySelector('[data-position]').onclick=startLayout;
  panel.querySelector('[data-close]').onclick=panel.querySelector('[data-done]').onclick=close;
  refresh();apply();panel.querySelector('[data-close]').focus();
 }

 // Saved normalized positions survive display size, orientation and button-size changes.
 function bounds(el){
  if(!insetProbe){insetProbe=document.createElement('div');insetProbe.style.cssText='position:fixed;visibility:hidden;pointer-events:none;padding:env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left);';document.body.appendChild(insetProbe);}
  var c=getComputedStyle(insetProbe),r=el.getBoundingClientRect(),left=12+(parseFloat(c.paddingLeft)||0),top=6+(parseFloat(c.paddingTop)||0),right=12+(parseFloat(c.paddingRight)||0),bottom=12+(parseFloat(c.paddingBottom)||0);
  return {left:left,top:top,width:Math.max(0,innerWidth-left-right-r.width),height:Math.max(0,innerHeight-top-bottom-r.height)};
 }
 function applyPositions(){
  ['movement','actions','top'].forEach(function(k){var el=node.querySelector('.'+k),pos=settings.positions[k];
   if(!pos){['left','top','right','bottom'].forEach(function(p){el.style.removeProperty(p);});return;}
   var box=bounds(el);el.style.left=(box.left+pos.x*box.width)+'px';el.style.top=(box.top+pos.y*box.height)+'px';el.style.right='auto';el.style.bottom='auto';
  });
 }
 function endDrag(){
  if(!layoutDrag)return;var id=layoutDrag.pointer;layoutDrag=null;
  if(node.hasPointerCapture(id))node.releasePointerCapture(id);save();release();
 }
 function finishLayout(){
  if(!layoutEditing)return;endDrag();layoutEditing=false;
  if(layoutBar){layoutBar.remove();layoutBar=null;}node.classList.remove('layout-editing');apply();save();release();
 }
 function startLayout(){
  if(originalSelected()&&(SceneManager._scene instanceof Scene_Title)){AndroidInterface.message('请进入游戏后调整原版虚拟按钮的位置。');return;}
  close();closeImport();release();layoutEditing=true;node.classList.add('layout-editing');apply();
  layoutBar=document.createElement('div');layoutBar.id='android-layout-editor';layoutBar.innerHTML='<span>拖动移动区、右侧按键区或顶部工具栏</span><button data-layout-reset>重置位置</button><button data-layout-done>完成</button>';
  ['pointerdown','pointermove','pointerup','touchstart','touchmove','touchend','mousedown','mouseup','click'].forEach(function(type){layoutBar.addEventListener(type,function(e){e.stopPropagation();});});
  layoutBar.querySelector('[data-layout-reset]').onclick=function(){endDrag();settings.positions={movement:null,actions:null,top:null};settings.originalPositions={movement:null,actions:null};apply();save();};
  layoutBar.querySelector('[data-layout-done]').onclick=function(){finishLayout();open();};document.body.appendChild(layoutBar);
 }
 function setupPositionDrag(){
  node.addEventListener('pointerdown',function(e){
   if(!layoutEditing)return;e.preventDefault();e.stopImmediatePropagation();
   var el=e.target.closest('.movement,.actions,.top');if(!el||layoutDrag)return;
   var key=el.classList.contains('movement')?'movement':el.classList.contains('actions')?'actions':'top',r=el.getBoundingClientRect();
   layoutDrag={pointer:e.pointerId,key:key,el:el,x:e.clientX,y:e.clientY,left:r.left,top:r.top,box:bounds(el)};try{node.setPointerCapture(e.pointerId);}catch(_){}release();
  },true);
  node.addEventListener('pointermove',function(e){
   if(!layoutEditing)return;e.preventDefault();e.stopImmediatePropagation();var d=layoutDrag;if(!d||d.pointer!==e.pointerId)return;
   var box=d.box,x=Math.max(box.left,Math.min(box.left+box.width,d.left+e.clientX-d.x)),y=Math.max(box.top,Math.min(box.top+box.height,d.top+e.clientY-d.y));
   settings.positions[d.key]={x:box.width?(x-box.left)/box.width:0,y:box.height?(y-box.top)/box.height:0};applyPositions();
  },true);
  ['pointerup','pointercancel','lostpointercapture'].forEach(function(type){node.addEventListener(type,function(e){
   if(!layoutEditing)return;e.preventDefault();e.stopImmediatePropagation();if(layoutDrag&&layoutDrag.pointer===e.pointerId)endDrag();
  },true);});
  window.addEventListener('resize',function(){endDrag();if(layoutEditing)apply();});
  window.addEventListener('blur',function(){endDrag();release();});
  document.addEventListener('visibilitychange',function(){if(document.hidden&&layoutEditing)finishLayout();});
 }

 function importSave(){
  release();
  if(!(SceneManager._scene instanceof Scene_Title)){AndroidInterface.message('请先保存并返回标题，再导入存档。');return;}
  if(typeof AndroidInterface.importsavejson!=='function'){AndroidInterface.message('请覆盖安装支持JSON存档导入的新版手机版。');return;}
  AndroidInterface.importsavejson();
 }
 function closeImport(){if(savePanel){savePanel.remove();savePanel=null;release();if(saveFocus&&saveFocus.isConnected)saveFocus.focus();saveFocus=null;}}
 function exportSave(){
  release();
  if(!(SceneManager._scene instanceof Scene_Title)){AndroidInterface.message('请先保存并返回标题，再导出存档。');return;}
  if(typeof AndroidInterface.exportsavejson!=='function'){AndroidInterface.message('导出JSON需要覆盖安装v0.05新版APK；请保留应用和存档，不要卸载。');return;}
  close();closeImport();saveFocus=document.activeElement;
  savePanel=document.createElement('div');savePanel.id='android-save-export';savePanel.className='android-port-dialog';
  savePanel.innerHTML='<section role="dialog" aria-modal="true" aria-labelledby="save-export-heading"><header><h2 id="save-export-heading">导出JSON存档</h2><button data-export-cancel>取消</button></header><p>请选择已有存档。导出的是最近一次保存的进度，可用于手机重新导入。</p><label class="save-slot">导出存档<select data-export-slot aria-label="选择导出存档"></select></label><footer><button data-export-next>选择导出位置</button></footer></section>';
  var select=savePanel.querySelector('[data-export-slot]'),max=Math.min(200,DataManager.maxSavefiles()),count=0,global=DataManager.loadGlobalInfo()||[];
  for(var slot=1;slot<=max;slot++){if(!AndroidInterface.savefileexists('file'+slot+'.rpgsave'))continue;
   var option=document.createElement('option');option.value=slot;option.textContent='存档 '+String(slot).padStart(2,'0')+(global[slot]&&global[slot].playtime?' · '+global[slot].playtime:'');select.appendChild(option);count++;
  }
  if(!count){closeImport();AndroidInterface.message('还没有可导出的存档，请先在游戏中保存。');return;}
  document.body.appendChild(savePanel);
  ['pointerdown','pointermove','pointerup','touchstart','touchmove','touchend','mousedown','mouseup','click','keydown','keyup'].forEach(function(type){savePanel.addEventListener(type,function(e){e.stopPropagation();});});
  savePanel.querySelector('[data-export-cancel]').onclick=closeImport;
  savePanel.addEventListener('keydown',function(e){if(e.key==='Escape'){e.preventDefault();closeImport();}});
  savePanel.querySelector('[data-export-next]').onclick=function(){
   try{var id=Number(select.value),raw=StorageManager.load(id);if(typeof raw!=='string'||!raw)throw Error('存档为空或损坏');
    var data=JSON.parse(raw),keys=['system','screen','timer','switches','variables','selfSwitches','actors','party','map','player'];
    if(!keys.every(function(k){return data[k]&&typeof data[k]==='object'&&!Array.isArray(data[k]);}))throw Error('存档数据不完整');
    AndroidInterface.exportsavejson(id,JSON.stringify({format:'kyo-save-json-v1',game:'org.kyo.xiyou',releaseVersion:'v0.05',slot:id,exportedAt:new Date().toISOString(),data:data}));closeImport();
   }catch(e){AndroidInterface.message('存档未导出：'+String(e.message||e));}
  };
  select.focus();
 }
 function prepareJSONImport(){
  var text=AndroidInterface.claimimportjson();if(!text)return;
  if(!(SceneManager._scene instanceof Scene_Title)){AndroidInterface.message('请返回标题后重新导入。');return;}
  try{
   var value=JSON.parse(text),raw=value;
   if(value.format){if(value.format!=='kyo-save-json-v1'||value.game!=='org.kyo.xiyou')throw Error('这不是本游戏的JSON存档');raw=value.data;}
   var keys=['system','screen','timer','switches','variables','selfSwitches','actors','party','map','player'];
   if(!raw||Array.isArray(raw)||!keys.every(function(k){return raw[k]&&typeof raw[k]==='object'&&!Array.isArray(raw[k]);}))throw Error('JSON缺少完整的游戏存档数据');
   var portable=null;
   if(value.aux){
    if(typeof AndroidInterface.confirmimportjsonportable!=='function')throw Error('此JSON包含成长记录，请覆盖安装v0.05新版APK后导入');
    portable=value.aux;
    if(!portable||Array.isArray(portable)||Object.keys(portable).some(function(k){return k!=='crown'&&k!=='yunshang';}))throw Error('成长记录格式无效');
    ['crown','yunshang'].forEach(function(k){if(!portable[k])return;var record=portable[k],id=raw.system[k==='crown'?'_codexCrownProfile':'_yunProfile'];
     if(record.version!==(k==='crown'?1:2)||!record.profiles||Array.isArray(record.profiles)||Object.keys(record.profiles).some(function(p){return p!==id;}))throw Error('成长记录与存档不匹配');
     if(id&&!record.profiles[id])throw Error('JSON缺少该存档的成长记录');
    });
   }
   var json=JSON.stringify(raw),contents=JsonEx.parse(json);
   var types=[Game_System,Game_Screen,Game_Timer,Game_Switches,Game_Variables,Game_SelfSwitches,Game_Actors,Game_Party,Game_Map,Game_Player];
   if(!keys.every(function(k,i){return contents[k] instanceof types[i];})||!Array.isArray(contents.party._actors)||!Array.isArray(contents.actors._data))throw Error('存档的角色或地图格式无效');
   if(contents.party._actors.some(function(id){return !Number.isInteger(id)||!$dataActors[id]||!contents.actors._data[id];}))throw Error('存档包含当前版本没有的角色');
   var actors=contents.party._actors.slice(0,4).map(function(id){return contents.actors._data[id];});
   var seconds=Math.floor(Number(contents.system._framesOnSave||0)/60),pad=function(n){return String(n).padStart(2,'0');};
   var info={globalId:DataManager._globalId,title:$dataSystem.gameTitle,characters:actors.map(function(a){return [a._characterName,a._characterIndex];}),faces:actors.map(function(a){return [a._faceName,a._faceIndex];}),playtime:pad(Math.floor(seconds/3600))+':'+pad(Math.floor(seconds/60)%60)+':'+pad(seconds%60),timestamp:Date.now()};
   var payload=LZString.compressToBase64(json),max=Math.min(200,DataManager.maxSavefiles()),firstEmpty=1;
   close();closeImport();release();saveFocus=document.activeElement;
   savePanel=document.createElement('div');savePanel.id='android-save-import';savePanel.className='android-port-dialog';
   savePanel.innerHTML='<section role="dialog" aria-modal="true" aria-labelledby="save-import-heading"><header><h2 id="save-import-heading">导入JSON存档</h2><button data-import-cancel>取消</button></header><p>已检查存档格式。请选择存档槽位，下一步确认后导入。</p><label class="save-slot">导入位置<select data-import-slot aria-label="选择存档槽位"></select></label><footer><button data-import-next>下一步</button></footer></section>';
   var select=savePanel.querySelector('[data-import-slot]'),found=false;
   for(var i=1;i<=max;i++){var option=document.createElement('option'),exists=AndroidInterface.savefileexists('file'+i+'.rpgsave');option.value=i;option.textContent='存档 '+pad(i)+(exists?'（已有存档）':'（空）');select.appendChild(option);if(!exists&&!found){firstEmpty=i;found=true;}}
   select.value=firstEmpty;document.body.appendChild(savePanel);
   ['pointerdown','pointermove','pointerup','touchstart','touchmove','touchend','mousedown','mouseup','click','keydown','keyup'].forEach(function(type){savePanel.addEventListener(type,function(e){e.stopPropagation();});});
   var saveBackdropDown=false;
   savePanel.addEventListener('pointerdown',function(e){saveBackdropDown=e.target===savePanel;});
   savePanel.addEventListener('click',function(e){if(e.target===savePanel&&saveBackdropDown)closeImport();saveBackdropDown=false;});
   savePanel.addEventListener('keydown',function(e){if(e.key==='Escape'){e.preventDefault();closeImport();}});
   savePanel.querySelector('[data-import-cancel]').onclick=closeImport;
   savePanel.querySelector('[data-import-next]').onclick=function(){var slot=Number(select.value),global=DataManager.loadGlobalInfo()||[];global=global.slice();global[slot]=info;var compressed=LZString.compressToBase64(JSON.stringify(global));if(portable)AndroidInterface.confirmimportjsonportable(slot,payload,compressed,JSON.stringify(portable));else AndroidInterface.confirmimportjson(slot,payload,compressed);closeImport();};
   select.focus();
  }catch(e){closeImport();AndroidInterface.message('存档未导入：'+String(e.message||e));}
 }
 function titleVisible(on){if(!node)return;node.querySelector('[data-import-save]').hidden=!on||typeof AndroidInterface.importsavejson!=='function';node.querySelector('[data-export-save]').hidden=!on;apply();}
 function mount(root){
  if(node)return;node=root;
  var css=document.createElement('style');css.textContent=`
   #toaster{left:50%!important;top:50%!important;right:auto!important;transform:translate(-50%,-50%);width:min(640px,86vw)!important;text-align:center;pointer-events:none}
   #toaster > div{max-width:100%;box-sizing:border-box;overflow-wrap:anywhere}

   #android-controls.original-controls .movement,#android-controls.original-controls .actions{display:none!important}
   #android-original-controls{position:fixed;inset:0;z-index:89999;pointer-events:none;user-select:none;-webkit-user-select:none}
   #android-original-controls .original-movement,#android-original-controls .original-actions,#android-original-controls button{position:absolute;pointer-events:auto;touch-action:none;box-sizing:border-box}
   #android-original-controls .original-movement,#android-original-controls button{border-radius:50%}
   #android-original-controls button{opacity:0;border:0;padding:0;background:transparent}
   #android-original-controls.layout-editing .original-movement,#android-original-controls.layout-editing .original-actions{outline:2px dashed #ffd47a}
   #android-original-controls.layout-editing button{pointer-events:none}
   #android-controls.layout-editing .movement,#android-controls.layout-editing .actions,#android-controls.layout-editing .top{pointer-events:auto;touch-action:none;outline:2px dashed #ffd47a;cursor:move;box-shadow:0 0 0 3px #102335aa}
   #android-controls.layout-editing button,#android-controls.layout-editing .joystick,#android-controls.layout-editing .direction-pad{pointer-events:none}
   #android-controls.layout-editing .movement::before,#android-controls.layout-editing .actions::before,#android-controls.layout-editing .top::before{position:absolute;left:0;top:0;transform:translateY(-100%);color:#ffdc99;background:#102335e8;font:12px system-ui;padding:3px 6px;pointer-events:none;white-space:nowrap}
   #android-controls.layout-editing .movement::before{content:'移动区'}#android-controls.layout-editing .actions::before{content:'右侧按键'}#android-controls.layout-editing .top::before{content:'顶部工具'}
   #android-layout-editor{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:90004;display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:8px;width:max-content;max-width:92vw;padding:10px 14px;border:1px solid #93b0c1;border-radius:12px;background:#102335f2;color:#e6f1ff;font:13px system-ui;box-shadow:0 5px 20px #0006}
   #android-layout-editor span{flex-basis:100%;text-align:center}#android-layout-editor button{font:inherit;min-height:38px;color:inherit;background:#284b67;border:1px solid #93b0c1;border-radius:8px;padding:6px 12px;touch-action:manipulation}
   #android-touch-settings .position-button{width:100%;margin-top:8px}
   #android-controls .movement{width:var(--touch-move-width)!important;height:var(--touch-move-height)!important}
   #android-controls .joystick{width:var(--touch-stick)!important;height:var(--touch-stick)!important}
   #android-controls .joystick .knob{width:var(--touch-knob)!important;height:var(--touch-knob)!important}
   #android-controls .direction-pad{display:none;pointer-events:auto;touch-action:none;position:absolute;left:0;bottom:0;width:var(--touch-pad);height:var(--touch-pad);grid-template:repeat(3,var(--touch-pad-cell))/repeat(3,var(--touch-pad-cell));gap:var(--touch-pad-gap)}
   #android-controls.direction-buttons .joystick{display:none}#android-controls.direction-buttons .direction-pad{display:grid}
   #android-controls .direction-pad button{width:100%;height:100%;min-width:0;min-height:0;padding:0;font-size:var(--touch-pad-font)}
   #android-controls.direction-buttons .run{left:auto;right:0;top:0}
   #android-controls .actions{grid-template:var(--touch-action-height) var(--touch-action-height) var(--touch-confirm-height)/var(--touch-action-width) var(--touch-action-width);gap:var(--touch-gap)}
   #android-controls .actions button,#android-controls .run{min-width:0;min-height:0;padding:3px;font-size:var(--touch-font)}
   #android-controls .actions button{width:100%;height:100%}#android-controls:not(.layout-ab) .actions [data-key=ok]::after{content:' 确认';font-size:var(--touch-font)}#android-controls:not(.layout-ab) .actions [data-key=escape]::after{content:' 返回';font-size:var(--touch-font)}#android-controls .run{width:var(--touch-run);height:var(--touch-run);font-size:var(--touch-run-font)}
   #android-controls.layout-ab .actions{display:block;width:var(--touch-ab-width);height:var(--touch-ab-height)}
   #android-controls.layout-ab .actions button{display:none}
   #android-controls.layout-ab .actions [data-key=ok],#android-controls.layout-ab .actions [data-key=escape]{display:block;position:absolute;width:var(--touch-ab-size);height:var(--touch-ab-size);border-radius:50%;font-size:var(--touch-ab-font);font-weight:600;background:#27405a8c;border:2px solid #d7e6ef99}
   #android-controls.layout-ab .actions [data-key=ok]{left:0;bottom:0;color:#ccf6d8}
   #android-controls.layout-ab .actions [data-key=escape]{right:0;top:0;color:#c5e5ff}
   #android-controls .top button{min-width:0;min-height:var(--touch-top-height);font-size:var(--touch-top-font);padding:var(--touch-top-y) var(--touch-top-x);white-space:nowrap}
   #android-controls [hidden]{display:none!important}
   #android-touch-settings{position:fixed;top:0;right:0;bottom:0;left:0;inset:0;z-index:90002;display:flex;align-items:flex-start;justify-content:center;box-sizing:border-box;padding:4vh 0;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;background:#06101c66;color:#e6f1ff;font:14px system-ui;touch-action:pan-y}
   #android-touch-settings section{box-sizing:border-box;width:94vw;width:min(440px,94vw);max-height:92vh;max-height:92dvh;margin:auto;flex-shrink:0;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;touch-action:pan-y;padding:12px 16px;border:1px solid #718fa8;border-radius:16px;background:#102335f2;box-shadow:0 8px 30px #0007}
   #android-touch-settings header,#android-touch-settings footer{display:flex;align-items:center;justify-content:space-between;gap:12px}
   #android-touch-settings h2{font-size:19px;margin:0}#android-touch-settings button{color:inherit;background:#284b67;border:1px solid #93b0c1;border-radius:9px;padding:7px 14px;font:inherit;min-height:34px}
   #android-touch-settings .visible{display:flex;align-items:center;gap:8px;margin:9px 0}#android-touch-settings .visible input{width:20px;height:20px;margin:0;accent-color:#87c7ef}
   #android-touch-settings fieldset{display:flex;flex-wrap:wrap;gap:12px;border:0;padding:0;margin:9px 0}#android-touch-settings .stack{flex-direction:column;gap:6px}#android-touch-settings legend{float:left;margin-right:12px}#android-touch-settings fieldset label{display:flex;align-items:center;gap:5px}#android-touch-settings input[type=radio]{width:18px;height:18px;margin:0;accent-color:#87c7ef}
   #android-touch-settings [hidden]{display:none!important}
   #android-touch-settings .size-row{display:grid;grid-template-columns:1fr auto;gap:2px;margin:7px 0}#android-touch-settings input[type=range]{grid-column:1/-1;width:100%;margin:0;height:25px;accent-color:#87c7ef;touch-action:pan-x}
   @media (max-height:480px){#android-touch-settings{padding:2vh 0}#android-touch-settings section{max-height:96vh;max-height:96dvh;padding:8px 12px}#android-touch-settings h2{font-size:17px}#android-touch-settings fieldset,#android-touch-settings .visible{margin:5px 0}#android-touch-settings .size-row{margin:4px 0}#android-touch-settings p{margin:4px 0}#android-touch-settings button{min-height:30px;padding:5px 12px}}
   #android-touch-settings output{font-variant-numeric:tabular-nums}#android-touch-settings p{font-size:12px;color:#c1d3e1;margin:8px 0}
   #android-save-import .save-slot,#android-save-export .save-slot{display:grid;gap:8px;margin:16px 0}#android-save-import select,#android-save-export select{font:inherit;color:inherit;background:#284b67;border:1px solid #93b0c1;border-radius:9px;padding:10px;width:100%}
  `.replace(/#android-touch-settings/g,'.android-port-dialog');document.head.appendChild(css);
  node.querySelector('.actions [data-key=ok]').textContent='A';node.querySelector('.actions [data-key=ok]').setAttribute('aria-label','A 确认');node.querySelector('.actions [data-key=escape]').textContent='B';node.querySelector('.actions [data-key=escape]').setAttribute('aria-label','B 取消／返回');
  var button=document.createElement('button');button.textContent='导入存档';button.dataset.importSave='';button.onclick=importSave;
  node.querySelector('[data-tool]').after(button);button.hidden=typeof AndroidInterface.importsavejson!=='function';
  var exportButton=document.createElement('button');exportButton.textContent='导出存档';exportButton.dataset.exportSave='';exportButton.onclick=exportSave;button.after(exportButton);
  setupPositionDrag();
  node.querySelector('[data-toggle]').onclick=open;
  node.querySelector('[data-tool]').onclick=function(){release();if(SceneManager._scene instanceof Scene_Title)AndroidInterface.savetools();else AndroidInterface.message('请先保存并返回标题，再导入或导出存档。');};
  titleVisible(SceneManager._scene instanceof Scene_Title);
  window.addEventListener('resize',apply);
  new MutationObserver(function(){if(document.getElementById('codex-feedback')){close();closeImport();}}).observe(document.body,{childList:true});
 }
// 【Codex·未经Claude检验】v0.03：装备窗口点击释放时执行一次；拖动不确认。
 [Window_EquipSlot,Window_EquipItem].forEach(function(Type){var original=Type.prototype.processTouch;
  Type.prototype.processTouch=function(){
   if(!this.isOpenAndActive()){this._androidEquipTap=null;return original.apply(this,arguments);}
   if(TouchInput.isCancelled()){this._androidEquipTap=null;return original.apply(this,arguments);}
   var x=this.canvasToLocalX(TouchInput.x),y=this.canvasToLocalY(TouchInput.y),hit=this.hitTest(x,y);
   if(TouchInput.isTriggered()&&this.isTouchedInsideFrame()){
    if(hit<0){this._androidEquipTap=null;return original.apply(this,arguments);}
    if(hit!==this.index()&&this.isCursorMovable()){this.select(hit);SoundManager.playCursor();}
    this._androidEquipTap={index:hit,x:TouchInput.x,y:TouchInput.y,item:this.item(),actor:this._actor,slot:this._slotId,top:this.topRow(),cancelled:false};return;
   }
   var tap=this._androidEquipTap;if(!tap)return;
   var limit=14*Graphics.width/Math.max(1,innerWidth);
   if(Math.hypot(TouchInput.x-tap.x,TouchInput.y-tap.y)>limit||this.topRow()!==tap.top)tap.cancelled=true;
   if(TouchInput.isPressed()){this.onTouch(false);return;}
   this._androidEquipTap=null;
   if(TouchInput.isReleased()&&!tap.cancelled&&hit===tap.index&&this._actor===tap.actor&&this._slotId===tap.slot&&this.item()===tap.item&&this.isTouchOkEnabled())this.processOk();
  };
 });

 // 【Codex·未经Claude检验】 Menu repeat follows elapsed time, not accelerated logic frames.
 var navKeys=['up','down','left','right','pageup','pagedown'],nav={},navCycle=0,navBattle=false;
 function inBattleScene(){return SceneManager._scene instanceof Scene_Battle;}
 var selectionTypes=[Window_PartyCommand,Window_ActorCommand,Window_BattleSkill,Window_BattleItem,Window_BattleActor,Window_BattleEnemy];
 function battleWindow(win){return inBattleScene()&&selectionTypes.some(function(Type){return win instanceof Type;});}
 function resetNavigation(){nav={};navBattle=false;navCycle++;}
 var navClear=Input.clear;
 Input.clear=function(){resetNavigation();return navClear.apply(this,arguments);};
 var navUpdate=Input.update;
 Input.update=function(){
  var result=navUpdate.apply(this,arguments);navCycle++;
  if(!inBattleScene()){if(navBattle)resetNavigation();return result;}
  navBattle=true;var now=performance.now();
  navKeys.forEach(function(key){
   var state=nav[key]||(nav[key]={down:false,next:0,pulse:false,first:false});
   var pressed=Input.isPressed(key);state.pulse=false;state.first=false;
   if(!pressed){state.down=false;return;}
   if(!state.down){state.down=true;state.next=now+400;state.pulse=true;state.first=true;}
   else if(now>=state.next){state.next=now+100;state.pulse=true;}
  });return result;
 };
 var navRepeated=Input.isRepeated,navTriggered=Input.isTriggered;
 Input.isRepeated=function(key){
  if(inBattleScene()&&navKeys.indexOf(key)>=0)return !!(nav[key]&&nav[key].pulse);
  return navRepeated.apply(this,arguments);
 };
 Input.isTriggered=function(key){
  if(inBattleScene()&&navKeys.indexOf(key)>=0)return !!(nav[key]&&nav[key].pulse&&nav[key].first);
  return navTriggered.apply(this,arguments);
 };
 // Guard derived and inherited handlers together. A delegated base call is
 // part of the same move; a second outer call in one input cycle is ignored.
 var cursorReads=new WeakMap();
 [Window_Selectable,Window_BattleActor,Window_BattleEnemy].forEach(function(Type){
  if(!Object.prototype.hasOwnProperty.call(Type.prototype,'processCursorMove'))return;
  var original=Type.prototype.processCursorMove;
  Type.prototype.processCursorMove=function(){
   if(!battleWindow(this))return original.apply(this,arguments);
   var state=cursorReads.get(this);if(!state){state={cycle:-1,depth:0};cursorReads.set(this,state);}
   if(!state.depth&&state.cycle===navCycle)return;
   if(!state.depth)state.cycle=navCycle;state.depth++;
   try{return original.apply(this,arguments);}finally{state.depth--;}
  };
 });
 // Target sprites have their own touch overrides, so wrap those as well as
 // the shared list handler. Other battle tools and non-battle menus retain touch.
 [Window_Selectable,Window_BattleActor,Window_BattleEnemy].forEach(function(Type){
  if(!Object.prototype.hasOwnProperty.call(Type.prototype,'processTouch'))return;
  var original=Type.prototype.processTouch;
  Type.prototype.processTouch=function(){
   if(battleWindow(this)&&!settings.battleTouch){this._touching=false;return;}
   return original.apply(this,arguments);
  };
 });
 var battleWheel=Window_Selectable.prototype.processWheel;
 Window_Selectable.prototype.processWheel=function(){
  if(battleWindow(this)&&!settings.battleTouch)return;
  return battleWheel.apply(this,arguments);
 };

 var mapTouch=Scene_Map.prototype.processMapTouch;Scene_Map.prototype.processMapTouch=function(){if(!settings.mapTouch){this._touchCount=0;$gameTemp.clearDestination();return;}return mapTouch.apply(this,arguments);};
 window.addEventListener('kyo-background-setting',function(e){if(panel)panel.querySelector('[data-background]').checked=!!e.detail;});
 var sceneUpdate=SceneManager.updateScene;SceneManager.updateScene=function(){if(panel||savePanel||layoutEditing)return;var result=sceneUpdate.apply(this,arguments);syncOriginalControls();return result;};
 var back=AndroidPort.back;AndroidPort.back=function(){if(layoutEditing){finishLayout();open();return;}if(panel){close();return;}if(savePanel){closeImport();return;}return back.apply(this,arguments);};
 var start=Scene_Title.prototype.start;Scene_Title.prototype.start=function(){start.apply(this,arguments);titleVisible(true);};
 var terminate=Scene_Title.prototype.terminate;Scene_Title.prototype.terminate=function(){close();closeImport();titleVisible(false);return terminate.apply(this,arguments);};
 var commands=Window_Options.prototype.makeCommandList;Window_Options.prototype.makeCommandList=function(){commands.apply(this,arguments);this.addCommand('手机按键设置','codexAndroidControls');};
 var status=Window_Options.prototype.statusText;Window_Options.prototype.statusText=function(index){return this.commandSymbol(index)==='codexAndroidControls'?'调整':status.apply(this,arguments);};
 ['processOk','cursorLeft','cursorRight'].forEach(function(method){var original=Window_Options.prototype[method];Window_Options.prototype[method]=function(){if(this.commandSymbol(this.index())==='codexAndroidControls'){if(method==='processOk'){this.playOkSound();open();}return;}return original.apply(this,arguments);};});
 window.CodexAndroidTouch={useOriginalControls:function(){return originalAvailable(SceneManager._scene);},attachOriginalControls:attachOriginalControls,releaseOriginalControls:releaseOriginalControls,originalCanvasTouchAllowed:originalCanvasTouchAllowed,syncOriginalControls:syncOriginalControls,version:'v0.08',startLayout:startLayout,finishLayout:finishLayout,isLayoutEditing:function(){return layoutEditing;},mount:mount,open:open,close:close,importSave:importSave,exportSave:exportSave,prepareJSONImport:prepareJSONImport,settings:function(){return JSON.parse(JSON.stringify(settings));},effective:function(){return Object.assign({},effective);},isOpen:function(){return !!panel;},isImportOpen:function(){return !!savePanel;}};
})();
