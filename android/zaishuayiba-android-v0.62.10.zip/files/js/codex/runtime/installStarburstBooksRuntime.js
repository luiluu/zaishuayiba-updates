// 【Claude·未经Codex检验】v0.62.10 星爆气流斩三本被动书分开获得（Kyo 2026-11-01）。
// 帕奇只掉本体技能书；三本被动书改到神魔之塔：
// - 封弊者：8 层守层者胜利送一本（每个存档一次）。
// - 阐释者：13 层深渊·未知存在的不朽存在通关，每次 1/66；灭世、洪荒按难度系数上浮，最高 1/33。
//   由本模块掷骰，不吃掉率加成。
// - 流光闪：18 层守层者胜利送一本（每个存档一次）。
// 老存档已通过 8／18 层的，读档后补发一次。
window.CodexRuntime.register('installStarburstBooksRuntime', function() {
  'use strict';
  if (window.KyoStarburstBooks) return window.KyoStarburstBooks;
  var B = window.KyoStarburstBooks = {version: 1, GIFTS: {8: 1121, 18: 1161}, IMMORTAL_MAP: 152, IMMORTAL_BOOK: 1141,
    BASE_RATE: 1 / 66, MAX_RATE: 1 / 33};
  function state() {
    var s = $gameSystem._kyoStarburstBooks;
    if (!s || typeof s !== 'object') s = $gameSystem._kyoStarburstBooks = {};
    return s;
  }
  function toast(text) { if (window.$ && $.toaster) $.toaster({message: text}); }
  function give(id, why) {
    var item = $dataItems[id];
    if (!item) return;
    $gameParty.gainItem(item, 1);
    toast(why + '：获得' + item.name + '！');
  }
  function gift(floor, why) {
    var s = state(), id = B.GIFTS[floor];
    if (!id || s[floor]) return;
    s[floor] = 1;
    give(id, why);
  }
  // 天灾及以下 1/66；灭世、洪荒按真气路线系数（天灾 5、洪荒 13）线性上浮，洪荒到 1/33 封顶。
  B.immortalRate = function() {
    var Z = window.CodexZhenqi, coef = Z && Z.route ? Number(Z.route().coef) || 1 : 1;
    var r = B.BASE_RATE * (1 + Math.max(0, coef - 5) / 8);
    return Math.min(B.MAX_RATE, r);
  };
  function onVictory() {
    var Z = window.CodexZhenqi, b = Z && Z._battle;
    if (b && !b.trial && !b.scaled && b.guardianFloor && B.GIFTS[b.guardianFloor]) gift(b.guardianFloor, '第' + b.guardianFloor + '层守层者');
    var Y = window.CodexYunshang;
    if ($gameMap.mapId() === B.IMMORTAL_MAP && Y && Y.isImmortalClear && Y.isImmortalClear() && Math.random() < B.immortalRate())
      give(B.IMMORTAL_BOOK, '不朽存在');
  }
  var endBattle = BattleManager.endBattle;
  BattleManager.endBattle = function(result) {
    if (result === 0) { try { onVictory(); } catch (e) { console.error('[StarburstBooks]', e); } }
    return endBattle.apply(this, arguments);
  };
  // 老存档补发：当前路线已通过的层数够了就送，每个存档只送一次。
  var mapStart = Scene_Map.prototype.start;
  Scene_Map.prototype.start = function() {
    mapStart.apply(this, arguments);
    try {
      var Z = window.CodexZhenqi, passed = Z && Z.progressFloor ? Z.progressFloor() : 0;
      Object.keys(B.GIFTS).forEach(function(f) { if (passed >= Number(f)) gift(Number(f), '已通过第' + f + '层守层者'); });
    } catch (e) { console.error('[StarburstBooks]', e); }
  };
  return B;
});
