// Repeat each complete native draw event, with its own ticket cost and rules.
window.CodexRuntime.register('installCasinoBatchRuntime',function(){
 'use strict';
 var modes={single:{eventId:1432,cost:1,threshold:-30000,title:'自定义单抽',unit:'抽'},twenty:{eventId:1431,cost:20,threshold:-200000,title:'自定义20连抽',unit:'次20连抽'}};
 var C=window.CodexCasino={version:3,ticketId:1639,eventId:1432,session:null,lastResult:null};
 function stock(){return Math.max(0,Math.floor(Number($gameParty.numItems($dataItems[C.ticketId]))||0));}
 function maximum(mode){var rules=modes[mode||'single'];return rules?Math.floor(stock()/rules.cost):0;}
 C.maxCount=maximum;
 function nativeList(eventId){return $dataCommonEvents[eventId].list.map(function(command){
  var copy={code:command.code,indent:command.indent,parameters:command.parameters.slice()};
  if((copy.code===355||copy.code===655)&&!/if\(actor\)/.test(copy.parameters[0])&&/actor\.learnSkill\((8101|8102|8091)\)/.test(copy.parameters[0]))copy.parameters[0]=copy.parameters[0].replace('actor.learnSkill(','if(actor)actor.learnSkill(');
  return copy;
 });}
 function el(tag,text){var node=document.createElement(tag);if(text)node.textContent=text;return node;}
 function styleButton(button){button.style.cssText='padding:10px 18px;border:1px solid #8195a7;border-radius:6px;background:#344c60;color:white;font-size:17px;cursor:pointer';}
 C.open=function(parent,mode){
  mode=mode||'single';var rules=modes[mode];
  if(!rules||C.session||!(SceneManager._scene instanceof Scene_Map)||$gameMap.mapId()!==4)return false;
  var available=maximum(mode);
  if(!available){$gameMessage.add(mode==='twenty'?'20连抽至少需要20张肝帝积分抽奖券。':'肝帝积分抽奖券不足。');return false;}
  var s=C.session={parent:parent,scene:SceneManager._scene,mode:mode,rules:rules,state:'quantity',requested:0,used:0,second:0,proof:0,newProof:false,initialProof:$gameParty.members().some(a=>a.isLearnedSkill(8101)),points:$gameVariables.value(206),samples:[]};
  parent.setWaitMode('codexCasinoBatch');
  var overlay=s.dom=el('div'),panel=el('div'),title=el('h2',rules.title);
  overlay.id='codex-casino-batch';overlay.style.cssText='position:fixed;inset:0;z-index:10000;background:rgba(0,0,0,.66);display:flex;align-items:center;justify-content:center';
  panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');panel.setAttribute('aria-label',rules.title);
  panel.style.cssText='width:min(480px,85vw);padding:26px;border:1px solid #8b9cab;border-radius:14px;background:#17222e;color:#edf2f7;box-shadow:0 12px 50px #000';
  title.style.cssText='font-size:24px;margin:0 0 14px';panel.appendChild(title);
  var desc=el('p',mode==='twenty'?'每次消耗20张券，完整执行一次20连抽，逐次判定二阶段、欧皇之证及原生奖励。':'每抽消耗1张券，逐次判定二阶段与欧皇之证。');
  desc.textContent+='自动选择「赢下所有」，积分不足时停止。';desc.style.cssText='font-size:16px;line-height:1.7';panel.appendChild(desc);
  var label=el('label');label.htmlFor='codex-casino-count';panel.appendChild(label);
  var row=el('div');row.style.cssText='display:flex;gap:10px;align-items:center;margin:10px 0 14px';
  var input=s.input=el('input');input.id='codex-casino-count';input.type='number';input.min='1';input.max=String(available);input.step='1';input.value='1';input.setAttribute('aria-label',mode==='twenty'?'20连抽次数':'抽数');
  input.style.cssText='flex:1;min-width:0;box-sizing:border-box;padding:10px;font-size:22px;background:#0d1520;color:#fff;border:1px solid #76899c;border-radius:6px';row.appendChild(input);
  var max=s.max=el('button','MAX');max.id='codex-casino-max';max.type='button';max.setAttribute('aria-label','最大次数');styleButton(max);row.appendChild(max);panel.appendChild(row);
  var status=s.status=el('p');status.setAttribute('role','status');status.style.cssText='font-size:16px;min-height:24px';panel.appendChild(status);
  var buttons=el('div');buttons.style.cssText='display:flex;gap:12px;justify-content:flex-end';
  var cancel=s.cancel=el('button','取消'),ok=s.ok=el('button','开始抽取');
  [cancel,ok].forEach(function(button){button.type='button';styleButton(button);buttons.appendChild(button);});panel.appendChild(buttons);overlay.appendChild(panel);document.body.appendChild(overlay);
  function refreshLimit(){var n=maximum(mode);input.max=String(n);max.disabled=n<1;label.textContent=(mode==='twenty'?'20连抽次数':'抽数')+'（持有 '+stock()+' 张券，最多 '+n+(mode==='twenty'?' 次':' 抽')+'）';return n;}
  function preview(){var n=Number(input.value);status.textContent=Number.isSafeInteger(n)&&n>0?'共 '+(n*rules.cost)+' 抽，消耗 '+(n*rules.cost)+' 张券；积分门槛 '+rules.threshold+'。':'';}
  function confirm(){var n=refreshLimit(),value=Number(input.value);if(!Number.isSafeInteger(value)||value<1||value>n){status.textContent='请输入1～'+n+'之间的整数。';return;}C.begin(value);}
  max.addEventListener('click',function(){if(s.state!=='quantity')return;var n=refreshLimit();if(n<1){status.textContent='抽奖券不足。';return;}input.value=String(n);preview();input.focus();input.select();});
  input.addEventListener('input',preview);ok.addEventListener('click',confirm);
  cancel.addEventListener('click',function(){if(s.state==='quantity')C.finish('取消');else{s.stop=true;cancel.disabled=true;cancel.textContent='正在完成当前'+(mode==='twenty'?'20连抽':'一抽');}});
  overlay.addEventListener('keydown',function(event){event.stopPropagation();if(event.key==='Escape'){event.preventDefault();cancel.click();}else if(event.key==='Enter'&&s.state==='quantity'&&event.target===input){event.preventDefault();confirm();}},true);
  // Let the controls handle their own input before blocking MV's document listeners.
  ['pointerdown','pointerup','mousedown','mouseup','mousemove','touchstart','touchmove','touchend','wheel'].forEach(function(type){overlay.addEventListener(type,function(event){event.stopPropagation();});});
  refreshLimit();preview();Input.clear();TouchInput.clear();input.focus();input.select();return true;
 };
 C.begin=function(count){
  var s=C.session;if(!s||s.state!=='quantity'||!Number.isSafeInteger(count)||count<1||count>maximum(s.mode))return false;
  s.requested=count;s.state='drawing';if(s.input){s.input.disabled=true;s.max.disabled=true;s.ok.style.display='none';s.cancel.textContent='停止后续抽取';}Input.clear();TouchInput.clear();return true;
 };
 C.finish=function(reason){
  var s=C.session;if(!s)return;
  C.lastResult={mode:s.mode,eventId:s.rules.eventId,ticketsPerDraw:s.rules.cost,requested:s.requested,used:s.used,totalDraws:s.used*s.rules.cost,ticketsUsed:s.used*s.rules.cost,second:s.second,proof:s.proof,newProof:s.newProof,initialPoints:s.points,finalPoints:$gameVariables.value(206),pointChange:$gameVariables.value(206)-s.points,remaining:stock(),reason:reason,samples:s.samples};
  if(s.dom)s.dom.remove();C.session=null;s.parent.setWaitMode('');Input.clear();TouchInput.clear();
  if(s.used)$gameMessage.add(s.rules.title+'完成：'+s.used+'/'+s.requested+s.rules.unit+(s.mode==='twenty'?'（共 '+C.lastResult.totalDraws+' 抽）':'')+'\n二阶段 '+s.second+' 次，欧皇达标 '+s.proof+' 次'+(s.newProof?'（新获欧皇之证）':'')+'\n积分 '+s.points+' → '+C.lastResult.finalPoints+'（变化 '+(C.lastResult.pointChange>=0?'+':'')+C.lastResult.pointChange+'）；剩余券 '+stock()+(reason==='完成'?'':'\n停止原因：'+reason));
 };
 C.update=function(){
  var s=C.session;if(!s||s.state!=='drawing')return;
  if(SceneManager._scene!==s.scene||SceneManager.isSceneChanging()){if(!s.draw)C.finish('离开赌场');return;}
  var started=Date.now();
  for(var i=0;i<4&&Date.now()-started<8;i++){
   if(!s.draw){
    if(s.stop)return C.finish('已停止');if(s.used>=s.requested)return C.finish('完成');
    if(maximum(s.mode)<1)return C.finish('抽奖券不足');if($gameVariables.value(206)<s.rules.threshold)return C.finish('肝帝积分低于原'+(s.mode==='twenty'?'20连抽':'单抽')+'门槛');
    if(!$gameSwitches.value(2495))return C.finish('赌场已关闭');
    s.hitSecond=false;s.hitProof=false;s.draw=new Game_Interpreter();s.draw.setup(nativeList(s.rules.eventId),s.parent._eventId);s.draw._codexCasinoDraw=s;s.draw._codexCasinoRoot=true;
    $gameParty.loseItem($dataItems[C.ticketId],s.rules.cost);
   }
   var toaster=window.$&&$.toaster;
   try{if(toaster)$.toaster=function(){};s.draw.update();}finally{if(toaster)$.toaster=toaster;}
   if(s.draw.isRunning())break;
   s.used++;if(s.hitSecond)s.second++;if(s.hitProof)s.proof++;
   s.newProof=s.newProof||(!s.initialProof&&$gameParty.members().some(a=>a.isLearnedSkill(8101)));
   if(s.samples.length<20)s.samples.push({draw:s.used,second:s.hitSecond,proof:s.hitProof,points:$gameVariables.value(206)});
   s.draw=null;if(s.status)s.status.textContent='已完成 '+s.used+' / '+s.requested+s.rules.unit+'；二阶段 '+s.second+' 次';
  }
 };
 var wait=Game_Interpreter.prototype.updateWaitMode;
 Game_Interpreter.prototype.updateWaitMode=function(){if(this._waitMode==='codexCasinoBatch'){if(C.session&&C.session.parent===this)return true;this._waitMode='';return false;}return wait.apply(this,arguments);};
 var child=Game_Interpreter.prototype.setupChild;
 Game_Interpreter.prototype.setupChild=function(){var out=child.apply(this,arguments);if(this._codexCasinoDraw&&this._childInterpreter)this._childInterpreter._codexCasinoDraw=this._codexCasinoDraw;return out;};
 var text=Game_Interpreter.prototype.command101;
 Game_Interpreter.prototype.command101=function(){if(!this._codexCasinoDraw)return text.apply(this,arguments);while(this.nextEventCode()===401)this._index++;return true;};
 var choices=Game_Interpreter.prototype.command102;
 Game_Interpreter.prototype.command102=function(){if(!this._codexCasinoDraw)return choices.apply(this,arguments);if(this._codexCasinoRoot&&this._indent===5)this._codexCasinoDraw.hitSecond=true;this._branch[this._indent]=0;return true;};
 [212,230].forEach(function(code){var original=Game_Interpreter.prototype['command'+code];Game_Interpreter.prototype['command'+code]=function(){if(this._codexCasinoDraw&&this._codexCasinoRoot)return true;return original.apply(this,arguments);};});
 var learn=Game_Actor.prototype.learnSkill;
 Game_Actor.prototype.learnSkill=function(id){if(id===8101&&C.session&&C.session.draw)C.session.hitProof=true;return learn.apply(this,arguments);};
 var update=Scene_Map.prototype.update;
 Scene_Map.prototype.update=function(){var out=update.apply(this,arguments);C.update();return out;};
 // v0.62.10: abyss casino (1434) stage 2 read v1191-1195 before rerolling them; 20-draw leaves those at about ±30000. Roll first, then read.
 function fixAbyssStage2(events){
  var event=events&&events[1434];if(!event||!event.list)return;var list=event.list;
  for(var i=0;i+1<list.length;i++){
   var read=list[i],roll=list[i+1],slot=read.parameters[4];
   if(read.code===122&&roll.code===122&&read.parameters[0]===1197&&read.parameters[2]===0&&read.parameters[3]===1&&slot>=1191&&slot<=1195&&roll.parameters[0]===slot&&roll.parameters[3]===2){list[i]=roll;list[i+1]=read;i++;}
  }
 }
 C.fixAbyssStage2=fixAbyssStage2;
 var onLoad=DataManager.onLoad;
 DataManager.onLoad=function(object){var out=onLoad.apply(this,arguments);if(object===window.$dataCommonEvents)fixAbyssStage2(object);return out;};
 if(window.$dataCommonEvents)fixAbyssStage2(window.$dataCommonEvents);
});
