// 【Claude·未经Codex检验】v0.62.10 双持时专属武器只能装一把（Kyo 2026-11-01）。
// 专属武器＝带 <req_actors> 的武器（和出售保护的「专属」同一判定）；现有专武都只限一名角色，
// 能装上的都是这名角色的，所以名字不同的两把专武也只能装一把。
// - 换装列表：另一个武器栏已有专武时，其它专武变灰、点不了；同一栏里换专武不受影响。
// - 最强装备：第一栏挑了专武，第二栏跳过专武。
// - 老存档已同时装着两把：刷新时保留排在前面的一把，其余卸回背包，不会丢。
// - 例外：白晶晶（毒吻＋穿肠本就是一对双持专武，Kyo 2026-11-01：「白晶晶例外」）。
window.CodexRuntime.register('installDualExclusiveRuntime', function() {
  'use strict';
  if (window.KyoDualExclusive) return window.KyoDualExclusive;
  function isExclusive(item) {
    return !!(item && DataManager.isWeapon(item) &&
      ((item.meta && item.meta.req_actors != null) || /<req_actors\s*:/i.test(item.note || '')));
  }
  // 除 slotId 这一栏外，其它武器栏里是否已有专武。
  function otherHasExclusive(actor, slotId) {
    var slots = actor.equipSlots(), equips = actor.equips();
    for (var i = 0; i < equips.length; i++) if (i !== slotId && slots[i] === 1 && isExclusive(equips[i])) return true;
    return false;
  }
  var EXEMPT = { 76: true };
  function exempt(actor) { return !!EXEMPT[actor.actorId()]; }
  function blocked(actor, slotId, item) {
    return !exempt(actor) && isExclusive(item) && actor.equipSlots()[slotId] === 1 && otherHasExclusive(actor, slotId);
  }
  var D = window.KyoDualExclusive = { version: 'v0.62.10', exempt: EXEMPT, isExclusive: isExclusive, blocked: blocked };

  var change = Game_Actor.prototype.changeEquip;
  Game_Actor.prototype.changeEquip = function(slotId, item) {
    if (blocked(this, slotId, item)) return;
    return change.apply(this, arguments);
  };

  var bestSlot = null;
  var best = Game_Actor.prototype.bestEquipItem;
  Game_Actor.prototype.bestEquipItem = function(slotId) {
    var prior = bestSlot;
    bestSlot = slotId;
    try { return best.apply(this, arguments); } finally { bestSlot = prior; }
  };
  var canEquip = Game_BattlerBase.prototype.canEquip;
  Game_BattlerBase.prototype.canEquip = function(item) {
    if (bestSlot !== null && this.isActor() && blocked(this, bestSlot, item)) return false;
    return canEquip.apply(this, arguments);
  };

  var release = Game_Actor.prototype.releaseUnequippableItems;
  Game_Actor.prototype.releaseUnequippableItems = function(forcing) {
    var result = release.apply(this, arguments);
    if (exempt(this)) return result;
    var slots = this.equipSlots(), equips = this.equips(), kept = false;
    for (var i = 0; i < equips.length; i++) {
      if (slots[i] !== 1 || !isExclusive(equips[i])) continue;
      if (!kept) { kept = true; continue; }
      // 不论 forcing，都退回背包：这把是玩家原有的，不能凭空消失。
      this.tradeItemWithParty(null, equips[i]);
      this._equips[i].setObject(null);
    }
    return result;
  };

  var enabled = Window_EquipItem.prototype.isEnabled;
  Window_EquipItem.prototype.isEnabled = function(item) {
    if (this._actor && blocked(this._actor, this._slotId, item)) return false;
    return enabled.apply(this, arguments);
  };
  return D;
});
