// 【Claude·未经Codex检验】v0.62.11 解除眩晕、放逐等不能行动的状态（或复活）后插回行动条，也守每回合 5 次上限（Kyo 2026-11-01）。
// 原来 Olivia_BattleSysOTB 的 otbInsertActionOrders 按「行动次数－本回合已行动」整串插回，不经过上限：
// 云裳断锦·拆神净化队友的眩晕时，行动次数多的角色会在行动条上插出一长排。
// 上限与插件末尾一键修复的 MAX_TOTAL_ACTIONS 一致：本回合最多 5 次（含已行动的），下回合最多 5 次。
// 孤语再生走的也是这个入口，一并生效。
window.CodexRuntime.register('installOtbRestoreCapRuntime',function(){
 'use strict';
 var MAX=5;
 var old=BattleManager.otbInsertActionOrders;
 if(!old)return {skipped:true};
 BattleManager.otbInsertActionOrders=function(battler,array){
  if(!battler||!array||array.contains(battler)||!(window.Olivia&&Olivia.OctoBattle.OTB.AddedActionTimes))return old.apply(this,arguments);
  var current=array===this._actionBattlers,acted=Number(battler._otbTimesActedThisTurn)||0;
  var room=current?MAX-acted:MAX;
  if(room<=0)return;
  var times=Math.min(Math.max(battler.makeActionTimes()-acted,1),room);
  while(times--)array.push(battler);
  this.otbDisplayWindow().createReturnedBattlerSprite(battler,current);
 };
 return {max:MAX};
});
