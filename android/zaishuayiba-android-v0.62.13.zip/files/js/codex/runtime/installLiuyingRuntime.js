// 流萤 v0.62.03 角色运行时（数据公式 + 结算钩子 + 形态/护盾/印记）
// v0.62.08（Kyo 2026-11-01）：天火轰击、完全燃烧的说明按当前进阶阶数生成（第 15 节），不再写「X阶后变成…」；运行时 1.2.0。生命项系数 3110→3000。萨姆残核改由第 16 节按难度掉落（不受队伍掉落率影响）。
// v0.62.03（Kyo 2026-10-31）：击破印记不可驱散（只在引爆、目标死亡、战斗结束时消失）；引爆眩晕无视抗性，霸体照常免疫，
// 同一目标眩晕后 2 个自然回合内不再因引爆眩晕；逐火累计 2000 场后递减（不写进说明）。生命项系数维持 3888（v0.62.03 曾改 3305，已撤回）。
// 修订：Kyo 2026-10-31 定两招伤害整体 ×0.7（hiddenRate，不写进说明；引爆真伤不受影响）。
// v0.62.06：Kyo 2026-10-31 定生命项系数 3888→3110（×0.8，明改，说明与玩家日志同步写）。
// v0.60.02：号角 3063 进 Map132 不朽号角商店（与黄泉同一货架，见第 11 节末）。
// v0.61：新被动「梦应归于何处」（第 14 节，技能与状态按备注标签识别）；赤染之茧无视目标火焰、物理抗性 33%，受火焰、物理伤害各 -33%（说明与数值一致，改数值要同步改说明）。
// v0.60.01：冷却改按 $gameTroop.turnCount()；熟练度只由原生管线乘一次；负面免疫按状态备注判断；
// 印记随状态移除清层；再释放整次重放；完全燃烧不再清空队友期限护盾；引爆为不经护盾的真伤。
// 数据侧：10622 天火轰击、10623 完全燃烧 的 damage.formula 调用 CodexLiuying.damage。
// 结算侧：window.CodexDamageHooks 提供全部百分比乘区（makeDamageValue 是死链，不可用）。
window.CodexRuntime.register("installLiuyingRuntime", function(){
'use strict';

var C = window.CodexLiuying = {
  version: '1.2.0',
  actor: 179,
  classId: 177,
  skills: { tianhuo: 10622, ranshao: 10623 },
  passives: {
    pianShi: 10624, guoZai: 10625, ziXian: 10626, chiRan: 10627,
    zhuiLuo: 10628, xingHe: 10629, feiYing: 10630, changYe: 10631, mingTian: 10632
  },
  states: { mark: 2787, form: 2788, immune: 2789, undying: 2790 },
  stunState: 29,
  weapon: 4004,
  armor: 4582,
  horn: 3063,
  hpN: 3000,             // 生命项系数：v0.62.06 3888→3110（明改）；v0.62.08 Kyo 2026-11-01 定 3000（说明与玩家日志写 3000）
  stunLock: 2,           // v0.62.03：同一目标强制眩晕后锁定的自然回合数
  hiddenRate: 0.7,       // 两招伤害整体倍率，不写进说明（Kyo 2026-10-31）
  emberFull: 2000,       // v0.62.03：逐火满额场数，之后每场 10×2000/已胜场数
  damageN: 3888,         // 标定旋钮：v0.60.01 修复后按黄泉同条件重标，Kyo 定 3888，见 v0.60.01 README
  base: { 10622: 88000, 10623: 880000 },
  markMax: 12,
  explodeRate: 6,          // 引爆真伤 = 流萤最大生命 × 6
  shieldCap: 0.5,          // 三阶增盾上限：最大生命 50%
  hpCostRate: 0.05,
  reRelease: 0.2,          // 再释放概率
  cooldown: { 10623: 4 },  // 自然回合固定冷却
  fireflyMax: 30,          // 萤火印记上限
  fireflyRate: 0.1,        // 每层全队终伤 +10%
  chiRanRate: 0.33         // 赤染之茧：无视抗性与受伤减免（改这里要同步改技能说明）
};

var L = C;
var S = C.skills, P = C.passives, ST = C.states;

function is(a) { return !!(a && a.actorId && a.actorId() === C.actor); }
function learned(a, id) { return !!(a && a.isLearnedSkill && a.isLearnedSkill(id)); }
function rank(a) { return Number((a && a._AdvancedNum) || 0); }
function lbSkill(id) { return id === S.tianhuo || id === S.ranshao; }
function enemy(b) { return b && (b.isEnemy ? b.isEnemy() : !!b._enemyId); }
function alive(b) { return b && b.isAlive && b.isAlive(); }
function baseId(i) { return Number(i && (i.originalBaseItemId || i.baseItemId || i.id)); }
function equippedArmor(a) {
  var items = a && a.equips ? a.equips() : [];
  for (var i = 0; i < items.length; i++) if (baseId(items[i]) === C.armor) return items[i];
  return null;
}
function equippedWeapon(a) {
  var items = a && a.equips ? a.equips() : [];
  for (var i = 0; i < items.length; i++) if (baseId(items[i]) === C.weapon) return items[i];
  return null;
}
function turnNow() { return (window.$gameTroop && $gameTroop.turnCount) ? Number($gameTroop.turnCount()) || 0 : 0; }
function hyperArmor(t) {
  return !!(window.CodexBossDifficulty && CodexBossDifficulty.hasHyperArmor && CodexBossDifficulty.hasHyperArmor(t));
}
function toast(text) {
  if (window.$ && $.toaster) $.toaster({ message: text });
  else if (window.$gameMessage) $gameMessage.add(text);
}
function refreshWindow() {
  var scene = SceneManager._scene;
  if (scene && scene._statusWindow && scene._statusWindow.refresh) scene._statusWindow.refresh();
}

// ── 1. 伤害原始值（数据公式入口；AI 预览同样调用这里） ─────────────────
// 技能熟练度由原生伤害管线按 YEP 熟练度公式乘一次，这里不再重复乘。
L.damage = function(a, b, id) {
  if (!a) return 0;
  var base = C.base[id] || 0;
  if (!base && !C.base.hasOwnProperty(id)) return 0;
  var mhp = Math.max(0, Number(a.mhp) || 0);
  var atk = Math.max(0, Number(a.atk) || 0);
  var agi = Math.max(0, Number(a.agi) || 0);
  var shield = a._codexLbCastShield != null ? Math.max(0, Number(a._codexLbCastShield) || 0)
    : Math.max(0, Number(a.shield) || 0);
  var n = Number(C.damageN) || 0;
  var hn = C.hpN != null ? Number(C.hpN) || 0 : n;
  var raw = ((base + mhp * hn + atk * n) + (agi + shield * n)) * (C.hiddenRate != null ? Number(C.hiddenRate) : 1);
  if (!isFinite(raw) || raw <= 0) return 1;
  return Math.round(raw);
};

window.CodexAIEstimators = window.CodexAIEstimators || [];
window.CodexAIEstimators.push(function(actor, target, item, action, formula) {
  if (item && is(actor) && lbSkill(item.id) && /CodexLiuying\.damage\(a,b,1062[23]\)/.test(String(formula || ''))) {
    return L.damage(actor, target, item.id);
  }
  return undefined;
});

// 赤染之茧减免的伤害类型判定
function fireOrPhysical(subject, item) {
  var ids = [], e = Number(item.damage.elementId);
  if (e > 0) ids.push(e);
  if (e < 0) ids = ids.concat(subject && subject.attackElements ? subject.attackElements() : []);
  if (item.multipleElements) ids = ids.concat(item.multipleElements);
  if (ids.indexOf(2) >= 0) return true;
  return item.hitType === 1 && ids.indexOf(1) >= 0;
}

// ── 2. 乘区钩子 ────────────────────────────────────────────────────────
window.CodexDamageHooks = window.CodexDamageHooks || [];
window.CodexDamageHooks.push({
  name: 'liuying', build: function(action, target, f) {
    var a = action && action.subject && action.subject();
    var item = action && action.item && action.item();
    if (!a || !item) return;
    if (is(a) && lbSkill(item.id)) {
      f.mode = 'physical';
      // 赤染之茧：无视目标火焰、物理抗性
      if (learned(a, P.chiRan)) {
        f.physicalIncomingPierce = Math.max(Number(f.physicalIncomingPierce) || 0, C.chiRanRate);
        var byEl = Object.assign({}, f.resistancePierceByElement || {});
        byEl[2] = Math.max(Number(byEl[2]) || 0, C.chiRanRate * 100);
        f.resistancePierceByElement = byEl;
      }
      if (learned(a, P.ziXian)) {                                                 // 火焰、物理伤害各 +200%
        f.elementAdd[2] = (f.elementAdd[2] || 0) + 2;
        f.elementAdd[1] = (f.elementAdd[1] || 0) + 2;
      }
      if (equippedArmor(a)) f.skillMultiplier = (f.skillMultiplier || 1) * 4;   // 独特技能增伤 +300%
      if (learned(a, P.zhuiLuo)) f.finalAdd = (f.finalAdd || 0) + 2;            // 终伤 +200%
      if (learned(a, P.changYe)) f.finalAdd = (f.finalAdd || 0) + 3;            // 终伤 +300%
      var weapon = equippedWeapon(a);
      if (weapon && a.level) {
        var lost = Math.floor(Math.max(0, Number(a.mhp) || 0) / 10000);
        if (lost > 0) f.finalAdd = (f.finalAdd || 0) + lost * 0.01;             // 失熵
      }
      if (item.id === S.tianhuo && learned(a, P.xingHe)) f.skillMultiplier = (f.skillMultiplier || 1) * 5;
      if (item.id === S.ranshao && learned(a, P.feiYing)) f.skillMultiplier = (f.skillMultiplier || 1) * 1.5;
      if (action._codexLbSingleBonus) f.skillMultiplier = (f.skillMultiplier || 1) * action._codexLbSingleBonus;
      if (action._codexLbSpread) f.skillMultiplier = (f.skillMultiplier || 1) * action._codexLbSpread;
    }
    // 目标身上有击破印记：全队对该目标的伤害易伤，最多 120%
    var marks = L.markCount(target);
    if (marks > 0) f.skillMultiplier = (f.skillMultiplier || 1) * (1 + 0.1 * Math.min(C.markMax, marks));
    // 流萤自身受到火焰、物理伤害减免（双属性只减一次）
    if (is(target) && learned(target, P.chiRan) && item.damage && fireOrPhysical(a, item)) {
      f.incomingMultiplier = (f.incomingMultiplier || 1) * (1 - C.chiRanRate);
    }
    // 萤火印记：全队行动者终伤 +10%/层
    var ff = L.fireflyCount();
    if (ff > 0 && a.isActor && a.isActor()) f.finalAdd = (f.finalAdd || 0) + C.fireflyRate * ff;
  }
});

// ── 3. 命中/暴击/段数 ─────────────────────────────────────────────────
function guaranteed(action) {
  var a = action && action.subject(), item = action && action.item();
  return !!(is(a) && item && lbSkill(item.id));
}
var oldItemHit = Game_Action.prototype.itemHit;
Game_Action.prototype.itemHit = function(target) { return guaranteed(this) ? 1 : oldItemHit.call(this, target); };
var oldItemEva = Game_Action.prototype.itemEva;
Game_Action.prototype.itemEva = function(target) { return guaranteed(this) ? 0 : oldItemEva.call(this, target); };
// 爆伤沿用原生 150%（伤害管线自行结算暴击，不再覆写 applyCritical）。
var oldRepeats = Game_Action.prototype.numRepeats;
Game_Action.prototype.numRepeats = function() {
  var a = this.subject(), item = this.item();
  if (is(a) && item && lbSkill(item.id)) {
    if (this._codexLbRepeats == null) {
      this._codexLbRepeats = item.id === S.tianhuo
        ? 5 + (learned(a, P.xingHe) ? 3 : 0)
        : 9;
    }
    return this._codexLbRepeats;
  }
  return oldRepeats.call(this);
};

// ── 4. 印记（层数存在目标私有字段，状态只作标记） ─────────────────────
// 层数只在目标带着击破印记状态时有效；状态被驱散或移除时同时清层。
L.markCount = function(t) {
  if (!t || !t.isStateAffected || !t.isStateAffected(ST.mark)) return 0;
  return Math.max(0, Number(t._codexLbMark) || 0);
};
L.addMark = function(actor, target, count) {
  if (!target || !alive(target) || !enemy(target) || count <= 0) return;
  if (!target.isStateAffected(ST.mark)) {
    target._codexLbMark = 0;
    target.addState(ST.mark);
    if (!target.isStateAffected(ST.mark)) return;
  }
  var now = Math.min(C.markMax, L.markCount(target) + count);
  target._codexLbMark = now;
  if (now >= C.markMax) L.explode(actor, target);
  refreshWindow();
};
L.explode = function(actor, target) {
  target._codexLbMark = 0;
  markRemoving = true;
  try { if (target.isStateAffected(ST.mark)) target.removeState(ST.mark); } finally { markRemoving = false; }
  // 固定真伤：直接扣生命，不经护盾与治疗修正
  var dmg = Math.floor(Math.max(0, Number(actor && actor.mhp) || 0) * C.explodeRate);
  if (dmg > 0 && alive(target)) target.setHp(Math.max(0, target.hp - dmg));
  // 眩晕无视状态抵抗与有效度；霸体照常免疫；同一目标眩晕后 stunLock 个自然回合内不再眩晕
  var now = turnNow();
  if (alive(target) && !hyperArmor(target) && !(Number(target._codexLbStunLock) >= now)) {
    if (!target.isStateAffected(C.stunState)) target.addNewState(C.stunState);
    if (target.isStateAffected(C.stunState)) {
      target._codexLbForcedStun = true;
      target.resetStateCounts(C.stunState);
      target._codexLbStunLock = now + C.stunLock;
      target.refresh();
    }
  }
  toast('击破印记引爆！');
  refreshWindow();
};

// 印记只挂在敌人身上；Game_Enemy 自有 removeState（其他模块覆写过），所以挂在 Game_Enemy 上。
// v0.62.03：印记不可驱散。战斗中、目标未死时，移除、抹除、清空状态都保留印记和层数；只有引爆（markRemoving）放行。
var markRemoving = false;
function hasMark(b) { return !!(b && b._states && b._states.indexOf(ST.mark) >= 0); }
function markLocked(b) { return !markRemoving && hasMark(b) && Number(b._hp) > 0 && !!(window.$gameParty && $gameParty.inBattle()); }
var oldRemoveState = Game_Enemy.prototype.removeState;
Game_Enemy.prototype.removeState = function(stateId) {
  if (stateId === ST.mark && markLocked(this)) return;
  var v = oldRemoveState.apply(this, arguments);
  if (stateId === ST.mark && !this.isStateAffected(ST.mark)) this._codexLbMark = 0;
  return v;
};

var oldEraseState = Game_Enemy.prototype.eraseState;
Game_Enemy.prototype.eraseState = function(stateId) {
  if (stateId === ST.mark && markLocked(this)) return;
  return oldEraseState.apply(this, arguments);
};
var oldClearStates = Game_Enemy.prototype.clearStates;
Game_Enemy.prototype.clearStates = function() {
  var keep = markLocked(this) ? { n: this._codexLbMark, turns: this._stateTurns ? this._stateTurns[ST.mark] : 0 } : null;
  var v = oldClearStates.apply(this, arguments);
  if (keep && this._states && this._states.indexOf(ST.mark) < 0) {
    this._states.push(ST.mark);
    if (this._stateTurns) this._stateTurns[ST.mark] = keep.turns || 0;
    if (this.sortStates) this.sortStates();
    this._codexLbMark = keep.n;
  }
  return v;
};
// 引爆的强制眩晕：原生 refresh 会抹掉目标抵抗的状态，这里在眩晕持续期间把它从抵抗列表里拿掉；眩晕结束后恢复原抵抗。
var oldStateResistSet = Game_Enemy.prototype.stateResistSet;
Game_Enemy.prototype.stateResistSet = function() {
  var list = oldStateResistSet.apply(this, arguments);
  if (this._codexLbForcedStun) {
    if (this._states && this._states.indexOf(C.stunState) >= 0) return list.filter(function(id) { return id !== C.stunState; });
    this._codexLbForcedStun = false;
  }
  return list;
};

// ── 5. 护盾与生命费用 ─────────────────────────────────────────────────
L.amount = function(a) { return Math.max(0, Number(a && a.shield) || 0); };
function payHp(actor) {
  var hp = Math.max(0, Number(actor.hp) || 0);
  var cost = Math.min(Math.floor(hp * C.hpCostRate), Math.max(0, hp - 1));
  if (cost <= 0) return 0;
  actor._hp = hp - cost;
  actor.refresh();
  L.noteHpLoss(actor);
  if (actor.startDamagePopup) actor.startDamagePopup();
  return cost;
}
function shieldBonus(actor) {
  return Math.max(0, Number(actor.shieldEffectBonus && actor.shieldEffectBonus()) || 0);
}

// ── 6. 主要结算流程 ───────────────────────────────────────────────────
var oldApply = Game_Action.prototype.apply;
Game_Action.prototype.apply = function(target) {
  var item = this.item(), actor = this.subject();
  if (!item || !actor) return oldApply.call(this, target);
  if (!(is(actor) && lbSkill(item.id))) return oldApply.call(this, target);

  var first = !this._codexLbStarted;
  if (first) {
    this._codexLbStarted = true;
    actor._codexLbCastShield = L.amount(actor);
    var singles = $gameTroop.aliveMembers().length === 1;
    if (item.id === S.tianhuo) {
      // 5% 当前生命转护盾：绕过护盾、至少留 1HP、按实际扣血转盾（吃护盾加成）
      var paid = payHp(actor);
      if (paid > 0) { actor._shield = Math.max(0, (Number(actor._shield) || 0) + Math.floor(paid * (1 + shieldBonus(actor)))); refreshWindow(); }
      if (singles) this._codexLbSingleBonus = 1.2;
    } else {
      var snapshot = actor._codexLbCastShield;
      if (rank(actor) >= 3) {
        // 三阶：不消耗，改为增加等量护盾；按施放前护盾、不吃加成、上限 50% 最大生命
        var add = Math.min(Math.floor(snapshot), Math.floor(actor.mhp * C.shieldCap));
        if (add > 0) { actor._shield = Math.max(0, (Number(actor._shield) || 0) + add); refreshWindow(); }
      } else {
        if (snapshot > 0) {
          actor.addShield(-snapshot);   // 只消耗自身原生护盾；队友给的期限护盾（护盾账本）保留
          refreshWindow();
        }
      }
      actor.setHp(actor.mhp);
      if (singles) this._codexLbSingleBonus = 1.5;
      // 冷却：按自然回合；三阶 3 回合；三阶 33% 不进冷却（每次施放只抽一次）
      var cd = C.cooldown[S.ranshao] || 4;
      if (rank(actor) >= 3) { cd = Math.max(0, cd - 1); if (Math.random() < 0.33) cd = 0; }
      if (cd > 0) actor._codexLbRsReady = turnNow() + cd;
      else actor._codexLbRsReady = 0;
    }
    // 再释放：每次主动施放抽一次，抽中则整次重放（每段、扩散、单目标额外段都再结算一次；不叠印记、不重复收费与冷却）
    this._codexLbReReleaseOn = Math.random() < C.reRelease;
  }

  segment(this, target, item, actor, false);
  if (this._codexLbReReleaseOn) {
    this._codexLbReRelease = true;
    try { segment(this, target, item, actor, true); } finally { this._codexLbReRelease = false; }
  }
};

function segment(action, target, item, actor, replay) {
  oldApply.call(action, target);
  var hit = !!(target.result && target.result().isHit());
  if (hit && !replay && !action._codexLbMarkDone) {
    action._codexLbMarkDone = true;
    L.addMark(actor, target, item.id === S.tianhuo ? 1 : 5);
  }
  // 天火：其他敌人受 50% 扩散
  if (item.id === S.tianhuo) {
    $gameTroop.aliveMembers().forEach(function(other) {
      if (other === target) return;
      action._codexLbSpread = 0.5;
      try { oldApply.call(action, other); } finally { action._codexLbSpread = 0; }
      if (other.result && other.result().isHit()) other.startDamagePopup();
    });
  }
  // 完全燃烧单目标：额外 4 段，整体 ×1.5（重放时同样补 4 段）
  var flag = replay ? '_codexLbExtraDoneReplay' : '_codexLbExtraDone';
  if (item.id === S.ranshao && $gameTroop.aliveMembers().length === 1 && !action[flag]) {
    action[flag] = true;
    for (var i = 0; i < 4; i++) oldApply.call(action, target);
    target.startDamagePopup();
  }
}

// 印记：受到治疗 -10%/层，最低 0%
var oldGainHp = Game_Battler.prototype.gainHp;
Game_Battler.prototype.gainHp = function(value) {
  var marks = value > 0 ? Math.min(C.markMax, L.markCount(this)) : 0;
  if (marks > 0) {
    value = Math.floor(value * Math.max(0, 1 - 0.1 * marks));
  }
  return oldGainHp.call(this, value);
};

// ── 7. 属性与被动 ─────────────────────────────────────────────────────
var oldParam = Game_Actor.prototype.param;
Game_Actor.prototype.param = function(paramId) {
  var v = oldParam.call(this, paramId);
  if (is(this)) {
    if (paramId === 0) {
      var hpRate = 1;
      if (learned(this, P.ziXian)) hpRate += 1.5;
      if (learned(this, P.zhuiLuo)) hpRate += 2;
      if (learned(this, P.mingTian)) hpRate += 3;
      v = Math.floor(v * hpRate);
    }
    if (paramId === 6) {
      var agiRate = 1;
      if (learned(this, P.guoZai)) agiRate += 0.3;
      if (learned(this, P.mingTian)) agiRate += 2;
      v = Math.floor(v * agiRate);
    }
    if (paramId === 2 && learned(this, P.guoZai)) v += 5000;
  }
  return v;
};
var oldShieldBonus = Game_Battler.prototype.shieldEffectBonus;
Game_Battler.prototype.shieldEffectBonus = function() {
  var v = oldShieldBonus.call(this);
  if (is(this) && learned(this, P.ziXian)) v += 1;
  return v;
};

// 再动：基础 30%（职业 trait）＋被动 30% 分开抽签；法宝与一阶各固定 +1
var oldActionPlus = Game_Actor.prototype.actionPlusSet;
Game_Actor.prototype.actionPlusSet = function() {
  var rates = oldActionPlus.call(this);
  if (is(this)) {
    if (learned(this, P.guoZai)) rates.push(0.3);
    if (equippedArmor(this)) rates.push(1);
    if (rank(this) >= 1) rates.push(1);
  }
  return rates;
};

// ── 8. 形态（战斗内固定萨姆 SV；只换外观 + 再动，不改属性） ─────────────
var oldBattlerName = Game_Actor.prototype.battlerName;
Game_Actor.prototype.battlerName = function() {
  if (is(this) && this.isStateAffected(ST.form)) return 'Codex_Sam_SV';
  return oldBattlerName.call(this);
};
L.enterForm = function(a) {
  if (!is(a) || !equippedArmor(a) || !$gameParty.inBattle()) return;
  if (!a.isStateAffected(ST.form)) a.addState(ST.form);
  if (learned(a, P.feiYing)) {
    a.addState(ST.immune);
    a.addState(ST.undying);
  }
};
L.clearForm = function(a) {
  if (!is(a)) return;
  [ST.form, ST.immune, ST.undying].forEach(function(id) { if (a.isStateAffected(id)) a.removeState(id); });
  delete a._codexLbEmberBattle;
  delete a._codexLbMark;
  delete a._lbBattleStarted;
  a._codexLbRsReady = 0;
};
L.refreshUndying = function(a) {
  if (!learned(a, P.feiYing)) return;
  if (a.isStateAffected(ST.immune)) a.removeState(ST.immune);
  if (a.isStateAffected(ST.undying)) a.removeState(ST.undying);
  a.addState(ST.immune);
  a.addState(ST.undying);
};

// ── 9. 通用状态钩子：负面免疫 ─────────────────────────────────────────
// 负面状态按状态备注判断（不写死 ID）：有 <BuffType> 的按类型；没有的按行动限制或状态名。
var NEGATIVE_TYPE = /毒|灼伤|损伤|眩晕|睡眠|混乱|沉默|麻痹|破甲|疾病|减益|天灾|暗黑|黑暗|致盲|冰封|冰冷|过冷|溺水|魅惑|愤怒|禁咒|变形|封印|诅咒|流血|持续伤害/;
function isNegative(stateId) {
  if (!stateId || stateId === 1) return false;
  var st = window.$dataStates && $dataStates[stateId];
  if (!st) return false;
  var m = /<BuffType:\s*([^>]+)>/i.exec(st.note || '');
  if (m) return NEGATIVE_TYPE.test(m[1]);
  if (Number(st.restriction) > 0) return true;
  return NEGATIVE_TYPE.test(st.name || '');
}
var oldAddState = Game_Battler.prototype.addState;
Game_Battler.prototype.addState = function(stateId) {
  if (is(this) && this.isStateAffected(ST.immune) && isNegative(stateId)) return;
  return oldAddState.call(this, stateId);
};
// 负面免疫的兜底：部分模块会绕过 addState/isStateAddable 直接写状态，这里在刷新时清掉负面状态。
var oldRefresh = Game_Battler.prototype.refresh;
Game_Battler.prototype.refresh = function() {
  var v = oldRefresh.call(this);
  if (is(this) && this.isStateAffected(ST.immune) && !this._codexLbCleaning) {
    this._codexLbCleaning = true;
    try {
      (this._states || []).slice().forEach(function(id) {
        if (id !== ST.immune && isNegative(id)) this.removeState(id);
      }, this);
    } finally { delete this._codexLbCleaning; }
  }
  return v;
};
var oldIsStateAddable = Game_Battler.prototype.isStateAddable;
Game_Battler.prototype.isStateAddable = function(stateId) {
  if (is(this) && this.isStateAffected(ST.immune) && isNegative(stateId)) return false;
  return oldIsStateAddable.call(this, stateId);
};

// ── 10. 战斗生命周期 ─────────────────────────────────────────────────
var oldSetup = Game_Actor.prototype.setup;
Game_Actor.prototype.setup = function(actorId) {
  var v = oldSetup.call(this, actorId);
  if (is(this) && $gameParty && $gameParty.inBattle()) L.enterForm(this);
  return v;
};
var oldStartBattle2 = BattleManager.startBattle;
BattleManager.startBattle = function() {
  if ($gameTroop) $gameTroop._codexLbFirefly = 0;
  var v = oldStartBattle2.call(this);
  $gameParty.battleMembers().forEach(function(a) {
    if (!is(a)) return;
    if (equippedArmor(a) && !a.isStateAffected(ST.form)) a.addState(ST.form);
    if (learned(a, P.feiYing)) { if (!a.isStateAffected(ST.immune)) a.addState(ST.immune); if (!a.isStateAffected(ST.undying)) a.addState(ST.undying); }
  });
  return v;
};
var oldMakeActions = Game_Actor.prototype.makeActions;
Game_Actor.prototype.makeActions = function() {
  if (is(this) && $gameParty.inBattle() && !this._lbBattleStarted) {
    this._lbBattleStarted = true;
    if (equippedArmor(this) && !this.isStateAffected(ST.form)) this.addState(ST.form);
    if (learned(this, P.feiYing)) { this.addState(ST.immune); this.addState(ST.undying); }
  }
  return oldMakeActions.call(this);
};
var oldOnBattleStart = Game_Actor.prototype.onBattleStart;
Game_Actor.prototype.onBattleStart = function() {
  oldOnBattleStart.call(this);
  if (!is(this)) return;
  if (equippedArmor(this) && !this.isStateAffected(ST.form)) this.addState(ST.form);
  if (learned(this, P.feiYing)) { this.addState(ST.immune); this.addState(ST.undying); }
};
var oldStartBattle = BattleManager.setup;
BattleManager.setup = function(troopId, canEscape, canLose) {
  var v = oldStartBattle.call(this, troopId, canEscape, canLose);
  $gameParty.battleMembers().forEach(function(a) {
    if (!is(a)) return;
    if (equippedArmor(a) && !a.isStateAffected(ST.form)) a.addState(ST.form);
    if (learned(a, P.feiYing)) { a.addState(ST.immune); a.addState(ST.undying); }
  });
  return v;
};
var oldEndBattle = BattleManager.endBattle;
BattleManager.endBattle = function(result) {
  $gameParty.members().forEach(function(a) { if (is(a)) L.clearForm(a); });
  return oldEndBattle.call(this, result);
};
// 完全燃烧施放后刷新负面免疫与免死
var oldEndAction = BattleManager.endAction;
BattleManager.endAction = function() {
  var v = oldEndAction.call(this);
  try {
    if (BattleManager._action && is(BattleManager._action.subject()) && equippedWeapon(BattleManager._action.subject())) {
      var a = BattleManager._action.subject();
      if (BattleManager._action.item() && BattleManager._action.item().id === S.ranshao && learned(a, P.feiYing)) {
        L.refreshUndying(a);
      }
    }
  } catch (e) { console.error(e); }
  return v;
};
// 逐火：每次战斗胜利永久 +10 基础生命（记在角色字段，随存档保存）
var oldGainRewards = BattleManager.gainRewards;
BattleManager.gainRewards = function() {
  var v = oldGainRewards.call(this);
  try {
    $gameParty.battleMembers().forEach(function(a) {
      if (is(a) && equippedWeapon(a)) {
        // v0.62.03：前 emberFull 场每场 +10，之后每场 10×emberFull/已胜场数（旧存档按已得生命÷10 估算场数，已得的不收回）
        var ember = Math.max(0, Number(a._codexLbEmber) || 0);
        var wins = a._codexLbEmberWins != null ? Math.max(0, Number(a._codexLbEmberWins) || 0) : Math.floor(ember / 10);
        a._codexLbEmber = ember + 10 * (wins < C.emberFull ? 1 : C.emberFull / wins);
        a._codexLbEmberWins = wins + 1;
      }
    });
  } catch (e) { console.error(e); }
  return v;
};
var oldParamPlus = Game_Actor.prototype.paramPlus;
Game_Actor.prototype.paramPlus = function(paramId) {
  var v = oldParamPlus.call(this, paramId);
  if (is(this) && paramId === 0) v += Number(this._codexLbEmber) || 0;
  if (is(this) && paramId === 2 && equippedWeapon(this)) {
    var lv = Math.max(1, Number(this.level) || 1);
    v += 30 * lv;
  }
  if (is(this) && paramId === 6 && equippedWeapon(this)) {
    var lv2 = Math.max(1, Number(this.level) || 1);
    v += 30 * lv2;
  }
  return v;
};

// ── 11. 号角召唤 ─────────────────────────────────────────────────────
L.recruit = function() {
  if (!$dataActors[C.actor] || !$dataWeapons[C.weapon] || !$dataArmors[C.armor]) throw new Error('流萤数据库缺失');
  if ($gameParty._actors.indexOf(C.actor) !== -1) return false;
  var actor = $gameActors.actor(C.actor);
  $gameParty.addActor(C.actor);
  equipBase(actor, $dataWeapons[C.weapon]);
  equipBase(actor, $dataArmors[C.armor]);
  ImageManager.loadSvActor('Codex_Sam_SV');
  toast('小伙伴 流萤 加入队伍');
  toast('获得并装备专属武器：飞萤逐火·向死而生');
  toast('获得并装备专属法宝：萨姆变身器');
  return true;
};
function equipBase(actor, base) {
  if (!base) return null;
  var slots = actor.equipSlots();
  for (var s = 0; s < slots.length; s++) {
    if (slots[s] !== base.etypeId) continue;
    var worn = actor.equips()[s];
    if (worn && baseId(worn) === base.id) return worn;
    var item = null;
    if (DataManager.isIndependent(base) && $gameParty.gainIndependentItem) {
      var list = $gameParty.gainIndependentItem(base, 1);
      item = list && list[0];
    } else {
      item = base;
    }
    actor.changeEquip(s, item);
    return item;
  }
  return null;
}

// Map132 不朽号角货架（以波风水门号角 2788 识别，同黄泉）；价格读号角备注的魂灯价。
var oldShopPrepare = Scene_Shop.prototype.prepare;
Scene_Shop.prototype.prepare = function(goods, purchaseOnly) {
  goods = goods || [];
  var has = function(id) { return goods.some(function(g) { return g[0] === 0 && g[1] === id; }); };
  if ($gameMap && $gameMap.mapId() === 132 && has(2788) && !has(C.horn) && $dataItems[C.horn]) goods.push([0, C.horn, 0, 0]);
  return oldShopPrepare.call(this, goods, purchaseOnly);
};

// ── 12. 读档重建：按等级/进阶补学，清理越阶技能 ─────────────────────────
L.sync = function(a) {
  if (!is(a) || a._codexLbSync) return;
  a._codexLbSync = true;
  try {
    var lv = Number(a.level) || 1;
    var r = rank(a);
    var levelMap = [[1, P.pianShi], [20, P.guoZai], [35, P.ziXian], [35, P.chiRan]];
    levelMap.forEach(function(pair) {
      if (lv >= pair[0]) { if (!a.isLearnedSkill(pair[1])) a.learnSkill(pair[1]); }
      else if (a.isLearnedSkill(pair[1])) a.forgetSkill(pair[1]);
    });
    var rankMap = [[1, P.zhuiLuo], [2, S.ranshao], [2, P.xingHe], [2, P.feiYing], [3, P.changYe], [3, P.mingTian]];
    if (L.mengYingId()) rankMap.push([1, L.mengYingId()]);
    rankMap.forEach(function(pair) {
      if (r >= pair[0]) { if (!a.isLearnedSkill(pair[1])) a.learnSkill(pair[1]); }
      else if (a.isLearnedSkill(pair[1])) a.forgetSkill(pair[1]);
    });
    if (!a.isLearnedSkill(S.tianhuo)) a.learnSkill(S.tianhuo);
  } finally { delete a._codexLbSync; }
};
var oldExtract = DataManager.extractSaveContents;
DataManager.extractSaveContents = function(contents) {
  oldExtract.call(this, contents);
  var a = $gameActors && $gameActors._data && $gameActors._data[C.actor];
  if (a) L.sync(a);
};
var oldLevelUp = Game_Actor.prototype.levelUp;
Game_Actor.prototype.levelUp = function() {
  var v = oldLevelUp.apply(this, arguments);
  if (is(this)) L.sync(this);
  return v;
};
var oldChangeLevel = Game_Actor.prototype.changeLevel;
Game_Actor.prototype.changeLevel = function(level) {
  var v = oldChangeLevel.call(this, level);
  if (is(this)) L.sync(this);
  return v;
};

// 自然回合冷却：完全燃烧未到可用回合时不可使用。
var oldMeets = Game_Actor.prototype.meetsSkillConditions;
Game_Actor.prototype.meetsSkillConditions = function(skill) {
  if (is(this) && skill && skill.id === S.ranshao) {
    var ready = Number(this._codexLbRsReady) || 0;
    if (ready > turnNow()) return false;
  }
  return oldMeets.call(this, skill);
};

// ── 13. 技能名用品质颜色（10622-10632，原生只覆盖 10171-10224） ─────────
var oldDrawItemName = Window_Base.prototype.drawItemName;
Window_Base.prototype.drawItemName = function(item, x, y, width) {
  var id = item && Number(item.id);
  if (!item || item.stypeId == null || !(id >= 10622 && id <= 10632 || /<CodexLiuyingPassive:/.test(item.note || '')) ||
      !window.RJO || !RJO.IQ || !RJO.IQ.QualitiesColor) {
    return oldDrawItemName.call(this, item, x, y, width);
  }
  var quality = Number(item.meta && item.meta.quality);
  if (!quality) { var m = /<quality:\s*(\d+)>/i.exec(item.note || ''); quality = m ? Number(m[1]) : 0; }
  var color = RJO.IQ.QualitiesColor[quality];
  if (!color) return oldDrawItemName.call(this, item, x, y, width);
  var hadOwn = Object.prototype.hasOwnProperty.call(this, 'itemColor');
  var original = this.itemColor;
  this.itemColor = function() { return color; };
  try { return oldDrawItemName.call(this, item, x, y, width); }
  finally { if (hadOwn) this.itemColor = original; else delete this.itemColor; }
};

// ── 14. 梦应归于何处（一阶）：流萤每损失一次生命，全队叠 1 层萤火印记，终伤 +10%/层，最多 30 层，本场有效 ──
function byTag(list, re) {
  for (var i = 1; list && i < list.length; i++) if (list[i] && re.test(list[i].note || '')) return i;
  return 0;
}
L.mengYingId = function() {
  if (!C._mengYing && window.$dataSkills) C._mengYing = byTag($dataSkills, /<CodexLiuyingPassive:\s*mengYing\s*>/i);
  return C._mengYing || 0;
};
L.fireflyStateId = function() {
  if (!C._firefly && window.$dataStates) C._firefly = byTag($dataStates, /<CodexLiuyingState:\s*firefly\s*>/i);
  return C._firefly || 0;
};
L.fireflyCount = function() {
  return (window.$gameParty && $gameParty.inBattle() && window.$gameTroop) ? Number($gameTroop._codexLbFirefly) || 0 : 0;
};
L.addFirefly = function() {
  var n = Math.min(C.fireflyMax, L.fireflyCount() + 1);
  $gameTroop._codexLbFirefly = n;
  var sid = L.fireflyStateId();
  if (sid) $gameParty.battleMembers().forEach(function(m) { if (m.isAlive() && !m.isStateAffected(sid)) m.addState(sid); });
  return n;
};
// 「一次」按一次行动计：同一行动的多段、扩散只叠 1 层；行动之外的掉血（回合结束等）每次各算一次
var lastFireflyAct = null;   // 只放内存，不进存档
L.noteHpLoss = function(actor) {
  if (!(is(actor) && $gameParty.inBattle() && L.mengYingId() && learned(actor, L.mengYingId()))) return;
  var act = BattleManager._action;
  if (act && lastFireflyAct === act) return;
  lastFireflyAct = act || null;
  L.addFirefly();
};
// 受击、真伤等生命减少经过 setHp；天火的生命消耗在 payHp 里另行计数
var oldSetHp = Game_Actor.prototype.setHp;
Game_Actor.prototype.setHp = function(hp) {
  var prev = this._hp;
  var v = oldSetHp.call(this, hp);
  if (this._hp < prev) L.noteHpLoss(this);
  return v;
};
// 一阶进阶由原生进阶插件学会 10628；同时学会新被动（不改插件参数）
var oldLearn = Game_Actor.prototype.learnSkill;
Game_Actor.prototype.learnSkill = function(skillId) {
  var v = oldLearn.apply(this, arguments);
  if (is(this) && skillId === P.zhuiLuo && L.mengYingId() && !this.isLearnedSkill(L.mengYingId())) oldLearn.call(this, L.mengYingId());
  return v;
};


// ── 15. 技能说明按当前进阶显示（v0.62.08，Kyo 2026-11-01：只写当前阶的数值） ──
// 显示顺序与原生面板一致（伤害在上、效果在下）；HelpExtend 把 APs 行倒序插入，所以写进备注时要反过来。
// 数字取自上面的配置；hiddenRate、逐火递减等暗改项不写。
function apsLine(t) { return '<pos=APs text=' + t + ' size=18 color=rgba(255,255,255,1) line=false align=0>'; }
function formulaText(id) {
  return '伤害：每段[' + C.base[id] + '＋己·最大生命×' + C.hpN + '＋己·物理攻击×' + C.damageN +
    '＋己·敏捷＋施放前护盾×' + C.damageN + ']×[1+技能等级×0.1]';
}
L.skillLines = function(id, r) {
  var rr = Math.round(C.reRelease * 100);
  if (id === S.tianhuo) {
    return [formulaText(id), '伤害属性：火焰·物理', '目标：敌方单体', '命中类型：必中', '能否暴击：是',
      '攻击次数：' + (5 + (r >= 2 ? 3 : 0)),
      '消耗：5%当前生命',
      '装备限制：剑',
      '效果：消耗5%当前生命（至少保留1点），按实际扣除量转化为护盾',
      '效果：除主目标外，其余敌人受到50%扩散伤害',
      '效果：只有一个目标时，伤害结算×1.2',
      '效果：有' + rr + '%概率再释放一次（不再消耗）',
      '效果：主动施放后叠加1层击破印记（多段与再释放不重复叠加）'];
  }
  if (id === S.ranshao) {
    var top = r >= 3;
    var cd = (C.cooldown[S.ranshao] || 4) - (top ? 1 : 0);
    var lines = [formulaText(id), '伤害属性：火焰·物理', '目标：敌方全体', '命中类型：必中', '能否暴击：是',
      '攻击次数：9（只有一个目标时13）',
      '冷却时间：' + cd + '回合（按自然回合计，再动不缩短）' + (top ? '；施放后33%概率不进入冷却' : '')];
    if (!top) lines.push('消耗：当前全部护盾');
    lines.push('装备限制：剑');
    lines.push(top ? '效果：增加与施放前护盾等量的护盾（上限为最大生命' + Math.round(C.shieldCap * 100) + '%）'
                   : '效果：消耗当前全部护盾');
    lines.push('效果：施放后回复全部生命', '效果：只有一个目标时，伤害结算×1.5',
      '效果：有' + rr + '%概率再释放一次（不再消耗、不进冷却）',
      '效果：主动施放后叠加5层击破印记（多段与再释放不重复叠加）');
    if (r < 2) lines.push('解锁：进阶2阶');
    return lines;
  }
  return null;
};
function liuyingActor() { return window.$gameActors && $gameActors._data ? $gameActors._data[C.actor] : null; }
L.refreshText = function(force) {
  if (!window.$dataSkills) return;
  var r = rank(liuyingActor());
  if (!force && C._textRank === r) return;
  C._textRank = r;
  [S.tianhuo, S.ranshao].forEach(function(id) {
    var sk = $dataSkills[id], lines = L.skillLines(id, r);
    if (!sk || !lines) return;
    var keep = String(sk.note || '').split(/\r?\n/).filter(function(t) { return t.indexOf('<pos=APs ') !== 0; });
    sk.note = keep.concat(lines.slice().reverse().map(apsLine)).join('\n');
    if (id === S.ranshao) {
      if (C._rsCostText == null) C._rsCostText = sk.customCostText || '';
      sk.customCostText = r >= 3 ? '' : C._rsCostText;
    }
    if (window.RJO && RJO.HE && RJO.HE.getDescParams) RJO.HE.getDescParams(sk, 3);
  });
};
if (typeof Sprite_ItemHelp !== 'undefined') {
  var oldHelpSetItem = Sprite_ItemHelp.prototype.setItem;
  Sprite_ItemHelp.prototype.setItem = function(item) {
    var id = item && Number(item.id);
    if (item && item.stypeId != null && lbSkill(id) && window.$dataSkills && $dataSkills[id]) {
      L.refreshText();
      if (item !== $dataSkills[id]) item.descParams = $dataSkills[id].descParams;   // 图鉴传入的是副本
    }
    return oldHelpSetItem.apply(this, arguments);
  };
}
var oldSkillListRefresh = Window_SkillList.prototype.refresh;
Window_SkillList.prototype.refresh = function() {
  if (is(this._actor)) L.refreshText();
  return oldSkillListRefresh.apply(this, arguments);
};


// ── 16. 萨姆残核掉落（v0.62.08，Kyo 2026-11-01）────────────────────────
// 不吃队伍掉落率，按难度：天灾及以下 3%、灭世 5%、洪荒按诅咒倍率 6%～18%（全轻 6%，四重一中 18%）。
// 敌人备注 <CodexLiuyingCoreDrop> 标记（神魔之塔 15、17、19、21、27 层深渊「未知存在」，只在深渊地图里掉）；每只被击败的标记敌人独立掷一次。
// <CodexLiuyingCoreDrop:10> 表示该敌人概率至少 10%：取 max(下限, 上面的难度概率)（Kyo 2026-11-01：21、27 层提到 10%）。
// 加在战斗奖励最后，不经 Star_DropTop 的掉落件数上限，也不被品质屏蔽过滤。
C.coreItem = 3062;
C.coreRates = { base: 0.03, doom: 0.05, primordialMin: 0.06, primordialMax: 0.18 };
L.coreRate = function() {
  var A = window.CodexAffixRate, r = A && A.route ? A.route() : null, R = C.coreRates;
  if (!r) return R.base;
  if (r.key === 'primordial') {
    var top = Number(A.HH_MAX) || 6.075, h = Math.min(top, Math.max(1, Number(A.curse()) || 1));
    return R.primordialMin + (R.primordialMax - R.primordialMin) * (h - 1) / (top - 1);
  }
  return r.key === 'doom' ? R.doom : R.base;
};
L.coreRateFor = function(enemy) {
  var m = /<CodexLiuyingCoreDrop(?::\s*(\d+(?:\.\d+)?))?>/i.exec((enemy && enemy.note) || '');
  if (!m || !L.coreMapOk()) return 0;
  return Math.max(L.coreRate(), m[1] ? Number(m[1]) / 100 : 0);
};
// 只在深渊地图（地图名以「深渊」开头）里掉；天之上野外遇到同一批敌人不掉（Kyo 2026-11-01：「不掉」）。
// 地图备注 <CodexLiuyingCoreDrop> 例外放行：猴山（15 层那批的野外，v0.62.08 前就掉）暂时保留，待 Kyo 定。
L.coreMapOk = function() {
  var info = window.$dataMapInfos && window.$gameMap && $dataMapInfos[$gameMap.mapId()];
  if (info && /^深渊/.test(info.name || '')) return true;
  return !!(window.$dataMap && /<CodexLiuyingCoreDrop>/i.test($dataMap.note || ''));
};
var oldMakeRewards = BattleManager.makeRewards;
BattleManager.makeRewards = function() {
  var v = oldMakeRewards.apply(this, arguments);
  try {
    var item = window.$dataItems && $dataItems[C.coreItem], rw = this._rewards;
    if (item && rw) {
      rw.items = rw.items || [];
      $gameTroop.deadMembers().forEach(function(e) {
        var rate = L.coreRateFor(e.enemy());
        if (rate > 0 && Math.random() < rate) rw.items.push(item);
      });
    }
  } catch (e) { console.error(e); }
  return v;
};

return L;
});
